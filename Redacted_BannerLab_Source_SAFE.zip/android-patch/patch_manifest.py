from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()

ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
A = f"{{{ns}}}"

app = root.find("application")
if app is None:
    raise SystemExit("application absente du manifest")

activity = None
for a in app.findall("activity"):
    name = a.get(A + "name", "")
    if name.endswith(".MainActivity") or name == "com.bannerforge.mobile.MainActivity":
        activity = a
        break

if activity is None:
    activity = app.find("activity")
if activity is None:
    raise SystemExit("MainActivity introuvable")

# Deep link retour IITC -> Redacted BannerLab.
exists = False
for filt in activity.findall("intent-filter"):
    for data in filt.findall("data"):
        if data.get(A + "scheme") == "redactedbannerlab":
            exists = True

if not exists:
    filt = ET.SubElement(activity, "intent-filter")
    ET.SubElement(filt, "action", {A + "name": "android.intent.action.VIEW"})
    ET.SubElement(filt, "category", {A + "name": "android.intent.category.DEFAULT"})
    ET.SubElement(filt, "category", {A + "name": "android.intent.category.BROWSABLE"})
    ET.SubElement(filt, "data", {A + "scheme": "redactedbannerlab"})

# Android 11+ : rendre IITC visible aux intents ciblés.
queries = root.find("queries")
if queries is None:
    queries = ET.Element("queries")
    # AndroidManifest convention: queries before application when possible.
    children = list(root)
    app_index = children.index(app)
    root.insert(app_index, queries)

wanted = [
    "org.exarhteam.iitc_mobile",
    "org.exarhteam.iitcprime",
]

existing_packages = {
    p.get(A + "name")
    for p in queries.findall("package")
}

for package_name in wanted:
    if package_name not in existing_packages:
        ET.SubElement(queries, "package", {A + "name": package_name})

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print("Deep link BannerLab + visibilité IITC Mobile/IITC Prime ajoutés.")
