import './style.css';
import JSZip from 'jszip';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { IntentLauncher, ActivityAction } from '@capgo/capacitor-intent-launcher';

const APP_VERSION = '0.7.1';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;

const SUPPORTED_LANGS=['fr','en','es'];
let APP_LANG=localStorage.getItem('rbl-language')||((navigator.language||'fr').toLowerCase().startsWith('es')?'es':(navigator.language||'fr').toLowerCase().startsWith('en')?'en':'fr');
if(!SUPPORTED_LANGS.includes(APP_LANG))APP_LANG='fr';
const I18N={
  fr:{
    fresco:'Fresque',route:'Parcours',missions:'Missions',publish:'Publier',projects:'Projets',rows:'Rangées',
    image:'Image',framing:'Cadrage',text:'Texte',preview:'Aperçu',export:'Exporter',
    wholeFresco:'Fresque entière',oneMission:'Une mission',noMission:'Aucune mission sélectionnée',
    addImage:'Ajoute ton image',imageHint:'Elle sera cadrée directement sur la géométrie Prime.',
    circles:'Cercles Prime',grid:'Grille 512',numbers:'Numéros',enlarge:'Agrandir mission',resetMission:'Réinitialiser mission',
    prev:'Précédente',next:'Suivante',complete:'Mission complète',remaining:'Encore {n} portail(s)',
    openIitc:'Ouvrir IITC Companion',tutorial:'Tutoriel',installPlugin:'Installer / mettre à jour le plugin IITC',
    addPortal:'Ajouter un portail manuellement',autoAdvance:'Passer automatiquement à la mission suivante à {n} portails',
    reuseLast:'Reprendre automatiquement le dernier portail comme premier de la mission suivante',
    carryPrev:'Reprendre le dernier portail précédent',noPortal:'Aucun portail pour cette mission.',
    action:'Action',hack:'Hack',mod:'Installer un mod',capture:'Capturer / améliorer',link:'Créer un lien',field:'Créer un champ',passphrase:'Passphrase',
    question:'Question',answer:'Réponse attendue',save:'Enregistrer',cancel:'Annuler',
    settings:'Réglages communs',commonDesc:'Description commune',titleFormat:'Format des titres',defaultType:'Type par défaut',
    location:'Localisation',visible:'Visible',hidden:'Cachée',sequential:'Séquentielle',anyOrder:'Ordre libre',
    portalsPerMission:'Portails / mission',editMission:'Éditer la mission',title:'Titre',description:'Description',
    missionReady:'Prête',missionIncomplete:'Incomplète',openRoute:'Modifier le parcours',
    publishPack:'Créer le pack BannerLab',openMat:'Ouvrir Mission Authoring Tool',
    ownWorkflow:'BannerLab utilise désormais son propre format de projet et son propre pack de publication.',
    language:'Langue',french:'Français',english:'English',spanish:'Español',
    companionStats:'Stats piétonnes dans IITC',companionStatsDesc:'Dans le mini panneau IITC : 📊 Stats inutiles calcule les km à pied estimés, temps, détour et autres absurdités.',
    duplicateBad:'{n} réutilisation(s) de portail à vérifier.',handoverOk:'La reprise fin → début de mission est autorisée.',
    pluginVersion:'Companion 0.5',
    undo:'Annuler',redo:'Rétablir'
  },
  en:{
    fresco:'Banner',route:'Route',missions:'Missions',publish:'Publish',projects:'Projects',rows:'Rows',
    image:'Image',framing:'Framing',text:'Text',preview:'Preview',export:'Export',
    wholeFresco:'Whole banner',oneMission:'One mission',noMission:'No mission selected',
    addImage:'Add your image',imageHint:'It will be framed directly on the Prime geometry.',
    circles:'Prime circles',grid:'512 grid',numbers:'Numbers',enlarge:'Enlarge mission',resetMission:'Reset mission',
    prev:'Previous',next:'Next',complete:'Mission complete',remaining:'{n} portal(s) remaining',
    openIitc:'Open IITC Companion',tutorial:'Tutorial',installPlugin:'Install / update IITC plugin',
    addPortal:'Add a portal manually',autoAdvance:'Automatically move to next mission at {n} portals',
    reuseLast:'Automatically reuse the last portal as the first portal of the next mission',
    carryPrev:'Reuse previous mission last portal',noPortal:'No portal in this mission.',
    action:'Action',hack:'Hack',mod:'Install a mod',capture:'Capture / upgrade',link:'Create a link',field:'Create a field',passphrase:'Passphrase',
    question:'Question',answer:'Expected answer',save:'Save',cancel:'Cancel',
    settings:'Common settings',commonDesc:'Common description',titleFormat:'Title format',defaultType:'Default type',
    location:'Location',visible:'Visible',hidden:'Hidden',sequential:'Sequential',anyOrder:'Any order',
    portalsPerMission:'Portals / mission',editMission:'Edit mission',title:'Title',description:'Description',
    missionReady:'Ready',missionIncomplete:'Incomplete',openRoute:'Edit route',
    publishPack:'Create BannerLab pack',openMat:'Open Mission Authoring Tool',
    ownWorkflow:'BannerLab now uses its own project format and publication pack.',
    language:'Language',french:'Français',english:'English',spanish:'Español',
    companionStats:'Walking stats in IITC',companionStatsDesc:'In the IITC mini panel: 📊 Useless stats calculates estimated walking distance, time, detour and other nonsense.',
    duplicateBad:'{n} portal reuse(s) to review.',handoverOk:'Mission-end → next-start reuse is allowed.',
    pluginVersion:'Companion 0.5',
    undo:'Undo',redo:'Redo'
  },
  es:{
    fresco:'Mosaico',route:'Recorrido',missions:'Misiones',publish:'Publicar',projects:'Proyectos',rows:'Filas',
    image:'Imagen',framing:'Encuadre',text:'Texto',preview:'Vista previa',export:'Exportar',
    wholeFresco:'Mosaico completo',oneMission:'Una misión',noMission:'Ninguna misión seleccionada',
    addImage:'Añade tu imagen',imageHint:'Se encuadrará directamente con la geometría Prime.',
    circles:'Círculos Prime',grid:'Cuadrícula 512',numbers:'Números',enlarge:'Ampliar misión',resetMission:'Restablecer misión',
    prev:'Anterior',next:'Siguiente',complete:'Misión completa',remaining:'Faltan {n} portal(es)',
    openIitc:'Abrir IITC Companion',tutorial:'Tutorial',installPlugin:'Instalar / actualizar plugin IITC',
    addPortal:'Añadir portal manualmente',autoAdvance:'Pasar automáticamente a la siguiente misión al llegar a {n} portales',
    reuseLast:'Reutilizar automáticamente el último portal como primero de la siguiente misión',
    carryPrev:'Reutilizar el último portal anterior',noPortal:'No hay portales en esta misión.',
    action:'Acción',hack:'Hackear',mod:'Instalar un mod',capture:'Capturar / mejorar',link:'Crear un enlace',field:'Crear un campo',passphrase:'Contraseña',
    question:'Pregunta',answer:'Respuesta esperada',save:'Guardar',cancel:'Cancelar',
    settings:'Ajustes comunes',commonDesc:'Descripción común',titleFormat:'Formato de títulos',defaultType:'Tipo predeterminado',
    location:'Ubicación',visible:'Visible',hidden:'Oculta',sequential:'Secuencial',anyOrder:'Cualquier orden',
    portalsPerMission:'Portales / misión',editMission:'Editar misión',title:'Título',description:'Descripción',
    missionReady:'Lista',missionIncomplete:'Incompleta',openRoute:'Editar recorrido',
    publishPack:'Crear paquete BannerLab',openMat:'Abrir Mission Authoring Tool',
    ownWorkflow:'BannerLab usa ahora su propio formato de proyecto y paquete de publicación.',
    language:'Idioma',french:'Français',english:'English',spanish:'Español',
    companionStats:'Estadísticas a pie en IITC',companionStatsDesc:'En el mini panel IITC: 📊 Stats inútiles calcula distancia a pie estimada, tiempo, desvío y otras tonterías.',
    duplicateBad:'{n} reutilización(es) de portal para revisar.',handoverOk:'Se permite reutilizar fin de misión → inicio de la siguiente.',
    pluginVersion:'Companion 0.5',
    undo:'Deshacer',redo:'Rehacer'
  }
};
function tr(key,vars={}){
  let s=(I18N[APP_LANG]&&I18N[APP_LANG][key])||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))s=s.replaceAll('{'+k+'}',String(v));
  return s;
}
function setAppLanguage(lang){
  if(!SUPPORTED_LANGS.includes(lang))return;
  localStorage.setItem('rbl-language',lang);
  location.reload();
}

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  name: 'Ma fresque',
  rows: 3,
  showGrid: true,
  showCircles: true,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0 },
  texts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    reuseLastPortal: true,
    currentMission: 0,
    missions: []
  }
};

let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;
let historyUndo = [];
let historyRedo = [];
let historyBusy = false;
const HISTORY_LIMIT = 80;

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function snapshotState(){
  const data=serializeState();
  delete data.updatedAt;
  return {data:deepClone(data),blob:state.bg.blob,image:state.bg.image,active:state.active};
}
function snapshotsEqual(a,b){
  return !!a&&!!b&&a.blob===b.blob&&a.image===b.image&&a.active===b.active&&JSON.stringify(a.data)===JSON.stringify(b.data);
}
function beginHistory(){return historyBusy?null:snapshotState()}
function commitHistory(before,label='Modification'){
  if(historyBusy||!before)return;
  const after=snapshotState();
  if(snapshotsEqual(before,after))return;
  historyUndo.push({snapshot:before,label});
  if(historyUndo.length>HISTORY_LIMIT)historyUndo.shift();
  historyRedo.length=0;
  updateHistoryUi();
}
function resetHistory(){historyUndo=[];historyRedo=[];updateHistoryUi()}
async function restoreSnapshot(snap){
  if(!snap)return;
  historyBusy=true;
  try{
    const d=snap.data||{};
    state.name=d.name||'Ma fresque';
    state.rows=clamp(parseInt(d.rows)||3,1,25);
    state.showGrid=d.showGrid!==false;state.showCircles=d.showCircles!==false;state.showNumbers=d.showNumbers!==false;
    state.editMode=d.editMode==='mission'?'mission':'fresco';
    state.selectedMissionKey=d.selectedMissionKey||null;
    state.missionOverrides=deepClone(d.missionOverrides||{});
    state.texts=deepClone(d.texts||[]);
    state.active=snap.active||'background';
    state.planner=normalizePlanner(d.planner||{});ensurePlannerMissions();
    state.bg={image:snap.image||null,blob:snap.blob||null,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0};
    Object.assign(state.bg,d.bg||{});
    if(!state.bg.image&&state.bg.blob)state.bg.image=await blobToImage(state.bg.blob);
    refreshProjectUi();render();
    if(missionEditorBack)renderMissionEditor();
    scheduleSave();
  }finally{historyBusy=false;updateHistoryUi()}
}
async function undoAction(){
  const item=historyUndo.pop();if(!item)return;
  historyRedo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('undo')} · ${item.label}`);
}
async function redoAction(){
  const item=historyRedo.pop();if(!item)return;
  historyUndo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('redo')} · ${item.label}`);
}
function updateHistoryUi(){
  const undoDisabled=!historyUndo.length,redoDisabled=!historyRedo.length;
  $$('.undoActionBtn').forEach(b=>{b.disabled=undoDisabled;b.classList.toggle('disabled',undoDisabled);b.title=undoDisabled?tr('undo'):`${tr('undo')} · ${historyUndo.at(-1).label}`});
  $$('.redoActionBtn').forEach(b=>{b.disabled=redoDisabled;b.classList.toggle('disabled',redoDisabled);b.title=redoDisabled?tr('redo'):`${tr('redo')} · ${historyRedo.at(-1).label}`});
}
function historyControl(el,label){
  if(!el)return;
  let before=null;
  const begin=()=>{if(before===null)before=beginHistory()};
  const commit=()=>{if(before!==null){commitHistory(before,label);before=null}};
  el.addEventListener('pointerdown',begin);
  el.addEventListener('focus',begin);
  el.addEventListener('change',commit);
  el.addEventListener('blur',commit);
}

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand">
        <div class="brandmark"><img src="/redacted-logo-512.png" alt="Redacted"></div>
        <div><h1>Redacted BannerLab</h1><small>Fresques Ingress Prime · v${APP_VERSION}</small></div>
      </div>
      <div class="grow"></div><button class="iconbtn" id="infoBtn" aria-label="Infos">${icon('info')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div class="projectidentity"><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> missions · source ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>${tr("projects")}</span></button>
        <div class="rowpick"><span>${tr("rows")}</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>${tr("fresco")}</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>${tr("route")}</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>${tr("missions")}</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>${tr("publish")}</span></button>
      </div>
      <div class="card workspace">
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">${tr("wholeFresco")}</button>
          <button class="modebtn" data-editmode="mission">${tr("oneMission")}</button>
          <div class="missionstatus" id="missionStatus">${tr("noMission")}</div>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>${tr("addImage")}</strong>${tr("imageHint")}</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">${tr("circles")}</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">${tr("grid")}</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">${tr("numbers")}</button>
          <button class="chip historychip undoActionBtn" id="undoBtn" disabled>↶ ${tr("undo")}</button>
          <button class="chip historychip redoActionBtn" id="redoBtn" disabled>↷ ${tr("redo")}</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} ${tr("enlarge")}</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>${tr("resetMission")}</button>
        </div>
        <div class="hint" id="gestureHint"><b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>${tr("image")}</span></button>
      <button class="tool active" data-tool="move">${icon('move')}<span>${tr("framing")}</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>${tr("text")}</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>${tr("preview")}</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>${tr("export")}</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawBaseBackground(c){
  if(!state.bg.image)return;
  const b=state.bg;
  c.save();c.translate(b.x,b.y);c.rotate(b.rotation);c.scale(b.scale,b.scale);
  c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
}

function drawOverlayWorld(c){
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  const lines=(t.text||'Texte').split('\n');
  c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  const lineH=t.fontSize*1.08;
  lines.forEach((line,i)=>{const y=(i-(lines.length-1)/2)*lineH;if(t.strokeWidth>0){c.lineWidth=t.strokeWidth;c.strokeStyle=t.strokeColor;c.strokeText(line,0,y)}c.fillStyle=t.color;c.fillText(line,0,y)});
  c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseBackground(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseBackground(c);
    c.restore();
  }
  drawOverlayWorld(c);
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=state.bg.image?'none':'grid';
  updateMissionUi();
  updateHistoryUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission'||!state.active.startsWith('text:'))return;
  const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
  c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;
  const lines=t.text.split('\n');const w=Math.max(...lines.map(x=>c.measureText(x).width),40)+36;const h=lines.length*t.fontSize*1.08+28;
  c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  $$('.tool').forEach(b=>b.classList.toggle('active',(b.dataset.tool==='move'&&a==='background')||(b.dataset.tool==='text'&&a.startsWith('text:'))));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=`Mission ${missionNumber(rc.row,rc.col)} sélectionnée`;
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent='Touche un médaillon';reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML='<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi la déplacer directement ici à 1 doigt.';
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML='<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.';
  }
}

async function loadImageFile(file){
  if(!file)return;
  const before=beginHistory();
  if(file.size>45*1024*1024)toast('Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.');
  const img=await blobToImage(file);state.bg.blob=file;state.bg.image=img;
  fitBackground();setEditMode('fresco');setActive('background');commitHistory(before,'Importer image');scheduleSave();render();toast(`${img.naturalWidth} × ${img.naturalHeight} px importés`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight)}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasPointToMission(clientX,clientY){
  const rect=canvas.getBoundingClientRect();const scale=rect.width/WORLD_W;
  const x=(clientX-rect.left)/scale,y=(clientY-rect.top)/scale;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

canvas.addEventListener('pointerdown',e=>{
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(pointers.size===1){gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,isMission:state.editMode==='mission',historyBefore:beginHistory()}}
  else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:state.editMode==='mission',historyBefore:gesture?.historyBefore||beginHistory()}}
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(pointers.size===1&&gesture?.mode==='one'){
    const dx=(e.clientX-gesture.startX)/getCssScale(),dy=(e.clientY-gesture.startY)/getCssScale();
    if(state.editMode==='mission'){obj.dx=gesture.objX+dx;obj.dy=gesture.objY+dy}else{obj.x=gesture.objX+dx;obj.y=gesture.objY+dy}
    render();
  } else if(pointers.size===2){
    const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),historyBefore:gesture?.historyBefore||beginHistory()};return}
    const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);
    obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),state.editMode==='mission'?.2:.02,state.editMode==='mission'?5:30);obj.rotation=gesture.objRot+(a-gesture.angle);
    const x=gesture.objX+(m.x-gesture.mid.x)/getCssScale(),y=gesture.objY+(m.y-gesture.mid.y)/getCssScale();
    if(state.editMode==='mission'){obj.dx=x;obj.dy=y}else{obj.x=x;obj.y=y}
    render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){
    const before=gesture?.historyBefore,label=state.editMode==='mission'?'Recadrage mission':(state.active.startsWith('text:')?'Déplacement texte':'Cadrage image');
    gesture=null;commitHistory(before,label);scheduleSave();
  }else if(pointers.size===1){
    const p=[...pointers.values()][0],obj=selectedObj(),before=gesture?.historyBefore;
    if(obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:state.editMode==='mission'?(obj.dx||0):obj.x,objY:state.editMode==='mission'?(obj.dy||0):obj.y,historyBefore:before};
  }
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||'Ma fresque';ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>changeRows(+e.target.value));
function changeRows(rows){
  const before=beginHistory();
  const oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();commitHistory(before,'Changer le nombre de rangées');scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>setEditMode(btn.dataset.editmode)));
$('#resetMissionBtn').addEventListener('click',resetSelectedMission);
$('#openMissionEditorBtn').addEventListener('click',openMissionEditor);

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(t==='image')$('#fileInput').click();
  if(t==='move')openTransformSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#infoBtn').addEventListener('click',openInfoSheet);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$('#undoBtn').addEventListener('click',undoAction);
$('#redoBtn').addEventListener('click',redoAction);
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  $$('.flowstep').forEach(x=>x.classList.toggle('on',x===btn));
  const flow=btn.dataset.flow;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}));

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}

function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast('Touche d’abord la mission que tu veux recadrer.');return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>Mission ${n}</h2><p>Ce cadrage ne touche qu’à ce médaillon.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>Zoom local <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>Rotation <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} Réinitialiser cette mission</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),'Zoom mission');
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),'Rotation mission');
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:');
  const baseScale=state.bg.image?Math.max(WORLD_W/state.bg.image.naturalWidth,worldH()/state.bg.image.naturalHeight):1;
  const zoomValue=Math.round((isText?o.scale:o.scale/baseScale)*100);
  const sh=openSheet(`<div class="sheethead"><div><h2>${isText?'Transformer le texte':'Cadrer l’image'}</h2><p>Le geste à deux doigts reste disponible directement sur la fresque.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Zoom</label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>Rotation <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">Centrer</button><button class="secondary" id="resetBtn">${icon('reset')} Réinitialiser</button>${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} Supprimer</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),isText?'Rotation texte':'Rotation image');
  $('#zoom',sh).oninput=e=>{if(isText)o.scale=+e.target.value/100;else if(state.bg.image)o.scale=baseScale*(+e.target.value/100);render();scheduleSave()};historyControl($('#zoom',sh),isText?'Zoom texte':'Zoom image');
  $('#centerBtn',sh).onclick=()=>{const before=beginHistory();o.x=WORLD_W/2;o.y=worldH()/2;render();commitHistory(before,isText?'Centrer texte':'Centrer image');scheduleSave()};
  $('#resetBtn',sh).onclick=()=>{const before=beginHistory();if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else fitBackground();closeSheet();render();commitHistory(before,isText?'Réinitialiser texte':'Réinitialiser image');scheduleSave()};
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast('Sélectionne d’abord une mission.');return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="Fermer">${icon('close')}</button>
      <div><strong id="missionEditorTitle">Mission ${n}</strong><span>Recadrage individuel · 512 × 512</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="Aperçu cercle">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>1 doigt</b> déplacer · <b>2 doigts</b> zoomer et tourner</div>
    <section class="missioneditorcontrols">
      <div class="missionhistory"><button class="secondary undoActionBtn missionundo" disabled>↶ ${tr('undo')}</button><button class="secondary redoActionBtn missionredo" disabled>↷ ${tr('redo')}</button></div>
      <div class="missionnav">
        <button class="secondary missionprev">‹ Mission précédente</button>
        <button class="secondary missionnext">Mission suivante ›</button>
      </div>
      <div class="field"><label>Zoom <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>Rotation <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} Réinitialiser</button><button class="primary missiondone">Terminé</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const before=beginHistory(),o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();commitHistory(before,'Réinitialiser mission');scheduleSave();};
  $('.missionundo',back).onclick=undoAction;$('.missionredo',back).onclick=redoAction;
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorZoom',back),'Zoom mission');
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorRot',back),'Rotation mission');
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=`Mission ${n}`;
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0,historyBefore:beginHistory()};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){const before=missionEditorGesture?.historyBefore;missionEditorGesture=null;commitHistory(before,'Recadrage mission');scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0],before=missionEditorGesture?.historyBefore;missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0,historyBefore:before};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  const before=beginHistory();
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();commitHistory(before,'Réinitialiser mission');scheduleSave();toast(`Mission ${missionNumber(rc.row,rc.col)} réinitialisée`);
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  const before=beginHistory();
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();commitHistory(before,'Supprimer texte');scheduleSave();toast('Texte supprimé');
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>Texte</h2><p>Chaque texte reste un calque indépendant, modifiable ou supprimable.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Calque</label><select id="textLayer"><option value="new">+ Nouveau texte</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);const box=$('#textEditor',sh);
    box.innerHTML=`<div class="field"><label>Texte</label><input id="txt" value="${escapeAttr(t?.text||'GREEN RILLETTES 7')}" maxlength="120"></div>
      <div class="grid2"><div class="field"><label>Taille</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>Contour</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div></div>
      <div class="grid2"><div class="field"><label>Couleur</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div><div class="field"><label>Couleur contour</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?'Mettre à jour':'Ajouter'}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} Supprimer</button>`:''}</div>`;
    $('#saveText',box).onclick=()=>{
      const before=beginHistory(),wasNew=!t;
      if(!t){t={id:uid(),text:$('#txt',box).value||'Texte',x:WORLD_W/2,y:worldH()/2,fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,scale:1,rotation:0};state.texts.push(t)}
      else Object.assign(t,{text:$('#txt',box).value||'Texte',fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0});
      setActive('text:'+t.id);commitHistory(before,wasNew?'Ajouter texte':'Modifier texte');scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Aperçu Prime</h2><p>Les recadrages individuels sont déjà appliqués.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseBackground(cc);cc.restore();
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);drawOverlayWorld(cc);cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>Exporter ${count} missions</h2><p>Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!state.bg.image?'<div class="rule warning"><span class="dot"></span><span>Aucune image de fond n’est chargée.</span></div>':''}
    <div class="field"><label>Format des missions</label><select id="exportFormat"><option value="jpeg" selected>JPG rapide · qualité élevée</option><option value="png">PNG sans perte · plus lent</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.</span></div><div class="rule"><span class="dot"></span><span>Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.</span></div><div class="rule"><span class="dot"></span><span>${adjusted} mission(s) avec recadrage individuel.</span></div><div class="rule warning"><span class="dot"></span><span>Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">Prêt.</div>
    <div class="actions"><button class="primary" id="doExport" ${!state.bg.image?'disabled':''}>Créer le ZIP</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseBackground(cc);drawOverlayWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent='Assemblage du ZIP…';bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`Assemblage du ZIP… ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent='ZIP créé.';
      await Share.share({title:'Export Redacted BannerLab',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:'Enregistrer ou partager le ZIP'});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent='ZIP téléchargé.';
    }
    toast(`Export ${jpeg?'JPG rapide':'PNG'} terminé`);
  }catch(err){console.error(err);txt.textContent='Erreur : '+(err?.message||err);toast('L’export a échoué.')}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}\n${state.name}\n${state.rows} rangée(s) · ${state.rows*6} missions\n\nOrdre de création :\n`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false);s+=`${String(n).padStart(3,'0')}.${ext} : rangée ${row+1} depuis le haut, colonne ${col+1} depuis la gauche${o&&!isIdentityOverride(o)?' · recadrage individuel':''}\n`}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('Canvas export impossible')),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const OBJECTIVE_LABELS={
  HACK_PORTAL:'hack',
  INSTALL_MOD:'mod',
  CAPTURE_PORTAL:'capture',
  CREATE_LINK:'link',
  CREATE_FIELD:'field',
  PASSPHRASE:'passphrase'
};
function objectiveLabel(type){return tr(OBJECTIVE_LABELS[type]||'hack')}
function missionSequential(m){return typeof m?.sequential==='boolean'?m.sequential:state.planner.sequential!==false}
function missionHidden(m){return missionSequential(m)&&(typeof m?.hiddenLocation==='boolean'?m.hiddenLocation:!!state.planner.hiddenLocation)}


function normalizePlanner(p={}){
  const planner={
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||6,1,24),
    autoAdvance: p.autoAdvance!==false,
    reuseLastPortal: p.reuseLastPortal!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    sequential: typeof m.sequential==='boolean'?m.sequential:null,
    hiddenLocation: typeof m.hiddenLocation==='boolean'?m.hiddenLocation:null,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||'Portail'),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||'Fresque';
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function guidOccurrences(guid){
  const out=[];
  state.planner.missions.forEach((m,mi)=>(m.portals||[]).forEach((p,pi)=>{if(guid&&p.guid===guid)out.push({mi,pi})}));
  return out;
}
function isAllowedHandoverOccurrences(occ){
  if(occ.length!==2)return false;
  const [a,b]=occ;
  if(b.mi!==a.mi+1||b.pi!==0)return false;
  const prev=state.planner.missions[a.mi]?.portals||[];
  return a.pi===prev.length-1;
}
function duplicateGuidCount(){
  const guids=new Set(state.planner.missions.flatMap(m=>(m.portals||[]).map(p=>p.guid).filter(Boolean)));
  let bad=0;
  for(const guid of guids){const occ=guidOccurrences(guid);if(occ.length>1&&!isAllowedHandoverOccurrences(occ))bad++}
  return bad;
}
function canReuseAsHandover(portal,mi){
  if(!portal?.guid||mi<=0)return false;
  const cur=plannerMission(mi),prev=plannerMission(mi-1);
  return cur.portals.length===0&&prev?.portals?.at(-1)?.guid===portal.guid;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):tr('route');
  const badGuid=!p.guid,pass=p.objective?.type==='PASSPHRASE';
  const extra=pass&&p.objective?.passphrase_params?.question?` · ${escapeHtml(p.objective.passphrase_params.question)}`:'';
  return `<div class="portalrow portalrow-v2" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||'Portail')}</strong><span>${dist}${badGuid?' · GUID ?':''}</span>
      <button class="portalactionbtn">${escapeHtml(objectiveLabel(p.objective?.type))}${extra}</button>
    </div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="↑">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="↓">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="×">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('route')} · ${tr('missions')} ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} ${tr('portalsPerMission').split(' / ')[0].toLowerCase()} · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ ${tr('prev')}</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>${tr('next')} ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?tr('complete'):tr('remaining',{n:Math.max(0,need-count)})}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion">
      <div class="iitccompanion-head"><img src="/redacted-logo-512.png" alt="Redacted"><div><b>IITC Companion</b><span>${tr('companionStats')}</span></div><span class="beta">${tr('pluginVersion')}</span></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('companionStats')}</b><small>${tr('companionStatsDesc')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('action')}</b><small>Hack / Mod / Capture / Link / Field / Passphrase directement depuis le Companion.</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('handoverOk')}</b><small>Le dernier portail peut devenir le premier de la mission suivante sans être considéré comme un doublon fautif.</small></div></div>
      <div class="actions companionactions"><button class="primary openintel">${icon('globe')} ${tr('openIitc')}</button><button class="secondary tutorialiitc">${icon('info')} ${tr('tutorial')}</button></div>
      <div class="actions companionsecondary"><button class="secondary sharebridge">${tr('installPlugin')}</button></div>
    </div>
    <div class="actions routeactions"><button class="secondary addportal">${icon('plus')} ${tr('addPortal')}</button></div>
    <div class="routeoptions">
      <label class="switchline"><input type="checkbox" id="autoAdvance" ${state.planner.autoAdvance?'checked':''}> ${tr('autoAdvance',{n:need})}</label>
      <label class="switchline"><input type="checkbox" id="reuseLastPortal" ${state.planner.reuseLastPortal?'checked':''}> ${tr('reuseLast')}</label>
    </div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${tr('duplicateBad',{n:dup})}</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):`<div class="emptyroute">${tr('noPortal')}</div>`}</div>
    <div class="actions"><button class="secondary carryprev" ${idx===0||!plannerMission(idx-1)?.portals?.length||m.portals.length?'disabled':''}>${tr('carryPrev')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('#autoAdvance',sh).onchange=e=>{state.planner.autoAdvance=e.target.checked;scheduleSave()};
  $('#reuseLastPortal',sh).onchange=e=>{state.planner.reuseLastPortal=e.target.checked;scheduleSave()};
  $('.openintel',sh).onclick=openIntel;
  $('.tutorialiitc',sh).onclick=openIitcTutorial;
  $('.addportal',sh).onclick=()=>openAddPortalSheet(idx);
  $('.carryprev',sh).onclick=()=>{const prev=plannerMission(idx-1)?.portals?.at(-1);if(prev){addPortalToMission(structuredClone(prev),idx,{handover:true});openRoutePlanner()}};
  $('.sharebridge',sh).onclick=shareIitcBridge;
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalactionbtn',row).onclick=()=>openPortalObjectiveSheet(idx,pi);
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();openRoutePlanner();
}
function removePortal(mi,pi){const m=plannerMission(mi);if(!m)return;m.portals.splice(pi,1);scheduleSave();openRoutePlanner()}

function openPortalObjectiveSheet(mi,pi){
  const m=plannerMission(mi),p=m?.portals?.[pi];if(!p)return;
  const options=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('action')}</h2><p>${escapeHtml(p.title)}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('action')}</label><select id="objectiveType">${options}</select></div>
    <div class="passphraseFields" ${p.objective?.type==='PASSPHRASE'?'':'hidden'}>
      <div class="field"><label>${tr('question')}</label><input id="passQuestion" value="${escapeAttr(p.objective?.passphrase_params?.question||'')}"></div>
      <div class="field"><label>${tr('answer')}</label><input id="passAnswer" value="${escapeAttr(p.objective?.passphrase_params?._single_passphrase||'')}"></div>
    </div>
    <div class="actions"><button class="secondary close2">${tr('cancel')}</button><button class="primary saveobj">${tr('save')}</button></div>`);
  const update=()=>$('.passphraseFields',sh).hidden=$('#objectiveType',sh).value!=='PASSPHRASE';
  $('#objectiveType',sh).onchange=update;
  $('.close',sh).onclick=closeSheet;$('.close2',sh).onclick=closeSheet;
  $('.saveobj',sh).onclick=()=>{
    p.objective.type=$('#objectiveType',sh).value;
    p.objective.passphrase_params.question=$('#passQuestion',sh)?.value?.trim()||'';
    p.objective.passphrase_params._single_passphrase=$('#passAnswer',sh)?.value?.trim()||'';
    scheduleSave();openRoutePlanner();
  };
}

function openAddPortalSheet(mi=state.planner.currentMission,prefill={}){
  const opts=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}">${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('addPortal')}</h2><p>${tr('missions')} ${mi+1}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Lien Intel</label><input id="intelUrl" placeholder="https://intel.ingress.com/intel?...&pll=47.1,-1.6" value="${escapeAttr(prefill.url||'')}"></div>
    <div class="field"><label>Portail</label><input id="portalTitle" value="${escapeAttr(prefill.title||'')}"></div>
    <div class="field"><label>GUID</label><input id="portalGuid" value="${escapeAttr(prefill.guid||'')}"></div>
    <div class="grid2"><div class="field"><label>Latitude</label><input id="portalLat" inputmode="decimal" value="${escapeAttr(prefill.lat??'')}"></div><div class="field"><label>Longitude</label><input id="portalLng" inputmode="decimal" value="${escapeAttr(prefill.lng??'')}"></div></div>
    <div class="field"><label>${tr('action')}</label><select id="portalObjective">${opts}</select></div>
    <div class="passphraseFields" hidden><div class="field"><label>${tr('question')}</label><input id="portalQuestion"></div><div class="field"><label>${tr('answer')}</label><input id="portalAnswer"></div></div>
    <div class="actions"><button class="secondary parseintel">Lire le lien Intel</button><button class="primary saveportal">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#portalObjective',sh).onchange=()=>$('.passphraseFields',sh).hidden=$('#portalObjective',sh).value!=='PASSPHRASE';
  $('.parseintel',sh).onclick=()=>{const p=parseIntelUrl($('#intelUrl',sh).value);if(!p){toast('Coordonnées introuvables.');return}$('#portalLat',sh).value=p.lat;$('#portalLng',sh).value=p.lng;};
  $('.saveportal',sh).onclick=()=>{
    const lat=parseFloat(String($('#portalLat',sh).value).replace(',','.')),lng=parseFloat(String($('#portalLng',sh).value).replace(',','.'));
    if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180){toast('Coordonnées invalides.');return}
    const p=normalizePortal({guid:$('#portalGuid',sh).value.trim(),title:$('#portalTitle',sh).value.trim()||'Portail',location:{latitude:lat,longitude:lng},
      objective:{type:$('#portalObjective',sh).value,passphrase_params:{question:$('#portalQuestion',sh).value.trim(),_single_passphrase:$('#portalAnswer',sh).value.trim()}}});
    addPortalToMission(p,mi);openRoutePlanner();
  };
}
function parseIntelUrl(raw){
  try{const u=new URL(raw.trim());const pll=u.searchParams.get('pll');if(!pll)return null;const [lat,lng]=pll.split(',').map(Number);if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;return {lat,lng}}catch{return null}
}
function addPortalToMission(portal,mi=state.planner.currentMission,opts={}){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  const p=normalizePortal(portal);
  const occ=p.guid?guidOccurrences(p.guid):[];
  const allowed=opts.handover||canReuseAsHandover(p,mi);
  if(occ.length&&!allowed){toast('Ce portail est déjà utilisé ailleurs dans la bannière.');return false}
  m.portals.push(p);scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){
    const last=m.portals.at(-1);
    state.planner.currentMission=mi+1;
    const next=plannerMission(mi+1);
    if(state.planner.reuseLastPortal&&next.portals.length===0&&last)next.portals.push(structuredClone(last));
    scheduleSave();
    toast(`Mission ${mi+1} complète · ${mi+2}`);
  }else toast(`Portail ajouté · mission ${mi+1}`);
  return true;
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||'Portail',Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL',p.objective?.passphrase_params?.question||'',p.objective?.passphrase_params?._single_passphrase||'']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||'Portail',location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL',passphrase_params:{question:a?.[6]||'',_single_passphrase:a?.[7]||''}}})}
function bridgePlannerPayload(){
  ensurePlannerMissions();return {v:3,pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,carry:state.planner.reuseLastPortal!==false,lang:APP_LANG,m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact))};
}
async function openIntel(){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  u.searchParams.set('rbl',bridgeEncode(bridgePlannerPayload()));

  if(!Capacitor.isNativePlatform()){
    window.open(u.toString(),'_blank','noopener');
    return;
  }

  // Android : une URL https seule part dans Chrome. On cible donc explicitement
  // IITC Mobile avec ACTION_VIEW + l'URL contenant le payload BannerLab.
  const candidates=[
    'org.exarhteam.iitc_mobile',
    'org.exarhteam.iitcprime'
  ];

  for(const packageName of candidates){
    try{
      await IntentLauncher.startActivityAsync({
        action: ActivityAction.VIEW,
        data: u.toString(),
        packageName
      });
      toast(packageName.includes('iitcprime')
        ? 'IITC Prime ouvert avec le projet BannerLab.'
        : 'IITC Mobile ouvert avec le projet BannerLab.');
      return;
    }catch(e){
      console.warn(`IITC non ouvert via ${packageName}`,e);
    }
  }

  // Ultime secours : on ouvre IITC Mobile sans payload si Android refuse
  // l'intent ciblé, puis seulement le navigateur si IITC n'est pas installé.
  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitc_mobile'});
    toast('IITC Mobile ouvert. Le Companion utilisera son dernier état synchronisé.');
    return;
  }catch(e){
    console.warn('IITC Mobile absent',e);
  }

  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitcprime'});
    toast('IITC Prime ouvert. Le Companion utilisera son dernier état synchronisé.');
    return;
  }catch(e){
    console.warn('IITC Prime absent',e);
  }

  await AppLauncher.openUrl({url:u.toString()});
  toast('IITC non détecté : ouverture dans le navigateur.');
}
async function bridgeUserscriptText(){
  const r=await fetch('/redacted-bannerlab-iitc.user.js',{cache:'no-store'});if(!r.ok)throw new Error('Plugin IITC introuvable');return await r.text();
}
async function shareIitcBridge(){
  const name='redacted-bannerlab-iitc.user.js';
  try{
    const text=await bridgeUserscriptText();
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab · IITC Companion 0.5.0',text:'Plugin Companion 0.5.0. Dans IITC Mobile, remplace la version précédente. Si IITC refuse de l’écraser, supprime une fois l’ancien plugin puis installe ce fichier.',url:uri.uri,dialogTitle:'Installer / mettre à jour Companion 0.5.0'});
    }else downloadBlob(new Blob([text],{type:'text/javascript'}),name);
  }catch(e){console.error(e);toast('Impossible de partager le plugin IITC.')}
}
function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>Construis toute la bannière dans IITC, même si le nombre total de missions n’a pas été transmis.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>Installe le plugin une seule fois</strong><span>Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>Ouvre IITC depuis BannerLab</strong><span>BannerLab tente d’envoyer le projet. Si IITC ne transmet pas ces données, le Companion continue quand même et crée les missions suivantes tout seul.</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>Construis directement sur la carte</strong><span>Avec « Ajout direct » activé, touche simplement un portail. Tu peux retirer le dernier, changer de mission et voir le tracé sans revenir dans BannerLab.</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>Synchronise quand tu as fini</strong><span>Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>Si tu préfères contrôler chaque ajout, désactive « Ajout direct » : sélectionne le portail puis appuie sur + dans le mini panneau.</span></div>
    <div class="actions"><button class="secondary installplugin">Installer / mettre à jour</button><button class="primary launchiitc">Ouvrir IITC Companion</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}
function handleBridgeUrl(raw){
  try{
    const u=new URL(raw);if(u.protocol!=='redactedbannerlab:')return false;
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||'Portail',imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='sync'){
      const data=bridgeDecode(u.searchParams.get('data')||'');if(!data||![2,3,4].includes(data.v)||!Array.isArray(data.m))return false;
      ensurePlannerMissions();
      state.planner.portalsPerMission=clamp(parseInt(data.ppm)||state.planner.portalsPerMission,1,24);
      state.planner.autoAdvance=data.auto!==false;if(typeof data.carry==='boolean')state.planner.reuseLastPortal=data.carry;
      data.m.slice(0,state.planner.missions.length).forEach((portals,i)=>{if(Array.isArray(portals))state.planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean)});
      state.planner.currentMission=clamp(parseInt(data.c)||0,0,state.planner.missions.length-1);
      scheduleSave();saveProject();
      if(!data.pv)toast('Parcours synchronisé · ancien Companion détecté : installe la version 0.5.0.');
      else toast(`Parcours IITC synchronisé · Companion ${data.pv}.`);
      openRoutePlanner();return true;
    }
    return false;
  }catch(e){console.warn('bridge',e);toast('Synchronisation IITC illisible.');return false}
}
function openMissionSettings(){
  ensurePlannerMissions();
  const complete=state.planner.missions.filter(m=>m.portals.length>=state.planner.portalsPerMission).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')}</h2><p>${complete}/${state.planner.missions.length} ${tr('missionReady').toLowerCase()}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <details class="missiondefaults">
      <summary>${tr('settings')}</summary>
      <div class="missiondefaults-body">
        <div class="field"><label>${tr('commonDesc')}</label><textarea id="bannerDesc" rows="2">${escapeHtml(state.planner.description||'')}</textarea></div>
        <div class="field"><label>${tr('titleFormat')}</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><small>$T = nom · $N = numéro · $M = total · $0N = 01, 02…</small></div>
        <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>${tr('sequential')}</option><option value="0" ${!state.planner.sequential?'selected':''}>${tr('anyOrder')}</option></select></div>
        <div class="field"><label>${tr('location')}</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>${tr('visible')}</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>${tr('hidden')}</option></select></div></div>
        <div class="field"><label>${tr('portalsPerMission')}</label><input id="ppm" type="number" min="1" max="24" value="${state.planner.portalsPerMission}"></div>
      </div>
    </details>
    <div class="missionlist-v2">${state.planner.missions.map((x,i)=>{
      const ok=x.portals.length>=state.planner.portalsPerMission;
      return `<button class="missioncard-v2 ${ok?'ok':''}" data-mi="${i}">
        <span class="missioncard-num">${String(i+1).padStart(2,'0')}</span>
        <span class="missioncard-copy"><b>${escapeHtml(x.title||generatedMissionTitle(i))}</b><small>${x.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(x))}</small></span>
        <span class="missioncard-state">${ok?'✓':'!'}</span>
      </button>`;
    }).join('')}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('#bannerDesc',sh).oninput=e=>{state.planner.description=e.target.value;state.planner.missions.forEach(x=>{if(!x.descriptionCustom)x.description=e.target.value});scheduleSave()};
  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{state.planner.portalsPerMission=clamp(parseInt(e.target.value)||6,1,24);scheduleSave();openMissionSettings()};
  $$('.missioncard-v2',sh).forEach(btn=>btn.onclick=()=>openMissionDetail(+btn.dataset.mi));
}
function openMissionDetail(idx){
  ensurePlannerMissions();state.planner.currentMission=idx;const m=plannerMission(idx);
  const seq=missionSequential(m),hidden=missionHidden(m);
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${idx+1}</h2><p>${m.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(m))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionsetcard missiondetail-v2">
      <div class="field"><label>${tr('title')}</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>${tr('description')}</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="missionSeq"><option value="1" ${seq?'selected':''}>${tr('sequential')}</option><option value="0" ${!seq?'selected':''}>${tr('anyOrder')}</option></select></div>
      <div class="field"><label>${tr('location')}</label><select id="missionHidden" ${!seq?'disabled':''}><option value="0" ${!hidden?'selected':''}>${tr('visible')}</option><option value="1" ${hidden?'selected':''}>${tr('hidden')}</option></select></div></div>
      <div class="missiondetail-actions"><button class="secondary backmissions">‹ ${tr('missions')}</button><button class="primary openRoute">${icon('route')} ${tr('openRoute')}</button></div>
    </div>`);
  $('.close',sh).onclick=closeSheet;
  $('.backmissions',sh).onclick=openMissionSettings;
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('#missionSeq',sh).onchange=e=>{m.sequential=e.target.value==='1';if(!m.sequential)m.hiddenLocation=false;scheduleSave();openMissionDetail(idx)};
  $('#missionHidden',sh).onchange=e=>{m.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('.openRoute',sh).onclick=openRoutePlanner;
}
function validatePlanner(){
  ensurePlannerMissions();const need=state.planner.portalsPerMission,issues=[];
  state.planner.missions.forEach((m,i)=>{
    if(!m.title.trim())issues.push(`Mission ${i+1} : titre vide`);
    if(!m.description.trim())issues.push(`Mission ${i+1} : description vide`);
    if(m.portals.length<need)issues.push(`Mission ${i+1} : ${m.portals.length}/${need} portails`);
    const missing=m.portals.filter(p=>!p.guid).length;if(missing)issues.push(`Mission ${i+1} : ${missing} GUID manquant(s)`);
    const badPass=m.portals.filter(p=>p.objective?.type==='PASSPHRASE'&&(!p.objective?.passphrase_params?.question?.trim()||!p.objective?.passphrase_params?._single_passphrase?.trim())).length;
    if(badPass)issues.push(`Mission ${i+1} : ${badPass} passphrase(s) incomplète(s)`);
  });
  return issues;
}
function openPublishSheet(){
  ensurePlannerMissions();const issues=validatePlanner(),complete=state.planner.missions.filter(m=>m.portals.length>=state.planner.portalsPerMission).length,total=state.planner.missions.length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('publish')}</h2><p>${complete}/${total} · ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishscore ${issues.length?'warn':'ok'}"><b>${issues.length?`${issues.length} point(s) à vérifier`:'Projet BannerLab prêt'}</b><span>${issues.length?'Corrige les éléments avant publication.':tr('ownWorkflow')}</span></div>
    ${issues.length?`<div class="issuebox">${issues.slice(0,24).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}</div>`:''}
    <div class="actions"><button class="primary exportpack">${icon('download')} ${tr('publishPack')}</button></div>
    <div class="actions"><button class="secondary openmat">${icon('globe')} ${tr('openMat')}</button></div>
    <div class="bridgebox"><b>Redacted BannerLab Publisher</b><span>${tr('ownWorkflow')} Le prochain pont remplira le Mission Authoring Tool directement depuis ce format natif. La soumission finale restera volontairement faite dans l’outil officiel.</span></div>`);
  $('.close',sh).onclick=closeSheet;$('.exportpack',sh).onclick=exportBannerLabPack;$('.openmat',sh).onclick=openMissionAuthoring;
}
async function exportBannerLabPack(){
  ensurePlannerMissions();
  const zip=new JSZip(),imgFolder=zip.folder('missions');
  const manifest={
    format:'redacted-bannerlab',version:1,appVersion:APP_VERSION,name:state.name,
    language:APP_LANG,portalsPerMission:state.planner.portalsPerMission,
    missions:state.planner.missions.map((m,i)=>({
      number:i+1,title:m.title,description:m.description,sequential:missionSequential(m),hiddenLocation:missionHidden(m),
      image:`missions/${String(i+1).padStart(3,'0')}.jpg`,
      portals:(m.portals||[]).map(p=>({
        guid:p.guid,title:p.title,latitude:p.location.latitude,longitude:p.location.longitude,imageUrl:p.imageUrl||'',
        objective:{type:p.objective?.type||'HACK_PORTAL',question:p.objective?.passphrase_params?.question||'',answer:p.objective?.passphrase_params?._single_passphrase||''}
      }))
    }))
  };
  try{
    toast('Création du pack BannerLab…');
    for(let n=1;n<=manifest.missions.length;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      imgFolder.file(`${String(n).padStart(3,'0')}.jpg`,await canvasBlob(c,'image/jpeg',.94));
      if(n%4===0)await tick();
    }
    zip.file('missions.json',JSON.stringify(manifest,null,2));
    const name=`${safeName(state.name)}_BannerLab.zip`;
    if(Capacitor.isNativePlatform()){
      const b64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true});
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:b64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:`${manifest.missions.length} missions · ${state.name}`,url:uri.uri,dialogTitle:name});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
      downloadBlob(blob,name);
    }
    toast('Pack BannerLab créé');
  }catch(e){console.error(e);toast('Export impossible : '+(e?.message||e))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Redacted BannerLab</h2><p>Version ${APP_VERSION}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('language')}</label><select id="appLanguage"><option value="fr" ${APP_LANG==='fr'?'selected':''}>🇫🇷 ${tr('french')}</option><option value="en" ${APP_LANG==='en'?'selected':''}>🇬🇧 ${tr('english')}</option><option value="es" ${APP_LANG==='es'?'selected':''}>🇪🇸 ${tr('spanish')}</option></select></div>
    <div class="rulelist">
      <div class="rule"><span class="dot"></span><span><b>Prime</b> · 6 colonnes · 544 px · crop 512 px.</span></div>
      <div class="rule"><span class="dot"></span><span><b>Mission Planner</b> · actions portail, passphrases, reprise fin→début et pack BannerLab natif.</span></div>
      <div class="rule"><span class="dot"></span><span><b>IITC Companion 0.5</b> · parcours, actions, tracé et statistiques piétonnes.</span></div>
      <div class="rule warning"><span class="dot"></span><span>Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.</span></div>
    </div>
    <div class="actions"><button class="secondary" id="manageProjects">${icon('folder')} ${tr('projects')}</button><button class="primary" id="newProject">${icon('plus')} Nouveau projet</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#appLanguage',sh).onchange=e=>setAppLanguage(e.target.value);
  $('#manageProjects',sh).onclick=openProjectsSheet;
  $('#newProject',sh).onclick=createNewProject;
}

function freshEditor(name='Ma fresque'){
  state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0};state.texts=[];state.active='background';state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,reuseLastPortal:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  $('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name='Nouvelle fresque'){
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();await saveProject();closeSheet();toast('Nouveau projet créé avec Redacted');
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||'Sans nom')}</strong><span>${(d.rows||3)*6} missions${updated?' · '+escapeHtml(updated):''}</span></div>${current?'<span class="currentbadge">Ouvert</span>':''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>Ouvrir</button><button class="secondary renameproject">${icon('edit')} Renommer</button><button class="secondary duplicateproject">${icon('copy')} Copier</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||'<div class="small">Aucun projet enregistré.</div>';
  const sh=openSheet(`<div class="sheethead"><div><h2>Mes projets</h2><p>${projects.length} projet(s) enregistré(s) sur ce téléphone.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="projectlist">${cards}</div><div class="actions"><button class="primary" id="createProject">${icon('plus')} Nouveau projet</button></div>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}
async function switchProject(id){await saveProject();await loadProject(id);resetHistory();closeSheet();toast(`Projet ouvert : ${state.name}`)}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>Renommer le projet</h2><p>Un nom humainement reconnaissable, concept révolutionnaire.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>Nom du projet</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||'Ma fresque')}"></div><div class="actions"><button class="secondary cancel">Annuler</button><button class="primary save">Enregistrer</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||'Ma fresque';const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;$('#projectName').value=name}closeSheet();toast('Projet renommé')};
}
async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>Supprimer ce projet ?</h2><p>${escapeHtml(rec.data?.name||'Sans nom')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>La fresque et son image enregistrée localement seront supprimées.</span></div><div class="actions"><button class="secondary cancel">Annuler</button><button class="danger confirmdelete">${icon('trash')} Supprimer</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}
async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||'Fresque'} copie`;data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob});await txDone(tx2);await loadProject(newId);closeSheet();toast('Copie créée');
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast('Projet supprimé');
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation},texts:state.texts,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject(){try{const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current')}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();resetHistory();await saveProject();return}
    freshEditor();state.projectId=target;
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[]});
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

if(Capacitor.isNativePlatform()){
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url)}).catch?.(()=>{});
  App.getLaunchUrl().then(r=>{if(r?.url)handleBridgeUrl(r.url)}).catch(()=>{});
}
window.addEventListener('resize',render);
window.addEventListener('keydown',e=>{
  const k=(e.key||'').toLowerCase(),ctrl=e.ctrlKey||e.metaKey;if(!ctrl)return;
  const target=e.target,tag=(target?.tagName||'').toUpperCase();
  const editing=['INPUT','TEXTAREA','SELECT'].includes(tag)||target?.isContentEditable;
  if(editing)return; // laisse l'annulation native fonctionner dans les champs texte
  if(k==='z'&&!e.shiftKey){e.preventDefault();undoAction();return}
  if(k==='y'||(k==='z'&&e.shiftKey)){e.preventDefault();redoAction();return}
});
if('serviceWorker' in navigator&&!Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();migrateLegacyStorage().then(()=>loadProject());
