// ==UserScript==
// @name         Redacted BannerLab IITC Companion
// @id           redacted-bannerlab-bridge
// @category     Mission
// @version      0.5.0
// @description  Companion BannerLab : parcours, missions, tracé, stats piétonnes Valhalla/OSM et synchronisation Android.
// @match        https://intel.ingress.com/*
// @grant        none
// ==/UserScript==
(function(){
  function wrapper(){
    if(typeof window.plugin!=='function') window.plugin=function(){};
    const KEY='redactedBannerLabCompanionV3';const OLD_KEY='redactedBannerLabCompanionV2';
    const STATS_KEY='redactedBannerLabStatsV1';
    const VALHALLA='https://valhalla1.openstreetmap.de/route';
    const MAX_ROUTE_POINTS=45;
    const ICON='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAABMWlDQ1BJQ0MgUHJvZmlsZQAAeJx9kD9Lw0AYxn+Wgv8H0dEhYxelKqiDLlUMOkmsYHVK07QV2hqSlFJw8wv4IQRnR0Ho6uAgCK76EcTBtT5JkGSJ7/He/e65h7t7XyhMoSiWodsLfcusGGe1c2PykwmNOGwn8MgPuX7eE+/byj++vJhuuIGj9UvZ8PW4rqyKl1oJtyOuJ3wd8SD0QvFtxH7V2hPfiUutDNcz7Hh+5H8R73Q7fSf9N3Nu7/RE64FymX0uCfDoYDPE4JgNzaZ2XfqE4oEcIW1RgKWTiqiKL0dPShNXTNS/5ImbD9gdjcfjp1Q7GsHDFsw8plppGxZm4TmjpT31bN+OpaKy0GzC9z3M12DxVfdc/DUypzYjrs3kSqOl2lwph/qvw6ponTJrbP4CGDVN6D4vo30AADTOSURBVHjaRbxJjGxZet/3O/ecO9+YM3LON9XQNXR1dVV1s5ukJFIkNRiyAMm2ZBqwIYGGN4Y3XnvTW2+9MeCFlloINgzLG2s0KJLi5Fazu9k1vjlfvhxijrjzPYMX8UgtEpHIRCzixne+7z99R/wnf/szN181+JOP+OjgjHdty+dNxeDeR7T5l9zOfsZ2uyP0feomJEynTMaHHAjJw/4hzra82l4y2804vTigtSUvX92yXldMx+dUnaC0gtHRW/ie5q0HF4wmx7zaxajxByg/pmtzqs0ton8K8RjnHM45YP8qAGctbx36PDpQdLrD9ywCi+dZmqajrhsQ4AmBcw5rHZ12dBZAIKWPkhInBBbFtvWptaDWgrJzWASdtgQSHh0oToY+eW2RSqofxb0T2k6T5Cve8lNCbXgvyqjyV9zkl3Rakxfgi4iR8pB1Qds2COkw9RpDQd6VCGWpTMur6w2dETz84AeEowcIP+LD976FEjWP//w/ELiYxh8iygVi/g3V6iXF5jV+OkYlIxyAEAhACIEQAicETefYVoa8tpSNpenAlwJnDdYYnHMYazHGoLWh7TRtpzHG4KxDKkk/CcgiRRx4jFJFawTbxoFzHPYVbx8FXEx8sliyLgyqqiripuXw4dukZUHgBLrcYhczTr0B1/GUqi9Yr1vWd3Penkw5CPr84uZLNtUlSRQilMVTjq9f3LDcNCgv5PzRxxy+9zcYHV7Q83YMAs3nP8/ZHT7Cqh7r1z/DFHfEThANRhxOLyBOaPCQwuEAJwSeEOyfmKOzjkVpCX0PiUB6UGhHqhTKWYQzWKsxBjrroe2+kpyzODSy6yhqSaEhDEKORoqx0eQ1jHoB33u7xzCVWAuh8hj2Y1SvN0DYgt38a6rBIZ93c+Zyw4u7OaEBN8oIwpjAu+Hg8Jzd4IJXV49Z5SvGyZTSWby2IUkijPU4Co45HR3xfL3mdrbg5OQCUVxzeT2nsT7R5B7z3Yqrp3+I7mr6fsqDXsTF6QHqOOPJTtNogScF0lP4zRbR1eh0gudJHB4Wi3WgrWBZGkop8WVE5Bpk29KoAI2PdoCwOOEASdl6uNbDCcFZ7BEpwTTzSIOAk4OE80mI1o6q1QgBg1SiBof3qcs1YdjnOs953VQo4GAgydsKN2s48s4JVMr4W38TsmPU+ob300/Y+JK1yNnMXnK3mhMEEfcuHlBsc7rdDcsv/jnPumeYcsa8qFDZEcVmi85v0G3FarMjVyX2Vcgv/frf5t6DIb0N3G4cr7cOz2m6659i6pzRw++TKp8Gj0YGdCokpCWq1mAc2vMo0VgnqZMeVuwrYV+L4AGRhFDCYV9y78An8gWB8hilHqEybPMKa6FuDTvn8JVEhXGfqtxSFSW6bSi2C7CGKDnAD0Ou6orZ7Q2jkynTOMFWLzgb9fludM4X1Y6r5edoIyh3hsF4TCt9brsF04MJtHf8+Z/8nwhAqTGnxzHlbs5qdUmrG8LAZzAYcXx4Thb3ULrlvOcTuYbNqqRcXJK/+kNM23EWRKTpgLprcUFCmo5ITEu+eIntWrSuUWffRo/uYfAQbv9g2Ld4RongYqzIQkmoLIE0gEUJkB6YzpBrAc7hHDgnqDuNioXg0bu/zE/+7N9wtbhmOj3lKMnQueHV9o7p+ccsF1dkWrB++VNMc01lDGFlKP2EpqgoG81gMGIYJlw/e0orc5Jpj7yq2VQVQRjQa1vS1RaH5XXX4UuF1g1xmqKU4o9+9//h/OQhQdZjtV4yu76hym9pd3OEc6xehixUwqzNgY6T7Ajf77E0JXVX43k+4yAGP8CzGpwHOKxzJL7gwYHi4WEIQFF1GGOQnkeWBPi+ous0TWcomw6tNVIqhJCoX56c8q2Dd5g8XPO/7/4VMZpfOn5EIBX/pv4pdy9/znq3JY1TytUNyiv5+PA+s2LGT29fsMpzrHDQs8y9Bcs8pzYl1rMoJdnsKuIGkoHmprmjbBuM6dDWIhB0bctseUOxmXN39QVCCHbFlqosiMOIIIyR0me1vsSqDOdLis1zbosF3lu/QjR6H19FBP0jVP8YJxwWDyEcke8w1jGIBUd9RRZJ2s4iU5/QD3Fvmr+xhqbrKKuGsu6oGw2AlB7q55c/Y7W8YrbZ8u70jPcOz5n4Kdo47mcDQn/OLtfcXT8lDSWBstzFd3jCZ1UXbOuCYZZQd447U9NhcCrgZrbl4vyck5Mx+XyFJwXXzYxdXjFJUqwA60ccDA8R1rJez1iu54BDeIJh1iMJYrrWsO4qNi4nDhPSNEJ3DW4QEZ++jZ+MMOEILx6C8LDWkIYwCB2Zb/EAX4G1hvmmIlQe/SzAV5KialisC4qypu0M2jiMsbRvYII1BjVO+9x5G7Rq+MHBQ47SEZ0VPFlc0QnNex99i49/0Off/d6/Z7lY0ctiXu1m+CogixIGwQAPS2kMCEdnNIPBkF52zvnZCaF0vDY1uzyncZbzi0cMZESlayZnD8AYbq9ekhclbWvJyxrheyg/wGqLri2dtRhnac2KUS9jOjri/OhbiHJDIgMYnFF7AosgkIL7B5LDxFHVBhC0xvFq2WKt42Qg6bRGG0tZNRR1izGWumnRWmOsxRpHpw1ad6iBTrC+xR/GVJXh+XJGbTo60TI6nhDEIVmi+Pb7j/jTn3xJ0xmqxqCURxKEZC4BKzmNfGpb8rTOCehQtqTNb6h0gx+GeH5Ez49Jh0fMF3c403A/jEn9kKdff85qsybwfRCCoqiZO0fgK7rWcDI85rA3YFmssdZwEB/wMDvj5e0lrtjimhLdPyKZ3CPxHT3R4jnQzf6162DRBgjPoxdqqsZSdw5nDaGvCHxB22qMsVhn0cZirUXgIV2if/T1zSWz3YrWGW7yJVflnLPhlIKK2+0dSinGowlt17Le5aw3OY22FHXFutzSuRYhBQZD2g9569EpWhfsthua1hJlB7z13qdo63j89c9Yzq8RTrPbzNnmc5o2Z1eUWCfwJCglOJ2ccjQ5wRce0/4RB/0D7g0mDCOf+W7NercjbzZ0XU1brQnxSGyLzG/pdhvqpmVzc8Xm5oa2k+RejBOghMWX4BB40iPwJR7Q6j32CfyAKIrI0oQsTVAvNzPAMd+uma93JFmfo3TCclewrNbIvk9edlzdXHJ7t6KXpHRtR13XBL7Cw0PLhmi4nwpFayjLHGscu7JjNJ7gqwAfRWxjEhEwODgEa3l9+xoVvhnEwuIJxWFvjDOaadZHyAiiPlEUY2iIgwjtAspuhS5ekalTQgJ6OiG+u6FZ3NFkA3QUYp9XbKsVZnzM5HDAIPOx1hCFPpO+pGoNi8KxKQRSGKTz8KREeh5KSpRS+yo6Px04IQXWOsqyZTwaM+0PuZdO8YcZs3qGH3jMFmseP74kTUIGvRRjzR6ACYkfSN46PmTa73G1nVOUHbqxHKQ9BsMBDTAcT/jeb5xTFR3//l8+Yzmfo5whDQOscwziMRWOfpCgu5ZFsaRuNKEM6Q/6aFHiS2jaDl0bfBmxqCrieMx704f0lIdTMX46xgmBOjjk6P33mJweMRpmDBOPrnOEviCQ0GjLtoabraWoNZFo8GyDNgZrLbo11G2LcgJMtx/JOMtuu2UQZyyVwOxKbm9mFOUaqRRhqPCVIg1TOr3HC03XUTQNX+kbutOOqtVsNhVJHJMkMc42zBYbjj8UvPtbQ8LmgKY+4V/8HzccTcd4jaVsW9KsxzDoMdUBJtK8Wt0yz9ckYYj2G+quwVjLwegYrTpWuzWeDGi6knU1p/QN803OID7g/N3vMXz0PsloyDC0TEKNLyW26zAdNNYDBJkPF0OoOoU2HlYr2ralbjpwHqEA1TSaOA4RzjEaZrS1oZ8OSFXM7fyatq0Jw4BeGuNXirJuuFutOZlMGA1j5vkGxB4zVF1LECikUog2pGkdIoC60jgcu2XB1WzOd379Abb9mD/6f/8cJT2KtmVx84JJMkCoPlfbBcvNDq0tq25H2dTgIIlipAhBSQJRoGSIAS4Xr+n3ErwgREYBsWngyS94+nXBM9XxzocfMTi9R607uroE1xFGGZ5KkRJ83ydQAQTqDeF1pElI4Euk8MyPHA4caG3AQS/JGKQZVV2xzFdMRiMmvSHrfIdxUFY1SiqQjkZrotAHHE3XMooyPpm8x3f7b1PtWpZ6SzL2GI57hCPLptlQVwV+Jqg3ktcv1jgjkNbQCz2MMHx5c0ndNkjhYXE4J6i6DmMtTZUTCEcsQ4qypGkrQk/hOYFyAmcaYjTF6jV3r56SVwXje++g4gHL1Zxf/Pz3+bOf/AF50eL5GZ0R5GVLpzs84ei0peksoS/Jkgh1fnBI3lRs8pLQV/SSBKTlbvOavCkIA4lw0Gq7F6PsHlssdhs2VU6gFNuiwGGJYp+/dvGAvz76hKVeEXxU88lHQw5OIvAcdVORRgF//OMvmd8VXNx7l95lRqwUwvpsNwV325fIMOAgzijKAiEVaZSw2q7QRrMpCyLp0c8OKDzohz3eP/uAMEixwuFEw7R3yNPbS26KBX/tV3+V4/MLrID14oqf/dkfUpUFeb7FDwMu7n8H7TzqVlPVHcLz0MaCs3gC5H/7vb/1o4PhkLt6jfA8jDFY19KLe4yzIU5orHVs8g3KV3upQewJHQ4624IQhKFP4oVI6XH8aUz4W1se/npMbwidrghDsLrEFyFZ2icMAzZ5wTvfvc8nvz7m/kcZxlc8/6bEF4o4Dmm6hq5r8YVHGvoEStEPY85GB4yzIWnsczo6puk0vh+xyJesijmegrxp8fyQ45Mp0leUdclXX/0JV5dP95/D7HC2wVoIwhSpIlpt6PReXOs6Q1Vr5NvT6Y8qaeg8S1k3COFIoph3z99Feh6v5q/Y1TnbqqRpO4ZZRhqH5FVJlkTcnxyhfIHnBO+8e8yv/MMThp+1BKlDGYFu9tOuKiuKoiXrhaSRz6if8e47Z0wmAUIY4h58+Okx9x5MaO408+stKIfHfsJKCaNswLuHDxilfVZlwdHgiFEy5eXiFda0zHd33O1uWZZz1sUa08Bqdo0RhsY2XL78Gdv1HZttCQjiMOTo9G2mR/eJooRAeUSBTxr7GAtFo5Enp4MflV1D3XYUZUkUBWhtKaqa096Qpmt4Z3zOD86+xfVujRWW4SDhcDLib337B/zDt/86ta45+37Cf/qP3+LiYY9EJXhA07YYo5FCAh69fooQHk2jCUNF5Eu2yw1PvrliMBgSRxI/zXnn42PaTvDsq1uatsNhsdbxRnSmbBsiP2OU9rjbLvlm9hiJprMdt9sVrTas8w3gcdQ/oq23fPHNn7Jc3FE3Busiev0x211Of3jB+PCcIIhRShJFPlkSoKSHQyDH4+xH1+s5nekwzgIWHBRNzd12iY/PZ+N3eJQdse4K5t2WKPb5jYef8Un2Nl6/Y/qblo9/44AsCXHWYkxD07Y4BEYbnLM0dYX0BG3b0XYt1jiqqiHLUobjAXHskEIzu8vZ7DZ88OkJo4M+z75ckkYhnTYYa+locEqzqysu5ze8WLxiU65JwoBBcsCq2iI8R6hCAumjvAjpfGgMm7xgW5Z0ukJ6muvXN7y6fEWWJQwGQ3w/QGBp6hrlWXqxQiaZ+JE2jnWeIwPF2emU/iBCKsEurxmrHtiOu+2a8XhEehhRbWvOggHTT0H++orhPQ+hBWVdsZzP0MYiPIVzFpyh6VqapsPzJEVeo5Sk0waLxZgKYzq6tqMsO/70D59RFrBdN7z/8THn9w746R9f0umORMUEviJLQ+brJfPNjkGa8fDwnPvjtxgmU+62c2bbJRKJLwVlXdI0mklvjKcM1isII0nT1qxWFYfTE959dI5Hha53SFPRlmucLrFtjnz30dGPiqpFCp9R3CcNEsZHAy4m53wy+Bad7vhm+xrrgfVhXmzI+oqP/4sh0x8K4kBR5yWN3rPhujZ4gCcFRrc457Fa5GS9BG0sUnmoQNA2NcZq2kpTlYZXLzbMbkrG0zH9UYrpYLnIufdwRJJGPP9qQaAUnTFo29JLInwZM8lGnAxOyMIBq3LN5eKSttN02tKZDiFgW+X4KmAymHByeEgQB1RdSVt3aLuXVvP1LYu7l5g2R7mO3fqO66unyDjxfyQ8wenwkLPeFFF59EzG33n0S3x3/IhVnfOHV59zWy55dn3N/Q8G/PZ//z733u4Tipi2a1G+pOs6nGXfc6REeB6B7+GcwDqPJPVpm466rijzGtNZukbj+wHLWc1209LrZ1zcH7FZ7UhTnzxvefL4lh/+2iN07fj6qxtqU1O3LZ7w9iJXo7ldz3l695zbzR1t2xEHCb2ojzZuTz6DiEDF3D98xHH/nE1esGuXZJnP7G7JN4+f0nUtbVtT1xW3d9c8ffwLbi8fI2XAj456Y0LpY7Bo3ZF5Eaeqx83ihl1T8jy/Zlnk/PA3z/lH/8OnTA5irLYYOqwzOGspywpnzBsfS+IHiqap8JXCGItUgsVsS77rCPwQP1A451gvKxbzmuFBQhT7lEXD7HbLZlVyc71lvqhYrXPe++iYq2c7dpsaX0l2dUXdaIwzrIsNrWkQQqC8AIRDSUGtG1rdEvsJZV3hrCNRKZt6y836huUqZ7utCHyfNEno9/qMR31mt69ZXb8mEg714ekjfCTDMENqj51Xsm63/PH1V/gOStcgBDy4d8hv/853SVNJnheoQFJtC6yzJEmGNgbpOToNVmvqqqJrNYu2REhJvoPlvCaMY4I4YH67ocg7rIYwDLi53GHclunhkNeXObtdR5QE7LYNT79ZIpzHB5+dU+YdpnEgPLSwe/btKVrd0pkdgQzwlUDIEOsMre5oTUPm93lxe8m8mGPDlsV6x2ZdEviSo8MEY0pubm5RoqMudsS+xEmDPJ2MfnS1mrHIt4S+QnuaVbNl21W0nuW2W7HalvyNv/8tvverp+T5llY3GF2zXu1wbl8ts9sFZd7SaUuaZXz15TVJL2Ozrsl6PaqyI4gCRuOU9WqHkJKjozHFruP19Zbb65JeL2W7rnjxbIV10LaWpjYEgU9ZtkSZjy8CduuKwWBPhbZ5Sac1XVfTGY3nCTyh8FBoY2m7DmcN/XiIQ/J88YKob5hOUsbjhOPjHkoJtBZk6RjPUwhrGI8mZJMx6s+vnu698DeN9Ww4pjINh8lkP1Zrx2/93ff4O//wXVbLBcZ2KKmoypKs18c6qKuKqtDESUh/mHL5ckaSJkyPMuqqZTxNiCKJsRpPOqyxJIlicTdHGzg/n3B0KKjbjlfPd6hAYq2l0w4/UFhnaVvDbL4h7accTPq0Xbf/0fVev/E9rAVrHW2rwUo8qeglPTzfkrdbxskJUZVQN5rhsE8UO5R0vHy5xrqEB99+xOHBlEjBeDTBOYuapH2iIMBTkrNsRCYjIhWSxBHLbc7J+z3+3u+8jdYFm82WrBdRVQ1t40j7jmrX4L2xitMsxDlNkXecXwxZrTbkecF6uWS7qRj0M6rK4nmSy+crDo5HjCLINx2bTUWedwCkacRqUewpgbV0bYdVFk95EFmmhwOePL6k6VrSOKKf9rE4Wt3QtB0SgcXg4dHr94hiCTpChYaekwwmfR5cvM+r169ZrOZkw2x/ZN0K7UK0iQjDkMPpAerD8wfUbcOi3XFTLYijkEZ1/MnlF4wOevw3v/NXKKstTW3A24PIsqyJopC2aREeVFWHHwZYHOvZCuVLnLBI4ZFkAbPbNVL65EVJVbRIGVBVmsCHP/r9F0ymfdrOsVlVXF9uOTkbItWeF5oOPM9DOUsU+jRdhRABbdPhSYiC8E0TrrEGtNZ4SqLU3tJRQmK1oBcmHEwHKEp644jxJGa2UshGMRhFKOVRmQWXdytcl1Aaj9qBWpuC2XbFtq7wlcT4exYqpOM3//5DpieCq1cbuq4hywL8yCe1MU1dEkUhu+2O/rBHGBnapgV8duuKtq44POnRNYa71znDccZ6UdM0hrotyTcNv/dvn5L1Y7briqo0dK3j0bempKmPChR3NxuElCgp8JXHdlPgeY40cpwcHuz1nU7TtNV+SjmHMIowCpn0h9RN95dfrGBL4hROgaZjUV0yPILh8cFezxICKdUb26lHkIUsdxvUts5pjeHi6JSq2jPp5WbDZ3/1Pr/6W6fc3szxA0XXNWjjKIqc1V1DXuSMpz086RNEitVii0BRN5qT8wGPv7xjcuRR5i1F4dHWFSrw8KTPYBjwzS92VGXL0YnH46+WHJ312a4aHJrF3OEJhbMC4RxOWrrWIaUHAkSoSZKIOEhYF3f4StIfhbSdRm86tO2wWE4e9pGRBCkQ1iOaGOIgQCoPK1pkIJCet4cm3t6CFkhas2O9+gW2sKgsjglEwLQ/YiEMVad558MT/s4/eJfNZk2nG5q6Ik5TgjDEGANyb+UcHo/YrkqefXXF5dMdRWFIeiHn91sOjhNG4xRnHFcvd3Stz/3TAfm24uuf37FeFrz13hSsw8OjzDscsF7VZFnIbldhrSCO/L2s0ml6g5i6aslVxWze0FlNmiTsioq8LPHk3jYy2lE2NRfjAePTBDyB0RaEA7w98X0zmIyzOLf/l8UipY/wLC0btDN442zAeJTx/PYli92WWtf84DdOGB45ZndrhJBUdYtz0HUdcRwCjjgWXF+uaBrL3W1LnA0wLkGbkKePd1R1w3ZT8PLpHYt5yXJR4XBsNxVXVwWToxQhHHfXOWWh6WqLs/vAVFu16EYThB5124EFqy3FrsYaQ6dbVApWGiyGKA04v38BDoJA4YRDSEkY9ojCMUZbjNtb3sZorN37XwiH2AsECCzWdGhTo02L8xx+z0c1m5badax2Ozpj+c6nD/jg4wl3t3cMBhnKdwg84iQiCODu9R1Pv55zfu8QpRzbdc5mbTiYBnz03QOMrVitBFkv4+42Z7ezDEYZ62XDelkSJzFZL6I/iFmvaoxzHJ6lGG0Jwv1It05gHVRFixMSJQ0OUNLDdAZPWMaHA5pakvT6nJ2c8t573+bf/dt/x263I02HjA8OeOfhZ4RxwNP8J2gDnpQYbWjaFt9X2I49bpICayVaG4wzb5JtICWottMgPZz1mBxk/NbffYuo1/HV4xsmkzEyUIwPenRtzde/uMFaj/c+esTV5YrxIMBZyfK25p//0z9lNErAwflbfT75geDt9w958WTN1fM1KoiYTPtURc3xSUYQSe6ud4SxR1cbdOfwfUe5M6AknhIo5SGlJO2FmM7sj4mDum6ZDBRHB/cIopTIl1xdLpge3efkVGIR3Lt3wSff/oyqrunFMWEokVKyWK65vr3l/vkp0vP29pUA4e3zRNbt5Rm3L2dUeBwRxSkfHsZ8/zdGvPORJN+1JEmMtZa21lR5w2yWc3A45cGjQ26vVxwdjQiCAOFpFjc1//i//h9xCP7JP/lf6dqCX/tb7/Dq5R2zu4Kj8zH9YcTrV3OaqgNP8PzJmt2uo+d8qnKfL5zd1CSJwjpHGHsIPHbrlsVdzvQw+4+9w4Y4ofn0009Yrmpu727QRcPDR2+TpQkvL18RRSFJlqICn7qLCUKBkj5Nqzkn4uNvfUgY7KEJvIn5CUB4OBzOOhwO9e5b9/j6+Uve/zTjO9/P6LqGstpxcDTEGkuxrXBCcXZ+TJwofv5nXxGFGXES0LSWqjTMrzvuHszYbCo6G/FLv3bCaGL4D39SYLTi4Chms2q4eZXTH4U0VUechiRZxKtnW5wT+JHHcJrS1Zqq1FA5RpOYrnUgJDJQ5MuC/jDGGMdidUd1uuXk5CFxmnBzfYsQewsnS1N8pfgL4fzHP/8Jl9ePaWtIVcZb994hv3+OjfZ2tBBiH1p4E7oybo/IHaBuFit2zYqzd2L8yNC1Fuc0dbXHGGEUM+ln6E7z6sUNSqdM3QO6/grhO7782Rw/VPzrf/HPaTvL4XHEo2+NwUk++u45o/EG6UdkaUwUSZ4+XnFzlZOlAYenPY7OMtarhjgWSOkwat9/4sTHVx5xLNmsO9aLkije/00bh+/7lPWWh/f6vP32BT/92edsNju0Njx8eJ/RqIezDk9I1jPD1ZOWh2fHfPzOI0ajCV1T0XkOpRQIgduf3jcR5H3CzOFQ882c3/x7x4yOPKqqZLXagpNsNzmDccbd7QwZKFbzLZt1x9tvD5mOFdcbzdNv7nj+fMHJg4j1rOX97x3xn//OB4RBSRAmDAYZ/UGPxXJHU+WchWOaWvLWw1Mclqwf8uSbGWWxZX7bMZqEeFIRpz7WaHTn2Kw0V5dbzu/3GE8S8rzDmIZgmnI9f8633/urnBwdUbxV8c2T53TaMB4NiaKAtq1xODabiizO+OVPv8PF+THWOrQx5GW1T5J5Yp8tcmCdw9i/aNIS9d0fHnJ40uC02qeqlMdqtkOqAKMdVeFo647VoiDJMharHZevr7h8suTZk4JPfvAeFw+mfPjJhm9/fMb4ELQOiKMIYwynp2OODsdIz+BJn48/M/T6iq7WhJHPz34y5l/rJ1w8GPKzn14xvymw2nJwlJIXmvldCU5QlobloiTthwgBu12F580py71DcXx8xNXrO/KiYDhImS/WVPmW0SDBcx2+knzz4oonlzc4BA6FNg6LQ/kK6cn/aF9FEUkckkQBajAxhFFIkvhsdxs8T6JNS5JlrG4r6hqefnPDcq45OUswXc0XP1/jhxGf/vCCT75/gdYdj956SBQ4ttsd1gkWswUH0wPSJARb0zYNu6JlOBjQVpauMdy8XtI0O/6z//I97j0c8skPTikLQ+A5BoOI6+sd/9vVj3n2eEfS+owOUpxz5FUHDvq9lLrRWOfI0hRPKtabHavVis1qxdMnj5kME7IIIhmzWC73KTLrUdSaqjU4t9ejhPDwfcVkNGB6MMTzPOqmQSkp6bqGujZEccxuvSUMUnabjtWqpCod09M+VblCdyFVteODjx/y7genSA+yJCEIFEJYimKH1aD8gMPjI8JAspjPKPJ2DxkA00EofZ48e81209G0HnU5Z3o0YjIKMOaao6Me8+trxgcZv/073+N/+Z//DaM3hLLIK/zAw8PSdRptOnTXksQRYSCZL5Z89fkv8KXl1auXfPHlDpyg0Za61UjpE0UpCA/j9oBSGQ/PkwjkXpmwljD09zHgg8OAzqxADNhtdmyWmsPjKT//8QvSXkYYw2gU89bbMXXTce/hmEdv32M0yGjqjq5twFnquiNLMoRXoPyAsthyd7OhKjQH0wllWaO1wZMxs/mKVy9WfPjx2yjfp9iafVV1sFlZrl9dc/1qx/SoJUkT/qvf+ZTXr5aURY0zliD2aRpL3TZ0usFpjScso35C11S8vtlydtBn3Itoq4Kq1bRtS9MYoshHKUkYhjStxji3zyRgAMdmkyMEexmln6KsKOhlB7RtB3gEQcJmXiB9SdZPkEqhdce9R0MCFZBkGb6UtE1NHEeEsWKzWgH7kgzCgM1qy9dfPOPg8JgoCVivV0jlE6mYstpQNZYHD8/pZRHL9Y4g9PdB7xiawlGXivF4TBr1ePb4lgcPJ3z/B5/xz/7pH9M0NTKQ+L5E647Vas2zFy+4ODtiNEyZL27506fPGfazfYXpDucsnpQM+gOyLMMYQ13XOMS+8sKIvGowxrAtCuarDY+fXeH7Psr3YvatqiPf1qxXGil8JtM+g1GMEA1ZekAv6+Mpx/RggG4NQeiz2iwIwpjlak1VtYxGQ0IdsNuWJGmP7W6HwHB4MsETliCQdLWmaxr6wxFNY9huKupqQ1nWGN2Aldy/N+Lq5YLtuubqcgd4jCdDLu4dUO5qqrIjyRRxFLNcLvn93/1XfPitB5yennP/aIiupvuNICXwVYQnBEEYkg0GCOGz25V73cjz6FqNY/9w9ha3QymJ5wmCwEd9/Nbf5CdP/i+qtmKzqHn2uOSjTy+YHg3QnWE8POTi4oiiqsD5NKVGOI9VtSQvK7rVhqbR1GWLN3bcvJ6B80jSiOvXc84fHJOkPjevFhyfhWyWO16/2HDxUFHmHVVpuP9gys3rNWEYcjBNuHyxoqkNB9OE8bjPYJCiW00vC0j7CYvZDqsN1gq0dthWM7+7o8xzDocpnB9gjEHgqNqO5bYET5Ile0VCKYV7I/yVdYNrGhACa/fiXJqm+9UpC+qo94CD3glPr7+mqjRdA+vljgcPDukf9tjlOc+fXxKnMZPRhPVyg5KS2jQYo8nziteXC5S/H5ueVGxXJVk/ZDwe0ssUVy9es9toAl/y8tmC7dowmjTc3aw4Pp+w25W8eLHk7GxCsyx58WLF9DAh60XEseTRowG9LMA5QRzHJEn1JstUc3n5hN2q5Oun+9UoATRNi5KCMAwIwxBtBdtdhfDW9HoZre7wfR/P8/A8D20tkVJ4UlK+2T2TngQEKgmOSZMxN9czfL/Pp798CFbStIaqrJH4iNCn18soii27co33pgS3m5zlYkPWG6ICi7UGnGW7LoiTkLQXsrhdoPyQIAjwVUrWb3j2zQ3jg5woDYhjn+urDUka07Qdm3XDyUnGYNAjzxt++CvvsFnOuXu9Jc9bJgcpTVPQtQbrHC9fvNon2YTAA5TycG4/4cAx6PUYjYakSUxZ1ZRVg+9L0jSl7fQ+YGEdbbM/cn7okybh3oyoO1SSnPBo8hmu/peEWcDR0YAg8hkNxsxnd0gv4HgyZbte0HYdQRhw+eKWri3xlE9daU7OfJTvsVrMmN1sibMJdaPRXY2zhnc+uODV8xlNVxOGjk9/+SFN1SCFwxhNr+8jMBR5S1V1fPLZ+V6g9xxPvrqmyEuqqmU5b/krv/kWxychf/QHj0mSjDT1cLZm0E/BOvKqRhvwfclw0KPf6yGEQngKpSRxtIcLwvOo6oaqbhgM+iRRhHOOwaBHL03Z5gVt26HKrqOXvMN/9w/+J37/z/5vqmpLGMZEoSLLYqaHR3R1Q13WNG/8pyhKKYqa2A8YT1KKomDQ79HUju1O0x/6CBxhHBCGPXa7HZ2usdpS5hVNXaG1h9EebetQAcxua/wgwto9AVaB4eXza4T0ub0rGPYT2rak2DQ8+2aOQNBL+nz3O+csZltGvZi6qri6XdBpw/HhhOnBlCTNmK9z5osN49GANImYLTegIQxDpFejPI/RoE8QSJI4pmk6emnC8eEEJbAUjWLUe4/P3t/y5c3vYYDVaouvQoqi3HOlxRzrQuq6o65qjk9PiGKP2d2C1XKL7jqkDLh4MKWtaqYnQ5JY0LYV87sdbQOLu5y28nj2zYokS7n3YLrPIltJUbQc9QY8+XrG6VmfXj/ipz+5YTLt8Rt/+wN+/O9fsts0XL8qKfKGRxfv0w/usXYbhmlIFEjQinE/xfMUZ6cnqCBhV9ZobTHGssurfcB8U6KdQykfTyo2eYWQa3wlgQ0IwfnJIQeTMWqzeA34vFg8peA1ddeyWGyI4oCT4xM8LEZbDo9PWMy3tI2maxuUcjjbEUYxcWRRKmaz3rHb5ATK5+R8hJSC7SpndrPi3qMLrl4UXL8sOD49BOEYjFLKXcd6UzA+6PH461s225bZrCCIY9arhu//8AzrNkgpmUz7lFXLO2/fI/PfZzsr2CyWFGWBkpKmM3uJ1lO0r27xVIDWbo+SBdze3gECoXySLCMKQvq9lE5rAhUQxyFSSqyD9a6ienaFEtbhPImUHbt8jjaGwWCAtQ03d9ccHUypin1UJY5C6qoiTfuUhWU4lgS+YzBMGU16pGnAMooIAonVLYvbai9ldj6L2x3LeYXuJFXZkmQ+P//JK3QniGLJcBRzem9E0xr6/YjLpwvO7/cYHYS8fLplt22xzrBc7JiO3iLqjfni7iVXs7056SvvTeylYzo5QHqKIAiIQ5+201hjiOOINE33eg977jXo91BSUpQNnvCYjAakScpivaPpOpTpWqLBCNUFWKnfjNEInKYoCqLIo6wq1qsVXSd48WTLaDIh6Rnubgo63bJZFuB1OGPoDxRGC26u1+SbCiEE89mO29ct/cGAl0+uWS5q6kpzfDZgMu3TNQ3zuw2nDyb8yq/d5/Hnd3z5ixmnFwlV2XF3U/Py2Y4wCUhixXh4Sl60PLu8Q3cC4SfUuqGsNHHkMxyOmE4n7PKa5WZH2zRYp8nSlDRNKesObaHVhqJsCcOQsu4oy4rZakeSxnstyVMoKX2Es6zza15dvSKMfJq2wLT7c3tzfUec9InShJunc5Iso2t9PCHwfVjMSoIwZLMs0J1G+VDmjg8+esg321ckaUYYdJy/e8RuXYHzcM7jO5+ds91UNHVDmiYY6+Mr2Kw2JJlCScXVyx1lYWgbgQx96towHiWsdtd8+fmSuq5Qb3wt5zwePTjnu99+F6V8tnnFbb2mqgrqqiIMfaT0WCw3FLUmCEM8z6MoGrrO4HlibxnVjqbTeH+Bg4Tn8JAk0RCHwTqPyA9wStDWHnXtKKsN08MeQlxxfHbEw/vvsljf0bQ74lS9wR4G6RS+CgiiiuVyjrH7I3Xv4b4fffWLaybTlLZxlEVHvx/xe//2BSD47vemzG5XnJwN+fGf3LFZVrz34RFNbdCmYTiMwXoUec3l1WPqOqTMK6QET3hIJfjwnTN+9bMPabXl6YvX7PKcUEFR+nveGCZs8xVpEhFFIXXbMRqkb45VzGaXs1zvKKuWumkJowAVRgOqbs43V79LGCl8JZnPlkjPYzbLSbMM6wxRHAI+q9WOd99b07cgq4TVYkMYOqTXkW9q2lpyfDFgNd+yvCuoyhIpFZ4n6Q8StPbotOFP/+Al7390wNFpnzRVfPPFijC2vPvBCaaznN8boHyPVy83+3hK21Hkht22IYwD3nnrHh/cexs/kITBHjGfHk6J4oRmV6AdHB5MGPUTHJZXN2u0gXtnPkkSE0cxQjg++ehbXJwdoZSkbbr9qsViy+1shScl4vrJH7uqXvP59b/g6d0fslnnNLUhy1IuL5cEUcx4EtHphtFwSlNbmnqJ9ATWObpOcnpvyosnV7StZTjOsLrk859ek6YZ2JjNqubB22M+/8kdL54V9Pop/YFHWVq0cfz93/6A3/3XL/ji5685Oe2RJDH5rqWqDGXRcnavTxj63N7kCM/j+HTAP/q7/5i3zh/uNR3h7Y+HfSOZvtkgNLolDjyMsbx8vaTRmixJ3sSJPQLf5+zkcB9ab1qUlEhfgRNvzEVQOM2uu6KyM/r9Hk3b4HkheQGet4/EnZ6NsaUgiDwmk4TZrKGpSzbzHYiYsihQviPNYuZ3G7rOEScp241l9npFvjWUBXz5iy2bjSYbJDx6d0JVwfXVhq+/uEYpy+n5mDST1FWLEB7FriLNJHEUUFYaXwpG45C/+umv8OD8bZbbHXXd4AcK3w/eXE2xF/STOEZrQddUgMfFxQlJHP8lB3MOhLe/r6MoazwBXhiiO0PbtvtEifJRQgaMeu/x7azHT7/+ZyixQkYKR0evN8BYRxA5+sMh69WKxcyQJD5ad1y+2IIzxEnM069uGQwHjCYJTWNJYokUHZdPShazDikbhCe5/zBDt5rb1yVvv3eILyV/9ieXTI8S7t2PyfoBzx/nbNf1m94myHc10vdxDqwTvHj9ii+fPqEuOsq64vT4iMFAYo2jblrWuyXb3Y40UhyNewRxShwEtNqyzXcEgc96s8UBy9WO1WbH0cGIJIkxes/xwjDYI+m6LgnTA0R3RZaMmI4tu/YWz2+wneRwPObzL75gdldy7+EpwgnqsmU1r2kaQZom7PKGdz+4x+Mv57RtywffGfDVn8+5eVWjfJ9H76Z4QiCVYH7X4nmWr75Y8PSbFUJ4VGVH15V88Ys5Zxd9QLFZ16Spj2BvA5m2o2kNz5/NiNOEb148Y3ZTgXDMljsCf493wjCirGour65RnuPibEpnIAxTmnZ/2cnZ8QF38yV1u78A5eZ2AWKvcX/3w7d5/90HpHGE9CSqbg1BT5IGZyTxmNpsyIuQqtgiPIXWGuWFtG1D2ouIQ8lylpOmKb1BxeGxDxauXxXEoQIhef2yYrds6VqPzari4kFI1zqcFbS1YXQQUVV7CbRrGwajhPWyxfMUXeeoyoqDw4QwCqiKjrrW1G8kjLOLPqP+hBcv5tzebsnLkqazWGNRvqKfpfi+h+8JAiX48c++JggTzk5O0LpDSsXL17dIIVlvCoQH5ydT7hZr6qZ749rMGPRS8qJCxdmQrq1J4yGhiLl+tqYxHUHYB9Xx5PlT6sbieftd88ViiVQRaSCIIrVv1rblYBqwWSqEB1Hos1oYqsKRpjHLWUPaj3nxfEUQSLabCoCmtvT6iqY29IcBxbbBao2vBEXeEoSSuu4Iwv3y7WQSMR6Pmb0WbDa3RFGA50mapt6DOva7qEpJfCUY9mOiUJL1x9y/OKZuGvbXnIj94m4v4/HzSxbrjvOT6R4gI7i9W7Jeb8nLCrVfJJMYrYjCEcNxD21Tcj1js9nQVBrnJN/68Igk8bi7bglCQdKPODsbsVw01IWh2FW0nUO3jj9+cUtTQxRLXl/l9HoBm80OENx/NMQTBucktzc7Do9ivvlqg+4sYeCR6pDlvCTrS+5utljjkDIgiiVREmGBKFHMZzl5VSLEPqqnlL//XXesNyUuVUShZLsrqbVgk9dsdiVdt89yJ3GEH4QUVc2on3J+OiWK9rcxTMcDsjRGeB7KWqibkt5gzMXhr1Hnkln5JXZhWO4KQl/jREiR1zTNku225uJ+j7vbGl/BYlbT1qA7i1Iem3XDfNaRZRFVYTk6CZnfNZS5pTcMWa8KmlozPcxYL/eUwxpHU3ccHPbpWo0fSMrSMBgFWGPxA0EQKqqqBc8xGIeIV2Aah/L3frwQAq1bAuXwhWbc63Hv+IBndoF2il3RMFvlOOuw1mCXW4IwZNTLEAievryh7TqUUhyOhzRtQxQGqCiOWC5uyMoxoa84OHyPpIk4jt7Gb3/BNnhM2a559XSJEx69/oC6aUizEM9Z6rJlfguTw5imbrl8XpOkIUJCVWhUqPCkIEo9hqMArTvKsuWbL+coFTAchUSxQXgO3TmMNkgfmlxTFhC+eX/TaKLYYzjok+cObffyaxD4GOuQUv3lzQnaOB6/WvDyZoVB4USA8BSeJ/ZxZ0+B8FBKkdcN9c2C+XLLZNxn0Ev55tlLoiimbVvUfLFiuZzTGxwyuv8WvcGIxUyyreZMj5Y02+e0Xkc2MJSFx+FRj9ndEl/5LG92rOY18zuH70ui2KPTjii2DEchZd5xc1USRgE4Q9aTFIVGCI+udUQxrFY1xc7QdYbBUIBwTA5ihLBMpjHWeMxmBdq0HB6fc3sVMr+z+CrGOUfxxl/3lU8cx1jrqMriL0W5IIqwiL135u0ziVEUIqWPNvvcY6Akga/QFja7grv5Gj+oiUMfL037jMbHzGdXVGVOWRYIl+FFIcvyOXm1RneKfAtXz9c8+2aF9EJ+/uNrVitHr58RxyHGOqbHMYN+wOWLgjiL+f6vnvHt7x5SFR1aW25vSrrOYc1fZA4Vvb5PGAlOLzKkciQ9ge/vNwyFMKTZPtJ7etojjYYs54Km2d+UUDftfv9Md1R1TVlWNE2LM4aurhmlCb0kQhuNw6KkxFeKwPfx/f2uSBIFJFFI3bSAI4qCvbZU10zGAzxPeozO7+PilPliRpnnCBVTtAu0s1xMf4h0e4Vvt+64uSyQynHv4R4UWuuoq5btyvDkyw0qFFw8yLh8subZ1yuG45CDowgpBU1tWdw15NuO8TQCLGEoOToJ6Q88nDWMhjF1bTDG7RNgWuCcZTxOCYMeUbx3H7o3vnr8l7xK/uV9ZUIpgqxH3hm2Rb1XOz2FCmLCOCEIIoxxOCzL7Y7ZakPbaQK1l1yH/Ywg8LHOomxvhJSS83ePWF4/h6oiiR2+GfL+23+V3aqinc55+fKSwI9oasHTL3N0a7i52uFLn8EoYH7XIoRC+h4Hg5D/7w9uSNOG/tAnCAXjaUjXOPJdSxB5XNzv8fXnG/pDi/TADwwH04irlzXbbcFoHLFYtDjbcO/eiMnkgs26+Uu+5VxHFMQcjEYgoCgbjLF4HgjhYfFotMa5DoFA+QFhGDDspWRZQlO3bLc7Vrsc7SxhGHK33LLa5HjSI45D7p8d8f8Dd6JB/2WkCSQAAAAASUVORK5CYII=';
    const plugin=window.plugin.redactedBannerLabBridge={};
    plugin.state={v:2,c:0,n:1,ppm:6,auto:true,m:[[]],direct:true};
    plugin.routeLayer=null;plugin.selectedGuid=null;plugin.collapsed=false;
    const enc=obj=>{const b=new TextEncoder().encode(JSON.stringify(obj));let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')};
    const dec=raw=>{let s=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const bin=atob(s),b=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(b))};
    const normalize=st=>{
      st=st&&typeof st==='object'?st:{};
      const rawN=parseInt(st.n);
      // Sans projectId fiable, le total reçu via l'URL IITC n'est pas considéré
      // comme certain. Le Companion passe alors en mode "total inconnu".
      const knownTotal=!!String(st.pid||'')&&Number.isFinite(rawN)&&rawN>=1;
      const n=knownTotal?rawN:0;
      const source=Array.isArray(st.m)?st.m:[];
      const count=Math.max(1,n||source.length||1);
      const m=source.slice(0,count);
      while(m.length<count)m.push([]);
      const maxIndex=Math.max(0,m.length-1);
      return {
        v:4,pid:String(st.pid||''),name:String(st.name||'BannerLab'),
        c:Math.max(0,Math.min(maxIndex,parseInt(st.c)||0)),
        n,ppm:Math.max(1,Math.min(24,parseInt(st.ppm)||6)),
        auto:st.auto!==false,carry:st.carry!==false,
        lang:['fr','en','es'].includes(st.lang)?st.lang:'fr',
        askAction:st.askAction!==false,
        objective:String(st.objective||'HACK_PORTAL'),
        question:String(st.question||''),answer:String(st.answer||''),
        m:m.map(x=>Array.isArray(x)?x:[]),
        direct:st.direct!==false
      };
    };

    const TXT={
      fr:{touch:'Touche un portail sur la carte',add:'Ajouter',remove:'Retirer',prev:'Mission',next:'Mission',sync:'Synchroniser BannerLab',direct:'Ajout direct au toucher',ask:'Demander l’action avant ajout',reuse:'Fin précédente → début suivante',stats:'Stats parfaitement inutiles',hideStats:'Masquer les stats',action:'Action',hack:'Hack',mod:'Mod',capture:'Capture / upgrade',link:'Lien',field:'Champ',pass:'Passphrase',question:'Question',answer:'Réponse',carry:'↪ Reprendre fin précédente',used:'Déjà utilisé dans la bannière',added:'Portail ajouté',choose:'Choisis l’action puis Ajouter',mission:'Mission',unknown:'Total inconnu',linked:'Projet lié'},
      en:{touch:'Tap a portal on the map',add:'Add',remove:'Remove',prev:'Mission',next:'Mission',sync:'Sync BannerLab',direct:'Direct add on tap',ask:'Ask action before adding',reuse:'Previous end → next start',stats:'Perfectly useless stats',hideStats:'Hide stats',action:'Action',hack:'Hack',mod:'Mod',capture:'Capture / upgrade',link:'Link',field:'Field',pass:'Passphrase',question:'Question',answer:'Answer',carry:'↪ Reuse previous end',used:'Already used in banner',added:'Portal added',choose:'Choose the action, then Add',mission:'Mission',unknown:'Unknown total',linked:'Linked project'},
      es:{touch:'Toca un portal en el mapa',add:'Añadir',remove:'Quitar',prev:'Misión',next:'Misión',sync:'Sincronizar BannerLab',direct:'Añadir directamente al tocar',ask:'Preguntar acción antes de añadir',reuse:'Fin anterior → inicio siguiente',stats:'Estadísticas perfectamente inútiles',hideStats:'Ocultar estadísticas',action:'Acción',hack:'Hackear',mod:'Mod',capture:'Capturar / mejorar',link:'Enlace',field:'Campo',pass:'Contraseña',question:'Pregunta',answer:'Respuesta',carry:'↪ Reutilizar final anterior',used:'Ya usado en el mosaico',added:'Portal añadido',choose:'Elige la acción y pulsa Añadir',mission:'Misión',unknown:'Total desconocido',linked:'Proyecto vinculado'}
    };
    plugin.t=k=>(TXT[plugin.state.lang]||TXT.fr)[k]||TXT.fr[k]||k;
    plugin.objectiveOptions=()=>[
      ['HACK_PORTAL',plugin.t('hack')],
      ['INSTALL_MOD',plugin.t('mod')],
      ['CAPTURE_PORTAL',plugin.t('capture')],
      ['CREATE_LINK',plugin.t('link')],
      ['CREATE_FIELD',plugin.t('field')],
      ['PASSPHRASE',plugin.t('pass')]
    ];
    plugin.readObjectiveUi=()=>{
      const type=document.getElementById('rbl-objective')?.value||plugin.state.objective||'HACK_PORTAL';
      const question=document.getElementById('rbl-question')?.value||'';
      const answer=document.getElementById('rbl-answer')?.value||'';
      plugin.state.objective=type;plugin.state.question=question;plugin.state.answer=answer;
      return {type,question,answer};
    };

    plugin.save=()=>{try{localStorage.setItem(KEY,JSON.stringify(plugin.state))}catch(e){}};
    plugin.load=()=>{try{
      const u=new URL(location.href);
      const hm=u.hash.match(/(?:^|[?#&])rbl=([^&]+)/);
      const raw=u.searchParams.get('rbl')||(hm?.[1]?decodeURIComponent(hm[1]):'');
      if(raw){
        plugin.state=normalize(dec(raw));
        plugin.save();
        return;
      }
      const current=localStorage.getItem(KEY);
      if(current){
        plugin.state=normalize(JSON.parse(current));
        return;
      }
      // Migration automatique de Companion 0.2 : on garde les portails,
      // mais un vieux "1/1" sans liaison projet devient un total inconnu.
      const old=localStorage.getItem(OLD_KEY);
      if(old){
        plugin.state=normalize(JSON.parse(old));
        plugin.save();
      }
    }catch(e){console.warn('[BannerLab] load',e)}};
    plugin.ensureMission=i=>{while(plugin.state.m.length<=i)plugin.state.m.push([]);return plugin.state.m[i]};
    plugin.current=()=>plugin.ensureMission(plugin.state.c);
    plugin.hasKnownTotal=()=>plugin.state.n>0;
    plugin.totalLabel=()=>plugin.hasKnownTotal()?String(plugin.state.n):'?';
    plugin.canCreateNext=()=>!plugin.hasKnownTotal()||plugin.state.c<plugin.state.n-1;
    plugin.goNext=()=>{
      if(plugin.hasKnownTotal()&&plugin.state.c>=plugin.state.n-1){plugin.flash('Dernière mission');return false}
      const next=plugin.state.c+1;
      plugin.ensureMission(next);
      plugin.state.c=next;
      return true;
    };

    plugin.rad=x=>x*Math.PI/180;
    plugin.haversine=(a,b)=>{
      const lat1=Number(a?.[2]),lon1=Number(a?.[3]),lat2=Number(b?.[2]),lon2=Number(b?.[3]);
      if(![lat1,lon1,lat2,lon2].every(Number.isFinite))return 0;
      const dlat=plugin.rad(lat2-lat1),dlon=plugin.rad(lon2-lon1);
      const s=Math.sin(dlat/2)**2+Math.cos(plugin.rad(lat1))*Math.cos(plugin.rad(lat2))*Math.sin(dlon/2)**2;
      return 6371*2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
    };
    plugin.formatKm=km=>{
      km=Number(km)||0;
      if(km<1)return Math.round(km*1000)+' m';
      return km.toFixed(km<10?2:1)+' km';
    };
    plugin.formatTime=sec=>{
      sec=Math.max(0,Math.round(Number(sec)||0));
      const h=Math.floor(sec/3600),m=Math.round((sec%3600)/60);
      if(!h)return m+' min';
      return h+' h '+String(m).padStart(2,'0');
    };
    plugin.routeSignature=()=>{
      const points=[];
      plugin.state.m.forEach((mission,mi)=>{
        (mission||[]).forEach((p,pi)=>{
          points.push([mi,pi,String(p?.[0]||''),Number(p?.[2])||0,Number(p?.[3])||0]);
        });
      });
      return JSON.stringify(points);
    };
    plugin.directStats=()=>{
      const missions=plugin.state.m||[];
      const perMission=missions.map((m,mi)=>{
        let km=0,longest=0,longestNames=null;
        for(let i=0;i<(m||[]).length-1;i++){
          const d=plugin.haversine(m[i],m[i+1]);
          km+=d;
          if(d>longest){longest=d;longestNames=[m[i]?.[1]||'Portail',m[i+1]?.[1]||'Portail']}
        }
        return {mi,km,portals:(m||[]).length,longest,longestNames};
      });
      let total=0,transitions=0,longest=0,longestNames=null;
      for(const x of perMission){total+=x.km;if(x.longest>longest){longest=x.longest;longestNames=x.longestNames}}
      for(let mi=0;mi<missions.length-1;mi++){
        const a=missions[mi]||[],b=missions[mi+1]||[];
        if(a.length&&b.length){
          const d=plugin.haversine(a[a.length-1],b[0]);
          transitions+=d;total+=d;
          if(d>longest){longest=d;longestNames=[a[a.length-1]?.[1]||'Fin mission',b[0]?.[1]||'Début mission']}
        }
      }
      const portals=missions.reduce((n,m)=>n+(m||[]).length,0);
      const started=missions.filter(m=>(m||[]).length>0).length;
      const complete=missions.filter(m=>(m||[]).length>=plugin.state.ppm).length;
      return {perMission,total,transitions,portals,started,complete,longest,longestNames};
    };
    plugin.flattenRoute=()=>{
      const flat=[];
      (plugin.state.m||[]).forEach((mission,mi)=>{
        (mission||[]).forEach((p,pi)=>{
          flat.push({p,mi,pi});
        });
      });
      return flat;
    };
    plugin.loadStatsCache=()=>{
      try{
        const raw=localStorage.getItem(STATS_KEY);
        if(!raw)return null;
        const obj=JSON.parse(raw);
        return obj&&obj.sig===plugin.routeSignature()?obj:null;
      }catch(e){return null}
    };
    plugin.saveStatsCache=result=>{
      try{
        localStorage.setItem(STATS_KEY,JSON.stringify({...result,sig:plugin.routeSignature(),at:Date.now()}));
      }catch(e){}
    };
    plugin.fetchChunk=async chunk=>{
      const ctrl=new AbortController();
      const timer=setTimeout(()=>ctrl.abort(),18000);
      try{
        const body={
          locations:chunk.map(x=>({lat:Number(x.p[2]),lon:Number(x.p[3]),type:'break'})),
          costing:'pedestrian',
          units:'kilometers',
          directions_options:{units:'kilometers',language:'fr-FR'}
        };
        const r=await fetch(VALHALLA,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify(body),
          signal:ctrl.signal
        });
        if(!r.ok)throw new Error('Valhalla HTTP '+r.status);
        const data=await r.json();
        const legs=data?.trip?.legs||[];
        if(legs.length!==Math.max(0,chunk.length-1))throw new Error('Réponse de routage incomplète');
        return legs.map(leg=>({
          km:Number(leg?.summary?.length)||0,
          sec:Number(leg?.summary?.time)||0
        }));
      }finally{
        clearTimeout(timer);
      }
    };
    plugin.walkStats=async()=>{
      const direct=plugin.directStats();
      const flat=plugin.flattenRoute();
      if(flat.length<2){
        return {direct,walking:null,error:'Ajoute au moins deux portails.'};
      }

      const cached=plugin.loadStatsCache();
      if(cached?.walking)return {direct,walking:cached.walking,cached:true};

      const missionKm=(plugin.state.m||[]).map(()=>0);
      const missionSec=(plugin.state.m||[]).map(()=>0);
      let totalKm=0,totalSec=0,transitionKm=0,transitionSec=0;
      let longestKm=0,longestNames=null,longestMission=null;

      // Valhalla accepte un nombre configurable de locations; on reste sous 50
      // et on chevauche le dernier point pour ne perdre aucune étape.
      let start=0;
      while(start<flat.length-1){
        const end=Math.min(flat.length,start+MAX_ROUTE_POINTS);
        const chunk=flat.slice(start,end);
        const legs=await plugin.fetchChunk(chunk);

        legs.forEach((leg,i)=>{
          const a=chunk[i],b=chunk[i+1];
          totalKm+=leg.km;totalSec+=leg.sec;
          if(a.mi===b.mi){
            missionKm[a.mi]=(missionKm[a.mi]||0)+leg.km;
            missionSec[a.mi]=(missionSec[a.mi]||0)+leg.sec;
          }else{
            transitionKm+=leg.km;transitionSec+=leg.sec;
          }
          if(leg.km>longestKm){
            longestKm=leg.km;
            longestNames=[a.p?.[1]||'Portail',b.p?.[1]||'Portail'];
          }
        });

        if(end>=flat.length)break;
        start=end-1;
        await new Promise(r=>setTimeout(r,180));
      }

      missionKm.forEach((km,mi)=>{
        if(km>0&&(!longestMission||km>longestMission.km)){
          longestMission={mi,km,sec:missionSec[mi]||0};
        }
      });

      const walking={
        totalKm,totalSec,transitionKm,transitionSec,
        missionKm,missionSec,longestKm,longestNames,longestMission
      };
      plugin.saveStatsCache({walking});
      return {direct,walking,cached:false};
    };
    plugin.statsOpen=false;
    plugin.statsLoading=false;
    plugin.renderStats=async(force=false)=>{
      const box=document.getElementById('rbl-stats-box');
      if(!box)return;
      const direct=plugin.directStats();
      const current=direct.perMission[plugin.state.c]||{km:0,portals:0};
      const directTotal=direct.total;
      const directActive=current.km;
      const totalMissions=plugin.state.n||plugin.state.m.length||1;
      const avgDirect=direct.started?directTotal/direct.started:0;
      const directPortalsPerKm=directTotal>0?direct.portals/directTotal:0;

      box.innerHTML=`
        <div class="rbl-stats-grid">
          <div><b>${direct.portals}</b><span>portails</span></div>
          <div><b>${direct.complete}/${totalMissions}</b><span>missions complètes</span></div>
          <div><b>${plugin.formatKm(directActive)}</b><span>mission · direct</span></div>
          <div><b>${plugin.formatKm(directTotal)}</b><span>fresque · direct</span></div>
        </div>
        <div class="rbl-stats-note">Calcul piéton Valhalla/OSM en cours…</div>`;

      if(plugin.statsLoading)return;
      plugin.statsLoading=true;
      try{
        if(force)localStorage.removeItem(STATS_KEY);
        const result=await plugin.walkStats();
        const w=result.walking;
        if(!w){
          box.innerHTML+=`<div class="rbl-stats-error">${result.error||'Routage indisponible.'}</div>`;
          return;
        }

        const activeKm=w.missionKm[plugin.state.c]||0;
        const activeSec=w.missionSec[plugin.state.c]||0;
        const detour=directTotal>0?((w.totalKm/directTotal)-1)*100:0;
        const walkPerPortal=direct.portals>0?w.totalKm/direct.portals:0;
        const portalsPerKm=w.totalKm>0?direct.portals/w.totalKm:0;
        const avgMission=direct.started?w.totalKm/direct.started:0;
        const longestMission=w.longestMission;
        const longestMissionLabel=longestMission
          ?`M${longestMission.mi+1} · ${plugin.formatKm(longestMission.km)}`
          :'—';
        const longestStep=w.longestNames
          ?`${plugin.formatKm(w.longestKm)} · ${w.longestNames[0]} → ${w.longestNames[1]}`
          :'—';

        box.innerHTML=`
          <div class="rbl-stats-grid">
            <div><b>${direct.portals}</b><span>portails</span></div>
            <div><b>${direct.complete}/${totalMissions}</b><span>missions complètes</span></div>
            <div><b>${plugin.formatKm(activeKm)}</b><span>mission à pied</span></div>
            <div><b>${plugin.formatTime(activeSec)}</b><span>temps mission</span></div>
            <div><b>${plugin.formatKm(w.totalKm)}</b><span>fresque à pied</span></div>
            <div><b>${plugin.formatTime(w.totalSec)}</b><span>temps théorique</span></div>
            <div><b>${plugin.formatKm(w.transitionKm)}</b><span>liaisons missions</span></div>
            <div><b>+${Math.max(0,detour).toFixed(0)}%</b><span>détour civilisation</span></div>
          </div>
          <div class="rbl-fun">
            <div><span>Mission la plus sportive</span><b>${longestMissionLabel}</b></div>
            <div><span>Étape la plus longue</span><b>${longestStep}</b></div>
            <div><span>Moyenne / mission</span><b>${plugin.formatKm(avgMission)}</b></div>
            <div><span>Mètres / portail</span><b>${Math.round(walkPerPortal*1000)} m</b></div>
            <div><span>Portails / km</span><b>${portalsPerKm.toFixed(1)}</b></div>
            <div><span>Vol d’oiseau cumulé</span><b>${plugin.formatKm(directTotal)}</b></div>
          </div>
          <div class="rbl-stats-note">${result.cached?'Résultat en cache':'Calculé maintenant'} · estimation piétonne Valhalla + OpenStreetMap, pas un GPS.</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ Recalculer les stats piétonnes</button>`;

        const refresh=document.getElementById('rbl-stats-refresh');
        if(refresh)refresh.onclick=()=>plugin.renderStats(true);
      }catch(e){
        console.warn('[BannerLab Stats]',e);
        box.innerHTML=`
          <div class="rbl-stats-grid">
            <div><b>${direct.portals}</b><span>portails</span></div>
            <div><b>${direct.complete}/${totalMissions}</b><span>missions complètes</span></div>
            <div><b>${plugin.formatKm(directActive)}</b><span>mission · direct</span></div>
            <div><b>${plugin.formatKm(directTotal)}</b><span>fresque · direct</span></div>
          </div>
          <div class="rbl-stats-error">Routage piéton indisponible pour l’instant. Les stats directes restent valables.</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ Réessayer</button>`;
        const refresh=document.getElementById('rbl-stats-refresh');
        if(refresh)refresh.onclick=()=>plugin.renderStats(true);
      }finally{
        plugin.statsLoading=false;
      }
    };
    plugin.toggleStats=()=>{
      plugin.statsOpen=!plugin.statsOpen;
      plugin.render();
      if(plugin.statsOpen)setTimeout(()=>plugin.renderStats(false),0);
    };

    plugin.portalFromMarker=(marker,obj)=>{if(!marker)return null;const d=marker.options&&marker.options.data||{},ll=marker.getLatLng(),o=obj||plugin.readObjectiveUi();return [String(marker.options&&marker.options.guid||''),String(d.title||'Portail'),Number(ll.lat),Number(ll.lng),String(d.image||''),String(o.type||'HACK_PORTAL'),String(o.question||''),String(o.answer||'')]};
    plugin.findMarker=guid=>guid&&window.portals&&window.portals[guid];
    plugin.guidUses=guid=>{
      const uses=[];
      plugin.state.m.forEach((m,mi)=>(m||[]).forEach((p,pi)=>{if(guid&&p&&p[0]===guid)uses.push({mi,pi})}));
      return uses;
    };
    plugin.allowedHandover=guid=>{
      if(!guid||plugin.state.c<=0||plugin.current().length)return false;
      const prev=plugin.state.m[plugin.state.c-1]||[];
      return prev.length&&prev[prev.length-1]?.[0]===guid;
    };
    plugin.isUsed=guid=>plugin.guidUses(guid).length>0;
    plugin.addMarker=(marker,forceHandover=false)=>{
      const obj=plugin.readObjectiveUi();
      const p=plugin.portalFromMarker(marker,obj);if(!p)return;
      if(plugin.isUsed(p[0])&&!forceHandover&&!plugin.allowedHandover(p[0])){plugin.flash(plugin.t('used'));return}
      const arr=plugin.current();arr.push(p);
      if(plugin.state.auto&&arr.length>=plugin.state.ppm&&plugin.canCreateNext()){
        const oldMission=plugin.state.c+1;
        plugin.goNext();
        if(plugin.state.carry){
          const next=plugin.current();
          if(!next.length)next.push([...p]);
        }
        plugin.flash(plugin.t('mission')+' '+oldMission+' → '+plugin.t('mission')+' '+(plugin.state.c+1));
      }else plugin.flash(plugin.t('added'));
      localStorage.removeItem(STATS_KEY);plugin.save();plugin.render();plugin.drawRoute();
    };
    plugin.addSelected=()=>{const guid=window.selectedPortal||plugin.selectedGuid,marker=plugin.findMarker(guid);if(!marker){plugin.flash('Sélectionne un portail');return}plugin.addMarker(marker)};
    plugin.carryPrevious=()=>{
      if(plugin.state.c<=0||plugin.current().length){plugin.flash('—');return}
      const prev=plugin.state.m[plugin.state.c-1]||[];
      const p=prev[prev.length-1];if(!p){plugin.flash('—');return}
      plugin.current().push([...p]);localStorage.removeItem(STATS_KEY);plugin.save();plugin.render();plugin.drawRoute();
      plugin.flash(plugin.t('reuse'));
    };
    plugin.removeLast=()=>{const arr=plugin.current();if(!arr.length){plugin.flash('Mission vide');return}const guid=window.selectedPortal||plugin.selectedGuid;const idx=guid?arr.findIndex(p=>p&&p[0]===guid):-1;if(idx>=0){arr.splice(idx,1);plugin.flash('Portail sélectionné retiré')}else{arr.pop();plugin.flash('Dernier portail retiré')}localStorage.removeItem(STATS_KEY);plugin.save();plugin.render();plugin.drawRoute()};
    plugin.prev=()=>{if(plugin.state.c>0)plugin.state.c--;plugin.save();plugin.render();plugin.drawRoute()};
    plugin.next=()=>{if(plugin.goNext()){plugin.flash('Mission '+(plugin.state.c+1));plugin.save();plugin.render();plugin.drawRoute()}};
    plugin.sync=()=>{plugin.save();const payload={...plugin.state,n:plugin.state.n||plugin.state.m.length,pv:'0.5.0',direct:undefined};window.location.href='redactedbannerlab://sync?data='+encodeURIComponent(enc(payload))};
    plugin.flash=msg=>{const el=document.getElementById('rbl-flash');if(!el)return;el.textContent=msg;el.classList.add('show');clearTimeout(plugin.flashTimer);plugin.flashTimer=setTimeout(()=>el.classList.remove('show'),1600)};
    plugin.toggleDirect=()=>{plugin.state.direct=!plugin.state.direct;plugin.save();plugin.render();plugin.flash(plugin.state.direct?'Ajout direct activé':'Ajout direct désactivé')};
    plugin.toggleCollapse=()=>{plugin.collapsed=!plugin.collapsed;plugin.render()};
    // 0.4.1 SAFE : ne touche plus individuellement aux marqueurs Leaflet.
    // On s'appuie uniquement sur le hook officiel IITC portalSelected.
    plugin.lastDirectGuid=null;
    plugin.lastDirectAt=0;
    plugin.handlePortalSelected=data=>{
      const guid=String(data?.selectedPortalGuid||window.selectedPortal||'');
      plugin.selectedGuid=guid||null;
      plugin.updateSelected();

      if(!plugin.state.direct||!guid)return;
      if(plugin.state.askAction){plugin.flash(plugin.t('choose'));return}

      const now=Date.now();
      if(plugin.lastDirectGuid===guid && now-plugin.lastDirectAt<700)return;
      plugin.lastDirectGuid=guid;
      plugin.lastDirectAt=now;

      const marker=plugin.findMarker(guid);
      if(!marker){
        plugin.flash('Portail sélectionné, données pas encore prêtes');
        return;
      }

      // Laisse IITC terminer sa propre sélection avant d'ajouter au parcours.
      setTimeout(()=>{
        const currentMarker=plugin.findMarker(guid);
        if(currentMarker)plugin.addMarker(currentMarker);
      },40);
    };
    plugin.updateSelected=()=>{const guid=window.selectedPortal||plugin.selectedGuid,m=plugin.findMarker(guid),el=document.getElementById('rbl-selected');if(!el)return;if(!m){el.textContent=plugin.t('touch');return}const d=m.options&&m.options.data||{};el.textContent=String(d.title||'Portail sélectionné')};
    plugin.drawRoute=()=>{if(!window.L||!window.map)return;if(!plugin.routeLayer){plugin.routeLayer=L.layerGroup().addTo(map)}plugin.routeLayer.clearLayers();const arr=plugin.current(),pts=arr.map(p=>[Number(p[2]),Number(p[3])]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));if(pts.length>1)L.polyline(pts,{color:'#36f08a',weight:5,opacity:.86,lineJoin:'round'}).addTo(plugin.routeLayer);pts.forEach((ll,i)=>{const ic=L.divIcon({className:'rbl-route-dot',html:'<span>'+(i+1)+'</span>',iconSize:[26,26],iconAnchor:[13,13]});L.marker(ll,{icon:ic,interactive:false}).addTo(plugin.routeLayer)})};
    plugin.render=()=>{
      let root=document.getElementById('rbl-companion');
      if(!root){root=document.createElement('div');root.id='rbl-companion';document.body.appendChild(root)}
      const arr=plugin.current(),total=plugin.totalLabel();
      if(plugin.collapsed){
        root.innerHTML='<button id="rbl-open" class="rbl-mini"><img src="'+ICON+'"><span>M'+(plugin.state.c+1)+'/'+total+' · '+arr.length+'/'+plugin.state.ppm+'</span></button>';
        document.getElementById('rbl-open').onclick=plugin.toggleCollapse;
        return;
      }
      const actionOpts=plugin.objectiveOptions().map(([v,l])=>`<option value="${v}" ${plugin.state.objective===v?'selected':''}>${l}</option>`).join('');
      const showPass=plugin.state.objective==='PASSPHRASE';
      const prev=plugin.state.c>0?(plugin.state.m[plugin.state.c-1]||[]):[];
      const canCarry=plugin.state.c>0&&!arr.length&&prev.length;
      root.innerHTML=`<div class="rbl-head"><img src="${ICON}"><div><b>BannerLab <small>0.5</small></b><span>${plugin.t('mission')} ${plugin.state.c+1}/${total} · ${arr.length}/${plugin.state.ppm}</span></div><button id="rbl-collapse">−</button></div>
      <div class="rbl-mode">${plugin.hasKnownTotal()?plugin.t('linked')+' · '+plugin.state.n:plugin.t('unknown')} · safe</div>
      <div id="rbl-selected" class="rbl-selected">${plugin.t('touch')}</div>
      <div class="rbl-actionbox">
        <label>${plugin.t('action')}</label>
        <select id="rbl-objective">${actionOpts}</select>
        <div id="rbl-passbox" class="rbl-passbox" ${showPass?'':'hidden'}>
          <input id="rbl-question" placeholder="${plugin.t('question')}" value="${String(plugin.state.question||'').replaceAll('"','&quot;')}">
          <input id="rbl-answer" placeholder="${plugin.t('answer')}" value="${String(plugin.state.answer||'').replaceAll('"','&quot;')}">
        </div>
      </div>
      <label class="rbl-direct"><input id="rbl-ask" type="checkbox" ${plugin.state.askAction?'checked':''}> ${plugin.t('ask')}</label>
      <label class="rbl-direct"><input id="rbl-direct" type="checkbox" ${plugin.state.direct?'checked':''}> ${plugin.t('direct')}</label>
      <label class="rbl-direct"><input id="rbl-carry" type="checkbox" ${plugin.state.carry?'checked':''}> ${plugin.t('reuse')}</label>
      <div class="rbl-grid">
        <button id="rbl-add">＋ ${plugin.t('add')}</button>
        <button id="rbl-remove">↶ ${plugin.t('remove')}</button>
        <button id="rbl-prev" ${plugin.state.c===0?'disabled':''}>‹ ${plugin.t('prev')}</button>
        <button id="rbl-next" ${plugin.hasKnownTotal()&&plugin.state.c===plugin.state.n-1?'disabled':''}>${plugin.t('next')} ›</button>
      </div>
      <button id="rbl-carryprev" class="rbl-carryprev" ${canCarry?'':'disabled'}>${plugin.t('carry')}</button>
      <button id="rbl-stats" class="rbl-stats-toggle">📊 ${plugin.statsOpen?plugin.t('hideStats'):plugin.t('stats')}</button>
      ${plugin.statsOpen?'<div id="rbl-stats-box" class="rbl-stats-box"><div class="rbl-stats-note">…</div></div>':''}
      <button id="rbl-sync" class="rbl-sync">↩ ${plugin.t('sync')}</button>
      <div id="rbl-flash" class="rbl-flash"></div>`;
      document.getElementById('rbl-collapse').onclick=plugin.toggleCollapse;
      document.getElementById('rbl-direct').onchange=e=>{plugin.state.direct=e.target.checked;plugin.save()};
      document.getElementById('rbl-ask').onchange=e=>{plugin.state.askAction=e.target.checked;plugin.save()};
      document.getElementById('rbl-carry').onchange=e=>{plugin.state.carry=e.target.checked;plugin.save()};
      document.getElementById('rbl-objective').onchange=e=>{
        plugin.state.objective=e.target.value;
        document.getElementById('rbl-passbox').hidden=e.target.value!=='PASSPHRASE';
        plugin.save();
      };
      const q=document.getElementById('rbl-question'),a=document.getElementById('rbl-answer');
      if(q)q.oninput=e=>{plugin.state.question=e.target.value;plugin.save()};
      if(a)a.oninput=e=>{plugin.state.answer=e.target.value;plugin.save()};
      document.getElementById('rbl-add').onclick=plugin.addSelected;
      document.getElementById('rbl-remove').onclick=plugin.removeLast;
      document.getElementById('rbl-prev').onclick=plugin.prev;
      document.getElementById('rbl-next').onclick=plugin.next;
      document.getElementById('rbl-carryprev').onclick=plugin.carryPrevious;
      document.getElementById('rbl-stats').onclick=plugin.toggleStats;
      document.getElementById('rbl-sync').onclick=plugin.sync;
      plugin.updateSelected();
      if(plugin.statsOpen)setTimeout(()=>plugin.renderStats(false),0);
    };
    function setup(){
      const css=document.createElement('style');css.textContent=`#rbl-companion{position:fixed;z-index:10000;right:10px;bottom:72px;width:min(300px,calc(100vw - 20px));font-family:system-ui,-apple-system,sans-serif;color:#f3fff8;filter:drop-shadow(0 10px 28px rgba(0,0,0,.45))}#rbl-companion *{box-sizing:border-box}#rbl-companion>div:not(.rbl-flash),#rbl-companion{}.rbl-head{display:flex;align-items:center;gap:9px;background:#07150e;border:1px solid rgba(54,240,138,.35);border-bottom:0;border-radius:16px 16px 0 0;padding:8px 9px}.rbl-head img{width:38px;height:38px;border-radius:11px;object-fit:cover}.rbl-head div{min-width:0;flex:1}.rbl-head b{font-size:14px;display:block}.rbl-head b small{font-size:9px;color:#58f69d;margin-left:4px}.rbl-head span{font-size:11px;color:#9bb6a7}.rbl-head button{width:34px;height:34px;border:0;border-radius:10px;background:#10291b;color:#fff;font-size:22px}.rbl-mode{background:#0d2418;color:#70d99f;padding:5px 10px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);font-size:9px;font-weight:700}.rbl-actionbox{background:#07150e;padding:7px 9px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}.rbl-actionbox label{display:block;font-size:9px;color:#83a58f;margin-bottom:3px}.rbl-actionbox select,.rbl-passbox input{width:100%;min-height:34px;border:1px solid #244b34;border-radius:8px;background:#0e2519;color:#fff;padding:6px 8px;font-size:11px}.rbl-passbox{display:grid;gap:5px;margin-top:5px}.rbl-passbox[hidden]{display:none}.rbl-carryprev{width:100%;min-height:34px;border:1px solid #244b34;border-radius:0;background:#0e2519;color:#9ceaba;font-weight:750;font-size:10px}.rbl-carryprev:disabled{opacity:.35}.rbl-selected{background:#0a1d13;padding:8px 10px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12px;font-weight:700}.rbl-direct{display:flex;align-items:center;gap:7px;background:#0a1d13;padding:7px 10px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);font-size:11px;color:#cfe7d9}.rbl-direct input{accent-color:#36f08a;width:18px;height:18px}.rbl-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;background:#07150e;padding:7px 8px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}.rbl-grid button,.rbl-sync{min-height:42px;border:1px solid #244b34;border-radius:10px;background:#10291b;color:#f3fff8;font-weight:750;font-size:12px}.rbl-grid button:disabled{opacity:.35}.rbl-grid button:first-child{background:#36f08a;color:#05130b;border-color:#36f08a}.rbl-stats-toggle{width:100%;min-height:38px;border:1px solid #244b34;border-radius:0;background:#0d2418;color:#8ff2b8;font-weight:800;font-size:11px}.rbl-stats-box{background:#07150e;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);padding:8px}.rbl-stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px}.rbl-stats-grid div{background:#0d2418;border:1px solid #1e432e;border-radius:9px;padding:7px 8px;min-width:0}.rbl-stats-grid b{display:block;color:#f5fff9;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rbl-stats-grid span{display:block;color:#8cae9a;font-size:8px;margin-top:2px}.rbl-fun{margin-top:7px;border-top:1px dashed #214a32;padding-top:5px}.rbl-fun div{display:flex;justify-content:space-between;gap:8px;padding:3px 1px;font-size:9px}.rbl-fun span{color:#87a794}.rbl-fun b{color:#dff9e9;text-align:right;max-width:62%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rbl-stats-note{font-size:8px;line-height:1.35;color:#6f927c;margin-top:7px}.rbl-stats-error{font-size:9px;line-height:1.4;color:#ffb9a8;background:#2a1510;border:1px solid #593026;border-radius:8px;padding:7px;margin-top:7px}.rbl-stats-refresh{width:100%;min-height:34px;margin-top:7px;border:1px solid #27563a;border-radius:8px;background:#10291b;color:#8ff2b8;font-weight:800;font-size:10px}.rbl-sync{width:100%;border-radius:0 0 16px 16px;background:#163c28;border-color:rgba(54,240,138,.35);color:#58f69d}.rbl-flash{position:absolute;left:10px;right:10px;bottom:-34px;background:#020a05;color:#fff;border-radius:9px;padding:7px 9px;font-size:11px;text-align:center;opacity:0;pointer-events:none;transition:.18s}.rbl-flash.show{opacity:1}.rbl-mini{display:flex;align-items:center;gap:8px;border:1px solid rgba(54,240,138,.45);border-radius:999px;background:#07150e;color:#fff;padding:5px 10px 5px 5px;font-weight:800}.rbl-mini img{width:36px;height:36px;border-radius:50%;object-fit:cover}.rbl-route-dot{background:transparent!important;border:0!important}.rbl-route-dot span{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#07150e;border:2px solid #36f08a;color:#fff;font:bold 11px system-ui;box-shadow:0 2px 7px #000}`;document.head.appendChild(css);
      plugin.load();plugin.render();plugin.drawRoute();
      window.addHook('portalSelected',plugin.handlePortalSelected);
      window.addHook('mapDataRefreshEnd',()=>{plugin.drawRoute()});
      if(window.IITC&&IITC.toolbox&&IITC.toolbox.addButton)IITC.toolbox.addButton({label:'BannerLab',title:'Afficher/masquer IITC Companion',action:plugin.toggleCollapse});
    }
    setup.info={script:{name:'Redacted BannerLab IITC Companion',version:'0.5.0'}};window.bootPlugins=window.bootPlugins||[];window.bootPlugins.push(setup);if(window.iitcLoaded)setup();
  }
  const s=document.createElement('script');s.textContent='('+wrapper+')();';(document.body||document.head||document.documentElement).appendChild(s);
})();
