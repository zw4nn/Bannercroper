import './style.css';
import JSZip from 'jszip';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const APP_VERSION = '0.1.0';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  name: 'Ma fresque', rows: 3,
  showGrid: true, showCircles: true, showNumbers: true,
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0 },
  texts: [], active: 'background', dirty:false
};

let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand"><div class="brandmark"><svg viewBox="0 0 24 24" fill="none" stroke="#041009" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M7 12h10M12 7v10"/></svg></div><div><h1>BannerForge</h1><small>Fresques Ingress Prime · v${APP_VERSION}</small></div></div>
      <div class="grow"></div><button class="iconbtn" id="infoBtn" aria-label="Infos">${icon('info')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> missions · source ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <div class="rowpick"><span>Rangées</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="card workspace">
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>Ajoute ton image</strong>Elle sera cadrée directement sur la géométrie Prime.</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">Cercles Prime</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">Grille 512</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">Numéros</button>
        </div>
        <div class="hint"><b>1 doigt</b> déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent. Les zones de 512 px sont espacées sur un pas de 544 px avec 16 px de marge de chaque côté.</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>Image</span></button>
      <button class="tool active" data-tool="move">${icon('move')}<span>Cadrage</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>Texte</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>Aperçu</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>Exporter</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return s.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function renderContent(target, scaleFactor=1, offsetX=0, offsetY=0){
  const c=target;
  c.save();
  c.translate(offsetX,offsetY);
  c.scale(scaleFactor,scaleFactor);
  if(state.bg.image){
    const b=state.bg;
    c.save();c.translate(b.x,b.y);c.rotate(b.rotation);c.scale(b.scale,b.scale);
    c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
  }
  for(const t of state.texts) drawTextWorld(c,t);
  c.restore();
}

function drawTextWorld(c,t){
  const lines=(t.text||'Texte').split('\n');
  c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  const lineH=t.fontSize*1.08;
  lines.forEach((line,i)=>{const y=(i-(lines.length-1)/2)*lineH;if(t.strokeWidth>0){c.lineWidth=t.strokeWidth;c.strokeStyle=t.strokeColor;c.strokeText(line,0,y)}c.fillStyle=t.color;c.fillText(line,0,y)});
  c.restore();
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  renderContent(ctx,s);
  if(state.showGrid||state.showCircles||state.showNumbers) drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=state.bg.image?'none':'grid';
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(!state.active.startsWith('text:'))return;
  const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
  c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;
  const lines=t.text.split('\n');const w=Math.max(...lines.map(x=>c.measureText(x).width),40)+36;const h=lines.length*t.fontSize*1.08+28;
  c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}

function selectedObj(){if(state.active==='background')return state.bg;if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));return state.bg}

function setActive(a){state.active=a;$$('.tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='move'&&a==='background'||b.dataset.tool==='text'&&a.startsWith('text:')));render()}

async function loadImageFile(file){
  if(!file)return; if(file.size>45*1024*1024){toast('Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.');}
  const img=await blobToImage(file);state.bg.blob=file;state.bg.image=img;
  fitBackground();setActive('background');scheduleSave();render();toast(`${img.naturalWidth} × ${img.naturalHeight} px importés`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight)}

canvas.addEventListener('pointerdown',e=>{
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  const obj=selectedObj();
  if(pointers.size===1){gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.x,objY:obj.y,objScale:obj.scale,objRot:obj.rotation||0}}
  else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x,objY:obj.y,objScale:obj.scale,objRot:obj.rotation||0,mid:mid(p[0],p[1])}}
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();
  if(pointers.size===1&&gesture?.mode==='one'){
    obj.x=gesture.objX+(e.clientX-gesture.startX)/getCssScale();obj.y=gesture.objY+(e.clientY-gesture.startY)/getCssScale();render();
  } else if(pointers.size===2){
    const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x,objY:obj.y,objScale:obj.scale,objRot:obj.rotation||0,mid:mid(p[0],p[1])};return}
    const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),.02,30);obj.rotation=gesture.objRot+(a-gesture.angle);obj.x=gesture.objX+(m.x-gesture.mid.x)/getCssScale();obj.y=gesture.objY+(m.y-gesture.mid.y)/getCssScale();render();
  }
});
function pointerEnd(e){pointers.delete(e.pointerId);if(pointers.size===0){gesture=null;scheduleSave()}else if(pointers.size===1){const p=[...pointers.values()][0],obj=selectedObj();gesture={mode:'one',startX:p.x,startY:p.y,objX:obj.x,objY:obj.y,objScale:obj.scale,objRot:obj.rotation||0}}}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||'Ma fresque';scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>changeRows(+e.target.value));
function changeRows(rows){
  const oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  $('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(t==='image')$('#fileInput').click();
  if(t==='move'){setActive('background');openTransformSheet()}
  if(t==='text')openTextSheet();
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#infoBtn').addEventListener('click',openInfoSheet);

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}

function openTransformSheet(){
  const o=selectedObj();const isText=state.active.startsWith('text:');const sh=openSheet(`<div class="sheethead"><div><h2>${isText?'Transformer le texte':'Cadrer l’image'}</h2><p>Le geste à deux doigts reste disponible directement sur la fresque.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Zoom</label><input id="zoom" type="range" min="20" max="500" value="${Math.round((isText?o.scale: o.scale/(state.bg.image?Math.max(WORLD_W/state.bg.image.naturalWidth,worldH()/state.bg.image.naturalHeight):1))*100)}"></div>
    <div class="field"><label>Rotation <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">Centrer</button><button class="secondary" id="resetBtn">${icon('reset')} Réinitialiser</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};
  $('#zoom',sh).oninput=e=>{if(isText)o.scale=+e.target.value/100;else if(state.bg.image)o.scale=Math.max(WORLD_W/state.bg.image.naturalWidth,worldH()/state.bg.image.naturalHeight)*(+e.target.value/100);render();scheduleSave()};
  $('#centerBtn',sh).onclick=()=>{o.x=WORLD_W/2;o.y=worldH()/2;render();scheduleSave()};
  $('#resetBtn',sh).onclick=()=>{if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else fitBackground();closeSheet();render();scheduleSave()};
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>Texte</h2><p>Ajoute le titre dans la composition plutôt que de le sacrifier aux bords des médaillons.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Calque</label><select id="textLayer"><option value="new">+ Nouveau texte</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);const box=$('#textEditor',sh);
    box.innerHTML=`<div class="field"><label>Texte</label><input id="txt" value="${escapeAttr(t?.text||'GREEN RILLETTES 7')}" maxlength="120"></div>
      <div class="grid2"><div class="field"><label>Taille</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>Contour</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div></div>
      <div class="grid2"><div class="field"><label>Couleur</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div><div class="field"><label>Contour</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?'Mettre à jour':'Ajouter'}</button>${t?`<button class="danger" id="deleteText">${icon('trash')}</button>`:''}</div>`;
    $('#saveText',box).onclick=()=>{
      if(!t){t={id:uid(),text:$('#txt',box).value||'Texte',x:WORLD_W/2,y:worldH()/2,fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,scale:1,rotation:0};state.texts.push(t)}
      else Object.assign(t,{text:$('#txt',box).value||'Texte',fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0});
      setActive('text:'+t.id);scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>{state.texts=state.texts.filter(x=>x.id!==t.id);setActive('background');scheduleSave();closeSheet();render()};
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Aperçu Prime</h2><p>Ordre et cadrage des médaillons tels qu’ils formeront la fresque.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);const k=size/TILE;const cropX=col*STEP+PAD,cropY=row*STEP+PAD;
  renderContent(cc,k,-cropX*k,-cropY*k);
}

function openExportSheet(){
  const count=state.rows*6;const sh=openSheet(`<div class="sheethead"><div><h2>Exporter ${count} missions</h2><p>PNG 512 × 512, déjà nommés dans l’ordre de création.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!state.bg.image?'<div class="rule warning"><span class="dot"></span><span>Aucune image de fond n’est chargée. Le ZIP serait d’une poésie minimaliste assez discutable.</span></div>':''}
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>6 colonnes · pas 544 px · crop 512 px · marge 16 px.</span></div><div class="rule"><span class="dot"></span><span>Mission 001 = médaillon en bas à droite.</span></div><div class="rule warning"><span class="dot"></span><span>Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent, et pas de caractère unique dominant.</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">Prêt.</div>
    <div class="actions"><button class="primary" id="doExport" ${!state.bg.image?'disabled':''}>Créer le ZIP</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh);btn.disabled=true;const zip=new JSZip();const folder=zip.folder('missions');const total=state.rows*6;
  try{
    for(let n=1;n<=total;n++){
      const {row,col}=rowColForMission(n);const c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);const blob=await canvasBlob(c,'image/png');folder.file(`${String(n).padStart(3,'0')}.png`,blob);bar.style.width=`${Math.round(n/total*82)}%`;txt.textContent=`Mission ${n}/${total}`;await tick();
    }
    const preview=makeFlatPreview();const previewBlob=await canvasBlob(preview,'image/jpeg',.9);zip.file('apercu_fresque.jpg',previewBlob);
    zip.file('ordre.txt',orderText());zip.file('projet.json',JSON.stringify(serializeState(),null,2));
    txt.textContent='Compression du ZIP…';bar.style.width='90%';
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'DEFLATE',compressionOptions:{level:6}});const filename=`${safeName(state.name)}_${total}_missions.zip`;await Filesystem.mkdir({path:'BannerForge',directory:Directory.Cache,recursive:true}).catch(()=>{});await Filesystem.writeFile({path:`BannerForge/${filename}`,data:base64,directory:Directory.Cache});const uri=await Filesystem.getUri({path:`BannerForge/${filename}`,directory:Directory.Cache});bar.style.width='100%';txt.textContent='ZIP créé.';await Share.share({title:'Export BannerForge',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:'Enregistrer ou partager le ZIP'});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}});downloadBlob(blob,`${safeName(state.name)}_${total}_missions.zip`);bar.style.width='100%';txt.textContent='ZIP téléchargé.';
    }
    toast('Export terminé');
  }catch(err){console.error(err);txt.textContent='Erreur : '+(err?.message||err);toast('L’export a échoué.');}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);renderContent(cc,w/WORLD_W);return c}
function orderText(){let s=`BannerForge v${APP_VERSION}\n${state.name}\n${state.rows} rangée(s) · ${state.rows*6} missions\n\nOrdre de création :\n`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);s+=`${String(n).padStart(3,'0')}.png : rangée ${row+1} depuis le haut, colonne ${col+1} depuis la gauche\n`}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise(r=>c.toBlob(r,type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>BannerForge</h2><p>Version ${APP_VERSION} · éditeur non officiel.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span><b>Moteur Prime :</b> 6 colonnes, 544 px par cellule, zone utile 512 × 512 centrée avec 16 px de marge.</span></div><div class="rule"><span class="dot"></span><span><b>Local :</b> les images restent sur l’appareil. Le projet courant est sauvegardé automatiquement.</span></div><div class="rule"><span class="dot"></span><span><b>Gestes :</b> un doigt déplace le calque actif, deux doigts zooment et tournent.</span></div><div class="rule warning"><span class="dot"></span><span>Ingress et Ingress Prime sont des marques de Niantic. BannerForge n’est ni affilié ni approuvé par Niantic.</span></div></div>
    <div class="actions"><button class="danger" id="newProject">Nouveau projet</button></div>`);$('.close',sh).onclick=closeSheet;$('#newProject',sh).onclick=()=>resetProject();
}
function resetProject(){state.name='Ma fresque';state.rows=3;state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0};state.texts=[];state.active='background';$('#projectName').value=state.name;$('#rowsSelect').value='3';$('#missionCount').textContent='18';$('#worldH').textContent=1632;closeSheet();resizeCanvas();saveProject();toast('Nouveau projet créé')}

function serializeState(){return {version:APP_VERSION,name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation},texts:state.texts,updatedAt:new Date().toISOString()}}
function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,500)}
async function saveProject(){try{const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').put({id:'current',data:serializeState(),blob:state.bg.blob});await txDone(tx)}catch(e){console.warn('save',e)}}
async function loadProject(){try{const db=await openDB();const tx=db.transaction('project','readonly');const rec=await request(tx.objectStore('project').get('current'));if(!rec)return;Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,texts:rec.data.texts||[]});Object.assign(state.bg,rec.data.bg||{});if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}$('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();resizeCanvas()}catch(e){console.warn('load',e)}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('bannerforge',1);r.onupgradeneeded=()=>r.result.createObjectStore('project',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

window.addEventListener('resize',render);
if('serviceWorker' in navigator && !Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();loadProject();
