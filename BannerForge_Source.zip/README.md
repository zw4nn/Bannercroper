# BannerForge 0.3.0

Éditeur mobile-first de fresques de missions Ingress Prime, non officiel.

## Nouveautés 0.3.0

- Nouvelle icône native Android extraite de la photo de Redacted fournie par l'utilisateur.
- Les ressources Android remplacent à la fois les icônes `mipmap` et le foreground `drawable` de Capacitor pour éviter le retour du logo Capacitor sur certains launchers.
- Gestion de plusieurs projets locaux.
- Chaque projet peut être nommé, renommé, ouvert, copié et supprimé.
- Le projet ouvert est mémorisé et chaque projet garde sa propre image, ses textes et ses recadrages mission par mission.
- Export ZIP nettement accéléré : les PNG, déjà compressés, ne sont plus recompressés en DEFLATE. Rendu par lots de 4 missions et assemblage `STORE`.

## Signature Android stable

Ne jamais remplacer `signing/bannerforge-debug.keystore`.

SHA-256 du fichier keystore :
`1b7cc0b63572f546cd2998e7be7e09ed9ae24b5a75e3f89be5d0f18f6d34b30a`

SHA-256 du certificat attendu :
`DC:BD:F2:49:EC:D4:51:40:A2:B7:94:0E:A0:86:64:30:E1:FA:73:EC:2A:0A:18:8A:43:27:85:F6:3B:95:98:5B`

## Compilation GitHub

Conserver `BannerForge_Source.zip` à la racine du dépôt et le workflow actuel dans `.github/workflows/build-bannerforge.yml`.

Il suffit de remplacer le ZIP puis de relancer l'Action. Le YAML de la v0.2.1 reste compatible avec cette version.

Ingress et Ingress Prime sont des marques de Niantic. BannerForge n'est ni affilié ni approuvé par Niantic.
