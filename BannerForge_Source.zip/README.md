# BannerForge 0.1.0

Éditeur mobile-first de fresques de missions Ingress Prime, non officiel.

## Fonctions de la v0.1

- 1 à 25 rangées, toujours 6 colonnes.
- Géométrie intégrée : cellule 544 px, crop 512 x 512, marge 16 px.
- Import PNG/JPEG/WebP.
- Déplacement à un doigt, zoom + rotation à deux doigts.
- Aperçu des cercles Prime et numérotation des missions.
- Texte superposé avec couleur, contour, taille, déplacement, zoom et rotation.
- Sauvegarde locale automatique via IndexedDB.
- Export ZIP avec chaque mission en PNG 512 x 512, aperçu JPG, ordre.txt et projet.json.
- Fonctionne aussi comme site web/PWA.

## Compiler l'APK avec GitHub

1. Créer un dépôt GitHub vide.
2. Envoyer **tout le contenu de ce ZIP à la racine du dépôt**, y compris le dossier `.github`.
3. Ouvrir l'onglet **Actions** du dépôt.
4. Lancer le workflow **Build Android APK** avec `Run workflow`, ou simplement faire un commit sur `main`.
5. À la fin du job, télécharger l'artifact **BannerForge-debug-apk**.
6. Le fichier installable est `app-debug.apk`.

## Mises à jour Android

Le dépôt contient `signing/bannerforge-debug.keystore`. Le workflow le copie comme clé debug Android avant la compilation. **Ne supprime pas et ne remplace pas ce fichier** si tu veux que les prochains APK puissent être installés comme mises à jour par-dessus la version existante.

Cette clé est volontairement une clé de développement. Pour une publication Play Store, il faudra utiliser une vraie clé de release conservée dans les GitHub Secrets.

## Lancer comme site en local

```bash
npm install
npm run dev
```

Build web :

```bash
npm run build
```

Le site compilé est dans `dist/`.

## Identité Android

- App ID : `com.bannerforge.mobile`
- Nom : `BannerForge`
- Version : `0.1.0`

Ingress et Ingress Prime sont des marques de Niantic. BannerForge est un outil non officiel et n'est ni affilié ni approuvé par Niantic.
