# BannerForge 0.2.0

Éditeur mobile-first de fresques de missions Ingress Prime, non officiel.

## Nouveautés 0.2.0

- Correction des zones sûres Android : le contenu tient compte de la barre d'état et de la barre de navigation via les insets SystemBars de Capacitor 8.
- Nouveau logo Redacted à partir de la référence fournie par l'utilisateur.
- Suppression d'un texte directement depuis son panneau de transformation ou depuis l'éditeur de texte.
- Nouveau mode **Une mission** : toucher un médaillon permet de déplacer, zoomer et tourner uniquement cette mission sans modifier les autres.
- Bouton de remise à zéro du recadrage individuel.
- Les recadrages individuels sont conservés dans la sauvegarde locale et appliqués à l'aperçu et à l'export PNG.

## Fonctions générales

- 1 à 25 rangées, toujours 6 colonnes.
- Géométrie : cellule 544 px, crop 512 × 512, marge 16 px.
- Import PNG/JPEG/WebP.
- Déplacement à un doigt, zoom + rotation à deux doigts.
- Cercles Prime, grille et numérotation.
- Calques texte indépendants.
- Sauvegarde locale via IndexedDB.
- Export ZIP : PNG 512 × 512 + aperçu + ordre.txt + projet.json.

## Compilation GitHub depuis un ZIP

Le workflow externe `build-bannerforge.yml` reste compatible : le dépôt peut conserver `BannerForge_Source.zip` à la racine et le YAML dans `.github/workflows/`.

La clé `signing/bannerforge-debug.keystore` est inchangée afin de conserver la compatibilité des mises à jour Android.

Ingress et Ingress Prime sont des marques de Niantic. BannerForge n'est ni affilié ni approuvé par Niantic.
