# BannerForge 0.2.1

Éditeur mobile-first de fresques de missions Ingress Prime, non officiel.

## Correctifs 0.2.1

- Le logo Android natif utilise désormais la tête de Redacted, et pas l’icône Capacitor par défaut.
- Les ressources `mipmap-*` Android sont fournies dans `android-res/` puis copiées après `npx cap add android`.
- La signature de l’APK est maintenant FORCÉE après compilation avec `signing/bannerforge-debug.keystore`.
- Le workflow vérifie le certificat final et échoue si l’APK n’utilise pas la clé stable attendue.
- La clé stable est strictement la même que celle déjà fournie dans les sources précédentes.

## Empreinte de la clé stable

SHA-256 certificat :
`DC:BD:F2:49:EC:D4:51:40:A2:B7:94:0E:A0:86:64:30:E1:FA:73:EC:2A:0A:18:8A:43:27:85:F6:3B:95:98:5B`

Cette clé ne doit plus jamais être régénérée.

## Fonctions 0.2.x

- 1 à 25 rangées, 6 colonnes.
- Cellule 544 px, crop 512×512, marge 16 px.
- Import PNG/JPEG/WebP.
- Déplacement, zoom et rotation tactiles.
- Cercles Prime, grille et numérotation.
- Calques texte supprimables.
- Mode `Une mission` avec recadrage indépendant.
- Sauvegarde locale IndexedDB.
- Export ZIP des PNG 512×512.

Ingress et Ingress Prime sont des marques de Niantic. BannerForge n’est ni affilié ni approuvé par Niantic.
