# Redacted BannerLab 1.0.15.16 TEST · build 11517

## Arcade
- Tous les mini-jeux proposent désormais **ENL ou RES** avant le départ.
- Les éléments **Machina rouges** restent les ennemis communs aux deux factions.
- Tous les jeux proposent **Arcade** ou **Entraînement**.
- Mode Arcade : chrono de base, combos qui rendent du temps, pénalités et records.
- Mode Entraînement : pas de limite de temps et pas d’enregistrement de record.
- Portal Blaster démarre plus doucement ; la difficulté progresse davantage par les PV/patterns que par une pluie d’ennemis.
- Portal Panic utilise une grille contrainte pour éviter les cercles coupés hors de l’arène sur écrans mobiles.

- Lab Memory transforme les cartes Machina rouges en pièges : elles coûtent du temps et ne constituent plus une paire à terminer.

## Accueil
- La recherche Bannergress devient l’action centrale et pleine largeur du header.
- Branding Redacted BannerLab + logo regroupé et centré au-dessus, version affichée discrètement.
- Le projet actif est affiché juste sous la recherche et ouvre la liste des projets au toucher.
