package com.bannerforge.mobile;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "MissionOverlay")
public class MissionOverlayPlugin extends Plugin {
    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(getContext());
    }

    @PluginMethod
    public void hasPermission(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", canOverlay());
        call.resolve(ret);
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        if (canOverlay()) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        Intent intent = new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getContext().getPackageName())
        );
        getActivity().startActivity(intent);
        JSObject ret = new JSObject();
        ret.put("granted", false);
        ret.put("openedSettings", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void start(PluginCall call) {
        if (!canOverlay()) {
            call.reject("Overlay permission not granted");
            return;
        }
        String sessionJson = call.getString("sessionJson");
        if (sessionJson == null || sessionJson.trim().isEmpty()) {
            call.reject("Missing sessionJson");
            return;
        }
        Intent intent = new Intent(getContext(), MissionOverlayService.class);
        intent.setAction(MissionOverlayService.ACTION_START);
        intent.putExtra(MissionOverlayService.EXTRA_SESSION, sessionJson);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject();
        ret.put("started", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent intent = new Intent(getContext(), MissionOverlayService.class);
        intent.setAction(MissionOverlayService.ACTION_STOP);
        getContext().startService(intent);
        JSObject ret = new JSObject();
        ret.put("stopped", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void getState(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences(MissionOverlayService.PREFS, Context.MODE_PRIVATE);
        JSObject ret = new JSObject();
        ret.put("active", p.getBoolean("active", false));
        ret.put("bannerId", p.getString("bannerId", ""));
        ret.put("bannerTitle", p.getString("bannerTitle", ""));
        ret.put("currentIndex", p.getInt("currentIndex", 0));
        ret.put("total", p.getInt("total", 0));
        ret.put("missionTitle", p.getString("missionTitle", ""));
        ret.put("doneJson", p.getString("doneJson", "[]"));
        ret.put("sessionJson", p.getString("sessionJson", ""));
        ret.put("startedAt", p.getLong("startedAt", 0L));
        ret.put("finishedAt", p.getLong("finishedAt", 0L));
        ret.put("pausedAt", p.getLong("pausedAt", 0L));
        ret.put("pausedTotal", p.getLong("pausedTotal", 0L));
        ret.put("paused", p.getBoolean("paused", false));
        call.resolve(ret);
    }
}
