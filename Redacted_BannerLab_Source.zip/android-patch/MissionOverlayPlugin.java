package com.bannerforge.mobile;

import android.Manifest;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "MissionOverlay")
public class MissionOverlayPlugin extends Plugin {
    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(getContext());
    }

    @PluginMethod
    public void hasPermission(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", canOverlay());
        call.resolve(ret);
    }

    /**
     * Step 1 for sideloaded APKs on Android versions/devices that protect
     * "restricted settings". Android exposes no public API that tells us whether
     * the user has enabled that menu item, so RBL opens its own application
     * details page and explains the manual ⋮ -> Allow restricted settings step.
     */
    @PluginMethod
    public void openRestrictedSettings(PluginCall call) {
        try {
            Intent intent = new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getContext().getPackageName())
            );
            startActivityForResult(call, intent, "restrictedSettingsReturned");
        } catch (Exception e) {
            call.reject("Unable to open application settings", e);
        }
    }

    @ActivityCallback
    private void restrictedSettingsReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        ret.put("returned", true);
        ret.put("granted", canOverlay());
        call.resolve(ret);
    }

    /**
     * Step 2: request the actual "display over other apps" permission.
     * Resolve only after the user comes back from Android Settings.
     */
    @PluginMethod
    public void requestPermission(PluginCall call) {
        if (canOverlay()) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }

        try {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getContext().getPackageName())
            );
            startActivityForResult(call, intent, "overlayPermissionReturned");
        } catch (Exception e) {
            call.reject("Unable to open overlay settings", e);
        }
    }

    @ActivityCallback
    private void overlayPermissionReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        ret.put("returned", true);
        ret.put("granted", canOverlay());
        call.resolve(ret);
    }

    @PluginMethod
    public void start(PluginCall call) {
        if (!canOverlay()) {
            call.reject("Overlay permission not granted");
            return;
        }
        String sessionJson = call.getString("sessionJson");
        if (sessionJson == null || sessionJson.trim().isEmpty()) {
            call.reject("Missing sessionJson");
            return;
        }
        Intent intent = new Intent(getContext(), MissionOverlayService.class);
        intent.setAction(MissionOverlayService.ACTION_START);
        intent.putExtra(MissionOverlayService.EXTRA_SESSION, sessionJson);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject();
        ret.put("started", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent intent = new Intent(getContext(), MissionOverlayService.class);
        intent.setAction(MissionOverlayService.ACTION_STOP);
        getContext().startService(intent);
        JSObject ret = new JSObject();
        ret.put("stopped", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void startRedacted(PluginCall call) {
        if (!canOverlay()) {
            call.reject("Overlay permission not granted");
            return;
        }
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        intent.setAction(RedactedOverlayService.ACTION_START);
        String state = call.getString("state", "MAP");
        String faction = call.getString("faction", getContext().getSharedPreferences(RedactedOverlayService.PREFS, Context.MODE_PRIVATE).getString("faction", "ENL"));
        intent.putExtra(RedactedOverlayService.EXTRA_STATE, state);
        intent.putExtra(RedactedOverlayService.EXTRA_FACTION, faction);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject();
        ret.put("started", true);
        ret.put("state", state);
        call.resolve(ret);
    }

    @PluginMethod
    public void startRedactedCalibration(PluginCall call) {
        if (!canOverlay()) {
            call.reject("Overlay permission not granted");
            return;
        }
        String state = call.getString("state", "MAP");
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        intent.setAction(RedactedOverlayService.ACTION_CALIBRATE);
        String faction = call.getString("faction", getContext().getSharedPreferences(RedactedOverlayService.PREFS, Context.MODE_PRIVATE).getString("faction", "ENL"));
        intent.putExtra(RedactedOverlayService.EXTRA_STATE, state);
        intent.putExtra(RedactedOverlayService.EXTRA_FACTION, faction);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject();
        ret.put("started", true);
        ret.put("state", state);
        call.resolve(ret);
    }


    @PluginMethod
    public void configureRedactedSelection(PluginCall call) {
        if (!canOverlay()) { call.reject("Overlay permission not granted"); return; }
        String components = call.getString("components", "neon,sensorProfile,sensorAction,sensorProfileBack,sensorInventoryBack,sensorAttackBack,visualRedacted,visualIgor,visualMilo,visualLeon");
        String faction = call.getString("faction", getContext().getSharedPreferences(RedactedOverlayService.PREFS, Context.MODE_PRIVATE).getString("faction", "ENL"));
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        intent.setAction(RedactedOverlayService.ACTION_CONFIGURE_SELECTION);
        intent.putExtra(RedactedOverlayService.EXTRA_COMPONENTS, components);
        intent.putExtra(RedactedOverlayService.EXTRA_FACTION, faction);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject();
        ret.put("started", true);
        ret.put("components", components);
        call.resolve(ret);
    }

    @PluginMethod
    public void setRedactedState(PluginCall call) {
        if (!canOverlay()) { call.reject("Overlay permission not granted"); return; }
        String state = call.getString("state", "MAP");
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        intent.setAction(RedactedOverlayService.ACTION_SET_STATE);
        intent.putExtra(RedactedOverlayService.EXTRA_STATE, state);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject(); ret.put("state", state); call.resolve(ret);
    }

    @PluginMethod
    public void setRedactedFaction(PluginCall call) {
        if (!canOverlay()) { call.reject("Overlay permission not granted"); return; }
        String faction = call.getString("faction", "ENL");
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        intent.setAction(RedactedOverlayService.ACTION_SET_FACTION);
        intent.putExtra(RedactedOverlayService.EXTRA_FACTION, faction);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject ret = new JSObject(); ret.put("faction", faction); call.resolve(ret);
    }

    @PluginMethod
    public void resetRedactedCalibration(PluginCall call) {
        RedactedOverlayService.resetCalibration(getContext());
        JSObject ret = new JSObject(); ret.put("reset", true); call.resolve(ret);
    }

    private boolean hasAccessibilityAccessInternal() {
        try {
            String enabled = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String full = getContext().getPackageName() + "/com.bannerforge.mobile.PrimeOverlayAccessibilityService";
            return enabled.toLowerCase(java.util.Locale.ROOT).contains(full.toLowerCase(java.util.Locale.ROOT));
        } catch (Exception e) { return false; }
    }

    @PluginMethod
    public void hasAccessibilityAccess(PluginCall call) {
        JSObject ret = new JSObject(); ret.put("granted", hasAccessibilityAccessInternal()); call.resolve(ret);
    }

    @PluginMethod
    public void requestAccessibilityAccess(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivityForResult(call, intent, "accessibilitySettingsReturned");
        } catch (Exception e) { call.reject("Unable to open accessibility settings", e); }
    }

    @ActivityCallback
    private void accessibilitySettingsReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject(); ret.put("granted", hasAccessibilityAccessInternal()); call.resolve(ret);
    }

    @PluginMethod
    public void stopRedacted(PluginCall call) {
        Intent intent = new Intent(getContext(), RedactedOverlayService.class);
        boolean stopped = getContext().stopService(intent);
        JSObject ret = new JSObject();
        ret.put("stopped", stopped);
        call.resolve(ret);
    }

    @PluginMethod
    public void getRedactedState(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences(RedactedOverlayService.PREFS, Context.MODE_PRIVATE);
        JSObject ret = new JSObject();
        ret.put("active", p.getBoolean("active", false));
        ret.put("calibrating", p.getBoolean("calibrating", false));
        ret.put("state", p.getString("state", "MAP"));
        ret.put("faction", p.getString("faction", "ENL"));
        ret.put("accessibility", hasAccessibilityAccessInternal());
        ret.put("usageAccess", hasUsageAccessInternal());
        ret.put("calibratedMAP", p.getBoolean("calibrated_MAP", false));
        ret.put("calibratedPROFILE", p.getBoolean("calibrated_PROFILE", false));
        ret.put("calibratedINVENTORY", p.getBoolean("calibrated_INVENTORY", false));
        ret.put("calibratedATTACK", p.getBoolean("calibrated_ATTACK", false));
        for (String c : new String[]{"neon","sensorProfile","sensorAction","sensorProfileBack","sensorInventoryBack","sensorAttackBack","visualRedacted","visualIgor","visualMilo","visualLeon","visualStateBeacon","visualPulse","visualSecret","visualCrosshair","visualScanline","visualCode","visualCorner","visualTubeH","visualTubeV","visualLiquidTube","visualCable","visualCableCoil","visualScreen","visualTerminal","visualCalculator","visualScope","visualGauge","visualSegments","visualRadar","visualBattery","visualWarning","visualVent","visualAntenna","visualData","visualReactor","visualBolts"}) {
            ret.put("enabled_" + c, p.getBoolean("enabled_component_" + c, true));
            ret.put("calibrated_" + c, p.getBoolean("calibrated_component_" + c, false));
        }
        call.resolve(ret);
    }


    private boolean hasUsageAccessInternal() {
        try {
            AppOpsManager appOps = (AppOpsManager) getContext().getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getContext().getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    @PluginMethod
    public void hasUsageAccess(PluginCall call) {
        JSObject ret = new JSObject(); ret.put("granted", hasUsageAccessInternal()); call.resolve(ret);
    }

    @PluginMethod
    public void requestUsageAccess(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            startActivityForResult(call, intent, "usageAccessReturned");
        } catch (Exception e) { call.reject("Unable to open usage access settings", e); }
    }

    @ActivityCallback
    private void usageAccessReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject(); ret.put("returned", true); ret.put("granted", hasUsageAccessInternal()); call.resolve(ret);
    }

    private boolean hasNotificationPermissionInternal() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void hasNotificationPermission(PluginCall call) {
        JSObject ret = new JSObject(); ret.put("granted", hasNotificationPermissionInternal()); call.resolve(ret);
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (hasNotificationPermissionInternal()) {
            JSObject ret = new JSObject(); ret.put("granted", true); call.resolve(ret); return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            startActivityForResult(call, intent, "notificationSettingsReturned");
        } catch (Exception e) { call.reject("Unable to open notification settings", e); }
    }

    @ActivityCallback
    private void notificationSettingsReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject(); ret.put("granted", hasNotificationPermissionInternal()); call.resolve(ret);
    }

    private boolean hasActiveNativeTimer(String timersJson) {
        try {
            org.json.JSONArray arr = new org.json.JSONArray(timersJson == null ? "[]" : timersJson);
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                boolean overlay = o.optBoolean("overlay", true);
                boolean runningNotify = o.optBoolean("running", false) && o.optBoolean("notify", true);
                if (overlay || runningNotify) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @PluginMethod
    public void syncTimers(PluginCall call) {
        String timersJson = call.getString("timersJson", "[]");
        Intent intent = new Intent(getContext(), TimerOverlayService.class);
        if (!hasActiveNativeTimer(timersJson)) {
            // TEST-40: an idle timer may legitimately keep the foreground service alive when its overlay is visible.
            // If no overlay exists and no running notification timer exists, do not start the service at all.
            getContext().stopService(intent);
            JSObject ret = new JSObject(); ret.put("synced", true); ret.put("active", false); call.resolve(ret);
            return;
        }
        intent.setAction(TimerOverlayService.ACTION_SYNC);
        intent.putExtra(TimerOverlayService.EXTRA_TIMERS, timersJson);
        try {
            ContextCompat.startForegroundService(getContext(), intent);
            JSObject ret = new JSObject(); ret.put("synced", true); ret.put("active", true); call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to start LEON timer service", e);
        }
    }

    @PluginMethod
    public void stopTimers(PluginCall call) {
        Intent intent = new Intent(getContext(), TimerOverlayService.class);
        boolean stopped = getContext().stopService(intent);
        JSObject ret = new JSObject(); ret.put("stopped", stopped); call.resolve(ret);
    }

    @PluginMethod
    public void getTimerState(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences(TimerOverlayService.PREFS, Context.MODE_PRIVATE);
        JSObject ret = new JSObject(); ret.put("active", p.getBoolean("active", false)); ret.put("timersJson", p.getString("timersJson", "[]")); call.resolve(ret);
    }

    @PluginMethod
    public void openIngress(PluginCall call) {
        try {
            Intent launch = getContext().getPackageManager().getLaunchIntentForPackage("com.nianticproject.ingress");
            if (launch == null) { call.reject("Ingress Prime not installed"); return; }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            getContext().startActivity(launch);
            JSObject ret = new JSObject(); ret.put("opened", true); call.resolve(ret);
        } catch (Exception e) { call.reject("Unable to open Ingress Prime", e); }
    }

    @PluginMethod
    public void getState(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences(MissionOverlayService.PREFS, Context.MODE_PRIVATE);
        JSObject ret = new JSObject();
        ret.put("active", p.getBoolean("active", false));
        ret.put("bannerId", p.getString("bannerId", ""));
        ret.put("bannerTitle", p.getString("bannerTitle", ""));
        ret.put("currentIndex", p.getInt("currentIndex", 0));
        ret.put("total", p.getInt("total", 0));
        ret.put("missionTitle", p.getString("missionTitle", ""));
        ret.put("doneJson", p.getString("doneJson", "[]"));
        ret.put("sessionJson", p.getString("sessionJson", ""));
        ret.put("startedAt", p.getLong("startedAt", 0L));
        ret.put("finishedAt", p.getLong("finishedAt", 0L));
        ret.put("pausedAt", p.getLong("pausedAt", 0L));
        ret.put("pausedTotal", p.getLong("pausedTotal", 0L));
        ret.put("paused", p.getBoolean("paused", false));
        call.resolve(ret);
    }
}
