package com.bannerforge.mobile;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import org.json.*;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class RblOverlayService extends Service {
    private static final int NOTIF_ID = 9090;
    private static final String CHANNEL = "rbl_overlay";
    private WindowManager wm;
    private View overlay;
    private WindowManager.LayoutParams params;
    private JSONObject session;
    private JSONArray missions;
    private int current = 0;
    private boolean minimized = false;
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("rbl_overlay", MODE_PRIVATE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "com.bannerforge.mobile.RBL_OVERLAY_STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIF_ID, notification());
        loadSession();
        if (session == null || missions == null || missions.length() == 0) {
            stopSelf();
            return START_NOT_STICKY;
        }
        showOverlay();
        boolean autoOpen = session.optBoolean("autoOpen", false);
        if (autoOpen) {
            session.remove("autoOpen");
            saveState();
            new android.os.Handler(getMainLooper()).postDelayed(this::openCurrentMission, 450);
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "RBL mission overlay", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Overlay Redacted BannerLab pendant une bannière Ingress");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent close = new Intent(this, RblOverlayService.class);
        close.setAction("com.bannerforge.mobile.RBL_OVERLAY_STOP");
        PendingIntent pclose = PendingIntent.getService(this, 44, close, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(getApplicationInfo().icon)
         .setContentTitle("Redacted BannerLab")
         .setContentText(session == null ? "Overlay mission actif" : session.optString("title","Overlay mission actif"))
         .setOngoing(true)
         .addAction(new Notification.Action.Builder(null, "Fermer", pclose).build());
        return b.build();
    }

    private void loadSession() {
        try {
            File f = new File(getCacheDir(), "RedactedBannerLab/play-session.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[8192]; int n;
                while ((n=in.read(buf))!=-1) out.write(buf,0,n);
            }
            session = new JSONObject(out.toString("UTF-8"));
            missions = session.optJSONArray("missions");
            String bannerId = session.optString("bannerId","");
            int requested = session.optInt("current",0);
            String storedBanner = prefs.getString("bannerId","");
            current = bannerId.equals(storedBanner) ? prefs.getInt("current",requested) : requested;
            current = Math.max(0, Math.min(missions.length()-1,current));
            prefs.edit().putString("bannerId",bannerId).putInt("current",current).apply();
        } catch (Exception e) {
            session = null; missions = null;
        }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }
    private TextView text(String value, int sp, boolean bold) {
        TextView v=new TextView(this);v.setText(value);v.setTextColor(Color.WHITE);v.setTextSize(sp);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private Button button(String value) {
        Button b=new Button(this);b.setText(value);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(16,41,27),10,Color.rgb(46,104,68)));
        b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(10),dp(7),dp(10),dp(7));return b;
    }

    private void showOverlay() {
        removeOverlay();
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            minimized ? dp(74) : dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = prefs.getInt("x", dp(18));
        params.y = prefs.getInt("y", dp(180));
        overlay = minimized ? buildBubble() : buildPanel();
        wm.addView(overlay, params);
    }

    private View buildBubble() {
        FrameLayout root=new FrameLayout(this);root.setBackground(bg(Color.rgb(7,21,14),36,Color.rgb(49,237,131)));
        ImageView logo=new ImageView(this);logo.setImageResource(com.bannerforge.mobile.R.drawable.redacted_bannerlab_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(62),dp(62),Gravity.CENTER);root.addView(logo,ip);
        TextView count=text((current+1)+"/"+missions.length(),9,true);count.setGravity(Gravity.CENTER);count.setBackground(bg(Color.argb(225,7,21,14),9,Color.rgb(49,237,131)));
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(42),dp(20),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);cp.bottomMargin=dp(2);root.addView(count,cp);
        root.setOnClickListener(v->{minimized=false;showOverlay();});
        attachDrag(root);
        return root;
    }

    private View buildPanel() {
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(9),dp(9),dp(9),dp(9));
        root.setBackground(bg(Color.rgb(7,21,14),16,Color.rgb(49,237,131)));

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(com.bannerforge.mobile.R.drawable.redacted_bannerlab_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        head.addView(logo,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(8),0,dp(5),0);
        TextView title=text(session.optString("title","Redacted BannerLab"),12,true);title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView progress=text("Mission "+(current+1)+" / "+missions.length(),10,false);progress.setTextColor(Color.rgb(143,190,158));
        copy.addView(title);copy.addView(progress);head.addView(copy,new LinearLayout.LayoutParams(0,dp(44),1));
        Button mini=button("—");mini.setOnClickListener(v->{minimized=true;showOverlay();});head.addView(mini,new LinearLayout.LayoutParams(dp(40),dp(38)));
        root.addView(head);
        attachDrag(head);

        JSONObject m=missions.optJSONObject(current);
        TextView mt=text(m==null?"Mission":m.optString("title","Mission"),11,true);mt.setPadding(dp(2),dp(7),dp(2),dp(6));mt.setMaxLines(2);root.addView(mt);

        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(0,dp(2),0,0);
        Button prev=button("‹");prev.setEnabled(current>0);prev.setAlpha(current>0?1f:.35f);prev.setOnClickListener(v->{if(current>0){current--;saveState();showOverlay();}});
        Button open=button("▶ Ouvrir");open.setBackground(bg(Color.rgb(49,237,131),10,0));open.setTextColor(Color.rgb(5,22,12));open.setTypeface(Typeface.DEFAULT,Typeface.BOLD);open.setOnClickListener(v->openCurrentMission());
        Button next=button("›");next.setEnabled(current<missions.length()-1);next.setAlpha(current<missions.length()-1?1f:.35f);next.setOnClickListener(v->{if(current<missions.length()-1){current++;saveState();showOverlay();}});
        nav.addView(prev,new LinearLayout.LayoutParams(dp(54),dp(42)));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(42),1);op.setMargins(dp(6),0,dp(6),0);nav.addView(open,op);
        nav.addView(next,new LinearLayout.LayoutParams(dp(54),dp(42)));
        root.addView(nav);

        LinearLayout foot=new LinearLayout(this);foot.setGravity(Gravity.CENTER);
        Button close=button("Fermer l’overlay");close.setTextSize(9);close.setOnClickListener(v->stopSelf());
        foot.addView(close,new LinearLayout.LayoutParams(-1,dp(35)));root.addView(foot);
        return root;
    }

    private void attachDrag(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            int sx,sy;float tx,ty;boolean moved;
            @Override public boolean onTouch(View view, android.view.MotionEvent e) {
                switch(e.getAction()){
                    case android.view.MotionEvent.ACTION_DOWN:
                        sx=params.x;sy=params.y;tx=e.getRawX();ty=e.getRawY();moved=false;return false;
                    case android.view.MotionEvent.ACTION_MOVE:
                        int nx=sx+(int)(e.getRawX()-tx),ny=sy+(int)(e.getRawY()-ty);
                        if(Math.abs(nx-sx)>4||Math.abs(ny-sy)>4)moved=true;
                        params.x=nx;params.y=ny;try{wm.updateViewLayout(overlay,params);}catch(Exception ignored){}return true;
                    case android.view.MotionEvent.ACTION_UP:
                        prefs.edit().putInt("x",params.x).putInt("y",params.y).apply();return moved;
                }
                return false;
            }
        });
    }

    private void openCurrentMission() {
        try {
            JSONObject m=missions.getJSONObject(current);
            String id=m.optString("id","");
            if(id.isEmpty())return;
            String intel="https://intel.ingress.com/mission/"+URLEncoder.encode(id,"UTF-8");
            String url="https://link.ingress.com/?link="+URLEncoder.encode(intel,"UTF-8")+
                "&apn=com.nianticproject.ingress&isi=576505181&ibi=com.google.ingress"+
                "&ifl="+URLEncoder.encode("https://apps.apple.com/app/ingress/id576505181","UTF-8")+
                "&ofl="+URLEncoder.encode(intel,"UTF-8");
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch(Exception ignored) {}
    }

    private void saveState() {
        try {
            session.put("current",current);
            prefs.edit().putInt("current",current).apply();
            File dir=new File(getCacheDir(),"RedactedBannerLab");dir.mkdirs();
            try(OutputStream out=new FileOutputStream(new File(dir,"play-state.json"))){
                out.write(session.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch(Exception ignored) {}
    }

    private void removeOverlay() {
        if(overlay!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}
    }

    @Override public void onDestroy(){saveState();removeOverlay();super.onDestroy();}
}
