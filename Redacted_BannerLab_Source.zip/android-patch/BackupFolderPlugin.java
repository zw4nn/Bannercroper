package com.bannerforge.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name = "BackupFolder")
public class BackupFolderPlugin extends Plugin {
    private static final String PREFS = "redacted_bannerlab_backup";
    private static final String KEY_URI = "folder_uri";

    private android.content.SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private Uri configuredUri() {
        String raw = prefs().getString(KEY_URI, "");
        if (raw == null || raw.isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Exception e) { return null; }
    }

    private String folderLabel(Uri treeUri) {
        if (treeUri == null) return "";
        try {
            ContentResolver resolver = getContext().getContentResolver();
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
            try (Cursor c = resolver.query(docUri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {}
        String last = treeUri.getLastPathSegment();
        return last == null ? treeUri.toString() : Uri.decode(last).replace("primary:", "Stockage/");
    }

    private JSObject folderResult(Uri uri) {
        JSObject ret = new JSObject();
        ret.put("configured", uri != null);
        ret.put("uri", uri == null ? "" : uri.toString());
        ret.put("label", folderLabel(uri));
        return ret;
    }

    @PluginMethod
    public void getFolder(PluginCall call) {
        call.resolve(folderResult(configuredUri()));
    }

    @PluginMethod
    public void chooseFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "folderPicked");
    }

    @ActivityCallback
    private void folderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.resolve(folderResult(configuredUri()));
            return;
        }
        Uri uri = result.getData().getData();
        int flags = result.getData().getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException ignored) {}
        prefs().edit().putString(KEY_URI, uri.toString()).apply();
        call.resolve(folderResult(uri));
    }

    private Uri findChild(ContentResolver resolver, Uri treeUri, String fileName) throws Exception {
        String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId);
        String[] projection = new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    if (fileName.equals(name)) return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                }
            }
        }
        return null;
    }

    @PluginMethod
    public void writeTextFile(PluginCall call) {
        Uri treeUri = configuredUri();
        if (treeUri == null) {
            call.reject("No backup folder configured");
            return;
        }
        String fileName = call.getString("fileName", "Redacted_BannerLab_Autosave.json");
        String text = call.getString("text");
        if (text == null) {
            call.reject("Missing text");
            return;
        }
        fileName = fileName.replace("/", "_").replace("\\", "_");
        try {
            ContentResolver resolver = getContext().getContentResolver();
            Uri target = findChild(resolver, treeUri, fileName);
            if (target == null) {
                String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId);
                target = DocumentsContract.createDocument(resolver, parent, "application/json", fileName);
            }
            if (target == null) throw new IllegalStateException("Unable to create backup file");
            try (OutputStream out = resolver.openOutputStream(target, "wt")) {
                if (out == null) throw new IllegalStateException("Unable to open backup file");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            JSObject ret = new JSObject();
            ret.put("written", true);
            ret.put("fileName", fileName);
            ret.put("uri", target.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to write backup: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearFolder(PluginCall call) {
        Uri uri = configuredUri();
        if (uri != null) {
            try {
                getContext().getContentResolver().releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
            } catch (Exception ignored) {}
        }
        prefs().edit().remove(KEY_URI).apply();
        call.resolve(folderResult(null));
    }
}
