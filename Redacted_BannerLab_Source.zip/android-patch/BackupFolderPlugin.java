package com.bannerforge.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;

import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@CapacitorPlugin(name = "BackupFolder")
public class BackupFolderPlugin extends Plugin {
    private static final String PREFS = "redacted_bannerlab_backup";
    private static final String KEY_URI = "folder_uri";
    private static final String KEY_IITC_TREE_URI = "iitc_tree_uri";
    private static final String IITC_ASSET = "public/redacted-bannerlab-iitc.user.js";
    private static final int IITC_MIN_BYTES = 1024;
    private static final String IITC_CANONICAL_FILE = "redacted-bannerlab-iitc.user.js";

    private byte[] bundledIitcBytes() throws IOException {
        try (InputStream in = getContext().getAssets().open(IITC_ASSET);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            byte[] data = out.toByteArray();
            if (data.length < IITC_MIN_BYTES) {
                throw new IOException("Bundled IITC plugin is unexpectedly small: " + data.length + " bytes");
            }
            return data;
        }
    }

    private void writeBytesToUri(Uri uri, byte[] data) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        OutputStream out = null;
        try {
            // rwt = write + truncate. Some document providers reject it, so fall back to w.
            try { out = resolver.openOutputStream(uri, "rwt"); } catch (Exception ignored) {}
            if (out == null) out = resolver.openOutputStream(uri, "w");
            if (out == null) throw new IllegalStateException("Unable to open destination file");
            out.write(data);
            out.flush();
        } finally {
            if (out != null) try { out.close(); } catch (Exception ignored) {}
        }
    }

    private long queryUriSize(Uri uri) {
        try (Cursor c = getContext().getContentResolver().query(
                uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) {}
        try (ParcelFileDescriptor pfd = getContext().getContentResolver().openFileDescriptor(uri, "r")) {
            if (pfd != null) return pfd.getStatSize();
        } catch (Exception ignored) {}
        return -1;
    }

    private JSObject saveBundledIitcToDownloads(String fileName, byte[] data) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "text/javascript");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Unable to create Downloads entry");
        boolean ok = false;
        try {
            writeBytesToUri(uri, data);
            long actual = queryUriSize(uri);
            if (actual != data.length) {
                throw new IllegalStateException("Saved plugin size mismatch: " + actual + "/" + data.length + " bytes");
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
            ok = true;

            JSObject ret = new JSObject();
            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", fileName);
            ret.put("bytes", data.length);
            ret.put("verifiedBytes", actual);
            ret.put("uri", uri.toString());
            ret.put("location", "Downloads");
            ret.put("location", "Downloads");
            return ret;
        } finally {
            if (!ok) {
                try { resolver.delete(uri, null, null); } catch (Exception ignored) {}
            }
        }
    }

    private android.content.SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private Uri configuredUri() {
        String raw = prefs().getString(KEY_URI, "");
        if (raw == null || raw.isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Exception e) { return null; }
    }

    private String folderLabel(Uri treeUri) {
        if (treeUri == null) return "";
        try {
            ContentResolver resolver = getContext().getContentResolver();
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
            try (Cursor c = resolver.query(docUri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {}
        String last = treeUri.getLastPathSegment();
        return last == null ? treeUri.toString() : Uri.decode(last).replace("primary:", "Stockage/");
    }

    private JSObject folderResult(Uri uri) {
        JSObject ret = new JSObject();
        ret.put("configured", uri != null);
        ret.put("uri", uri == null ? "" : uri.toString());
        ret.put("label", folderLabel(uri));
        return ret;
    }

    @PluginMethod
    public void getFolder(PluginCall call) {
        call.resolve(folderResult(configuredUri()));
    }

    @PluginMethod
    public void chooseFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "folderPicked");
    }

    @ActivityCallback
    private void folderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.resolve(folderResult(configuredUri()));
            return;
        }
        Uri uri = result.getData().getData();
        int flags = result.getData().getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (flags == 0) flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException ignored) {}
        prefs().edit().putString(KEY_URI, uri.toString()).apply();
        call.resolve(folderResult(uri));
    }

    private Uri findChild(ContentResolver resolver, Uri treeUri, String fileName) throws Exception {
        String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId);
        String[] projection = new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    if (fileName.equals(name)) return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                }
            }
        }
        return null;
    }


    private static class ChildDoc {
        String id;
        String name;
        String mime;
        Uri uri;
        ChildDoc(String id, String name, String mime, Uri uri) {
            this.id = id;
            this.name = name;
            this.mime = mime;
            this.uri = uri;
        }
    }

    private Uri configuredIitcTreeUri() {
        String raw = prefs().getString(KEY_IITC_TREE_URI, "");
        if (raw == null || raw.isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Exception e) { return null; }
    }

    private ChildDoc findChildDoc(ContentResolver resolver, Uri treeUri, String parentDocId, String childName) throws Exception {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
        String[] projection = new String[]{
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    String mime = c.getString(2);
                    if (childName.equals(name)) {
                        return new ChildDoc(id, name, mime, DocumentsContract.buildDocumentUriUsingTree(treeUri, id));
                    }
                }
            }
        }
        return null;
    }

    private byte[] readBytesFromUri(Uri uri) throws Exception {
        try (InputStream in = getContext().getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("Unable to read document");
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    private String sha256(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private String userscriptMeta(byte[] data, String key) {
        try {
            String text = new String(data, StandardCharsets.UTF_8);
            Pattern p = Pattern.compile("(?m)^\\s*//\\s*@" + Pattern.quote(key) + "\\s+(.+?)\\s*$");
            Matcher m = p.matcher(text);
            return m.find() ? m.group(1).trim() : "";
        } catch (Exception e) {
            return "";
        }
    }

    private boolean isKnownLegacyCompanion(Uri uri) {
        try {
            byte[] data = readBytesFromUri(uri);
            String text = new String(data, StandardCharsets.UTF_8);
            String id = userscriptMeta(data, "id");
            return text.contains("Redacted BannerLab") && "redacted-bannerlab-bridge".equals(id);
        } catch (Exception e) {
            return false;
        }
    }


    private ChildDoc findLegacyCompanion(ContentResolver resolver, Uri treeUri, String parentDocId) throws Exception {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
        String[] projection = new String[]{
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    String mime = c.getString(2);
                    if (name == null || IITC_CANONICAL_FILE.equals(name) || DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) continue;
                    String low = name.toLowerCase(Locale.ROOT);
                    if (!low.endsWith(".js") && !low.endsWith(".user.js")) continue;
                    Uri uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    if (isKnownLegacyCompanion(uri)) return new ChildDoc(id, name, mime, uri);
                }
            }
        }
        return null;
    }

    private String iitcSelectionKind(Uri treeUri) {
        if (treeUri == null) return "";
        String label = folderLabel(treeUri).toLowerCase(Locale.ROOT).trim();
        String docId = "";
        try { docId = DocumentsContract.getTreeDocumentId(treeUri).replace('\\', '/').toLowerCase(Locale.ROOT); } catch (Exception ignored) {}
        if ("plugins".equals(label) || docId.endsWith("/plugins")) return "plugins";
        if ("iitc_mobile".equals(label) || "iitc mobile".equals(label) || docId.endsWith(":iitc_mobile") || docId.endsWith("/iitc_mobile")) return "root";
        return "";
    }

    private ChildDoc resolveIitcPluginsFolder(Uri treeUri, boolean create) throws Exception {
        if (treeUri == null) throw new IllegalStateException("IITC folder not configured");
        ContentResolver resolver = getContext().getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId);
        String label = folderLabel(treeUri);
        String kind = iitcSelectionKind(treeUri);

        if ("plugins".equals(kind)) {
            return new ChildDoc(rootId, label, DocumentsContract.Document.MIME_TYPE_DIR, rootDoc);
        }
        if (!"root".equals(kind)) {
            throw new IllegalArgumentException("Select IITC_Mobile or its plugins folder");
        }

        ChildDoc plugins = findChildDoc(resolver, treeUri, rootId, "plugins");
        if (plugins != null) {
            if (!DocumentsContract.Document.MIME_TYPE_DIR.equals(plugins.mime)) {
                throw new IllegalStateException("IITC_Mobile/plugins is not a folder");
            }
            return plugins;
        }
        if (!create) return null;
        Uri created = DocumentsContract.createDocument(resolver, rootDoc, DocumentsContract.Document.MIME_TYPE_DIR, "plugins");
        if (created == null) throw new IllegalStateException("Unable to create IITC_Mobile/plugins");
        String id = DocumentsContract.getDocumentId(created);
        return new ChildDoc(id, "plugins", DocumentsContract.Document.MIME_TYPE_DIR, created);
    }

    private JSObject iitcCompanionStatusInternal() throws Exception {
        byte[] bundled = bundledIitcBytes();
        String availableVersion = userscriptMeta(bundled, "version");
        String availableId = userscriptMeta(bundled, "id");
        String availableHash = sha256(bundled);

        JSObject ret = new JSObject();
        ret.put("available", true);
        ret.put("availableVersion", availableVersion);
        ret.put("availableId", availableId);
        ret.put("availableBytes", bundled.length);
        ret.put("availableHash", availableHash);
        ret.put("fileName", IITC_CANONICAL_FILE);

        Uri treeUri = configuredIitcTreeUri();
        ret.put("configured", treeUri != null);
        if (treeUri == null) {
            ret.put("installed", false);
            ret.put("upToDate", false);
            return ret;
        }

        ret.put("folderLabel", folderLabel(treeUri));
        ChildDoc plugins = resolveIitcPluginsFolder(treeUri, false);
        if (plugins == null) {
            ret.put("installed", false);
            ret.put("upToDate", false);
            return ret;
        }

        ContentResolver resolver = getContext().getContentResolver();
        ChildDoc plugin = findChildDoc(resolver, treeUri, plugins.id, IITC_CANONICAL_FILE);
        boolean legacy = false;
        String legacyName = "";
        if (plugin == null) {
            ChildDoc old = findLegacyCompanion(resolver, treeUri, plugins.id);
            if (old != null) {
                plugin = old;
                legacy = true;
                legacyName = old.name;
            }
        }

        if (plugin == null) {
            ret.put("installed", false);
            ret.put("upToDate", false);
            return ret;
        }

        byte[] installedBytes = readBytesFromUri(plugin.uri);
        String installedHash = sha256(installedBytes);
        String installedVersion = userscriptMeta(installedBytes, "version");
        String installedId = userscriptMeta(installedBytes, "id");
        ret.put("installed", true);
        ret.put("installedVersion", installedVersion);
        ret.put("installedId", installedId);
        ret.put("installedBytes", installedBytes.length);
        ret.put("installedHash", installedHash);
        ret.put("legacy", legacy);
        ret.put("legacyName", legacyName);
        ret.put("upToDate", !legacy && IITC_CANONICAL_FILE.equals(plugin.name) && availableHash.equals(installedHash));
        return ret;
    }

    @PluginMethod
    public void getIitcCompanionStatus(PluginCall call) {
        try {
            call.resolve(iitcCompanionStatusInternal());
        } catch (SecurityException e) {
            prefs().edit().remove(KEY_IITC_TREE_URI).apply();
            call.reject("IITC folder permission was lost", e);
        } catch (Exception e) {
            call.reject("Unable to inspect IITC companion: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void chooseIitcFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3AIITC_Mobile"));
            } catch (Exception ignored) {}
        }
        startActivityForResult(call, intent, "iitcFolderPicked");
    }

    @ActivityCallback
    private void iitcFolderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            try { call.resolve(iitcCompanionStatusInternal()); }
            catch (Exception e) { call.reject("Unable to inspect IITC folder: " + e.getMessage(), e); }
            return;
        }
        Uri uri = result.getData().getData();
        if (iitcSelectionKind(uri).isEmpty()) {
            call.reject("Select the IITC_Mobile folder (or IITC_Mobile/plugins)");
            return;
        }
        int flags = result.getData().getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (flags == 0) flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException e) {
            call.reject("Unable to keep access to IITC_Mobile", e);
            return;
        }
        prefs().edit().putString(KEY_IITC_TREE_URI, uri.toString()).apply();
        try {
            resolveIitcPluginsFolder(uri, true);
            call.resolve(iitcCompanionStatusInternal());
        } catch (Exception e) {
            prefs().edit().remove(KEY_IITC_TREE_URI).apply();
            call.reject("Unable to use IITC_Mobile: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void installOrUpdateBundledIitc(PluginCall call) {
        Uri treeUri = configuredIitcTreeUri();
        if (treeUri == null) {
            call.reject("IITC_FOLDER_REQUIRED");
            return;
        }
        try {
            byte[] bundled = bundledIitcBytes();
            String expectedHash = sha256(bundled);
            ContentResolver resolver = getContext().getContentResolver();
            ChildDoc plugins = resolveIitcPluginsFolder(treeUri, true);
            ChildDoc target = findChildDoc(resolver, treeUri, plugins.id, IITC_CANONICAL_FILE);
            boolean existed = target != null;
            if (target == null) {
                Uri created = DocumentsContract.createDocument(resolver, plugins.uri, "application/javascript", IITC_CANONICAL_FILE);
                if (created == null) throw new IllegalStateException("Unable to create " + IITC_CANONICAL_FILE);
                target = new ChildDoc(DocumentsContract.getDocumentId(created), IITC_CANONICAL_FILE, "application/javascript", created);
            }

            writeBytesToUri(target.uri, bundled);
            byte[] verified = readBytesFromUri(target.uri);
            if (verified.length != bundled.length || !expectedHash.equals(sha256(verified))) {
                throw new IllegalStateException("Companion verification failed after write");
            }

            boolean migratedLegacy = false;
            for (int guard = 0; guard < 8; guard++) {
                ChildDoc old = findLegacyCompanion(resolver, treeUri, plugins.id);
                if (old == null || old.uri.equals(target.uri)) break;
                try {
                    if (DocumentsContract.deleteDocument(resolver, old.uri)) migratedLegacy = true;
                    else break;
                } catch (Exception ignored) { break; }
            }

            JSObject ret = iitcCompanionStatusInternal();
            ret.put("written", true);
            ret.put("updated", existed);
            ret.put("migratedLegacy", migratedLegacy);
            ret.put("verifiedBytes", verified.length);
            call.resolve(ret);
        } catch (SecurityException e) {
            prefs().edit().remove(KEY_IITC_TREE_URI).apply();
            call.reject("IITC folder permission was lost", e);
        } catch (Exception e) {
            call.reject("Unable to install/update IITC Companion: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearIitcFolder(PluginCall call) {
        prefs().edit().remove(KEY_IITC_TREE_URI).apply();
        try { call.resolve(iitcCompanionStatusInternal()); }
        catch (Exception e) { call.reject("Unable to clear IITC folder: " + e.getMessage(), e); }
    }

    @PluginMethod
    public void writeTextFile(PluginCall call) {
        Uri treeUri = configuredUri();
        if (treeUri == null) {
            call.reject("No backup folder configured");
            return;
        }
        String fileName = call.getString("fileName", "Redacted_BannerLab_Autosave.json");
        String text = call.getString("text");
        if (text == null) {
            call.reject("Missing text");
            return;
        }
        fileName = fileName.replace("/", "_").replace("\\", "_");
        try {
            ContentResolver resolver = getContext().getContentResolver();
            Uri target = findChild(resolver, treeUri, fileName);
            if (target == null) {
                String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId);
                target = DocumentsContract.createDocument(resolver, parent, "application/json", fileName);
            }
            if (target == null) throw new IllegalStateException("Unable to create backup file");
            try (OutputStream out = resolver.openOutputStream(target, "rwt")) {
                if (out == null) throw new IllegalStateException("Unable to open backup file");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            JSObject ret = new JSObject();
            ret.put("written", true);
            ret.put("fileName", fileName);
            ret.put("uri", target.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to write backup: " + e.getMessage(), e);
        }
    }


    @PluginMethod
    public void getBundledIitcInfo(PluginCall call) {
        try {
            byte[] data = bundledIitcBytes();
            JSObject ret = new JSObject();
            ret.put("available", true);
            ret.put("bytes", data.length);
            ret.put("fileName", "redacted-bannerlab-iitc.user.js");
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Bundled IITC plugin unavailable: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openBundledIitcWithIitc(PluginCall call) {
        String fileName = call.getString("fileName", "redacted-bannerlab-iitc.user.js");
        String packageName = call.getString("packageName", "org.exarhteam.iitc_mobile");
        fileName = fileName.replace("/", "_").replace("\\", "_");
        if (!fileName.endsWith(".user.js")) fileName += ".user.js";

        try {
            byte[] data = bundledIitcBytes();
            // Utiliser exactement la même copie physique dans Téléchargements que celle
            // qui fonctionne lors d'une installation manuelle depuis IITC. On évite ainsi
            // l'URI temporaire FileProvider/cache, mal gérée par certaines versions d'IITC.
            JSObject saved = saveBundledIitcToDownloads(fileName, data);
            String savedUri = saved.getString("uri");
            if (savedUri == null || savedUri.isEmpty()) {
                throw new IllegalStateException("Saved Downloads URI is missing");
            }
            Uri uri = Uri.parse(savedUri);
            long verifiedSize = queryUriSize(uri);
            if (verifiedSize != data.length || verifiedSize < IITC_MIN_BYTES) {
                throw new IllegalStateException("Downloads plugin copy is invalid: " + verifiedSize + " bytes");
            }

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "text/javascript");
            intent.setClipData(ClipData.newRawUri(fileName, uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // IITC Mobile exposes this activity specifically for external .user.js installs.
            // Using the explicit component avoids Android picking the wrong activity or silently
            // dropping the intent on recent Android versions.
            if ("org.exarhteam.iitc_mobile".equals(packageName)) {
                intent.setClassName(
                    "org.exarhteam.iitc_mobile",
                    "org.exarhteam.iitc_mobile.prefs.PluginPreferenceActivity"
                );
            } else if (packageName != null && !packageName.trim().isEmpty()) {
                intent.setPackage(packageName.trim());
            }

            getContext().grantUriPermission(
                packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
            getContext().startActivity(intent);

            JSObject ret = new JSObject();
            ret.put("opened", true);
            ret.put("fileName", fileName);
            ret.put("bytes", data.length);
            ret.put("verifiedBytes", verifiedSize);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to open bundled IITC plugin: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveBundledIitcAs(PluginCall call) {
        String fileName = call.getString("fileName", "redacted-bannerlab-iitc.user.js");
        fileName = fileName.replace("/", "_").replace("\\", "_");
        if (!fileName.endsWith(".user.js")) fileName += ".user.js";

        try {
            byte[] data = bundledIitcBytes();

            // Android 10+: write atomically through MediaStore. This avoids ACTION_CREATE_DOCUMENT
            // creating a 0-byte placeholder before Capacitor receives its activity callback.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                call.resolve(saveBundledIitcToDownloads(fileName, data));
                return;
            }

            // Legacy fallback for Android 7-9.
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/javascript");
            intent.putExtra(Intent.EXTRA_TITLE, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(call, intent, "bundledIitcFilePicked");
        } catch (Exception e) {
            call.reject("Bundled IITC plugin unavailable: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    @ActivityCallback
    private void bundledIitcFilePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            ret.put("saved", false);
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        Uri uri = result.getData().getData();
        try {
            byte[] data = bundledIitcBytes();
            writeBytesToUri(uri, data);
            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", "redacted-bannerlab-iitc.user.js");
            ret.put("bytes", data.length);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to save bundled IITC plugin: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveTextFileAs(PluginCall call) {
        String fileName = call.getString("fileName", "Redacted_BannerLab_Project.rbl.json");
        String mimeType = call.getString("mimeType", "application/json");
        fileName = fileName.replace("/", "_").replace("\\", "_");

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType == null || mimeType.isEmpty() ? "application/json" : mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(call, intent, "textFilePicked");
    }

    @ActivityCallback
    private void textFilePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;

        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            ret.put("saved", false);
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        String text = call.getString("text");
        if (text == null) {
            call.reject("Missing text");
            return;
        }

        Uri uri = result.getData().getData();
        try {
            ContentResolver resolver = getContext().getContentResolver();
            try (OutputStream out = resolver.openOutputStream(uri, "rwt")) {
                if (out == null) throw new IllegalStateException("Unable to open destination file");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

            String displayName = call.getString("fileName", "Redacted_BannerLab_Project.rbl.json");
            try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) displayName = name;
                }
            } catch (Exception ignored) {}

            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", displayName);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to save file: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearFolder(PluginCall call) {
        Uri uri = configuredUri();
        if (uri != null) {
            try {
                getContext().getContentResolver().releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
            } catch (Exception ignored) {}
        }
        prefs().edit().remove(KEY_URI).apply();
        call.resolve(folderResult(null));
    }
}
