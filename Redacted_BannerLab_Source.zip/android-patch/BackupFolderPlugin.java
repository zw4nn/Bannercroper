package com.bannerforge.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;

import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name = "BackupFolder")
public class BackupFolderPlugin extends Plugin {
    private static final String PREFS = "redacted_bannerlab_backup";
    private static final String KEY_URI = "folder_uri";
    private static final String IITC_ASSET = "public/redacted-bannerlab-iitc.user.js";
    private static final int IITC_MIN_BYTES = 1024;

    private byte[] bundledIitcBytes() throws IOException {
        try (InputStream in = getContext().getAssets().open(IITC_ASSET);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            byte[] data = out.toByteArray();
            if (data.length < IITC_MIN_BYTES) {
                throw new IOException("Bundled IITC plugin is unexpectedly small: " + data.length + " bytes");
            }
            return data;
        }
    }

    private void writeBytesToUri(Uri uri, byte[] data) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        OutputStream out = null;
        try {
            // rwt = write + truncate. Some document providers reject it, so fall back to w.
            try { out = resolver.openOutputStream(uri, "rwt"); } catch (Exception ignored) {}
            if (out == null) out = resolver.openOutputStream(uri, "w");
            if (out == null) throw new IllegalStateException("Unable to open destination file");
            out.write(data);
            out.flush();
        } finally {
            if (out != null) try { out.close(); } catch (Exception ignored) {}
        }
    }

    private long queryUriSize(Uri uri) {
        try (Cursor c = getContext().getContentResolver().query(
                uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) {}
        try (ParcelFileDescriptor pfd = getContext().getContentResolver().openFileDescriptor(uri, "r")) {
            if (pfd != null) return pfd.getStatSize();
        } catch (Exception ignored) {}
        return -1;
    }

    private JSObject saveBundledIitcToDownloads(String fileName, byte[] data) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "text/javascript");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Unable to create Downloads entry");
        boolean ok = false;
        try {
            writeBytesToUri(uri, data);
            long actual = queryUriSize(uri);
            if (actual != data.length) {
                throw new IllegalStateException("Saved plugin size mismatch: " + actual + "/" + data.length + " bytes");
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
            ok = true;

            JSObject ret = new JSObject();
            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", fileName);
            ret.put("bytes", data.length);
            ret.put("verifiedBytes", actual);
            ret.put("uri", uri.toString());
            ret.put("location", "Downloads");
            ret.put("location", "Downloads");
            return ret;
        } finally {
            if (!ok) {
                try { resolver.delete(uri, null, null); } catch (Exception ignored) {}
            }
        }
    }

    private android.content.SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private Uri configuredUri() {
        String raw = prefs().getString(KEY_URI, "");
        if (raw == null || raw.isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Exception e) { return null; }
    }

    private String folderLabel(Uri treeUri) {
        if (treeUri == null) return "";
        try {
            ContentResolver resolver = getContext().getContentResolver();
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
            try (Cursor c = resolver.query(docUri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {}
        String last = treeUri.getLastPathSegment();
        return last == null ? treeUri.toString() : Uri.decode(last).replace("primary:", "Stockage/");
    }

    private JSObject folderResult(Uri uri) {
        JSObject ret = new JSObject();
        ret.put("configured", uri != null);
        ret.put("uri", uri == null ? "" : uri.toString());
        ret.put("label", folderLabel(uri));
        return ret;
    }

    @PluginMethod
    public void getFolder(PluginCall call) {
        call.resolve(folderResult(configuredUri()));
    }

    @PluginMethod
    public void chooseFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "folderPicked");
    }

    @ActivityCallback
    private void folderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.resolve(folderResult(configuredUri()));
            return;
        }
        Uri uri = result.getData().getData();
        int flags = result.getData().getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException ignored) {}
        prefs().edit().putString(KEY_URI, uri.toString()).apply();
        call.resolve(folderResult(uri));
    }

    private Uri findChild(ContentResolver resolver, Uri treeUri, String fileName) throws Exception {
        String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId);
        String[] projection = new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    if (fileName.equals(name)) return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                }
            }
        }
        return null;
    }

    @PluginMethod
    public void writeTextFile(PluginCall call) {
        Uri treeUri = configuredUri();
        if (treeUri == null) {
            call.reject("No backup folder configured");
            return;
        }
        String fileName = call.getString("fileName", "Redacted_BannerLab_Autosave.json");
        String text = call.getString("text");
        if (text == null) {
            call.reject("Missing text");
            return;
        }
        fileName = fileName.replace("/", "_").replace("\\", "_");
        try {
            ContentResolver resolver = getContext().getContentResolver();
            Uri target = findChild(resolver, treeUri, fileName);
            if (target == null) {
                String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId);
                target = DocumentsContract.createDocument(resolver, parent, "application/json", fileName);
            }
            if (target == null) throw new IllegalStateException("Unable to create backup file");
            try (OutputStream out = resolver.openOutputStream(target, "rwt")) {
                if (out == null) throw new IllegalStateException("Unable to open backup file");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            JSObject ret = new JSObject();
            ret.put("written", true);
            ret.put("fileName", fileName);
            ret.put("uri", target.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to write backup: " + e.getMessage(), e);
        }
    }


    @PluginMethod
    public void getBundledIitcInfo(PluginCall call) {
        try {
            byte[] data = bundledIitcBytes();
            JSObject ret = new JSObject();
            ret.put("available", true);
            ret.put("bytes", data.length);
            ret.put("fileName", "redacted-bannerlab-iitc.user.js");
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Bundled IITC plugin unavailable: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openBundledIitcWithIitc(PluginCall call) {
        String fileName = call.getString("fileName", "redacted-bannerlab-iitc.user.js");
        String packageName = call.getString("packageName", "org.exarhteam.iitc_mobile");
        fileName = fileName.replace("/", "_").replace("\\", "_");
        if (!fileName.endsWith(".user.js")) fileName += ".user.js";

        try {
            byte[] data = bundledIitcBytes();
            // Utiliser exactement la même copie physique dans Téléchargements que celle
            // qui fonctionne lors d'une installation manuelle depuis IITC. On évite ainsi
            // l'URI temporaire FileProvider/cache, mal gérée par certaines versions d'IITC.
            JSObject saved = saveBundledIitcToDownloads(fileName, data);
            String savedUri = saved.getString("uri");
            if (savedUri == null || savedUri.isEmpty()) {
                throw new IllegalStateException("Saved Downloads URI is missing");
            }
            Uri uri = Uri.parse(savedUri);
            long verifiedSize = queryUriSize(uri);
            if (verifiedSize != data.length || verifiedSize < IITC_MIN_BYTES) {
                throw new IllegalStateException("Downloads plugin copy is invalid: " + verifiedSize + " bytes");
            }

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "text/javascript");
            intent.setClipData(ClipData.newRawUri(fileName, uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // IITC Mobile exposes this activity specifically for external .user.js installs.
            // Using the explicit component avoids Android picking the wrong activity or silently
            // dropping the intent on recent Android versions.
            if ("org.exarhteam.iitc_mobile".equals(packageName)) {
                intent.setClassName(
                    "org.exarhteam.iitc_mobile",
                    "org.exarhteam.iitc_mobile.prefs.PluginPreferenceActivity"
                );
            } else if (packageName != null && !packageName.trim().isEmpty()) {
                intent.setPackage(packageName.trim());
            }

            getContext().grantUriPermission(
                packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
            getContext().startActivity(intent);

            JSObject ret = new JSObject();
            ret.put("opened", true);
            ret.put("fileName", fileName);
            ret.put("bytes", data.length);
            ret.put("verifiedBytes", verifiedSize);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to open bundled IITC plugin: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveBundledIitcAs(PluginCall call) {
        String fileName = call.getString("fileName", "redacted-bannerlab-iitc.user.js");
        fileName = fileName.replace("/", "_").replace("\\", "_");
        if (!fileName.endsWith(".user.js")) fileName += ".user.js";

        try {
            byte[] data = bundledIitcBytes();

            // Android 10+: write atomically through MediaStore. This avoids ACTION_CREATE_DOCUMENT
            // creating a 0-byte placeholder before Capacitor receives its activity callback.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                call.resolve(saveBundledIitcToDownloads(fileName, data));
                return;
            }

            // Legacy fallback for Android 7-9.
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/javascript");
            intent.putExtra(Intent.EXTRA_TITLE, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(call, intent, "bundledIitcFilePicked");
        } catch (Exception e) {
            call.reject("Bundled IITC plugin unavailable: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    @ActivityCallback
    private void bundledIitcFilePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            ret.put("saved", false);
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        Uri uri = result.getData().getData();
        try {
            byte[] data = bundledIitcBytes();
            writeBytesToUri(uri, data);
            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", "redacted-bannerlab-iitc.user.js");
            ret.put("bytes", data.length);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to save bundled IITC plugin: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveTextFileAs(PluginCall call) {
        String fileName = call.getString("fileName", "Redacted_BannerLab_Project.rbl.json");
        String mimeType = call.getString("mimeType", "application/json");
        fileName = fileName.replace("/", "_").replace("\\", "_");

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType == null || mimeType.isEmpty() ? "application/json" : mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(call, intent, "textFilePicked");
    }

    @ActivityCallback
    private void textFilePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;

        JSObject ret = new JSObject();
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            ret.put("saved", false);
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        String text = call.getString("text");
        if (text == null) {
            call.reject("Missing text");
            return;
        }

        Uri uri = result.getData().getData();
        try {
            ContentResolver resolver = getContext().getContentResolver();
            try (OutputStream out = resolver.openOutputStream(uri, "rwt")) {
                if (out == null) throw new IllegalStateException("Unable to open destination file");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

            String displayName = call.getString("fileName", "Redacted_BannerLab_Project.rbl.json");
            try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) displayName = name;
                }
            } catch (Exception ignored) {}

            ret.put("saved", true);
            ret.put("cancelled", false);
            ret.put("fileName", displayName);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Unable to save file: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearFolder(PluginCall call) {
        Uri uri = configuredUri();
        if (uri != null) {
            try {
                getContext().getContentResolver().releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
            } catch (Exception ignored) {}
        }
        prefs().edit().remove(KEY_URI).apply();
        call.resolve(folderResult(null));
    }
}
