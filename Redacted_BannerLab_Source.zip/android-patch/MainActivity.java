package com.bannerforge.mobile;

import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MissionOverlayPlugin.class);
        registerPlugin(BackupFolderPlugin.class);
        registerPlugin(LocationStatusPlugin.class);
        registerPlugin(IitcSyncInboxPlugin.class);
        super.onCreate(savedInstanceState);

        // Plusieurs hotfix 1.0.12 ont partage le meme cache Service Worker. Une ancienne
        // page RBL pouvait donc continuer a tourner apres mise a jour de l'APK. On purge
        // uniquement ServiceWorker/CacheStorage, jamais IndexedDB/localStorage des projets.
        try {
            WebView webView = getBridge().getWebView();
            webView.postDelayed(() -> webView.evaluateJavascript(
                "(async()=>{try{" +
                "let changed=false;" +
                "if('serviceWorker'in navigator){const r=await navigator.serviceWorker.getRegistrations();" +
                "if(r.length){changed=true;await Promise.all(r.map(x=>x.unregister()));}}" +
                "if('caches'in window){const k=await caches.keys();const d=k.filter(x=>x.startsWith('redacted-bannerlab-'));" +
                "if(d.length){changed=true;await Promise.all(d.map(x=>caches.delete(x)));}}" +
                "if(changed&&!sessionStorage.getItem('rbl11216Reload')){sessionStorage.setItem('rbl11216Reload','1');location.reload();}" +
                "}catch(e){console.warn('[RBL cache purge]',e)}})();", null), 1200);
        } catch (Exception ignored) {}
    }
}
