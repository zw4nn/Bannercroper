package com.bannerforge.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;

public class MainActivity extends BridgeActivity {
    private static final String UPDATE_STATUS_ACTION = "com.bannerforge.mobile.RBL_UPDATE_INSTALL_STATUS";
    private View statusBarShield;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MissionOverlayPlugin.class);
        registerPlugin(BackupFolderPlugin.class);
        registerPlugin(LocationStatusPlugin.class);
        registerPlugin(IitcSyncInboxPlugin.class);
        registerPlugin(IitcBridgeLauncherPlugin.class);
        registerPlugin(UpdateManagerPlugin.class);
        registerPlugin(PublisherFilePlugin.class);
        super.onCreate(savedInstanceState);

        // TEST-04: Android 15+ force l'edge-to-edge. RBL garde donc un bouclier
        // natif au-dessus du WebView dans la zone de la barre d'état. Le contenu
        // peut continuer à défiler, mais il n'est jamais visible derrière l'heure,
        // le réseau ou la batterie. Les gestes système restent la propriété d'Android.
        installStatusBarShield();

        // PackageInstaller can start MainActivity directly through the mutable
        // status PendingIntent. Handle that callback while RBL is visibly in
        // the foreground, then open Android's own confirmation Intent.
        handleUpdateInstallIntent(getIntent());

        // Plusieurs hotfix 1.0.12 ont partage le meme cache Service Worker. Une ancienne
        // page RBL pouvait donc continuer a tourner apres mise a jour de l'APK. On purge
        // uniquement ServiceWorker/CacheStorage, jamais IndexedDB/localStorage des projets.
        try {
            WebView webView = getBridge().getWebView();
            webView.postDelayed(() -> webView.evaluateJavascript(
                "(async()=>{try{" +
                "let changed=false;" +
                "if('serviceWorker'in navigator){const r=await navigator.serviceWorker.getRegistrations();" +
                "if(r.length){changed=true;await Promise.all(r.map(x=>x.unregister()));}}" +
                "if('caches'in window){const k=await caches.keys();const d=k.filter(x=>x.startsWith('redacted-bannerlab-'));" +
                "if(d.length){changed=true;await Promise.all(d.map(x=>caches.delete(x)));}}" +
                "if(changed&&!sessionStorage.getItem('rbl11221Reload')){sessionStorage.setItem('rbl11221Reload','1');location.reload();}" +
                "}catch(e){console.warn('[RBL cache purge]',e)}})();", null), 1200);
        } catch (Exception ignored) {}
    }

    private void installStatusBarShield() {
        try {
            View decor = getWindow().getDecorView();
            if (!(decor instanceof FrameLayout)) return;

            FrameLayout root = (FrameLayout) decor;
            if (statusBarShield != null) {
                root.removeView(statusBarShield);
            }

            statusBarShield = new View(this);
            statusBarShield.setBackgroundColor(Color.rgb(7, 16, 12));
            statusBarShield.setClickable(true);
            statusBarShield.setFocusable(false);
            statusBarShield.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            statusBarShield.setOnTouchListener((v, event) -> true);
            statusBarShield.setElevation(10000f);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    Gravity.TOP
            );
            root.addView(statusBarShield, lp);
            statusBarShield.bringToFront();

            // Ne remplace surtout pas le listener WindowInsets de Capacitor : il alimente
            // les variables CSS --safe-area-inset-*. On lit simplement ses insets racine.
            decor.post(this::updateStatusBarShieldHeight);
        } catch (Exception e) {
            Log.w("RBL SystemBars", "Unable to install status bar shield", e);
        }
    }

    private void updateStatusBarShieldHeight() {
        if (statusBarShield == null) return;
        try {
            View decor = getWindow().getDecorView();
            int top = 0;
            WindowInsetsCompat insets = ViewCompat.getRootWindowInsets(decor);
            if (insets != null) {
                Insets bars = insets.getInsets(
                        WindowInsetsCompat.Type.statusBars() |
                        WindowInsetsCompat.Type.displayCutout()
                );
                top = Math.max(0, bars.top);
            }
            if (top <= 0) {
                int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
                if (id > 0) top = getResources().getDimensionPixelSize(id);
            }
            ViewGroup.LayoutParams lp = statusBarShield.getLayoutParams();
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
            lp.height = Math.max(0, top);
            statusBarShield.setLayoutParams(lp);
            statusBarShield.bringToFront();
        } catch (Exception e) {
            Log.w("RBL SystemBars", "Unable to refresh status bar shield", e);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        View decor = getWindow().getDecorView();
        decor.post(this::updateStatusBarShieldHeight);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().post(this::updateStatusBarShieldHeight);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleUpdateInstallIntent(intent);
    }

    private SharedPreferences updatePrefs() {
        return getSharedPreferences(UpdateManagerPlugin.PREFS, Context.MODE_PRIVATE);
    }

    private void saveUpdateState(String status, String message, int sessionId) {
        updatePrefs().edit()
                .putString(UpdateManagerPlugin.KEY_STATUS, status == null ? "" : status)
                .putString(UpdateManagerPlugin.KEY_MESSAGE, message == null ? "" : message)
                .putInt(UpdateManagerPlugin.KEY_SESSION_ID, sessionId)
                .putLong(UpdateManagerPlugin.KEY_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    @SuppressWarnings("deprecation")
    private Intent confirmationIntent(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) {
            return source.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
        }
        return source.getParcelableExtra(Intent.EXTRA_INTENT);
    }

    private boolean handleUpdateInstallIntent(Intent intent) {
        if (intent == null || !UPDATE_STATUS_ACTION.equals(intent.getAction())) return false;

        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, Integer.MIN_VALUE);
        int sessionId = intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID,
                intent.getIntExtra("rbl_session_id", -1));
        String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);

        Log.i("RBL Update", "PackageInstaller callback status=" + status + " session=" + sessionId + " msg=" + message);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            saveUpdateState("pending_user_action",
                    message == null ? "Confirmation Android requise" : message,
                    sessionId);

            try {
                Intent confirm = confirmationIntent(intent);
                if (confirm == null) {
                    saveUpdateState("failed", "Android n'a fourni aucun écran de confirmation", sessionId);
                    return true;
                }

                // The user has just pressed Installer in this foreground Activity.
                // Android explicitly recommends launching EXTRA_INTENT immediately
                // in that situation. No NEW_TASK trampoline is needed here.
                startActivity(confirm);
            } catch (Exception e) {
                Log.e("RBL Update", "Unable to open Android install confirmation", e);
                saveUpdateState("failed", "Impossible d'ouvrir la confirmation: " + e.getMessage(), sessionId);
            }
            return true;
        }

        if (status == PackageInstaller.STATUS_SUCCESS) {
            saveUpdateState("success", "Mise à jour installée", sessionId);
            try {
                new File(new File(getFilesDir(), "rbl_updates"), "rbl-update-staged.apk").delete();
            } catch (Exception ignored) {}
            return true;
        }

        if (status != Integer.MIN_VALUE) {
            saveUpdateState("failed",
                    message == null ? "Échec Android (" + status + ")" : message,
                    sessionId);
            Log.e("RBL Update", "Install failed status=" + status + " " + message);
            return true;
        }

        return false;
    }
}
