package com.bannerforge.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

import java.io.File;

public class MainActivity extends BridgeActivity {
    private static final String UPDATE_STATUS_ACTION = "com.bannerforge.mobile.RBL_UPDATE_INSTALL_STATUS";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MissionOverlayPlugin.class);
        registerPlugin(BackupFolderPlugin.class);
        registerPlugin(LocationStatusPlugin.class);
        registerPlugin(IitcSyncInboxPlugin.class);
        registerPlugin(UpdateManagerPlugin.class);
        registerPlugin(PublisherFilePlugin.class);
        super.onCreate(savedInstanceState);

        // PackageInstaller can start MainActivity directly through the mutable
        // status PendingIntent. Handle that callback while RBL is visibly in
        // the foreground, then open Android's own confirmation Intent.
        handleUpdateInstallIntent(getIntent());

        // Plusieurs hotfix 1.0.12 ont partage le meme cache Service Worker. Une ancienne
        // page RBL pouvait donc continuer a tourner apres mise a jour de l'APK. On purge
        // uniquement ServiceWorker/CacheStorage, jamais IndexedDB/localStorage des projets.
        try {
            WebView webView = getBridge().getWebView();
            webView.postDelayed(() -> webView.evaluateJavascript(
                "(async()=>{try{" +
                "let changed=false;" +
                "if('serviceWorker'in navigator){const r=await navigator.serviceWorker.getRegistrations();" +
                "if(r.length){changed=true;await Promise.all(r.map(x=>x.unregister()));}}" +
                "if('caches'in window){const k=await caches.keys();const d=k.filter(x=>x.startsWith('redacted-bannerlab-'));" +
                "if(d.length){changed=true;await Promise.all(d.map(x=>caches.delete(x)));}}" +
                "if(changed&&!sessionStorage.getItem('rbl11221Reload')){sessionStorage.setItem('rbl11221Reload','1');location.reload();}" +
                "}catch(e){console.warn('[RBL cache purge]',e)}})();", null), 1200);
        } catch (Exception ignored) {}
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleUpdateInstallIntent(intent);
    }

    private SharedPreferences updatePrefs() {
        return getSharedPreferences(UpdateManagerPlugin.PREFS, Context.MODE_PRIVATE);
    }

    private void saveUpdateState(String status, String message, int sessionId) {
        updatePrefs().edit()
                .putString(UpdateManagerPlugin.KEY_STATUS, status == null ? "" : status)
                .putString(UpdateManagerPlugin.KEY_MESSAGE, message == null ? "" : message)
                .putInt(UpdateManagerPlugin.KEY_SESSION_ID, sessionId)
                .putLong(UpdateManagerPlugin.KEY_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    @SuppressWarnings("deprecation")
    private Intent confirmationIntent(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) {
            return source.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
        }
        return source.getParcelableExtra(Intent.EXTRA_INTENT);
    }

    private boolean handleUpdateInstallIntent(Intent intent) {
        if (intent == null || !UPDATE_STATUS_ACTION.equals(intent.getAction())) return false;

        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, Integer.MIN_VALUE);
        int sessionId = intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID,
                intent.getIntExtra("rbl_session_id", -1));
        String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);

        Log.i("RBL Update", "PackageInstaller callback status=" + status + " session=" + sessionId + " msg=" + message);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            saveUpdateState("pending_user_action",
                    message == null ? "Confirmation Android requise" : message,
                    sessionId);

            try {
                Intent confirm = confirmationIntent(intent);
                if (confirm == null) {
                    saveUpdateState("failed", "Android n'a fourni aucun écran de confirmation", sessionId);
                    return true;
                }

                // The user has just pressed Installer in this foreground Activity.
                // Android explicitly recommends launching EXTRA_INTENT immediately
                // in that situation. No NEW_TASK trampoline is needed here.
                startActivity(confirm);
            } catch (Exception e) {
                Log.e("RBL Update", "Unable to open Android install confirmation", e);
                saveUpdateState("failed", "Impossible d'ouvrir la confirmation: " + e.getMessage(), sessionId);
            }
            return true;
        }

        if (status == PackageInstaller.STATUS_SUCCESS) {
            saveUpdateState("success", "Mise à jour installée", sessionId);
            try {
                new File(new File(getFilesDir(), "rbl_updates"), "rbl-update-staged.apk").delete();
            } catch (Exception ignored) {}
            return true;
        }

        if (status != Integer.MIN_VALUE) {
            saveUpdateState("failed",
                    message == null ? "Échec Android (" + status + ")" : message,
                    sessionId);
            Log.e("RBL Update", "Install failed status=" + status + " " + message);
            return true;
        }

        return false;
    }
}
