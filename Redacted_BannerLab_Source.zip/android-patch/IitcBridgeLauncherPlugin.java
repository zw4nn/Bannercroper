package com.bannerforge.mobile;

import android.content.Intent;
import android.net.Uri;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "IitcBridgeLauncher")
public class IitcBridgeLauncherPlugin extends Plugin {
    private static final String[] PACKAGES = new String[]{
            "org.exarhteam.iitc_mobile",
            "org.exarhteam.iitcprime"
    };

    @PluginMethod
    public void open(PluginCall call) {
        String url = call.getString("url", "");
        if (url == null || url.trim().isEmpty()) {
            call.reject("URL IITC absente");
            return;
        }

        Exception last = null;
        for (String packageName : PACKAGES) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.setPackage(packageName);
                // Reuse the existing IITC task/activity when possible. CLEAR_TOP + SINGLE_TOP
                // delivers the fresh rblcmd/rblreq URL through onNewIntent without destroying
                // IITC's whole task. NEW_TASK keeps IITC out of BannerLab's own task.
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                getContext().startActivity(intent);

                JSObject ret = new JSObject();
                ret.put("opened", true);
                ret.put("packageName", packageName);
                call.resolve(ret);
                return;
            } catch (Exception e) {
                last = e;
            }
        }

        call.reject("IITC Mobile / IITC Prime introuvable", last);
    }
}
