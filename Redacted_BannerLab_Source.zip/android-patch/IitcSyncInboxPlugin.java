package com.bannerforge.mobile;

import android.content.Context;
import android.content.SharedPreferences;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;

@CapacitorPlugin(name = "IitcSyncInbox")
public class IitcSyncInboxPlugin extends Plugin {
    @PluginMethod
    public void consume(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences(IitcAutoSyncActivity.PREFS, Context.MODE_PRIVATE);
        String raw = p.getString(IitcAutoSyncActivity.KEY_QUEUE, "[]");
        long lastAt = p.getLong(IitcAutoSyncActivity.KEY_LAST_AT, 0L);
        p.edit().remove(IitcAutoSyncActivity.KEY_QUEUE).apply();

        JSArray urls = new JSArray();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String url = arr.optString(i, "");
                if (!url.isEmpty()) urls.put(url);
            }
        } catch (Exception ignored) {}

        JSObject ret = new JSObject();
        ret.put("urls", urls);
        ret.put("count", urls.length());
        ret.put("lastAt", lastAt);
        call.resolve(ret);
    }

    @PluginMethod
    public void peek(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences(IitcAutoSyncActivity.PREFS, Context.MODE_PRIVATE);
        String raw = p.getString(IitcAutoSyncActivity.KEY_QUEUE, "[]");
        int count = 0;
        try { count = new JSONArray(raw).length(); } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("count", count);
        ret.put("lastAt", p.getLong(IitcAutoSyncActivity.KEY_LAST_AT, 0L));
        call.resolve(ret);
    }
}
