package com.bannerforge.mobile;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@CapacitorPlugin(name = "UpdateManager")
public class UpdateManagerPlugin extends Plugin {
    private static final String STAGED_APK = "rbl-update-staged.apk";
    static final String PREFS = "rbl_update_state";
    static final String KEY_STATUS = "status";
    static final String KEY_MESSAGE = "message";
    static final String KEY_SESSION_ID = "session_id";
    static final String KEY_UPDATED_AT = "updated_at";

    private File stagedFile() {
        return new File(getContext().getCacheDir(), STAGED_APK);
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private void saveInstallState(String status, String message, int sessionId) {
        prefs().edit()
                .putString(KEY_STATUS, status == null ? "" : status)
                .putString(KEY_MESSAGE, message == null ? "" : message)
                .putInt(KEY_SESSION_ID, sessionId)
                .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    private long versionCode(PackageInfo info) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) return info.getLongVersionCode();
        return info.versionCode;
    }

    private Set<String> signerDigests(PackageInfo info) throws Exception {
        Set<String> out = new HashSet<>();
        Signature[] sigs = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && info.signingInfo != null) {
            sigs = info.signingInfo.hasMultipleSigners()
                    ? info.signingInfo.getApkContentsSigners()
                    : info.signingInfo.getSigningCertificateHistory();
        }
        if (sigs == null) sigs = info.signatures;
        if (sigs != null) {
            for (Signature sig : sigs) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                out.add(hex(md.digest(sig.toByteArray())));
            }
        }
        return out;
    }

    private String hex(byte[] data) {
        StringBuilder sb = new StringBuilder(data.length * 2);
        for (byte b : data) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private PackageInfo installedInfo() throws Exception {
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
        return getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), flags);
    }

    private PackageInfo archiveInfo(File apk) throws Exception {
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
        PackageInfo info = getContext().getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
        if (info == null) throw new IllegalStateException("APK illisible");
        return info;
    }

    private JSObject verifyApk(File apk, String expectedSha) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(apk)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
        }

        String actualSha = hex(md.digest());
        String expected = expectedSha == null ? "" :
                expectedSha.trim().toLowerCase(Locale.US).replace("sha256:", "");

        if (expected.isEmpty()) throw new SecurityException("SHA-256 de la release absent");
        if (!actualSha.equals(expected)) throw new SecurityException("SHA-256 incorrect");

        PackageInfo current = installedInfo();
        PackageInfo candidate = archiveInfo(apk);

        if (!getContext().getPackageName().equals(candidate.packageName))
            throw new SecurityException("Package APK incorrect: " + candidate.packageName);

        long currentCode = versionCode(current);
        long nextCode = versionCode(candidate);
        if (nextCode <= currentCode)
            throw new SecurityException("versionCode non supérieur (" + nextCode + " <= " + currentCode + ")");

        Set<String> currentSigners = signerDigests(current);
        Set<String> candidateSigners = signerDigests(candidate);
        boolean sameSigner = false;
        for (String s : candidateSigners) {
            if (currentSigners.contains(s)) {
                sameSigner = true;
                break;
            }
        }

        if (!sameSigner || currentSigners.isEmpty() || candidateSigners.isEmpty())
            throw new SecurityException("Certificat de signature différent");

        JSObject ret = new JSObject();
        ret.put("verified", true);
        ret.put("sha256", actualSha);
        ret.put("packageName", candidate.packageName);
        ret.put("versionName", candidate.versionName == null ? "" : candidate.versionName);
        ret.put("versionCode", nextCode);
        ret.put("size", apk.length());
        return ret;
    }

    private boolean canRequestInstalls() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || getContext().getPackageManager().canRequestPackageInstalls();
    }

    private boolean hasOwnedInstallSession() {
        try {
            PackageInstaller installer = getContext().getPackageManager().getPackageInstaller();
            List<PackageInstaller.SessionInfo> sessions = installer.getMySessions();
            for (PackageInstaller.SessionInfo info : sessions) {
                if (getContext().getPackageName().equals(info.getAppPackageName())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        try {
            PackageInfo current = installedInfo();
            JSObject ret = new JSObject();

            ret.put("packageName", getContext().getPackageName());
            ret.put("versionName", current.versionName == null ? "" : current.versionName);
            ret.put("versionCode", versionCode(current));
            ret.put("sdk", Build.VERSION.SDK_INT);
            ret.put("canRequestPackageInstalls", canRequestInstalls());

            boolean staged = stagedFile().isFile() && stagedFile().length() > 0;

            // If the staged APK is no longer newer, the update succeeded or became obsolete.
            if (staged) {
                try {
                    PackageInfo stagedInfo = archiveInfo(stagedFile());
                    long stagedCode = versionCode(stagedInfo);
                    ret.put("stagedVersionName", stagedInfo.versionName == null ? "" : stagedInfo.versionName);
                    ret.put("stagedVersionCode", stagedCode);

                    if (stagedCode <= versionCode(current)) {
                        stagedFile().delete();
                        staged = false;
                        saveInstallState("success", "Version installée", -1);
                    }
                } catch (Exception ignored) {}
            }

            ret.put("staged", staged);
            ret.put("installSessionActive", hasOwnedInstallSession());
            ret.put("installStatus", prefs().getString(KEY_STATUS, "idle"));
            ret.put("installMessage", prefs().getString(KEY_MESSAGE, ""));
            ret.put("installSessionId", prefs().getInt(KEY_SESSION_ID, -1));
            ret.put("installUpdatedAt", prefs().getLong(KEY_UPDATED_AT, 0L));

            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Impossible de lire le statut de mise à jour", e);
        }
    }

    @PluginMethod
    public void openInstallPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || canRequestInstalls()) {
                JSObject ret = new JSObject();
                ret.put("canRequestPackageInstalls", true);
                call.resolve(ret);
                return;
            }

            Intent i = new Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getContext().getPackageName())
            );

            // IMPORTANT: resolve only when the user actually comes back from Android Settings.
            startActivityForResult(call, i, "installPermissionReturned");
        } catch (Exception e) {
            call.reject("Impossible d'ouvrir l'autorisation d'installation", e);
        }
    }

    @ActivityCallback
    private void installPermissionReturned(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        ret.put("canRequestPackageInstalls", canRequestInstalls());
        call.resolve(ret);
    }

    @PluginMethod
    public void clearStagedUpdate(PluginCall call) {
        try {
            if (stagedFile().exists()) stagedFile().delete();
            saveInstallState("idle", "", -1);
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void downloadUpdate(final PluginCall call) {
        final String url = call.getString("url", "");
        final String expectedSha = call.getString("sha256", "");

        if (url.isEmpty()) {
            call.reject("URL APK absente");
            return;
        }

        new Thread(() -> {
            File tmp = new File(getContext().getCacheDir(), STAGED_APK + ".part");

            try {
                if (tmp.exists()) tmp.delete();

                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setRequestProperty("User-Agent", "Redacted-BannerLab-Android");
                conn.setRequestProperty(
                        "Accept",
                        "application/vnd.android.package-archive,application/octet-stream,*/*"
                );

                int status = conn.getResponseCode();
                if (status < 200 || status >= 300)
                    throw new IllegalStateException("HTTP " + status);

                long total = conn.getContentLengthLong();
                long done = 0;
                long lastEvent = 0;

                try (InputStream in = conn.getInputStream();
                     OutputStream out = new FileOutputStream(tmp)) {

                    byte[] buf = new byte[65536];
                    int n;

                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n);
                        done += n;

                        long now = System.currentTimeMillis();
                        if (now - lastEvent > 180 || (total > 0 && done >= total)) {
                            JSObject p = new JSObject();
                            p.put("downloaded", done);
                            p.put("total", total);
                            p.put(
                                    "percent",
                                    total > 0
                                            ? Math.min(100, Math.round(done * 100.0 / total))
                                            : -1
                            );
                            notifyListeners("updateProgress", p);
                            lastEvent = now;
                        }
                    }

                    out.flush();
                } finally {
                    conn.disconnect();
                }

                JSObject verified = verifyApk(tmp, expectedSha);

                File staged = stagedFile();
                if (staged.exists()) staged.delete();

                if (!tmp.renameTo(staged)) {
                    try (InputStream in = new FileInputStream(tmp);
                         OutputStream out = new FileOutputStream(staged)) {

                        byte[] b = new byte[65536];
                        int n;
                        while ((n = in.read(b)) != -1) out.write(b, 0, n);
                    }
                    tmp.delete();
                }

                saveInstallState("ready", "APK téléchargé et vérifié", -1);
                verified.put("downloaded", true);
                call.resolve(verified);

            } catch (Exception e) {
                try { tmp.delete(); } catch (Exception ignored) {}
                saveInstallState("failed", "Téléchargement/vérification: " + e.getMessage(), -1);
                call.reject("Téléchargement/vérification refusé: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void installStagedUpdate(final PluginCall call) {
        try {
            File apk = stagedFile();

            if (!apk.isFile() || apk.length() == 0) {
                call.reject("Aucune mise à jour téléchargée");
                return;
            }

            if (!canRequestInstalls()) {
                saveInstallState("permission_required", "Autorisation Android requise", -1);
                JSObject ret = new JSObject();
                ret.put("needsPermission", true);
                call.resolve(ret);
                return;
            }

            // Re-check package/signature/version at install time.
            PackageInfo current = installedInfo();
            PackageInfo candidate = archiveInfo(apk);

            if (!getContext().getPackageName().equals(candidate.packageName))
                throw new SecurityException("Package incorrect");

            if (versionCode(candidate) <= versionCode(current))
                throw new SecurityException("versionCode non supérieur");

            Set<String> cur = signerDigests(current);
            Set<String> next = signerDigests(candidate);
            boolean same = false;
            for (String s : next) {
                if (cur.contains(s)) {
                    same = true;
                    break;
                }
            }
            if (!same) throw new SecurityException("Certificat différent");

            PackageInstaller installer = getContext().getPackageManager().getPackageInstaller();

            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);

            params.setAppPackageName(getContext().getPackageName());
            params.setSize(apk.length());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
            }

            int sessionId = installer.createSession(params);
            saveInstallState("writing", "Préparation de la session Android", sessionId);

            try (PackageInstaller.Session session = installer.openSession(sessionId);
                 InputStream in = new FileInputStream(apk);
                 OutputStream out = session.openWrite("base.apk", 0, apk.length())) {

                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                session.fsync(out);

                Intent result = new Intent(getContext(), UpdateInstallActivity.class);
                result.setAction("com.bannerforge.mobile.RBL_UPDATE_COMMIT");
                result.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                );

                // Use an Activity PendingIntent, not a BroadcastReceiver trampoline.
                PendingIntent pi = PendingIntent.getActivity(
                        getContext(),
                        sessionId,
                        result,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
                );

                saveInstallState("committing", "Installation confiée à Android", sessionId);
                session.commit(pi.getIntentSender());
            }

            JSObject ret = new JSObject();
            ret.put("committed", true);
            ret.put("sessionId", sessionId);
            call.resolve(ret);

        } catch (Exception e) {
            saveInstallState("failed", "Installation: " + e.getMessage(), -1);
            call.reject("Installation impossible: " + e.getMessage(), e);
        }
    }
}
