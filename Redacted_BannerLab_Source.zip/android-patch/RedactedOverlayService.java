package com.bannerforge.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class RedactedOverlayService extends Service {
    public static final String ACTION_START = "com.bannerforge.mobile.redactedoverlay.START";
    public static final String ACTION_STOP = "com.bannerforge.mobile.redactedoverlay.STOP";
    public static final String ACTION_CALIBRATE = "com.bannerforge.mobile.redactedoverlay.CALIBRATE";
    public static final String ACTION_SET_STATE = "com.bannerforge.mobile.redactedoverlay.SET_STATE";
    public static final String ACTION_SET_FACTION = "com.bannerforge.mobile.redactedoverlay.SET_FACTION";
    public static final String ACTION_CONFIGURE_SELECTION = "com.bannerforge.mobile.redactedoverlay.CONFIGURE_SELECTION";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_FACTION = "faction";
    public static final String EXTRA_COMPONENTS = "components";
    public static final String PREFS = "rbl_redacted_overlay";

    private static final String CHANNEL_ID = "rbl_redacted_overlay";
    private static final int NOTIFICATION_ID = 6132;
    private static final String INGRESS_PACKAGE = "com.nianticproject.ingress";
    private static final String[] COMPONENTS = new String[]{"neon"};
    private static final int MICRO_DOT_PX = 4;
    private static final int MICRO_SPREAD_PX = 10;

    private WindowManager wm;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LabFrameView hud;
    private FrameLayout calibrationBar;
    private WindowManager.LayoutParams calibrationBarLp;
    private boolean calibrationBarCollapsed = false;
    private float calibrationBarDownX, calibrationBarDownY;
    private int calibrationBarStartX, calibrationBarStartY;
    private final List<HotspotWindow> hotspotWindows = new ArrayList<>();
    private final List<VisualWindow> visualWindows = new ArrayList<>();
    private String state = "MAP";
    private String faction = "ENL";
    private boolean calibration = false;
    private boolean wizardCalibration = false;
    private final List<String> wizardComponents = new ArrayList<>();
    private int wizardComponentIndex = 0;
    private boolean visible = false;
    private boolean placementMode = true;
    private long lastUsageEventCheck = Math.max(0L, System.currentTimeMillis() - 15000L);
    private String lastUsageForegroundPackage = "";
    private final Deque<String> history = new ArrayDeque<>();

    private final Runnable foregroundTicker = new Runnable() {
        @Override public void run() {
            refreshVisibility();
            handler.postDelayed(this, 650L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        state = prefs.getString("state", "MAP");
        faction = normalizeFaction(prefs.getString("faction", "ENL"));
        ensureDefaultConfig();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("active", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            prefs.edit().putBoolean("active", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && intent.hasExtra(EXTRA_STATE)) {
            setState(normalizeState(intent.getStringExtra(EXTRA_STATE)), false);
        }
        if (intent != null && intent.hasExtra(EXTRA_FACTION)) {
            faction = normalizeFaction(intent.getStringExtra(EXTRA_FACTION));
            prefs.edit().putString("faction", faction).apply();
        }
        if (intent != null && ACTION_SET_FACTION.equals(intent.getAction())) {
            if (hud != null) rebuildAll();
            return START_STICKY;
        }
        if (intent != null && ACTION_CONFIGURE_SELECTION.equals(intent.getAction())) {
            String csv = intent.getStringExtra(EXTRA_COMPONENTS);
            applyComponentSelection(csv == null ? "" : csv);
            prepareSelectiveWizard();
            calibration = !wizardComponents.isEmpty();
            wizardCalibration = calibration;
            if (calibration) {
                wizardComponentIndex = 0;
                String firstComponent = wizardComponents.get(0);
                state = isVisualComponent(firstComponent) ? visualAssignedState(firstComponent) : stateForComponent(firstComponent);
                if("ALL".equals(state)) state="MAP";
                placementMode = true;
                prefs.edit().putString("state", state).apply();
            }
        } else {
            calibration = intent != null && ACTION_CALIBRATE.equals(intent.getAction());
            wizardCalibration = calibration;
            wizardComponents.clear();
            if (calibration) {
                for (String c : COMPONENTS) if (isComponentEnabled(c) && !isComponentCalibrated(c)) wizardComponents.add(c);
                if (wizardComponents.isEmpty()) {
                    // Legacy single-state calibration remains available as a fallback.
                    String c = firstComponentForState(state);
                    if (c != null) wizardComponents.add(c);
                }
                wizardComponentIndex = 0;
                if (!wizardComponents.isEmpty()) state = stateForComponent(wizardComponents.get(0));
            }
        }
        prefs.edit().putBoolean("active", true).putBoolean("calibrating", calibration).putString("state", state).apply();
        startForeground(NOTIFICATION_ID, buildNotification());
        rebuildAll();
        handler.removeCallbacks(foregroundTicker);
        handler.post(foregroundTicker);
        if (calibration || (intent != null && ACTION_CONFIGURE_SELECTION.equals(intent.getAction()))) openIngress();
        return START_STICKY;
    }

    private void refreshVisibility() {
        boolean primeConfirmed = isPrimeForegroundConfirmed();
        boolean detectorAvailable = hasUsageAccess() || PrimeOverlayAccessibilityService.isReady();
        boolean shouldShow = calibration ? (!detectorAvailable || primeConfirmed) : primeConfirmed;
        visible = shouldShow;
        if (hud != null) hud.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (calibrationBar != null) calibrationBar.setVisibility(visible ? View.VISIBLE : View.GONE);
        for (HotspotWindow h : hotspotWindows) h.root.setVisibility(visible ? View.VISIBLE : View.GONE);
        for (VisualWindow v : visualWindows) v.root.setVisibility(visible ? View.VISIBLE : View.GONE);
        refreshHotspotInteractivity(primeConfirmed);
    }

    private void refreshHotspotInteractivity(boolean primeConfirmed) {
        boolean interactive = calibration
            ? (visible && placementMode)
            : (visible && primeConfirmed && PrimeOverlayAccessibilityService.isReady());
        for (HotspotWindow h : hotspotWindows) {
            if (h.replaying) continue;
            boolean currentlyTouchable = (h.lp.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0;
            if (interactive == currentlyTouchable) continue;
            if (interactive) h.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else h.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            try { wm.updateViewLayout(h.root, h.lp); } catch (Exception ignored) {}
        }
    }

    private void rebuildAll() {
        removeAll();
        buildHud();
        buildHotspots();
        buildVisuals();
        if (calibration) buildCalibrationBar();
        refreshVisibility();
    }

    /** Passive, full-screen frame. It never consumes a touch. */
    private void buildHud() {
        if (!isComponentEnabled("neon")) { hud = null; return; }
        hud = new LabFrameView(this);
        hud.setAccent(accentForState());
        hud.setLevelName(levelName());
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1, -1, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(hud, lp);
    }

    private void buildCalibrationBar() {
        calibrationBar = new FrameLayout(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        int savedX = prefs.getInt("calibration_bar_x", 0);
        int savedY = prefs.getInt("calibration_bar_y", dp(3));
        calibrationBarCollapsed = prefs.getBoolean("calibration_bar_collapsed", false);

        if (calibrationBarCollapsed) {
            LinearLayout pill = new LinearLayout(this);
            pill.setOrientation(LinearLayout.HORIZONTAL);
            pill.setGravity(Gravity.CENTER_VERTICAL);
            pill.setPadding(dp(10), dp(6), dp(7), dp(6));
            pill.setBackground(rounded(0xF207120C, accentForState(), 16, 1));

            TextView label = text("LAB " + (wizardComponentIndex + 1) + "/" + Math.max(1, wizardComponents.size()), 7.5f, Color.WHITE, true);
            label.setGravity(Gravity.CENTER_VERTICAL);
            pill.addView(label, new LinearLayout.LayoutParams(0, -1, 1f));

            TextView expand = text("▣", 9f, 0xFFB8FFD0, true);
            expand.setGravity(Gravity.CENTER);
            expand.setPadding(dp(7), dp(3), dp(7), dp(3));
            expand.setOnClickListener(v -> {
                prefs.edit().putBoolean("calibration_bar_collapsed", false).apply();
                calibrationBarCollapsed = false;
                rebuildAll();
            });
            pill.addView(expand, new LinearLayout.LayoutParams(-2, -1));
            calibrationBar.addView(pill, new FrameLayout.LayoutParams(-1, -1));
            installCalibrationBarDrag(pill);

            calibrationBarLp = new WindowManager.LayoutParams(dp(128), dp(42), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        } else {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(10), dp(6), dp(8), dp(7));
            box.setBackground(rounded(0xF207120C, 0xFF2EEA78, 18, 1));

            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);

            TextView copy = text(calibrationTitle(), 8.1f, Color.WHITE, true);
            copy.setMaxLines(5);
            copy.setEllipsize(null);
            copy.setPadding(0, 0, dp(6), 0);
            header.addView(copy, new LinearLayout.LayoutParams(0, -1, 1f));
            installCalibrationBarDrag(copy);

            TextView collapse = text("−", 11f, 0xFFB8FFD0, true);
            collapse.setGravity(Gravity.CENTER);
            collapse.setPadding(dp(8), dp(3), dp(8), dp(3));
            collapse.setBackground(rounded(0x222EEA78, accentForState(), 10, 1));
            collapse.setOnClickListener(v -> {
                prefs.edit().putBoolean("calibration_bar_collapsed", true).apply();
                calibrationBarCollapsed = true;
                rebuildAll();
            });
            header.addView(collapse, new LinearLayout.LayoutParams(-2, -1));
            box.addView(header, new LinearLayout.LayoutParams(-1, dp(68)));

            LinearLayout controls = new LinearLayout(this);
            controls.setOrientation(LinearLayout.HORIZONTAL);
            controls.setGravity(Gravity.CENTER_VERTICAL);

            String target = currentWizardComponent();
            TextView prev = text("‹", 9f, Color.WHITE, true);
            prev.setGravity(Gravity.CENTER); prev.setPadding(dp(8),dp(7),dp(8),dp(7));
            prev.setBackground(rounded(0x332EEA78,accentForState(),12,1));
            prev.setOnClickListener(v -> previousCalibrationStep());
            controls.addView(prev,new LinearLayout.LayoutParams(-2,-2));

            TextView mode = text(placementMode ? "MODE PRIME" : "MODE ÉDITION", 7.1f, placementMode ? 0xFFB8FFD0 : Color.WHITE, true);
            mode.setGravity(Gravity.CENTER); mode.setPadding(dp(7),dp(7),dp(7),dp(7));
            mode.setBackground(rounded(placementMode ? 0x332EEA78 : 0x332E8AEA, accentForState(), 12, 1));
            mode.setOnClickListener(v -> { placementMode = !placementMode; rebuildAll(); });
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-2,-2); mp.leftMargin=dp(4); controls.addView(mode,mp);

            if (isVisualComponent(target)) {
                TextView setup = text("RÉGLER", 7.1f, Color.WHITE, true);
                setup.setGravity(Gravity.CENTER); setup.setPadding(dp(7),dp(7),dp(7),dp(7));
                setup.setBackground(rounded(0x332EEA78,accentForState(),12,1));
                LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2); sp.leftMargin=dp(4); controls.addView(setup,sp);
                setup.setOnClickListener(v -> showVisualSetupChooser(target));

                if ("NAV".equals(visualBehavior(target))) {
                    TextView test=text("TEST",7.1f,0xFF07120C,true); test.setGravity(Gravity.CENTER); test.setPadding(dp(7),dp(7),dp(7),dp(7));
                    test.setBackground(rounded(0xFFFFB74D,0xFFFFD180,12,1));
                    LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2);tp.leftMargin=dp(4);controls.addView(test,tp);
                    test.setOnClickListener(v -> testVisualNavigation(target));
                }
            }

            TextView skip=text("PASSER",7.1f,Color.WHITE,true); skip.setGravity(Gravity.CENTER);skip.setPadding(dp(7),dp(7),dp(7),dp(7));
            skip.setBackground(rounded(0x33222222,0xFF6C8A78,12,1));
            LinearLayout.LayoutParams skp=new LinearLayout.LayoutParams(-2,-2);skp.leftMargin=dp(4);controls.addView(skip,skp);
            skip.setOnClickListener(v -> skipCalibrationStep());

            TextView next = text(wizardCalibration && wizardComponentIndex < wizardComponents.size()-1 ? "✓" : "FIN", 7.6f, 0xFF07120C, true);
            next.setGravity(Gravity.CENTER); next.setPadding(dp(9),dp(7),dp(9),dp(7));
            next.setBackground(rounded(0xFF62F59D,0xFFB8FFD0,12,1));
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);np.leftMargin=dp(4);controls.addView(next,np);
            next.setOnClickListener(v -> finishCalibrationStep());

            box.addView(controls, new LinearLayout.LayoutParams(-1, -2));
            calibrationBar.addView(box, new FrameLayout.LayoutParams(-1, -1));
            calibrationBarLp = new WindowManager.LayoutParams(Math.min(dp(410), sw - dp(10)), dp(126), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        }

        calibrationBarLp.gravity = Gravity.TOP | Gravity.START;
        calibrationBarLp.x = Math.max(0, Math.min(savedX, Math.max(0, sw - calibrationBarLp.width)));
        calibrationBarLp.y = Math.max(0, Math.min(savedY, Math.max(0, sh - calibrationBarLp.height)));
        wm.addView(calibrationBar, calibrationBarLp);
    }

    private void installCalibrationBarDrag(View handle) {
        handle.setOnTouchListener((v,e) -> {
            if (calibrationBarLp == null) return false;
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    calibrationBarDownX=e.getRawX(); calibrationBarDownY=e.getRawY();
                    calibrationBarStartX=calibrationBarLp.x; calibrationBarStartY=calibrationBarLp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx=Math.round(e.getRawX()-calibrationBarDownX), dy=Math.round(e.getRawY()-calibrationBarDownY);
                    int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
                    calibrationBarLp.x=Math.max(0,Math.min(calibrationBarStartX+dx,Math.max(0,sw-calibrationBarLp.width)));
                    calibrationBarLp.y=Math.max(0,Math.min(calibrationBarStartY+dy,Math.max(0,sh-calibrationBarLp.height)));
                    try{wm.updateViewLayout(calibrationBar,calibrationBarLp);}catch(Exception ignored){}
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    prefs.edit().putInt("calibration_bar_x",calibrationBarLp.x).putInt("calibration_bar_y",calibrationBarLp.y).apply();
                    return true;
            }
            return false;
        });
    }

    private String visualAssignedState(String component) {
        String def = stateForComponent(component);
        if (!"visualIgor".equals(component) && !"visualMilo".equals(component) && !"visualLeon".equals(component) && !"visualRita".equals(component)) def = "MAP";
        return prefs.getString("visual_" + component + "_state", def);
    }

    private String visualScreenLabel(String st) {
        if ("PROFILE".equals(st)) return "PROFIL";
        if ("INVENTORY".equals(st)) return "INVENTAIRE";
        if ("ATTACK".equals(st)) return "ACTION";
        if ("COMM".equals(st)) return "COMM";
        if ("ALL".equals(st)) return "TOUS";
        return "SCANNER";
    }

    private void showVisualScreenChooser(String component) {
        final String[] values={"MAP","PROFILE","INVENTORY","ATTACK","COMM","ALL"};
        final String[] labels={"SCANNER","PROFIL","INVENTAIRE","ACTION","COMM","TOUS"};
        android.app.AlertDialog.Builder b=new android.app.AlertDialog.Builder(this);
        b.setTitle("Où afficher cet élément ?");
        b.setSingleChoiceItems(labels, -1, (d,which)->{
            String chosen=values[which];
            prefs.edit().putString("visual_"+component+"_state",chosen).apply();
            if(!"ALL".equals(chosen)){state=chosen;prefs.edit().putString("state",state).apply();}
            placementMode=false; d.dismiss(); rebuildAll();
        });
        android.app.AlertDialog dlg=b.create();
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O && dlg.getWindow()!=null) dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        dlg.show();
    }

    private String visualBehavior(String component) { return prefs.getString("visual_"+component+"_behavior","PASS"); }
    private String visualDestination(String component) { return prefs.getString("visual_"+component+"_destination","PROFILE"); }

    private void showVisualSetupChooser(String component) {
        final String[] screens={"MAP","PROFILE","INVENTORY","ATTACK","COMM","ALL"};
        final String[] labels={"SCANNER","PROFIL","INVENTAIRE","ACTION","COMM","TOUS"};
        android.app.AlertDialog.Builder b=new android.app.AlertDialog.Builder(this);
        b.setTitle("Niveau d’affichage");
        b.setItems(labels,(d,which)->{
            String chosen=screens[which]; prefs.edit().putString("visual_"+component+"_state",chosen).apply();
            showVisualBehaviorChooser(component);
        });
        android.app.AlertDialog dlg=b.create(); if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O && dlg.getWindow()!=null)dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); dlg.show();
    }

    private void showVisualBehaviorChooser(String component) {
        final String[] labels={"Décoratif · clic traversant","Naviguant · clic actif"};
        android.app.AlertDialog.Builder b=new android.app.AlertDialog.Builder(this); b.setTitle("Comportement de l’élément");
        b.setItems(labels,(d,which)->{
            if(which==0){prefs.edit().putString("visual_"+component+"_behavior","PASS").apply();rebuildAll();}
            else {prefs.edit().putString("visual_"+component+"_behavior","NAV").apply();showVisualDestinationChooser(component);}
        });
        android.app.AlertDialog dlg=b.create();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O&&dlg.getWindow()!=null)dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);dlg.show();
    }

    private void showVisualDestinationChooser(String component) {
        final String[] values={"MAP","PROFILE","INVENTORY","ATTACK","COMM"}; final String[] labels={"SCANNER","PROFIL","INVENTAIRE","ACTION","COMM"};
        android.app.AlertDialog.Builder b=new android.app.AlertDialog.Builder(this);b.setTitle("Destination du clic");
        b.setItems(labels,(d,which)->{prefs.edit().putString("visual_"+component+"_destination",values[which]).apply();rebuildAll();});
        android.app.AlertDialog dlg=b.create();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O&&dlg.getWindow()!=null)dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);dlg.show();
    }

    private void testVisualNavigation(String component) {
        for(VisualWindow vw:visualWindows) if(component.equals(vw.component)){
            float x=vw.lp.x+vw.lp.width/2f,y=vw.lp.y+vw.lp.height/2f;
            vw.lp.flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; try{wm.updateViewLayout(vw.root,vw.lp);}catch(Exception ignored){}
            boolean sent=PrimeOverlayAccessibilityService.tap(x,y);
            if(sent) handler.postDelayed(()->setState(visualDestination(component),true),180L);
            else {vw.lp.flags&=~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;try{wm.updateViewLayout(vw.root,vw.lp);}catch(Exception ignored){}}
            return;
        }
    }

    private void previousCalibrationStep(){ if(wizardComponentIndex<=0)return; wizardComponentIndex--; String c=currentWizardComponent();state=isVisualComponent(c)?visualAssignedState(c):stateForComponent(c);if("ALL".equals(state))state="MAP";placementMode=true;prefs.edit().putString("state",state).apply();rebuildAll(); }
    private void skipCalibrationStep(){ if(wizardComponents.isEmpty())return; String c=currentWizardComponent();prefs.edit().putBoolean("calibrated_component_"+c,false).apply();wizardComponentIndex++;if(wizardComponentIndex>=wizardComponents.size()){finishWizard();return;}String n=currentWizardComponent();state=isVisualComponent(n)?visualAssignedState(n):stateForComponent(n);if("ALL".equals(state))state="MAP";placementMode=true;prefs.edit().putString("state",state).apply();rebuildAll(); }

    private void cycleVisualScreen(String component) {
        String[] screens = new String[]{"MAP","PROFILE","INVENTORY","ATTACK","COMM","ALL"};
        String cur = visualAssignedState(component); int idx=0;
        for(int i=0;i<screens.length;i++) if(screens[i].equals(cur)){idx=i;break;}
        String next = screens[(idx+1)%screens.length];
        prefs.edit().putString("visual_"+component+"_state",next).apply();
        if(!"ALL".equals(next)) { state=next; prefs.edit().putString("state",state).apply(); }
        placementMode = false; // after choosing a screen, let the user navigate Prime first
        rebuildAll();
    }

    private String calibrationTitle() {
        if (!wizardCalibration || wizardComponents.isEmpty()) return "CALIBRATION · " + levelName() + "\nDéplace le grand capteur sur la vraie commande Prime.";
        String c = wizardComponents.get(Math.max(0, Math.min(wizardComponentIndex, wizardComponents.size()-1)));
        String hint;
        if ("sensorProfile".equals(c)) hint = "PROFIL · ACCÈS 1/2 · sur le Scanner, place le repère sur le premier accès Profil.";
        else if ("sensorProfile2".equals(c)) hint = "PROFIL · ACCÈS 2/2 · place le repère sur le second accès Profil.";
        else if ("sensorAction".equals(c)) hint = "CAPTEURS ACTION · place le repère au départ de tes swipes.";
        else if ("sensorInventoryDirect".equals(c)) hint = "ACCÈS DIRECT INVENTAIRE · sur le Scanner, place le repère sur le bouton Inventaire.";
        else if ("sensorCommDirect".equals(c)) hint = "COMM · ACCÈS 1/2 · place le repère sur le premier accès COMM.";
        else if ("sensorCommDirect2".equals(c)) hint = "COMM · ACCÈS 2/2 · place le repère sur le second accès COMM.";
        else if ("sensorProfileBack".equals(c)) hint = "CAPTEUR RETOUR PROFIL · ouvre Profil puis place le repère sur Retour.";
        else if ("sensorInventoryBack".equals(c)) hint = "CAPTEUR FERMER INVENTAIRE · ouvre Inventaire puis place le repère sur Fermer.";
        else if ("sensorAttackBack".equals(c)) hint = "CAPTEUR FERMER ACTION · ouvre Action puis place le repère sur Fermer.";
        else if ("sensorCommBack".equals(c)) hint = "CAPTEUR RETOUR COMM · ouvre COMM puis place le repère sur Retour/Fermer.";
        else if ("visualRedacted".equals(c)) hint = "VISUEL REDACTED · place sa tête exactement sur le logo voulu. Les clics traverseront totalement.";
        else if ("visualIgor".equals(c)) hint = "VISUEL IGOR · OUVRE PROFIL DANS PRIME, puis déplace IGOR où tu veux. Il sera totalement traversant.";
        else if ("visualMilo".equals(c)) hint = "VISUEL MILO · OUVRE INVENTAIRE DANS PRIME, puis déplace MILO où tu veux. Il sera totalement traversant.";
        else if ("visualLeon".equals(c)) hint = "VISUEL LEON · OUVRE ACTION DANS PRIME, puis déplace LEON où tu veux. Il sera totalement traversant.";
        else if ("visualRita".equals(c)) hint = "VISUEL RITA · OUVRE COMM DANS PRIME, puis déplace RITA où tu veux. Elle sera totalement traversante.";
        else if ("visualStateBeacon".equals(c)) hint = "BALISE DE NIVEAU · place le voyant où tu veux. Il affichera SCANNER / PROFIL / INVENTAIRE / ACTION en direct.";
        else if ("visualPulse".equals(c)) hint = "VOYANT LAB · place ce petit voyant lumineux décoratif où tu veux.";
        else if ("visualSecret".equals(c)) hint = "MARQUEUR SECRET · place ce petit symbole du Lab où tu veux.";
        else if ("visualCrosshair".equals(c)) hint = "VISEUR LAB · petit réticule purement décoratif, à placer où tu veux.";
        else if ("visualScanline".equals(c)) hint = "SCANLINE · petite barre technique du Lab, traversante.";
        else if ("visualCode".equals(c)) hint = "CODE LIVE · mini étiquette technique RBL // LIVE.";
        else hint = "COIN TECHNIQUE · petit angle lumineux à poser où tu veux.";
        if(isVisualComponent(c)) hint += "  Niveau : " + visualScreenLabel(visualAssignedState(c)) + " · " + ("NAV".equals(visualBehavior(c)) ? "NAVIGUANT → "+visualScreenLabel(visualDestination(c)) : "CLIC TRAVERSANT") + ". RÉGLER pour modifier.";
        hint += placementMode ? "  Mode PLACEMENT." : "  Mode NAVIGATION : Prime est entièrement cliquable.";
        return "LAB PRIME · ÉTAPE " + (wizardComponentIndex + 1) + "/" + wizardComponents.size() + "\n" + hint;
    }

    private void finishCalibrationStep() {
        if (wizardComponents.isEmpty()) { finishWizard(); return; }
        String component = wizardComponents.get(Math.max(0, Math.min(wizardComponentIndex, wizardComponents.size()-1)));
        prefs.edit().putBoolean("calibrated_component_" + component, true).apply();
        updateLegacyStateCalibration(stateForComponent(component));
        wizardComponentIndex++;
        if (wizardComponentIndex >= wizardComponents.size()) { finishWizard(); return; }
        String nextComponent = wizardComponents.get(wizardComponentIndex);
        state = isVisualComponent(nextComponent) ? visualAssignedState(nextComponent) : stateForComponent(nextComponent);
        if("ALL".equals(state)) state="MAP";
        placementMode = true;
        prefs.edit().putString("state", state).apply();
        rebuildAll();
    }

    private void finishWizard() {
        calibration = false;
        wizardCalibration = false;
        wizardComponents.clear();
        wizardComponentIndex = 0;
        state = "MAP";
        prefs.edit().putBoolean("calibrating", false).putString("state", state).apply();
        rebuildAll();
    }

    private String currentWizardComponent() {
        if (!calibration || wizardComponents.isEmpty()) return null;
        return wizardComponents.get(Math.max(0, Math.min(wizardComponentIndex, wizardComponents.size()-1)));
    }

    private boolean isSensorComponent(String c) { return c != null && c.startsWith("sensor"); }
    private boolean isVisualComponent(String c) { return c != null && c.startsWith("visual"); }
    private boolean needsCalibration(String c) { return isSensorComponent(c) || isVisualComponent(c); }

    private String stateForComponent(String c) {
        if ("sensorProfileBack".equals(c) || "visualIgor".equals(c)) return "PROFILE";
        if ("sensorInventoryBack".equals(c) || "visualMilo".equals(c)) return "INVENTORY";
        if ("sensorAttackBack".equals(c) || "visualLeon".equals(c)) return "ATTACK";
        if ("sensorCommBack".equals(c) || "visualRita".equals(c)) return "COMM";
        return "MAP";
    }

    private String sensorComponentFor(String s, String id) {
        if ("MAP".equals(s) && "profile".equals(id)) return "sensorProfile";
        if ("MAP".equals(s) && "profile2".equals(id)) return "sensorProfile2";
        if ("MAP".equals(s) && "action".equals(id)) return "sensorAction";
        if ("MAP".equals(s) && "inventoryDirect".equals(id)) return "sensorInventoryDirect";
        if ("MAP".equals(s) && "commDirect".equals(id)) return "sensorCommDirect";
        if ("MAP".equals(s) && "commDirect2".equals(id)) return "sensorCommDirect2";
        if ("PROFILE".equals(s) && "back".equals(id)) return "sensorProfileBack";
        if ("INVENTORY".equals(s) && "back".equals(id)) return "sensorInventoryBack";
        if ("ATTACK".equals(s) && "back".equals(id)) return "sensorAttackBack";
        if ("COMM".equals(s) && "back".equals(id)) return "sensorCommBack";
        return null;
    }

    private String firstComponentForState(String st) {
        if ("PROFILE".equals(st)) return "sensorProfileBack";
        if ("INVENTORY".equals(st)) return "sensorInventoryBack";
        if ("ATTACK".equals(st)) return "sensorAttackBack";
        if ("COMM".equals(st)) return "sensorCommBack";
        return "sensorProfile";
    }

    private boolean isComponentEnabled(String c) { return prefs.getBoolean("enabled_component_" + c, "neon".equals(c)); }
    private boolean isComponentCalibrated(String c) { return !needsCalibration(c) || prefs.getBoolean("calibrated_component_" + c, false); }

    private void prepareSelectiveWizard() {
        wizardComponents.clear();
        // Sensors first: learn the navigation graph before decorating it.
        for (String c : COMPONENTS) if (isSensorComponent(c) && isComponentEnabled(c) && !isComponentCalibrated(c)) wizardComponents.add(c);
        // Visuals second: they are completely touch-through once validated.
        for (String c : COMPONENTS) if (isVisualComponent(c) && isComponentEnabled(c) && !isComponentCalibrated(c)) wizardComponents.add(c);
        wizardComponentIndex = 0;
    }

    private void applyComponentSelection(String csv) {
        java.util.HashSet<String> selected = new java.util.HashSet<>();
        for (String raw : csv.split(",")) { String c = raw.trim(); if (!c.isEmpty()) selected.add(c); }
        SharedPreferences.Editor ed = prefs.edit().putBoolean("selection_initialized_v46", true);
        for (String c : COMPONENTS) {
            boolean was = isComponentEnabled(c);
            boolean now = selected.contains(c);
            ed.putBoolean("enabled_component_" + c, now);
            if (was && !now && needsCalibration(c)) ed.putBoolean("calibrated_component_" + c, false);
        }
        ed.apply();
    }

    private void updateLegacyStateCalibration(String st) {
        boolean any=false, all=true;
        for (String c : COMPONENTS) if (isSensorComponent(c) && stateForComponent(c).equals(st) && isComponentEnabled(c)) { any=true; all &= isComponentCalibrated(c); }
        prefs.edit().putBoolean("calibrated_" + st, any && all).apply();
    }

    private void buildHotspots() { if (true) return; // PROD 1.1.0: interactive HUD disabled
        JSONArray arr = readHotspots(state);
        String target = currentWizardComponent();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String component = sensorComponentFor(state, o.optString("id", ""));
            if (component == null || !isComponentEnabled(component)) continue;
            if (calibration) {
                if (!component.equals(target)) continue;
                addHotspotCalibration(o);
            } else {
                if (!isComponentCalibrated(component)) continue;
                addMicroConstellation(o);
            }
        }
    }

    private void addHotspotCalibration(JSONObject o) {
        final HotspotWindow hw = new HotspotWindow();
        hw.data = o;
        hw.root = new FrameLayout(this);
        String label = o.optString("label", "CAPTEUR");
        String id = o.optString("id", "");
        GradientDrawable dbg = rounded(0x442EEA78, accentForState(), 48, 2);
        dbg.setShape(GradientDrawable.OVAL);
        hw.root.setBackground(dbg);
        TextView t = text(("action".equals(id) ? "CAPTEURS ACTION\n↖  ↑  ↗" : label) + "\nzone de placement", 8f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        hw.root.addView(t, new FrameLayout.LayoutParams(-1, -1));

        int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
        // During calibration every sensor starts in the centre of the Scanner so it is impossible to miss.
        // Its saved geometry is only updated when the user moves/resizes it.
        int w=Math.max(dp(92), Math.min(dp(124),(int)Math.round(o.optDouble("w",.2)*sw)));
        int h=Math.max(dp(92), Math.min(dp(124),(int)Math.round(o.optDouble("h",.1)*sh)));
        int x=(sw-w)/2, y=Math.max(dp(120),(sh-h)/2);
        int type=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int calFlags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if(!placementMode) calFlags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        hw.lp=new WindowManager.LayoutParams(w,h,type,calFlags,PixelFormat.TRANSLUCENT);
        hw.lp.gravity=Gravity.TOP|Gravity.START; hw.lp.x=x; hw.lp.y=y;
        wm.addView(hw.root,hw.lp); if(placementMode) hw.root.setOnTouchListener((v,e)->handleHotspotTouch(hw,e)); hotspotWindows.add(hw);
    }

    /** Final sensors are deliberately microscopic: four 4 px dots inside a ~10 px constellation. */
    private void addMicroConstellation(JSONObject o) {
        int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
        int cx=(int)Math.round((o.optDouble("x",.1)+o.optDouble("w",.1)/2d)*sw);
        int cy=(int)Math.round((o.optDouble("y",.1)+o.optDouble("h",.1)/2d)*sh);
        HotspotWindow hw=new HotspotWindow(); hw.data=o; hw.root=new FrameLayout(this);
        int dot=Math.max(2,MICRO_DOT_PX/2), size=MICRO_SPREAD_PX;
        int[][] pos=new int[][]{{1,size/2-dot/2},{size-dot-1,size/2-dot/2},{size/2-dot/2,1},{size/2-dot/2,size-dot-1}};
        for(int[] q:pos){
            View v=new View(this); v.setBackground(rounded(accentForState(),accentForState(),99,0));
            FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(dot,dot); vp.leftMargin=q[0]; vp.topMargin=q[1]; hw.root.addView(v,vp);
        }
        int type=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int f=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if(!PrimeOverlayAccessibilityService.isReady())f|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        hw.lp=new WindowManager.LayoutParams(size,size,type,f,PixelFormat.TRANSLUCENT);
        hw.lp.gravity=Gravity.TOP|Gravity.START; hw.lp.x=cx-size/2; hw.lp.y=cy-size/2;
        wm.addView(hw.root,hw.lp); hw.root.setOnTouchListener((v,e)->handleHotspotTouch(hw,e)); hotspotWindows.add(hw);
    }

    private void buildVisuals(){
        String target=currentWizardComponent();
        for(String c:COMPONENTS){
            if(!isVisualComponent(c) || !isComponentEnabled(c)) continue;
            if(calibration){
                if(c.equals(target)) addVisual(c,true);
            }else if(isComponentCalibrated(c)){
                String assigned=visualAssignedState(c);
                if("ALL".equals(assigned) || state.equals(assigned)) addVisual(c,false);
            }
        }
    }

    private int drawableForVisual(String c){
        String n="redacted_dino_cutout";
        if("visualIgor".equals(c))n="igor_overlay";
        else if("visualMilo".equals(c))n="milo_overlay";
        else if("visualLeon".equals(c))n="leon_overlay";
        else if("visualRita".equals(c))n="rita_overlay";
        return getResources().getIdentifier(n,"drawable",getPackageName());
    }

    private double[] visualDefaults(String c){
        if("visualStateBeacon".equals(c))return new double[]{.035,.135,.16,.030};
        if("visualPulse".equals(c))return new double[]{.92,.24,.045,.03};
        if("visualSecret".equals(c))return new double[]{.055,.72,.055,.038};
        if("visualCrosshair".equals(c))return new double[]{.86,.60,.07,.045};
        if("visualScanline".equals(c))return new double[]{.34,.12,.32,.035};
        if("visualCode".equals(c))return new double[]{.04,.64,.20,.045};
        if("visualCorner".equals(c))return new double[]{.86,.76,.07,.05};
        if("visualTubeH".equals(c))return new double[]{.18,.08,.38,.035};
        if("visualTubeV".equals(c))return new double[]{.94,.30,.035,.28};
        if("visualLiquidTube".equals(c))return new double[]{.84,.30,.08,.18};
        if("visualCable".equals(c))return new double[]{.05,.52,.26,.06};
        if("visualCableCoil".equals(c))return new double[]{.78,.62,.12,.08};
        if("visualScreen".equals(c))return new double[]{.05,.25,.28,.09};
        if("visualTerminal".equals(c))return new double[]{.67,.25,.28,.10};
        if("visualCalculator".equals(c))return new double[]{.05,.38,.18,.10};
        if("visualScope".equals(c))return new double[]{.67,.40,.28,.08};
        if("visualGauge".equals(c))return new double[]{.06,.61,.12,.08};
        if("visualSegments".equals(c))return new double[]{.38,.20,.18,.06};
        if("visualRadar".equals(c))return new double[]{.80,.52,.12,.08};
        if("visualBattery".equals(c))return new double[]{.38,.72,.22,.05};
        if("visualWarning".equals(c))return new double[]{.05,.80,.16,.055};
        if("visualVent".equals(c))return new double[]{.76,.80,.20,.055};
        if("visualAntenna".equals(c))return new double[]{.90,.10,.07,.08};
        if("visualData".equals(c))return new double[]{.66,.68,.28,.08};
        if("visualReactor".equals(c))return new double[]{.43,.48,.14,.09};
        if("visualBolts".equals(c))return new double[]{.25,.86,.20,.04};
        if("visualIgor".equals(c))return new double[]{.055,.17,.14,.09};
        if("visualMilo".equals(c))return new double[]{.80,.17,.14,.09};
        if("visualLeon".equals(c))return new double[]{.80,.17,.14,.09};
        if("visualRita".equals(c))return new double[]{.80,.17,.14,.09};
        return new double[]{.68,.15,.14,.09};
    }

    private void addVisual(String component,boolean edit){
        double[] def=visualDefaults(component);
        int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
        double xD=Double.longBitsToDouble(prefs.getLong("visual_"+component+"_x",Double.doubleToRawLongBits(def[0])));
        double yD=Double.longBitsToDouble(prefs.getLong("visual_"+component+"_y",Double.doubleToRawLongBits(def[1])));
        double wD=Double.longBitsToDouble(prefs.getLong("visual_"+component+"_w",Double.doubleToRawLongBits(def[2])));
        double hD=Double.longBitsToDouble(prefs.getLong("visual_"+component+"_h",Double.doubleToRawLongBits(def[3])));
        // Every visual currently being configured starts clearly in the middle. Existing validated visuals
        // never enter this branch, so their saved positions are preserved during ordinary reconfiguration.
        if(edit){
            if(component.startsWith("visualRedacted")||component.startsWith("visualIgor")||component.startsWith("visualMilo")||component.startsWith("visualLeon")||component.startsWith("visualRita")){wD=.24;hD=.15;}
            else if("visualStateBeacon".equals(component)){wD=.30;hD=.055;}
            else {wD=Math.max(wD,.14);hD=Math.max(hD,.075);}
            xD=Math.max(0d,(1d-wD)/2d);
            yD=Math.max(.18d,(1d-hD)/2d);
        }
        VisualWindow vw=new VisualWindow(); vw.component=component; vw.root=new FrameLayout(this);

        if("visualStateBeacon".equals(component)){
            TextView badge=text("● "+shortLevelName(),7f,accentForState(),true);
            badge.setGravity(Gravity.CENTER);badge.setBackground(rounded(0x9907110B,accentForState(),10,1));
            vw.root.addView(badge,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualPulse".equals(component)){
            TextView pulse=text("●",18f,accentForState(),true);pulse.setGravity(Gravity.CENTER);vw.root.addView(pulse,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualSecret".equals(component)){
            TextView secret=text("⌬",20f,accentForState(),true);secret.setGravity(Gravity.CENTER);vw.root.addView(secret,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualCrosshair".equals(component)){
            TextView x=text("⌖",22f,accentForState(),true);x.setGravity(Gravity.CENTER);vw.root.addView(x,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualScanline".equals(component)){
            TextView x=text("━━━━  SCAN  ━━━━",8f,accentForState(),true);x.setGravity(Gravity.CENTER);vw.root.addView(x,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualCode".equals(component)){
            TextView x=text("RBL // LIVE",8f,accentForState(),true);x.setGravity(Gravity.CENTER);vw.root.addView(x,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualCorner".equals(component)){
            TextView x=text("⌟",24f,accentForState(),true);x.setGravity(Gravity.CENTER);vw.root.addView(x,new FrameLayout.LayoutParams(-1,-1));
        }else if("visualTubeH".equals(component)){ addTechText(vw,"━━━◉━━━━━━━━◉━━━",11f);
        }else if("visualTubeV".equals(component)){ addTechText(vw,"┃\n●\n┃\n●\n┃",11f);
        }else if("visualLiquidTube".equals(component)){ addTechText(vw,"╭──╮\n│░░│\n│▓▓│\n│▓▓│\n╰──╯",10f);
        }else if("visualCable".equals(component)){ addTechText(vw,"◉~~~~~~⌁~~~~▣",10f);
        }else if("visualCableCoil".equals(component)){ addTechText(vw,"◎◎◎  ⌁",15f);
        }else if("visualScreen".equals(component)){ addTechText(vw,"┌ DIAG ─────┐\n│ SYS  ONLINE │\n│ SIG  98.7%  │\n└───────────┘",8f);
        }else if("visualTerminal".equals(component)){ addTechText(vw,"RBL> SCAN\n01F A7 3C\nLINK: OK",8f);
        }else if("visualCalculator".equals(component)){ addTechText(vw,"┌ LEON ┐\n│ 125×8 │\n│=1000AP│\n└───────┘",8f);
        }else if("visualScope".equals(component)){ addTechText(vw,"OSC  _/\\__/\\_//\\__",9f);
        }else if("visualGauge".equals(component)){ addTechText(vw,"◜ 72% ◝\n   ╱",10f);
        }else if("visualSegments".equals(component)){ addTechText(vw,"88:88:88",14f);
        }else if("visualRadar".equals(component)){ addTechText(vw,"◉ )))\n RADAR",10f);
        }else if("visualBattery".equals(component)){ addTechText(vw,"ENERGY [██████░░]",8f);
        }else if("visualWarning".equals(component)){ addTechText(vw,"⚡ HIGH VOLTAGE",9f);
        }else if("visualVent".equals(component)){ addTechText(vw,"≡≡≡≡≡≡≡≡",12f);
        }else if("visualAntenna".equals(component)){ addTechText(vw,")))\n │\n╱╲",10f);
        }else if("visualData".equals(component)){ addTechText(vw,"A7F2 09C1\nSYNC 0110\nRX  ███░",8f);
        }else if("visualReactor".equals(component)){ addTechText(vw,"◉\nCORE",15f);
        }else if("visualBolts".equals(component)){ addTechText(vw,"• ───────── •",10f);
        }else{
            ImageView img=new ImageView(this); int dr=drawableForVisual(component); if(dr!=0)img.setImageResource(dr); img.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            vw.root.addView(img,new FrameLayout.LayoutParams(-1,-1));
        }
        if(edit){
            vw.root.setBackground(rounded(0x44101010,accentForState(),18,2));
            TextView tag=text("↔ DÉPLACE-MOI     ◢ taille",8f,Color.WHITE,true);tag.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);tag.setPadding(dp(3),0,dp(3),dp(2));vw.root.addView(tag,new FrameLayout.LayoutParams(-1,-1));
        }
        int type=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        boolean navVisual=!edit && "NAV".equals(visualBehavior(component));
        if((!edit && !navVisual) || (edit && !placementMode))flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        vw.lp=new WindowManager.LayoutParams(Math.max(dp(40),(int)(wD*sw)),Math.max(dp(40),(int)(hD*sh)),type,flags,PixelFormat.TRANSLUCENT);
        vw.lp.gravity=Gravity.TOP|Gravity.START; vw.lp.x=(int)(xD*sw); vw.lp.y=(int)(yD*sh); clamp(vw.lp,sw,sh);
        wm.addView(vw.root,vw.lp);
        if(edit && placementMode)vw.root.setOnTouchListener((v,e)->handleVisualCalibration(vw,e));
        else if(!edit && navVisual) vw.root.setOnClickListener(v->{ float tx=vw.lp.x+vw.lp.width/2f,ty=vw.lp.y+vw.lp.height/2f; vw.lp.flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;try{wm.updateViewLayout(vw.root,vw.lp);}catch(Exception ignored){} boolean sent=PrimeOverlayAccessibilityService.tap(tx,ty); if(sent)handler.postDelayed(()->setState(visualDestination(component),true),180L); else {vw.lp.flags&=~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;try{wm.updateViewLayout(vw.root,vw.lp);}catch(Exception ignored){}} });
        visualWindows.add(vw);
    }

    private void addTechText(VisualWindow vw,String value,float size){
        TextView x=text(value,size,accentForState(),true); x.setGravity(Gravity.CENTER);
        x.setShadowLayer(dp(5),0,0,accentForState());
        vw.root.addView(x,new FrameLayout.LayoutParams(-1,-1));
    }

    private boolean handleVisualCalibration(VisualWindow vw,MotionEvent e){
        int sw=getResources().getDisplayMetrics().widthPixels,sh=getResources().getDisplayMetrics().heightPixels;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: vw.downRawX=e.getRawX();vw.downRawY=e.getRawY();vw.startX=vw.lp.x;vw.startY=vw.lp.y;vw.startW=vw.lp.width;vw.startH=vw.lp.height;vw.resizing=e.getX()>vw.lp.width-dp(24)&&e.getY()>vw.lp.height-dp(24);return true;
            case MotionEvent.ACTION_MOVE: int dx=Math.round(e.getRawX()-vw.downRawX),dy=Math.round(e.getRawY()-vw.downRawY);if(vw.resizing){vw.lp.width=Math.max(dp(30),vw.startW+dx);vw.lp.height=Math.max(dp(30),vw.startH+dy);}else{vw.lp.x=vw.startX+dx;vw.lp.y=vw.startY+dy;}clamp(vw.lp,sw,sh);try{wm.updateViewLayout(vw.root,vw.lp);}catch(Exception ignored){}return true;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: clamp(vw.lp,sw,sh);saveVisualGeometry(vw,sw,sh);return true;
            default:return true;
        }
    }

    private void saveVisualGeometry(VisualWindow vw,int sw,int sh){
        prefs.edit()
            .putLong("visual_"+vw.component+"_x",Double.doubleToRawLongBits((double)vw.lp.x/sw))
            .putLong("visual_"+vw.component+"_y",Double.doubleToRawLongBits((double)vw.lp.y/sh))
            .putLong("visual_"+vw.component+"_w",Double.doubleToRawLongBits((double)vw.lp.width/sw))
            .putLong("visual_"+vw.component+"_h",Double.doubleToRawLongBits((double)vw.lp.height/sh)).apply();
    }

    private boolean handleHotspotTouch(HotspotWindow hw, MotionEvent e) {
        if (calibration) return handleCalibrationTouch(hw, e);
        int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                hw.downRawX=e.getRawX(); hw.downRawY=e.getRawY();
                hw.startX=hw.lp.x; hw.startY=hw.lp.y; hw.dragging=false;
                return true;
            case MotionEvent.ACTION_MOVE:
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                float sx=hw.downRawX, sy=hw.downRawY, ex=e.getRawX(), ey=e.getRawY();
                replayAndTransition(hw, sx, sy, ex, ey);
                return true;
            default: return true;
        }
    }

    private boolean handleCalibrationTouch(HotspotWindow hw, MotionEvent e) {
        int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                hw.downRawX=e.getRawX(); hw.downRawY=e.getRawY(); hw.startX=hw.lp.x; hw.startY=hw.lp.y; hw.startW=hw.lp.width; hw.startH=hw.lp.height;
                hw.resizing = e.getX() > hw.lp.width - dp(30) && e.getY() > hw.lp.height - dp(30);
                return true;
            case MotionEvent.ACTION_MOVE:
                int dx=Math.round(e.getRawX()-hw.downRawX), dy=Math.round(e.getRawY()-hw.downRawY);
                if(hw.resizing){ hw.lp.width=Math.max(dp(58),hw.startW+dx); hw.lp.height=Math.max(dp(58),hw.startH+dy); }
                else { hw.lp.x=hw.startX+dx; hw.lp.y=hw.startY+dy; }
                clamp(hw.lp, sw, sh);
                try{wm.updateViewLayout(hw.root,hw.lp);}catch(Exception ignored){}
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                clamp(hw.lp, sw, sh);
                saveGeometry(hw, sw, sh);
                return true;
            default:return true;
        }
    }

    private void replayAndTransition(HotspotWindow hw, float sx,float sy,float ex,float ey) {
        float dx=ex-sx, dy=ey-sy;
        String gesture="tap";
        float threshold=dp(28);
        if(Math.abs(dx)>threshold||Math.abs(dy)>threshold){
            if(Math.abs(dx)>Math.abs(dy)) gesture=dx>0?"right":"left";
            else gesture=dy>0?"down":"up";
        }
        hw.replaying = true;
        temporarilyPassThrough(hw, true);
        boolean sent = PrimeOverlayAccessibilityService.replay(sx,sy,ex,ey, gesture.equals("tap")?55L:260L);
        final String g=gesture;
        final long restoreDelay = gesture.equals("tap") ? 140L : 360L;
        handler.postDelayed(()->{
            hw.replaying = false;
            temporarilyPassThrough(hw, false);
            if(sent) applyTransition(hw.data, g);
        }, restoreDelay);
    }

    private void temporarilyPassThrough(HotspotWindow hw, boolean pass) {
        if (pass) hw.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else if (visible && isPrimeForegroundConfirmed() && PrimeOverlayAccessibilityService.isReady())
            hw.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try{wm.updateViewLayout(hw.root,hw.lp);}catch(Exception ignored){}
    }

    private void applyTransition(JSONObject hotspot, String gesture) {
        String next = "";
        String id = hotspot.optString("id", "");
        if (state.equals("MAP")) {
            if ((id.equals("profile") || id.equals("profile2")) && gesture.equals("tap")) next="PROFILE";
            if (id.equals("inventoryDirect") && gesture.equals("tap")) next="INVENTORY";
            if ((id.equals("commDirect") || id.equals("commDirect2")) && gesture.equals("tap")) next="COMM";
            if (id.equals("action") && gesture.equals("up")) next="ATTACK";
            if (id.equals("action") && gesture.equals("left")) next="INVENTORY";
            if (id.equals("action") && gesture.equals("right")) next="COMM";
        } else if ((state.equals("PROFILE")||state.equals("INVENTORY")||state.equals("ATTACK")||state.equals("COMM")) && id.equals("back")) {
            next = history.isEmpty()?"MAP":history.pop();
            if(!next.isEmpty()) setState(next, false);
            return;
        }
        if(!next.isEmpty()) setState(next, true);
    }

    private void performConfiguredGesture(String sourceState, String id, String gesture) {
        try {
            JSONArray arr = readHotspots(sourceState);
            JSONObject target = null;
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.optJSONObject(i);
                if(o!=null && id.equals(o.optString("id"))) { target=o; break; }
            }
            if(target==null)return;
            int sw=getResources().getDisplayMetrics().widthPixels, sh=getResources().getDisplayMetrics().heightPixels;
            float x=(float)((target.optDouble("x",.1)+target.optDouble("w",.1)/2d)*sw);
            float y=(float)((target.optDouble("y",.1)+target.optDouble("h",.1)/2d)*sh);
            float ex=x, ey=y;
            float travel=dp(115);
            if("left".equals(gesture))ex=x-travel;
            else if("right".equals(gesture))ex=x+travel;
            else if("up".equals(gesture))ey=y-travel;
            else if("down".equals(gesture))ey=y+travel;
            PrimeOverlayAccessibilityService.replay(x,y,ex,ey,"tap".equals(gesture)?55L:260L);
        } catch(Exception ignored) {}
    }

    private void setState(String next, boolean remember) {
        next=normalizeState(next);
        if(next.equals(state)) return;
        if(remember) history.push(state);
        state=next;
        prefs.edit().putString("state",state).apply();
        rebuildAll();
    }

    private JSONArray readHotspots(String s) {
        try { return new JSONArray(prefs.getString("hotspots_"+s, defaultsFor(s).toString())); }
        catch(Exception e){ return defaultsFor(s); }
    }

    private void saveGeometry(HotspotWindow hw,int sw,int sh){
        try{
            JSONArray arr=readHotspots(state);
            String id=hw.data.optString("id");
            for(int i=0;i<arr.length();i++){
                JSONObject o=arr.optJSONObject(i); if(o==null||!id.equals(o.optString("id")))continue;
                o.put("x",Math.max(0d,Math.min(1d,(double)hw.lp.x/sw)));
                o.put("y",Math.max(0d,Math.min(1d,(double)hw.lp.y/sh)));
                o.put("w",Math.max(.04d,Math.min(1d,(double)hw.lp.width/sw)));
                o.put("h",Math.max(.03d,Math.min(1d,(double)hw.lp.height/sh)));
            }
            prefs.edit().putString("hotspots_"+state,arr.toString()).apply();
        }catch(Exception ignored){}
    }

    private JSONArray defaultsFor(String s) {
        JSONArray a=new JSONArray();
        try{
            if(s.equals("MAP")){
                a.put(hs("profile","PROFIL / accès 1",.60,.045,.28,.085));
                a.put(hs("profile2","PROFIL / accès 2",.06,.045,.18,.085));
                a.put(hs("action","ACTION / swipes",.36,.790,.28,.115));
                a.put(hs("inventoryDirect","INVENTAIRE / accès direct",.80,.325,.13,.075));
                a.put(hs("commDirect","COMM / accès 1",.80,.245,.13,.075));
                a.put(hs("commDirect2","COMM / accès 2",.06,.245,.13,.075));
            }else if(s.equals("PROFILE")){
                a.put(hs("back","IGOR / retour",.01,.035,.20,.085));
            }else if(s.equals("INVENTORY")){
                a.put(hs("back","MILO / fermer",.405,.845,.19,.085));
            }else if(s.equals("ATTACK")){
                a.put(hs("back","LEON / fermer",.405,.845,.19,.085));
            }else if(s.equals("COMM")){
                a.put(hs("back","RITA / retour",.01,.035,.20,.085));
            }
        }catch(Exception ignored){}
        return a;
    }

    private JSONObject hs(String id,String label,double x,double y,double w,double h)throws Exception{
        JSONObject o=new JSONObject();o.put("id",id);o.put("label",label);o.put("x",x);o.put("y",y);o.put("w",w);o.put("h",h);return o;
    }

    private void ensureDefaultConfig(){
        for(String st:new String[]{"MAP","PROFILE","INVENTORY","ATTACK","COMM"}){
            if(!prefs.contains("hotspots_"+st))prefs.edit().putString("hotspots_"+st,defaultsFor(st).toString()).apply();
        }
        if(!prefs.getBoolean("selection_initialized_v46", false)){
            SharedPreferences.Editor ed=prefs.edit().putBoolean("selection_initialized_v46", true);
            // TEST-46 migration: old logical components become separate sensor + visual layers.
            boolean oldProfile=prefs.getBoolean("enabled_component_profile",true);
            boolean oldAction=prefs.getBoolean("enabled_component_action",true);
            boolean oldPB=prefs.getBoolean("enabled_component_profileBack",true);
            boolean oldIB=prefs.getBoolean("enabled_component_inventoryBack",true);
            boolean oldAB=prefs.getBoolean("enabled_component_attackBack",true);
            ed.putBoolean("enabled_component_neon",true);
            ed.putBoolean("enabled_component_sensorProfile",oldProfile);
            ed.putBoolean("enabled_component_sensorAction",oldAction);
            ed.putBoolean("enabled_component_sensorProfileBack",oldPB);
            ed.putBoolean("enabled_component_sensorInventoryBack",oldIB);
            ed.putBoolean("enabled_component_sensorAttackBack",oldAB);
            ed.putBoolean("enabled_component_visualRedacted",oldProfile);
            ed.putBoolean("enabled_component_visualIgor",oldPB);
            ed.putBoolean("enabled_component_visualMilo",oldIB);
            ed.putBoolean("enabled_component_visualLeon",oldAB);
            ed.putBoolean("enabled_component_visualStateBeacon",true);
            ed.putBoolean("enabled_component_visualPulse",false);
            ed.putBoolean("enabled_component_visualSecret",false);
            ed.putBoolean("calibrated_component_sensorProfile",prefs.getBoolean("calibrated_component_profile",prefs.getBoolean("calibrated_MAP",false)));
            ed.putBoolean("calibrated_component_sensorAction",prefs.getBoolean("calibrated_component_action",prefs.getBoolean("calibrated_MAP",false)));
            ed.putBoolean("calibrated_component_sensorProfileBack",prefs.getBoolean("calibrated_component_profileBack",prefs.getBoolean("calibrated_PROFILE",false)));
            ed.putBoolean("calibrated_component_sensorInventoryBack",prefs.getBoolean("calibrated_component_inventoryBack",prefs.getBoolean("calibrated_INVENTORY",false)));
            ed.putBoolean("calibrated_component_sensorAttackBack",prefs.getBoolean("calibrated_component_attackBack",prefs.getBoolean("calibrated_ATTACK",false)));
            // Visuals intentionally ask for one precise placement in TEST-46.
            ed.putBoolean("calibrated_component_visualRedacted",false).putBoolean("calibrated_component_visualIgor",false).putBoolean("calibrated_component_visualMilo",false).putBoolean("calibrated_component_visualLeon",false);
            ed.apply();
        }
        if(!prefs.getBoolean("migration_v47_decor",false)){
            prefs.edit().putBoolean("migration_v47_decor",true)
                .putBoolean("enabled_component_visualStateBeacon",true)
                .putBoolean("enabled_component_visualPulse",false)
                .putBoolean("enabled_component_visualSecret",false)
                .putBoolean("enabled_component_visualCrosshair",false)
                .putBoolean("enabled_component_visualScanline",false)
                .putBoolean("enabled_component_visualCode",false)
                .putBoolean("enabled_component_visualCorner",false)
                .putBoolean("calibrated_component_visualStateBeacon",false)
                .putBoolean("calibrated_component_visualPulse",false)
                .putBoolean("calibrated_component_visualSecret",false)
                .putBoolean("calibrated_component_visualCrosshair",false)
                .putBoolean("calibrated_component_visualScanline",false)
                .putBoolean("calibrated_component_visualCode",false)
                .putBoolean("calibrated_component_visualCorner",false).apply();
        }

        if(!prefs.getBoolean("migration_v48_labprops",false)){
            SharedPreferences.Editor e=prefs.edit().putBoolean("migration_v48_labprops",true);
            String[] props=new String[]{"visualTubeH","visualTubeV","visualLiquidTube","visualCable","visualCableCoil","visualScreen","visualTerminal","visualCalculator","visualScope","visualGauge","visualSegments","visualRadar","visualBattery","visualWarning","visualVent","visualAntenna","visualData","visualReactor","visualBolts"};
            for(String c:props){e.putBoolean("enabled_component_"+c,false);e.putBoolean("calibrated_component_"+c,false);}
            e.apply();
        }
        if(!prefs.getBoolean("migration_v51_nav",false)){
            SharedPreferences.Editor ed=prefs.edit();
            ed.putBoolean("enabled_component_sensorInventoryDirect",true)
              .putBoolean("enabled_component_sensorCommDirect",true)
              .putBoolean("enabled_component_sensorCommBack",true)
              .putBoolean("enabled_component_visualRita",true)
              .putBoolean("calibrated_component_sensorInventoryDirect",false)
              .putBoolean("calibrated_component_sensorCommDirect",false)
              .putBoolean("calibrated_component_sensorCommBack",false)
              .putBoolean("calibrated_component_visualRita",false);
            double bw=Double.longBitsToDouble(prefs.getLong("visual_visualStateBeacon_w",Double.doubleToRawLongBits(.16)));
            double bh=Double.longBitsToDouble(prefs.getLong("visual_visualStateBeacon_h",Double.doubleToRawLongBits(.030)));
            if(bw>.22)ed.putLong("visual_visualStateBeacon_w",Double.doubleToRawLongBits(.16));
            if(bh>.055)ed.putLong("visual_visualStateBeacon_h",Double.doubleToRawLongBits(.030));
            ed.putBoolean("migration_v51_nav",true).apply();
        }
        if(!prefs.getBoolean("migration_v55_multientry",false)){
            prefs.edit().putBoolean("enabled_component_sensorProfile2",true)
                .putBoolean("enabled_component_sensorCommDirect2",true)
                .putBoolean("calibrated_component_sensorProfile2",false)
                .putBoolean("calibrated_component_sensorCommDirect2",false)
                .putBoolean("migration_v55_multientry",true).apply();
            try{
                JSONArray map=readHotspots("MAP"); boolean hasP2=false,hasC2=false;
                for(int i=0;i<map.length();i++){JSONObject o=map.optJSONObject(i);if(o==null)continue;String id=o.optString("id");if("profile2".equals(id))hasP2=true;if("commDirect2".equals(id))hasC2=true;}
                if(!hasP2)map.put(hs("profile2","PROFIL / accès 2",.06,.045,.18,.085));
                if(!hasC2)map.put(hs("commDirect2","COMM / accès 2",.06,.245,.13,.075));
                prefs.edit().putString("hotspots_MAP",map.toString()).apply();
            }catch(Exception ignored){}
        }
    }

    private boolean isStateCalibrated(String s){ return prefs.getBoolean("calibrated_" + normalizeState(s), false); }

    public static void resetCalibration(Context c){
        SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        p.edit()
            .remove("hotspots_MAP").remove("hotspots_PROFILE").remove("hotspots_INVENTORY").remove("hotspots_ATTACK").remove("hotspots_COMM")
            .remove("calibrated_MAP").remove("calibrated_PROFILE").remove("calibrated_INVENTORY").remove("calibrated_ATTACK").remove("calibrated_COMM")
            .remove("calibrated_component_profile").remove("calibrated_component_action").remove("calibrated_component_profileBack").remove("calibrated_component_inventoryBack").remove("calibrated_component_attackBack")
            .remove("calibrated_component_sensorProfile").remove("calibrated_component_sensorProfile2").remove("calibrated_component_sensorAction").remove("calibrated_component_sensorInventoryDirect").remove("calibrated_component_sensorCommDirect").remove("calibrated_component_sensorCommDirect2").remove("calibrated_component_sensorProfileBack").remove("calibrated_component_sensorInventoryBack").remove("calibrated_component_sensorAttackBack").remove("calibrated_component_sensorCommBack")
            .remove("calibrated_component_visualRedacted").remove("calibrated_component_visualIgor").remove("calibrated_component_visualMilo").remove("calibrated_component_visualLeon").remove("calibrated_component_visualRita")
            .remove("calibrated_component_visualStateBeacon").remove("calibrated_component_visualPulse").remove("calibrated_component_visualSecret")
            .remove("calibrated_component_visualCrosshair").remove("calibrated_component_visualScanline").remove("calibrated_component_visualCode").remove("calibrated_component_visualCorner").remove("calibrated_component_visualTubeH").remove("calibrated_component_visualTubeV").remove("calibrated_component_visualLiquidTube").remove("calibrated_component_visualCable").remove("calibrated_component_visualCableCoil").remove("calibrated_component_visualScreen").remove("calibrated_component_visualTerminal").remove("calibrated_component_visualCalculator").remove("calibrated_component_visualScope").remove("calibrated_component_visualGauge").remove("calibrated_component_visualSegments").remove("calibrated_component_visualRadar").remove("calibrated_component_visualBattery").remove("calibrated_component_visualWarning").remove("calibrated_component_visualVent").remove("calibrated_component_visualAntenna").remove("calibrated_component_visualData").remove("calibrated_component_visualReactor").remove("calibrated_component_visualBolts")
            .putString("state","MAP").apply();
    }

    private void clamp(WindowManager.LayoutParams lp,int sw,int sh){
        lp.width=Math.min(lp.width,sw);lp.height=Math.min(lp.height,sh);
        lp.x=Math.max(0,Math.min(lp.x,Math.max(0,sw-lp.width)));
        lp.y=Math.max(0,Math.min(lp.y,Math.max(0,sh-lp.height)));
    }

    private boolean isPrimeForegroundConfirmed(){
        if (PrimeOverlayAccessibilityService.isReady() && PrimeOverlayAccessibilityService.isPackageForeground(INGRESS_PACKAGE)) return true;
        return hasUsageAccess() && isIngressForeground();
    }

    private boolean hasUsageAccess(){
        try{
            android.app.AppOpsManager ao=(android.app.AppOpsManager)getSystemService(APP_OPS_SERVICE);
            return ao!=null&&ao.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),getPackageName())==android.app.AppOpsManager.MODE_ALLOWED;
        }catch(Exception e){return false;}
    }

    private boolean isIngressForeground(){
        if(!hasUsageAccess())return false;
        try{
            UsageStatsManager usm=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE); if(usm==null)return false;
            long end=System.currentTimeMillis();
            long start=Math.max(0L, Math.min(lastUsageEventCheck - 1000L, end - 15000L));
            UsageEvents ev=usm.queryEvents(start,end);
            UsageEvents.Event e=new UsageEvents.Event();
            while(ev.hasNextEvent()){
                ev.getNextEvent(e);
                int t=e.getEventType();
                if(t==UsageEvents.Event.MOVE_TO_FOREGROUND || (Build.VERSION.SDK_INT>=29 && t==UsageEvents.Event.ACTIVITY_RESUMED)){
                    if(e.getPackageName()!=null)lastUsageForegroundPackage=e.getPackageName();
                }
            }
            lastUsageEventCheck=end;
            return INGRESS_PACKAGE.equals(lastUsageForegroundPackage);
        }catch(Exception e){return false;}
    }

    private void openIngress(){
        try{Intent i=getPackageManager().getLaunchIntentForPackage(INGRESS_PACKAGE);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);}}catch(Exception ignored){}
    }

    private void removeAll(){
        if(hud!=null){try{wm.removeView(hud);}catch(Exception ignored){}hud=null;}
        if(calibrationBar!=null){try{wm.removeView(calibrationBar);}catch(Exception ignored){}calibrationBar=null;calibrationBarLp=null;}
        for(HotspotWindow h:hotspotWindows){try{wm.removeView(h.root);}catch(Exception ignored){}}
        hotspotWindows.clear();
        for(VisualWindow v:visualWindows){try{wm.removeView(v.root);}catch(Exception ignored){}}
        visualWindows.clear();
    }

    @Override public void onDestroy(){
        handler.removeCallbacks(foregroundTicker);removeAll();prefs.edit().putBoolean("active",false).putBoolean("calibrating",false).apply();super.onDestroy();
    }

    private String normalizeState(String s){
        if(s==null)return "MAP";s=s.toUpperCase(java.util.Locale.ROOT);return (s.equals("PROFILE")||s.equals("INVENTORY")||s.equals("ATTACK")||s.equals("COMM"))?s:"MAP";
    }

    private String normalizeFaction(String f){return "RES".equalsIgnoreCase(f)?"RES":"ENL";}
    private int accentForState(){return "RES".equals(faction)?0xFF4DB8FF:0xFF62F59D;}
    private String levelName(){if(state.equals("PROFILE"))return "NIVEAU IGOR · PROFIL";if(state.equals("INVENTORY"))return "NIVEAU MILO · INVENTAIRE";if(state.equals("ATTACK"))return "NIVEAU LEON · ACTION";if(state.equals("COMM"))return "NIVEAU RITA · COMM";return "REDACTED · SCANNER";}
    private String shortLevelName(){if(state.equals("PROFILE"))return "PROFIL";if(state.equals("INVENTORY"))return "INVENTAIRE";if(state.equals("ATTACK"))return "ACTION";if(state.equals("COMM"))return "COMM";return "SCANNER";}

    private TextView text(String s,float sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable rounded(int fill,int stroke,int radius,int width){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(width),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void createChannel(){if(Build.VERSION.SDK_INT<26)return;NotificationManager nm=getSystemService(NotificationManager.class);if(nm==null)return;NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Redacted Prime HUD",NotificationManager.IMPORTANCE_LOW);ch.setShowBadge(false);nm.createNotificationChannel(ch);}
    private Notification buildNotification(){Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());PendingIntent pi=null;if(launch!=null){int f=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)f|=PendingIntent.FLAG_IMMUTABLE;pi=PendingIntent.getActivity(this,6132,launch,f);}NotificationCompat.Builder b=new NotificationCompat.Builder(this,CHANNEL_ID).setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Redacted Prime HUD").setContentText("Cadre Lab actif dans Ingress Prime").setOngoing(true).setSilent(true).setPriority(NotificationCompat.PRIORITY_LOW);if(pi!=null)b.setContentIntent(pi);return b.build();}

    /** Neon laboratory frame: deliberately visual-only and touch-through. */
    private class LabFrameView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int accent = 0xFF62F59D;
        private String level = "REDACTED · SCANNER";
        LabFrameView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setAccent(int c){accent=c;invalidate();}
        void setLevelName(String s){level=s;invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float d=getResources().getDisplayMetrics().density;
            float pad=5f*d;
            RectF r=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);
            for(int i=4;i>=1;i--){
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth((i==1?1.25f:1.0f)*d);
                p.setColor((accent & 0x00FFFFFF) | ((18 + (4-i)*18) << 24));
                p.setShadowLayer((i*4f)*d,0,0,accent);
                c.drawRoundRect(r,18*d,18*d,p);
            }
            p.clearShadowLayer();
            p.setColor(accent);p.setStrokeWidth(2f*d);p.setStyle(Paint.Style.STROKE);
            float L=28*d, off=9*d;
            // corner brackets
            c.drawLine(off,off,off+L,off,p);c.drawLine(off,off,off,off+L,p);
            c.drawLine(getWidth()-off,off,getWidth()-off-L,off,p);c.drawLine(getWidth()-off,off,getWidth()-off,off+L,p);
            c.drawLine(off,getHeight()-off,off+L,getHeight()-off,p);c.drawLine(off,getHeight()-off,off,getHeight()-off-L,p);
            c.drawLine(getWidth()-off,getHeight()-off,getWidth()-off-L,getHeight()-off,p);c.drawLine(getWidth()-off,getHeight()-off,getWidth()-off,getHeight()-off-L,p);
        }
    }

    private static class HotspotWindow{FrameLayout root;WindowManager.LayoutParams lp;JSONObject data;float downRawX,downRawY;int startX,startY,startW,startH;boolean resizing;boolean replaying;boolean dragging;}
    private static class VisualWindow{FrameLayout root;WindowManager.LayoutParams lp;String component;float downRawX,downRawY;int startX,startY,startW,startH;boolean resizing;}

    @Nullable @Override public IBinder onBind(Intent intent){return null;}
}
