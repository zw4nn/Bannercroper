package com.bannerforge.mobile;

import android.content.ActivityNotFoundException;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

public class MissionOverlayService extends Service {
    public static final String ACTION_START = "com.bannerforge.mobile.overlay.START";
    public static final String ACTION_STOP = "com.bannerforge.mobile.overlay.STOP";
    public static final String EXTRA_SESSION = "sessionJson";
    public static final String PREFS = "rbl_mission_overlay";

    private static final int NOTIFICATION_ID = 7407;
    private static final String CHANNEL_ID = "rbl_mission_overlay";

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private FrameLayout root;
    private LinearLayout expandedPanel;
    private FrameLayout bubble;
    private TextView counterText;
    private TextView titleText;
    private TextView doneText;
    private TextView pauseText;
    private boolean minimized = false;

    private JSONObject session;
    private JSONArray missions = new JSONArray();
    private int currentIndex = 0;
    private long startedAt = 0L;
    private long finishedAt = 0L;
    private long pausedAt = 0L;
    private long pausedTotal = 0L;
    private boolean paused = false;
    private final Set<String> done = new HashSet<>();
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String json = intent != null ? intent.getStringExtra(EXTRA_SESSION) : null;
        if (json != null && !json.trim().isEmpty()) {
            loadSession(json);
        } else {
            loadSession(prefs.getString("sessionJson", ""));
        }
        if (session == null || missions.length() == 0) {
            stopSelf();
            return START_NOT_STICKY;
        }
        createOrRefreshOverlay();
        startForegroundCompat();
        saveState(true);
        return START_NOT_STICKY;
    }

    private void loadSession(String json) {
        if (json == null || json.trim().isEmpty()) return;
        try {
            JSONObject next = new JSONObject(json);
            JSONArray nextMissions = next.optJSONArray("missions");
            if (nextMissions == null || nextMissions.length() == 0) return;
            String oldId = session == null ? prefs.getString("bannerId", "") : session.optString("bannerId", "");
            String newId = next.optString("bannerId", next.optString("id", ""));
            session = next;
            missions = nextMissions;
            if (!newId.equals(oldId)) {
                done.clear();
                currentIndex = Math.max(0, Math.min(next.optInt("currentIndex", 0), missions.length() - 1));
                startedAt = next.optLong("startedAt", System.currentTimeMillis());
                finishedAt = 0L; pausedAt = 0L; pausedTotal = 0L; paused = false;
            } else {
                currentIndex = Math.max(0, Math.min(prefs.getInt("currentIndex", next.optInt("currentIndex", 0)), missions.length() - 1));
                restoreDone();
                startedAt = prefs.getLong("startedAt", next.optLong("startedAt", System.currentTimeMillis()));
                finishedAt = prefs.getLong("finishedAt", 0L); pausedAt = prefs.getLong("pausedAt", 0L); pausedTotal = prefs.getLong("pausedTotal", 0L); paused = prefs.getBoolean("paused", false);
            }
        } catch (JSONException ignored) {
            session = null;
            missions = new JSONArray();
        }
    }

    private void restoreDone() {
        done.clear();
        String raw = prefs.getString("doneJson", "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) done.add(String.valueOf(arr.optInt(i)));
        } catch (JSONException ignored) {}
    }

    private void createOrRefreshOverlay() {
        if (root == null) {
            root = new FrameLayout(this);
            buildExpandedPanel();
            buildBubble();

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            params = new WindowManager.LayoutParams(
                expandedWidthPx(), WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = prefs.getInt("x", dp(18));
            params.y = prefs.getInt("y", dp(130));
            windowManager.addView(root, params);
            root.post(this::clampOverlayToScreen);
        }
        refreshUi();
        if (root != null) root.post(this::clampOverlayToScreen);
    }

    private void buildExpandedPanel() {
        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.VERTICAL);
        expandedPanel.setPadding(dp(12), dp(10), dp(12), dp(11));
        expandedPanel.setBackground(panelBackground(0xF207150E, 0xFF31ED83, 16));
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        root.addView(expandedPanel, ep);

        TextView dragBar = text("≡  Déplacer", 10, Color.rgb(118, 210, 151), true);
        dragBar.setGravity(Gravity.CENTER);
        dragBar.setPadding(dp(8), dp(5), dp(8), dp(7));
        dragBar.setBackground(panelBackground(0x44132F20, 0x552F8D58, 9));
        LinearLayout.LayoutParams dragLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(30));
        dragLp.setMargins(0,0,0,dp(5));
        expandedPanel.addView(dragBar, dragLp);
        attachDrag(dragBar, null);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        expandedPanel.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ImageView dino = new ImageView(this);
        dino.setImageResource(R.drawable.redacted_dino_cutout);
        dino.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams dinoLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        dinoLp.setMargins(0, 0, dp(9), 0);
        header.addView(dino, dinoLp);
        dino.setOnClickListener(v -> setMinimized(true));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        header.addView(labels, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        counterText = text("RBL", 13, Color.rgb(49, 237, 131), true);
        titleText = text("Mission", 11, Color.WHITE, true);
        titleText.setMaxLines(2);
        labels.addView(counterText);
        labels.addView(titleText);

        Button min = smallButton("−");
        min.setOnClickListener(v -> setMinimized(true));
        header.addView(min, new LinearLayout.LayoutParams(dp(38), dp(38)));

        Button close = smallButton("×");
        close.setOnClickListener(v -> stopSelf());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        closeLp.setMargins(dp(6),0,0,0);
        header.addView(close, closeLp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        controlsLp.setMargins(0, dp(10), 0, 0);
        expandedPanel.addView(controls, controlsLp);

        Button prev = actionButton("‹");
        prev.setOnClickListener(v -> changeMission(-1));
        controls.addView(prev, new LinearLayout.LayoutParams(dp(52), LinearLayout.LayoutParams.MATCH_PARENT));

        Button open = actionButton("▶ OUVRIR");
        open.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(49, 237, 131)));
        open.setTextColor(Color.rgb(4, 20, 10));
        open.setOnClickListener(v -> openCurrentMission());
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
        openLp.setMargins(dp(7),0,dp(7),0);
        controls.addView(open, openLp);

        Button next = actionButton("›");
        next.setOnClickListener(v -> changeMission(1));
        controls.addView(next, new LinearLayout.LayoutParams(dp(52), LinearLayout.LayoutParams.MATCH_PARENT));

        doneText = text("✓ Terminée", 11, Color.WHITE, true);
        doneText.setGravity(Gravity.CENTER);
        doneText.setPadding(dp(8), dp(10), dp(8), dp(10));
        doneText.setBackground(panelBackground(0xFF10291B, 0xFF2C6644, 11));
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(43));
        doneLp.setMargins(0, dp(8), 0, 0);
        expandedPanel.addView(doneText, doneLp);
        doneText.setOnClickListener(v -> markDoneAndAdvance());

        pauseText = text("⏸ Pause", 10, Color.rgb(190, 215, 198), true);
        pauseText.setGravity(Gravity.CENTER);
        pauseText.setPadding(dp(8), dp(8), dp(8), dp(8));
        pauseText.setBackground(panelBackground(0xFF0B2116, 0xFF28523B, 10));
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pauseLp.setMargins(0, dp(6), 0, 0);
        expandedPanel.addView(pauseText, pauseLp);
        pauseText.setOnClickListener(v -> togglePause());
    }

    private void buildBubble() {
        bubble = new FrameLayout(this);
        bubble.setVisibility(View.GONE);
        bubble.setBackground(panelBackground(0xEE07150E, 0xFF31ED83, 36));
        root.addView(bubble, new FrameLayout.LayoutParams(dp(70), dp(70)));
        attachDrag(bubble, () -> setMinimized(false));

        ImageView img = new ImageView(this);
        img.setImageResource(R.drawable.redacted_dino_cutout);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER);
        bubble.addView(img, ip);

        TextView badge = text("1/1", 9, Color.WHITE, true);
        badge.setId(View.generateViewId());
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(panelBackground(0xEE08160E, 0xFF31ED83, 12));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(38), dp(22), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bp.bottomMargin = dp(-1);
        bubble.addView(badge, bp);
        bubble.setTag(badge);
    }

    private void attachDrag(View handle, @Nullable Runnable onTap) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float startRawX, startRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRawX = event.getRawX();
                        startRawY = event.getRawY();
                        startX = params == null ? 0 : params.x;
                        startY = params == null ? 0 : params.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (params == null) return true;
                        float dx = event.getRawX() - startRawX;
                        float dy = event.getRawY() - startRawY;
                        if (!moved && Math.hypot(dx, dy) > dp(5)) moved = true;
                        if (moved) {
                            params.x = startX + Math.round(dx);
                            params.y = startY + Math.round(dy);
                            clampOverlayToScreen();
                            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved && params != null) {
                            clampOverlayToScreen();
                            prefs.edit().putInt("x", params.x).putInt("y", params.y).apply();
                            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                        } else if (onTap != null) {
                            onTap.run();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return true;
            }
        });
    }

    private int screenWidthPx() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenHeightPx() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int expandedWidthPx() {
        return Math.max(dp(250), Math.min(dp(320), screenWidthPx() - dp(16)));
    }

    private void clampOverlayToScreen() {
        if (params == null) return;
        int margin = dp(8);
        int width = params.width > 0 ? params.width : (minimized ? dp(72) : expandedWidthPx());
        int height = root != null && root.getHeight() > 0 ? root.getHeight() : dp(minimized ? 72 : 205);
        int maxX = Math.max(margin, screenWidthPx() - width - margin);
        int maxY = Math.max(margin, screenHeightPx() - height - margin);
        params.x = Math.max(margin, Math.min(params.x, maxX));
        params.y = Math.max(margin, Math.min(params.y, maxY));
    }

    private void setMinimized(boolean value) {
        minimized = value;
        if (expandedPanel != null) expandedPanel.setVisibility(value ? View.GONE : View.VISIBLE);
        if (bubble != null) bubble.setVisibility(value ? View.VISIBLE : View.GONE);
        if (params != null) {
            params.width = value ? dp(72) : expandedWidthPx();
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            clampOverlayToScreen();
            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
            if (root != null) root.post(() -> {
                clampOverlayToScreen();
                try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
            });
        }
        refreshUi();
    }

    private void refreshUi() {
        if (missions.length() == 0) return;
        currentIndex = Math.max(0, Math.min(currentIndex, missions.length() - 1));
        JSONObject m = missions.optJSONObject(currentIndex);
        String missionTitle = m == null ? "Mission" : m.optString("title", "Mission " + (currentIndex + 1));
        String bannerTitle = session == null ? "Redacted BannerLab" : session.optString("title", session.optString("bannerTitle", "Redacted BannerLab"));
        if (counterText != null) counterText.setText("🐊  " + (currentIndex + 1) + " / " + missions.length());
        if (titleText != null) titleText.setText(missionTitle);
        if (doneText != null) {
            boolean isDone = done.contains(String.valueOf(currentIndex));
            doneText.setText(isDone ? "✓ Terminée · suivante ›" : "✓ Marquer terminée");
            doneText.setAlpha(isDone ? 0.75f : 1f);
        }
        if (pauseText != null) pauseText.setText(paused ? "▶ Reprendre" : "⏸ Pause");
        if (bubble != null && bubble.getTag() instanceof TextView) {
            ((TextView) bubble.getTag()).setText((currentIndex + 1) + "/" + missions.length());
        }
        prefs.edit().putString("bannerTitle", bannerTitle).putString("missionTitle", missionTitle).apply();
        updateNotification();
        saveState(true);
    }

    private void changeMission(int delta) {
        int next = Math.max(0, Math.min(currentIndex + delta, missions.length() - 1));
        if (next == currentIndex) return;
        currentIndex = next;
        refreshUi();
    }

    private void markDoneAndAdvance() {
        done.add(String.valueOf(currentIndex));
        if (done.size() >= missions.length()) {
            if (paused) { pausedTotal += Math.max(0L, System.currentTimeMillis() - pausedAt); paused = false; pausedAt = 0L; }
            finishedAt = System.currentTimeMillis();
        }
        if (currentIndex < missions.length() - 1) currentIndex++;
        refreshUi();
    }

    private void togglePause() {
        long now = System.currentTimeMillis();
        if (paused) {
            pausedTotal += Math.max(0L, now - pausedAt);
            pausedAt = 0L;
            paused = false;
        } else {
            pausedAt = now;
            paused = true;
        }
        refreshUi();
    }

    private void openCurrentMission() {
        JSONObject m = missions.optJSONObject(currentIndex);
        if (m == null) return;
        String missionId = m.optString("id", "").trim();
        if (missionId.isEmpty()) return;
        String intel = "https://intel.ingress.com/mission/" + missionId;
        Uri uri = Uri.parse("https://link.ingress.com/").buildUpon()
            .appendQueryParameter("link", intel)
            .appendQueryParameter("apn", "com.nianticproject.ingress")
            .appendQueryParameter("isi", "576505181")
            .appendQueryParameter("ibi", "com.google.ingress")
            .appendQueryParameter("ifl", "https://apps.apple.com/app/ingress/id576505181")
            .appendQueryParameter("ofl", intel)
            .build();
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            i.setPackage("com.nianticproject.ingress");
            startActivity(i);
        } catch (ActivityNotFoundException ex) {
            i.setPackage(null);
            try { startActivity(i); } catch (Exception ignored) {}
        }
    }

    private void saveState(boolean active) {
        JSONArray d = new JSONArray();
        for (String x : done) {
            try { d.put(Integer.parseInt(x)); } catch (Exception ignored) {}
        }
        String bannerId = session == null ? "" : session.optString("bannerId", session.optString("id", ""));
        String bannerTitle = session == null ? "" : session.optString("title", session.optString("bannerTitle", ""));
        String missionTitle = "";
        JSONObject m = missions.optJSONObject(Math.max(0, Math.min(currentIndex, Math.max(0, missions.length()-1))));
        if (m != null) missionTitle = m.optString("title", "");
        prefs.edit()
            .putBoolean("active", active)
            .putString("bannerId", bannerId)
            .putString("bannerTitle", bannerTitle)
            .putInt("currentIndex", currentIndex)
            .putInt("total", missions.length())
            .putString("missionTitle", missionTitle)
            .putString("doneJson", d.toString())
            .putString("sessionJson", session == null ? "" : session.toString())
            .putLong("startedAt", startedAt)
            .putLong("finishedAt", finishedAt)
            .putLong("pausedAt", pausedAt)
            .putLong("pausedTotal", pausedTotal)
            .putBoolean("paused", paused)
            .apply();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "RBL Mission Overlay", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Navigation dans une bannière Ingress depuis Redacted BannerLab");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pending = launch == null ? null : PendingIntent.getActivity(
            this, 0, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );
        String title = session == null ? "Redacted BannerLab" : session.optString("title", "Redacted BannerLab");
        JSONObject m = missions.optJSONObject(Math.max(0, Math.min(currentIndex, Math.max(0, missions.length()-1))));
        String subtitle = (currentIndex + 1) + "/" + missions.length() + (m == null ? "" : " · " + m.optString("title", "Mission"));
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("RBL · " + title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW);
        if (pending != null) b.setContentIntent(pending);
        return b.build();
    }

    private void startForegroundCompat() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void updateNotification() {
        if (session == null || missions.length() == 0) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(18); b.setTextColor(Color.WHITE);
        b.setPadding(0,0,0,0);
        b.setMinWidth(0); b.setMinHeight(0);
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(18, 48, 31)));
        return b;
    }

    private Button actionButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setMinWidth(0); b.setMinHeight(0);
        b.setPadding(dp(6),0,dp(6),0);
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(16, 41, 27)));
        return b;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Nullable
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        if (root != null && windowManager != null) {
            try { windowManager.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        saveState(false);
        super.onDestroy();
    }
}
