package com.bannerforge.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public class PrimeOverlayAccessibilityService extends AccessibilityService {
    private static volatile PrimeOverlayAccessibilityService instance;
    private static volatile String foregroundPackage = "";

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // TEST-41: still no UI-tree scraping. We only remember the package name
        // announced by Android for window changes so the overlay can stay out of
        // every other app.
        if (event != null && event.getPackageName() != null) {
            foregroundPackage = String.valueOf(event.getPackageName());
        }
    }

    @Override public void onInterrupt() {}

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        foregroundPackage = "";
        super.onDestroy();
    }

    public static boolean isReady() { return instance != null; }

    public static boolean isPackageForeground(String packageName) {
        return packageName != null && packageName.equals(foregroundPackage);
    }

    public static boolean replay(float sx, float sy, float ex, float ey, long durationMs) {
        PrimeOverlayAccessibilityService svc = instance;
        if (svc == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        try {
            Path p = new Path();
            p.moveTo(sx, sy);
            p.lineTo(ex, ey);
            long d = Math.max(1L, durationMs);
            GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0L, d);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
            return svc.dispatchGesture(gesture, null, null);
        } catch (Exception ignored) { return false; }
    }

    public static boolean tap(float x, float y) {
        return replay(x, y, x + 0.5f, y + 0.5f, 55L);
    }
}
