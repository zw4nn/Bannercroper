package com.bannerforge.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import java.io.File;

public class UpdateInstallActivity extends Activity {
    private SharedPreferences prefs() {
        return getSharedPreferences(UpdateManagerPlugin.PREFS, Context.MODE_PRIVATE);
    }

    private void saveState(String status, String message, int sessionId) {
        prefs().edit()
                .putString(UpdateManagerPlugin.KEY_STATUS, status == null ? "" : status)
                .putString(UpdateManagerPlugin.KEY_MESSAGE, message == null ? "" : message)
                .putInt(UpdateManagerPlugin.KEY_SESSION_ID, sessionId)
                .putLong(UpdateManagerPlugin.KEY_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handleStatusIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleStatusIntent(intent);
    }

    @SuppressWarnings("deprecation")
    private Intent confirmationIntent(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) {
            return source.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
        }
        return source.getParcelableExtra(Intent.EXTRA_INTENT);
    }

    private void handleStatusIntent(Intent intent) {
        if (intent == null) {
            finish();
            return;
        }

        int status = intent.getIntExtra(
                PackageInstaller.EXTRA_STATUS,
                PackageInstaller.STATUS_FAILURE
        );

        int sessionId = intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1);
        String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            saveState(
                    "pending_user_action",
                    message == null ? "Confirmation Android requise" : message,
                    sessionId
            );

            try {
                Intent confirm = confirmationIntent(intent);

                if (confirm == null) {
                    saveState("failed", "Android n'a fourni aucun écran de confirmation", sessionId);
                    returnToRbl();
                    return;
                }

                // We are already an Activity in the foreground. Launching the system
                // confirmation from here avoids background-activity restrictions.
                startActivity(confirm);
                finish();

            } catch (Exception e) {
                Log.e("RBL Update", "Unable to open install confirmation", e);
                saveState("failed", "Impossible d'ouvrir la confirmation: " + e.getMessage(), sessionId);
                returnToRbl();
            }
            return;
        }

        if (status == PackageInstaller.STATUS_SUCCESS) {
            saveState("success", "Mise à jour installée", sessionId);

            try {
                new File(new File(getCacheDir(), "rbl_updates"), "rbl-update-staged.apk").delete();
            } catch (Exception ignored) {}

            returnToRbl();
            return;
        }

        saveState(
                "failed",
                message == null ? "Échec Android (" + status + ")" : message,
                sessionId
        );
        Log.e("RBL Update", "Install failed status=" + status + " " + message);
        returnToRbl();
    }

    private void returnToRbl() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launch);
            }
        } catch (Exception e) {
            Log.e("RBL Update", "Unable to return to RBL", e);
        }
        finish();
    }
}
