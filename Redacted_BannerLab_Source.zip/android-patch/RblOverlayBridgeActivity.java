package com.bannerforge.mobile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class RblOverlayBridgeActivity extends Activity {
    private boolean asked = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ensurePermissionAndStart();
    }

    @Override protected void onResume() {
        super.onResume();
        if (asked) ensurePermissionAndStart();
    }

    private void ensurePermissionAndStart() {
        if (Settings.canDrawOverlays(this)) {
            Intent svc = new Intent(this, RblOverlayService.class);
            svc.setAction("com.bannerforge.mobile.RBL_OVERLAY_START");
            try {
                startForegroundService(svc);
            } catch (Exception e) {
                startService(svc);
            }
            finish();
            return;
        }
        if (!asked) {
            asked = true;
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "Autorise Redacted BannerLab à s'afficher par-dessus les autres applications.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
        }
    }
}
