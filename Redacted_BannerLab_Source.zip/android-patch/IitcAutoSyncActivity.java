package com.bannerforge.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import org.json.JSONArray;

public class IitcAutoSyncActivity extends Activity {
    public static final String PREFS = "rbl_iitc_sync_inbox";
    public static final String KEY_QUEUE = "queue";
    public static final String KEY_LAST_AT = "lastAt";
    private static final int MAX_QUEUE = 40;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private void handle(Intent intent) {
        boolean bringRblToFront = false;
        try {
            Uri uri = intent != null ? intent.getData() : null;
            if (uri != null && "redactedbannerlab".equalsIgnoreCase(uri.getScheme())) {
                String host = uri.getHost() == null ? "" : uri.getHost();
                if ("sync".equalsIgnoreCase(host) || "autosync".equalsIgnoreCase(host)) {
                    String data = uri.getQueryParameter("data");
                    if (data != null && !data.trim().isEmpty()) {
                        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                        JSONArray old;
                        try { old = new JSONArray(p.getString(KEY_QUEUE, "[]")); }
                        catch (Exception ignored) { old = new JSONArray(); }
                        JSONArray next = new JSONArray();
                        int start = Math.max(0, old.length() - (MAX_QUEUE - 1));
                        for (int i = start; i < old.length(); i++) next.put(old.optString(i, ""));
                        next.put(uri.toString());
                        // commit() volontaire : le payload doit être durable AVANT de relancer MainActivity.
                        p.edit().putString(KEY_QUEUE, next.toString()).putLong(KEY_LAST_AT, System.currentTimeMillis()).commit();
                        bringRblToFront = "sync".equalsIgnoreCase(host);
                    }
                }
            }
        } catch (Exception ignored) {
        }

        if (bringRblToFront) {
            try {
                Intent launch = new Intent(this, MainActivity.class);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(launch);
            } catch (Exception ignored) {
            }
        }

        finish();
        overridePendingTransition(0, 0);
    }
}
