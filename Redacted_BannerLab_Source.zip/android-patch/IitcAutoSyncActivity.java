package com.bannerforge.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import org.json.JSONArray;

public class IitcAutoSyncActivity extends Activity {
    public static final String PREFS = "rbl_iitc_sync_inbox";
    public static final String KEY_QUEUE = "queue";
    public static final String KEY_LAST_AT = "lastAt";
    private static final int MAX_QUEUE = 40;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private boolean isRblScheme(Uri uri) {
        if (uri == null || uri.getScheme() == null) return false;
        String scheme = uri.getScheme();
        return "redactedbannerlab".equalsIgnoreCase(scheme)
                || "redactedbannerlabtest".equalsIgnoreCase(scheme);
    }

    private boolean isSyncHost(String host) {
        return "sync".equalsIgnoreCase(host)
                || "autosync".equalsIgnoreCase(host)
                || "igor-inventory".equalsIgnoreCase(host)
                || "igor-keys".equalsIgnoreCase(host)
                || "igor-core".equalsIgnoreCase(host);
    }

    private void enqueue(Uri uri) {
        synchronized (IitcAutoSyncActivity.class) {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old;
            try { old = new JSONArray(p.getString(KEY_QUEUE, "[]")); }
            catch (Exception ignored) { old = new JSONArray(); }

            String value = uri.toString();
            // Android/Capacitor may surface the same callback twice. Keep only one exact copy.
            if (old.length() > 0 && value.equals(old.optString(old.length() - 1, ""))) {
                p.edit().putLong(KEY_LAST_AT, System.currentTimeMillis()).commit();
                return;
            }

            JSONArray next = new JSONArray();
            int start = Math.max(0, old.length() - (MAX_QUEUE - 1));
            for (int i = start; i < old.length(); i++) {
                String previous = old.optString(i, "");
                if (!previous.isEmpty()) next.put(previous);
            }
            next.put(value);
            // commit() is intentional: the callback must be durable before MainActivity resumes.
            p.edit()
                    .putString(KEY_QUEUE, next.toString())
                    .putLong(KEY_LAST_AT, System.currentTimeMillis())
                    .commit();
        } catch (Exception ignored) {
        }
        }
    }

    private void handle(Intent intent) {
        Uri uri = intent != null ? intent.getData() : null;
        if (!isRblScheme(uri)) {
            finish();
            overridePendingTransition(0, 0);
            return;
        }

        String host = uri.getHost() == null ? "" : uri.getHost();
        if (isSyncHost(host)) enqueue(uri);

        try {
            Intent launch = new Intent(this, MainActivity.class);
            // Forward the exact deep-link to Capacitor, while the native inbox remains the
            // durable fallback if appUrlOpen/getLaunchUrl races with WebView lifecycle.
            launch.setData(uri);
            if (isSyncHost(host)) launch.putExtra("rbl_iitc_sync", true);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(launch);
        } catch (Exception ignored) {
        }

        finish();
        overridePendingTransition(0, 0);
    }
}
