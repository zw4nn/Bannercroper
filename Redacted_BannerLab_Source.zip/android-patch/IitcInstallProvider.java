package com.bannerforge.mobile;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Read-only provider used for the explicit "Install via IITC" flow.
 *
 * This provider is kept only for a genuine first install through IITC.
 * Existing canonical IGOR files are never deleted here: updates are written
 * in place through BackupFolderPlugin so IITC can preserve the plugin's
 * enabled/disabled preference.
 */
public class IitcInstallProvider extends ContentProvider {
    private static final String PREFS = "redacted_bannerlab_backup";
    private static final String KEY_IITC_TREE_URI = "iitc_tree_uri";
    private static final String ASSET = "public/igor.user.js";
    private static final String FILE_NAME = "igor.user.js";
    private static final String LEGACY_FILE_NAME = "redacted-bannerlab-iitc.user.js";
    private static final String MIME = "text/javascript";

    private volatile boolean replacementPrepared = false;
    private File payloadFile;

    @Override
    public boolean onCreate() {
        try {
            payloadFile = new File(getContext().getCacheDir(), "rbl-iitc-installer/" + FILE_NAME);
            File parent = payloadFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            copyBundledPayload();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void copyBundledPayload() throws Exception {
        if (payloadFile == null) throw new IllegalStateException("Installer payload path unavailable");
        try (InputStream in = getContext().getAssets().open(ASSET);
             FileOutputStream out = new FileOutputStream(payloadFile, false)) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
        }
        if (!payloadFile.exists() || payloadFile.length() < 1024) {
            throw new IllegalStateException("Installer payload is invalid");
        }
    }

    /** Clean only the obsolete legacy filename after IITC accepted a first install. */
    private synchronized void prepareReplacementIfNeeded() {
        if (replacementPrepared) return;
        replacementPrepared = true;
        try {
            Context ctx = getContext();
            if (ctx == null) return;
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(KEY_IITC_TREE_URI, "");
            if (raw == null || raw.isEmpty()) return;

            Uri treeUri = Uri.parse(raw);
            ContentResolver resolver = ctx.getContentResolver();
            String rootId = DocumentsContract.getTreeDocumentId(treeUri);
            String rootName = queryName(resolver, DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId));

            String pluginsId = rootId;
            if (!"plugins".equalsIgnoreCase(rootName) && !rootId.toLowerCase().endsWith("/plugins")) {
                pluginsId = findChildId(resolver, treeUri, rootId, "plugins");
                if (pluginsId == null) return;
            }

            // Never delete igor.user.js here. Deleting and recreating the canonical file
            // can make IITC Mobile forget that IGOR was enabled. Only remove the old identity.
            String fileId = findChildId(resolver, treeUri, pluginsId, LEGACY_FILE_NAME);
            if (fileId != null) {
                Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, fileId);
                try { DocumentsContract.deleteDocument(resolver, fileUri); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
            // If RBL lost SAF access, IITC still receives the package. Its importer may then
            // fail to replace an existing file, but we never crash the installer flow here.
        }
    }

    private static String queryName(ContentResolver resolver, Uri uri) {
        try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return "";
    }

    private static String findChildId(ContentResolver resolver, Uri treeUri, String parentId, String wanted) {
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
            String[] projection = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            };
            try (Cursor c = resolver.query(children, projection, null, null, null)) {
                if (c != null) {
                    while (c.moveToNext()) {
                        String id = c.getString(0);
                        String name = c.getString(1);
                        if (wanted.equals(name)) return id;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws java.io.FileNotFoundException {
        try {
            // IITC opens this URI only after its own confirmation dialog was accepted.
            // Only a legacy filename may be cleaned; the canonical file is preserved.
            prepareReplacementIfNeeded();
            if (payloadFile == null || !payloadFile.exists() || payloadFile.length() < 1024) copyBundledPayload();
            return ParcelFileDescriptor.open(payloadFile, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            java.io.FileNotFoundException x = new java.io.FileNotFoundException("Unable to expose IITC Companion: " + e.getMessage());
            x.initCause(e);
            throw x;
        }
    }

    @Override
    public String getType(Uri uri) { return MIME; }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor cursor = new MatrixCursor(cols);
        MatrixCursor.RowBuilder row = cursor.newRow();
        for (String col : cols) {
            if (OpenableColumns.DISPLAY_NAME.equals(col)) row.add(FILE_NAME);
            else if (OpenableColumns.SIZE.equals(col)) row.add(payloadFile != null && payloadFile.exists() ? payloadFile.length() : 0L);
            else row.add(null);
        }
        return cursor;
    }

    @Override public Uri insert(Uri uri, android.content.ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, android.content.ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
