from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()
ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
A = f"{{{ns}}}"

def ensure_permission(name):
    if not any(p.get(A+"name")==name for p in root.findall("uses-permission")):
        root.insert(0, ET.Element("uses-permission",{A+"name":name}))

for p in [
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
]:
    ensure_permission(p)

app = root.find("application")
if app is None: raise SystemExit("application absente du manifest")

activity = None
for a in app.findall("activity"):
    name=a.get(A+"name","")
    if name.endswith(".MainActivity") or name=="com.bannerforge.mobile.MainActivity":
        activity=a;break
if activity is None: activity=app.find("activity")
if activity is None: raise SystemExit("MainActivity introuvable")

# RBL deep links
if not any(data.get(A+"scheme")=="redactedbannerlab" for f in activity.findall("intent-filter") for data in f.findall("data")):
    f=ET.SubElement(activity,"intent-filter")
    ET.SubElement(f,"action",{A+"name":"android.intent.action.VIEW"})
    ET.SubElement(f,"category",{A+"name":"android.intent.category.DEFAULT"})
    ET.SubElement(f,"category",{A+"name":"android.intent.category.BROWSABLE"})
    ET.SubElement(f,"data",{A+"scheme":"redactedbannerlab"})

# Overlay bridge activity
if not any(a.get(A+"name","").endswith("RblOverlayBridgeActivity") for a in app.findall("activity")):
    a=ET.SubElement(app,"activity",{
        A+"name":".RblOverlayBridgeActivity",
        A+"exported":"true",
        A+"excludeFromRecents":"true",
        A+"theme":"@style/AppTheme.NoActionBar"
    })
    f=ET.SubElement(a,"intent-filter")
    ET.SubElement(f,"action",{A+"name":"android.intent.action.VIEW"})
    ET.SubElement(f,"category",{A+"name":"android.intent.category.DEFAULT"})
    ET.SubElement(f,"category",{A+"name":"android.intent.category.BROWSABLE"})
    ET.SubElement(f,"data",{A+"scheme":"redactedoverlay",A+"host":"start"})

# Foreground overlay service
if not any(s.get(A+"name","").endswith("RblOverlayService") for s in app.findall("service")):
    s=ET.SubElement(app,"service",{
        A+"name":".RblOverlayService",
        A+"exported":"false",
        A+"foregroundServiceType":"specialUse"
    })
    ET.SubElement(s,"property",{
        A+"name":"android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
        A+"value":"Visible mission-navigation overlay controlled by the user"
    })

# package visibility
queries=root.find("queries")
if queries is None:
    queries=ET.Element("queries")
    children=list(root);root.insert(children.index(app),queries)
existing={p.get(A+"name") for p in queries.findall("package")}
for package_name in [
    "org.exarhteam.iitc_mobile","org.exarhteam.iitcprime",
    "org.mozilla.firefox","org.mozilla.firefox_beta",
    "com.android.chrome","com.chrome.beta",
    "com.nianticproject.ingress"
]:
    if package_name not in existing:
        ET.SubElement(queries,"package",{A+"name":package_name})

tree.write(manifest,encoding="utf-8",xml_declaration=True)

java_dir=Path("android/app/src/main/java/com/bannerforge/mobile")
java_dir.mkdir(parents=True,exist_ok=True)
for name in ["RblOverlayBridgeActivity.java","RblOverlayService.java"]:
    shutil.copy2(Path("android-patch")/name,java_dir/name)

print("Deep links + overlay natif RBL + visibilité IITC/Firefox/Chrome/Ingress intégrés.")
