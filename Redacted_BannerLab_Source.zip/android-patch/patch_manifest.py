from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()
ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
A = f"{{{ns}}}"

app = root.find("application")
if app is None:
    raise SystemExit("application absente du manifest")

# Force le nouveau visuel Redacted BannerLab pour le launcher et les métadonnées APK.
app.set(A+"icon", "@mipmap/ic_launcher")
app.set(A+"roundIcon", "@mipmap/ic_launcher_round")

# Overlay/foreground-service permissions.
existing_permissions = {p.get(A+"name") for p in root.findall("uses-permission")}
for permission in [
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_FINE_LOCATION",
]:
    if permission not in existing_permissions:
        root.insert(0, ET.Element("uses-permission", {A+"name": permission}))

activity = None
for a in app.findall("activity"):
    name = a.get(A + "name", "")
    if name.endswith(".MainActivity") or name == "com.bannerforge.mobile.MainActivity":
        activity = a
        break
if activity is None:
    activity = app.find("activity")
if activity is None:
    raise SystemExit("MainActivity introuvable")

# Deep links IITC / Browser Publisher -> BannerLab.
# Pont manuel historique : toutes les URLs redactedbannerlab:// reviennent directement
# dans MainActivity. C'est le comportement qui fonctionnait avant l'ajout de l'inbox native.
for f in list(activity.findall("intent-filter")):
    if any(data.get(A+"scheme") == "redactedbannerlab" for data in f.findall("data")):
        activity.remove(f)
manual_filter = ET.SubElement(activity, "intent-filter")
ET.SubElement(manual_filter, "action", {A+"name":"android.intent.action.VIEW"})
ET.SubElement(manual_filter, "category", {A+"name":"android.intent.category.DEFAULT"})
ET.SubElement(manual_filter, "category", {A+"name":"android.intent.category.BROWSABLE"})
ET.SubElement(manual_filter, "data", {A+"scheme":"redactedbannerlab"})

autosync_name = ".IitcAutoSyncActivity"
autosync = next((a for a in app.findall("activity") if a.get(A+"name") in [autosync_name, "com.bannerforge.mobile.IitcAutoSyncActivity"]), None)
if autosync is None:
    autosync = ET.SubElement(app, "activity", {
        A+"name": autosync_name,
        A+"exported": "true",
        A+"excludeFromRecents": "true",
        A+"noHistory": "true",
        A+"launchMode": "standard",
        A+"taskAffinity": "",
        A+"theme": "@android:style/Theme.NoDisplay",
    })
else:
    autosync.set(A+"exported", "true")
    autosync.set(A+"excludeFromRecents", "true")
    autosync.set(A+"noHistory", "true")
    autosync.set(A+"launchMode", "standard")
    autosync.set(A+"taskAffinity", "")
    autosync.set(A+"theme", "@android:style/Theme.NoDisplay")
for f in list(autosync.findall("intent-filter")):
    autosync.remove(f)
autosync.set(A+"exported", "false")

# Dedicated read-only provider for the real IITC external-plugin installer.
# It removes the existing canonical Companion lazily only when IITC opens the
# package after the user accepted IITC's own confirmation dialog.
install_provider_authority = "${applicationId}.rblinstallprovider"
if not any((pr.get(A+"authorities") == install_provider_authority) for pr in app.findall("provider")):
    ET.SubElement(app, "provider", {
        A+"name": ".IitcInstallProvider",
        A+"authorities": install_provider_authority,
        A+"exported": "false",
        A+"grantUriPermissions": "true",
    })

# FileProvider used to hand the bundled .user.js directly to IITC Mobile.
provider_authority = "${applicationId}.rblfileprovider"
if not any((pr.get(A+"authorities") == provider_authority) for pr in app.findall("provider")):
    provider = ET.SubElement(app, "provider", {
        A+"name": "androidx.core.content.FileProvider",
        A+"authorities": provider_authority,
        A+"exported": "false",
        A+"grantUriPermissions": "true",
    })
    ET.SubElement(provider, "meta-data", {
        A+"name": "android.support.FILE_PROVIDER_PATHS",
        A+"resource": "@xml/rbl_file_paths",
    })

# Native mission overlay service.
if not any((s.get(A+"name", "").endswith("MissionOverlayService")) for s in app.findall("service")):
    service = ET.SubElement(app, "service", {
        A+"name": ".MissionOverlayService",
        A+"enabled": "true",
        A+"exported": "false",
        A+"foregroundServiceType": "specialUse",
    })
    ET.SubElement(service, "property", {
        A+"name": "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
        A+"value": "Visible floating banner mission navigator controlled by the user; opens Ingress missions only through deep links."
    })

# Android 11+ package visibility
queries = root.find("queries")
if queries is None:
    queries = ET.Element("queries")
    children = list(root)
    root.insert(children.index(app), queries)
existing = {p.get(A+"name") for p in queries.findall("package")}
for package_name in [
    "org.exarhteam.iitc_mobile",
    "org.exarhteam.iitcprime",
    "org.mozilla.firefox",
    "org.mozilla.firefox_beta",
    "com.android.chrome",
    "com.chrome.beta",
    "com.nianticproject.ingress",
    "com.google.android.apps.maps",
]:
    if package_name not in existing:
        ET.SubElement(queries, "package", {A+"name": package_name})

tree.write(manifest, encoding="utf-8", xml_declaration=True)

# Force a higher Android package version code while keeping the visible version name.
# Redacted BannerLab v1.0.12 / Companion 0.6.7.
ANDROID_VERSION_CODE = 11222
ANDROID_VERSION_NAME = "1.0.12"

build_gradle = Path("android/app/build.gradle")
if not build_gradle.exists():
    raise SystemExit("android/app/build.gradle absent")
gradle_text = build_gradle.read_text(encoding="utf-8")
import re
new_gradle, code_count = re.subn(r"(?m)^(\s*)versionCode\s+\d+\s*$", rf"\1versionCode {ANDROID_VERSION_CODE}", gradle_text, count=1)
new_gradle, name_count = re.subn(r'(?m)^(\s*)versionName\s+["\'][^"\']*["\']\s*$', rf'\1versionName "{ANDROID_VERSION_NAME}"', new_gradle, count=1)
if code_count != 1 or name_count != 1:
    raise SystemExit(f"Impossible de forcer versionCode/versionName (code={code_count}, name={name_count})")
build_gradle.write_text(new_gradle, encoding="utf-8")

# The Android platform is regenerated by the workflow on every build.
# Reinstall the custom launcher resources every time so the APK metadata and
# installed launcher both use the same icon.
src_res = Path("android-res")
dst_res = Path("android/app/src/main/res")
if not src_res.exists():
    raise SystemExit("android-res absent")
for source in src_res.rglob("*"):
    if source.is_file():
        rel = source.relative_to(src_res)
        target = dst_res / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

# Hard build check: the exact Companion must already be present in the Android APK assets.
source_companion = Path("public/redacted-bannerlab-iitc.user.js")
android_companion = Path("android/app/src/main/assets/public/redacted-bannerlab-iitc.user.js")
if not source_companion.exists():
    raise SystemExit("Companion source absent: public/redacted-bannerlab-iitc.user.js")
if source_companion.stat().st_size < 1024:
    raise SystemExit(f"Companion source invalide: {source_companion.stat().st_size} octets")
companion_text = source_companion.read_text(encoding="utf-8")
for marker in ["// @id           redacted-bannerlab-iitc", "// @version      0.6.7"]:
    if marker not in companion_text:
        raise SystemExit(f"Identité/version Companion invalide: {marker}")
if not android_companion.exists():
    raise SystemExit("Companion absent des assets Android après cap sync")
if android_companion.read_bytes() != source_companion.read_bytes():
    raise SystemExit("Companion Android différent du Companion source")
print(f"Companion Android vérifié: {android_companion.stat().st_size} octets")

# Reinstall the custom plugin/service/MainActivity every time.
dst = Path("android/app/src/main/java/com/bannerforge/mobile")
dst.mkdir(parents=True, exist_ok=True)
for name in ["MissionOverlayPlugin.java", "MissionOverlayService.java", "BackupFolderPlugin.java", "LocationStatusPlugin.java", "IitcAutoSyncActivity.java", "IitcSyncInboxPlugin.java", "IitcInstallProvider.java", "MainActivity.java"]:
    source = Path("android-patch") / name
    if not source.exists():
        raise SystemExit(f"{source} absent")
    shutil.copy2(source, dst / name)

print("Deep links + reprise/synchro IITC manuelle + installateur Companion SAF + overlay + sauvegarde SAF + statut localisation + launcher intégrés.")
