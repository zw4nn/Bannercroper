from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()
ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
app = root.find("application")
if app is None:
    raise SystemExit("application absente du manifest")
activity = None
for a in app.findall("activity"):
    name = a.get(f"{{{ns}}}name", "")
    if name.endswith(".MainActivity") or name == "com.bannerforge.mobile.MainActivity":
        activity = a
        break
if activity is None:
    activity = app.find("activity")
if activity is None:
    raise SystemExit("MainActivity introuvable")

exists = False
for filt in activity.findall("intent-filter"):
    for data in filt.findall("data"):
        if data.get(f"{{{ns}}}scheme") == "redactedbannerlab":
            exists = True
if not exists:
    filt = ET.SubElement(activity, "intent-filter")
    ET.SubElement(filt, "action", {f"{{{ns}}}name":"android.intent.action.VIEW"})
    ET.SubElement(filt, "category", {f"{{{ns}}}name":"android.intent.category.DEFAULT"})
    ET.SubElement(filt, "category", {f"{{{ns}}}name":"android.intent.category.BROWSABLE"})
    ET.SubElement(filt, "data", {
        f"{{{ns}}}scheme":"redactedbannerlab",
        f"{{{ns}}}host":"portal"
    })

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print("Deep link redactedbannerlab://portal ajouté.")
