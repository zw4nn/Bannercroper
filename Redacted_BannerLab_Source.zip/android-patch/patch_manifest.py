from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()
ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
A = f"{{{ns}}}"

app = root.find("application")
if app is None:
    raise SystemExit("application absente du manifest")

activity = None
for a in app.findall("activity"):
    name = a.get(A + "name", "")
    if name.endswith(".MainActivity") or name == "com.bannerforge.mobile.MainActivity":
        activity = a
        break
if activity is None:
    activity = app.find("activity")
if activity is None:
    raise SystemExit("MainActivity introuvable")

# Deep links IITC / Browser Publisher -> BannerLab
if not any(
    data.get(A+"scheme") == "redactedbannerlab"
    for f in activity.findall("intent-filter")
    for data in f.findall("data")
):
    filt = ET.SubElement(activity, "intent-filter")
    ET.SubElement(filt, "action", {A+"name": "android.intent.action.VIEW"})
    ET.SubElement(filt, "category", {A+"name": "android.intent.category.DEFAULT"})
    ET.SubElement(filt, "category", {A+"name": "android.intent.category.BROWSABLE"})
    ET.SubElement(filt, "data", {A+"scheme": "redactedbannerlab"})

# Android 11+ package visibility
queries = root.find("queries")
if queries is None:
    queries = ET.Element("queries")
    children = list(root)
    root.insert(children.index(app), queries)

existing = {p.get(A+"name") for p in queries.findall("package")}
for package_name in [
    "org.exarhteam.iitc_mobile",
    "org.exarhteam.iitcprime",
    "org.mozilla.firefox",
    "org.mozilla.firefox_beta",
    "com.android.chrome",
    "com.chrome.beta",
]:
    if package_name not in existing:
        ET.SubElement(queries, "package", {A+"name": package_name})

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print("Deep link BannerLab + visibilité IITC/Firefox intégrés.")
