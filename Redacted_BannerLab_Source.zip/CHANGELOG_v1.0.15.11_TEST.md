# Redacted BannerLab 1.0.15.11 TEST · build 11512

## Arcade — vignettes harmonisées

- Les vignettes des mini-jeux utilisent maintenant un cadrage visuel homogène.
- Les deux jeux Redacted utilisent la **même vignette launcher/logo existante**.
- Le cadrage de Redacted est légèrement agrandi pour compenser la marge interne de l’asset et obtenir une tête de taille comparable à IGOR, MILO et RITA.
- `Lab Memory` devient **REDACTED - Lab Memory** pour rester cohérent avec les autres jeux nommés par personnage.
- Aucune image n’a été générée.
