# Redacted BannerLab 1.0.15.7 TEST · build 11508

## Arcade du Lab — multilingue

- Traduction complète de l’Arcade du Lab dans les **7 langues prioritaires** de RBL : français, anglais, espagnol, portugais, allemand, italien et néerlandais.
- Sont traduits : accueil clandestin, états IGOR/MILO/RITA, dialogues, briefings, tutoriels, HUD, messages de jeu, choix de faction et aides de chaque mini-jeu.
- Les **13 autres langues** prises en charge par RBL utilisent l’anglais comme fallback pour l’Arcade.
- Les noms propres et éléments de branding (Redacted Banner LAB/ARCADE, IGOR, MILO, RITA et noms des expériences) restent cohérents avec le Lab.
- Les dialogues de Redacted utilisent l’icône launcher existante comme avatar.
