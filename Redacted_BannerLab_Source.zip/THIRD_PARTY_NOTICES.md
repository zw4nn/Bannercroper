# Third-party notices

## Ingress Glyph Tools data model / glyph dictionary

Parts of `src/glyph-lab.js` use glyph geometry and dictionary values adapted from **gm9/ingress-glyph-tools**.

- Project: https://github.com/gm9/ingress-glyph-tools
- Copyright (c) 2014 gm9
- License: MIT

The Glyph Lab interface, training flow and Redacted BannerLab integration are original code for this project.

Ingress and its glyph language belong to Niantic. Redacted BannerLab is an unofficial fan tool and is not affiliated with or endorsed by Niantic.


## Lucide Icons

Certaines icônes génériques de l’inventaire IGOR (crosshair, radio, battery-charging, shield, zap, package, key) proviennent du projet public **Lucide**. Elles sont utilisées comme pictogrammes génériques et ne reproduisent pas les visuels propriétaires de l’inventaire Ingress.

Licence : ISC pour Lucide et MIT pour les icônes héritées de Feather, selon le fichier LICENSE du projet Lucide.
Copyright (c) Lucide Icons and Contributors / Cole Bemis.
Source : https://github.com/lucide-icons/lucide

Le texte complet de licence est disponible dans le dépôt source Lucide.

### Lucide ISC License

Copyright (c) 2026 Lucide Icons and Contributors

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

### Feather MIT License (for inherited icons where applicable)

Copyright (c) 2013-present Cole Bemis

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


## ingress-items

Item artwork used in the RBL inventory UI is loaded from the community project `le-jeu/ingress-items`, based on `Kofirs2634/ingress-items`. The project states that these unofficial manually vectorized Ingress item images are licensed under Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). Ingress/Niantic trademarks remain the property of their respective owners. Source: https://github.com/le-jeu/ingress-items

## Ingress Drone Mk II reference images (TEST-40 prototype)

The TEST-40 LEON Drone timer uses the Drone Mk II ENL and RES reference images supplied by the tester for the prototype.
Reference/source page supplied by the tester: **Ingress Wiki — Dronenet** (`https://ingress.fandom.com/wiki/Dronenet?file=Drone_Mk_II_RES.png`).
Ingress and related visual assets are trademarks/copyright of their respective owners. These files are included only as UI reference assets for the Ingress companion prototype and are not claimed as Redacted BannerLab artwork.
