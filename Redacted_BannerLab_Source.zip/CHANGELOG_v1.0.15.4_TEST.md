# Redacted BannerLab 1.0.15.4 TEST · build 11505

## RITA · Portal Blaster — arcade pass

- Formations d’ennemis : lignes, vagues et zigzags.
- Boss de la faction adverse avec barre de vie dédiée.
- Barre de progression de niveau dans l’arène.
- Nouveau **SUPER** chargé par les destructions et bonus de faction.
- Super tir plein écran à 100 %.
- Bonus de la couleur du joueur volontairement plus rares.
- Machina rouges environ deux fois plus résistants que les ennemis standards.
- Effets d’explosion et particules enrichis.
- Contrôles joystick/flèches sécurisés contre le scroll tactile parasite.
