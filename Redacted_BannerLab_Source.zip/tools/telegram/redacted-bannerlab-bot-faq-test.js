// Redacted BannerLab Telegram Bot — FAQ TEST v0.2 — 2026-09-07
const TELEGRAM_API = "https://api.telegram.org";
const SUPPORT_PENDING_TTL = 1800; // 30 minutes

const I18N = {
  "fr": {
    "label": "🇫🇷 Français",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Salut <b>{name}</b> 👋",
    "welcome": "Bienvenue à l’entrée du laboratoire.\n\nIci tu peux contacter le support, suivre les nouvelles versions et rejoindre la communauté.\n\nRedacted devait gérer l’accueil lui-même. Après quelques incidents impliquant des câbles et du scotch, nous avons préféré automatiser la procédure.",
    "support_btn": "🐛 Contacter le support",
    "channel_btn": "📢 Rejoindre le canal",
    "community_btn": "💬 Rejoindre la communauté",
    "about_btn": "ℹ️ À propos",
    "language_btn": "🌐 Langue",
    "support_title": "🐛 SUPPORT REDACTED BANNERLAB",
    "support_body": "Très bien Agent.\n\n<b>Envoie simplement ton problème dans ton prochain message.</b>\n\nTu peux envoyer du texte, une capture, une photo, une vidéo, un document ou un vocal.\n\nSi possible, indique ta version de BannerLab, ce que tu voulais faire, ce qui s’est passé et comment reproduire le problème.\n\n🦖 Le traditionnel « ça marche pas » reste autorisé. Nous ne garantissons simplement pas l’absence de jugement.",
    "cancel_btn": "❌ Annuler",
    "cancelled": "❌ <b>Demande annulée.</b>\n\nRedacted remet le formulaire dans le tiroir. Il prétend qu’il était parfaitement rangé avant.",
    "sent_title": "✅ MESSAGE TRANSMIS AU LABORATOIRE",
    "sent_body": "Ta demande est partie. Redacted l’a mise sur la pile des choses importantes.\n\nTu recevras directement ici la réponse du support. 🦖",
    "another_btn": "🐛 Envoyer une autre demande",
    "back_btn": "⬅️ Retour au menu",
    "unknown": "🦖 Je n’ai pas compris cette demande.\n\nJe sais, venant d’un bot installé dans un laboratoire, ce n’est pas extrêmement rassurant.",
    "channel_title": "📢 LE CANAL REDACTED BANNERLAB",
    "channel_body": "Versions, changelogs, nouveautés et expériences ayant miraculeusement survécu au laboratoire.",
    "join_channel": "📢 Rejoindre le canal",
    "community_title": "💬 LA COMMUNAUTÉ REDACTED BANNERLAB",
    "community_body": "Besoin d’aide, envie de montrer une fresque ou de proposer une idée complètement déraisonnable ? Les expériences collectives commencent ici.",
    "join_group": "💬 Rejoindre le groupe",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Un outil communautaire indépendant conçu pour préparer, éditer et publier des bannières Ingress sans sacrifier trois soirées et une partie de sa santé mentale.\n\n👨‍🔬 Créé par <b>Zw4nn</b>\n🦖 Supervisé avec un sérieux très discutable par <b>Redacted</b>.",
    "choose_language": "🌐 <b>Choisis ta langue</b>\n\nRedacted essaiera ensuite de juger tes bugs dans la langue appropriée.",
    "language_saved": "✅ Langue enregistrée : <b>{language}</b>",
    "lab_reply": "🦖 <b>RÉPONSE DU LABORATOIRE</b>",
    "lab_media": "Le support t’a envoyé un fichier ou un média 👇",
    "reply_again": "Besoin de répondre ou d’envoyer autre chose ?"
  },
  "en": {
    "label": "🇬🇧 English",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Hi <b>{name}</b> 👋",
    "welcome": "Welcome to the laboratory entrance.\n\nHere you can contact support, follow new releases and join the community.\n\nRedacted was supposed to run reception. After a few incidents involving cables and tape, we decided to automate the process.",
    "support_btn": "🐛 Contact support",
    "channel_btn": "📢 Join the channel",
    "community_btn": "💬 Join the community",
    "about_btn": "ℹ️ About",
    "language_btn": "🌐 Language",
    "support_title": "🐛 REDACTED BANNERLAB SUPPORT",
    "support_body": "All right, Agent.\n\n<b>Simply send your problem in your next message.</b>\n\nYou can send text, a screenshot, photo, video, document or voice message.\n\nIf possible, include your BannerLab version, what you were trying to do, what happened and how to reproduce it.\n\n🦖 The classic “it doesn’t work” is still accepted. We simply cannot guarantee a judgement-free laboratory.",
    "cancel_btn": "❌ Cancel",
    "cancelled": "❌ <b>Request cancelled.</b>\n\nRedacted is putting the form back in the drawer. He claims it was perfectly organized before.",
    "sent_title": "✅ MESSAGE SENT TO THE LAB",
    "sent_body": "Your request is on its way. Redacted placed it on the important-things pile.\n\nYou’ll receive the support reply right here. 🦖",
    "another_btn": "🐛 Send another request",
    "back_btn": "⬅️ Back to menu",
    "unknown": "🦖 I didn’t understand that request.\n\nComing from a bot installed in a laboratory, that is not especially reassuring.",
    "channel_title": "📢 REDACTED BANNERLAB CHANNEL",
    "channel_body": "Releases, changelogs, news and experiments that somehow survived the laboratory.",
    "join_channel": "📢 Join the channel",
    "community_title": "💬 REDACTED BANNERLAB COMMUNITY",
    "community_body": "Need help, want to show a banner, or have an unreasonable idea for the next version? Collective experiments start here.",
    "join_group": "💬 Join the group",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "An independent community tool for preparing, editing and publishing Ingress banners without sacrificing three evenings and part of your sanity.\n\n👨‍🔬 Created by <b>Zw4nn</b>\n🦖 Supervised with highly questionable seriousness by <b>Redacted</b>.",
    "choose_language": "🌐 <b>Choose your language</b>\n\nRedacted will then try to judge your bugs in the appropriate language.",
    "language_saved": "✅ Language saved: <b>{language}</b>",
    "lab_reply": "🦖 <b>REPLY FROM THE LAB</b>",
    "lab_media": "Support sent you a file or media 👇",
    "reply_again": "Need to reply or send something else?"
  },
  "es": {
    "label": "🇪🇸 Español",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Hola <b>{name}</b> 👋",
    "welcome": "Bienvenido a la entrada del laboratorio.\n\nAquí puedes contactar con soporte, seguir nuevas versiones y unirte a la comunidad.\n\nRedacted iba a encargarse de la recepción. Tras varios incidentes con cables y cinta adhesiva, preferimos automatizar el proceso.",
    "support_btn": "🐛 Contactar con soporte",
    "channel_btn": "📢 Unirse al canal",
    "community_btn": "💬 Unirse a la comunidad",
    "about_btn": "ℹ️ Acerca de",
    "language_btn": "🌐 Idioma",
    "support_title": "🐛 SOPORTE REDACTED BANNERLAB",
    "support_body": "Muy bien, Agente.\n\n<b>Envía simplemente tu problema en tu próximo mensaje.</b>\n\nPuedes enviar texto, captura, foto, vídeo, documento o audio.\n\nSi puedes, indica tu versión de BannerLab, qué intentabas hacer, qué ocurrió y cómo reproducirlo.\n\n🦖 El tradicional «no funciona» sigue estando permitido. No garantizamos que Redacted no te juzgue.",
    "cancel_btn": "❌ Cancelar",
    "cancelled": "❌ <b>Solicitud cancelada.</b>\n\nRedacted vuelve a guardar el formulario. Jura que antes estaba perfectamente ordenado.",
    "sent_title": "✅ MENSAJE ENVIADO AL LABORATORIO",
    "sent_body": "Tu solicitud ha salido. Redacted la ha puesto en la pila de cosas importantes.\n\nRecibirás aquí mismo la respuesta del soporte. 🦖",
    "another_btn": "🐛 Enviar otra solicitud",
    "back_btn": "⬅️ Volver al menú",
    "unknown": "🦖 No he entendido esa solicitud.\n\nPara un bot instalado en un laboratorio, no es especialmente tranquilizador.",
    "channel_title": "📢 CANAL REDACTED BANNERLAB",
    "channel_body": "Versiones, cambios, novedades y experimentos que milagrosamente sobrevivieron al laboratorio.",
    "join_channel": "📢 Unirse al canal",
    "community_title": "💬 COMUNIDAD REDACTED BANNERLAB",
    "community_body": "¿Necesitas ayuda, quieres enseñar una fresque o tienes una idea absurdamente ambiciosa? Los experimentos colectivos empiezan aquí.",
    "join_group": "💬 Unirse al grupo",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Una herramienta comunitaria independiente para preparar, editar y publicar banners de Ingress sin sacrificar tres noches y parte de tu salud mental.\n\n👨‍🔬 Creado por <b>Zw4nn</b>\n🦖 Supervisado con una seriedad muy discutible por <b>Redacted</b>.",
    "choose_language": "🌐 <b>Elige tu idioma</b>\n\nRedacted intentará juzgar tus bugs en el idioma adecuado.",
    "language_saved": "✅ Idioma guardado: <b>{language}</b>",
    "lab_reply": "🦖 <b>RESPUESTA DEL LABORATORIO</b>",
    "lab_media": "Soporte te ha enviado un archivo o contenido multimedia 👇",
    "reply_again": "¿Necesitas responder o enviar algo más?"
  },
  "pt": {
    "label": "🇵🇹 Português",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Olá <b>{name}</b> 👋",
    "welcome": "Bem-vindo à entrada do laboratório.\n\nAqui podes contactar o suporte, acompanhar novas versões e juntar-te à comunidade.\n\nRedacted deveria tratar da receção. Depois de alguns incidentes com cabos e fita-cola, preferimos automatizar o processo.",
    "support_btn": "🐛 Contactar o suporte",
    "channel_btn": "📢 Entrar no canal",
    "community_btn": "💬 Entrar na comunidade",
    "about_btn": "ℹ️ Sobre",
    "language_btn": "🌐 Idioma",
    "support_title": "🐛 SUPORTE REDACTED BANNERLAB",
    "support_body": "Muito bem, Agente.\n\n<b>Envia simplesmente o teu problema na próxima mensagem.</b>\n\nPodes enviar texto, captura, foto, vídeo, documento ou áudio.\n\nSe possível, indica a versão do BannerLab, o que tentavas fazer, o que aconteceu e como reproduzir o problema.\n\n🦖 O clássico «não funciona» continua autorizado. Não garantimos ausência de julgamento.",
    "cancel_btn": "❌ Cancelar",
    "cancelled": "❌ <b>Pedido cancelado.</b>\n\nRedacted voltou a guardar o formulário. Jura que estava perfeitamente arrumado.",
    "sent_title": "✅ MENSAGEM ENVIADA AO LABORATÓRIO",
    "sent_body": "O teu pedido foi enviado. Redacted colocou-o na pilha das coisas importantes.\n\nReceberás aqui a resposta do suporte. 🦖",
    "another_btn": "🐛 Enviar outro pedido",
    "back_btn": "⬅️ Voltar ao menu",
    "unknown": "🦖 Não percebi esse pedido.\n\nVindo de um bot instalado num laboratório, não é particularmente tranquilizador.",
    "channel_title": "📢 CANAL REDACTED BANNERLAB",
    "channel_body": "Versões, changelogs, novidades e experiências que sobreviveram milagrosamente ao laboratório.",
    "join_channel": "📢 Entrar no canal",
    "community_title": "💬 COMUNIDADE REDACTED BANNERLAB",
    "community_body": "Precisas de ajuda, queres mostrar uma banner ou tens uma ideia completamente absurda? As experiências coletivas começam aqui.",
    "join_group": "💬 Entrar no grupo",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Uma ferramenta comunitária independente para preparar, editar e publicar banners Ingress sem sacrificar três noites e parte da sanidade.\n\n👨‍🔬 Criado por <b>Zw4nn</b>\n🦖 Supervisionado com uma seriedade muito discutível por <b>Redacted</b>.",
    "choose_language": "🌐 <b>Escolhe o teu idioma</b>\n\nRedacted tentará julgar os teus bugs no idioma apropriado.",
    "language_saved": "✅ Idioma guardado: <b>{language}</b>",
    "lab_reply": "🦖 <b>RESPOSTA DO LABORATÓRIO</b>",
    "lab_media": "O suporte enviou-te um ficheiro ou conteúdo multimédia 👇",
    "reply_again": "Precisas de responder ou enviar mais alguma coisa?"
  },
  "de": {
    "label": "🇩🇪 Deutsch",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Hallo <b>{name}</b> 👋",
    "welcome": "Willkommen am Eingang des Labors.\n\nHier kannst du den Support kontaktieren, neue Versionen verfolgen und der Community beitreten.\n\nEigentlich sollte Redacted den Empfang übernehmen. Nach ein paar Zwischenfällen mit Kabeln und Klebeband haben wir das lieber automatisiert.",
    "support_btn": "🐛 Support kontaktieren",
    "channel_btn": "📢 Kanal beitreten",
    "community_btn": "💬 Community beitreten",
    "about_btn": "ℹ️ Über",
    "language_btn": "🌐 Sprache",
    "support_title": "🐛 REDACTED BANNERLAB SUPPORT",
    "support_body": "Alles klar, Agent.\n\n<b>Sende dein Problem einfach in deiner nächsten Nachricht.</b>\n\nText, Screenshot, Foto, Video, Dokument oder Sprachnachricht sind möglich.\n\nWenn möglich: BannerLab-Version, was du tun wolltest, was passiert ist und wie man es reproduziert.\n\n🦖 Das klassische „geht nicht“ ist weiterhin erlaubt. Urteilsfreiheit können wir nicht garantieren.",
    "cancel_btn": "❌ Abbrechen",
    "cancelled": "❌ <b>Anfrage abgebrochen.</b>\n\nRedacted legt das Formular zurück in die Schublade. Angeblich war dort vorher alles perfekt sortiert.",
    "sent_title": "✅ NACHRICHT ANS LABOR GESENDET",
    "sent_body": "Deine Anfrage ist unterwegs. Redacted hat sie auf den Stapel der wichtigen Dinge gelegt.\n\nDie Antwort des Supports kommt direkt hierher. 🦖",
    "another_btn": "🐛 Weitere Anfrage",
    "back_btn": "⬅️ Zurück zum Menü",
    "unknown": "🦖 Diese Anfrage habe ich nicht verstanden.\n\nFür einen Labor-Bot ist das nicht besonders beruhigend.",
    "channel_title": "📢 REDACTED BANNERLAB KANAL",
    "channel_body": "Versionen, Changelogs, Neuigkeiten und Experimente, die das Labor irgendwie überlebt haben.",
    "join_channel": "📢 Kanal beitreten",
    "community_title": "💬 REDACTED BANNERLAB COMMUNITY",
    "community_body": "Hilfe nötig, Banner zeigen oder eine völlig übertriebene Idee vorschlagen? Die gemeinsamen Experimente beginnen hier.",
    "join_group": "💬 Gruppe beitreten",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Ein unabhängiges Community-Tool zum Vorbereiten, Bearbeiten und Veröffentlichen von Ingress-Bannern, ohne drei Abende und einen Teil der geistigen Gesundheit zu opfern.\n\n👨‍🔬 Erstellt von <b>Zw4nn</b>\n🦖 Mit höchst fragwürdigem Ernst beaufsichtigt von <b>Redacted</b>.",
    "choose_language": "🌐 <b>Wähle deine Sprache</b>\n\nRedacted versucht dann, deine Bugs in der passenden Sprache zu beurteilen.",
    "language_saved": "✅ Sprache gespeichert: <b>{language}</b>",
    "lab_reply": "🦖 <b>ANTWORT AUS DEM LABOR</b>",
    "lab_media": "Der Support hat dir eine Datei oder ein Medium geschickt 👇",
    "reply_again": "Möchtest du antworten oder noch etwas senden?"
  },
  "it": {
    "label": "🇮🇹 Italiano",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Ciao <b>{name}</b> 👋",
    "welcome": "Benvenuto all’ingresso del laboratorio.\n\nQui puoi contattare il supporto, seguire le nuove versioni e unirti alla community.\n\nRedacted doveva occuparsi dell’accoglienza. Dopo alcuni incidenti con cavi e nastro adesivo abbiamo preferito automatizzare.",
    "support_btn": "🐛 Contatta il supporto",
    "channel_btn": "📢 Unisciti al canale",
    "community_btn": "💬 Unisciti alla community",
    "about_btn": "ℹ️ Informazioni",
    "language_btn": "🌐 Lingua",
    "support_title": "🐛 SUPPORTO REDACTED BANNERLAB",
    "support_body": "Va bene, Agente.\n\n<b>Invia semplicemente il problema nel tuo prossimo messaggio.</b>\n\nPuoi inviare testo, screenshot, foto, video, documento o vocale.\n\nSe possibile indica versione di BannerLab, cosa volevi fare, cosa è successo e come riprodurlo.\n\n🦖 Il classico «non funziona» è ancora ammesso. Non garantiamo l’assenza di giudizio.",
    "cancel_btn": "❌ Annulla",
    "cancelled": "❌ <b>Richiesta annullata.</b>\n\nRedacted rimette il modulo nel cassetto. Sostiene che fosse perfettamente ordinato.",
    "sent_title": "✅ MESSAGGIO INVIATO AL LABORATORIO",
    "sent_body": "La richiesta è partita. Redacted l’ha messa nella pila delle cose importanti.\n\nRiceverai qui la risposta del supporto. 🦖",
    "another_btn": "🐛 Invia un’altra richiesta",
    "back_btn": "⬅️ Torna al menu",
    "unknown": "🦖 Non ho capito questa richiesta.\n\nPer un bot installato in un laboratorio non è particolarmente rassicurante.",
    "channel_title": "📢 CANALE REDACTED BANNERLAB",
    "channel_body": "Versioni, changelog, novità ed esperimenti sopravvissuti miracolosamente al laboratorio.",
    "join_channel": "📢 Unisciti al canale",
    "community_title": "💬 COMMUNITY REDACTED BANNERLAB",
    "community_body": "Serve aiuto, vuoi mostrare una banner o proporre un’idea completamente irragionevole? Gli esperimenti collettivi iniziano qui.",
    "join_group": "💬 Unisciti al gruppo",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Uno strumento indipendente della community per preparare, modificare e pubblicare banner Ingress senza sacrificare tre serate e parte della propria sanità mentale.\n\n👨‍🔬 Creato da <b>Zw4nn</b>\n🦖 Supervisionato con serietà molto discutibile da <b>Redacted</b>.",
    "choose_language": "🌐 <b>Scegli la lingua</b>\n\nRedacted proverà poi a giudicare i tuoi bug nella lingua giusta.",
    "language_saved": "✅ Lingua salvata: <b>{language}</b>",
    "lab_reply": "🦖 <b>RISPOSTA DAL LABORATORIO</b>",
    "lab_media": "Il supporto ti ha inviato un file o un contenuto multimediale 👇",
    "reply_again": "Vuoi rispondere o inviare altro?"
  },
  "nl": {
    "label": "🇳🇱 Nederlands",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Hoi <b>{name}</b> 👋",
    "welcome": "Welkom bij de ingang van het laboratorium.\n\nHier kun je support contacteren, nieuwe versies volgen en lid worden van de community.\n\nRedacted zou de receptie doen. Na enkele incidenten met kabels en tape hebben we dat maar geautomatiseerd.",
    "support_btn": "🐛 Contact support",
    "channel_btn": "📢 Word lid van het kanaal",
    "community_btn": "💬 Word lid van de community",
    "about_btn": "ℹ️ Over",
    "language_btn": "🌐 Taal",
    "support_title": "🐛 REDACTED BANNERLAB SUPPORT",
    "support_body": "Goed, Agent.\n\n<b>Stuur je probleem gewoon in je volgende bericht.</b>\n\nTekst, screenshot, foto, video, document of spraakbericht kan allemaal.\n\nVermeld indien mogelijk je BannerLab-versie, wat je wilde doen, wat er gebeurde en hoe het te reproduceren is.\n\n🦖 Het klassieke “het werkt niet” blijft toegestaan. Zonder oordeel kunnen we niets beloven.",
    "cancel_btn": "❌ Annuleren",
    "cancelled": "❌ <b>Verzoek geannuleerd.</b>\n\nRedacted legt het formulier terug in de lade. Volgens hem was die perfect georganiseerd.",
    "sent_title": "✅ BERICHT NAAR HET LAB GESTUURD",
    "sent_body": "Je verzoek is onderweg. Redacted heeft het op de stapel belangrijke dingen gelegd.\n\nJe krijgt het antwoord van support hier. 🦖",
    "another_btn": "🐛 Nog een verzoek",
    "back_btn": "⬅️ Terug naar menu",
    "unknown": "🦖 Ik begreep dat verzoek niet.\n\nVoor een bot in een laboratorium is dat niet bijzonder geruststellend.",
    "channel_title": "📢 REDACTED BANNERLAB KANAAL",
    "channel_body": "Versies, changelogs, nieuws en experimenten die het laboratorium wonder boven wonder overleefden.",
    "join_channel": "📢 Word lid van het kanaal",
    "community_title": "💬 REDACTED BANNERLAB COMMUNITY",
    "community_body": "Hulp nodig, een banner tonen of een belachelijk ambitieus idee delen? De gezamenlijke experimenten beginnen hier.",
    "join_group": "💬 Word lid van de groep",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Een onafhankelijke communitytool om Ingress-banners voor te bereiden, te bewerken en te publiceren zonder drie avonden en een deel van je geestelijke gezondheid op te offeren.\n\n👨‍🔬 Gemaakt door <b>Zw4nn</b>\n🦖 Onder twijfelachtig serieus toezicht van <b>Redacted</b>.",
    "choose_language": "🌐 <b>Kies je taal</b>\n\nRedacted zal je bugs daarna in de juiste taal proberen te beoordelen.",
    "language_saved": "✅ Taal opgeslagen: <b>{language}</b>",
    "lab_reply": "🦖 <b>ANTWOORD UIT HET LAB</b>",
    "lab_media": "Support heeft je een bestand of media gestuurd 👇",
    "reply_again": "Wil je antwoorden of nog iets sturen?"
  },
  "pl": {
    "label": "🇵🇱 Polski",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Cześć <b>{name}</b> 👋",
    "welcome": "Witaj przy wejściu do laboratorium.\n\nTutaj skontaktujesz się ze wsparciem, sprawdzisz nowe wersje i dołączysz do społeczności.\n\nRedacted miał prowadzić recepcję. Po kilku incydentach z kablami i taśmą uznaliśmy, że lepiej to zautomatyzować.",
    "support_btn": "🐛 Skontaktuj się ze wsparciem",
    "channel_btn": "📢 Dołącz do kanału",
    "community_btn": "💬 Dołącz do społeczności",
    "about_btn": "ℹ️ O projekcie",
    "language_btn": "🌐 Język",
    "support_title": "🐛 WSPARCIE REDACTED BANNERLAB",
    "support_body": "Dobrze, Agencie.\n\n<b>Po prostu wyślij opis problemu w następnej wiadomości.</b>\n\nMożesz wysłać tekst, zrzut ekranu, zdjęcie, film, dokument lub wiadomość głosową.\n\nJeśli możesz, podaj wersję BannerLab, co próbowałeś zrobić, co się stało i jak odtworzyć problem.\n\n🦖 Klasyczne „nie działa” nadal jest dozwolone. Braku osądzania nie gwarantujemy.",
    "cancel_btn": "❌ Anuluj",
    "cancelled": "❌ <b>Zgłoszenie anulowane.</b>\n\nRedacted odkłada formularz do szuflady. Twierdzi, że wcześniej panował tam idealny porządek.",
    "sent_title": "✅ WIADOMOŚĆ WYSŁANA DO LABORATORIUM",
    "sent_body": "Zgłoszenie wysłane. Redacted położył je na stosie ważnych rzeczy.\n\nOdpowiedź wsparcia otrzymasz tutaj. 🦖",
    "another_btn": "🐛 Wyślij kolejne zgłoszenie",
    "back_btn": "⬅️ Wróć do menu",
    "unknown": "🦖 Nie zrozumiałem tej prośby.\n\nJak na bota z laboratorium nie brzmi to szczególnie uspokajająco.",
    "channel_title": "📢 KANAŁ REDACTED BANNERLAB",
    "channel_body": "Wersje, changelogi, nowości i eksperymenty, które cudem przetrwały laboratorium.",
    "join_channel": "📢 Dołącz do kanału",
    "community_title": "💬 SPOŁECZNOŚĆ REDACTED BANNERLAB",
    "community_body": "Potrzebujesz pomocy, chcesz pokazać banner albo masz absurdalnie ambitny pomysł? Wspólne eksperymenty zaczynają się tutaj.",
    "join_group": "💬 Dołącz do grupy",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Niezależne narzędzie społecznościowe do przygotowywania, edycji i publikowania bannerów Ingress bez poświęcania trzech wieczorów i części zdrowia psychicznego.\n\n👨‍🔬 Autor: <b>Zw4nn</b>\n🦖 Nadzór o bardzo wątpliwej powadze: <b>Redacted</b>.",
    "choose_language": "🌐 <b>Wybierz język</b>\n\nRedacted spróbuje potem oceniać twoje bugi w odpowiednim języku.",
    "language_saved": "✅ Zapisano język: <b>{language}</b>",
    "lab_reply": "🦖 <b>ODPOWIEDŹ Z LABORATORIUM</b>",
    "lab_media": "Wsparcie wysłało ci plik lub multimedia 👇",
    "reply_again": "Chcesz odpowiedzieć lub wysłać coś jeszcze?"
  },
  "cs": {
    "label": "🇨🇿 Čeština",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Ahoj <b>{name}</b> 👋",
    "welcome": "Vítej u vstupu do laboratoře.\n\nTady můžeš kontaktovat podporu, sledovat nové verze a připojit se ke komunitě.\n\nRecepci měl původně řídit Redacted. Po několika incidentech s kabely a páskou jsme to raději zautomatizovali.",
    "support_btn": "🐛 Kontaktovat podporu",
    "channel_btn": "📢 Připojit se ke kanálu",
    "community_btn": "💬 Připojit se ke komunitě",
    "about_btn": "ℹ️ O aplikaci",
    "language_btn": "🌐 Jazyk",
    "support_title": "🐛 PODPORA REDACTED BANNERLAB",
    "support_body": "Dobře, Agente.\n\n<b>Pošli problém jednoduše v další zprávě.</b>\n\nMůžeš poslat text, screenshot, fotku, video, dokument nebo hlasovou zprávu.\n\nPokud můžeš, uveď verzi BannerLab, co jsi chtěl udělat, co se stalo a jak problém zopakovat.\n\n🦖 Klasické „nefunguje to“ je stále povoleno. Bez posuzování nic neslibujeme.",
    "cancel_btn": "❌ Zrušit",
    "cancelled": "❌ <b>Požadavek zrušen.</b>\n\nRedacted vrací formulář do šuplíku. Tvrdí, že tam předtím byl perfektní pořádek.",
    "sent_title": "✅ ZPRÁVA ODESLÁNA DO LABORATOŘE",
    "sent_body": "Požadavek byl odeslán. Redacted ho položil na hromádku důležitých věcí.\n\nOdpověď podpory dostaneš přímo sem. 🦖",
    "another_btn": "🐛 Poslat další požadavek",
    "back_btn": "⬅️ Zpět do menu",
    "unknown": "🦖 Tomuto požadavku jsem nerozuměl.\n\nOd bota v laboratoři to není úplně uklidňující.",
    "channel_title": "📢 KANÁL REDACTED BANNERLAB",
    "channel_body": "Verze, changelogy, novinky a experimenty, které zázračně přežily laboratoř.",
    "join_channel": "📢 Připojit se ke kanálu",
    "community_title": "💬 KOMUNITA REDACTED BANNERLAB",
    "community_body": "Potřebuješ pomoc, chceš ukázat banner nebo navrhnout šíleně ambiciózní nápad? Společné experimenty začínají tady.",
    "join_group": "💬 Připojit se ke skupině",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Nezávislý komunitní nástroj pro přípravu, úpravy a publikování Ingress bannerů bez obětování tří večerů a části duševního zdraví.\n\n👨‍🔬 Vytvořil <b>Zw4nn</b>\n🦖 S velmi pochybnou vážností dohlíží <b>Redacted</b>.",
    "choose_language": "🌐 <b>Vyber jazyk</b>\n\nRedacted se pak pokusí hodnotit tvoje bugy ve správném jazyce.",
    "language_saved": "✅ Jazyk uložen: <b>{language}</b>",
    "lab_reply": "🦖 <b>ODPOVĚĎ Z LABORATOŘE</b>",
    "lab_media": "Podpora ti poslala soubor nebo média 👇",
    "reply_again": "Chceš odpovědět nebo poslat něco dalšího?"
  },
  "ro": {
    "label": "🇷🇴 Română",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Salut <b>{name}</b> 👋",
    "welcome": "Bine ai venit la intrarea în laborator.\n\nAici poți contacta suportul, urmări versiunile noi și intra în comunitate.\n\nRedacted trebuia să se ocupe de recepție. După câteva incidente cu cabluri și bandă adezivă, am preferat automatizarea.",
    "support_btn": "🐛 Contactează suportul",
    "channel_btn": "📢 Intră pe canal",
    "community_btn": "💬 Intră în comunitate",
    "about_btn": "ℹ️ Despre",
    "language_btn": "🌐 Limbă",
    "support_title": "🐛 SUPORT REDACTED BANNERLAB",
    "support_body": "Bine, Agent.\n\n<b>Trimite pur și simplu problema în următorul mesaj.</b>\n\nPoți trimite text, captură, fotografie, video, document sau mesaj vocal.\n\nDacă poți, indică versiunea BannerLab, ce încercai să faci, ce s-a întâmplat și cum se reproduce.\n\n🦖 Clasicul „nu merge” este în continuare acceptat. Nu garantăm lipsa judecății.",
    "cancel_btn": "❌ Anulează",
    "cancelled": "❌ <b>Cerere anulată.</b>\n\nRedacted pune formularul înapoi în sertar. Susține că înainte era perfect ordonat.",
    "sent_title": "✅ MESAJ TRIMIS LA LABORATOR",
    "sent_body": "Cererea a plecat. Redacted a pus-o pe teancul lucrurilor importante.\n\nVei primi aici răspunsul suportului. 🦖",
    "another_btn": "🐛 Trimite altă cerere",
    "back_btn": "⬅️ Înapoi la meniu",
    "unknown": "🦖 Nu am înțeles această cerere.\n\nPentru un bot instalat într-un laborator, nu e foarte liniștitor.",
    "channel_title": "📢 CANAL REDACTED BANNERLAB",
    "channel_body": "Versiuni, changelog-uri, noutăți și experimente care au supraviețuit miraculos laboratorului.",
    "join_channel": "📢 Intră pe canal",
    "community_title": "💬 COMUNITATE REDACTED BANNERLAB",
    "community_body": "Ai nevoie de ajutor, vrei să arăți un banner sau ai o idee complet nerezonabilă? Experimentele colective încep aici.",
    "join_group": "💬 Intră în grup",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Un instrument comunitar independent pentru pregătirea, editarea și publicarea bannerelor Ingress fără a sacrifica trei seri și o parte din sănătatea mintală.\n\n👨‍🔬 Creat de <b>Zw4nn</b>\n🦖 Supravegheat cu o seriozitate foarte discutabilă de <b>Redacted</b>.",
    "choose_language": "🌐 <b>Alege limba</b>\n\nRedacted va încerca apoi să-ți judece bugurile în limba potrivită.",
    "language_saved": "✅ Limbă salvată: <b>{language}</b>",
    "lab_reply": "🦖 <b>RĂSPUNS DIN LABORATOR</b>",
    "lab_media": "Suportul ți-a trimis un fișier sau conținut media 👇",
    "reply_again": "Vrei să răspunzi sau să mai trimiți ceva?"
  },
  "tr": {
    "label": "🇹🇷 Türkçe",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Merhaba <b>{name}</b> 👋",
    "welcome": "Laboratuvarın girişine hoş geldin.\n\nBuradan desteğe ulaşabilir, yeni sürümleri takip edebilir ve topluluğa katılabilirsin.\n\nResepsiyonu Redacted yönetecekti. Kablolar ve bantla ilgili birkaç olaydan sonra otomasyona geçtik.",
    "support_btn": "🐛 Desteğe ulaş",
    "channel_btn": "📢 Kanala katıl",
    "community_btn": "💬 Topluluğa katıl",
    "about_btn": "ℹ️ Hakkında",
    "language_btn": "🌐 Dil",
    "support_title": "🐛 REDACTED BANNERLAB DESTEK",
    "support_body": "Peki Ajan.\n\n<b>Sorununu bir sonraki mesajında doğrudan gönder.</b>\n\nMetin, ekran görüntüsü, fotoğraf, video, belge veya sesli mesaj gönderebilirsin.\n\nMümkünse BannerLab sürümünü, ne yapmaya çalıştığını, ne olduğunu ve sorunun nasıl tekrarlandığını belirt.\n\n🦖 Klasik “çalışmıyor” hâlâ kabul ediliyor. Yargılanmama garantisi veremiyoruz.",
    "cancel_btn": "❌ İptal",
    "cancelled": "❌ <b>Talep iptal edildi.</b>\n\nRedacted formu çekmeceye geri koyuyor. Önceden kusursuz düzenli olduğunu iddia ediyor.",
    "sent_title": "✅ MESAJ LABORATUVARA GÖNDERİLDİ",
    "sent_body": "Talebin gönderildi. Redacted onu önemli şeyler yığınının üstüne koydu.\n\nDestek yanıtını burada alacaksın. 🦖",
    "another_btn": "🐛 Başka talep gönder",
    "back_btn": "⬅️ Menüye dön",
    "unknown": "🦖 Bu isteği anlamadım.\n\nLaboratuvardaki bir bot için pek güven verici değil.",
    "channel_title": "📢 REDACTED BANNERLAB KANALI",
    "channel_body": "Sürümler, değişiklik notları, haberler ve laboratuvardan mucizevi şekilde sağ çıkan deneyler.",
    "join_channel": "📢 Kanala katıl",
    "community_title": "💬 REDACTED BANNERLAB TOPLULUĞU",
    "community_body": "Yardıma mı ihtiyacın var, bir banner mı göstermek istiyorsun, yoksa tamamen mantıksız bir fikrin mi var? Ortak deneyler burada başlıyor.",
    "join_group": "💬 Gruba katıl",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Ingress banner'larını üç akşamını ve akıl sağlığının bir kısmını feda etmeden hazırlamak, düzenlemek ve yayınlamak için bağımsız bir topluluk aracı.\n\n👨‍🔬 <b>Zw4nn</b> tarafından oluşturuldu\n🦖 Son derece tartışmalı bir ciddiyetle <b>Redacted</b> tarafından denetleniyor.",
    "choose_language": "🌐 <b>Dilini seç</b>\n\nRedacted daha sonra hatalarını uygun dilde yargılamaya çalışacak.",
    "language_saved": "✅ Dil kaydedildi: <b>{language}</b>",
    "lab_reply": "🦖 <b>LABORATUVARDAN YANIT</b>",
    "lab_media": "Destek sana bir dosya veya medya gönderdi 👇",
    "reply_again": "Yanıtlamak veya başka bir şey göndermek ister misin?"
  },
  "ru": {
    "label": "🇷🇺 Русский",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Привет, <b>{name}</b> 👋",
    "welcome": "Добро пожаловать ко входу в лабораторию.\n\nЗдесь можно связаться с поддержкой, следить за новыми версиями и вступить в сообщество.\n\nRedacted должен был работать на ресепшене. После нескольких происшествий с проводами и скотчем мы решили всё автоматизировать.",
    "support_btn": "🐛 Связаться с поддержкой",
    "channel_btn": "📢 Вступить в канал",
    "community_btn": "💬 Вступить в сообщество",
    "about_btn": "ℹ️ О проекте",
    "language_btn": "🌐 Язык",
    "support_title": "🐛 ПОДДЕРЖКА REDACTED BANNERLAB",
    "support_body": "Хорошо, Агент.\n\n<b>Просто отправь описание проблемы следующим сообщением.</b>\n\nМожно отправить текст, скриншот, фото, видео, документ или голосовое сообщение.\n\nЕсли возможно, укажи версию BannerLab, что ты хотел сделать, что произошло и как воспроизвести проблему.\n\n🦖 Классическое «не работает» всё ещё принимается. Отсутствие осуждения не гарантируем.",
    "cancel_btn": "❌ Отмена",
    "cancelled": "❌ <b>Запрос отменён.</b>\n\nRedacted кладёт форму обратно в ящик. Он утверждает, что до этого там был идеальный порядок.",
    "sent_title": "✅ СООБЩЕНИЕ ОТПРАВЛЕНО В ЛАБОРАТОРИЮ",
    "sent_body": "Запрос отправлен. Redacted положил его в стопку важных дел.\n\nОтвет поддержки придёт прямо сюда. 🦖",
    "another_btn": "🐛 Отправить ещё запрос",
    "back_btn": "⬅️ Назад в меню",
    "unknown": "🦖 Я не понял этот запрос.\n\nДля бота из лаборатории звучит не слишком обнадёживающе.",
    "channel_title": "📢 КАНАЛ REDACTED BANNERLAB",
    "channel_body": "Версии, changelog, новости и эксперименты, чудом пережившие лабораторию.",
    "join_channel": "📢 Вступить в канал",
    "community_title": "💬 СООБЩЕСТВО REDACTED BANNERLAB",
    "community_body": "Нужна помощь, хочешь показать баннер или предложить совершенно безумную идею? Совместные эксперименты начинаются здесь.",
    "join_group": "💬 Вступить в группу",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Независимый инструмент сообщества для подготовки, редактирования и публикации Ingress-баннеров без жертвы трёх вечеров и части здравого смысла.\n\n👨‍🔬 Создано <b>Zw4nn</b>\n🦖 Под крайне сомнительным надзором <b>Redacted</b>.",
    "choose_language": "🌐 <b>Выбери язык</b>\n\nRedacted постарается осуждать твои баги на подходящем языке.",
    "language_saved": "✅ Язык сохранён: <b>{language}</b>",
    "lab_reply": "🦖 <b>ОТВЕТ ИЗ ЛАБОРАТОРИИ</b>",
    "lab_media": "Поддержка отправила тебе файл или медиа 👇",
    "reply_again": "Хочешь ответить или отправить что-то ещё?"
  },
  "uk": {
    "label": "🇺🇦 Українська",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Привіт, <b>{name}</b> 👋",
    "welcome": "Ласкаво просимо до входу в лабораторію.\n\nТут можна звернутися до підтримки, стежити за новими версіями та приєднатися до спільноти.\n\nRedacted мав працювати на рецепції. Після кількох пригод із кабелями та скотчем ми вирішили все автоматизувати.",
    "support_btn": "🐛 Звернутися до підтримки",
    "channel_btn": "📢 Приєднатися до каналу",
    "community_btn": "💬 Приєднатися до спільноти",
    "about_btn": "ℹ️ Про проєкт",
    "language_btn": "🌐 Мова",
    "support_title": "🐛 ПІДТРИМКА REDACTED BANNERLAB",
    "support_body": "Добре, Агенте.\n\n<b>Просто надішли опис проблеми наступним повідомленням.</b>\n\nМожна надсилати текст, скриншот, фото, відео, документ або голосове повідомлення.\n\nЯкщо можливо, вкажи версію BannerLab, що ти хотів зробити, що сталося і як відтворити проблему.\n\n🦖 Класичне «не працює» все ще дозволено. Відсутність осуду не гарантуємо.",
    "cancel_btn": "❌ Скасувати",
    "cancelled": "❌ <b>Запит скасовано.</b>\n\nRedacted повертає форму до шухляди. Каже, що до цього там був ідеальний порядок.",
    "sent_title": "✅ ПОВІДОМЛЕННЯ НАДІСЛАНО ДО ЛАБОРАТОРІЇ",
    "sent_body": "Запит надіслано. Redacted поклав його до стосу важливих справ.\n\nВідповідь підтримки прийде прямо сюди. 🦖",
    "another_btn": "🐛 Надіслати ще запит",
    "back_btn": "⬅️ Назад до меню",
    "unknown": "🦖 Я не зрозумів цей запит.\n\nДля бота з лабораторії це не дуже заспокійливо.",
    "channel_title": "📢 КАНАЛ REDACTED BANNERLAB",
    "channel_body": "Версії, changelog, новини та експерименти, які дивом пережили лабораторію.",
    "join_channel": "📢 Приєднатися до каналу",
    "community_title": "💬 СПІЛЬНОТА REDACTED BANNERLAB",
    "community_body": "Потрібна допомога, хочеш показати банер чи маєш абсолютно божевільну ідею? Спільні експерименти починаються тут.",
    "join_group": "💬 Приєднатися до групи",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Незалежний інструмент спільноти для підготовки, редагування та публікації Ingress-банерів без жертвування трьома вечорами й частиною здорового глузду.\n\n👨‍🔬 Створив <b>Zw4nn</b>\n🦖 Під дуже сумнівно серйозним наглядом <b>Redacted</b>.",
    "choose_language": "🌐 <b>Обери мову</b>\n\nRedacted спробує оцінювати твої баги відповідною мовою.",
    "language_saved": "✅ Мову збережено: <b>{language}</b>",
    "lab_reply": "🦖 <b>ВІДПОВІДЬ ІЗ ЛАБОРАТОРІЇ</b>",
    "lab_media": "Підтримка надіслала тобі файл або медіа 👇",
    "reply_again": "Хочеш відповісти або надіслати ще щось?"
  },
  "ja": {
    "label": "🇯🇵 日本語",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "こんにちは <b>{name}</b> 👋",
    "welcome": "研究所の入口へようこそ。\n\nここではサポートへの連絡、新バージョンの確認、コミュニティへの参加ができます。\n\n本来はRedactedが受付を担当する予定でした。ケーブルとテープをめぐる数件の事故のあと、自動化することにしました。",
    "support_btn": "🐛 サポートに連絡",
    "channel_btn": "📢 チャンネルに参加",
    "community_btn": "💬 コミュニティに参加",
    "about_btn": "ℹ️ このBotについて",
    "language_btn": "🌐 言語",
    "support_title": "🐛 REDACTED BANNERLAB サポート",
    "support_body": "了解です、エージェント。\n\n<b>次のメッセージで問題をそのまま送ってください。</b>\n\nテキスト、スクリーンショット、写真、動画、文書、音声メッセージを送れます。\n\n可能ならBannerLabのバージョン、やりたかったこと、実際に起きたこと、再現手順を書いてください。\n\n🦖 伝統の「動きません」だけでも受け付けます。Redactedが無言で評価しない保証はありません。",
    "cancel_btn": "❌ キャンセル",
    "cancelled": "❌ <b>問い合わせをキャンセルしました。</b>\n\nRedactedがフォームを引き出しに戻しています。最初から完璧に整理されていたと言い張っています。",
    "sent_title": "✅ 研究所へ送信しました",
    "sent_body": "問い合わせを送信しました。Redactedが「重要なもの」の山に置きました。\n\nサポートからの返信はここに届きます。🦖",
    "another_btn": "🐛 別の問い合わせを送る",
    "back_btn": "⬅️ メニューへ戻る",
    "unknown": "🦖 その内容は理解できませんでした。\n\n研究所のBotとしては、あまり安心できる発言ではありません。",
    "channel_title": "📢 REDACTED BANNERLAB チャンネル",
    "channel_body": "新バージョン、変更履歴、ニュース、そして研究所を奇跡的に生き延びた実験のお知らせ。",
    "join_channel": "📢 チャンネルに参加",
    "community_title": "💬 REDACTED BANNERLAB コミュニティ",
    "community_body": "助けが必要？ バナーを見せたい？ 次のバージョンに入れたくなる無茶なアイデアがある？ 共同実験はここからです。",
    "join_group": "💬 グループに参加",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Ingressバナーの準備・編集・公開を、3晩と正気の一部を犠牲にせず行うための独立コミュニティツールです。\n\n👨‍🔬 制作: <b>Zw4nn</b>\n🦖 非常に疑わしい真剣さで監督: <b>Redacted</b>",
    "choose_language": "🌐 <b>言語を選択</b>\n\nRedactedが、その言語であなたのバグを評価しようとします。",
    "language_saved": "✅ 言語を保存しました: <b>{language}</b>",
    "lab_reply": "🦖 <b>研究所からの返信</b>",
    "lab_media": "サポートからファイルまたはメディアが届きました 👇",
    "reply_again": "返信または追加送信が必要ですか？"
  },
  "ko": {
    "label": "🇰🇷 한국어",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "안녕하세요 <b>{name}</b> 👋",
    "welcome": "연구소 입구에 오신 것을 환영합니다.\n\n여기서 지원팀에 문의하고, 새 버전을 확인하고, 커뮤니티에 참여할 수 있습니다.\n\n원래는 Redacted가 접수를 맡을 예정이었습니다. 케이블과 테이프 관련 사고가 몇 번 난 뒤 자동화하기로 했습니다.",
    "support_btn": "🐛 지원 문의",
    "channel_btn": "📢 채널 참여",
    "community_btn": "💬 커뮤니티 참여",
    "about_btn": "ℹ️ 정보",
    "language_btn": "🌐 언어",
    "support_title": "🐛 REDACTED BANNERLAB 지원",
    "support_body": "좋습니다, 에이전트.\n\n<b>다음 메시지에 문제를 그대로 보내주세요.</b>\n\n텍스트, 스크린샷, 사진, 동영상, 문서, 음성 메시지를 보낼 수 있습니다.\n\n가능하면 BannerLab 버전, 하려던 작업, 실제로 일어난 일, 재현 방법을 적어주세요.\n\n🦖 전통적인 “안 돼요”도 접수됩니다. Redacted가 조용히 판단하지 않는다고는 약속 못 합니다.",
    "cancel_btn": "❌ 취소",
    "cancelled": "❌ <b>요청이 취소되었습니다.</b>\n\nRedacted가 양식을 서랍에 다시 넣고 있습니다. 원래 완벽하게 정리되어 있었다고 주장합니다.",
    "sent_title": "✅ 연구소로 전송했습니다",
    "sent_body": "요청을 전송했습니다. Redacted가 중요한 일 더미에 올려두었습니다.\n\n지원팀 답변은 이 채팅으로 바로 옵니다. 🦖",
    "another_btn": "🐛 다른 요청 보내기",
    "back_btn": "⬅️ 메뉴로",
    "unknown": "🦖 그 요청은 이해하지 못했습니다.\n\n연구소에 설치된 Bot치고는 별로 안심되는 말이 아니군요.",
    "channel_title": "📢 REDACTED BANNERLAB 채널",
    "channel_body": "새 버전, 변경 내역, 소식, 그리고 연구소에서 기적적으로 살아남은 실험들.",
    "join_channel": "📢 채널 참여",
    "community_title": "💬 REDACTED BANNERLAB 커뮤니티",
    "community_body": "도움이 필요하거나 배너를 보여주고 싶거나 터무니없이 야심찬 아이디어가 있나요? 공동 실험은 여기서 시작됩니다.",
    "join_group": "💬 그룹 참여",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "세 번의 저녁과 정신 건강 일부를 희생하지 않고 Ingress 배너를 준비·편집·게시하기 위한 독립 커뮤니티 도구입니다.\n\n👨‍🔬 제작: <b>Zw4nn</b>\n🦖 매우 의심스러운 진지함으로 감독: <b>Redacted</b>",
    "choose_language": "🌐 <b>언어를 선택하세요</b>\n\nRedacted가 적절한 언어로 버그를 판단해 보겠습니다.",
    "language_saved": "✅ 언어 저장됨: <b>{language}</b>",
    "lab_reply": "🦖 <b>연구소 답변</b>",
    "lab_media": "지원팀에서 파일 또는 미디어를 보냈습니다 👇",
    "reply_again": "답장하거나 더 보낼 것이 있나요?"
  },
  "zh-CN": {
    "label": "🇨🇳 简体中文",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "你好 <b>{name}</b> 👋",
    "welcome": "欢迎来到实验室入口。\n\n你可以在这里联系支持、查看新版本并加入社区。\n\n原本应该由 Redacted 负责接待。经历了几次与电缆和胶带有关的事故后，我们决定把这件事自动化。",
    "support_btn": "🐛 联系支持",
    "channel_btn": "📢 加入频道",
    "community_btn": "💬 加入社区",
    "about_btn": "ℹ️ 关于",
    "language_btn": "🌐 语言",
    "support_title": "🐛 REDACTED BANNERLAB 支持",
    "support_body": "好的，特工。\n\n<b>请直接在下一条消息里发送你的问题。</b>\n\n可以发送文字、截图、照片、视频、文档或语音。\n\n最好附上 BannerLab 版本、你想做什么、实际发生了什么，以及如何复现。\n\n🦖 经典的“它不能用”依然接受。至于 Redacted 会不会默默评价你，我们不保证。",
    "cancel_btn": "❌ 取消",
    "cancelled": "❌ <b>请求已取消。</b>\n\nRedacted 正把表格塞回抽屉，并坚称那里原本非常整齐。",
    "sent_title": "✅ 已发送到实验室",
    "sent_body": "你的请求已经送出。Redacted 把它放进了“重要事项”那一堆。\n\n支持回复会直接发到这里。🦖",
    "another_btn": "🐛 再发一个请求",
    "back_btn": "⬅️ 返回菜单",
    "unknown": "🦖 我没有理解这个请求。\n\n对于一个实验室里的 Bot 来说，这并不特别令人安心。",
    "channel_title": "📢 REDACTED BANNERLAB 频道",
    "channel_body": "新版本、更新日志、消息，以及那些奇迹般活着走出实验室的实验。",
    "join_channel": "📢 加入频道",
    "community_title": "💬 REDACTED BANNERLAB 社区",
    "community_body": "需要帮助、想展示你的 banner，或者有一个离谱但可能会进入下一版的想法？集体实验从这里开始。",
    "join_group": "💬 加入群组",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "一个独立的社区工具，用来准备、编辑和发布 Ingress banner，而不用牺牲三个晚上和一部分理智。\n\n👨‍🔬 创建者：<b>Zw4nn</b>\n🦖 以非常可疑的认真程度监督：<b>Redacted</b>",
    "choose_language": "🌐 <b>选择语言</b>\n\n之后 Redacted 会尝试用正确的语言评价你的 bug。",
    "language_saved": "✅ 已保存语言：<b>{language}</b>",
    "lab_reply": "🦖 <b>实验室回复</b>",
    "lab_media": "支持团队给你发送了文件或媒体 👇",
    "reply_again": "需要回复或继续发送内容吗？"
  },
  "zh-TW": {
    "label": "🇹🇼 繁體中文",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "你好 <b>{name}</b> 👋",
    "welcome": "歡迎來到實驗室入口。\n\n你可以在這裡聯絡支援、查看新版本並加入社群。\n\n原本應該由 Redacted 負責接待。經歷幾次與電線和膠帶有關的事故後，我們決定自動化。",
    "support_btn": "🐛 聯絡支援",
    "channel_btn": "📢 加入頻道",
    "community_btn": "💬 加入社群",
    "about_btn": "ℹ️ 關於",
    "language_btn": "🌐 語言",
    "support_title": "🐛 REDACTED BANNERLAB 支援",
    "support_body": "好的，特工。\n\n<b>請直接在下一則訊息裡傳送你的問題。</b>\n\n可以傳文字、截圖、照片、影片、文件或語音。\n\n最好附上 BannerLab 版本、你原本想做什麼、實際發生什麼，以及如何重現。\n\n🦖 經典的「不能用」仍然接受。至於 Redacted 會不會默默評價你，我們不保證。",
    "cancel_btn": "❌ 取消",
    "cancelled": "❌ <b>請求已取消。</b>\n\nRedacted 正把表格塞回抽屜，並堅稱那裡原本非常整齊。",
    "sent_title": "✅ 已傳送到實驗室",
    "sent_body": "你的請求已送出。Redacted 把它放到「重要事項」那一堆。\n\n支援回覆會直接傳到這裡。🦖",
    "another_btn": "🐛 再傳一個請求",
    "back_btn": "⬅️ 返回選單",
    "unknown": "🦖 我沒有理解這個請求。\n\n對一個實驗室裡的 Bot 來說，這並不特別令人安心。",
    "channel_title": "📢 REDACTED BANNERLAB 頻道",
    "channel_body": "新版本、更新紀錄、消息，以及那些奇蹟般活著走出實驗室的實驗。",
    "join_channel": "📢 加入頻道",
    "community_title": "💬 REDACTED BANNERLAB 社群",
    "community_body": "需要幫忙、想展示你的 banner，或有一個離譜但可能會進下一版的想法？集體實驗從這裡開始。",
    "join_group": "💬 加入群組",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "一個獨立的社群工具，用來準備、編輯和發布 Ingress banner，而不用犧牲三個晚上和一部分理智。\n\n👨‍🔬 建立者：<b>Zw4nn</b>\n🦖 以非常可疑的認真程度監督：<b>Redacted</b>",
    "choose_language": "🌐 <b>選擇語言</b>\n\n之後 Redacted 會嘗試用正確的語言評價你的 bug。",
    "language_saved": "✅ 已儲存語言：<b>{language}</b>",
    "lab_reply": "🦖 <b>實驗室回覆</b>",
    "lab_media": "支援團隊傳送了檔案或媒體給你 👇",
    "reply_again": "需要回覆或繼續傳送內容嗎？"
  },
  "yue": {
    "label": "🇭🇰 廣東話",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "你好呀 <b>{name}</b> 👋",
    "welcome": "歡迎嚟到實驗室入口。\n\n你可以喺度搵支援、睇新版本，同埋加入社群。\n\n本來想叫 Redacted 負責接待。經過幾次電線同膠紙事故之後，我哋決定交俾自動化算數。",
    "support_btn": "🐛 搵支援",
    "channel_btn": "📢 加入頻道",
    "community_btn": "💬 加入社群",
    "about_btn": "ℹ️ 關於",
    "language_btn": "🌐 語言",
    "support_title": "🐛 REDACTED BANNERLAB 支援",
    "support_body": "好啦，特工。\n\n<b>下一個訊息直接講你遇到咩問題就得。</b>\n\n文字、截圖、相、影片、文件或者語音都得。\n\n最好講埋 BannerLab 版本、你原本想做咩、結果發生咗咩，同埋點樣重現。\n\n🦖 經典嘅「唔得喎」一樣收貨。不過 Redacted 會唔會靜靜雞評價你，我哋唔包。",
    "cancel_btn": "❌ 取消",
    "cancelled": "❌ <b>已取消支援請求。</b>\n\nRedacted 正將張表塞返入櫃桶，仲堅持話本身好整齊。",
    "sent_title": "✅ 已送到實驗室",
    "sent_body": "你嘅請求已經送出。Redacted 將佢放咗落「重要嘢」嗰疊。\n\n支援回覆會直接喺呢度收到。🦖",
    "another_btn": "🐛 再發一個請求",
    "back_btn": "⬅️ 返回選單",
    "unknown": "🦖 我唔係好明你呢個要求。\n\n一個實驗室 Bot 咁講，的確唔算太令人安心。",
    "channel_title": "📢 REDACTED BANNERLAB 頻道",
    "channel_body": "新版本、更新紀錄、消息，同埋啲奇蹟地生存到離開實驗室嘅實驗。",
    "join_channel": "📢 加入頻道",
    "community_title": "💬 REDACTED BANNERLAB 社群",
    "community_body": "要幫手、想晒下你張 banner，定係有個離譜到可能會入下一版嘅主意？集體實驗由呢度開始。",
    "join_group": "💬 加入群組",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "一個獨立社群工具，用嚟準備、編輯同發布 Ingress banner，唔使犧牲三晚同一部分理智。\n\n👨‍🔬 <b>Zw4nn</b> 製作\n🦖 由 <b>Redacted</b> 用非常可疑嘅認真程度監督。",
    "choose_language": "🌐 <b>揀語言</b>\n\n之後 Redacted 會嘗試用啱嘅語言評價你啲 bug。",
    "language_saved": "✅ 已儲存語言：<b>{language}</b>",
    "lab_reply": "🦖 <b>實驗室回覆</b>",
    "lab_media": "支援傳咗檔案或者媒體俾你 👇",
    "reply_again": "要回覆或者再傳其他嘢嗎？"
  },
  "ar": {
    "label": "🇸🇦 العربية",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "مرحبًا <b>{name}</b> 👋",
    "welcome": "مرحبًا بك عند مدخل المختبر.\n\nمن هنا يمكنك التواصل مع الدعم، متابعة الإصدارات الجديدة والانضمام إلى المجتمع.\n\nكان من المفترض أن يدير Redacted الاستقبال. بعد عدة حوادث مع الأسلاك والشريط اللاصق قررنا أتمتة العملية.",
    "support_btn": "🐛 تواصل مع الدعم",
    "channel_btn": "📢 انضم إلى القناة",
    "community_btn": "💬 انضم إلى المجتمع",
    "about_btn": "ℹ️ حول",
    "language_btn": "🌐 اللغة",
    "support_title": "🐛 دعم REDACTED BANNERLAB",
    "support_body": "حسنًا أيها العميل.\n\n<b>أرسل مشكلتك ببساطة في رسالتك التالية.</b>\n\nيمكنك إرسال نص أو لقطة شاشة أو صورة أو فيديو أو ملف أو رسالة صوتية.\n\nإن أمكن، اذكر إصدار BannerLab وما الذي كنت تحاول فعله وما الذي حدث وكيف يمكن إعادة المشكلة.\n\n🦖 عبارة «لا يعمل» التقليدية ما زالت مقبولة. لكننا لا نضمن غياب الأحكام الصامتة.",
    "cancel_btn": "❌ إلغاء",
    "cancelled": "❌ <b>تم إلغاء الطلب.</b>\n\nيعيد Redacted النموذج إلى الدرج ويدّعي أنه كان مرتبًا تمامًا من قبل.",
    "sent_title": "✅ تم إرسال الرسالة إلى المختبر",
    "sent_body": "تم إرسال طلبك. وضعه Redacted فوق كومة الأشياء المهمة.\n\nستصلك إجابة الدعم هنا مباشرة. 🦖",
    "another_btn": "🐛 إرسال طلب آخر",
    "back_btn": "⬅️ العودة إلى القائمة",
    "unknown": "🦖 لم أفهم هذا الطلب.\n\nهذا ليس مطمئنًا جدًا من Bot موجود في مختبر.",
    "channel_title": "📢 قناة REDACTED BANNERLAB",
    "channel_body": "الإصدارات وسجل التغييرات والأخبار والتجارب التي نجت من المختبر بأعجوبة.",
    "join_channel": "📢 انضم إلى القناة",
    "community_title": "💬 مجتمع REDACTED BANNERLAB",
    "community_body": "تحتاج مساعدة؟ تريد عرض banner؟ لديك فكرة غير معقولة قد تدخل الإصدار القادم؟ التجارب الجماعية تبدأ هنا.",
    "join_group": "💬 انضم إلى المجموعة",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "أداة مجتمعية مستقلة لإعداد وتحرير ونشر banners في Ingress دون التضحية بثلاث أمسيات وجزء من سلامتك العقلية.\n\n👨‍🔬 أنشأها <b>Zw4nn</b>\n🦖 يشرف عليها <b>Redacted</b> بجدية مشكوك فيها جدًا.",
    "choose_language": "🌐 <b>اختر لغتك</b>\n\nسيحاول Redacted بعدها الحكم على أخطائك باللغة المناسبة.",
    "language_saved": "✅ تم حفظ اللغة: <b>{language}</b>",
    "lab_reply": "🦖 <b>رد المختبر</b>",
    "lab_media": "أرسل لك الدعم ملفًا أو وسائط 👇",
    "reply_again": "تريد الرد أو إرسال شيء آخر؟"
  },
  "id": {
    "label": "🇮🇩 Bahasa Indonesia",
    "welcome_title": "🦖 REDACTED BANNERLAB",
    "hello": "Halo <b>{name}</b> 👋",
    "welcome": "Selamat datang di pintu masuk laboratorium.\n\nDi sini kamu bisa menghubungi dukungan, mengikuti versi baru, dan bergabung dengan komunitas.\n\nAwalnya Redacted ditugaskan menjaga resepsionis. Setelah beberapa insiden dengan kabel dan selotip, kami memilih otomatisasi.",
    "support_btn": "🐛 Hubungi dukungan",
    "channel_btn": "📢 Gabung kanal",
    "community_btn": "💬 Gabung komunitas",
    "about_btn": "ℹ️ Tentang",
    "language_btn": "🌐 Bahasa",
    "support_title": "🐛 DUKUNGAN REDACTED BANNERLAB",
    "support_body": "Baik, Agen.\n\n<b>Kirim saja masalahmu di pesan berikutnya.</b>\n\nKamu bisa mengirim teks, tangkapan layar, foto, video, dokumen, atau pesan suara.\n\nJika bisa, sertakan versi BannerLab, apa yang ingin dilakukan, apa yang terjadi, dan cara mengulang masalahnya.\n\n🦖 Kalimat klasik “nggak jalan” tetap diterima. Kami tidak menjamin Redacted tidak akan menilai diam-diam.",
    "cancel_btn": "❌ Batal",
    "cancelled": "❌ <b>Permintaan dibatalkan.</b>\n\nRedacted memasukkan formulir kembali ke laci. Katanya tadi semuanya sudah rapi.",
    "sent_title": "✅ PESAN DIKIRIM KE LAB",
    "sent_body": "Permintaanmu sudah dikirim. Redacted menaruhnya di tumpukan hal penting.\n\nBalasan dukungan akan datang langsung ke sini. 🦖",
    "another_btn": "🐛 Kirim permintaan lain",
    "back_btn": "⬅️ Kembali ke menu",
    "unknown": "🦖 Aku tidak memahami permintaan itu.\n\nUntuk Bot yang tinggal di laboratorium, ini memang tidak terlalu menenangkan.",
    "channel_title": "📢 KANAL REDACTED BANNERLAB",
    "channel_body": "Versi baru, changelog, berita, dan eksperimen yang entah bagaimana selamat dari laboratorium.",
    "join_channel": "📢 Gabung kanal",
    "community_title": "💬 KOMUNITAS REDACTED BANNERLAB",
    "community_body": "Butuh bantuan, ingin menunjukkan banner, atau punya ide keterlaluan untuk versi berikutnya? Eksperimen bersama dimulai di sini.",
    "join_group": "💬 Gabung grup",
    "about_title": "ℹ️ REDACTED BANNERLAB",
    "about_body": "Alat komunitas independen untuk menyiapkan, mengedit, dan menerbitkan banner Ingress tanpa mengorbankan tiga malam dan sebagian kewarasan.\n\n👨‍🔬 Dibuat oleh <b>Zw4nn</b>\n🦖 Diawasi dengan tingkat keseriusan yang sangat meragukan oleh <b>Redacted</b>.",
    "choose_language": "🌐 <b>Pilih bahasa</b>\n\nSetelah itu Redacted akan mencoba menilai bug-mu dalam bahasa yang sesuai.",
    "language_saved": "✅ Bahasa disimpan: <b>{language}</b>",
    "lab_reply": "🦖 <b>BALASAN DARI LAB</b>",
    "lab_media": "Dukungan mengirim file atau media untukmu 👇",
    "reply_again": "Perlu membalas atau mengirim hal lain?"
  }
};


// -----------------------------------------------------------------------------
// FAQ intelligente / aide rapide (prototype test)
// Les menus existants restent multilingues. La FAQ est traduite en FR/EN ;
// les autres langues utilisent automatiquement l'anglais en fallback.
// -----------------------------------------------------------------------------
const FAQ_I18N = {
  fr: {
    faq_btn: "🧠 Aide rapide / FAQ",
    faq_title: "🧠 AIDE RAPIDE REDACTED BANNERLAB",
    faq_intro: "Décris ton problème avec tes mots ou choisis un sujet. Redacted essaie d'abord les solutions connues avant de déranger un humain. Quelle époque.",
    faq_detected: "🔎 J'ai repéré un sujet qui ressemble à ta question :",
    faq_no_match: "🦖 Je n'ai pas trouvé une réponse assez sûre. Choisis le sujet le plus proche, ou passe directement au support.",
    faq_back: "⬅️ Sujet précédent",
    faq_home: "🏠 FAQ",
    faq_support: "🐛 Passer au support",
    yes: "✅ Oui",
    no: "❌ Non",
    solved: "✅ C'est réglé",
    not_solved: "🐛 Toujours bloqué",
  },
  en: {
    faq_btn: "🧠 Quick help / FAQ",
    faq_title: "🧠 REDACTED BANNERLAB QUICK HELP",
    faq_intro: "Describe the problem in your own words or choose a topic. Redacted will try known fixes before bothering a human. Civilization survives another minute.",
    faq_detected: "🔎 I found a topic that looks related to your question:",
    faq_no_match: "🦖 I could not find a sufficiently reliable answer. Pick the closest topic or go straight to support.",
    faq_back: "⬅️ Previous topic",
    faq_home: "🏠 FAQ",
    faq_support: "🐛 Contact support",
    yes: "✅ Yes",
    no: "❌ No",
    solved: "✅ Fixed",
    not_solved: "🐛 Still stuck",
  }
};

const FAQ_NODES = {
  root: {
    fr: ["🧠 <b>FAQ & diagnostic</b>", "Choisis ce qui ressemble le plus à ton problème. Tu peux aussi écrire directement une phrase comme « Publisher ne se lance pas » ou « mise à jour bloquée »."],
    en: ["🧠 <b>FAQ & diagnostics</b>", "Choose the topic closest to your issue. You can also type a sentence such as “Publisher does not start” or “update is stuck”."],
    rows: [
      [["📤 Publisher / Chrome", "faq:publisher"]],
      [["📦 Installation / mise à jour", "faq:update"]],
      [["🧪 IGOR / IITC / parcours", "faq:igor"]],
      [["💾 Sauvegarde / projets", "faq:backup"]],
      [["🖼️ Images / calques / Studio", "faq:studio"]],
    ]
  },

  publisher: {
    fr: ["📤 <b>Publisher / Chrome</b>", "Tu bloques à quel moment ?"],
    en: ["📤 <b>Publisher / Chrome</b>", "Where are you stuck?"],
    rows: [
      [["🧩 Installer Publisher", "faq:publisher_saved"]],
      [["⭐ Créer / modifier le favori", "faq:publisher_bookmark"]],
      [["▶️ Lancer RBL Publisher", "faq:publisher_launch"]],
      [["📄 Choisir le bon fichier", "faq:publisher_file"]],
      [["🔐 Autorisation Chrome", "faq:publisher_permission"]],
    ],
    parent: "root"
  },

  publisher_saved: {
    fr: ["🧩 <b>Installation de Publisher</b>", "As-tu déjà enregistré le fichier <code>redacted-bannerlab-publisher.user.js</code> depuis le tutoriel Chrome de RBL ?"],
    en: ["🧩 <b>Publisher installation</b>", "Have you already saved <code>redacted-bannerlab-publisher.user.js</code> from RBL's Chrome tutorial?"],
    rows: [
      [["✅ Oui", "faq:publisher_bookmark"], ["❌ Non", "faq:publisher_save_how"]],
    ],
    parent: "publisher"
  },

  publisher_save_how: {
    fr: ["📁 <b>Enregistre d'abord Publisher</b>", "Dans RBL : <b>Publier → Chrome → Configurer Chrome</b>. À la première étape, choisis un dossier facile à retrouver puis enregistre le Publisher. RBL mémorise ce dossier."],
    en: ["📁 <b>Save Publisher first</b>", "In RBL: <b>Publish → Chrome → Set up Chrome</b>. On the first step choose an easy-to-find folder and save Publisher. RBL remembers that folder."],
    rows: [
      [["✅ C'est fait", "faq:publisher_bookmark"]],
    ],
    parent: "publisher_saved"
  },

  publisher_bookmark: {
    fr: ["⭐ <b>Favori Chrome</b>", "Le favori <b>RBL Publisher</b> existe-t-il déjà dans Chrome ?"],
    en: ["⭐ <b>Chrome bookmark</b>", "Does the <b>RBL Publisher</b> bookmark already exist in Chrome?"],
    rows: [
      [["✅ Oui", "faq:publisher_launch"], ["❌ Non", "faq:publisher_bookmark_how"]],
    ],
    parent: "publisher"
  },

  publisher_bookmark_how: {
    fr: ["⭐ <b>Créer le favori</b>", "Ouvre <b>missions.ingress.com</b> dans Chrome, ajoute la page aux favoris, puis ouvre <b>Favoris d'appareils mobiles</b>. Sur le favori Mission Authoring : menu → <b>Modifier</b>. Mets le nom <b>RBL Publisher</b> et remplace complètement l'URL par le mini-code copié depuis RBL."],
    en: ["⭐ <b>Create the bookmark</b>", "Open <b>missions.ingress.com</b> in Chrome and bookmark the page. Open <b>Mobile bookmarks</b>, edit the Mission Authoring bookmark, rename it <b>RBL Publisher</b> and replace its whole URL with the mini-code copied from RBL."],
    rows: [
      [["✅ C'est fait", "faq:publisher_launch"]],
    ],
    parent: "publisher_bookmark"
  },

  publisher_launch: {
    fr: ["▶️ <b>Lancer Publisher</b>", "Sur Mission Authoring, touche la barre d'adresse et commence à taper <b>RBL Publisher</b>. Le favori apparaît-il dans les suggestions avec une étoile ?"],
    en: ["▶️ <b>Run Publisher</b>", "On Mission Authoring, tap the address bar and start typing <b>RBL Publisher</b>. Does the bookmark appear in suggestions with a star?"],
    rows: [
      [["✅ Oui", "faq:publisher_permission"], ["❌ Non", "faq:publisher_not_found"]],
    ],
    parent: "publisher"
  },

  publisher_not_found: {
    fr: ["🔎 <b>Favori introuvable</b>", "Vérifie dans Chrome → Favoris → Favoris d'appareils mobiles que le nom est bien <b>RBL Publisher</b>. Ouvre <b>Modifier</b> et vérifie aussi que l'URL commence par <code>javascript:</code>. Ne colle pas le code dans une recherche Google : il doit être dans l'URL du favori."],
    en: ["🔎 <b>Bookmark not found</b>", "Check Chrome → Bookmarks → Mobile bookmarks. The name should be <b>RBL Publisher</b>. Edit it and make sure its URL starts with <code>javascript:</code>. The code belongs in the bookmark URL, not in a Google search."],
    rows: [
      [["✅ Je le vois maintenant", "faq:publisher_permission"]],
    ],
    parent: "publisher_launch"
  },

  publisher_permission: {
    fr: ["🔐 <b>Autorisation du fichier</b>", "Au premier lancement, Chrome peut demander : « Autoriser ce site à consulter et à copier redacted-bannerlab-publisher.user.js ? ». Vois-tu cette fenêtre ?"],
    en: ["🔐 <b>File permission</b>", "On first run Chrome may ask whether the site can access and copy redacted-bannerlab-publisher.user.js. Do you see that prompt?"],
    rows: [
      [["✅ Oui", "faq:publisher_allow"], ["❌ Non", "faq:publisher_file"]],
    ],
    parent: "publisher"
  },

  publisher_allow: {
    fr: ["✅ <b>Autorise</b>", "Touche <b>Autoriser</b>. Cette permission ne donne accès qu'au fichier Publisher que tu as choisi. Ensuite le panneau <b>RBL Publisher</b> doit apparaître dans Mission Authoring."],
    en: ["✅ <b>Allow it</b>", "Tap <b>Allow</b>. This permission only grants access to the Publisher file you selected. The <b>RBL Publisher</b> panel should then appear in Mission Authoring."],
    rows: [
      [["✅ Le panneau apparaît", "faq:publisher_file"], ["🐛 Toujours rien", "support"]],
    ],
    parent: "publisher_permission"
  },

  publisher_file: {
    fr: ["📄 <b>Quel fichier choisir ?</b>", "Il y a deux fichiers différents, parce qu'un seul aurait été trop simple :\n\n• <code>redacted-bannerlab-publisher.user.js</code> : le moteur Publisher, choisi lors du premier lancement du favori.\n• <code>RBL_Current_Session.rblpub.json</code> : ta fresque / session à charger ensuite dans le panneau Publisher avec le bouton dossier 📂."],
    en: ["📄 <b>Which file should I choose?</b>", "There are two different files, because apparently one would have been too easy:\n\n• <code>redacted-bannerlab-publisher.user.js</code>: the Publisher engine, selected the first time the bookmark runs.\n• <code>RBL_Current_Session.rblpub.json</code>: your current banner/session, loaded afterwards from the Publisher panel using the folder button 📂."],
    rows: [
      [["✅ Compris", "faq:publisher"]],
    ],
    parent: "publisher"
  },

  update: {
    fr: ["📦 <b>Installation / mise à jour</b>", "Quelle situation correspond à ton problème ?"],
    en: ["📦 <b>Install / update</b>", "Which situation matches your problem?"],
    rows: [
      [["⬆️ La mise à jour est détectée mais ne s'installe pas", "faq:update_install"]],
      [["1.0.12 → version récente", "faq:update_v12"]],
      [["📲 Android refuse l'installation", "faq:update_android"]],
    ],
    parent: "root"
  },

  update_v12: {
    fr: ["🧓 <b>Depuis RBL 1.0.12</b>", "L'ancien updater peut échouer à ouvrir la confirmation d'installation sur certains Android récents. Fais une <b>installation manuelle unique</b> de l'APK récent par-dessus la 1.0.12. <b>Ne désinstalle pas RBL</b> : l'application, les projets et les réglages sont conservés si la signature est la même."],
    en: ["🧓 <b>From RBL 1.0.12</b>", "The old updater may fail to open Android's install confirmation on newer devices. Perform a <b>one-time manual install</b> of the recent APK over 1.0.12. <b>Do not uninstall RBL</b>: the app data stays in place when the signing key matches."],
    rows: [],
    parent: "update"
  },

  update_install: {
    fr: ["⬆️ <b>Mise à jour détectée mais bloquée</b>", "Laisse RBL télécharger et vérifier l'APK, puis touche <b>Installer</b>. Android doit afficher sa propre confirmation. Si rien n'apparaît sur une très ancienne version de RBL, utilise l'installation manuelle de l'APK récent sans désinstaller l'application."],
    en: ["⬆️ <b>Update detected but stuck</b>", "Let RBL download and verify the APK, then tap <b>Install</b>. Android should display its own confirmation. If nothing appears on a very old RBL build, manually install the recent APK without uninstalling the app."],
    rows: [],
    parent: "update"
  },

  update_android: {
    fr: ["📲 <b>Android refuse l'installation</b>", "Vérifie que RBL a l'autorisation <b>Installer des applications inconnues</b>. Si Android indique un conflit de signature, n'insiste pas : il faut conserver la même clé de signature RBL. Une APK officielle RBL doit pouvoir s'installer par-dessus une version officielle précédente."],
    en: ["📲 <b>Android refuses installation</b>", "Check that RBL is allowed to <b>Install unknown apps</b>. If Android reports a signing conflict, do not force it: RBL must keep the same signing key. An official RBL APK should install over a previous official build."],
    rows: [],
    parent: "update"
  },

  igor: {
    fr: ["🧪 <b>IGOR / IITC / parcours</b>", "Tu rencontres quoi ?"],
    en: ["🧪 <b>IGOR / IITC / routes</b>", "What is happening?"],
    rows: [
      [["🔄 Synchronisation vers RBL", "faq:igor_sync"]],
      [["🧠 IGOR a perdu le parcours", "faq:igor_route"]],
      [["🚪 « Rouvre IGOR depuis le Lab »", "faq:igor_token"]],
    ],
    parent: "root"
  },

  igor_sync: {
    fr: ["🔄 <b>Synchronisation IGOR → RBL</b>", "Ouvre toujours IGOR <b>depuis le Lab</b> pour que le projet, la session et le jeton de passerelle soient frais. Ensuite utilise l'envoi manuel vers RBL. L'autosync reste volontairement désactivé."],
    en: ["🔄 <b>IGOR → RBL sync</b>", "Always open IGOR <b>from the Lab</b> so the project, session and bridge token are fresh. Then use the manual send-to-RBL action. Autosync intentionally stays disabled."],
    rows: [],
    parent: "igor"
  },

  igor_route: {
    fr: ["🧠 <b>Parcours / progression</b>", "IGOR garde une mémoire locale du parcours. Si nécessaire, utilise <b>Recharger depuis BannerLab</b> pour reprendre le dernier état reçu du Lab. Évite de réinitialiser la progression tant que tu n'as pas vérifié cette sauvegarde."],
    en: ["🧠 <b>Route / progress</b>", "IGOR keeps a local route state. If needed use <b>Reload from BannerLab</b> to restore the last state received from the Lab. Avoid resetting progress until you have checked that snapshot."],
    rows: [],
    parent: "igor"
  },

  igor_token: {
    fr: ["🚪 <b>« Rouvre IGOR depuis le Lab »</b>", "Ce message signifie qu'IGOR n'a pas de jeton de passerelle valide. Ferme simplement ce parcours et relance IITC avec le bouton RBL qui ouvre IGOR depuis le projet actif. IGOR récupérera le jeton frais."],
    en: ["🚪 <b>“Reopen IGOR from the Lab”</b>", "This means IGOR does not currently have a valid bridge token. Reopen IITC/IGOR from the active RBL project so it receives a fresh token."],
    rows: [],
    parent: "igor"
  },

  backup: {
    fr: ["💾 <b>Sauvegarde / projets</b>", "RBL garde les projets localement. Pour une copie portable, utilise l'export du projet ou le backup complet. Avant une désinstallation ou un changement de téléphone, fais toujours un export manuel : Android adore transformer les migrations en jeu de hasard."],
    en: ["💾 <b>Backup / projects</b>", "RBL stores projects locally. Use project export or a full backup for a portable copy. Before uninstalling or changing phones, always make a manual export."],
    rows: [],
    parent: "root"
  },

  studio: {
    fr: ["🖼️ <b>Images / calques / Studio</b>", "Le <b>fond principal</b> sert de base à toute la fresque. Les autres images sont des <b>calques</b> que tu peux déplacer, redimensionner, masquer ou rattacher à une mission. Pour une série d'images déjà découpées, utilise l'import de série de missions."],
    en: ["🖼️ <b>Images / layers / Studio</b>", "The <b>main background</b> is the base of the whole banner. Other images are <b>layers</b> you can move, resize, hide or attach to a mission. For an already-sliced image series, use the mission-series import."],
    rows: [],
    parent: "root"
  },
};

const FAQ_KEYWORDS = [
  { node: "publisher", words: ["publisher", "publier", "publication", "mission authoring", "authoring", "bookmark", "favori", "chrome", "javascript"] },
  { node: "update", words: ["mise a jour", "mettre a jour", "update", "apk", "version", "installer", "installation"] },
  { node: "igor", words: ["igor", "iitc", "route", "parcours", "portail", "portal", "sync", "synchronisation"] },
  { node: "backup", words: ["backup", "sauvegarde", "restaurer", "restauration", "projet perdu", "projets perdus", "export"] },
  { node: "studio", words: ["image", "calque", "layer", "fond", "studio", "police", "font", "fresque"] },
];

const LANG_ALIASES = {
  "fr": "fr",
  "en": "en",
  "es": "es",
  "pt": "pt",
  "pt-br": "pt",
  "pt-pt": "pt",
  "de": "de",
  "it": "it",
  "nl": "nl",
  "pl": "pl",
  "cs": "cs",
  "ro": "ro",
  "tr": "tr",
  "ru": "ru",
  "uk": "uk",
  "ja": "ja",
  "ko": "ko",
  "zh": "zh-CN",
  "zh-cn": "zh-CN",
  "zh-sg": "zh-CN",
  "zh-hans": "zh-CN",
  "zh-tw": "zh-TW",
  "zh-mo": "zh-TW",
  "zh-hant": "zh-TW",
  "zh-hk": "yue",
  "yue": "yue",
  "yue-hant": "yue",
  "ar": "ar",
  "id": "id"
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response(
        "🦖 Redacted BannerLab Bot is alive. Multilingual mode enabled.",
        {
          status: 200,
          headers: { "Content-Type": "text/plain; charset=UTF-8" },
        }
      );
    }

    const expectedWebhookPath = `/webhook/${env.WEBHOOK_SECRET}`;

    if (
      request.method !== "POST" ||
      url.pathname !== expectedWebhookPath
    ) {
      return new Response("Not found", { status: 404 });
    }

    try {
      const update = await request.json();

      if (update.message) {
        await handleMessage(update.message, env);
      }

      if (update.callback_query) {
        await handleCallback(update.callback_query, env);
      }

      return new Response("OK", { status: 200 });
    } catch (error) {
      console.error("Webhook error:", error);
      return new Response("OK", { status: 200 });
    }
  },
};

async function handleMessage(message, env) {
  const chatId = message.chat.id;
  const userId = message.from?.id || chatId;
  const text = typeof message.text === "string" ? message.text.trim() : "";

  if (String(chatId) === String(env.SUPPORT_CHAT_ID)) {
    await handleSupportGroupMessage(message, env);
    return;
  }

  if (text === "/chatid" || text.startsWith("/chatid@")) {
    await sendMessage(
      chatId,
      `🆔 <b>Chat ID</b>\n\n<code>${chatId}</code>`,
      null,
      env
    );
    return;
  }

  if (text === "/lang" || text === "/language" || text.startsWith("/lang@") || text.startsWith("/language@")) {
    await showLanguageMenu(chatId, env, userId);
    return;
  }

  if (/^\/start(?:@\w+)?(?:\s|$)/.test(text)) {
    const payload = getStartPayload(text);

    if (payload) {
      const parsed = parseStartPayload(payload);

      if (parsed.lang) {
        await setUserLanguage(userId, parsed.lang, env);
      }

      if (parsed.action === "support") {
        await showSupport(chatId, env, message.from);
        return;
      }
    }

    await clearSupportPending(userId, env);
    await showMainMenu(chatId, env, message.from);
    return;
  }

  if (text === "/menu" || text.startsWith("/menu@")) {
    await clearSupportPending(userId, env);
    await showMainMenu(chatId, env, message.from);
    return;
  }

  if (text === "/faq" || text === "/aide" || text.startsWith("/faq@") || text.startsWith("/aide@")) {
    await clearSupportPending(userId, env);
    await showFaqNode(chatId, env, message.from, "root");
    return;
  }

  if (text === "/support" || text.startsWith("/support@")) {
    await showSupport(chatId, env, message.from);
    return;
  }

  if (text === "/canal" || text === "/channel" || text.startsWith("/canal@") || text.startsWith("/channel@")) {
    await clearSupportPending(userId, env);
    await showChannel(chatId, env, message.from);
    return;
  }

  if (
    text === "/communaute" ||
    text === "/community" ||
    text.startsWith("/communaute@") ||
    text.startsWith("/community@")
  ) {
    await clearSupportPending(userId, env);
    await showCommunity(chatId, env, message.from);
    return;
  }

  if (text === "/infos" || text === "/about" || text.startsWith("/infos@") || text.startsWith("/about@")) {
    await clearSupportPending(userId, env);
    await showInfos(chatId, env, message.from);
    return;
  }

  if (
    message.chat.type === "group" ||
    message.chat.type === "supergroup"
  ) {
    return;
  }

  if (message.chat.type === "private") {
    const pending = await isSupportPending(userId, env);

    if (pending) {
      await clearSupportPending(userId, env);
      await receiveSupportRequest(message, env);
      return;
    }
  }

  const lang = await getUserLanguage(userId, message.from, env);

  if (message.chat.type === "private" && text) {
    const faqNode = detectFaqNode(text);
    if (faqNode) {
      await showFaqNode(chatId, env, message.from, faqNode, { detected: true });
      return;
    }

    await sendMessage(
      chatId,
      faqText(lang, "faq_no_match"),
      faqKeyboardForNode("root", lang),
      env
    );
    return;
  }

  await sendMessage(
    chatId,
    tr(lang, "unknown"),
    mainKeyboard(lang, env),
    env
  );
}

async function handleCallback(query, env) {
  const chatId = query.message?.chat?.id;
  const userId = query.from?.id;

  if (!chatId || !userId) return;

  await telegram(
    "answerCallbackQuery",
    { callback_query_id: query.id },
    env
  );

  if (query.data?.startsWith("lang:")) {
    const requested = query.data.slice(5);
    const lang = normalizeLanguage(requested);

    await setUserLanguage(userId, lang, env);

    await sendMessage(
      chatId,
      format(tr(lang, "language_saved"), {
        language: tr(lang, "label"),
      }),
      null,
      env
    );

    await showMainMenu(chatId, env, query.from);
    return;
  }

  if (query.data?.startsWith("faq:")) {
    const node = query.data.slice(4) || "root";
    await clearSupportPending(userId, env);
    await showFaqNode(chatId, env, query.from, node);
    return;
  }

  switch (query.data) {
    case "menu":
      await clearSupportPending(userId, env);
      await showMainMenu(chatId, env, query.from);
      break;

    case "faq":
      await clearSupportPending(userId, env);
      await showFaqNode(chatId, env, query.from, "root");
      break;

    case "support":
      await showSupport(chatId, env, query.from);
      break;

    case "support_cancel": {
      await clearSupportPending(userId, env);
      const lang = await getUserLanguage(userId, query.from, env);
      await sendMessage(
        chatId,
        tr(lang, "cancelled"),
        mainKeyboard(lang, env),
        env
      );
      break;
    }

    case "channel":
      await clearSupportPending(userId, env);
      await showChannel(chatId, env, query.from);
      break;

    case "community":
      await clearSupportPending(userId, env);
      await showCommunity(chatId, env, query.from);
      break;

    case "infos":
      await clearSupportPending(userId, env);
      await showInfos(chatId, env, query.from);
      break;

    case "language":
      await showLanguageMenu(chatId, env, userId);
      break;

    default:
      break;
  }
}

async function showMainMenu(chatId, env, user = null) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);
  const name = user?.first_name ? escapeHtml(user.first_name) : "Agent";

  await sendMessage(
    chatId,
    `${tr(lang, "welcome_title")}

${format(tr(lang, "hello"), { name })}

${tr(lang, "welcome")}`,
    mainKeyboard(lang, env),
    env
  );
}

function mainKeyboard(lang, env) {
  const rows = [
    [{ text: faqText(lang, "faq_btn"), callback_data: "faq" }],
    [{ text: tr(lang, "support_btn"), callback_data: "support" }],
  ];

  if (isValidUrl(env.CHANNEL_URL)) {
    rows.push([
      { text: tr(lang, "channel_btn"), url: env.CHANNEL_URL },
    ]);
  }

  if (isValidUrl(env.GROUP_URL)) {
    rows.push([
      { text: tr(lang, "community_btn"), url: env.GROUP_URL },
    ]);
  }

  rows.push([
    { text: tr(lang, "about_btn"), callback_data: "infos" },
    { text: tr(lang, "language_btn"), callback_data: "language" },
  ]);

  return { inline_keyboard: rows };
}


function faqLanguage(lang) {
  return FAQ_I18N[lang] ? lang : "en";
}

function faqText(lang, key) {
  const l = faqLanguage(lang);
  return FAQ_I18N[l]?.[key] ?? FAQ_I18N.en[key] ?? key;
}

function faqNodeText(nodeId, lang) {
  const node = FAQ_NODES[nodeId] || FAQ_NODES.root;
  const l = faqLanguage(lang);
  const tuple = node[l] || node.en || FAQ_NODES.root.en;
  return `${tuple[0]}\n\n${tuple[1]}`;
}

function faqKeyboardForNode(nodeId, lang) {
  const node = FAQ_NODES[nodeId] || FAQ_NODES.root;
  const rows = (node.rows || []).map(row =>
    row.map(([text, data]) => ({ text, callback_data: data }))
  );

  const nav = [];
  if (node.parent) nav.push({ text: faqText(lang, "faq_back"), callback_data: `faq:${node.parent}` });
  if (nodeId !== "root") nav.push({ text: faqText(lang, "faq_home"), callback_data: "faq:root" });
  if (nav.length) rows.push(nav);

  rows.push([{ text: faqText(lang, "faq_support"), callback_data: "support" }]);
  return { inline_keyboard: rows };
}

async function showFaqNode(chatId, env, user = null, nodeId = "root", options = {}) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);
  const safeNode = FAQ_NODES[nodeId] ? nodeId : "root";
  const prefix = options.detected ? `${faqText(lang, "faq_detected")}\n\n` : "";
  await sendMessage(
    chatId,
    `${prefix}${faqNodeText(safeNode, lang)}`,
    faqKeyboardForNode(safeNode, lang),
    env
  );
}

function normalizeFaqInput(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s:/._-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function detectFaqNode(text) {
  const q = normalizeFaqInput(text);
  if (!q) return null;

  let best = null;
  let bestScore = 0;
  for (const group of FAQ_KEYWORDS) {
    let score = 0;
    for (const rawWord of group.words) {
      const word = normalizeFaqInput(rawWord);
      if (word && q.includes(word)) score += word.includes(" ") ? 3 : 1;
    }
    if (score > bestScore) {
      bestScore = score;
      best = group.node;
    }
  }
  return bestScore > 0 ? best : null;
}

async function showLanguageMenu(chatId, env, userId) {
  const current = await getUserLanguage(userId, null, env);
  const rows = [];
  const codes = Object.keys(I18N);

  for (let i = 0; i < codes.length; i += 2) {
    const row = [];

    for (const code of codes.slice(i, i + 2)) {
      row.push({
        text: `${code === current ? "✅ " : ""}${I18N[code].label}`,
        callback_data: `lang:${code}`,
      });
    }

    rows.push(row);
  }

  rows.push([
    { text: tr(current, "back_btn"), callback_data: "menu" },
  ]);

  await sendMessage(
    chatId,
    tr(current, "choose_language"),
    { inline_keyboard: rows },
    env
  );
}

async function showSupport(chatId, env, user = null) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);

  if (!env.RBL_KV) {
    await sendMessage(
      chatId,
      "🦖 RBL_KV is missing. The support memory is not connected.",
      mainKeyboard(lang, env),
      env
    );
    return;
  }

  await setSupportPending(userId, env);

  await sendMessage(
    chatId,
    `${tr(lang, "support_title")}

${tr(lang, "support_body")}`,
    {
      inline_keyboard: [
        [{ text: tr(lang, "cancel_btn"), callback_data: "support_cancel" }],
      ],
    },
    env
  );
}

async function receiveSupportRequest(message, env) {
  if (!env.SUPPORT_CHAT_ID) {
    const lang = await getUserLanguage(message.from?.id, message.from, env);
    await sendMessage(
      message.chat.id,
      "🦖 SUPPORT_CHAT_ID is missing.",
      mainKeyboard(lang, env),
      env
    );
    return;
  }

  const user = message.from || {};
  const userId = user.id;
  const lang = await getUserLanguage(userId, user, env);
  const fullName =
    `${escapeHtml(user.first_name || "")} ${escapeHtml(user.last_name || "")}`
      .trim() || "Unknown Agent";
  const username = user.username ? `@${escapeHtml(user.username)}` : "—";
  const content = getMessageContent(message);
  const marker = `#RBL_USER_${userId}`;
  const langLabel = tr(lang, "label");

  const cardText =
`🐛 <b>NOUVELLE DEMANDE SUPPORT</b>

🌐 <b>Langue :</b> ${langLabel}
👤 <b>Agent :</b> ${fullName}
🔗 <b>Username :</b> ${username}
🆔 <b>Telegram :</b> <code>${userId}</code>

💬 <b>Message :</b>
${content}

──────────────

↩️ <b>Réponds directement à CE message pour répondre à l’utilisateur.</b>

<code>${marker}</code>`;

  const cardResult = await sendMessage(
    env.SUPPORT_CHAT_ID,
    cardText,
    null,
    env
  );

  if (hasMedia(message)) {
    const payload = {
      chat_id: env.SUPPORT_CHAT_ID,
      from_chat_id: message.chat.id,
      message_id: message.message_id,
    };

    const cardMessageId = cardResult?.result?.message_id;

    if (cardMessageId) {
      payload.reply_parameters = { message_id: cardMessageId };
    }

    await telegram("copyMessage", payload, env);
  }

  await sendMessage(
    message.chat.id,
    `${tr(lang, "sent_title")}

${tr(lang, "sent_body")}`,
    {
      inline_keyboard: [
        [{ text: tr(lang, "another_btn"), callback_data: "support" }],
        [{ text: tr(lang, "back_btn"), callback_data: "menu" }],
      ],
    },
    env
  );
}

async function handleSupportGroupMessage(message, env) {
  const text = typeof message.text === "string" ? message.text.trim() : "";

  if (text === "/chatid" || text.startsWith("/chatid@")) {
    await sendMessage(
      message.chat.id,
      `🆔 <b>Chat ID</b>\n\n<code>${message.chat.id}</code>`,
      null,
      env
    );
    return;
  }

  const replied = message.reply_to_message;
  if (!replied) return;

  const repliedContent = `${replied.text || ""}\n${replied.caption || ""}`;
  const match = repliedContent.match(/#RBL_USER_(\d+)/);
  if (!match) return;

  const destinationUserId = match[1];
  const lang = await getUserLanguage(destinationUserId, null, env);

  if (message.text && !message.text.startsWith("/")) {
    await sendMessage(
      destinationUserId,
      `${tr(lang, "lab_reply")}

${escapeHtml(message.text)}`,
      {
        inline_keyboard: [
          [{ text: tr(lang, "support_btn"), callback_data: "support" }],
          [{ text: tr(lang, "back_btn"), callback_data: "menu" }],
        ],
      },
      env
    );

    await confirmSupportReply(message, destinationUserId, env);
    return;
  }

  if (hasMedia(message)) {
    await sendMessage(
      destinationUserId,
      `${tr(lang, "lab_reply")}

${tr(lang, "lab_media")}`,
      null,
      env
    );

    await telegram(
      "copyMessage",
      {
        chat_id: destinationUserId,
        from_chat_id: message.chat.id,
        message_id: message.message_id,
      },
      env
    );

    await sendMessage(
      destinationUserId,
      tr(lang, "reply_again"),
      {
        inline_keyboard: [
          [{ text: tr(lang, "support_btn"), callback_data: "support" }],
          [{ text: tr(lang, "back_btn"), callback_data: "menu" }],
        ],
      },
      env
    );

    await confirmSupportReply(message, destinationUserId, env);
  }
}

async function confirmSupportReply(message, userId, env) {
  await sendMessage(
    env.SUPPORT_CHAT_ID,
    `✅ Réponse envoyée à <code>${userId}</code>`,
    null,
    env,
    message.message_id
  );
}

async function showChannel(chatId, env, user = null) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);
  const rows = [];

  if (isValidUrl(env.CHANNEL_URL)) {
    rows.push([
      { text: tr(lang, "join_channel"), url: env.CHANNEL_URL },
    ]);
  }

  rows.push([
    { text: tr(lang, "back_btn"), callback_data: "menu" },
  ]);

  await sendMessage(
    chatId,
    `${tr(lang, "channel_title")}

${tr(lang, "channel_body")}`,
    { inline_keyboard: rows },
    env
  );
}

async function showCommunity(chatId, env, user = null) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);
  const rows = [];

  if (isValidUrl(env.GROUP_URL)) {
    rows.push([
      { text: tr(lang, "join_group"), url: env.GROUP_URL },
    ]);
  }

  rows.push([
    { text: tr(lang, "back_btn"), callback_data: "menu" },
  ]);

  await sendMessage(
    chatId,
    `${tr(lang, "community_title")}

${tr(lang, "community_body")}`,
    { inline_keyboard: rows },
    env
  );
}

async function showInfos(chatId, env, user = null) {
  const userId = user?.id || chatId;
  const lang = await getUserLanguage(userId, user, env);
  const rows = [];
  const firstRow = [];

  if (isValidUrl(env.CHANNEL_URL)) {
    firstRow.push({
      text: tr(lang, "channel_btn"),
      url: env.CHANNEL_URL,
    });
  }

  if (isValidUrl(env.GROUP_URL)) {
    firstRow.push({
      text: tr(lang, "community_btn"),
      url: env.GROUP_URL,
    });
  }

  if (firstRow.length) rows.push(firstRow);

  rows.push([
    { text: tr(lang, "language_btn"), callback_data: "language" },
  ]);
  rows.push([
    { text: tr(lang, "back_btn"), callback_data: "menu" },
  ]);

  await sendMessage(
    chatId,
    `${tr(lang, "about_title")}

${tr(lang, "about_body")}`,
    { inline_keyboard: rows },
    env
  );
}

function getStartPayload(text) {
  const match = text.match(/^\/start(?:@\w+)?(?:\s+(.+))?$/);
  return match?.[1]?.trim() || "";
}

function parseStartPayload(payload) {
  if (!payload) return { action: null, lang: null };

  if (payload.startsWith("support_")) {
    return {
      action: "support",
      lang: resolveLanguage(payload.slice(8)),
    };
  }

  if (payload === "support") {
    return { action: "support", lang: null };
  }

  const maybeLang = resolveLanguage(payload);
  if (maybeLang) {
    return { action: null, lang: maybeLang };
  }

  return { action: null, lang: null };
}

function resolveLanguage(value) {
  if (!value) return null;
  const raw = String(value).trim();
  if (I18N[raw]) return raw;

  const lower = raw.toLowerCase().replaceAll("_", "-");

  if (LANG_ALIASES[lower]) return LANG_ALIASES[lower];

  const base = lower.split("-")[0];
  if (LANG_ALIASES[base]) return LANG_ALIASES[base];

  return null;
}

function normalizeLanguage(value) {
  return resolveLanguage(value) || "en";
}

function detectTelegramLanguage(user) {
  return normalizeLanguage(user?.language_code || "en");
}

function languageKey(userId) {
  return `lang_${userId}`;
}

async function getUserLanguage(userId, user, env) {
  if (!userId) return detectTelegramLanguage(user);

  if (env.RBL_KV) {
    const saved = await env.RBL_KV.get(languageKey(userId));
    if (saved && I18N[saved]) return saved;
  }

  const detected = detectTelegramLanguage(user);

  if (env.RBL_KV) {
    await env.RBL_KV.put(languageKey(userId), detected);
  }

  return detected;
}

async function setUserLanguage(userId, lang, env) {
  const normalized = normalizeLanguage(lang);

  if (env.RBL_KV && userId) {
    await env.RBL_KV.put(languageKey(userId), normalized);
  }

  return normalized;
}

function tr(lang, key) {
  return I18N[lang]?.[key] ?? I18N.en[key] ?? key;
}

function format(text, vars = {}) {
  return String(text).replace(/\{(\w+)\}/g, (_, key) =>
    Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : `{${key}}`
  );
}

function supportPendingKey(userId) {
  return `support_pending_${userId}`;
}

async function setSupportPending(userId, env) {
  if (!env.RBL_KV) return;

  await env.RBL_KV.put(
    supportPendingKey(userId),
    JSON.stringify({ createdAt: Date.now() }),
    { expirationTtl: SUPPORT_PENDING_TTL }
  );
}

async function isSupportPending(userId, env) {
  if (!env.RBL_KV) return false;
  return Boolean(await env.RBL_KV.get(supportPendingKey(userId)));
}

async function clearSupportPending(userId, env) {
  if (!env.RBL_KV) return;
  await env.RBL_KV.delete(supportPendingKey(userId));
}

function getMessageContent(message) {
  if (message.text) {
    return escapeHtml(truncate(message.text, 2500));
  }

  if (message.caption) {
    return escapeHtml(truncate(message.caption, 2200));
  }

  if (message.photo) return "📷 Photo / screenshot";
  if (message.video) return "🎥 Video";
  if (message.document) {
    const name = message.document.file_name
      ? escapeHtml(message.document.file_name)
      : "Document";
    return `📎 ${name}`;
  }
  if (message.animation) return "🎞 Animation";
  if (message.audio) return "🎵 Audio";
  if (message.voice) return "🎤 Voice message";
  if (message.sticker) return "🧩 Sticker";

  return "📦 Attachment";
}

function hasMedia(message) {
  return Boolean(
    message.photo ||
    message.video ||
    message.document ||
    message.animation ||
    message.audio ||
    message.voice ||
    message.sticker
  );
}

async function sendMessage(
  chatId,
  text,
  replyMarkup,
  env,
  replyToMessageId = null
) {
  const payload = {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    link_preview_options: { is_disabled: true },
  };

  if (replyMarkup) payload.reply_markup = replyMarkup;

  if (replyToMessageId) {
    payload.reply_parameters = { message_id: replyToMessageId };
  }

  return telegram("sendMessage", payload, env);
}

async function telegram(method, payload, env) {
  if (!env.TELEGRAM_BOT_TOKEN) {
    console.error("TELEGRAM_BOT_TOKEN missing");
    return null;
  }

  const response = await fetch(
    `${TELEGRAM_API}/bot${env.TELEGRAM_BOT_TOKEN}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }
  );

  const responseText = await response.text();
  let data;

  try {
    data = JSON.parse(responseText);
  } catch {
    data = { ok: false, description: responseText };
  }

  if (!response.ok || !data.ok) {
    console.error(
      `Telegram ${method} error:`,
      response.status,
      responseText
    );
  }

  return data;
}

function isValidUrl(value) {
  if (typeof value !== "string" || !value.trim()) return false;

  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function truncate(value, maxLength) {
  const text = String(value || "");
  return text.length <= maxLength
    ? text
    : `${text.slice(0, maxLength)}\n[…]`;
}
