/**
 * RITA — Redacted Information & Telegram Assistant
 * Cloudflare Worker (module syntax)
 *
 * Routes :
 *   GET  /health
 *   POST /telegram   Telegram webhook
 *   POST /github     GitHub Release webhook
 *   POST /publish    Publication externe protégée
 *
 * Secrets Cloudflare :
 *   TELEGRAM_BOT_TOKEN
 *   TELEGRAM_WEBHOOK_SECRET
 *   GITHUB_WEBHOOK_SECRET
 *   ADMIN_TELEGRAM_IDS
 *   RITA_PUBLISH_KEY
 *
 * Variables Cloudflare :
 *   TELEGRAM_INFO_CHAT_ID
 *   TELEGRAM_INFO_URL
 *   TELEGRAM_SUPPORT_URL
 *   GITHUB_REPO
 *   FAQ_CHAT_IDS
 *
 * Binding KV optionnel :
 *   RITA_KV
 *
 * RITA_KV permet d’éviter une double publication
 * Telegram si GitHub rejoue un webhook.
 */

const RITA_VERSION = "1.1.1";
const DEFAULT_REPO = "zw4nn/Redacted-Banner-Lab";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    try {
      if (
        request.method === "GET" &&
        (path === "/" || path === "/health")
      ) {
        return json({
          ok: true,
          service: "RITA",
          name: "Redacted Information & Telegram Assistant",
          version: RITA_VERSION,
          telegram: Boolean(env.TELEGRAM_BOT_TOKEN),
          info_channel: Boolean(env.TELEGRAM_INFO_CHAT_ID),
          github_repo: getGithubRepo(env),
          github_webhook: Boolean(env.GITHUB_WEBHOOK_SECRET),
          faq: true
        });
      }

      if (
        request.method === "POST" &&
        path === "/telegram"
      ) {
        return handleTelegramWebhook(
          request,
          env,
          ctx
        );
      }

      if (
        request.method === "POST" &&
        path === "/github"
      ) {
        return handleGithubWebhook(
          request,
          env
        );
      }

      if (
        request.method === "POST" &&
        path === "/publish"
      ) {
        return handleDirectPublish(
          request,
          env
        );
      }

      return json(
        {
          ok: false,
          error: "Not found"
        },
        404
      );
    } catch (error) {
      console.error(
        "RITA fatal error",
        error
      );

      return json(
        {
          ok: false,
          error: "Internal error"
        },
        500
      );
    }
  }
};

/* ==========================================================
 * TELEGRAM WEBHOOK
 * ========================================================== */

async function handleTelegramWebhook(
  request,
  env,
  ctx
) {
  if (!env.TELEGRAM_BOT_TOKEN) {
    return json(
      {
        ok: false,
        error: "TELEGRAM_BOT_TOKEN missing"
      },
      500
    );
  }

  if (env.TELEGRAM_WEBHOOK_SECRET) {
    const received =
      request.headers.get(
        "X-Telegram-Bot-Api-Secret-Token"
      ) || "";

    if (
      !constantTimeStringEqual(
        received,
        env.TELEGRAM_WEBHOOK_SECRET
      )
    ) {
      return json(
        {
          ok: false,
          error:
            "Invalid Telegram webhook secret"
        },
        403
      );
    }
  }

  const update =
    await request.json();

  ctx.waitUntil(
    processTelegramUpdate(
      update,
      env
    )
  );

  return json({
    ok: true
  });
}

async function processTelegramUpdate(
  update,
  env
) {
  try {
    if (update.callback_query) {
      await handleCallbackQuery(
        update.callback_query,
        env
      );
      return;
    }

    const message =
      update.message;

    if (
      !message?.chat?.id ||
      !message?.from?.id
    ) {
      return;
    }

    const rawText =
      String(
        message.text ||
        message.caption ||
        ""
      ).trim();

    if (rawText.startsWith("/")) {
      await handleCommand(
        message,
        rawText,
        env
      );
      return;
    }

    if (
      !rawText ||
      !shouldHandleFreeText(
        message,
        env
      )
    ) {
      return;
    }

    const detection =
      detectFaqIntent(rawText);

    if (!detection) {
      await sendMessage(
        env,
        message.chat.id,
        "🧠 <b>RITA n’a pas identifié le sujet avec assez de certitude.</b>\n\n" +
          "Choisis une rubrique et on évite le diagnostic au hasard.",
        {
          reply_markup:
            faqRootKeyboard(env)
        }
      );

      return;
    }

    if (
      detection.ambiguous?.length
    ) {
      const rows =
        detection.ambiguous.map(
          intent => [
            {
              text:
                FAQ_INTENTS[
                  intent
                ].label,
              callback_data:
                `faq:${intent}`
            }
          ]
        );

      rows.push(
        ...commonFaqRows(
          env,
          "faq:root"
        )
      );

      await sendMessage(
        env,
        message.chat.id,
        "🧠 <b>J’hésite entre plusieurs sujets.</b>\n\n" +
          "Lequel correspond à ton problème ?",
        {
          reply_markup: {
            inline_keyboard:
              rows
          }
        }
      );

      return;
    }

    await sendFaqNode(
      env,
      message.chat.id,
      `faq:${detection.intent}`
    );
  } catch (error) {
    console.error(
      "Telegram update error",
      error
    );
  }
}

function shouldHandleFreeText(
  message,
  env
) {
  if (
    message.chat.type ===
    "private"
  ) {
    return true;
  }

  const allowed =
    csv(env.FAQ_CHAT_IDS);

  return allowed.includes(
    String(message.chat.id)
  );
}

/* ==========================================================
 * COMMANDES
 * ========================================================== */

async function handleCommand(
  message,
  rawText,
  env
) {
  const match =
    rawText.match(
      /^\/([a-zA-Z0-9_]+)(?:@\S+)?(?:\s+([\s\S]*))?$/
    );

  if (!match) {
    return;
  }

  const command =
    match[1].toLowerCase();

  const args =
    String(
      match[2] || ""
    ).trim();

  const chatId =
    message.chat.id;

  const userId =
    message.from.id;

  switch (command) {
    case "start":
    case "menu":
      await commandStart(
        env,
        chatId,
        userId
      );
      return;

    case "faq":
    case "aide":
    case "help":
      await sendFaqRoot(
        env,
        chatId
      );
      return;

    case "latest":
    case "version":
      await commandLatest(
        env,
        chatId
      );
      return;

    case "info":
    case "canal":
      await commandInfo(
        env,
        chatId
      );
      return;

    case "support":
      await commandSupport(
        env,
        chatId
      );
      return;

    case "github":
      await commandGithub(
        env,
        chatId
      );
      return;

    case "id":
      await sendMessage(
        env,
        chatId,
        `👤 Ton ID : <code>${escapeHtml(
          userId
        )}</code>\n` +
          `💬 Chat ID : <code>${escapeHtml(
            chatId
          )}</code>`
      );
      return;

    case "status":
      await commandStatus(
        env,
        chatId,
        userId
      );
      return;

    case "pub":
    case "publier":
      await commandPublish(
        env,
        chatId,
        userId,
        message,
        args
      );
      return;

    case "release":
      await commandPublishLatestRelease(
        env,
        chatId,
        userId
      );
      return;

    default:
      await sendMessage(
        env,
        chatId,
        "🧪 <b>Commande inconnue.</b>\n\n" +
          "Utilise /faq pour l’aide rapide ou /menu pour revenir au menu.",
        {
          reply_markup:
            mainMenuKeyboard(
              env,
              userId
            )
        }
      );
  }
}

async function commandStart(
  env,
  chatId,
  userId
) {
  await sendMessage(
    env,
    chatId,
    "🧪 <b>RITA</b>\n" +
      "<i>Redacted Information &amp; Telegram Assistant</i>\n\n" +
      "Je peux diagnostiquer les problèmes courants de Redacted BannerLab, " +
      "te donner la dernière version et t’orienter vers le support si le Lab " +
      "décide de faire de la chimie tout seul.",
    {
      reply_markup:
        mainMenuKeyboard(
          env,
          userId
        )
    }
  );
}

function mainMenuKeyboard(
  env,
  userId
) {
  const rows = [
    [
      {
        text:
          "🧠 Aide rapide / FAQ",
        callback_data:
          "faq:root"
      }
    ],
    [
      {
        text:
          "📦 Dernière version",
        callback_data:
          "act:latest"
      }
    ]
  ];

  if (
    env.TELEGRAM_INFO_URL
  ) {
    rows.push([
      {
        text:
          "📢 Canal infos",
        url:
          env.TELEGRAM_INFO_URL
      }
    ]);
  }

  if (
    env.TELEGRAM_SUPPORT_URL
  ) {
    rows.push([
      {
        text:
          "🐛 Support",
        url:
          env.TELEGRAM_SUPPORT_URL
      }
    ]);
  }

  rows.push([
    {
      text:
        "🧪 GitHub",
      url:
        githubRepoUrl(env)
    }
  ]);

  if (
    isAdmin(
      env,
      userId
    )
  ) {
    rows.push([
      {
        text:
          "🔐 RITA admin",
        callback_data:
          "admin:help"
      }
    ]);
  }

  return {
    inline_keyboard:
      rows
  };
}

async function commandInfo(
  env,
  chatId
) {
  if (
    !env.TELEGRAM_INFO_URL
  ) {
    await sendMessage(
      env,
      chatId,
      "📢 Le lien du canal Info n’est pas configuré dans RITA."
    );

    return;
  }

  await sendMessage(
    env,
    chatId,
    "📢 <b>Canal d’informations Redacted BannerLab</b>",
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text:
                "Ouvrir le canal",
              url:
                env.TELEGRAM_INFO_URL
            }
          ]
        ]
      }
    }
  );
}

async function commandSupport(
  env,
  chatId
) {
  if (
    !env.TELEGRAM_SUPPORT_URL
  ) {
    await sendMessage(
      env,
      chatId,
      "🐛 Le lien du support n’est pas configuré dans RITA."
    );

    return;
  }

  await sendMessage(
    env,
    chatId,
    "🐛 <b>Passer au support</b>\n\n" +
      "Explique ce que tu faisais, ce que tu attendais et ce qui s’est passé. " +
      "Une capture aide énormément, contrairement à « ça marche pas », " +
      "chef-d’œuvre intemporel du diagnostic.",
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text:
                "Ouvrir le support",
              url:
                env.TELEGRAM_SUPPORT_URL
            }
          ]
        ]
      }
    }
  );
}

async function commandGithub(
  env,
  chatId
) {
  await sendMessage(
    env,
    chatId,
    "🧪 <b>Code source Redacted BannerLab</b>",
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text:
                "Voir le dépôt GitHub",
              url:
                githubRepoUrl(env)
            }
          ]
        ]
      }
    }
  );
}

async function commandLatest(
  env,
  chatId
) {
  const release =
    await fetchLatestGithubRelease(
      env
    );

  if (!release) {
    await sendMessage(
      env,
      chatId,
      "❌ Impossible de récupérer la dernière GitHub Release pour le moment."
    );

    return;
  }

  const payload =
    buildReleaseTelegramPayload(
      release,
      false,
      env
    );

  await sendMessage(
    env,
    chatId,
    payload.text,
    payload.options
  );
}

/* ==========================================================
 * FAQ INTELLIGENTE
 * ========================================================== */

const FAQ_INTENTS = {
  milo: {
    label:
      "🚀 MILO / Chrome",

    terms: [
      ["milo", 12],
      [
        "mission authoring tool",
        10
      ],
      ["mission import", 7],
      ["mission launch", 7],
      [
        "milo currentbanner",
        10
      ],
      ["milo launch", 10],
      ["milo user js", 10],
      ["favori", 3],
      ["bookmarklet", 5],
      ["chrome", 3],
      [
        "autorisation fichier",
        5
      ]
    ]
  },

  igor: {
    label:
      "🧪 IGOR / IITC",

    terms: [
      ["igor", 12],
      ["iitc", 10],
      ["synchro", 6],
      [
        "synchronisation",
        6
      ],
      ["sync", 6],
      ["parcours", 4],
      [
        "bridge token",
        8
      ],
      ["token", 3],
      ["mini igor", 8],
      ["portail", 2]
    ]
  },

  update: {
    label:
      "📲 Installation / mise à jour",

    terms: [
      ["mise a jour", 9],
      ["maj", 7],
      ["apk", 8],
      ["installer", 5],
      ["installation", 5],
      [
        "application non installee",
        12
      ],
      [
        "ne s installe pas",
        9
      ],
      ["signature", 7],
      ["version", 3]
    ]
  },

  projects: {
    label:
      "💾 Projets / sauvegardes",

    terms: [
      ["projet", 7],
      ["projets", 7],
      ["sauvegarde", 9],
      ["backup", 8],
      ["restaurer", 7],
      ["restauration", 7],
      [
        "perdu mon projet",
        11
      ],
      ["session", 3]
    ]
  },

  visuals: {
    label:
      "🖼️ Images / calques / Studio",

    terms: [
      ["calque", 10],
      ["calques", 10],
      ["studio", 11],
      ["opacite", 7],
      ["image", 5],
      ["images", 5],
      ["cercle", 4],
      ["decoupe", 4],
      ["alignement", 4]
    ]
  },

  search: {
    label:
      "🔎 Rechercher une fresque",

    terms: [
      ["bannergress", 12],
      [
        "rechercher une fresque",
        12
      ],
      [
        "recherche fresque",
        10
      ],
      [
        "trouver une fresque",
        10
      ],
      ["fresque", 5],
      ["banniere", 4],
      ["banner", 3]
    ]
  }
};

function detectFaqIntent(
  text
) {
  const normalized =
    normalizeText(text);

  const scored =
    Object.entries(
      FAQ_INTENTS
    )
      .map(
        ([intent, cfg]) => ({
          intent,

          score:
            cfg.terms.reduce(
              (
                sum,
                [term, weight]
              ) => {
                return (
                  sum +
                  (
                    containsTerm(
                      normalized,
                      normalizeText(
                        term
                      )
                    )
                      ? weight
                      : 0
                  )
                );
              },
              0
            )
        })
      )
      .filter(
        item =>
          item.score > 0
      )
      .sort(
        (a, b) =>
          b.score - a.score
      );

  if (
    !scored.length ||
    scored[0].score < 5
  ) {
    return null;
  }

  const top =
    scored[0];

  const close =
    scored.filter(
      item =>
        item.score >= 5 &&
        top.score -
          item.score <=
          2
    );

  if (
    close.length > 1
  ) {
    return {
      ambiguous:
        close
          .slice(0, 3)
          .map(
            item =>
              item.intent
          )
    };
  }

  return {
    intent:
      top.intent,

    score:
      top.score
  };
}

function normalizeText(
  value
) {
  return String(
    value || ""
  )
    .normalize("NFD")
    .replace(
      /[\u0300-\u036f]/g,
      ""
    )
    .toLowerCase()
    .replace(
      /[^a-z0-9]+/g,
      " "
    )
    .trim();
}

function containsTerm(
  text,
  term
) {
  if (!term) {
    return false;
  }

  return (
    ` ${text} `.includes(
      ` ${term} `
    ) ||
    text.includes(term)
  );
}

async function sendFaqRoot(
  env,
  chatId
) {
  await sendMessage(
    env,
    chatId,
    "🧠 <b>Aide rapide / FAQ</b>\n\n" +
      "Choisis le sujet. Tu peux aussi m’écrire directement ton problème : " +
      "je tente de reconnaître la rubrique automatiquement.",
    {
      reply_markup:
        faqRootKeyboard(
          env
        )
    }
  );
}

function faqRootKeyboard(
  env
) {
  const rows = [
    [
      {
        text:
          "🚀 MILO / Chrome",
        callback_data:
          "faq:milo"
      }
    ],

    [
      {
        text:
          "🧪 IGOR / IITC",
        callback_data:
          "faq:igor"
      }
    ],

    [
      {
        text:
          "📲 Installation / mise à jour",
        callback_data:
          "faq:update"
      }
    ],

    [
      {
        text:
          "💾 Projets / sauvegardes",
        callback_data:
          "faq:projects"
      }
    ],

    [
      {
        text:
          "🖼️ Images / calques / Studio",
        callback_data:
          "faq:visuals"
      }
    ],

    [
      {
        text:
          "🔎 Rechercher une fresque",
        callback_data:
          "faq:search"
      }
    ]
  ];

  if (
    env.TELEGRAM_SUPPORT_URL
  ) {
    rows.push([
      {
        text:
          "🐛 Passer au support",
        url:
          env.TELEGRAM_SUPPORT_URL
      }
    ]);
  }

  return {
    inline_keyboard:
      rows
  };
}

function commonFaqRows(
  env,
  back = "faq:root"
) {
  const rows = [
    [
      {
        text:
          "↩️ Retour",
        callback_data:
          back
      }
    ]
  ];

  if (
    env.TELEGRAM_SUPPORT_URL
  ) {
    rows.push([
      {
        text:
          "🐛 Passer au support",
        url:
          env.TELEGRAM_SUPPORT_URL
      }
    ]);
  }

  return rows;
}

function node(
  text,
  rows,
  env,
  back = "faq:root"
) {
  return {
    text,

    keyboard: {
      inline_keyboard: [
        ...rows,
        ...commonFaqRows(
          env,
          back
        )
      ]
    }
  };
}

function getFaqNode(
  key,
  env
) {
  switch (key) {

    /* ======================
     * RACINE
     * ====================== */

    case "faq:root":
      return {
        text:
          "🧠 <b>Aide rapide / FAQ</b>\n\n" +
          "Choisis le sujet. Tu peux aussi écrire ton problème directement à RITA.",

        keyboard:
          faqRootKeyboard(
            env
          )
      };

    /* ======================
     * MILO
     * ====================== */

    case "faq:milo":
      return node(
        "🚀 <b>MILO · Mission Import &amp; Launch Operator</b>\n\n" +
          "Que se passe-t-il ?",

        [
          [
            {
              text:
                "MILO ne se lance pas",
              callback_data:
                "milo:launch"
            }
          ],

          [
            {
              text:
                "Favori MILO / Chrome",
              callback_data:
                "milo:bookmark"
            }
          ],

          [
            {
              text:
                "Autorisation du fichier",
              callback_data:
                "milo:fileauth"
            }
          ],

          [
            {
              text:
                "Quel fichier choisir ?",
              callback_data:
                "milo:files"
            }
          ],

          [
            {
              text:
                "Import / lancement d’une mission",
              callback_data:
                "milo:mission"
            }
          ]
        ],

        env
      );

    case "milo:launch":
      return node(
        "🚀 <b>MILO ne se lance pas</b>\n\n" +
          "Le favori MILO est-il déjà créé dans Chrome ?",

        [
          [
            {
              text:
                "✅ Oui",
              callback_data:
                "milo:launch:favorite_yes"
            },

            {
              text:
                "❌ Non",
              callback_data:
                "milo:launch:favorite_no"
            }
          ]
        ],

        env,
        "faq:milo"
      );

    case "milo:launch:favorite_no":
      return node(
        "🔖 <b>Créer le favori MILO</b>\n\n" +
          "1. Ouvre le tutoriel MILO dans Redacted BannerLab.\n" +
          "2. Crée le favori demandé dans Chrome.\n" +
          "3. Remplace son URL par le code fourni par le Lab.\n" +
          "4. Enregistre-le avec un nom simple, par exemple <b>MILO</b>.\n\n" +
          "Ensuite reviens sur Mission Authoring Tool et lance ce favori depuis la barre d’adresse.",

        [
          [
            {
              text:
                "Le favori est créé",
              callback_data:
                "milo:launch:favorite_yes"
            }
          ]
        ],

        env,
        "milo:launch"
      );

    case "milo:launch:favorite_yes":
      return node(
        "🔖 <b>Favori présent</b>\n\n" +
          "Quand tu commences à taper <b>MILO</b> dans la barre d’adresse de Chrome, " +
          "le favori apparaît-il dans les suggestions ?",

        [
          [
            {
              text:
                "✅ Oui",
              callback_data:
                "milo:launch:suggest_yes"
            },

            {
              text:
                "❌ Non",
              callback_data:
                "milo:launch:suggest_no"
            }
          ]
        ],

        env,
        "milo:launch"
      );

    case "milo:launch:suggest_no":
      return node(
        "🔎 <b>MILO n’apparaît pas dans les suggestions Chrome</b>\n\n" +
          "Ouvre les favoris de Chrome et vérifie le favori MILO :\n" +
          "• le nom doit être facile à retrouver ;\n" +
          "• l’URL doit commencer par <code>javascript:</code> ;\n" +
          "• le code doit être celui fourni actuellement par Redacted BannerLab.\n\n" +
          "Si tu as modifié le favori plusieurs fois, supprime-le puis recrée-le proprement depuis le tutoriel MILO.",

        [
          [
            {
              text:
                "Il apparaît maintenant",
              callback_data:
                "milo:launch:suggest_yes"
            }
          ]
        ],

        env,
        "milo:launch:favorite_yes"
      );

    case "milo:launch:suggest_yes":
      return node(
        "📂 <b>MILO apparaît dans Chrome</b>\n\n" +
          "Quand tu le lances sur Mission Authoring Tool, Chrome te demande-t-il " +
          "d’autoriser / sélectionner un fichier ?",

        [
          [
            {
              text:
                "✅ Oui",
              callback_data:
                "milo:launch:file_yes"
            },

            {
              text:
                "❌ Non",
              callback_data:
                "milo:launch:file_no"
            }
          ]
        ],

        env,
        "milo:launch:favorite_yes"
      );

    case "milo:launch:file_no":
      return node(
        "📂 <b>Aucune demande de fichier</b>\n\n" +
          "Vérifie d’abord que tu es bien sur la page Mission Authoring Tool prévue pour MILO, " +
          "puis relance le favori depuis la barre d’adresse.\n\n" +
          "Si rien ne se passe encore, recrée le favori depuis le tutoriel MILO afin " +
          "d’éliminer un ancien code ou un collage incomplet.",

        [
          [
            {
              text:
                "Voir les fichiers MILO",
              callback_data:
                "milo:files"
            }
          ]
        ],

        env,
        "milo:launch:suggest_yes"
      );

    case "milo:launch:file_yes":
      return node(
        "📁 <b>Quel fichier utilises-tu ?</b>",

        [
          [
            {
              text:
                "MILO_CurrentBanner.json",
              callback_data:
                "milo:file:banner"
            }
          ],

          [
            {
              text:
                "MILO_Launch.txt",
              callback_data:
                "milo:file:launch"
            }
          ],

          [
            {
              text:
                "MILO.user.js",
              callback_data:
                "milo:file:userscript"
            }
          ],

          [
            {
              text:
                "Un autre fichier",
              callback_data:
                "milo:file:other"
            }
          ]
        ],

        env,
        "milo:launch:suggest_yes"
      );

    case "milo:bookmark":
      return node(
        "🔖 <b>Favori MILO / Chrome</b>\n\n" +
          "Le favori sert à lancer MILO depuis Chrome sur Mission Authoring Tool.\n\n" +
          "Si tu as un doute sur son contenu, le plus sûr est de le recréer depuis " +
          "le tutoriel actuel de Redacted BannerLab plutôt que de réparer un vieux code " +
          "caractère par caractère. Les humains ont déjà assez souffert des bookmarklets.",

        [
          [
            {
              text:
                "MILO ne se lance pas",
              callback_data:
                "milo:launch"
            }
          ],

          [
            {
              text:
                "Suggestions Chrome",
              callback_data:
                "milo:launch:suggest_no"
            }
          ]
        ],

        env,
        "faq:milo"
      );

    case "milo:fileauth":
      return node(
        "🔐 <b>Autorisation du fichier</b>\n\n" +
          "MILO a besoin que Chrome lui laisse accéder au fichier choisi par l’utilisateur.\n\n" +
          "Si l’autorisation n’apparaît pas, relance le favori depuis la page correcte et " +
          "vérifie que Chrome n’a pas annulé ou bloqué le sélecteur de fichier.\n\n" +
          "Si l’autorisation apparaît, choisis le fichier produit par le Lab pour la session en cours.",

        [
          [
            {
              text:
                "Quel fichier choisir ?",
              callback_data:
                "milo:files"
            }
          ]
        ],

        env,
        "faq:milo"
      );

    case "milo:files":
      return node(
        "📁 <b>Les fichiers MILO</b>\n\n" +
          "• <code>MILO_CurrentBanner.json</code> : données de la fresque / session courante à importer dans MILO.\n" +
          "• <code>MILO_Launch.txt</code> : fichier de lancement généré par le Lab pour le flux MILO.\n" +
          "• <code>MILO.user.js</code> : script d’installation de MILO, pas le fichier de session à sélectionner pendant une publication.",

        [
          [
            {
              text:
                "MILO_CurrentBanner.json",
              callback_data:
                "milo:file:banner"
            }
          ],

          [
            {
              text:
                "MILO_Launch.txt",
              callback_data:
                "milo:file:launch"
            }
          ],

          [
            {
              text:
                "MILO.user.js",
              callback_data:
                "milo:file:userscript"
            }
          ]
        ],

        env,
        "faq:milo"
      );

    case "milo:file:banner":
      return node(
        "✅ <b>MILO_CurrentBanner.json</b>\n\n" +
          "C’est le fichier contenant les données de la fresque / session courante destinées à MILO.\n\n" +
          "Si MILO demande le fichier de travail généré par Redacted BannerLab, c’est celui-ci qu’il faut sélectionner.",

        [
          [
            {
              text:
                "Continuer le diagnostic",
              callback_data:
                "milo:mission"
            }
          ]
        ],

        env,
        "milo:files"
      );

    case "milo:file:launch":
      return node(
        "ℹ️ <b>MILO_Launch.txt</b>\n\n" +
          "Ce fichier appartient au mécanisme de lancement préparé par le Lab.\n\n" +
          "Ne le confonds pas avec <code>MILO_CurrentBanner.json</code>, qui contient les données de la fresque à importer.",

        [
          [
            {
              text:
                "Voir tous les fichiers",
              callback_data:
                "milo:files"
            }
          ]
        ],

        env,
        "milo:files"
      );

    case "milo:file:userscript":
      return node(
        "🧩 <b>MILO.user.js</b>\n\n" +
          "C’est le script d’installation de MILO.\n\n" +
          "Ce n’est pas le fichier de bannière à sélectionner quand MILO te demande les données de la session courante.",

        [
          [
            {
              text:
                "Voir tous les fichiers",
              callback_data:
                "milo:files"
            }
          ]
        ],

        env,
        "milo:files"
      );

    case "milo:file:other":
      return node(
        "⚠️ <b>Ce fichier ne correspond pas au flux MILO actuel.</b>\n\n" +
          "Retourne dans Redacted BannerLab et régénère / récupère les fichiers MILO de la session courante.\n\n" +
          "Ensuite utilise le fichier indiqué par le tutoriel.",

        [
          [
            {
              text:
                "Voir les fichiers MILO",
              callback_data:
                "milo:files"
            }
          ]
        ],

        env,
        "milo:files"
      );

    case "milo:mission":
      return node(
        "🚀 <b>Import / lancement d’une mission</b>\n\n" +
          "Si MILO s’ouvre mais que l’import ne correspond pas à la fresque attendue :\n" +
          "• vérifie que le fichier vient bien du projet actuellement ouvert dans RBL ;\n" +
          "• régénère les fichiers si le projet a changé ;\n" +
          "• recharge Mission Authoring Tool avant de relancer MILO si la page est restée ouverte depuis une ancienne session.\n\n" +
          "Le bouton final de soumission reste volontairement entre les mains de l’Agent.",

        [
          [
            {
              text:
                "Diagnostic de lancement",
              callback_data:
                "milo:launch"
            }
          ]
        ],

        env,
        "faq:milo"
      );

    /* ======================
     * IGOR
     * ====================== */

    case "faq:igor":
      return node(
        "🧪 <b>IGOR · IITC Gateway for Operations &amp; Routing</b>\n\n" +
          "Quel est le problème ?",

        [
          [
            {
              text:
                "Installer / mettre à jour IGOR",
              callback_data:
                "igor:install"
            }
          ],

          [
            {
              text:
                "Synchronisation Lab ↔ IGOR",
              callback_data:
                "igor:sync"
            }
          ],

          [
            {
              text:
                "Parcours / missions",
              callback_data:
                "igor:route"
            }
          ],

          [
            {
              text:
                "Token / connexion au Lab",
              callback_data:
                "igor:token"
            }
          ],

          [
            {
              text:
                "Mini-IGOR",
              callback_data:
                "igor:mini"
            }
          ],

          [
            {
              text:
                "Reprise de progression",
              callback_data:
                "igor:resume"
            }
          ]
        ],

        env
      );

    case "igor:install":
      return node(
        "🧩 <b>Installer / mettre à jour IGOR</b>\n\n" +
          "Le fichier d’installation actuel est <code>igor.user.js</code>.\n\n" +
          "Utilise l’installation proposée par Redacted BannerLab puis recharge IITC.\n\n" +
          "Si une ancienne version semble encore active, ferme complètement IITC / l’onglet concerné puis rouvre-le après la mise à jour.",

        [
          [
            {
              text:
                "IGOR ne se connecte pas",
              callback_data:
                "igor:token"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    case "igor:sync":
      return node(
        "🔄 <b>Synchronisation Lab ↔ IGOR</b>\n\n" +
          "Dans le mini-IGOR :\n" +
          "• <b>↑ LAB</b> envoie l’état actuel d’IGOR vers Redacted BannerLab ;\n" +
          "• <b>↓ LAB</b> charge dans IGOR les données venant du Lab.\n\n" +
          "Une confirmation est demandée avant l’échange pour éviter d’écraser une progression par accident.",

        [
          [
            {
              text:
                "La synchro est refusée",
              callback_data:
                "igor:token"
            }
          ],

          [
            {
              text:
                "Mauvaise progression après sync",
              callback_data:
                "igor:resume"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    case "igor:route":
      return node(
        "🗺️ <b>Parcours / missions</b>\n\n" +
          "IGOR suit la mission en cours et peut passer à la suivante lorsque le parcours configuré est terminé.\n\n" +
          "Les options de progression automatique et de reprise se règlent directement dans les <b>Options d’IGOR dans IITC</b>.",

        [
          [
            {
              text:
                "Mission précédente / suivante",
              callback_data:
                "igor:mini"
            }
          ],

          [
            {
              text:
                "Reprise du dernier portail",
              callback_data:
                "igor:resume"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    case "igor:token":
      return node(
        "🔐 <b>Token / connexion au Lab</b>\n\n" +
          "Si IGOR refuse une synchronisation ou paraît déconnecté du Lab, recharge la bannière depuis Redacted BannerLab afin qu’IGOR récupère les informations de pont actuelles.\n\n" +
          "Évite de réutiliser une très ancienne session locale si le Lab a depuis régénéré ses données de connexion.",

        [
          [
            {
              text:
                "Tester ensuite la synchro",
              callback_data:
                "igor:sync"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    case "igor:mini":
      return node(
        "📟 <b>Mini-IGOR</b>\n\n" +
          "• appui court au centre : agrandir IGOR ;\n" +
          "• appui long + déplacement : déplacer le panneau ;\n" +
          "• ‹ / › : mission précédente / suivante ;\n" +
          "• ↑ LAB : envoyer vers le Lab ;\n" +
          "• ↓ LAB : charger depuis le Lab.",

        [
          [
            {
              text:
                "Synchronisation",
              callback_data:
                "igor:sync"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    case "igor:resume":
      return node(
        "📍 <b>Reprise de progression</b>\n\n" +
          "Les réglages de reprise et de progression automatique sont maintenant dans les <b>Options d’IGOR dans IITC</b>.\n\n" +
          "Si la reprise pointe au mauvais endroit après une ancienne session, recharge d’abord les données actuelles depuis le Lab puis vérifie l’option de reprise.",

        [
          [
            {
              text:
                "Synchronisation",
              callback_data:
                "igor:sync"
            }
          ]
        ],

        env,
        "faq:igor"
      );

    /* ======================
     * INSTALLATION / MAJ
     * ====================== */

    case "faq:update":
      return node(
        "📲 <b>Installation / mise à jour de Redacted BannerLab</b>\n\n" +
          "Quel symptôme vois-tu ?",

        [
          [
            {
              text:
                "Nouvelle installation",
              callback_data:
                "update:fresh"
            }
          ],

          [
            {
              text:
                "Mettre à jour l’application",
              callback_data:
                "update:upgrade"
            }
          ],

          [
            {
              text:
                "« Application non installée »",
              callback_data:
                "update:notinstalled"
            }
          ],

          [
            {
              text:
                "Téléchargement / APK bloqué",
              callback_data:
                "update:apk"
            }
          ],

          [
            {
              text:
                "TEST ou vraie Release ?",
              callback_data:
                "update:testrelease"
            }
          ]
        ],

        env
      );

    case "update:fresh":
      return node(
        "📲 <b>Nouvelle installation</b>\n\n" +
          "Télécharge l’APK depuis la dernière GitHub Release officielle, puis ouvre-le sur Android.\n\n" +
          "Si Android bloque l’installation, autorise l’installation d’applications provenant de la source utilisée pour ouvrir l’APK, puis relance l’installation.",

        [
          [
            {
              text:
                "Dernière version",
              callback_data:
                "act:latest"
            }
          ]
        ],

        env,
        "faq:update"
      );

    case "update:upgrade":
      return node(
        "⬆️ <b>Mise à jour</b>\n\n" +
          "Installe le nouvel APK par-dessus l’application existante.\n\n" +
          "Une mise à jour normale ne doit pas nécessiter de désinstaller RBL.\n\n" +
          "Si Android refuse l’APK comme incompatible, passe par le diagnostic « Application non installée » avant de supprimer quoi que ce soit.",

        [
          [
            {
              text:
                "Application non installée",
              callback_data:
                "update:notinstalled"
            }
          ]
        ],

        env,
        "faq:update"
      );

    case "update:notinstalled":
      return node(
        "⚠️ <b>« Application non installée »</b>\n\n" +
          "Causes fréquentes :\n" +
          "• APK incomplet ou téléchargement corrompu ;\n" +
          "• APK signé avec une clé différente de l’application déjà installée ;\n" +
          "• conflit avec une très ancienne installation.\n\n" +
          "Commence par retélécharger l’APK officiel.\n\n" +
          "<b>Ne désinstalle pas immédiatement l’application</b> si tu as des projets locaux importants : une désinstallation peut supprimer leurs données locales.",

        [
          [
            {
              text:
                "Mes projets sont importants",
              callback_data:
                "projects:missing"
            }
          ]
        ],

        env,
        "faq:update"
      );

    case "update:apk":
      return node(
        "📦 <b>APK bloqué / téléchargement</b>\n\n" +
          "Retélécharge l’APK depuis la GitHub Release officielle.\n\n" +
          "Si le navigateur l’a téléchargé partiellement, supprime ce fichier incomplet avant de recommencer.\n\n" +
          "Android peut aussi demander explicitement l’autorisation d’installer depuis ton navigateur ou ton gestionnaire de fichiers.",

        [
          [
            {
              text:
                "Voir la dernière Release",
              callback_data:
                "act:latest"
            }
          ]
        ],

        env,
        "faq:update"
      );

    case "update:testrelease":
      return node(
        "🧪 <b>TEST vs Release</b>\n\n" +
          "Les builds de test peuvent être générés comme artifacts sans devenir des GitHub Releases publiques.\n\n" +
          "RITA ne publie automatiquement sur le canal Info que lorsqu’une <b>GitHub Release est réellement publiée</b>.",

        [],

        env,
        "faq:update"
      );

    /* ======================
     * PROJETS
     * ====================== */

    case "faq:projects":
      return node(
        "💾 <b>Projets / sauvegardes</b>\n\n" +
          "Quel est le problème ?",

        [
          [
            {
              text:
                "Je ne retrouve plus un projet",
              callback_data:
                "projects:missing"
            }
          ],

          [
            {
              text:
                "Sauvegarder avant une manipulation",
              callback_data:
                "projects:backup"
            }
          ],

          [
            {
              text:
                "Projet / session incohérente",
              callback_data:
                "projects:session"
            }
          ]
        ],

        env
      );

    case "projects:missing":
      return node(
        "🔎 <b>Projet introuvable</b>\n\n" +
          "Commence par vérifier <b>Mes projets</b> dans RBL.\n\n" +
          "Si l’application a été désinstallée, ses données locales peuvent avoir été supprimées avec elle.\n\n" +
          "Si le projet existe encore mais s’ouvre mal, évite de recréer immédiatement un projet portant le même nom : garde l’état actuel et passe au support avec une capture.",

        [],

        env,
        "faq:projects"
      );

    case "projects:backup":
      return node(
        "💾 <b>Avant une manipulation risquée</b>\n\n" +
          "Si tu dois désinstaller, réinitialiser ou changer de téléphone, assure-toi d’avoir exporté / sauvegardé les projets importants avec les fonctions disponibles dans RBL.\n\n" +
          "Une désinstallation Android peut effacer les données locales de l’application.",

        [],

        env,
        "faq:projects"
      );

    case "projects:session":
      return node(
        "🧩 <b>Projet / session incohérente</b>\n\n" +
          "Vérifie d’abord que tu travailles sur le bon projet actif.\n\n" +
          "Si MILO ou IGOR utilise encore une session précédente, régénère ou resynchronise les données depuis le projet actuellement ouvert dans RBL.",

        [
          [
            {
              text:
                "MILO",
              callback_data:
                "faq:milo"
            }
          ],

          [
            {
              text:
                "IGOR",
              callback_data:
                "faq:igor"
            }
          ]
        ],

        env,
        "faq:projects"
      );

    /* ======================
     * IMAGES / CALQUES
     * ====================== */

    case "faq:visuals":
      return node(
        "🖼️ <b>Images / calques / Studio</b>\n\n" +
          "Quel type de problème ?",

        [
          [
            {
              text:
                "Image ou calque invisible",
              callback_data:
                "visuals:hidden"
            }
          ],

          [
            {
              text:
                "Opacité / cercles",
              callback_data:
                "visuals:opacity"
            }
          ],

          [
            {
              text:
                "Studio / cadrage",
              callback_data:
                "visuals:studio"
            }
          ],

          [
            {
              text:
                "Ordre des calques",
              callback_data:
                "visuals:layers"
            }
          ]
        ],

        env
      );

    case "visuals:hidden":
      return node(
        "👁️ <b>Image / calque invisible</b>\n\n" +
          "Vérifie la visibilité du calque, son opacité et son ordre d’empilement.\n\n" +
          "Un calque présent mais placé derrière un élément opaque peut parfaitement exister tout en jouant à cache-cache avec toi.",

        [
          [
            {
              text:
                "Ordre des calques",
              callback_data:
                "visuals:layers"
            }
          ]
        ],

        env,
        "faq:visuals"
      );

    case "visuals:opacity":
      return node(
        "◯ <b>Opacité / cercles</b>\n\n" +
          "L’opacité des cercles se règle directement avec le curseur prévu dans l’éditeur, avec aperçu en direct.\n\n" +
          "Si le résultat paraît trop sombre ou trop transparent, vérifie aussi ce qui se trouve sous le calque : le contraste change fortement la perception.",

        [],

        env,
        "faq:visuals"
      );

    case "visuals:studio":
      return node(
        "🎛️ <b>Studio / cadrage</b>\n\n" +
          "Si le résultat ne correspond pas à l’aperçu attendu, contrôle d’abord le cadrage, la taille de l’image et les transformations appliquées avant d’ajouter de nouveaux calques.\n\n" +
          "Pour un défaut reproductible, une capture de l’aperçu et du résultat final est idéale pour le support.",

        [],

        env,
        "faq:visuals"
      );

    case "visuals:layers":
      return node(
        "📚 <b>Ordre des calques</b>\n\n" +
          "Place les éléments de fond en dessous et les éléments devant rester visibles au-dessus.\n\n" +
          "Si un calque semble avoir disparu après une modification, vérifie d’abord son ordre et sa visibilité avant de le réimporter.",

        [],

        env,
        "faq:visuals"
      );

    /* ======================
     * RECHERCHE
     * ====================== */

    case "faq:search":
      return node(
        "🔎 <b>Rechercher une fresque</b>\n\n" +
          "La recherche Bannergress est accessible directement depuis l’accueil de Redacted BannerLab via <b>Rechercher une fresque</b>.\n\n" +
          "Si une fresque n’apparaît pas, essaie une recherche plus courte ou plus précise et vérifie ta connexion avant de conclure que la bannière s’est évaporée dans le néant.",

        [
          [
            {
              text:
                "Aucun résultat",
              callback_data:
                "search:none"
            }
          ],

          [
            {
              text:
                "Mauvaise fresque",
              callback_data:
                "search:wrong"
            }
          ]
        ],

        env
      );

    case "search:none":
      return node(
        "🔎 <b>Aucun résultat</b>\n\n" +
          "Essaie avec moins de mots ou une partie distinctive du nom de la fresque.\n\n" +
          "Si aucune recherche ne renvoie quoi que ce soit, vérifie la connexion réseau puis réessaie avant de passer au support.",

        [],

        env,
        "faq:search"
      );

    case "search:wrong":
      return node(
        "🎯 <b>Les résultats ne correspondent pas</b>\n\n" +
          "Réduis la recherche aux mots les plus distinctifs du titre et vérifie les informations du résultat avant de l’importer.\n\n" +
          "Plusieurs fresques peuvent évidemment partager des mots génériques. Même les titres ont réussi à inventer les collisions.",

        [],

        env,
        "faq:search"
      );

    default:
      return null;
  }
}

async function sendFaqNode(
  env,
  chatId,
  key
) {
  if (
    key === "act:latest"
  ) {
    await commandLatest(
      env,
      chatId
    );

    return;
  }

  const item =
    getFaqNode(
      key,
      env
    );

  if (!item) {
    await sendFaqRoot(
      env,
      chatId
    );

    return;
  }

  await sendMessage(
    env,
    chatId,
    item.text,
    {
      reply_markup:
        item.keyboard
    }
  );
}

/* ==========================================================
 * CALLBACKS TELEGRAM
 * ========================================================== */

async function handleCallbackQuery(
  query,
  env
) {
  const data =
    String(
      query.data || ""
    );

  const chatId =
    query.message?.chat?.id;

  const messageId =
    query.message?.message_id;

  const userId =
    query.from?.id;

  await answerCallbackQuery(
    env,
    query.id
  );

  if (!chatId) {
    return;
  }

  if (
    data === "act:latest"
  ) {
    await commandLatest(
      env,
      chatId
    );

    return;
  }

  if (
    data === "admin:help"
  ) {
    if (
      !isAdmin(
        env,
        userId
      )
    ) {
      await sendMessage(
        env,
        chatId,
        "⛔ Cette zone est réservée à l’administration de RITA."
      );

      return;
    }

    await editOrSend(
      env,
      chatId,
      messageId,

      "🔐 <b>RITA · Administration</b>\n\n" +
        "<code>/pub Ton message</code> — publier du texte sur le canal Info\n" +
        "<code>/pub</code> en réponse à un message — recopier ce message / média sur le canal\n" +
        "<code>/release</code> — republier la dernière GitHub Release\n" +
        "<code>/status</code> — état de RITA\n" +
        "<code>/id</code> — afficher les IDs Telegram",

      [
        [
          {
            text:
              "↩️ Menu",
            callback_data:
              "faq:root"
          }
        ]
      ]
    );

    return;
  }

  const item =
    getFaqNode(
      data,
      env
    );

  if (!item) {
    await editOrSend(
      env,
      chatId,
      messageId,

      "🧠 <b>Aide rapide / FAQ</b>",

      faqRootKeyboard(
        env
      ).inline_keyboard
    );

    return;
  }

  await editOrSend(
    env,
    chatId,
    messageId,
    item.text,
    item.keyboard.inline_keyboard
  );
}

async function editOrSend(
  env,
  chatId,
  messageId,
  text,
  inlineKeyboard
) {
  if (messageId) {
    const edited =
      await telegramApi(
        env,
        "editMessageText",
        {
          chat_id:
            chatId,

          message_id:
            messageId,

          text,

          parse_mode:
            "HTML",

          disable_web_page_preview:
            true,

          reply_markup: {
            inline_keyboard:
              inlineKeyboard
          }
        }
      );

    if (edited.ok) {
      return edited;
    }
  }

  return sendMessage(
    env,
    chatId,
    text,
    {
      reply_markup: {
        inline_keyboard:
          inlineKeyboard
      }
    }
  );
}

/* ==========================================================
 * ADMIN TELEGRAM
 * ========================================================== */

async function commandStatus(
  env,
  chatId,
  userId
) {
  if (
    !isAdmin(
      env,
      userId
    )
  ) {
    await denyAdmin(
      env,
      chatId
    );

    return;
  }

  await sendMessage(
    env,
    chatId,

    "🧪 <b>RITA · Status</b>\n\n" +

      `Version : <code>${escapeHtml(
        RITA_VERSION
      )}</code>\n` +

      `Canal Info : ${
        env.TELEGRAM_INFO_CHAT_ID
          ? "✅"
          : "❌"
      }\n` +

      `GitHub : <code>${escapeHtml(
        getGithubRepo(env)
      )}</code>\n` +

      `Webhook GitHub : ${
        env.GITHUB_WEBHOOK_SECRET
          ? "✅"
          : "❌"
      }\n` +

      `Webhook Telegram secret : ${
        env.TELEGRAM_WEBHOOK_SECRET
          ? "✅"
          : "❌"
      }\n` +

      `API /publish : ${
        env.RITA_PUBLISH_KEY
          ? "✅"
          : "❌"
      }\n` +

      `KV anti-doublon : ${
        env.RITA_KV
          ? "✅"
          : "—"
      }`
  );
}

async function commandPublish(
  env,
  chatId,
  userId,
  message,
  args
) {
  if (
    !isAdmin(
      env,
      userId
    )
  ) {
    await denyAdmin(
      env,
      chatId
    );

    return;
  }

  if (
    !env.TELEGRAM_INFO_CHAT_ID
  ) {
    await sendMessage(
      env,
      chatId,
      "❌ TELEGRAM_INFO_CHAT_ID n’est pas configuré."
    );

    return;
  }

  /*
   * /pub en réponse à un message
   *
   * Recopie le message sur le canal.
   * Marche avec texte, photo, vidéo,
   * document, animation, etc.
   */

  if (
    message.reply_to_message
  ) {
    const result =
      await telegramApi(
        env,
        "copyMessage",
        {
          chat_id:
            env.TELEGRAM_INFO_CHAT_ID,

          from_chat_id:
            message.chat.id,

          message_id:
            message
              .reply_to_message
              .message_id
        }
      );

    if (!result.ok) {
      await sendMessage(
        env,
        chatId,

        "❌ Publication impossible.\n\n" +
          `<code>${escapeHtml(
            result.description ||
            "Erreur Telegram"
          )}</code>`
      );

      return;
    }

    await sendMessage(
      env,
      chatId,
      "✅ <b>Publié sur le canal Info.</b>"
    );

    return;
  }

  /*
   * /pub Mon message
   */

  if (args) {
    const result =
      await sendMessage(
        env,
        env.TELEGRAM_INFO_CHAT_ID,
        escapeHtml(args)
      );

    if (!result?.ok) {
      await sendMessage(
        env,
        chatId,
        "❌ La publication a échoué."
      );

      return;
    }

    await sendMessage(
      env,
      chatId,
      "✅ <b>Publié sur le canal Info.</b>"
    );

    return;
  }

  await sendMessage(
    env,
    chatId,

    "📢 <b>Publication RITA</b>\n\n" +
      "• <code>/pub Ton message</code>\n" +
      "• ou réponds <code>/pub</code> à un texte, une photo, une vidéo ou un document pour le recopier sur le canal Info."
  );
}

async function commandPublishLatestRelease(
  env,
  chatId,
  userId
) {
  if (
    !isAdmin(
      env,
      userId
    )
  ) {
    await denyAdmin(
      env,
      chatId
    );

    return;
  }

  const release =
    await fetchLatestGithubRelease(
      env
    );

  if (!release) {
    await sendMessage(
      env,
      chatId,
      "❌ Impossible de récupérer la dernière GitHub Release."
    );

    return;
  }

  await publishGithubReleaseToTelegram(
    env,
    release
  );

  await sendMessage(
    env,
    chatId,
    "✅ <b>Dernière GitHub Release publiée sur le canal Info.</b>"
  );
}

async function denyAdmin(
  env,
  chatId
) {
  await sendMessage(
    env,
    chatId,
    "⛔ Cette commande est réservée à l’administration du Lab."
  );
}

/* ==========================================================
 * GITHUB RELEASE -> TELEGRAM
 * ========================================================== */

async function handleGithubWebhook(
  request,
  env
) {
  if (
    !env.GITHUB_WEBHOOK_SECRET
  ) {
    return json(
      {
        ok: false,
        error:
          "GITHUB_WEBHOOK_SECRET missing"
      },
      500
    );
  }

  const event =
    request.headers.get(
      "X-GitHub-Event"
    ) || "";

  const signature =
    request.headers.get(
      "X-Hub-Signature-256"
    ) || "";

  const delivery =
    request.headers.get(
      "X-GitHub-Delivery"
    ) || "";

  const rawBody =
    await request.text();

  const valid =
    await verifyGithubSignature(
      rawBody,
      signature,
      env.GITHUB_WEBHOOK_SECRET
    );

  if (!valid) {
    return json(
      {
        ok: false,
        error:
          "Invalid GitHub signature"
      },
      403
    );
  }

  /*
   * Test GitHub lors de la
   * création du webhook.
   */

  if (
    event === "ping"
  ) {
    return json({
      ok: true,
      event: "ping",
      message:
        "RITA écoute GitHub."
    });
  }

  if (
    event !== "release"
  ) {
    return json({
      ok: true,
      ignored: true,
      event
    });
  }

  let payload;

  try {
    payload =
      JSON.parse(rawBody);
  } catch {
    return json(
      {
        ok: false,
        error: "Invalid JSON"
      },
      400
    );
  }

  /*
   * Protection si le secret GitHub
   * est réutilisé ailleurs.
   */

  const configuredRepo =
    getGithubRepo(env)
      .toLowerCase();

  const payloadRepo =
    String(
      payload.repository
        ?.full_name ||
      ""
    ).toLowerCase();

  if (
    payloadRepo &&
    payloadRepo !==
      configuredRepo
  ) {
    return json({
      ok: true,
      ignored: true,
      reason:
        "wrong repository"
    });
  }

  /*
   * IMPORTANT
   *
   * Tant qu'il n'y a pas de vraie
   * GitHub Release publiée :
   *
   * RITA NE PUBLIE RIEN.
   *
   * Donc les builds TEST simples
   * restent silencieux.
   */

  if (
    payload.action !==
      "published" ||
    !payload.release ||
    payload.release.draft
  ) {
    return json({
      ok: true,
      ignored: true,
      action:
        payload.action
    });
  }

  const release =
    payload.release;

  /*
   * Anti-double publication optionnel
   * si un binding KV RITA_KV existe.
   */

  const dedupeKey =
    `github-release:${
      release.id ||
      release.tag_name ||
      delivery
    }`;

  if (env.RITA_KV) {
    const already =
      await env.RITA_KV.get(
        dedupeKey
      );

    if (already) {
      return json({
        ok: true,
        duplicate: true,
        tag:
          release.tag_name
      });
    }
  }

  /*
   * Publication Telegram.
   */

  await publishGithubReleaseToTelegram(
    env,
    release
  );

  /*
   * On marque la release publiée
   * seulement APRÈS succès Telegram.
   */

  if (env.RITA_KV) {
    await env.RITA_KV.put(
      dedupeKey,

      JSON.stringify({
        delivery,
        tag:
          release.tag_name,
        published_at:
          new Date()
            .toISOString()
      }),

      {
        expirationTtl:
          60 *
          60 *
          24 *
          90
      }
    );
  }

  return json({
    ok: true,
    published: true,
    tag:
      release.tag_name
  });
}

async function publishGithubReleaseToTelegram(
  env,
  release
) {
  if (
    !env.TELEGRAM_INFO_CHAT_ID
  ) {
    throw new Error(
      "TELEGRAM_INFO_CHAT_ID missing"
    );
  }

  const payload =
    buildReleaseTelegramPayload(
      release,
      true,
      env
    );

  const result =
    await sendMessage(
      env,
      env.TELEGRAM_INFO_CHAT_ID,
      payload.text,
      payload.options
    );

  if (!result?.ok) {
    throw new Error(
      result?.description ||
      "Telegram publication failed"
    );
  }

  return result;
}

function buildReleaseTelegramPayload(
  release,
  automatic = true,
  env = null
) {
  const tag =
    String(
      release.tag_name ||
      release.name ||
      "Nouvelle version"
    );

  const releaseName =
    release.name &&
    release.name !==
      release.tag_name
      ? String(
          release.name
        )
      : "";

  // Le lien GitHub doit toujours être présent dans le message Telegram,
  // même si GitHub ne fournit pas html_url pour une raison quelconque.
  const releaseUrl =
    String(
      release.html_url ||
      ""
    ).trim() ||
    `${
      env
        ? githubRepoUrl(env)
        : `https://github.com/${DEFAULT_REPO}`
    }/releases/tag/${encodeURIComponent(tag)}`;

  const prerelease =
    Boolean(
      release.prerelease
    );

  /*
   * Cherche automatiquement
   * le premier APK de la Release.
   */

  const apkAsset =
    Array.isArray(
      release.assets
    )
      ? release.assets.find(
          asset =>
            String(
              asset.name ||
              ""
            )
              .toLowerCase()
              .endsWith(
                ".apk"
              )
        )
      : null;

  let body =
    cleanGithubReleaseBody(
      release.body ||
      ""
    );

  /*
   * Marge sous les 4096 caractères
   * Telegram.
   */

  if (
    body.length > 2700
  ) {
    body =
      body
        .slice(
          0,
          2697
        )
        .trimEnd() +
      "…";
  }

  let text =
    "🧪 <b>Redacted BannerLab</b>\n\n" +

    (
      prerelease
        ? "🧪 <b>Nouvelle préversion publiée</b>\n"
        : "🚀 <b>Nouvelle version publiée</b>\n"
    ) +

    `📦 <b>${escapeHtml(
      tag
    )}</b>`;

  if (releaseName) {
    text +=
      `\n${escapeHtml(
        releaseName
      )}`;
  }

  if (body) {
    text +=
      `\n\n${escapeHtml(
        body
      )}`;
  }

  // Toujours afficher le lien en clair dans le message.
  // Ainsi il reste accessible même hors du bouton Telegram.
  text +=
    `\n\n🔗 <b>GitHub :</b>\n${escapeHtml(
      releaseUrl
    )}`;

  if (automatic) {
    text +=
      "\n\n<i>Publication automatique par RITA.</i>";
  }

  const rows = [];

  if (
    apkAsset
      ?.browser_download_url
  ) {
    rows.push([
      {
        text:
          "📲 Télécharger l’APK",

        url:
          apkAsset
            .browser_download_url
      }
    ]);
  }

  // Le bouton GitHub est lui aussi systématique.
  rows.push([
    {
      text:
        "🧪 Voir la Release GitHub",

      url:
        releaseUrl
    }
  ]);

  return {
    text,

    options:
      rows.length
        ? {
            reply_markup: {
              inline_keyboard:
                rows
            }
          }
        : {}
  };
}

/* ==========================================================
 * PUBLICATION EXTERNE PROTÉGÉE
 * ========================================================== */

/*
 * POST /publish
 *
 * Authorization:
 * Bearer RITA_PUBLISH_KEY
 *
 * JSON :
 *
 * {
 *   "title": "Information",
 *   "text": "Message",
 *   "silent": false,
 *   "button_text": "Ouvrir",
 *   "button_url": "https://..."
 * }
 */

async function handleDirectPublish(
  request,
  env
) {
  if (
    !env.RITA_PUBLISH_KEY
  ) {
    return json(
      {
        ok: false,
        error:
          "RITA_PUBLISH_KEY missing"
      },
      500
    );
  }

  const authorization =
    request.headers.get(
      "Authorization"
    ) || "";

  const expected =
    `Bearer ${env.RITA_PUBLISH_KEY}`;

  if (
    !constantTimeStringEqual(
      authorization,
      expected
    )
  ) {
    return json(
      {
        ok: false,
        error:
          "Unauthorized"
      },
      401
    );
  }

  if (
    !env.TELEGRAM_INFO_CHAT_ID
  ) {
    return json(
      {
        ok: false,
        error:
          "TELEGRAM_INFO_CHAT_ID missing"
      },
      500
    );
  }

  let body;

  try {
    body =
      await request.json();
  } catch {
    return json(
      {
        ok: false,
        error:
          "Invalid JSON"
      },
      400
    );
  }

  const title =
    String(
      body.title ||
      ""
    ).trim();

  const message =
    String(
      body.text ||
      ""
    ).trim();

  if (
    !title &&
    !message
  ) {
    return json(
      {
        ok: false,
        error:
          "title or text required"
      },
      400
    );
  }

  let text = "";

  if (title) {
    text +=
      `📢 <b>${escapeHtml(
        title
      )}</b>`;
  }

  if (message) {
    text +=
      `${
        text
          ? "\n\n"
          : ""
      }${escapeHtml(
        message
      )}`;
  }

  const options = {
    disable_notification:
      Boolean(
        body.silent
      )
  };

  const buttonText =
    String(
      body.button_text ||
      ""
    ).trim();

  const buttonUrl =
    String(
      body.button_url ||
      ""
    ).trim();

  if (
    buttonText &&
    isAllowedButtonUrl(
      buttonUrl
    )
  ) {
    options.reply_markup = {
      inline_keyboard: [
        [
          {
            text:
              buttonText.slice(
                0,
                64
              ),

            url:
              buttonUrl
          }
        ]
      ]
    };
  }

  const result =
    await sendMessage(
      env,
      env.TELEGRAM_INFO_CHAT_ID,
      text,
      options
    );

  if (!result?.ok) {
    return json(
      {
        ok: false,

        error:
          result?.description ||
          "Telegram publication failed"
      },
      502
    );
  }

  return json({
    ok: true,
    published: true,

    message_id:
      result.result
        ?.message_id
  });
}

/* ==========================================================
 * GITHUB API
 * ========================================================== */

async function fetchLatestGithubRelease(
  env
) {
  const response =
    await fetch(
      `https://api.github.com/repos/${getGithubRepo(
        env
      )}/releases/latest`,

      {
        headers: {
          Accept:
            "application/vnd.github+json",

          "User-Agent":
            "RITA-Redacted-BannerLab",

          "X-GitHub-Api-Version":
            "2022-11-28"
        }
      }
    );

  if (!response.ok) {
    console.error(
      "GitHub API error",
      response.status,
      await response.text()
    );

    return null;
  }

  return response.json();
}

function getGithubRepo(
  env
) {
  return String(
    env.GITHUB_REPO ||
    DEFAULT_REPO
  ).trim();
}

function githubRepoUrl(
  env
) {
  return (
    `https://github.com/` +
    getGithubRepo(env)
  );
}

/* ==========================================================
 * TELEGRAM API
 * ========================================================== */

async function telegramApi(
  env,
  method,
  payload = {}
) {
  if (
    !env.TELEGRAM_BOT_TOKEN
  ) {
    throw new Error(
      "TELEGRAM_BOT_TOKEN missing"
    );
  }

  const response =
    await fetch(
      `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`,

      {
        method:
          "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body:
          JSON.stringify(
            payload
          )
      }
    );

  let data;

  try {
    data =
      await response.json();
  } catch {
    data = {
      ok: false,

      description:
        "Invalid Telegram response"
    };
  }

  if (
    !response.ok ||
    !data.ok
  ) {
    console.error(
      `Telegram ${method} error`,
      data
    );
  }

  return data;
}

async function sendMessage(
  env,
  chatId,
  text,
  options = {}
) {
  const stringText =
    String(text);

  const safeText =
    stringText.length >
    4000
      ? stringText.slice(
          0,
          3997
        ) + "…"
      : stringText;

  return telegramApi(
    env,
    "sendMessage",
    {
      chat_id:
        chatId,

      text:
        safeText,

      parse_mode:
        "HTML",

      disable_web_page_preview:
        true,

      ...options
    }
  );
}

async function answerCallbackQuery(
  env,
  callbackQueryId,
  text = ""
) {
  return telegramApi(
    env,
    "answerCallbackQuery",
    {
      callback_query_id:
        callbackQueryId,

      ...(
        text
          ? { text }
          : {}
      )
    }
  );
}

/* ==========================================================
 * ADMIN
 * ========================================================== */

function isAdmin(
  env,
  userId
) {
  return csv(
    env.ADMIN_TELEGRAM_IDS
  ).includes(
    String(userId)
  );
}

function csv(
  value
) {
  return String(
    value ||
    ""
  )
    .split(",")
    .map(
      value =>
        value.trim()
    )
    .filter(Boolean);
}

/* ==========================================================
 * SÉCURITÉ GITHUB
 * ========================================================== */

async function verifyGithubSignature(
  body,
  signatureHeader,
  secret
) {
  if (
    !signatureHeader.startsWith(
      "sha256="
    )
  ) {
    return false;
  }

  const expectedHex =
    signatureHeader
      .slice(7)
      .toLowerCase();

  if (
    !/^[0-9a-f]{64}$/.test(
      expectedHex
    )
  ) {
    return false;
  }

  const encoder =
    new TextEncoder();

  const key =
    await crypto.subtle.importKey(
      "raw",

      encoder.encode(
        secret
      ),

      {
        name:
          "HMAC",

        hash:
          "SHA-256"
      },

      false,

      ["sign"]
    );

  const signature =
    await crypto.subtle.sign(
      "HMAC",
      key,
      encoder.encode(
        body
      )
    );

  const actualHex =
    [
      ...new Uint8Array(
        signature
      )
    ]
      .map(
        byte =>
          byte
            .toString(16)
            .padStart(
              2,
              "0"
            )
      )
      .join("");

  return constantTimeStringEqual(
    actualHex,
    expectedHex
  );
}

function constantTimeStringEqual(
  a,
  b
) {
  const aa =
    new TextEncoder()
      .encode(
        String(
          a ?? ""
        )
      );

  const bb =
    new TextEncoder()
      .encode(
        String(
          b ?? ""
        )
      );

  if (
    aa.length !==
    bb.length
  ) {
    return false;
  }

  let diff = 0;

  for (
    let i = 0;
    i < aa.length;
    i++
  ) {
    diff |=
      aa[i] ^
      bb[i];
  }

  return diff === 0;
}

/* ==========================================================
 * UTILITAIRES
 * ========================================================== */

function cleanGithubReleaseBody(
  text
) {
  return String(
    text ||
    ""
  )
    .replace(
      /\r/g,
      ""
    )

    .replace(
      /^#{1,6}\s+/gm,
      ""
    )

    .replace(
      /\*\*(.*?)\*\*/g,
      "$1"
    )

    .replace(
      /__(.*?)__/g,
      "$1"
    )

    .replace(
      /~~(.*?)~~/g,
      "$1"
    )

    .replace(
      /`([^`]+)`/g,
      "$1"
    )

    .replace(
      /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g,
      "$1"
    )

    .replace(
      /\n{3,}/g,
      "\n\n"
    )

    .trim();
}

function escapeHtml(
  value
) {
  return String(
    value ?? ""
  )
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    );
}

function isAllowedButtonUrl(
  url
) {
  try {
    const parsed =
      new URL(url);

    return (
      parsed.protocol ===
        "https:" ||
      parsed.protocol ===
        "http:"
    );
  } catch {
    return false;
  }
}

function json(
  data,
  status = 200
) {
  return new Response(
    JSON.stringify(
      data,
      null,
      2
    ),

    {
      status,

      headers: {
        "Content-Type":
          "application/json; charset=utf-8",

        "Cache-Control":
          "no-store"
      }
    }
  );
}