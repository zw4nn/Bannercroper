# Redacted BannerLab 1.0.15.5 TEST · build 11506

## Arcade du Lab — page d’accueil revue

- Refonte de la page d’accueil de l’Arcade du Lab pour lui donner une ambiance plus **backroom / salle de jeu clandestine**.
- Ajout d’une **marquee néon**, d’une scène centrale, de bornes latérales et d’un sol de salle d’arcade.
- Mise en avant de Redacted au centre avec un décor plus vivant.
- Ajout de cartes d’état pour **IGOR**, **MILO** et **RITA** afin de rendre l’entrée plus incarnée.
- Structure d’accueil plus riche tout en conservant les actions d’entrée vers les mini-jeux.
