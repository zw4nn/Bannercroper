# Redacted BannerLab 1.0.15 · build 11500

## 🧪 MILO entre au laboratoire

Le poste de publication accueille officiellement **MILO**, *Mission Import & Launch Operator*. Il remplace l’ancien RBL Publisher dans l’interface et accompagne désormais la publication des missions dans Mission Authoring Tool.

- **MILO 0.5.1** : interface plus claire, actions nommées et Submit reste toujours sous le contrôle de l’Agent.
- Nouvel assistant Chrome pas à pas avec de vraies captures nettoyées.
- Les fichiers prennent enfin son nom : `MILO.user.js`, `MILO_CurrentBanner.json` et `MILO_Launch.txt`.
- Compatibilité conservée avec les anciens fichiers de session pendant la migration vers les noms MILO.
- La configuration Chrome est rejouée une fois pour basculer proprement sur les nouveaux fichiers MILO.
- IGOR reste en **0.6.10**.

---
- Réglages : affichage des versions IGOR 0.6.10 et MILO 0.5.1.

## Build 11502 TEST — nouvel overlay de jeu
- Overlay agrandi plus compact et plus lisible.
- Tête officielle de Redacted à la place du découpage photo et suppression du dinosaure emoji dans le compteur.
- Navigation simplifiée avec `<` / `>` et bouton `Mission terminée`.
- Pause, annulation et reset relégués en commandes secondaires compactes.
- Fin de fresque renforcée : davantage de feux d’artifice et apparition de Redacted, IGOR et MILO avec quelques répliques de félicitations.
