# Redacted BannerLab 1.0.15 · build 11500

## 🧪 MILO entre au laboratoire

Le poste de publication accueille officiellement **MILO**, *Mission Import & Launch Operator*. Il remplace l’ancien RBL Publisher dans l’interface et accompagne désormais la publication des missions dans Mission Authoring Tool.

- **MILO 0.5.1** : interface plus claire, actions nommées et Submit reste toujours sous le contrôle de l’Agent.
- Nouvel assistant Chrome pas à pas avec de vraies captures nettoyées.
- Les fichiers prennent enfin son nom : `MILO.user.js`, `MILO_CurrentBanner.json` et `MILO_Launch.txt`.
- Compatibilité conservée avec les anciens fichiers de session pendant la migration vers les noms MILO.
- La configuration Chrome est rejouée une fois pour basculer proprement sur les nouveaux fichiers MILO.
- IGOR reste en **0.6.10**.

---
