# Redacted BannerLab 1.0.15.13 TEST · build 11514

## IGOR 0.6.12 — déplacement en mode réduit

- En mode réduit, **appui court** sur le bouton central IGOR : ouvre le panneau complet.
- En mode réduit, **appui maintenu / glissé** sur le bouton central : déplace directement IGOR sur l’écran.
- Le déplacement respecte toujours les limites de l’écran et la zone haute de sécurité.
- Les flèches **‹ / ›** restent indépendantes pour changer de mission sans ouvrir IGOR.
- La position est sauvegardée après déplacement.
