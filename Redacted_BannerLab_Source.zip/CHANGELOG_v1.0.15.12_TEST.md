# Redacted BannerLab 1.0.15.12 TEST · build 11513

## Création de bannière

- Ajout d’un **curseur d’opacité des cercles Prime** directement sous la zone de création.
- Le réglage est visible en temps réel sur la fresque, de 0 à 100 %.
- L’opacité est enregistrée avec le projet et restaurée à la réouverture.
- Traduction du nouveau réglage dans les 7 langues prioritaires ; anglais en fallback pour les autres.

## IGOR 0.6.11

- IGOR démarre désormais **réduit par défaut**.
- La miniature possède des flèches **‹ / ›** pour passer à la mission précédente ou suivante sans rouvrir le panneau complet.
- Largeur par défaut du panneau réduite de 300 à **260 px**.
- La progression passe désormais **automatiquement à la mission suivante au 6e portail** par défaut.
- Migration des anciens réglages par défaut de progression vers le nouveau comportement automatique.
- Les 8 commandes du bas sont réorganisées de **2 × 4** vers **4 × 2**, avec boutons plus compacts.
- Les raccourcis compacts sont traduits dans les 7 langues prioritaires, avec anglais en fallback.

## Arcade

- Uniformisation réelle du cadrage des vignettes IGOR / MILO / RITA / REDACTED : même échelle CSS pour toutes les cartes.
