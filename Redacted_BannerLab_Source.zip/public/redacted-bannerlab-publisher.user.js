// ==UserScript==
// @name         Redacted BannerLab Publisher
// @namespace    https://redacted-bannerlab.local/
// @version      0.4.0
// @description  Direct mobile Publisher for Redacted BannerLab on Ingress Mission Authoring.
// @match        https://missions.ingress.com/*
// @grant        none
// @inject-into  page
// @run-at       document-end
// ==/UserScript==

(function(){
'use strict';
if(window.__RBL_PUBLISHER_RUNNING__){window.__RBL_PUBLISHER_RENDER__?.();return}
window.__RBL_PUBLISHER_RUNNING__=true;

const VERSION='0.4.0-browser';
const STORAGE='redactedBannerLabPublisherSessionV2';
let data=null,busy=false,prepared=false,lang='fr';

if(location.hash.includes('rblsetup=chrome')){
  location.href='redactedbannerlab://publisher-chrome-ready';return;
}
if(location.hash.includes('rblsetup=firefox')){
  location.href='redactedbannerlab://publisher-firefox-ready';return;
}

const T={
fr:{title:'RBL Publisher',import:'Créer / importer cette mission',next:'Mission suivante',prev:'Mission précédente',back:'Retour RBL',
ready:'Prêt',login:'Connecte-toi normalement à Mission Authoring. La session RBL est conservée.',
creating:'Création du brouillon…',portals:'Ajout des portails…',image:'Préparation de l’image…',
saving:'Enregistrement…',done:'Mission {n} préparée. Vérifie puis Preview / Submit.',fail:'Erreur : {e}',
overwrite:'La mission ouverte contient déjà des waypoints. Les remplacer ?',noData:'Aucune session RBL. Relance Publier depuis Redacted BannerLab.',
notSubmit:'RBL ne clique jamais sur Submit.',missingImage:'Image mission absente.',missingPortalImages:'{n} portail(s) sans image connue : vérifie les waypoints.',
setup:'Session complète · {n}/{total}',descRequired:'Import bloqué : la mission n’a pas de description.',
portalsRequired:'Import bloqué : cette mission contient {count}/6 portails.',submitted:'Soumise',markSubmitted:'Marquer soumise',resume:'Session retrouvée'},
en:{title:'RBL Publisher',import:'Create / import this mission',next:'Next mission',prev:'Previous mission',back:'Back to RBL',
ready:'Ready',login:'Sign in normally to Mission Authoring. The RBL session is kept.',
creating:'Creating draft…',portals:'Adding portals…',image:'Preparing image…',saving:'Saving…',
done:'Mission {n} prepared. Review it, then Preview / Submit.',fail:'Error: {e}',overwrite:'The open mission already contains waypoints. Replace them?',
noData:'No RBL session. Launch Publish again from Redacted BannerLab.',notSubmit:'RBL never clicks Submit.',missingImage:'Mission image is missing.',
missingPortalImages:'{n} portal(s) have no known image: review the waypoints.',setup:'Full session · {n}/{total}',
descRequired:'Import blocked: this mission has no description.',portalsRequired:'Import blocked: this mission has {count}/6 portals.',
submitted:'Submitted',markSubmitted:'Mark submitted',resume:'Session restored'},
es:{title:'RBL Publisher',import:'Crear / importar esta misión',next:'Misión siguiente',prev:'Misión anterior',back:'Volver a RBL',
ready:'Listo',login:'Inicia sesión normalmente en Mission Authoring. La sesión RBL se conserva.',
creating:'Creando borrador…',portals:'Añadiendo portales…',image:'Preparando imagen…',saving:'Guardando…',
done:'Misión {n} preparada. Revísala y usa Preview / Submit.',fail:'Error: {e}',overwrite:'La misión abierta ya contiene waypoints. ¿Sustituirlos?',
noData:'No hay sesión RBL. Vuelve a Publicar desde Redacted BannerLab.',notSubmit:'RBL nunca pulsa Submit.',missingImage:'Falta la imagen de misión.',
missingPortalImages:'{n} portal(es) sin imagen conocida: revisa los waypoints.',setup:'Sesión completa · {n}/{total}',
descRequired:'Importación bloqueada: la misión no tiene descripción.',portalsRequired:'Importación bloqueada: esta misión tiene {count}/6 portales.',
submitted:'Enviada',markSubmitted:'Marcar enviada',resume:'Sesión restaurada'}};
const t=(k,v={})=>{let s=(T[lang]||T.fr)[k]||k;for(const [a,b] of Object.entries(v))s=s.replaceAll('{'+a+'}',String(b));return s};
const $=(s,r=document)=>r.querySelector(s);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const mission=()=>data?.missions?.[Number(data?.missionIndex)||0]||data?.mission||null;
function persist(){try{localStorage.setItem(STORAGE,JSON.stringify(data))}catch(e){console.warn('[RBL Publisher] persist',e)}}
function decodeIncoming(){
  try{
    const match=location.hash.match(/(?:^#|&)rblpub=([^&]+)/);
    if(match){
      const raw=decodeURIComponent(match[1]),parsed=JSON.parse(raw);
      if(parsed.mission&&!parsed.missions)parsed.missions=[parsed.mission];
      parsed.missionTotal=parsed.missions?.length||parsed.missionTotal||1;
      parsed.missionIndex=Math.max(0,Math.min(parsed.missionTotal-1,Number(parsed.missionIndex)||0));
      parsed.submitted=parsed.submitted||{};
      localStorage.setItem(STORAGE,JSON.stringify(parsed));
      history.replaceState(null,'',location.pathname+location.search);
      return parsed;
    }
    const stored=localStorage.getItem(STORAGE);
    return stored?JSON.parse(stored):null;
  }catch(e){console.error('[RBL Publisher] payload',e);return null}
}
function status(msg,cls=''){const e=$('#rbl-browser-status');if(e){e.textContent=msg;e.className='rbl-status '+cls}}
function getAngularApp(){if(!window.angular)throw new Error('Angular/Mission Authoring not ready');return angular.element(document.body)}
function getEditorScope(){const e=document.querySelector('div.editor');return e?angular.element(e).scope():undefined}
async function waitEditor(timeout=20000){let s=getEditorScope(),st=Date.now();while(!s?.mission&&Date.now()-st<timeout){await sleep(120);s=getEditorScope()}if(!s?.mission)throw new Error('Mission editor did not appear');return s}
async function createNewMission(){
  const app=getAngularApp(),$location=app.injector().get('$location'),scope=app.scope();
  return new Promise((resolve,reject)=>{
    let done=false;const timer=setTimeout(()=>{if(!done){done=true;reject(new Error('Mission editor timeout'))}},20000);
    const off=scope.$on('$routeChangeSuccess',()=>{if(done)return;done=true;clearTimeout(timer);off();setTimeout(resolve,120)});
    scope.$evalAsync(()=>{$location.path('/edit')});
  });
}
function confirmBox(message){return new Promise(resolve=>{const o=document.createElement('div');o.className='rbl-confirm';o.innerHTML='<div><p></p><section><button data-v="0">Cancel</button><button data-v="1">OK</button></section></div>';o.querySelector('p').textContent=message;document.body.appendChild(o);o.querySelectorAll('button').forEach(b=>b.onclick=()=>{const v=b.dataset.v==='1';o.remove();resolve(v)})})}
function dataUrlFile(url,name='banner.jpg'){const [meta,b64]=String(url||'').split(',');if(!b64)throw new Error(t('missingImage'));const mime=(meta.match(/data:([^;]+)/)||[])[1]||'image/jpeg';const bin=atob(b64),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return new File([bytes],name,{type:mime})}
async function missionImageDataUrl(m){
  if(m.imageDataUrl)return m.imageDataUrl;
  if(!data?.spriteDataUrl)throw new Error(t('missingImage'));
  const img=new Image();
  await new Promise((r,j)=>{img.onload=r;img.onerror=j;img.src=data.spriteDataUrl});
  const c=document.createElement('canvas');c.width=c.height=512;
  c.getContext('2d').drawImage(img,Number(m.spriteCol||0)*512,Number(m.spriteRow||0)*512,512,512,0,0,512,512);
  return c.toDataURL('image/jpeg',.94);
}
function portalToMat(p){
  let imageUrl=p.imageUrl||'',missing=!imageUrl;
  if(!imageUrl)imageUrl='https://lh3.googleusercontent.com/s0kCRS7KE-i0gQhbH_gx-qxvC2kHBJ9TDITirnpzSJnEDV-QVDio5OFl8bJ8OC8EhPGGFOFje5HeO9M6RDklZ971e8aSPeLs';
  if(imageUrl.startsWith('http:'))imageUrl=imageUrl.replace('http:','https:');
  return {missing,value:{$$hashKey:null,guid:String(p.guid||''),description:String(p.description||''),location:{latitude:Number(p.latitude),longitude:Number(p.longitude)},imageUrl,isOrnamented:false,isStartPoint:false,title:String(p.title||'Portal'),type:'PORTAL'}};
}
function applyObjective(w,p){w.objective=w.objective||{};w.objective.type=p.objective?.type||'HACK_PORTAL';w.objective.passphrase_params=w.objective.passphrase_params||{};w.objective.passphrase_params.question=p.objective?.question||'';w.objective.passphrase_params._single_passphrase=p.objective?.answer||''}
async function uploadImage(editor,m){
  const url=await missionImageDataUrl(m);
  if(!editor.mission.mission_guid){await editor.save();if(!editor.mission.mission_guid)throw new Error('Mission GUID missing')}
  status(t('image'));
  const file=dataUrlFile(url,'banner-'+String(data.missionIndex+1).padStart(3,'0')+'.jpg');
  const app=getAngularApp(),uploader=app.injector().get('$upload');
  const result=(await uploader.upload({url:'/logo_upload/',file,data:{missionGuid:editor.mission.mission_guid}})).data;
  await new Promise(resolve=>editor.$evalAsync(()=>{editor.mission.definition.logo_url=result.logo_url;editor.mission.definition.badge_url=result.badge_url;resolve()}));
}
async function importMission(){
  if(busy||!mission())return;
  const m=mission();
  if(!String(m.description||'').trim()){status(t('descRequired'),'error');return}
  if((m.portals||[]).length<6){status(t('portalsRequired',{count:(m.portals||[]).length}),'error');return}
  busy=true;const btn=$('#rbl-browser-import');if(btn)btn.disabled=true;
  try{
    status(t('creating'));let editor=getEditorScope();
    if(!editor?.mission){await createNewMission();editor=await waitEditor()}
    if(editor.mission?.definition?.waypoints?.length&&!await confirmBox(t('overwrite')))return;
    editor.$apply(()=>{editor.mission.definition._sequential=m.sequential!==false;editor.mission.definition._hidden=!!editor.mission.definition._sequential&&!!m.hiddenLocation;editor.mission.definition.name=m.title||'';editor.mission.definition.description=m.description||'';editor.mission.definition.waypoints=[];editor.waypointMarkers=[]});
    status(t('portals'));let missing=0;const old=editor.setSelectedWaypoint;
    try{editor.setSelectedWaypoint=()=>0;for(const p of (m.portals||[])){const c=portalToMat(p);if(c.missing)missing++;editor.addWaypoint(c.value)}}finally{editor.setSelectedWaypoint=old}
    (editor.mission.definition.waypoints||[]).forEach((w,i)=>{if(m.portals?.[i])applyObjective(w,m.portals[i])});editor.$apply();
    await uploadImage(editor,m);status(t('saving'));const next=editor.EditorScreenViews?.PREVIEW;await editor.save(next);if(editor.savingFailed)throw new Error('Mission save failed');
    prepared=true;render();status(missing?t('missingPortalImages',{n:missing}):t('done',{n:data.missionIndex+1}),missing?'warn':'ok');
  }catch(e){console.error('[RBL Publisher]',e);status(t('fail',{e:e?.message||e}),'error')}
  finally{busy=false;const b=$('#rbl-browser-import');if(b)b.disabled=false}
}
function changeMission(n){
  const max=(data?.missions?.length||1)-1;
  data.missionIndex=Math.max(0,Math.min(max,n));prepared=false;persist();render();
}
function nextMission(){changeMission((Number(data.missionIndex)||0)+1)}
function prevMission(){changeMission((Number(data.missionIndex)||0)-1)}
function markSubmitted(){data.submitted=data.submitted||{};data.submitted[data.missionIndex]=!data.submitted[data.missionIndex];persist();render()}
function backRbl(){location.href='redactedbannerlab://publisher-return'}
function render(){
  let root=$('#rbl-browser-publisher');
  if(!root){root=document.createElement('aside');root.id='rbl-browser-publisher';document.body.appendChild(root)}
  if(!data||!mission()){root.innerHTML=`<header><b>${t('title')}</b></header><div class="rbl-body"><div class="rbl-status error">${t('noData')}</div></div>`;return}
  const total=data.missions?.length||1,idx=Number(data.missionIndex)||0,done=!!data.submitted?.[idx];
  root.innerHTML=`<header><div><b>${t('title')}</b><span>${t('setup',{n:idx+1,total})} · v${VERSION}</span></div><button id="rbl-browser-collapse">−</button></header>
  <div class="rbl-body">
    <select id="rbl-mission-select">${data.missions.map((m,i)=>`<option value="${i}" ${i===idx?'selected':''}>${String(i+1).padStart(2,'0')} · ${String(m.title||'Mission').replaceAll('<','&lt;')}</option>`).join('')}</select>
    <div class="rbl-mission"><b>${String(idx+1).padStart(2,'0')} · ${mission().title||'Mission'}</b><span>${(mission().portals||[]).length} portals ${done?'· ✓ '+t('submitted'):''}</span></div>
    <button class="primary" id="rbl-browser-import">${prepared?'✓ ':''}${t('import')}</button>
    <div class="rbl-nav"><button id="rbl-browser-prev" ${idx===0?'disabled':''}>‹ ${t('prev')}</button><button id="rbl-browser-next" ${idx>=total-1?'disabled':''}>${t('next')} ›</button></div>
    <button id="rbl-browser-submitted">${done?'✓ ':''}${t('markSubmitted')}</button>
    <button id="rbl-browser-back">← ${t('back')}</button>
    <div id="rbl-browser-status" class="rbl-status">${t('ready')} · ${t('login')}</div><small>${t('notSubmit')}</small>
  </div>`;
  $('#rbl-mission-select').onchange=e=>changeMission(Number(e.target.value));
  $('#rbl-browser-import').onclick=importMission;$('#rbl-browser-next').onclick=nextMission;$('#rbl-browser-prev').onclick=prevMission;$('#rbl-browser-submitted').onclick=markSubmitted;$('#rbl-browser-back').onclick=backRbl;
  $('#rbl-browser-collapse').onclick=()=>{root.classList.toggle('mini');if(root.classList.contains('mini')){root.innerHTML='<button id="rbl-browser-open">🐊 RBL</button>';$('#rbl-browser-open').onclick=()=>{root.classList.remove('mini');render()}}};
}
window.__RBL_PUBLISHER_RENDER__=render;
const style=document.createElement('style');
style.textContent=`#rbl-browser-publisher{position:fixed;z-index:2147483000;right:8px;bottom:10px;width:min(340px,calc(100vw - 16px));font-family:system-ui,-apple-system,sans-serif;color:#f2fff7;background:#07150e;border:1px solid #31ed83;border-radius:15px;box-shadow:0 16px 45px #000b;overflow:hidden}#rbl-browser-publisher *{box-sizing:border-box}#rbl-browser-publisher header{display:flex;align-items:center;gap:8px;background:#0b1d13;padding:8px 10px;border-bottom:1px solid #225d3d}#rbl-browser-publisher header>div{flex:1;min-width:0}#rbl-browser-publisher header b{display:block;font-size:14px}#rbl-browser-publisher header span{display:block;font-size:9px;color:#8db59a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#rbl-browser-publisher header button{width:31px;height:31px;border:0;border-radius:9px;background:#143421;color:#fff;font-size:20px}.rbl-body{padding:9px}.rbl-body select{width:100%;min-height:37px;border:1px solid #285d3e;border-radius:9px;background:#0d2518;color:white;padding:5px}.rbl-mission{padding:7px;border:1px solid #25563a;border-radius:9px;background:#0d2518;margin:7px 0}.rbl-mission b{display:block;font-size:11px}.rbl-mission span{font-size:8px;color:#8db59a}.rbl-body>button,.rbl-nav button{width:100%;min-height:39px;margin-top:6px;border:1px solid #285d3e;border-radius:9px;background:#10291b;color:#fff;font-weight:800;font-size:10px}.rbl-body>button.primary{background:#31ed83;color:#06140b;border-color:#31ed83}.rbl-nav{display:grid;grid-template-columns:1fr 1fr;gap:6px}.rbl-nav button:disabled{opacity:.3}.rbl-status{margin-top:7px;background:#0d2518;border-radius:8px;padding:7px;color:#a7c9b3;font-size:9px;line-height:1.35}.rbl-status.ok{color:#8ff2b8}.rbl-status.warn{color:#ffd27c;background:#2b210c}.rbl-status.error{color:#ffb1a0;background:#2b120e}.rbl-body small{display:block;text-align:center;color:#688575;font-size:8px;margin-top:6px}#rbl-browser-publisher.mini{width:auto;background:transparent;border:0;box-shadow:none}#rbl-browser-publisher.mini>button{border:1px solid #31ed83;border-radius:999px;background:#07150e;color:#31ed83;padding:9px 12px;font-weight:900}.rbl-confirm{position:fixed;inset:0;z-index:2147483646;background:#000b;display:grid;place-items:center;padding:20px;font-family:system-ui}.rbl-confirm>div{max-width:360px;width:100%;background:#07150e;color:white;border:1px solid #31ed83;border-radius:15px;padding:14px}.rbl-confirm section{display:grid;grid-template-columns:1fr 1fr;gap:8px}.rbl-confirm button{min-height:40px;border-radius:9px;border:1px solid #27583c;background:#10291b;color:#fff;font-weight:800}.rbl-confirm button:last-child{background:#31ed83;color:#06140b}`;
document.head.appendChild(style);
data=decodeIncoming();lang=['fr','en','es'].includes(data?.language)?data.language:'fr';render();
})();
