// ==UserScript==
// @name         Redacted BannerLab Publisher
// @namespace    https://redacted-bannerlab.local/
// @version      0.4.1
// @description  Multi-project whole-banner Publisher for Redacted BannerLab.
// @match        https://missions.ingress.com/*
// @grant        none
// @inject-into  page
// @run-at       document-end
// ==/UserScript==

(async function(){
'use strict';

if(window.__RBL_PUBLISHER_041__){
  await window.__RBL_PUBLISHER_041__.refresh?.();
  return;
}

const VERSION='0.4.1-browser';
const DB_NAME='redactedBannerLabPublisherDbV3';
const DB_VERSION=1;
const SESSION_STORE='sessions';
const HANDLE_STORE='handles';
const ACTIVE_KEY='redactedBannerLabPublisherActiveProjectV3';
const LEGACY_SESSION='redactedBannerLabPublisherSessionV2';
const LEGACY_PROGRESS='redactedBannerLabPublisherProgressV2';

if(location.hash.includes('rblsetup=chrome')){
  location.href='redactedbannerlab://publisher-chrome-ready';
  return;
}
if(location.hash.includes('rblsetup=firefox')){
  location.href='redactedbannerlab://publisher-firefox-ready';
  return;
}

let data=null;
let activeProjectKey='';
let sessions=[];
let busy=false;
let progress={sessionId:'',currentIndex:0,prepared:[],done:[]};

const $=(s,r=document)=>r.querySelector(s);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function openDb(){
  return new Promise((resolve,reject)=>{
    const q=indexedDB.open(DB_NAME,DB_VERSION);
    q.onupgradeneeded=()=>{
      const db=q.result;
      if(!db.objectStoreNames.contains(SESSION_STORE))db.createObjectStore(SESSION_STORE,{keyPath:'key'});
      if(!db.objectStoreNames.contains(HANDLE_STORE))db.createObjectStore(HANDLE_STORE);
    };
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}
async function storeGet(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store).objectStore(store).get(key);
    q.onsuccess=()=>resolve(q.result||null);
    q.onerror=()=>reject(q.error);
  });
}
async function storePut(store,value,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const os=db.transaction(store,'readwrite').objectStore(store);
    const q=key===undefined?os.put(value):os.put(value,key);
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}
async function storeDelete(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store,'readwrite').objectStore(store).delete(key);
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}
async function storeClear(store){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store,'readwrite').objectStore(store).clear();
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}
async function getAllSessions(){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(SESSION_STORE).objectStore(SESSION_STORE).getAll();
    q.onsuccess=()=>resolve((q.result||[]).sort((a,b)=>(b.savedAt||0)-(a.savedAt||0)));
    q.onerror=()=>reject(q.error);
  });
}

function sessionProjectKey(s){
  return String(s?.projectId||'').trim()
    || `name:${String(s?.name||'RBL').trim().toLowerCase()}`
    || `session:${String(s?.sessionId||Date.now())}`;
}
function validateSession(s){
  if(!s||s.format!=='redacted-bannerlab-publisher-session'||!Array.isArray(s.missions)||!s.missions.length){
    throw new Error('Invalid RBL Publisher session');
  }
  return s;
}
async function rememberSession(s,{select=true}={}){
  s=validateSession(s);
  const key=sessionProjectKey(s);
  const previous=await storeGet(SESSION_STORE,key);
  const record={
    key,
    name:String(s.name||'RBL'),
    projectId:String(s.projectId||''),
    sessionId:String(s.sessionId||''),
    missionCount:s.missions.length,
    savedAt:Date.now(),
    session:s
  };
  await storePut(SESSION_STORE,record);
  if(previous?.sessionId && previous.sessionId!==record.sessionId){
    localStorage.removeItem(progressKey(previous.sessionId));
  }
  if(select){
    activeProjectKey=key;
    localStorage.setItem(ACTIVE_KEY,key);
  }
  await refreshSessionList();
  return record;
}
async function refreshSessionList(){
  sessions=await getAllSessions();
  if(!sessions.length){
    data=null;
    activeProjectKey='';
    localStorage.removeItem(ACTIVE_KEY);
    progress={sessionId:'',currentIndex:0,prepared:[],done:[]};
    return;
  }
  let wanted=activeProjectKey||localStorage.getItem(ACTIVE_KEY)||'';
  let rec=sessions.find(x=>x.key===wanted)||sessions[0];
  activeProjectKey=rec.key;
  localStorage.setItem(ACTIVE_KEY,rec.key);
  data=rec.session;
  progress=loadProgress();
}
function progressKey(sessionId){return `redactedBannerLabPublisherProgressV3:${sessionId||'none'}`}
function loadProgress(){
  if(!data)return {sessionId:'',currentIndex:0,prepared:[],done:[]};
  try{
    const p=JSON.parse(localStorage.getItem(progressKey(data.sessionId))||'{}');
    if(p.sessionId===data.sessionId){
      return {
        sessionId:data.sessionId,
        currentIndex:Math.max(0,Math.min(Number(p.currentIndex)||0,data.missions.length-1)),
        prepared:Array.isArray(p.prepared)?p.prepared:[],
        done:Array.isArray(p.done)?p.done:[]
      };
    }
  }catch{}
  return {
    sessionId:data.sessionId,
    currentIndex:Math.max(0,Math.min(Number(data.currentIndex)||0,data.missions.length-1)),
    prepared:[],
    done:[]
  };
}
function saveProgress(){
  if(data?.sessionId)localStorage.setItem(progressKey(data.sessionId),JSON.stringify(progress));
}
function mission(){return data?.missions?.[progress.currentIndex]||null}
function lang(){return ['fr','en','es'].includes(data?.language)?data.language:'fr'}

const T={
fr:{
 title:'RBL Publisher',project:'Projet',projects:'Projets Publisher',load:'Charger un JSON',
 refresh:'Actualiser depuis RBL',deleteProject:'Supprimer ce projet',clearAll:'Tout effacer',
 clearConfirm:'Supprimer toutes les sessions Publisher enregistrées dans ce navigateur ?',
 deleteConfirm:'Supprimer le projet « {name} » du Publisher ?',noProjects:'Aucun projet Publisher enregistré.',
 chooseCurrent:'Choisis RBL_Current_Session.rblpub.json dans Documents/RedactedBannerLab.',
 currentHandleSaved:'Fichier RBL mémorisé. Les prochaines préparations pourront réutiliser le même fichier.',
 sessionUpdated:'Projet chargé : {name} · {total} missions.',sessionDeleted:'Projet supprimé.',
 allDeleted:'Toutes les sessions Publisher ont été supprimées.',manage:'Gérer les projets',
 import:'Créer / importer cette mission',prev:'Mission précédente',next:'Mission suivante',
 submitted:'✓ J’ai soumis → préparer la suivante',ready:'Prêt',login:'Connecte-toi normalement à Mission Authoring.',
 creating:'Création du brouillon…',portals:'Ajout des portails…',image:'Envoi de l’image…',saving:'Enregistrement…',
 done:'Mission {n} préparée. Vérifie puis Preview / Submit.',fail:'Erreur : {e}',
 overwrite:'La mission ouverte contient déjà des waypoints. Les remplacer ?',notSubmit:'RBL ne clique jamais sur Submit.',
 missingImage:'Image mission absente.',missingPortalImages:'{n} portail(s) sans image connue : vérifie les waypoints.',
 descRequired:'Import bloqué : la mission n’a pas de description.',
 portalsRequired:'Import bloqué : cette mission contient {count}/6 portails.',
 setup:'{name} · mission {n}/{total}',allDone:'Toutes les missions sont marquées soumises. 🎉',
 status:'{done}/{total} soumises',loadedProjects:'{n} projet(s) mémorisé(s)',
 fileUnsupported:'Le sélecteur avancé n’est pas disponible ici. Utilise Charger un JSON.',
 reloadHint:'Prépare ton projet dans RBL, puis touche Actualiser depuis RBL. Chrome peut simplement redemander Autoriser.'
},
en:{
 title:'RBL Publisher',project:'Project',projects:'Publisher projects',load:'Load JSON',
 refresh:'Refresh from RBL',deleteProject:'Delete this project',clearAll:'Clear all',
 clearConfirm:'Delete every Publisher session stored in this browser?',
 deleteConfirm:'Delete project “{name}” from Publisher?',noProjects:'No Publisher project stored.',
 chooseCurrent:'Choose RBL_Current_Session.rblpub.json from Documents/RedactedBannerLab.',
 currentHandleSaved:'RBL file remembered. Future preparations can reuse the same file.',
 sessionUpdated:'Project loaded: {name} · {total} missions.',sessionDeleted:'Project deleted.',
 allDeleted:'All Publisher sessions have been deleted.',manage:'Manage projects',
 import:'Create / import this mission',prev:'Previous mission',next:'Next mission',
 submitted:'✓ Submitted → prepare next',ready:'Ready',login:'Sign in normally to Mission Authoring.',
 creating:'Creating draft…',portals:'Adding portals…',image:'Uploading image…',saving:'Saving…',
 done:'Mission {n} prepared. Review it, then Preview / Submit.',fail:'Error: {e}',
 overwrite:'The open mission already contains waypoints. Replace them?',notSubmit:'RBL never clicks Submit.',
 missingImage:'Mission image is missing.',missingPortalImages:'{n} portal(s) have no known image: review the waypoints.',
 descRequired:'Import blocked: this mission has no description.',
 portalsRequired:'Import blocked: this mission has {count}/6 portals.',
 setup:'{name} · mission {n}/{total}',allDone:'All missions are marked submitted. 🎉',
 status:'{done}/{total} submitted',loadedProjects:'{n} project(s) remembered',
 fileUnsupported:'Advanced file picker is not available here. Use Load JSON.',
 reloadHint:'Prepare your project in RBL, then tap Refresh from RBL. Chrome may only ask Allow again.'
},
es:{
 title:'RBL Publisher',project:'Proyecto',projects:'Proyectos Publisher',load:'Cargar JSON',
 refresh:'Actualizar desde RBL',deleteProject:'Eliminar este proyecto',clearAll:'Borrar todo',
 clearConfirm:'¿Eliminar todas las sesiones Publisher guardadas en este navegador?',
 deleteConfirm:'¿Eliminar el proyecto « {name} » del Publisher?',noProjects:'No hay proyectos Publisher guardados.',
 chooseCurrent:'Elige RBL_Current_Session.rblpub.json en Documents/RedactedBannerLab.',
 currentHandleSaved:'Archivo RBL memorizado. Las próximas preparaciones podrán reutilizar el mismo archivo.',
 sessionUpdated:'Proyecto cargado: {name} · {total} misiones.',sessionDeleted:'Proyecto eliminado.',
 allDeleted:'Se han eliminado todas las sesiones Publisher.',manage:'Gestionar proyectos',
 import:'Crear / importar esta misión',prev:'Misión anterior',next:'Misión siguiente',
 submitted:'✓ Enviada → preparar siguiente',ready:'Listo',login:'Inicia sesión normalmente en Mission Authoring.',
 creating:'Creando borrador…',portals:'Añadiendo portales…',image:'Subiendo imagen…',saving:'Guardando…',
 done:'Misión {n} preparada. Revísala y usa Preview / Submit.',fail:'Error: {e}',
 overwrite:'La misión abierta ya contiene waypoints. ¿Sustituirlos?',notSubmit:'RBL nunca pulsa Submit.',
 missingImage:'Falta la imagen de la misión.',missingPortalImages:'{n} portal(es) sin imagen conocida: revisa los waypoints.',
 descRequired:'Importación bloqueada: la misión no tiene descripción.',
 portalsRequired:'Importación bloqueada: esta misión tiene {count}/6 portales.',
 setup:'{name} · misión {n}/{total}',allDone:'Todas las misiones están marcadas como enviadas. 🎉',
 status:'{done}/{total} enviadas',loadedProjects:'{n} proyecto(s) memorizado(s)',
 fileUnsupported:'El selector avanzado no está disponible aquí. Usa Cargar JSON.',
 reloadHint:'Prepara tu proyecto en RBL y toca Actualizar desde RBL. Chrome puede pedir solo Autorizar.'
}};
const t=(k,v={})=>{
  let s=(T[lang()]||T.fr)[k]||k;
  for(const[a,b]of Object.entries(v))s=s.replaceAll('{'+a+'}',String(b));
  return s;
};

function status(msg,cls=''){
  const e=$('#rbl-browser-status');
  if(e){e.textContent=msg;e.className='rbl-status '+cls}
}

async function importRawSession(raw,opts={}){
  try{
    const parsed=validateSession(JSON.parse(raw));
    await rememberSession(parsed,{select:true});
    progress=loadProgress();
    render();
    status(t('sessionUpdated',{name:parsed.name||'RBL',total:parsed.missions.length}),'ok');
    return true;
  }catch(e){
    status(t('fail',{e:e?.message||e}),'error');
    return false;
  }
}

async function pickSessionAdvanced(){
  if(!window.showOpenFilePicker){
    $('#rbl-session-file')?.click();
    return;
  }
  try{
    const [handle]=await showOpenFilePicker({
      multiple:false,
      types:[{description:'Redacted BannerLab session',accept:{'application/json':['.json']}}]
    });
    await storePut(HANDLE_STORE,handle,'currentSessionFile');
    const raw=await(await handle.getFile()).text();
    if(await importRawSession(raw)){
      status(t('currentHandleSaved'),'ok');
    }
  }catch(e){
    if(e?.name!=='AbortError')status(t('fail',{e:e?.message||e}),'error');
  }
}

async function refreshFromRblFile(allowPick=true){
  try{
    let handle=await storeGet(HANDLE_STORE,'currentSessionFile');
    if(handle){
      let p=await handle.queryPermission?.({mode:'read'});
      if(p!=='granted'&&handle.requestPermission)p=await handle.requestPermission({mode:'read'});
      if(p==='granted'){
        const raw=await(await handle.getFile()).text();
        await importRawSession(raw);
        return;
      }
    }
    if(allowPick)return pickSessionAdvanced();
    status(t('reloadHint'),'warn');
  }catch(e){
    console.warn('[RBL session handle]',e);
    if(allowPick)return pickSessionAdvanced();
  }
}

async function switchProject(key){
  const rec=sessions.find(x=>x.key===key);
  if(!rec)return;
  activeProjectKey=key;
  localStorage.setItem(ACTIVE_KEY,key);
  data=rec.session;
  progress=loadProgress();
  render();
}

async function deleteCurrentProject(){
  const rec=sessions.find(x=>x.key===activeProjectKey);
  if(!rec)return;
  if(!confirm(t('deleteConfirm',{name:rec.name||'RBL'})))return;
  await storeDelete(SESSION_STORE,rec.key);
  if(rec.sessionId)localStorage.removeItem(progressKey(rec.sessionId));
  localStorage.removeItem(ACTIVE_KEY);
  activeProjectKey='';
  await refreshSessionList();
  render();
  status(t('sessionDeleted'),'ok');
}

async function clearAllProjects(){
  if(!confirm(t('clearConfirm')))return;
  for(const rec of sessions){
    if(rec.sessionId)localStorage.removeItem(progressKey(rec.sessionId));
  }
  await storeClear(SESSION_STORE);
  localStorage.removeItem(ACTIVE_KEY);
  activeProjectKey='';
  sessions=[];
  data=null;
  progress={sessionId:'',currentIndex:0,prepared:[],done:[]};
  render();
  status(t('allDeleted'),'ok');
}

function getAngularApp(){
  if(!window.angular)throw new Error('Angular/Mission Authoring not ready');
  return angular.element(document.body);
}
function getEditorScope(){
  const e=document.querySelector('div.editor');
  return e?angular.element(e).scope():undefined;
}
async function waitEditor(timeout=20000){
  let s=getEditorScope();
  if(s?.mission)return s;
  const started=Date.now();
  while(Date.now()-started<timeout){
    await sleep(120);
    s=getEditorScope();
    if(s?.mission)return s;
  }
  throw new Error('Mission editor did not appear');
}
async function createNewMission(){
  const app=getAngularApp(),$location=app.injector().get('$location'),scope=app.scope();
  return new Promise((resolve,reject)=>{
    let done=false;
    const timer=setTimeout(()=>{
      if(done)return;
      done=true;
      reject(new Error('Mission editor timeout'));
    },20000);
    const off=scope.$on('$routeChangeSuccess',()=>{
      if(done)return;
      done=true;
      clearTimeout(timer);
      off();
      setTimeout(resolve,120);
    });
    scope.$evalAsync(()=>{$location.path('/edit')});
  });
}
function confirmBox(message){
  return new Promise(resolve=>{
    const o=document.createElement('div');
    o.className='rbl-confirm';
    o.innerHTML='<div><p></p><section><button data-v="0">Cancel</button><button data-v="1">OK</button></section></div>';
    o.querySelector('p').textContent=message;
    document.body.appendChild(o);
    o.querySelectorAll('button').forEach(b=>b.onclick=()=>{
      const v=b.dataset.v==='1';
      o.remove();
      resolve(v);
    });
  });
}
function dataUrlFile(url,name='banner.jpg'){
  const[meta,b64]=String(url||'').split(',');
  if(!b64)throw new Error(t('missingImage'));
  const mime=(meta.match(/data:([^;]+)/)||[])[1]||'image/jpeg';
  const bin=atob(b64),bytes=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  return new File([bytes],name,{type:mime});
}
function portalToMat(p){
  let imageUrl=p.imageUrl||'',missing=!imageUrl;
  if(!imageUrl)imageUrl='https://lh3.googleusercontent.com/s0kCRS7KE-i0gQhbH_gx-qxvC2kHBJ9TDITirnpzSJnEDV-QVDio5OFl8bJ8OC8EhPGGFOFje5HeO9M6RDklZ971e8aSPeLs';
  if(imageUrl.startsWith('http:'))imageUrl=imageUrl.replace('http:','https:');
  return {missing,value:{
    $$hashKey:null,guid:String(p.guid||''),description:String(p.description||''),
    location:{latitude:Number(p.latitude),longitude:Number(p.longitude)},
    imageUrl,isOrnamented:false,isStartPoint:false,title:String(p.title||'Portal'),type:'PORTAL'
  }};
}
function applyObjective(w,p){
  w.objective=w.objective||{};
  w.objective.type=p.objective?.type||'HACK_PORTAL';
  w.objective.passphrase_params=w.objective.passphrase_params||{};
  w.objective.passphrase_params.question=p.objective?.question||'';
  w.objective.passphrase_params._single_passphrase=p.objective?.answer||'';
}
async function uploadImage(editor,m){
  if(!m.imageDataUrl)throw new Error(t('missingImage'));
  if(!editor.mission.mission_guid){
    await editor.save();
    if(!editor.mission.mission_guid)throw new Error('Mission GUID missing');
  }
  status(t('image'));
  const file=dataUrlFile(m.imageDataUrl,'banner-'+String(progress.currentIndex+1).padStart(3,'0')+'.jpg');
  const app=getAngularApp(),uploader=app.injector().get('$upload');
  const result=(await uploader.upload({
    url:'/logo_upload/',
    file,
    data:{missionGuid:editor.mission.mission_guid}
  })).data;
  await new Promise(resolve=>editor.$evalAsync(()=>{
    editor.mission.definition.logo_url=result.logo_url;
    editor.mission.definition.badge_url=result.badge_url;
    resolve();
  }));
}
async function importMission(){
  if(busy||!mission())return;
  const m=mission();
  if(!String(m.description||'').trim()){
    status(t('descRequired'),'error');
    return;
  }
  if((m.portals||[]).length<6){
    status(t('portalsRequired',{count:(m.portals||[]).length}),'error');
    return;
  }

  busy=true;
  const btn=$('#rbl-browser-import');
  if(btn)btn.disabled=true;
  try{
    status(t('creating'));
    let editor=getEditorScope();
    if(!editor?.mission){
      await createNewMission();
      editor=await waitEditor();
    }
    if(editor.mission?.definition?.waypoints?.length){
      if(!await confirmBox(t('overwrite')))return;
    }
    editor.$apply(()=>{
      editor.mission.definition._sequential=m.sequential!==false;
      editor.mission.definition._hidden=!!editor.mission.definition._sequential&&!!m.hiddenLocation;
      editor.mission.definition.name=m.title||'';
      editor.mission.definition.description=m.description||'';
      editor.mission.definition.waypoints=[];
      editor.waypointMarkers=[];
    });

    status(t('portals'));
    let missing=0;
    const old=editor.setSelectedWaypoint;
    try{
      editor.setSelectedWaypoint=()=>0;
      for(const p of(m.portals||[])){
        const c=portalToMat(p);
        if(c.missing)missing++;
        editor.addWaypoint(c.value);
      }
    }finally{
      editor.setSelectedWaypoint=old;
    }

    (editor.mission.definition.waypoints||[]).forEach((w,i)=>{
      if(m.portals?.[i])applyObjective(w,m.portals[i]);
    });
    editor.$apply();

    await uploadImage(editor,m);
    status(t('saving'));
    const next=editor.EditorScreenViews?.PREVIEW;
    await editor.save(next);
    if(editor.savingFailed)throw new Error('Mission save failed');

    progress.prepared[progress.currentIndex]=true;
    saveProgress();
    render();
    status(
      missing?t('missingPortalImages',{n:missing}):t('done',{n:progress.currentIndex+1}),
      missing?'warn':'ok'
    );
  }catch(e){
    console.error('[RBL Publisher]',e);
    status(t('fail',{e:e?.message||e}),'error');
  }finally{
    busy=false;
    const b=$('#rbl-browser-import');
    if(b)b.disabled=false;
  }
}

function setCurrent(i){
  if(!data?.missions?.length)return;
  progress.currentIndex=Math.max(0,Math.min(i,data.missions.length-1));
  saveProgress();
  render();
}
async function submittedNext(){
  if(!mission())return;
  progress.done[progress.currentIndex]=true;
  saveProgress();
  if(progress.currentIndex>=data.missions.length-1){
    render();
    status(t('allDone'),'ok');
    return;
  }
  setCurrent(progress.currentIndex+1);
  status(t('creating'));
  setTimeout(()=>importMission(),180);
}
function previousMission(){setCurrent(progress.currentIndex-1)}
function nextMission(){setCurrent(progress.currentIndex+1)}

function render(){
  let root=$('#rbl-browser-publisher');
  if(!root){
    root=document.createElement('aside');
    root.id='rbl-browser-publisher';
    document.body.appendChild(root);
  }

  if(!data||!Array.isArray(data.missions)||!data.missions.length){
    root.innerHTML=`<header><div><b>${t('title')}</b><span>v${VERSION}</span></div><button id="rbl-browser-collapse">−</button></header>
      <div class="rbl-body">
        <div class="rbl-empty"><b>${t('noProjects')}</b><span>${t('chooseCurrent')}</span></div>
        <button class="primary" id="rbl-refresh-session">↻ ${t('refresh')}</button>
        <button id="rbl-load-session">📂 ${t('load')}</button>
        <div id="rbl-browser-status" class="rbl-status">${t('reloadHint')}</div>
        <input type="file" id="rbl-session-file" accept=".json,.rblpub.json,application/json" hidden>
      </div>`;
    $('#rbl-refresh-session').onclick=()=>refreshFromRblFile(true);
    $('#rbl-load-session').onclick=()=>pickSessionAdvanced();
    $('#rbl-session-file').onchange=async e=>{
      const f=e.target.files?.[0];
      if(f)await importRawSession(await f.text());
    };
    $('#rbl-browser-collapse').onclick=()=>root.remove();
    return;
  }

  const m=mission();
  const total=data.missions.length;
  const done=progress.done.filter(Boolean).length;

  root.innerHTML=`<header>
      <div><b>${t('title')}</b><span>${t('setup',{name:data.name||'RBL',n:progress.currentIndex+1,total})} · v${VERSION}</span></div>
      <button id="rbl-browser-collapse">−</button>
    </header>
    <div class="rbl-body">
      <div class="rbl-projectbar">
        <label>${t('project')}</label>
        <select id="rbl-project-select">
          ${sessions.map(x=>`<option value="${esc(x.key)}" ${x.key===activeProjectKey?'selected':''}>${esc(x.name)} · ${x.missionCount}</option>`).join('')}
        </select>
        <div class="rbl-project-actions">
          <button id="rbl-refresh-session" title="${esc(t('refresh'))}">↻</button>
          <button id="rbl-load-session" title="${esc(t('load'))}">📂</button>
          <button id="rbl-delete-session" class="danger" title="${esc(t('deleteProject'))}">🗑</button>
        </div>
      </div>

      <div class="rbl-progress">${t('status',{done,total})}</div>
      <select id="rbl-mission-select">
        ${data.missions.map((x,i)=>`<option value="${i}" ${i===progress.currentIndex?'selected':''}>${progress.done[i]?'✓ ':progress.prepared[i]?'• ':''}${String(i+1).padStart(2,'0')} · ${esc(x.title||'Mission')}</option>`).join('')}
      </select>

      <div class="rbl-mission"><b>${String(progress.currentIndex+1).padStart(2,'0')} · ${esc(m?.title||'Mission')}</b><span>${(m?.portals||[]).length} portals</span></div>
      <button class="primary" id="rbl-browser-import">${progress.prepared[progress.currentIndex]?'↻ ':''}${t('import')}</button>
      <button class="submitted" id="rbl-browser-submitted">${t('submitted')}</button>

      <div class="rbl-nav">
        <button id="rbl-browser-prev" ${progress.currentIndex<=0?'disabled':''}>‹ ${t('prev')}</button>
        <button id="rbl-browser-next" ${progress.currentIndex>=total-1?'disabled':''}>${t('next')} ›</button>
      </div>

      <details class="rbl-manage">
        <summary>${t('manage')} · ${t('loadedProjects',{n:sessions.length})}</summary>
        <button id="rbl-clear-sessions" class="danger">${t('clearAll')}</button>
      </details>

      <div id="rbl-browser-status" class="rbl-status">${t('ready')} · ${t('login')}</div>
      <small>${t('notSubmit')}</small>
      <input type="file" id="rbl-session-file" accept=".json,.rblpub.json,application/json" hidden>
    </div>`;

  $('#rbl-project-select').onchange=e=>switchProject(e.target.value);
  $('#rbl-refresh-session').onclick=()=>refreshFromRblFile(true);
  $('#rbl-load-session').onclick=()=>pickSessionAdvanced();
  $('#rbl-delete-session').onclick=deleteCurrentProject;
  $('#rbl-clear-sessions').onclick=clearAllProjects;
  $('#rbl-session-file').onchange=async e=>{
    const f=e.target.files?.[0];
    if(f)await importRawSession(await f.text());
  };

  $('#rbl-browser-import').onclick=importMission;
  $('#rbl-browser-submitted').onclick=submittedNext;
  $('#rbl-browser-prev').onclick=previousMission;
  $('#rbl-browser-next').onclick=nextMission;
  $('#rbl-mission-select').onchange=e=>setCurrent(+e.target.value);

  $('#rbl-browser-collapse').onclick=()=>{
    root.classList.toggle('mini');
    if(root.classList.contains('mini')){
      root.innerHTML='<button id="rbl-browser-open">🐊 RBL</button>';
      $('#rbl-browser-open').onclick=()=>{
        root.classList.remove('mini');
        render();
      };
    }
  };
}

const style=document.createElement('style');
style.textContent=`
#rbl-browser-publisher{position:fixed;z-index:2147483000;right:8px;bottom:10px;width:min(350px,calc(100vw - 16px));max-height:calc(100vh - 20px);font-family:system-ui,-apple-system,sans-serif;color:#f2fff7;background:#07150e;border:1px solid #31ed83;border-radius:15px;box-shadow:0 16px 45px #000b;overflow:auto}
#rbl-browser-publisher *{box-sizing:border-box}
#rbl-browser-publisher header{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:8px;background:#0b1d13;padding:8px 10px;border-bottom:1px solid #225d3d}
#rbl-browser-publisher header>div{flex:1;min-width:0}
#rbl-browser-publisher header b{display:block;font-size:14px}
#rbl-browser-publisher header span{display:block;font-size:9px;color:#8db59a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#rbl-browser-publisher header button{width:31px;height:31px;border:0;border-radius:9px;background:#143421;color:#fff;font-size:20px}
.rbl-body{padding:9px}
.rbl-empty{padding:10px;border:1px solid #28553c;border-radius:10px;background:#0d2518}
.rbl-empty b,.rbl-empty span{display:block}.rbl-empty span{margin-top:4px;font-size:9px;color:#91aa99;line-height:1.4}
.rbl-projectbar{display:grid;grid-template-columns:1fr auto;gap:6px;align-items:end;margin-bottom:8px}
.rbl-projectbar label{grid-column:1/-1;font-size:8px;color:#8dac98;text-transform:uppercase;font-weight:800}
.rbl-projectbar select{min-width:0}
.rbl-project-actions{display:grid;grid-template-columns:repeat(3,36px);gap:4px}
.rbl-project-actions button{height:36px;border-radius:8px;border:1px solid #285d3e;background:#10291b;color:#fff}
.rbl-project-actions button.danger,.rbl-manage button.danger{border-color:#743c35;color:#ffb7aa;background:#2c1512}
.rbl-progress{font-size:9px;color:#31ed83;font-weight:800;margin-bottom:6px}
.rbl-body select{width:100%;min-height:36px;border-radius:8px;border:1px solid #25563a;background:#0d2518;color:#fff;padding:4px}
.rbl-mission{padding:7px;border:1px solid #25563a;border-radius:9px;background:#0d2518;margin-top:7px}
.rbl-mission b{display:block;font-size:11px}.rbl-mission span{font-size:8px;color:#8db59a}
.rbl-body>button,.rbl-nav button,.rbl-manage button{width:100%;min-height:39px;margin-top:6px;border:1px solid #285d3e;border-radius:9px;background:#10291b;color:#fff;font-weight:800;font-size:10px}
.rbl-body>button.primary{background:#31ed83;color:#06140b;border-color:#31ed83}
.rbl-body>button.submitted{background:#173c28;border-color:#31ed83}
.rbl-nav{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.rbl-nav button:disabled,.rbl-body>button:disabled{opacity:.35}
.rbl-manage{margin-top:8px;border-top:1px solid #183725;padding-top:6px}
.rbl-manage summary{font-size:9px;color:#8dac98;cursor:pointer}
.rbl-status{margin-top:7px;background:#0d2518;border-radius:8px;padding:7px;color:#a7c9b3;font-size:9px;line-height:1.35}
.rbl-status.ok{color:#8ff2b8}.rbl-status.warn{color:#ffd27c;background:#2b210c}.rbl-status.error{color:#ffb1a0;background:#2b120e}
.rbl-body small{display:block;text-align:center;color:#688575;font-size:8px;margin-top:6px}
#rbl-browser-publisher.mini{width:auto;background:transparent;border:0;box-shadow:none;overflow:visible}
#rbl-browser-publisher.mini>button{border:1px solid #31ed83;border-radius:999px;background:#07150e;color:#31ed83;padding:9px 12px;font-weight:900}
.rbl-confirm{position:fixed;inset:0;z-index:2147483646;background:#000b;display:grid;place-items:center;padding:20px;font-family:system-ui}
.rbl-confirm>div{max-width:360px;width:100%;background:#07150e;color:white;border:1px solid #31ed83;border-radius:15px;padding:14px}
.rbl-confirm section{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.rbl-confirm button{min-height:40px;border-radius:9px;border:1px solid #27583c;background:#10291b;color:#fff;font-weight:800}
.rbl-confirm button:last-child{background:#31ed83;color:#06140b}
`;
document.head.appendChild(style);

async function migrateLegacy(){
  try{
    const raw=localStorage.getItem(LEGACY_SESSION);
    if(raw){
      const parsed=JSON.parse(raw);
      if(parsed?.format==='redacted-bannerlab-publisher-session'&&Array.isArray(parsed.missions)&&parsed.missions.length){
        await rememberSession(parsed,{select:false});
      }
    }
  }catch(e){console.warn('[RBL legacy session]',e)}
  localStorage.removeItem(LEGACY_SESSION);
  localStorage.removeItem(LEGACY_PROGRESS);
}

async function bootstrap(){
  await migrateLegacy();

  // Direct hand-off from the Chrome bookmarklet when RBL has just prepared
  // RBL_Current_Session.rblpub.json.
  if(window.__RBL_SESSION_RAW__){
    const raw=window.__RBL_SESSION_RAW__;
    try{delete window.__RBL_SESSION_RAW__}catch{}
    await importRawSession(raw);
  }else{
    await refreshSessionList();
  }

  render();

  // If a stored file handle is already permanently granted, silently refresh
  // it. If Chrome requires a new user gesture, the "Actualiser depuis RBL"
  // button remains available instead.
  try{
    const handle=await storeGet(HANDLE_STORE,'currentSessionFile');
    if(handle&&await handle.queryPermission?.({mode:'read'})==='granted'){
      const raw=await(await handle.getFile()).text();
      await importRawSession(raw);
    }
  }catch(e){console.warn('[RBL auto refresh]',e)}
}

window.__RBL_PUBLISHER_041__={
  render,
  refresh:async()=>{
    await refreshSessionList();
    render();
  }
};

await bootstrap();
setInterval(()=>{
  if(!document.getElementById('rbl-browser-publisher'))render();
},1200);

})();