// ==UserScript==
// @name         MILO · Redacted BannerLab
// @namespace    https://redacted-bannerlab.local/
// @version      0.4.9
// @description  MILO, Mission Import & Launch Operator · assistant de publication de Redacted BannerLab.
// @match        https://missions.ingress.com/*
// @grant        none
// @inject-into  page
// @run-at       document-end
// ==/UserScript==

(async function(){
'use strict';

if(window.__RBL_PUBLISHER_041__){
  await window.__RBL_PUBLISHER_041__.refresh?.();
  return;
}

const VERSION='0.4.9-browser';
const MILO_AVATAR="data:image/webp;base64,UklGRsgWAABXRUJQVlA4ILwWAACwSACdASqAAIAAPlUei0UjoaEcPQ7sOAVEtgBcqZVkk+o8yerf3b+v/sj+6+4zq46k8pDpXzq/631PfpL2C+dx5hf3I9Yz0kf3f1DP8Z/ees49BH9tOtW/wn/O/dn2quoAvTDxj53/Q/3H90/717ZWN/z3+U/6voL/MPwb/E/v3oj4G/HnUI/K/6D/sP7B6ycIfo39N6Avuv9q/63hj6r/hH2A/1S/5frl/w/EeoC/oL1Wf7j/4f7Hz9fUP7WfAP+uH/g7JHpRPBDt4mgotbpHCzkF3/YGn3acQXA5UkLEl8BGMFvSsXVO4KcIua1qeR5u8joOBEjH0S1f6Dw956ebzVbcEzyQGwPTUjdbjRU/Y/TczthRvjraDCLHs2YEbR12EvLOvQpU6R1C91PmAqob8NVx9+R4Sk7hWOq27PmXlfSkdCaXfNJSYOeWEMtk2BaeXHbdh85xIkP9MCcYWUG802xkMUJID4ZygqwHCivtEDiNXDio2fL5TdB4buv30aB7mViM3YXfvsUgQkZvMwm02aVN/VKPAah1WZ9C2LdsaNWvHG40fjkHVzi1WB4Rq9dV2qvVOTUet9hJqqNJu7lqFAJR9oYUjP6A4AtPtXg+nYrqPZLeFZ8YrSAHm6EWomvY14E5eE+r+iIetSQsKAC6q/XJCqUWAX9uTVXyCm+KnfccwvPANyuvfo9W7D+ALv/M+n98TYqXx//n1aW2Y+KWYmfLmBRAeecZJfhMU/tNgps87qUXCmgZhQ8gXQ+d8RGOF//9oKBaHqlgVsa4AAD+/suX1Rgc2MB/7oWzAOkXTV3t1547WrlZ/UlQJMahR0DCv6PqnJhjDe7Op88v5tJq+Q42sA9qYlvmyJR1xtjoq8c9yYYEAD5WWEhY0nMf99At7gYb+mRufhfT1RkvgCsz2P/R58vQ6UbE6SdHTcWbp33+xn9DpGUvpLYPSh0fJ0jtrQCiq3end/hBVue3nlTCv1+f8L3lIYW2vv/9cJWEr+S1o8KF4UjwVdLAbV+OwklFiMD3z9GIMPTLWHglx192mngHWexaZY3qn6WZKpA5YtHdqQxodTOkJvv+wi7Vds5aIiDcwJd+5NWk4vSyBrTPxlTXtQZzc/tIVSV2KEPJWMx030OsWtC8DTpzaHJgmhrSWQiKI+zCrNnYEW7pZI6AqrfQFhv7iO1yFEVZ1SLcUlAbVL1lNmWdGW1HybuYF+lzPKJC/zVTy7tMDsaVoD0jA4bpect8f5ETIXtP7V3X+3eT0Y7bxOIhP7tReMRJHbg4qxiJrnL5cgJRC7zpD/EBqDm1WtIraEA503WIA9zb4f4nKPLjlKpUy1uOFlNsf4IZVfNDn/DV7CXbaxzjfq4Buv7U0ElJr+KndTNrIQBILZIniN+ANFOJTkYSKdnI3ROagtQufgCv8Km/aAkzcmtiXhE/XD1yQCQapZlV56XVHhzJPxTNhp0U+DLAFTytM2kLWxRyj+YOKZG11q7MASZOnl56VPXidm+GJ8USdjSQP+wl2JpRtEO9nN4ryNSMQHHp5O+ZIsSNfH1RC9Xej67y5JJH0mqgcnaGQ8/I0D3Us8QiJXeNeHi/SDNb1LPV/7cSO5kxs+eNdhkn3+yKQNZ+i+OFA9ADAhT819fj7b1LFqXJLcZYS4HohaZp9CGJOxNoZOJr5I8LuSdqmUZ206ney7DRh2D7HaMd4Yad0RYiNlFkRsW2qMxnCr8M6hIxGn3XWuJog/22QAuoqDplWx3dhb+KT28ZaBADqpR9Kc7hOANO9aFx9GW08GPDFBTkpBmQolyQMYSwfvmcAqK94gzbYpW7gr7yhuKS4TVLuCj17X+Z8rrKhknZT5yyBUE5bfzdzyd5xnIfBF7tuCYoABO1j8PeT6Sy/7/bzEP0cRR1LwF+iqhTC7X/PxXONT0UyQZO7NH6kU1mw1mG92siRmRDBaOqgoo0rRX4Y+AB7CW4VU1K8kBkRJRYp7p4FEb/7pxGlxVsax87zosZdIeHdB/2ZyxyMszrQkevM2d0asetRSR6IgVa2F/nmYU6v7IpENNuy5jl+pOJUMAbb/r9CfNwXNC525dvb/Q+7qkZlAYMLegMm1ha0uBAiZ9BUEV0BaTFmGidb888G6OJ01oZtCR7zgFxY5x6BkC0Ak2/xBiFtHzVFJRsdwO4GzHAFftBnLJRKN4OVeoHJN0A2S7c/GXjCGwl7wicBWc2uwpBmOzjvD+yI8P6pMT6/OVBorN6RhyVixr9yQPyyuBXc+XB/2Nj9Sahj7HpLOQ2g3e103YEbRFJQhSM0GoLezOvhiE4NH/a/oDQOyt4OohjDVYJ7SB3yhqopgQ/DWyoQ+WDBNbYdnWrLPg5rrcXKttAmyLqEqaJB7F4xHpZyAOIvXKbo2yORSpJ/oOM+j5Ev2f0z0pF9MtlsPocfZyetaNuCRtpsrk2h+MRF0JpOvMaQnjIIV5g1XKMwesOEYfEuuQIw/kvi1c7ilLgJc4SjQqjbLP5+ADMakAWy5qMB97jlXYhZb9r2gC47XbJmRABSEgJigHxjDW13pQ7hCK1J3cdxpMI1pntDrEtcPv3s3PHP6fpFp3RCkSZ3yvpSuYPc0RZkH8NTDdc655GEEJ/h5WeezOHnWk0w8/Ej/1PwNpuAsBz3c1fqhL9NtPn6RCeIQW47o+gPteNZAsQuZwzsCei/sM/M9p0nsBMyFpa9kU9SJm3kXr+EHn0nQm99ZvB23UnQxsMKhjMDLwJrclvOLkwfi7dI6liCo3oXErm4afxPiOotMy7Fn5ogCAnWEDTVsObiKQRH+icd7PzsiO51SK64OIJkfG2K5Fx/ZcXTt1/hvNpahCWPDe6tUjT44e7FTwtEqv2+7IVvX/Vd/P1YX187btvdDiR3Ssusk0+3T+VPIt1s09LLtYt0pZJBQJoddH62H+pPRPgOVVhLY78j7gu/RDb7KO6gH+YixLCcXf22JESGjpXZcNOZjKK6rZJ4k5OlWstPGxul/HOZkLgagzNJVPFYSeq7rXLIglg+tr5cJWtTU4wrDNcoQVfZ49bAN4rPPlCOstkd59X6q21eVNg40B86QzAcmaMWmX7ObeE3UC9jr4GgH6wT/EAfZsU/txl6XT/PPmHpubUTUUwA6U+9gysuaIbkvPF+JeMGNtGYcBpg27K7GgwCZPzrRREQiX98Td/Xp0xSkzP5TEu4nc4FYIeJSz3jnQmpNeZURUHFVXMGYu+5lpOsvZyHJ35vUjW0soZUOkYd9k4SPyBxvVpZQ8acDCXlIvNWGAk9B7hpW6E81SkCig+hLABp6bAeTQw0cr0dwmzohJ+pFZRLNYyZqal7Pp7YiQhEFXZ3HRpWZ1GM6WgrVlMCwZ7O9rYFlbI5GQmhV9yf/1AtbAkJT5MLgzmfAVR0yUpvXP6s00+5X1WwjmWUWUHKQKpBmnoeO4ih+k6zWL5+ll2TNCU0neUXvOTqKvlF2BWoMwGx825yhHn0Pmadpg/iLZSwvHmy5vJEC7ln25sig0qWP5VwMATDlPx52dFNBaatgZCJmB1wFyFLNas6Y9T4zl4g708lVgEzM4OXR/S+beKhfvEgXw/PLWfydWd7KdmvQ0mkKFV/p2Dr2PTacLD9ppUIdzKbFXTnqCHS8SCFbWo/kg1ICL0Fhl7bpBoea4co2gffX21cyK4GISn31kLJrYn0ZjwztNInJMQXjFe3bl/7UFdQlbMUrLwtasqmBFdlnNO1uPG9BcBj/xnONmPATgrlpYPZEe4beYMjdfGRn2nu1XJ3/AJ1pRP7Nn3JI16cwU71hjlmy3Yfo5GGHYjLFESOgMk6CaMko/H0HnpQjKguMG76yjOLalm8vKq0C51L+ywpdOZtsCcUX6fa1+d9t2JUgJh1TYD9Hlwg5IDmtM6zc6K+6+n55ZGbzcixIGelQfHyMrkbD2N/4QMXHl1aQ93G7RYW1omJhM2GIZhi8EtBze5nTEniuyEKqoUVpwYGXsiXEbu07LHCHIWcdomQZJSRw7eNsjiGjsKapYSBQ4n24dlZjmlN/j8jcW5O1Yk1n5C/z16OFkYE2qlMoBipV+EPoLG7OPaFNDvhU50rWZSx00Lg1VNsXmTij6+SmOWLUGrC3+AuHij9FqVBF1uCJBZyPcuO6YJoSl16Brkjtyz8ZITsniAB/O02wc6IskUeQZe3mKQGmrOojF+Znucf450nmdG4brUXu5tHcWtf8D8dplDrXxiX7QanSZtEiTdZawmVWUJG4n5Ndlw4szMPxOmWF916LaMm8ABdzjpYsmQTrKJeY6y7W6zwFy1JO79CWfnlTNLhbpG/VCpn9027K3jdYccy6E/5F+guodwX9S3OZ3hhbLPsbgqvcSXsv6zl7NHe/9LRmOdAu7zSI4zuDaMPmxwx9BzaB6Cz7mW39JCv5l9ln7Vs1YTIivQcjXZVks7UeFWz60FlBseWUlPXhBmLqoi7TP5VOMKEChRnRjb4KBhPFn4eyMcjRLhg+t0AOoglxbPpQ0IVbs07OkBUqwR0l/qoRn1nNdR3XemSSZ357fRO4qWHOkuzASBm7rF+UJl5xPCteG571rRWs81/omw3XJj+krQxKq9G1orwa19AmLramfNsvPbNiRmfgSGyRqIsJTIiuq1L8zNGmfMw36z4+ERvD2GFnBvS9LkO3P73O35k/Ar0etXp7hkxWi4JdBbg/TBNk+ybhnFxCzYqu4WziuvaVctcMPiXY61GWcroy5SLP7uJjYtLJk5/jlAPzx7chqjwT7Tg9bi26zMLexHN4lS4vHmrY272Hm4FFwa+7j7OB4XsVmVGTAZt0Plv22s4701lziiSAb6+uopvjA42CnU+Hd4hKjIgcVpQpGCZVwYXVz7wQ9t2D/qhoqMwoJF31ZIUbDH++a2ExQNroH0YYSAftcbmnlUlEEHpN/PFPAtIFhIoG8FfJsUKoJYy5YTtHqIBPLf/82V8+wd0BevfgAw5iIgcrGTSqQ0gtvelq449Z/y2eIv8YuwV5Ld+8VJAmEcG1zJ8xx/dj+9Mu+OPH0kK3CmCGQzK0lK+mO9xqGIDlUkvKDlvi/YuDHdtfBVWJBEywGrKC3WVTYc92mzqhFwgSmwTsPWJCDcZjNHUGxX9T3XQevA5d/D0uKpBw7+vUczHKJLvTcu0Pebzcgj1Jo7rqoEHt7CIlEMCdNfeam1DpySuof0XUrqnnhBSMdAjCdhbvsgi861e+hNzfmEN3QgRgkx5nVNuZrsX8s17B0/4R4373UYILEgWkXprdztothK2gTwrXeLFRnaNRIn3VBYYtMO/smNPhtViCH+n7uFe5sh6HKJN8zk85jk42DNSDmwMlQsz+DMTiPV+LgXFEEDc3c1Ydl95V+SsYpc2dOg+8Unep9T73NNTTyXH924WNsf4wnT2upXLlAiRcjQcoplXLxSAN6RsyqWMXQz8mZ5E7C1/52JZqxcsH3epDZUzvoTiWwlRz6e/9dNPA6Xbm3hUMsMx0HOeDdqD4sfaeSLEcNI4cKnkBkP0tPVQv/coPfg7wSGmbJCC07RLSfaYkOfe6TfMVHdkD4B5PQ+mRE/c/WQ65m9Rd+PWIZn/KnxsM3IG5deQcJdiaJYGfJxaKI7hEXnKZtEBL1kmD1babQIrka6XXsjgQzyZATfQKr8g+u61W/mL4M8dVFoWt3hCN4FNlVmtsBa37QbaIWWDjGFnKFGMR4crXMjvLXcgNAOj7P5poawlo35Rq4Wm6w/gMqQdne/X4qdO6cti1W5kWTRo5GKC/HCG8b5zi60TvITY79yW5zcNWH5DPy3+uF/Y7Re2jR4LEjAMdtaYU1CihkHeus07LN7DV1W2/79hm83Y+fgvlFIvHRVNfJyoZYqisF/zuskzhnfJb9oMSPNGEAO5c5W+TPGhdZIQqPwED1SzE4gk6//WN1byg6fkRuEQRKgyQnWv5Bap8L+EsdfPJg3jccsBm15FsSdCAN2fOsDpOSuQjpNNYyH/7WikDyATJAoN/16bIHjsYrz5nMH8VPy5YBIjSP3t0uI0yGICJNTD3F6k3BlGzHVoaWjZmTPC+EtVjsu0U8pbLSYm6p8QM7hy1Zjl17PvP/XBpmIis571btHPL1HHcyJFmFhlLY4TfAFBrYnaPmESslqMtjkp4j9KmNjs627vSXSVIVrywQcLhR4uj92+d29W8KptWflOy9WkFQw7wnilHF4e4JQ/HaoU6KthnU0X095yU60GzyTm6EyGFfk19UQvaXK5nrMoDwSldyYq1tcu2Z9LSBV8vwNXdsFUn0P888ERvO/Z4L/Fg/xAhS5bjt5wmwbFLNUE85mbBHiywJh0MeBDkJkfh9gATffgOjUlsCsdRsr1MdDyDSm0IaWya82b3aEhJY0xohdQUS9tNQaH0InmQBSfmaLVeR9Lv7J3tERdiNIhbfhdQG7CATnCszc1jWDpPbcXwzPBKzlTMm2GRANNFklQU6q9JuMLEIle+hpSxCNi3ZGEdPIihGdRBCYaUswwHHLKs28/psCQe9HlPfQu30Pm5mDvllq5nOcBsSjPwMKunRWIugGTl45jrWVYO79vBb3Eiye1v+YADZOLdQEEuL6f59gEFaPXYYWi/4Hpao303a3K3ppgEHZNMA4VxBcwjN9VzrjYYsYfe/IxIRzCm/g/dGUcWBXckPOy/JEzqLjMKyvsexeG2ijAY9tIcS873HI4PwPgx47oSKDum44KCMGKv+VvXjJdsvFHkjrJT08iiMB1tmyXV9Ugxxdx1QCgM40PZncam/ujVIqe21QRCgUNcmeA/KfeOFkF9orYy3+qPGOPBMeNlGz+cFExSRAGoZdTMhxWs2LgfNLBzin+FX+uv3nLctH4DyzalnwsAprLONj3QBpBpu0D5t5Qa15Q89sJQz24AxCJulmJjxKKkLAqjbbay7pvSbHHcN0EDBy+seurDkpUM3eJ7VgmPU2ukKa9Mxoay83ztsx/DezNwlUk1pwtTTrIN/W/Zgto46BZ/cYJkzWhzkN+Vujt9AxlWewiwgr1ggOoL9V/DQcYMbeeKh/QdxB+YGYdY4aQW2iehdTOYxDV1dOloTzRxu3C7WCxEBkKyns77mujErs+L75EJy8Q4qPMnhHc58uL9IwwTgJ2dffvsxxmHl0dyehLb7e7SVM9ms3BoOY/bdmAqFwLsn/Y67jHh4h0t5pHu7etbNfILC0hMhn4RHwpGXMnOtzpRG7B6V61FJh99NFYrQNm2qAZr7g6LDdKlAYvstCyR5EFnUQMZte9vqghxDdLdiNUaXidGPBa+NoCJ9I38ipQ1i3x6YHV/rOOIJCbUCxTVR1O3cigHu+Gew0ZmxATqk4Nn1HcfQZ4Yrcz6IcCfE1qhTuztBUV73GlfzA3G9YxL6KSMRBdx2nCedK9Ekslb9h8byOpHWCitRTCvgOo5fba+8VPZEJk17FAyXzHJJ4/dJOG/c9EOWptKgyyyBef8HpzHGlw0hO41yaEVyovZCpMb7127cmG0g8wf0CNf65AQhZ9XGSDi//i11KO30mfJIVaXqy3Tv/8hFxIeS52VlUY7nnWJbqdnV33OYB1me3/VPS0tnfekpBmZZk8EjZ4Y+ey72aJK8w1D6Ds4ddspZux/fVeSdc+bPYwpSim2b3Rz8QUN2XvNc273KBBhLrdAYvedTlrTIU7ihcx72u2GLoV9D332yy3FTToy2Kq0188gVeTZ5xLlA/Za1IyMFgcHZFXVpxiy0LQj5lHK4OAB9ijDP42Svi7XW5J1bvDgCtYFgBnIYAAAA=";
const DB_NAME='redactedBannerLabPublisherDbV3';
const DB_VERSION=1;
const SESSION_STORE='sessions';
const HANDLE_STORE='handles';
const ACTIVE_KEY='redactedBannerLabPublisherActiveProjectV3';
const LEGACY_SESSION='redactedBannerLabPublisherSessionV2';
const LEGACY_PROGRESS='redactedBannerLabPublisherProgressV2';

const RBL_HASH_PARAMS=new URLSearchParams(location.hash.replace(/^#/,''));
const RBL_SETUP_TOKEN=String(RBL_HASH_PARAMS.get('rbltoken')||'');
if(RBL_HASH_PARAMS.get('rblsetup')==='chrome'){
  location.href='redactedbannerlab://publisher-chrome-ready?token='+encodeURIComponent(RBL_SETUP_TOKEN);
  return;
}
if(RBL_HASH_PARAMS.get('rblsetup')==='firefox'){
  location.href='redactedbannerlab://publisher-firefox-ready?token='+encodeURIComponent(RBL_SETUP_TOKEN);
  return;
}

let data=null;
let activeProjectKey='';
let sessions=[];
let busy=false;
let progress={sessionId:'',currentIndex:0,prepared:[],done:[],bannergressSynced:[]};
let lastSessionFileModified=0;
let sessionFilePolling=false;

const $=(s,r=document)=>r.querySelector(s);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function openDb(){
  return new Promise((resolve,reject)=>{
    const q=indexedDB.open(DB_NAME,DB_VERSION);
    q.onupgradeneeded=()=>{
      const db=q.result;
      if(!db.objectStoreNames.contains(SESSION_STORE))db.createObjectStore(SESSION_STORE,{keyPath:'key'});
      if(!db.objectStoreNames.contains(HANDLE_STORE))db.createObjectStore(HANDLE_STORE);
    };
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}
async function storeGet(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store).objectStore(store).get(key);
    q.onsuccess=()=>resolve(q.result||null);
    q.onerror=()=>reject(q.error);
  });
}
async function storePut(store,value,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const os=db.transaction(store,'readwrite').objectStore(store);
    const q=key===undefined?os.put(value):os.put(value,key);
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}
async function storeDelete(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store,'readwrite').objectStore(store).delete(key);
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}
async function storeClear(store){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(store,'readwrite').objectStore(store).clear();
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}

async function bookmarkletDb(){
  return new Promise((resolve,reject)=>{
    const q=indexedDB.open('rblpubfs',1);
    q.onupgradeneeded=()=>{
      if(!q.result.objectStoreNames.contains('s'))q.result.createObjectStore('s');
    };
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}
async function bookmarkletSessionPut(handle){
  try{
    const db=await bookmarkletDb();
    await new Promise((resolve,reject)=>{
      const q=db.transaction('s','readwrite').objectStore('s').put(handle,'session');
      q.onsuccess=()=>resolve();
      q.onerror=()=>reject(q.error);
    });
  }catch(e){console.warn('[RBL bookmarklet session handle]',e)}
}
async function bookmarkletSessionDelete(){
  try{
    const db=await bookmarkletDb();
    await new Promise((resolve,reject)=>{
      const q=db.transaction('s','readwrite').objectStore('s').delete('session');
      q.onsuccess=()=>resolve();
      q.onerror=()=>reject(q.error);
    });
  }catch(e){console.warn('[RBL bookmarklet session delete]',e)}
}
async function forgetSessionFile(){
  await storeDelete(HANDLE_STORE,'currentSessionFile').catch(()=>{});
  await bookmarkletSessionDelete();
  status(t('forgotFile'),'ok');
}
async function getAllSessions(){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const q=db.transaction(SESSION_STORE).objectStore(SESSION_STORE).getAll();
    q.onsuccess=()=>resolve((q.result||[]).sort((a,b)=>(b.savedAt||0)-(a.savedAt||0)));
    q.onerror=()=>reject(q.error);
  });
}

function sessionProjectKey(s){
  return String(s?.projectId||'').trim()
    || `name:${String(s?.name||'RBL').trim().toLowerCase()}`
    || `session:${String(s?.sessionId||Date.now())}`;
}
function validateSession(s){
  if(!s||s.format!=='redacted-bannerlab-publisher-session'||!Array.isArray(s.missions)||!s.missions.length){
    throw new Error('Invalid MILO session');
  }
  return s;
}
async function rememberSession(s,{select=true}={}){
  s=validateSession(s);
  const key=sessionProjectKey(s);
  const previous=await storeGet(SESSION_STORE,key);
  const sameSession=previous?.sessionId&&previous.sessionId===String(s.sessionId||'');
  const record={
    key,
    name:String(s.name||'RBL'),
    projectId:String(s.projectId||''),
    sessionId:String(s.sessionId||''),
    missionCount:s.missions.length,
    savedAt:Date.now(),
    session:s,
    progress:sameSession&&previous?.progress?previous.progress:null
  };
  await storePut(SESSION_STORE,record);
  if(previous?.sessionId && previous.sessionId!==record.sessionId){
    localStorage.removeItem(progressKey(previous.sessionId));
  }
  if(select){
    activeProjectKey=key;
    localStorage.setItem(ACTIVE_KEY,key);
  }
  await refreshSessionList();
  return record;
}
async function refreshSessionList(){
  sessions=await getAllSessions();
  if(!sessions.length){
    data=null;
    activeProjectKey='';
    localStorage.removeItem(ACTIVE_KEY);
    progress={sessionId:'',currentIndex:0,prepared:[],done:[],bannergressSynced:[]};
    return;
  }
  let wanted=activeProjectKey||localStorage.getItem(ACTIVE_KEY)||'';
  let rec=sessions.find(x=>x.key===wanted)||sessions[0];
  activeProjectKey=rec.key;
  localStorage.setItem(ACTIVE_KEY,rec.key);
  data=rec.session;
  progress=loadProgress();
}
function progressKey(sessionId){return `redactedBannerLabPublisherProgressV3:${sessionId||'none'}`}
function normalizeProgress(p){
  if(!data)return {sessionId:'',currentIndex:0,prepared:[],done:[]};
  return {
    sessionId:data.sessionId,
    currentIndex:Math.max(0,Math.min(Number(p?.currentIndex)||0,data.missions.length-1)),
    prepared:Array.isArray(p?.prepared)?p.prepared:[],
    done:Array.isArray(p?.done)?p.done:[]
  };
}
function loadProgress(){
  if(!data)return {sessionId:'',currentIndex:0,prepared:[],done:[]};
  try{
    const p=JSON.parse(localStorage.getItem(progressKey(data.sessionId))||'{}');
    if(p.sessionId===data.sessionId)return normalizeProgress(p);
  }catch{}
  const rec=sessions.find(x=>x.key===activeProjectKey&&x.sessionId===data.sessionId);
  if(rec?.progress?.sessionId===data.sessionId)return normalizeProgress(rec.progress);
  return normalizeProgress({currentIndex:Number(data.currentIndex)||0,prepared:[],done:[]});
}
function saveProgress(){
  if(!data?.sessionId)return;
  const snapshot=JSON.parse(JSON.stringify(progress));
  localStorage.setItem(progressKey(data.sessionId),JSON.stringify(snapshot));

  const rec=sessions.find(x=>x.key===activeProjectKey&&x.sessionId===data.sessionId);
  if(rec){
    rec.progress=snapshot;
    storePut(SESSION_STORE,rec).catch(e=>console.warn('[RBL progress persist]',e));
  }
}
function mission(){return data?.missions?.[progress.currentIndex]||null}
function lang(){return ['fr','en','es'].includes(data?.language)?data.language:'fr'}

const T={
fr:{
 title:'MILO',assistant:'Mission Import & Launch Operator · Assistant Publisher du Lab',lore:'Je garde le fil de ta bannière et je prépare chaque mission. Toi, tu gardes le dernier mot sur Submit.',project:'Projet',projects:'Projets de MILO',load:'Charger un JSON',refreshShort:'Actualiser',loadShort:'Charger un projet',changeShort:'Changer de fichier',fileTools:'Fichiers & mémoire',forgetShort:'Oublier le fichier',deleteShort:'Supprimer ce projet',
 refresh:'Actualiser depuis RBL',deleteProject:'Supprimer ce projet',clearAll:'Tout effacer',
 clearConfirm:'Supprimer toutes les sessions mémorisées par MILO dans ce navigateur ?',
 deleteConfirm:'Supprimer le projet « {name} » de la mémoire de MILO ?',noProjects:'MILO n’a encore aucun projet en mémoire.',
 chooseCurrent:'Choisis RBL_Current_Session.rblpub.json dans le dossier Publisher sélectionné dans Redacted BannerLab.',
 currentHandleSaved:'Fichier RBL mémorisé. Les prochaines préparations pourront réutiliser le même fichier.',
 sessionUpdated:'Projet chargé : {name} · {total} missions.',sessionDeleted:'Projet supprimé.',
 allDeleted:'La mémoire de MILO a été vidée.',manage:'Gérer les projets',
 import:'Créer / importer cette mission',prev:'Mission précédente',next:'Mission suivante',
 submitted:'✓ J’ai soumis → préparer la suivante',ready:'Prêt',login:'Connecte-toi normalement à Mission Authoring.',
 creating:'Création du brouillon…',portals:'Ajout des portails…',image:'Envoi de l’image…',saving:'Enregistrement…',
 done:'Mission {n} préparée. Vérifie puis Preview / Submit.',fail:'Erreur : {e}',
 overwrite:'La mission ouverte contient déjà des waypoints. Les remplacer ?',notSubmit:'MILO prépare. Toi seul cliques sur Submit.',bgSyncing:'Synchronisation Bannergress…',bgSynced:'✓ Mission synchronisée avec Bannergress.',bgNoSession:'Bannergress n’est pas connecté dans ce navigateur : aucune connexion n’est ouverte automatiquement.',bgNotPublished:'La mission n’est pas encore publiée dans Mission Authoring. La synchro Bannergress attendra.',bgSyncFail:'Mission publiée, mais synchro Bannergress impossible : {e}',
 missingImage:'Image mission absente.',missingPortalImages:'{n} portail(s) sans image connue : vérifie les waypoints.',
 descRequired:'Import bloqué : la mission n’a pas de description.',
 portalsRequired:'Import bloqué : cette mission contient {count}/6 portails.',
 setup:'{name} · mission {n}/{total}',allDone:'Toutes les missions sont marquées soumises. 🎉',
 status:'{done}/{total} soumises',loadedProjects:'{n} projet(s) mémorisé(s)',
 fileUnsupported:'Le sélecteur avancé n’est pas disponible ici. Utilise Charger un JSON.',
 reloadHint:'Prépare ton projet dans RBL puis charge le JSON courant.',resumed:'Session reprise : {name} · mission {n}/{total}.',changeFile:'Changer le fichier de session',forgetFile:'Oublier le fichier mémorisé',forgotFile:'Fichier de session mémorisé oublié.',chooseAgain:'Choisis maintenant le nouveau JSON de session.'
},
en:{
 title:'MILO',assistant:'Mission Import & Launch Operator · Lab publishing assistant',lore:'I keep track of your banner and prepare each mission. You still keep the final word on Submit.',project:'Project',projects:'MILO projects',load:'Load JSON',refreshShort:'Refresh',loadShort:'Load project',changeShort:'Change file',fileTools:'Files & memory',forgetShort:'Forget file',deleteShort:'Delete project',
 refresh:'Refresh from RBL',deleteProject:'Delete this project',clearAll:'Clear all',
 clearConfirm:'Delete every session remembered by MILO in this browser?',
 deleteConfirm:'Delete project “{name}” from MILO’s memory?',noProjects:'MILO has no project in memory yet.',
 chooseCurrent:'Choose RBL_Current_Session.rblpub.json from the Publisher folder selected in Redacted BannerLab.',
 currentHandleSaved:'RBL file remembered. Future preparations can reuse the same file.',
 sessionUpdated:'Project loaded: {name} · {total} missions.',sessionDeleted:'Project deleted.',
 allDeleted:'MILO’s memory has been cleared.',manage:'Manage projects',
 import:'Create / import this mission',prev:'Previous mission',next:'Next mission',
 submitted:'✓ Submitted → prepare next',ready:'Ready',login:'Sign in normally to Mission Authoring.',
 creating:'Creating draft…',portals:'Adding portals…',image:'Uploading image…',saving:'Saving…',
 done:'Mission {n} prepared. Review it, then Preview / Submit.',fail:'Error: {e}',
 overwrite:'The open mission already contains waypoints. Replace them?',notSubmit:'MILO prepares. Only you click Submit.',bgSyncing:'Syncing with Bannergress…',bgSynced:'✓ Mission synced with Bannergress.',bgNoSession:'Bannergress is not signed in in this browser: no login is opened automatically.',bgNotPublished:'The mission is not published yet in Mission Authoring. Bannergress sync will wait.',bgSyncFail:'Mission published, but Bannergress sync failed: {e}',
 missingImage:'Mission image is missing.',missingPortalImages:'{n} portal(s) have no known image: review the waypoints.',
 descRequired:'Import blocked: this mission has no description.',
 portalsRequired:'Import blocked: this mission has {count}/6 portals.',
 setup:'{name} · mission {n}/{total}',allDone:'All missions are marked submitted. 🎉',
 status:'{done}/{total} submitted',loadedProjects:'{n} project(s) remembered',
 fileUnsupported:'Advanced file picker is not available here. Use Load JSON.',
 reloadHint:'Prepare your project in RBL, then load the current JSON.',resumed:'Session resumed: {name} · mission {n}/{total}.',changeFile:'Change session file',forgetFile:'Forget remembered file',forgotFile:'Remembered session file forgotten.',chooseAgain:'Now choose the new session JSON.'
},
es:{
 title:'MILO',assistant:'Mission Import & Launch Operator · Asistente Publisher del Lab',lore:'Yo mantengo el hilo de tu banner y preparo cada misión. Tú conservas la última palabra sobre Submit.',project:'Proyecto',projects:'Proyectos de MILO',load:'Cargar JSON',refreshShort:'Actualizar',loadShort:'Cargar proyecto',changeShort:'Cambiar archivo',fileTools:'Archivos y memoria',forgetShort:'Olvidar archivo',deleteShort:'Eliminar proyecto',
 refresh:'Actualizar desde RBL',deleteProject:'Eliminar este proyecto',clearAll:'Borrar todo',
 clearConfirm:'¿Eliminar todas las sesiones guardadas por MILO en este navegador?',
 deleteConfirm:'¿Eliminar el proyecto « {name} » de la memoria de MILO?',noProjects:'MILO aún no tiene proyectos en memoria.',
 chooseCurrent:'Elige RBL_Current_Session.rblpub.json en la carpeta Publisher seleccionada en Redacted BannerLab.',
 currentHandleSaved:'Archivo RBL memorizado. Las próximas preparaciones podrán reutilizar el mismo archivo.',
 sessionUpdated:'Proyecto cargado: {name} · {total} misiones.',sessionDeleted:'Proyecto eliminado.',
 allDeleted:'Se ha vaciado la memoria de MILO.',manage:'Gestionar proyectos',
 import:'Crear / importar esta misión',prev:'Misión anterior',next:'Misión siguiente',
 submitted:'✓ Enviada → preparar siguiente',ready:'Listo',login:'Inicia sesión normalmente en Mission Authoring.',
 creating:'Creando borrador…',portals:'Añadiendo portales…',image:'Subiendo imagen…',saving:'Guardando…',
 done:'Misión {n} preparada. Revísala y usa Preview / Submit.',fail:'Error: {e}',
 overwrite:'La misión abierta ya contiene waypoints. ¿Sustituirlos?',notSubmit:'MILO prepara. Solo tú pulsas Submit.',bgSyncing:'Sincronizando con Bannergress…',bgSynced:'✓ Misión sincronizada con Bannergress.',bgNoSession:'Bannergress no está conectado en este navegador: no se abre ningún inicio de sesión automáticamente.',bgNotPublished:'La misión todavía no está publicada en Mission Authoring. La sincronización con Bannergress esperará.',bgSyncFail:'Misión publicada, pero no se pudo sincronizar con Bannergress: {e}',
 missingImage:'Falta la imagen de la misión.',missingPortalImages:'{n} portal(es) sin imagen conocida: revisa los waypoints.',
 descRequired:'Importación bloqueada: la misión no tiene descripción.',
 portalsRequired:'Importación bloqueada: esta misión tiene {count}/6 portales.',
 setup:'{name} · misión {n}/{total}',allDone:'Todas las misiones están marcadas como enviadas. 🎉',
 status:'{done}/{total} enviadas',loadedProjects:'{n} proyecto(s) memorizado(s)',
 fileUnsupported:'El selector avanzado no está disponible aquí. Usa Cargar JSON.',
 reloadHint:'Prepara tu proyecto en RBL y carga el JSON actual.',resumed:'Sesión reanudada: {name} · misión {n}/{total}.',changeFile:'Cambiar archivo de sesión',forgetFile:'Olvidar archivo memorizado',forgotFile:'Archivo de sesión memorizado olvidado.',chooseAgain:'Elige ahora el nuevo JSON de sesión.'
}};
const t=(k,v={})=>{
  let s=(T[lang()]||T.fr)[k]||k;
  for(const[a,b]of Object.entries(v))s=s.replaceAll('{'+a+'}',String(b));
  return s;
};

function status(msg,cls=''){
  const e=$('#rbl-browser-status');
  if(e){e.textContent=msg;e.className='rbl-status '+cls}
}

async function importRawSession(raw,opts={}){
  try{
    const parsed=validateSession(JSON.parse(raw));
    await rememberSession(parsed,{select:true});
    progress=loadProgress();
    render();
    status(t('sessionUpdated',{name:parsed.name||'RBL',total:parsed.missions.length}),'ok');
    return true;
  }catch(e){
    status(t('fail',{e:e?.message||e}),'error');
    return false;
  }
}

async function pickSessionAdvanced(){
  if(!window.showOpenFilePicker){
    $('#rbl-session-file')?.click();
    return;
  }
  try{
    const [handle]=await showOpenFilePicker({
      multiple:false,
      types:[{description:'Redacted BannerLab session',accept:{'application/json':['.json']}}]
    });
    await storePut(HANDLE_STORE,handle,'currentSessionFile');
    await bookmarkletSessionPut(handle);
    const raw=await(await handle.getFile()).text();
    if(await importRawSession(raw)){
      status(t('currentHandleSaved'),'ok');
    }
  }catch(e){
    if(e?.name!=='AbortError')status(t('fail',{e:e?.message||e}),'error');
  }
}

async function refreshFromRblFile(allowPick=true,{silent=false}={}){
  try{
    let handle=await storeGet(HANDLE_STORE,'currentSessionFile');
    if(handle){
      let p=await handle.queryPermission?.({mode:'read'});
      if(p!=='granted'&&allowPick&&handle.requestPermission)p=await handle.requestPermission({mode:'read'});
      if(p==='granted'){
        const file=await handle.getFile();
        const modified=Number(file.lastModified)||0;

        // No disk change: do nothing, especially during polling.
        if(silent&&modified&&modified===lastSessionFileModified)return false;

        const raw=await file.text();
        const parsed=validateSession(JSON.parse(raw));

        // If both mtime and sessionId are unchanged, do not re-render.
        if(silent
          && data?.sessionId===parsed.sessionId
          && (!modified||modified===lastSessionFileModified)){
          return false;
        }

        lastSessionFileModified=modified;
        await rememberSession(parsed,{select:true});
        progress=loadProgress();
        render();
        if(!silent)status(t('sessionUpdated',{name:parsed.name||'RBL',total:parsed.missions.length}),'ok');
        else status(t('sessionUpdated',{name:parsed.name||'RBL',total:parsed.missions.length}),'ok');
        return true;
      }
    }
    if(allowPick)return pickSessionAdvanced();
    if(!silent)status(t('reloadHint'),'warn');
    return false;
  }catch(e){
    console.warn('[RBL session handle]',e);
    if(allowPick)return pickSessionAdvanced();
    if(!silent)status(t('fail',{e:e?.message||e}),'error');
    return false;
  }
}

async function pollCurrentSessionFile(){
  if(sessionFilePolling||busy)return;
  sessionFilePolling=true;
  try{
    await refreshFromRblFile(false,{silent:true});
  }finally{
    sessionFilePolling=false;
  }
}


async function changeSessionFile(){
  await forgetSessionFile();
  status(t('chooseAgain'),'warn');
  await pickSessionAdvanced();
}

async function switchProject(key){
  const rec=sessions.find(x=>x.key===key);
  if(!rec)return;
  activeProjectKey=key;
  localStorage.setItem(ACTIVE_KEY,key);
  data=rec.session;
  progress=loadProgress();
  render();
}

async function deleteCurrentProject(){
  const rec=sessions.find(x=>x.key===activeProjectKey);
  if(!rec)return;
  if(!confirm(t('deleteConfirm',{name:rec.name||'RBL'})))return;
  await storeDelete(SESSION_STORE,rec.key);
  if(rec.sessionId)localStorage.removeItem(progressKey(rec.sessionId));
  localStorage.removeItem(ACTIVE_KEY);
  activeProjectKey='';
  await refreshSessionList();
  render();
  status(t('sessionDeleted'),'ok');
}

async function clearAllProjects(){
  if(!confirm(t('clearConfirm')))return;
  for(const rec of sessions){
    if(rec.sessionId)localStorage.removeItem(progressKey(rec.sessionId));
  }
  await storeClear(SESSION_STORE);
  localStorage.removeItem(ACTIVE_KEY);
  activeProjectKey='';
  sessions=[];
  data=null;
  progress={sessionId:'',currentIndex:0,prepared:[],done:[],bannergressSynced:[]};
  render();
  status(t('allDeleted'),'ok');
}

function getAngularApp(){
  if(!window.angular)throw new Error('Angular/Mission Authoring not ready');
  return angular.element(document.body);
}
function getEditorScope(){
  const e=document.querySelector('div.editor');
  return e?angular.element(e).scope():undefined;
}
async function waitEditor(timeout=20000){
  let s=getEditorScope();
  if(s?.mission)return s;
  const started=Date.now();
  while(Date.now()-started<timeout){
    await sleep(120);
    s=getEditorScope();
    if(s?.mission)return s;
  }
  throw new Error('Mission editor did not appear');
}
async function createNewMission(){
  const app=getAngularApp(),$location=app.injector().get('$location'),scope=app.scope();
  return new Promise((resolve,reject)=>{
    let done=false;
    const timer=setTimeout(()=>{
      if(done)return;
      done=true;
      reject(new Error('Mission editor timeout'));
    },20000);
    const off=scope.$on('$routeChangeSuccess',()=>{
      if(done)return;
      done=true;
      clearTimeout(timer);
      off();
      setTimeout(resolve,120);
    });
    scope.$evalAsync(()=>{$location.path('/edit')});
  });
}
function confirmBox(message){
  return new Promise(resolve=>{
    const o=document.createElement('div');
    o.className='rbl-confirm';
    o.innerHTML='<div><p></p><section><button data-v="0">Cancel</button><button data-v="1">OK</button></section></div>';
    o.querySelector('p').textContent=message;
    document.body.appendChild(o);
    o.querySelectorAll('button').forEach(b=>b.onclick=()=>{
      const v=b.dataset.v==='1';
      o.remove();
      resolve(v);
    });
  });
}
function dataUrlFile(url,name='banner.jpg'){
  const[meta,b64]=String(url||'').split(',');
  if(!b64)throw new Error(t('missingImage'));
  const mime=(meta.match(/data:([^;]+)/)||[])[1]||'image/jpeg';
  const bin=atob(b64),bytes=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  return new File([bytes],name,{type:mime});
}
function portalToMat(p){
  let imageUrl=p.imageUrl||'',missing=!imageUrl;
  if(!imageUrl)imageUrl='https://lh3.googleusercontent.com/s0kCRS7KE-i0gQhbH_gx-qxvC2kHBJ9TDITirnpzSJnEDV-QVDio5OFl8bJ8OC8EhPGGFOFje5HeO9M6RDklZ971e8aSPeLs';
  if(imageUrl.startsWith('http:'))imageUrl=imageUrl.replace('http:','https:');
  return {missing,value:{
    $$hashKey:null,guid:String(p.guid||''),description:String(p.description||''),
    location:{latitude:Number(p.latitude),longitude:Number(p.longitude)},
    imageUrl,isOrnamented:false,isStartPoint:false,title:String(p.title||'Portal'),type:'PORTAL'
  }};
}
function applyObjective(w,p){
  w.objective=w.objective||{};
  w.objective.type=p.objective?.type||'HACK_PORTAL';
  w.objective.passphrase_params=w.objective.passphrase_params||{};
  w.objective.passphrase_params.question=p.objective?.question||'';
  w.objective.passphrase_params._single_passphrase=p.objective?.answer||'';
}
async function uploadImage(editor,m){
  if(!m.imageDataUrl)throw new Error(t('missingImage'));
  if(!editor.mission.mission_guid){
    await editor.save();
    if(!editor.mission.mission_guid)throw new Error('Mission GUID missing');
  }
  status(t('image'));
  const file=dataUrlFile(m.imageDataUrl,'banner-'+String(progress.currentIndex+1).padStart(3,'0')+'.jpg');
  const app=getAngularApp(),uploader=app.injector().get('$upload');
  const result=(await uploader.upload({
    url:'/logo_upload/',
    file,
    data:{missionGuid:editor.mission.mission_guid}
  })).data;
  await new Promise(resolve=>editor.$evalAsync(()=>{
    editor.mission.definition.logo_url=result.logo_url;
    editor.mission.definition.badge_url=result.badge_url;
    resolve();
  }));
}
async function importMission(){
  if(busy||!mission())return;
  const m=mission();
  if(!String(m.description||'').trim()){
    status(t('descRequired'),'error');
    return;
  }
  if((m.portals||[]).length<6){
    status(t('portalsRequired',{count:(m.portals||[]).length}),'error');
    return;
  }

  busy=true;
  const btn=$('#rbl-browser-import');
  if(btn)btn.disabled=true;
  try{
    status(t('creating'));
    let editor=getEditorScope();
    if(!editor?.mission){
      await createNewMission();
      editor=await waitEditor();
    }
    if(editor.mission?.definition?.waypoints?.length){
      if(!await confirmBox(t('overwrite')))return;
    }
    editor.$apply(()=>{
      editor.mission.definition._sequential=m.sequential!==false;
      editor.mission.definition._hidden=!!editor.mission.definition._sequential&&!!m.hiddenLocation;
      editor.mission.definition.name=m.title||'';
      editor.mission.definition.description=m.description||'';
      editor.mission.definition.waypoints=[];
      editor.waypointMarkers=[];
    });

    status(t('portals'));
    let missing=0;
    const old=editor.setSelectedWaypoint;
    try{
      editor.setSelectedWaypoint=()=>0;
      for(const p of(m.portals||[])){
        const c=portalToMat(p);
        if(c.missing)missing++;
        editor.addWaypoint(c.value);
      }
    }finally{
      editor.setSelectedWaypoint=old;
    }

    (editor.mission.definition.waypoints||[]).forEach((w,i)=>{
      if(m.portals?.[i])applyObjective(w,m.portals[i]);
    });
    editor.$apply();

    await uploadImage(editor,m);
    status(t('saving'));
    const next=editor.EditorScreenViews?.PREVIEW;
    await editor.save(next);
    if(editor.savingFailed)throw new Error('Mission save failed');

    progress.prepared[progress.currentIndex]=true;
    saveProgress();
    render();
    status(
      missing?t('missingPortalImages',{n:missing}):t('done',{n:progress.currentIndex+1}),
      missing?'warn':'ok'
    );
  }catch(e){
    console.error('[MILO]',e);
    status(t('fail',{e:e?.message||e}),'error');
  }finally{
    busy=false;
    const b=$('#rbl-browser-import');
    if(b)b.disabled=false;
  }
}

function setCurrent(i){
  if(!data?.missions?.length)return;
  progress.currentIndex=Math.max(0,Math.min(i,data.missions.length-1));
  saveProgress();
  render();
}

const BG_API='https://api.bannergress.com';
const BG_AUTHORITY='https://login.bannergress.com/auth/realms/bannergress';
const BG_CLIENT_ID='bannergress-creator-plugin';
const BG_STORAGE_KEY=`oidc.user:${BG_AUTHORITY}:${BG_CLIENT_ID}`;

function getStoredBannergressUser(){
  try{
    const raw=localStorage.getItem(BG_STORAGE_KEY);
    if(!raw)return null;
    const u=JSON.parse(raw);
    return u&&u.access_token?u:null;
  }catch(e){return null}
}
async function refreshBannergressUser(u){
  if(!u?.refresh_token)return null;
  try{
    const body=new URLSearchParams({grant_type:'refresh_token',refresh_token:u.refresh_token,client_id:BG_CLIENT_ID});
    const r=await fetch(`${BG_AUTHORITY}/protocol/openid-connect/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
    if(!r.ok)return null;
    const x=await r.json();
    const nu={...u,...x,expires_at:Math.floor(Date.now()/1000)+Number(x.expires_in||300)};
    localStorage.setItem(BG_STORAGE_KEY,JSON.stringify(nu));
    return nu;
  }catch(e){return null}
}
async function getBannergressUserNoLogin(){
  let u=getStoredBannergressUser();
  if(!u)return null;
  const expiresAt=Number(u.expires_at||0);
  if(expiresAt && expiresAt>Date.now()/1000+30)return u;
  return await refreshBannergressUser(u);
}
function getCreatorContext(){
  const injector=angular.element(document.body).injector();
  return {Api:injector.get('Api'),$http:injector.get('$http')};
}
async function getPublishedMissionResponse(guid){
  const creator=getCreatorContext();
  try{
    return await creator.$http.post(creator.Api.GET_MISSION_FOR_PROFILE,{'mission_guid':guid});
  }catch(e){
    if(e?.data?.mat_error?.title==='Mission Not Found')return e;
    throw e;
  }
}
async function getPublishedMissionState(guid){
  const creator=getCreatorContext();
  const response=await creator.$http.post(creator.Api.GET_MISSIONS_LIST);
  const lists=response?.data?.missionLists||[];
  const all=Array.isArray(lists)?lists.flat():[];
  const found=all.find(m=>String(m?.mission_guid||'')===String(guid));
  return found?.state||null;
}
async function waitUntilPublished(guid,tries=6){
  for(let i=0;i<tries;i++){
    try{
      const state=await getPublishedMissionState(guid);
      if(state==='PUBLISHED')return true;
    }catch(e){console.warn('[RBL publication check]',e)}
    if(i<tries-1)await sleep(2500);
  }
  return false;
}
async function syncMissionToBannergress(guid){
  const user=await getBannergressUserNoLogin();
  if(!user)return {ok:false,reason:'no-session'};
  const published=await waitUntilPublished(guid);
  if(!published)return {ok:false,reason:'not-published'};
  const response=await getPublishedMissionResponse(guid);
  if(response?.data?.mat_error?.title==='Mission Not Found')return {ok:false,reason:'not-published'};
  const r=await fetch(`${BG_API}/import/getMissionForProfile`,{
    method:'POST',mode:'cors',
    headers:{'Authorization':'Bearer '+user.access_token,'Content-Type':'application/json'},
    body:JSON.stringify({request:{mission_guid:guid},response:response.data})
  });
  if(!r.ok)throw new Error(r.statusText||`HTTP ${r.status}`);
  return {ok:true};
}


async function retryPendingBannergressSync(){
  if(!data?.missions?.length)return;
  const user=await getBannergressUserNoLogin();
  if(!user)return;
  for(let i=0;i<data.missions.length;i++){
    if(!progress.done[i]||progress.bannergressSynced[i])continue;
    const guid=String(data.missions[i]?.guid||'').trim();
    if(!guid)continue;
    try{
      status(t('bgSyncing'),'loading');
      const result=await syncMissionToBannergress(guid);
      if(result.ok){
        progress.bannergressSynced[i]=true;
        saveProgress();
      }
    }catch(e){
      console.warn('[RBL pending Bannergress sync]',e);
    }
  }
}

async function submittedNext(){
  if(!mission())return;
  const index=progress.currentIndex;
  const m=mission();
  progress.done[index]=true;
  saveProgress();

  // The mission must first be submitted by the user in Mission Authoring.
  // Then RBL re-reads the current mission and confirms it is actually published
  // before attempting Bannergress sync. No Bannergress login is opened here.
  try{
    const editor=getEditorScope();
    const guid=String(editor?.mission?.mission_guid||m?.guid||'').trim();
    if(guid && !progress.bannergressSynced[index]){
      status(t('bgSyncing'),'loading');
      const result=await syncMissionToBannergress(guid);
      if(result.ok){
        progress.bannergressSynced[index]=true;
        saveProgress();
        status(t('bgSynced'),'ok');
      }else if(result.reason==='no-session'){
        status(t('bgNoSession'),'warn');
      }else if(result.reason==='not-published'){
        status(t('bgNotPublished'),'warn');
      }
    }
  }catch(e){
    console.warn('[RBL Bannergress sync]',e);
    status(t('bgSyncFail',{e:e?.message||e}),'warn');
  }

  if(index>=data.missions.length-1){
    render();
    status(t('allDone'),'ok');
    return;
  }
  setCurrent(index+1);
  status(t('creating'));
  setTimeout(()=>importMission(),180);
}

function previousMission(){setCurrent(progress.currentIndex-1)}
function nextMission(){setCurrent(progress.currentIndex+1)}

function render(){
  let root=$('#rbl-browser-publisher');
  if(!root){
    root=document.createElement('aside');
    root.id='rbl-browser-publisher';
    document.body.appendChild(root);
  }

  if(!data||!Array.isArray(data.missions)||!data.missions.length){
    root.innerHTML=`<header><div class="rbl-brand"><img src="${MILO_AVATAR}" alt="MILO"><div><b>${t('title')}</b><span>${t('assistant')} · v${VERSION}</span></div></div><button id="rbl-browser-collapse">−</button></header>
      <div class="rbl-body">
        <div class="rbl-empty"><b>${t('noProjects')}</b><span>${t('chooseCurrent')}</span></div>
        <button class="primary" id="rbl-refresh-session">↻ ${t('refresh')}</button>
        <button id="rbl-load-session">📂 ${t('load')}</button>
        <button id="rbl-change-session">🔁 ${t('changeFile')}</button>
        <button id="rbl-forget-session" class="danger">🧹 ${t('forgetFile')}</button>
        <div id="rbl-browser-status" class="rbl-status">${t('reloadHint')}</div>
        <input type="file" id="rbl-session-file" accept=".json,.rblpub.json,application/json" hidden>
      </div>`;
    $('#rbl-refresh-session').onclick=()=>refreshFromRblFile(true);
    $('#rbl-load-session').onclick=()=>pickSessionAdvanced();
    $('#rbl-change-session').onclick=changeSessionFile;
    $('#rbl-forget-session').onclick=forgetSessionFile;
    $('#rbl-session-file').onchange=async e=>{
      const f=e.target.files?.[0];
      if(f)await importRawSession(await f.text());
    };
    $('#rbl-browser-collapse').onclick=()=>root.remove();
    return;
  }

  const m=mission();
  const total=data.missions.length;
  const done=progress.done.filter(Boolean).length;

  root.innerHTML=`<header>
      <div class="rbl-brand"><img src="${MILO_AVATAR}" alt="MILO"><div><b>${t('title')}</b><span>${t('assistant')}</span><em>${t('setup',{name:data.name||'RBL',n:progress.currentIndex+1,total})} · v${VERSION}</em></div></div>
      <button id="rbl-browser-collapse">−</button>
    </header>
    <div class="rbl-body">
      <div class="rbl-projectbar">
        <label>${t('project')}</label>
        <select id="rbl-project-select">
          ${sessions.map(x=>`<option value="${esc(x.key)}" ${x.key===activeProjectKey?'selected':''}>${esc(x.name)} · ${x.missionCount}</option>`).join('')}
        </select>
        <div class="rbl-project-actions">
          <button id="rbl-refresh-session"><span class="ico">↻</span><span>${t('refreshShort')}</span></button>
          <button id="rbl-load-session"><span class="ico">📂</span><span>${t('loadShort')}</span></button>
          <button id="rbl-change-session"><span class="ico">🔁</span><span>${t('changeShort')}</span></button>
        </div>
      </div>
      <div class="rbl-milo-lore"><b>MILO</b><span>${t('lore')}</span></div>

      <div class="rbl-progress">${t('status',{done,total})}</div>
      <select id="rbl-mission-select">
        ${data.missions.map((x,i)=>`<option value="${i}" ${i===progress.currentIndex?'selected':''}>${progress.done[i]?'✓ ':progress.prepared[i]?'• ':''}${String(i+1).padStart(2,'0')} · ${esc(x.title||'Mission')}</option>`).join('')}
      </select>

      <div class="rbl-mission"><b>${String(progress.currentIndex+1).padStart(2,'0')} · ${esc(m?.title||'Mission')}</b><span>${(m?.portals||[]).length} portals</span></div>
      <button class="primary" id="rbl-browser-import">${progress.prepared[progress.currentIndex]?'↻ ':''}${t('import')}</button>
      <button class="submitted" id="rbl-browser-submitted">${t('submitted')}</button>

      <div class="rbl-nav">
        <button id="rbl-browser-prev" ${progress.currentIndex<=0?'disabled':''}>‹ ${t('prev')}</button>
        <button id="rbl-browser-next" ${progress.currentIndex>=total-1?'disabled':''}>${t('next')} ›</button>
      </div>

      <details class="rbl-manage">
        <summary>⚙️ ${t('fileTools')} · ${t('loadedProjects',{n:sessions.length})}</summary>
        <button id="rbl-forget-session" class="danger">🧹 ${t('forgetShort')}</button>
        <button id="rbl-delete-session" class="danger">🗑 ${t('deleteShort')}</button>
        <button id="rbl-clear-sessions" class="danger">⚠️ ${t('clearAll')}</button>
      </details>

      <div id="rbl-browser-status" class="rbl-status">${t('ready')} · ${t('login')}</div>
      <small>${t('notSubmit')}</small>
      <input type="file" id="rbl-session-file" accept=".json,.rblpub.json,application/json" hidden>
    </div>`;

  $('#rbl-project-select').onchange=e=>switchProject(e.target.value);
  $('#rbl-refresh-session').onclick=()=>refreshFromRblFile(true);
  $('#rbl-load-session').onclick=()=>pickSessionAdvanced();
  $('#rbl-change-session').onclick=changeSessionFile;
  $('#rbl-forget-session').onclick=forgetSessionFile;
  $('#rbl-delete-session').onclick=deleteCurrentProject;
  $('#rbl-clear-sessions').onclick=clearAllProjects;
  $('#rbl-session-file').onchange=async e=>{
    const f=e.target.files?.[0];
    if(f)await importRawSession(await f.text());
  };

  $('#rbl-browser-import').onclick=importMission;
  $('#rbl-browser-submitted').onclick=submittedNext;
  $('#rbl-browser-prev').onclick=previousMission;
  $('#rbl-browser-next').onclick=nextMission;
  $('#rbl-mission-select').onchange=e=>setCurrent(+e.target.value);

  $('#rbl-browser-collapse').onclick=()=>{
    root.classList.toggle('mini');
    if(root.classList.contains('mini')){
      root.innerHTML='<button id="rbl-browser-open">🧪 MILO</button>';
      $('#rbl-browser-open').onclick=()=>{
        root.classList.remove('mini');
        render();
      };
    }
  };
}

const style=document.createElement('style');
style.textContent=`
#rbl-browser-publisher{position:fixed;z-index:2147483000;right:8px;bottom:10px;width:min(350px,calc(100vw - 16px));max-height:calc(100vh - 20px);font-family:system-ui,-apple-system,sans-serif;color:#f2fff7;background:#07150e;border:1px solid #31ed83;border-radius:15px;box-shadow:0 16px 45px #000b;overflow:auto}
#rbl-browser-publisher *{box-sizing:border-box}
#rbl-browser-publisher header{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:8px;background:#0b1d13;padding:8px 10px;border-bottom:1px solid #225d3d}
#rbl-browser-publisher header>div{flex:1;min-width:0}
.rbl-brand{display:flex;align-items:center;gap:8px}.rbl-brand>img{width:38px;height:38px;object-fit:cover;border-radius:11px;border:1px solid #31ed83;box-shadow:0 0 14px #31ed8344}.rbl-brand>div{min-width:0}.rbl-brand em{display:block;font-style:normal;font-size:8px;color:#6f9980;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#rbl-browser-publisher header b{display:block;font-size:14px}
#rbl-browser-publisher header span{display:block;font-size:9px;color:#8db59a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#rbl-browser-publisher header button{width:31px;height:31px;border:0;border-radius:9px;background:#143421;color:#fff;font-size:20px}
.rbl-body{padding:9px}
.rbl-empty{padding:10px;border:1px solid #28553c;border-radius:10px;background:#0d2518}
.rbl-empty b,.rbl-empty span{display:block}.rbl-empty span{margin-top:4px;font-size:9px;color:#91aa99;line-height:1.4}
.rbl-projectbar{display:grid;grid-template-columns:1fr;gap:6px;align-items:end;margin-bottom:8px}
.rbl-projectbar label{grid-column:1/-1;font-size:8px;color:#8dac98;text-transform:uppercase;font-weight:800}
.rbl-projectbar select{min-width:0}
.rbl-project-actions{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}.rbl-project-actions button{min-height:42px;padding:5px 4px;border-radius:8px;border:1px solid #285d3e;background:#10291b;color:#fff;font-size:8px;font-weight:800;line-height:1.1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}.rbl-project-actions .ico{font-size:15px;line-height:1}
.rbl-project-actions button.danger,.rbl-body>button.danger,.rbl-manage button.danger{border-color:#743c35;color:#ffb7aa;background:#2c1512}
.rbl-milo-lore{display:flex;gap:7px;align-items:flex-start;margin:7px 0;padding:7px 8px;border:1px solid #1f5739;border-radius:9px;background:#0a2115}.rbl-milo-lore b{font-size:8px;color:#31ed83;letter-spacing:.08em}.rbl-milo-lore span{font-size:8px;line-height:1.35;color:#99b9a4}.rbl-progress{font-size:9px;color:#31ed83;font-weight:800;margin-bottom:6px}
.rbl-body select{width:100%;min-height:36px;border-radius:8px;border:1px solid #25563a;background:#0d2518;color:#fff;padding:4px}
.rbl-mission{padding:7px;border:1px solid #25563a;border-radius:9px;background:#0d2518;margin-top:7px}
.rbl-mission b{display:block;font-size:11px}.rbl-mission span{font-size:8px;color:#8db59a}
.rbl-body>button,.rbl-nav button,.rbl-manage button{width:100%;min-height:39px;margin-top:6px;border:1px solid #285d3e;border-radius:9px;background:#10291b;color:#fff;font-weight:800;font-size:10px}
.rbl-body>button.primary{background:#31ed83;color:#06140b;border-color:#31ed83}
.rbl-body>button.submitted{background:#173c28;border-color:#31ed83}
.rbl-nav{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.rbl-nav button:disabled,.rbl-body>button:disabled{opacity:.35}
.rbl-manage{margin-top:8px;border-top:1px solid #183725;padding-top:6px}
.rbl-manage summary{font-size:9px;color:#8dac98;cursor:pointer}
.rbl-status{margin-top:7px;background:#0d2518;border-radius:8px;padding:7px;color:#a7c9b3;font-size:9px;line-height:1.35}
.rbl-status.ok{color:#8ff2b8}.rbl-status.warn{color:#ffd27c;background:#2b210c}.rbl-status.error{color:#ffb1a0;background:#2b120e}
.rbl-body small{display:block;text-align:center;color:#688575;font-size:8px;margin-top:6px}
#rbl-browser-publisher.mini{width:auto;background:transparent;border:0;box-shadow:none;overflow:visible}
#rbl-browser-publisher.mini>button{border:1px solid #31ed83;border-radius:999px;background:#07150e;color:#31ed83;padding:9px 12px;font-weight:900}
.rbl-confirm{position:fixed;inset:0;z-index:2147483646;background:#000b;display:grid;place-items:center;padding:20px;font-family:system-ui}
.rbl-confirm>div{max-width:360px;width:100%;background:#07150e;color:white;border:1px solid #31ed83;border-radius:15px;padding:14px}
.rbl-confirm section{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.rbl-confirm button{min-height:40px;border-radius:9px;border:1px solid #27583c;background:#10291b;color:#fff;font-weight:800}
.rbl-confirm button:last-child{background:#31ed83;color:#06140b}
`;
document.head.appendChild(style);

async function migrateLegacy(){
  try{
    const raw=localStorage.getItem(LEGACY_SESSION);
    if(raw){
      const parsed=JSON.parse(raw);
      if(parsed?.format==='redacted-bannerlab-publisher-session'&&Array.isArray(parsed.missions)&&parsed.missions.length){
        await rememberSession(parsed,{select:false});
      }
    }
  }catch(e){console.warn('[RBL legacy session]',e)}
  localStorage.removeItem(LEGACY_SESSION);
  localStorage.removeItem(LEGACY_PROGRESS);
}

async function bootstrap(){
  await migrateLegacy();

  // Direct hand-off from the Chrome bookmarklet when RBL has just prepared
  // RBL_Current_Session.rblpub.json.
  if(window.__RBL_SESSION_RAW__){
    const raw=window.__RBL_SESSION_RAW__;
    try{delete window.__RBL_SESSION_RAW__}catch{}
    await importRawSession(raw);
  }else{
    await refreshSessionList();
  }

  render();
  if(data?.missions?.length){
    status(t('resumed',{name:data.name||'RBL',n:progress.currentIndex+1,total:data.missions.length}),'ok');
  }
  retryPendingBannergressSync().catch(e=>console.warn('[RBL pending sync]',e));

  // If a stored file handle is already permanently granted, silently refresh
  // it. If Chrome requires a new user gesture, the "Actualiser depuis RBL"
  // button remains available instead.
  try{
    const handle=await storeGet(HANDLE_STORE,'currentSessionFile');
    if(handle&&await handle.queryPermission?.({mode:'read'})==='granted'){
      const file=await handle.getFile();
      lastSessionFileModified=Number(file.lastModified)||0;
      const raw=await file.text();
      await importRawSession(raw);
    }
  }catch(e){console.warn('[RBL auto refresh]',e)}
}

window.__RBL_PUBLISHER_041__={
  render,
  refresh:async()=>{
    await refreshSessionList();
    render();
  }
};

await bootstrap();
setInterval(()=>{
  if(!document.getElementById('rbl-browser-publisher'))render();
},1200);

// RBL always overwrites the same current-session file. Keeping this MAT tab
// alive means Google auth is not restarted, while new banners still arrive.
setInterval(pollCurrentSessionFile,2000);

})();