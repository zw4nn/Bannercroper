// ==UserScript==
// @name         Redacted BannerLab IITC Companion
// @id           redacted-bannerlab-bridge
// @category     Mission
// @version      0.6.3
// @description  Companion BannerLab : édition de missions, passphrases, tracés multi-missions, stats piétonnes et synchronisation Android.
// @match        https://intel.ingress.com/*
// @grant        none
// ==/UserScript==
(function(){
  function wrapper(){
    if(typeof window.plugin!=='function') window.plugin=function(){};

    const KEY='redactedBannerLabCompanionV3';
    const OLD_KEY='redactedBannerLabCompanionV2';
    const STATS_KEY='redactedBannerLabStatsV1';
    const VALHALLA='https://valhalla1.openstreetmap.de/route';
    const MAX_ROUTE_POINTS=45;
    const ICON='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAABMWlDQ1BJQ0MgUHJvZmlsZQAAeJx9kD9Lw0AYxn+Wgv8H0dEhYxelKqiDLlUMOkmsYHVK07QV2hqSlFJw8wv4IQRnR0Ho6uAgCK76EcTBtT5JkGSJ7/He/e65h7t7XyhMoSiWodsLfcusGGe1c2PykwmNOGwn8MgPuX7eE+/byj++vJhuuIGj9UvZ8PW4rqyKl1oJtyOuJ3wd8SD0QvFtxH7V2hPfiUutDNcz7Hh+5H8R73Q7fSf9N3Nu7/RE64FymX0uCfDoYDPE4JgNzaZ2XfqE4oEcIW1RgKWTiqiKL0dPShNXTNS/5ImbD9gdjcfjp1Q7GsHDFsw8plppGxZm4TmjpT31bN+OpaKy0GzC9z3M12DxVfdc/DUypzYjrs3kSqOl2lwph/qvw6ponTJrbP4CGDVN6D4vo30AADTOSURBVHjaRbxJjGxZet/3O/ecO9+YM3LON9XQNXR1dVV1s5ukJFIkNRiyAMm2ZBqwIYGGN4Y3XnvTW2+9MeCFlloINgzLG2s0KJLi5Fazu9k1vjlfvhxijrjzPYMX8UgtEpHIRCzixne+7z99R/wnf/szN181+JOP+OjgjHdty+dNxeDeR7T5l9zOfsZ2uyP0feomJEynTMaHHAjJw/4hzra82l4y2804vTigtSUvX92yXldMx+dUnaC0gtHRW/ie5q0HF4wmx7zaxajxByg/pmtzqs0ton8K8RjnHM45YP8qAGctbx36PDpQdLrD9ywCi+dZmqajrhsQ4AmBcw5rHZ12dBZAIKWPkhInBBbFtvWptaDWgrJzWASdtgQSHh0oToY+eW2RSqofxb0T2k6T5Cve8lNCbXgvyqjyV9zkl3Rakxfgi4iR8pB1Qds2COkw9RpDQd6VCGWpTMur6w2dETz84AeEowcIP+LD976FEjWP//w/ELiYxh8iygVi/g3V6iXF5jV+OkYlIxyAEAhACIEQAicETefYVoa8tpSNpenAlwJnDdYYnHMYazHGoLWh7TRtpzHG4KxDKkk/CcgiRRx4jFJFawTbxoFzHPYVbx8FXEx8sliyLgyqqiripuXw4dukZUHgBLrcYhczTr0B1/GUqi9Yr1vWd3Penkw5CPr84uZLNtUlSRQilMVTjq9f3LDcNCgv5PzRxxy+9zcYHV7Q83YMAs3nP8/ZHT7Cqh7r1z/DFHfEThANRhxOLyBOaPCQwuEAJwSeEOyfmKOzjkVpCX0PiUB6UGhHqhTKWYQzWKsxBjrroe2+kpyzODSy6yhqSaEhDEKORoqx0eQ1jHoB33u7xzCVWAuh8hj2Y1SvN0DYgt38a6rBIZ93c+Zyw4u7OaEBN8oIwpjAu+Hg8Jzd4IJXV49Z5SvGyZTSWby2IUkijPU4Co45HR3xfL3mdrbg5OQCUVxzeT2nsT7R5B7z3Yqrp3+I7mr6fsqDXsTF6QHqOOPJTtNogScF0lP4zRbR1eh0gudJHB4Wi3WgrWBZGkop8WVE5Bpk29KoAI2PdoCwOOEASdl6uNbDCcFZ7BEpwTTzSIOAk4OE80mI1o6q1QgBg1SiBof3qcs1YdjnOs953VQo4GAgydsKN2s48s4JVMr4W38TsmPU+ob300/Y+JK1yNnMXnK3mhMEEfcuHlBsc7rdDcsv/jnPumeYcsa8qFDZEcVmi85v0G3FarMjVyX2Vcgv/frf5t6DIb0N3G4cr7cOz2m6659i6pzRw++TKp8Gj0YGdCokpCWq1mAc2vMo0VgnqZMeVuwrYV+L4AGRhFDCYV9y78An8gWB8hilHqEybPMKa6FuDTvn8JVEhXGfqtxSFSW6bSi2C7CGKDnAD0Ou6orZ7Q2jkynTOMFWLzgb9fludM4X1Y6r5edoIyh3hsF4TCt9brsF04MJtHf8+Z/8nwhAqTGnxzHlbs5qdUmrG8LAZzAYcXx4Thb3ULrlvOcTuYbNqqRcXJK/+kNM23EWRKTpgLprcUFCmo5ITEu+eIntWrSuUWffRo/uYfAQbv9g2Ld4RongYqzIQkmoLIE0gEUJkB6YzpBrAc7hHDgnqDuNioXg0bu/zE/+7N9wtbhmOj3lKMnQueHV9o7p+ccsF1dkWrB++VNMc01lDGFlKP2EpqgoG81gMGIYJlw/e0orc5Jpj7yq2VQVQRjQa1vS1RaH5XXX4UuF1g1xmqKU4o9+9//h/OQhQdZjtV4yu76hym9pd3OEc6xehixUwqzNgY6T7Ajf77E0JXVX43k+4yAGP8CzGpwHOKxzJL7gwYHi4WEIQFF1GGOQnkeWBPi+ous0TWcomw6tNVIqhJCoX56c8q2Dd5g8XPO/7/4VMZpfOn5EIBX/pv4pdy9/znq3JY1TytUNyiv5+PA+s2LGT29fsMpzrHDQs8y9Bcs8pzYl1rMoJdnsKuIGkoHmprmjbBuM6dDWIhB0bctseUOxmXN39QVCCHbFlqosiMOIIIyR0me1vsSqDOdLis1zbosF3lu/QjR6H19FBP0jVP8YJxwWDyEcke8w1jGIBUd9RRZJ2s4iU5/QD3Fvmr+xhqbrKKuGsu6oGw2AlB7q55c/Y7W8YrbZ8u70jPcOz5n4Kdo47mcDQn/OLtfcXT8lDSWBstzFd3jCZ1UXbOuCYZZQd447U9NhcCrgZrbl4vyck5Mx+XyFJwXXzYxdXjFJUqwA60ccDA8R1rJez1iu54BDeIJh1iMJYrrWsO4qNi4nDhPSNEJ3DW4QEZ++jZ+MMOEILx6C8LDWkIYwCB2Zb/EAX4G1hvmmIlQe/SzAV5KialisC4qypu0M2jiMsbRvYII1BjVO+9x5G7Rq+MHBQ47SEZ0VPFlc0QnNex99i49/0Off/d6/Z7lY0ctiXu1m+CogixIGwQAPS2kMCEdnNIPBkF52zvnZCaF0vDY1uzyncZbzi0cMZESlayZnD8AYbq9ekhclbWvJyxrheyg/wGqLri2dtRhnac2KUS9jOjri/OhbiHJDIgMYnFF7AosgkIL7B5LDxFHVBhC0xvFq2WKt42Qg6bRGG0tZNRR1izGWumnRWmOsxRpHpw1ad6iBTrC+xR/GVJXh+XJGbTo60TI6nhDEIVmi+Pb7j/jTn3xJ0xmqxqCURxKEZC4BKzmNfGpb8rTOCehQtqTNb6h0gx+GeH5Ez49Jh0fMF3c403A/jEn9kKdff85qsybwfRCCoqiZO0fgK7rWcDI85rA3YFmssdZwEB/wMDvj5e0lrtjimhLdPyKZ3CPxHT3R4jnQzf6162DRBgjPoxdqqsZSdw5nDaGvCHxB22qMsVhn0cZirUXgIV2if/T1zSWz3YrWGW7yJVflnLPhlIKK2+0dSinGowlt17Le5aw3OY22FHXFutzSuRYhBQZD2g9569EpWhfsthua1hJlB7z13qdo63j89c9Yzq8RTrPbzNnmc5o2Z1eUWCfwJCglOJ2ccjQ5wRce0/4RB/0D7g0mDCOf+W7NercjbzZ0XU1brQnxSGyLzG/pdhvqpmVzc8Xm5oa2k+RejBOghMWX4BB40iPwJR7Q6j32CfyAKIrI0oQsTVAvNzPAMd+uma93JFmfo3TCclewrNbIvk9edlzdXHJ7t6KXpHRtR13XBL7Cw0PLhmi4nwpFayjLHGscu7JjNJ7gqwAfRWxjEhEwODgEa3l9+xoVvhnEwuIJxWFvjDOaadZHyAiiPlEUY2iIgwjtAspuhS5ekalTQgJ6OiG+u6FZ3NFkA3QUYp9XbKsVZnzM5HDAIPOx1hCFPpO+pGoNi8KxKQRSGKTz8KREeh5KSpRS+yo6Px04IQXWOsqyZTwaM+0PuZdO8YcZs3qGH3jMFmseP74kTUIGvRRjzR6ACYkfSN46PmTa73G1nVOUHbqxHKQ9BsMBDTAcT/jeb5xTFR3//l8+Yzmfo5whDQOscwziMRWOfpCgu5ZFsaRuNKEM6Q/6aFHiS2jaDl0bfBmxqCrieMx704f0lIdTMX46xgmBOjjk6P33mJweMRpmDBOPrnOEviCQ0GjLtoabraWoNZFo8GyDNgZrLbo11G2LcgJMtx/JOMtuu2UQZyyVwOxKbm9mFOUaqRRhqPCVIg1TOr3HC03XUTQNX+kbutOOqtVsNhVJHJMkMc42zBYbjj8UvPtbQ8LmgKY+4V/8HzccTcd4jaVsW9KsxzDoMdUBJtK8Wt0yz9ckYYj2G+quwVjLwegYrTpWuzWeDGi6knU1p/QN803OID7g/N3vMXz0PsloyDC0TEKNLyW26zAdNNYDBJkPF0OoOoU2HlYr2ralbjpwHqEA1TSaOA4RzjEaZrS1oZ8OSFXM7fyatq0Jw4BeGuNXirJuuFutOZlMGA1j5vkGxB4zVF1LECikUog2pGkdIoC60jgcu2XB1WzOd379Abb9mD/6f/8cJT2KtmVx84JJMkCoPlfbBcvNDq0tq25H2dTgIIlipAhBSQJRoGSIAS4Xr+n3ErwgREYBsWngyS94+nXBM9XxzocfMTi9R607uroE1xFGGZ5KkRJ83ydQAQTqDeF1pElI4Euk8MyPHA4caG3AQS/JGKQZVV2xzFdMRiMmvSHrfIdxUFY1SiqQjkZrotAHHE3XMooyPpm8x3f7b1PtWpZ6SzL2GI57hCPLptlQVwV+Jqg3ktcv1jgjkNbQCz2MMHx5c0ndNkjhYXE4J6i6DmMtTZUTCEcsQ4qypGkrQk/hOYFyAmcaYjTF6jV3r56SVwXje++g4gHL1Zxf/Pz3+bOf/AF50eL5GZ0R5GVLpzs84ei0peksoS/Jkgh1fnBI3lRs8pLQV/SSBKTlbvOavCkIA4lw0Gq7F6PsHlssdhs2VU6gFNuiwGGJYp+/dvGAvz76hKVeEXxU88lHQw5OIvAcdVORRgF//OMvmd8VXNx7l95lRqwUwvpsNwV325fIMOAgzijKAiEVaZSw2q7QRrMpCyLp0c8OKDzohz3eP/uAMEixwuFEw7R3yNPbS26KBX/tV3+V4/MLrID14oqf/dkfUpUFeb7FDwMu7n8H7TzqVlPVHcLz0MaCs3gC5H/7vb/1o4PhkLt6jfA8jDFY19KLe4yzIU5orHVs8g3KV3upQewJHQ4624IQhKFP4oVI6XH8aUz4W1se/npMbwidrghDsLrEFyFZ2icMAzZ5wTvfvc8nvz7m/kcZxlc8/6bEF4o4Dmm6hq5r8YVHGvoEStEPY85GB4yzIWnsczo6puk0vh+xyJesijmegrxp8fyQ45Mp0leUdclXX/0JV5dP95/D7HC2wVoIwhSpIlpt6PReXOs6Q1Vr5NvT6Y8qaeg8S1k3COFIoph3z99Feh6v5q/Y1TnbqqRpO4ZZRhqH5FVJlkTcnxyhfIHnBO+8e8yv/MMThp+1BKlDGYFu9tOuKiuKoiXrhaSRz6if8e47Z0wmAUIY4h58+Okx9x5MaO408+stKIfHfsJKCaNswLuHDxilfVZlwdHgiFEy5eXiFda0zHd33O1uWZZz1sUa08Bqdo0RhsY2XL78Gdv1HZttCQjiMOTo9G2mR/eJooRAeUSBTxr7GAtFo5Enp4MflV1D3XYUZUkUBWhtKaqa096Qpmt4Z3zOD86+xfVujRWW4SDhcDLib337B/zDt/86ta45+37Cf/qP3+LiYY9EJXhA07YYo5FCAh69fooQHk2jCUNF5Eu2yw1PvrliMBgSRxI/zXnn42PaTvDsq1uatsNhsdbxRnSmbBsiP2OU9rjbLvlm9hiJprMdt9sVrTas8w3gcdQ/oq23fPHNn7Jc3FE3Busiev0x211Of3jB+PCcIIhRShJFPlkSoKSHQyDH4+xH1+s5nekwzgIWHBRNzd12iY/PZ+N3eJQdse4K5t2WKPb5jYef8Un2Nl6/Y/qblo9/44AsCXHWYkxD07Y4BEYbnLM0dYX0BG3b0XYt1jiqqiHLUobjAXHskEIzu8vZ7DZ88OkJo4M+z75ckkYhnTYYa+locEqzqysu5ze8WLxiU65JwoBBcsCq2iI8R6hCAumjvAjpfGgMm7xgW5Z0ukJ6muvXN7y6fEWWJQwGQ3w/QGBp6hrlWXqxQiaZ+JE2jnWeIwPF2emU/iBCKsEurxmrHtiOu+2a8XhEehhRbWvOggHTT0H++orhPQ+hBWVdsZzP0MYiPIVzFpyh6VqapsPzJEVeo5Sk0waLxZgKYzq6tqMsO/70D59RFrBdN7z/8THn9w746R9f0umORMUEviJLQ+brJfPNjkGa8fDwnPvjtxgmU+62c2bbJRKJLwVlXdI0mklvjKcM1isII0nT1qxWFYfTE959dI5Hha53SFPRlmucLrFtjnz30dGPiqpFCp9R3CcNEsZHAy4m53wy+Bad7vhm+xrrgfVhXmzI+oqP/4sh0x8K4kBR5yWN3rPhujZ4gCcFRrc457Fa5GS9BG0sUnmoQNA2NcZq2kpTlYZXLzbMbkrG0zH9UYrpYLnIufdwRJJGPP9qQaAUnTFo29JLInwZM8lGnAxOyMIBq3LN5eKSttN02tKZDiFgW+X4KmAymHByeEgQB1RdSVt3aLuXVvP1LYu7l5g2R7mO3fqO66unyDjxfyQ8wenwkLPeFFF59EzG33n0S3x3/IhVnfOHV59zWy55dn3N/Q8G/PZ//z733u4Tipi2a1G+pOs6nGXfc6REeB6B7+GcwDqPJPVpm466rijzGtNZukbj+wHLWc1209LrZ1zcH7FZ7UhTnzxvefL4lh/+2iN07fj6qxtqU1O3LZ7w9iJXo7ldz3l695zbzR1t2xEHCb2ojzZuTz6DiEDF3D98xHH/nE1esGuXZJnP7G7JN4+f0nUtbVtT1xW3d9c8ffwLbi8fI2XAj456Y0LpY7Bo3ZF5Eaeqx83ihl1T8jy/Zlnk/PA3z/lH/8OnTA5irLYYOqwzOGspywpnzBsfS+IHiqap8JXCGItUgsVsS77rCPwQP1A451gvKxbzmuFBQhT7lEXD7HbLZlVyc71lvqhYrXPe++iYq2c7dpsaX0l2dUXdaIwzrIsNrWkQQqC8AIRDSUGtG1rdEvsJZV3hrCNRKZt6y836huUqZ7utCHyfNEno9/qMR31mt69ZXb8mEg714ekjfCTDMENqj51Xsm63/PH1V/gOStcgBDy4d8hv/853SVNJnheoQFJtC6yzJEmGNgbpOToNVmvqqqJrNYu2REhJvoPlvCaMY4I4YH67ocg7rIYwDLi53GHclunhkNeXObtdR5QE7LYNT79ZIpzHB5+dU+YdpnEgPLSwe/btKVrd0pkdgQzwlUDIEOsMre5oTUPm93lxe8m8mGPDlsV6x2ZdEviSo8MEY0pubm5RoqMudsS+xEmDPJ2MfnS1mrHIt4S+QnuaVbNl21W0nuW2W7HalvyNv/8tvverp+T5llY3GF2zXu1wbl8ts9sFZd7SaUuaZXz15TVJL2Ozrsl6PaqyI4gCRuOU9WqHkJKjozHFruP19Zbb65JeL2W7rnjxbIV10LaWpjYEgU9ZtkSZjy8CduuKwWBPhbZ5Sac1XVfTGY3nCTyh8FBoY2m7DmcN/XiIQ/J88YKob5hOUsbjhOPjHkoJtBZk6RjPUwhrGI8mZJMx6s+vnu698DeN9Ww4pjINh8lkP1Zrx2/93ff4O//wXVbLBcZ2KKmoypKs18c6qKuKqtDESUh/mHL5ckaSJkyPMuqqZTxNiCKJsRpPOqyxJIlicTdHGzg/n3B0KKjbjlfPd6hAYq2l0w4/UFhnaVvDbL4h7accTPq0Xbf/0fVev/E9rAVrHW2rwUo8qeglPTzfkrdbxskJUZVQN5rhsE8UO5R0vHy5xrqEB99+xOHBlEjBeDTBOYuapH2iIMBTkrNsRCYjIhWSxBHLbc7J+z3+3u+8jdYFm82WrBdRVQ1t40j7jmrX4L2xitMsxDlNkXecXwxZrTbkecF6uWS7qRj0M6rK4nmSy+crDo5HjCLINx2bTUWedwCkacRqUewpgbV0bYdVFk95EFmmhwOePL6k6VrSOKKf9rE4Wt3QtB0SgcXg4dHr94hiCTpChYaekwwmfR5cvM+r169ZrOZkw2x/ZN0K7UK0iQjDkMPpAerD8wfUbcOi3XFTLYijkEZ1/MnlF4wOevw3v/NXKKstTW3A24PIsqyJopC2aREeVFWHHwZYHOvZCuVLnLBI4ZFkAbPbNVL65EVJVbRIGVBVmsCHP/r9F0ymfdrOsVlVXF9uOTkbItWeF5oOPM9DOUsU+jRdhRABbdPhSYiC8E0TrrEGtNZ4SqLU3tJRQmK1oBcmHEwHKEp644jxJGa2UshGMRhFKOVRmQWXdytcl1Aaj9qBWpuC2XbFtq7wlcT4exYqpOM3//5DpieCq1cbuq4hywL8yCe1MU1dEkUhu+2O/rBHGBnapgV8duuKtq44POnRNYa71znDccZ6UdM0hrotyTcNv/dvn5L1Y7briqo0dK3j0bempKmPChR3NxuElCgp8JXHdlPgeY40cpwcHuz1nU7TtNV+SjmHMIowCpn0h9RN95dfrGBL4hROgaZjUV0yPILh8cFezxICKdUb26lHkIUsdxvUts5pjeHi6JSq2jPp5WbDZ3/1Pr/6W6fc3szxA0XXNWjjKIqc1V1DXuSMpz086RNEitVii0BRN5qT8wGPv7xjcuRR5i1F4dHWFSrw8KTPYBjwzS92VGXL0YnH46+WHJ312a4aHJrF3OEJhbMC4RxOWrrWIaUHAkSoSZKIOEhYF3f4StIfhbSdRm86tO2wWE4e9pGRBCkQ1iOaGOIgQCoPK1pkIJCet4cm3t6CFkhas2O9+gW2sKgsjglEwLQ/YiEMVad558MT/s4/eJfNZk2nG5q6Ik5TgjDEGANyb+UcHo/YrkqefXXF5dMdRWFIeiHn91sOjhNG4xRnHFcvd3Stz/3TAfm24uuf37FeFrz13hSsw8OjzDscsF7VZFnIbldhrSCO/L2s0ml6g5i6aslVxWze0FlNmiTsioq8LPHk3jYy2lE2NRfjAePTBDyB0RaEA7w98X0zmIyzOLf/l8UipY/wLC0btDN442zAeJTx/PYli92WWtf84DdOGB45ZndrhJBUdYtz0HUdcRwCjjgWXF+uaBrL3W1LnA0wLkGbkKePd1R1w3ZT8PLpHYt5yXJR4XBsNxVXVwWToxQhHHfXOWWh6WqLs/vAVFu16EYThB5124EFqy3FrsYaQ6dbVApWGiyGKA04v38BDoJA4YRDSEkY9ojCMUZbjNtb3sZorN37XwiH2AsECCzWdGhTo02L8xx+z0c1m5badax2Ozpj+c6nD/jg4wl3t3cMBhnKdwg84iQiCODu9R1Pv55zfu8QpRzbdc5mbTiYBnz03QOMrVitBFkv4+42Z7ezDEYZ62XDelkSJzFZL6I/iFmvaoxzHJ6lGG0Jwv1It05gHVRFixMSJQ0OUNLDdAZPWMaHA5pakvT6nJ2c8t573+bf/dt/x263I02HjA8OeOfhZ4RxwNP8J2gDnpQYbWjaFt9X2I49bpICayVaG4wzb5JtICWottMgPZz1mBxk/NbffYuo1/HV4xsmkzEyUIwPenRtzde/uMFaj/c+esTV5YrxIMBZyfK25p//0z9lNErAwflbfT75geDt9w958WTN1fM1KoiYTPtURc3xSUYQSe6ud4SxR1cbdOfwfUe5M6AknhIo5SGlJO2FmM7sj4mDum6ZDBRHB/cIopTIl1xdLpge3efkVGIR3Lt3wSff/oyqrunFMWEokVKyWK65vr3l/vkp0vP29pUA4e3zRNbt5Rm3L2dUeBwRxSkfHsZ8/zdGvPORJN+1JEmMtZa21lR5w2yWc3A45cGjQ26vVxwdjQiCAOFpFjc1//i//h9xCP7JP/lf6dqCX/tb7/Dq5R2zu4Kj8zH9YcTrV3OaqgNP8PzJmt2uo+d8qnKfL5zd1CSJwjpHGHsIPHbrlsVdzvQw+4+9w4Y4ofn0009Yrmpu727QRcPDR2+TpQkvL18RRSFJlqICn7qLCUKBkj5Nqzkn4uNvfUgY7KEJvIn5CUB4OBzOOhwO9e5b9/j6+Uve/zTjO9/P6LqGstpxcDTEGkuxrXBCcXZ+TJwofv5nXxGFGXES0LSWqjTMrzvuHszYbCo6G/FLv3bCaGL4D39SYLTi4Chms2q4eZXTH4U0VUechiRZxKtnW5wT+JHHcJrS1Zqq1FA5RpOYrnUgJDJQ5MuC/jDGGMdidUd1uuXk5CFxmnBzfYsQewsnS1N8pfgL4fzHP/8Jl9ePaWtIVcZb994hv3+OjfZ2tBBiH1p4E7oybo/IHaBuFit2zYqzd2L8yNC1Fuc0dbXHGGEUM+ln6E7z6sUNSqdM3QO6/grhO7782Rw/VPzrf/HPaTvL4XHEo2+NwUk++u45o/EG6UdkaUwUSZ4+XnFzlZOlAYenPY7OMtarhjgWSOkwat9/4sTHVx5xLNmsO9aLkije/00bh+/7lPWWh/f6vP32BT/92edsNju0Njx8eJ/RqIezDk9I1jPD1ZOWh2fHfPzOI0ajCV1T0XkOpRQIgduf3jcR5H3CzOFQ882c3/x7x4yOPKqqZLXagpNsNzmDccbd7QwZKFbzLZt1x9tvD5mOFdcbzdNv7nj+fMHJg4j1rOX97x3xn//OB4RBSRAmDAYZ/UGPxXJHU+WchWOaWvLWw1Mclqwf8uSbGWWxZX7bMZqEeFIRpz7WaHTn2Kw0V5dbzu/3GE8S8rzDmIZgmnI9f8633/urnBwdUbxV8c2T53TaMB4NiaKAtq1xODabiizO+OVPv8PF+THWOrQx5GW1T5J5Yp8tcmCdw9i/aNIS9d0fHnJ40uC02qeqlMdqtkOqAKMdVeFo647VoiDJMharHZevr7h8suTZk4JPfvAeFw+mfPjJhm9/fMb4ELQOiKMIYwynp2OODsdIz+BJn48/M/T6iq7WhJHPz34y5l/rJ1w8GPKzn14xvymw2nJwlJIXmvldCU5QlobloiTthwgBu12F580py71DcXx8xNXrO/KiYDhImS/WVPmW0SDBcx2+knzz4oonlzc4BA6FNg6LQ/kK6cn/aF9FEUkckkQBajAxhFFIkvhsdxs8T6JNS5JlrG4r6hqefnPDcq45OUswXc0XP1/jhxGf/vCCT75/gdYdj956SBQ4ttsd1gkWswUH0wPSJARb0zYNu6JlOBjQVpauMdy8XtI0O/6z//I97j0c8skPTikLQ+A5BoOI6+sd/9vVj3n2eEfS+owOUpxz5FUHDvq9lLrRWOfI0hRPKtabHavVis1qxdMnj5kME7IIIhmzWC73KTLrUdSaqjU4t9ejhPDwfcVkNGB6MMTzPOqmQSkp6bqGujZEccxuvSUMUnabjtWqpCod09M+VblCdyFVteODjx/y7genSA+yJCEIFEJYimKH1aD8gMPjI8JAspjPKPJ2DxkA00EofZ48e81209G0HnU5Z3o0YjIKMOaao6Me8+trxgcZv/073+N/+Z//DaM3hLLIK/zAw8PSdRptOnTXksQRYSCZL5Z89fkv8KXl1auXfPHlDpyg0Za61UjpE0UpCA/j9oBSGQ/PkwjkXpmwljD09zHgg8OAzqxADNhtdmyWmsPjKT//8QvSXkYYw2gU89bbMXXTce/hmEdv32M0yGjqjq5twFnquiNLMoRXoPyAsthyd7OhKjQH0wllWaO1wZMxs/mKVy9WfPjx2yjfp9iafVV1sFlZrl9dc/1qx/SoJUkT/qvf+ZTXr5aURY0zliD2aRpL3TZ0usFpjScso35C11S8vtlydtBn3Itoq4Kq1bRtS9MYoshHKUkYhjStxji3zyRgAMdmkyMEexmln6KsKOhlB7RtB3gEQcJmXiB9SdZPkEqhdce9R0MCFZBkGb6UtE1NHEeEsWKzWgH7kgzCgM1qy9dfPOPg8JgoCVivV0jlE6mYstpQNZYHD8/pZRHL9Y4g9PdB7xiawlGXivF4TBr1ePb4lgcPJ3z/B5/xz/7pH9M0NTKQ+L5E647Vas2zFy+4ODtiNEyZL27506fPGfazfYXpDucsnpQM+gOyLMMYQ13XOMS+8sKIvGowxrAtCuarDY+fXeH7Psr3YvatqiPf1qxXGil8JtM+g1GMEA1ZekAv6+Mpx/RggG4NQeiz2iwIwpjlak1VtYxGQ0IdsNuWJGmP7W6HwHB4MsETliCQdLWmaxr6wxFNY9huKupqQ1nWGN2Aldy/N+Lq5YLtuubqcgd4jCdDLu4dUO5qqrIjyRRxFLNcLvn93/1XfPitB5yennP/aIiupvuNICXwVYQnBEEYkg0GCOGz25V73cjz6FqNY/9w9ha3QymJ5wmCwEd9/Nbf5CdP/i+qtmKzqHn2uOSjTy+YHg3QnWE8POTi4oiiqsD5NKVGOI9VtSQvK7rVhqbR1GWLN3bcvJ6B80jSiOvXc84fHJOkPjevFhyfhWyWO16/2HDxUFHmHVVpuP9gys3rNWEYcjBNuHyxoqkNB9OE8bjPYJCiW00vC0j7CYvZDqsN1gq0dthWM7+7o8xzDocpnB9gjEHgqNqO5bYET5Ile0VCKYV7I/yVdYNrGhACa/fiXJqm+9UpC+qo94CD3glPr7+mqjRdA+vljgcPDukf9tjlOc+fXxKnMZPRhPVyg5KS2jQYo8nziteXC5S/H5ueVGxXJVk/ZDwe0ssUVy9es9toAl/y8tmC7dowmjTc3aw4Pp+w25W8eLHk7GxCsyx58WLF9DAh60XEseTRowG9LMA5QRzHJEn1JstUc3n5hN2q5Oun+9UoATRNi5KCMAwIwxBtBdtdhfDW9HoZre7wfR/P8/A8D20tkVJ4UlK+2T2TngQEKgmOSZMxN9czfL/Pp798CFbStIaqrJH4iNCn18soii27co33pgS3m5zlYkPWG6ICi7UGnGW7LoiTkLQXsrhdoPyQIAjwVUrWb3j2zQ3jg5woDYhjn+urDUka07Qdm3XDyUnGYNAjzxt++CvvsFnOuXu9Jc9bJgcpTVPQtQbrHC9fvNon2YTAA5TycG4/4cAx6PUYjYakSUxZ1ZRVg+9L0jSl7fQ+YGEdbbM/cn7okybh3oyoO1SSnPBo8hmu/peEWcDR0YAg8hkNxsxnd0gv4HgyZbte0HYdQRhw+eKWri3xlE9daU7OfJTvsVrMmN1sibMJdaPRXY2zhnc+uODV8xlNVxOGjk9/+SFN1SCFwxhNr+8jMBR5S1V1fPLZ+V6g9xxPvrqmyEuqqmU5b/krv/kWxychf/QHj0mSjDT1cLZm0E/BOvKqRhvwfclw0KPf6yGEQngKpSRxtIcLwvOo6oaqbhgM+iRRhHOOwaBHL03Z5gVt26HKrqOXvMN/9w/+J37/z/5vqmpLGMZEoSLLYqaHR3R1Q13WNG/8pyhKKYqa2A8YT1KKomDQ79HUju1O0x/6CBxhHBCGPXa7HZ2usdpS5hVNXaG1h9EebetQAcxua/wgwto9AVaB4eXza4T0ub0rGPYT2rak2DQ8+2aOQNBL+nz3O+csZltGvZi6qri6XdBpw/HhhOnBlCTNmK9z5osN49GANImYLTegIQxDpFejPI/RoE8QSJI4pmk6emnC8eEEJbAUjWLUe4/P3t/y5c3vYYDVaouvQoqi3HOlxRzrQuq6o65qjk9PiGKP2d2C1XKL7jqkDLh4MKWtaqYnQ5JY0LYV87sdbQOLu5y28nj2zYokS7n3YLrPIltJUbQc9QY8+XrG6VmfXj/ipz+5YTLt8Rt/+wN+/O9fsts0XL8qKfKGRxfv0w/usXYbhmlIFEjQinE/xfMUZ6cnqCBhV9ZobTHGssurfcB8U6KdQykfTyo2eYWQa3wlgQ0IwfnJIQeTMWqzeA34vFg8peA1ddeyWGyI4oCT4xM8LEZbDo9PWMy3tI2maxuUcjjbEUYxcWRRKmaz3rHb5ATK5+R8hJSC7SpndrPi3qMLrl4UXL8sOD49BOEYjFLKXcd6UzA+6PH461s225bZrCCIY9arhu//8AzrNkgpmUz7lFXLO2/fI/PfZzsr2CyWFGWBkpKmM3uJ1lO0r27xVIDWbo+SBdze3gECoXySLCMKQvq9lE5rAhUQxyFSSqyD9a6ienaFEtbhPImUHbt8jjaGwWCAtQ03d9ccHUypin1UJY5C6qoiTfuUhWU4lgS+YzBMGU16pGnAMooIAonVLYvbai9ldj6L2x3LeYXuJFXZkmQ+P//JK3QniGLJcBRzem9E0xr6/YjLpwvO7/cYHYS8fLplt22xzrBc7JiO3iLqjfni7iVXs7056SvvTeylYzo5QHqKIAiIQ5+201hjiOOINE33eg977jXo91BSUpQNnvCYjAakScpivaPpOpTpWqLBCNUFWKnfjNEInKYoCqLIo6wq1qsVXSd48WTLaDIh6Rnubgo63bJZFuB1OGPoDxRGC26u1+SbCiEE89mO29ct/cGAl0+uWS5q6kpzfDZgMu3TNQ3zuw2nDyb8yq/d5/Hnd3z5ixmnFwlV2XF3U/Py2Y4wCUhixXh4Sl60PLu8Q3cC4SfUuqGsNHHkMxyOmE4n7PKa5WZH2zRYp8nSlDRNKesObaHVhqJsCcOQsu4oy4rZakeSxnstyVMoKX2Es6zza15dvSKMfJq2wLT7c3tzfUec9InShJunc5Iso2t9PCHwfVjMSoIwZLMs0J1G+VDmjg8+esg321ckaUYYdJy/e8RuXYHzcM7jO5+ds91UNHVDmiYY6+Mr2Kw2JJlCScXVyx1lYWgbgQx96towHiWsdtd8+fmSuq5Qb3wt5zwePTjnu99+F6V8tnnFbb2mqgrqqiIMfaT0WCw3FLUmCEM8z6MoGrrO4HlibxnVjqbTeH+Bg4Tn8JAk0RCHwTqPyA9wStDWHnXtKKsN08MeQlxxfHbEw/vvsljf0bQ74lS9wR4G6RS+CgiiiuVyjrH7I3Xv4b4fffWLaybTlLZxlEVHvx/xe//2BSD47vemzG5XnJwN+fGf3LFZVrz34RFNbdCmYTiMwXoUec3l1WPqOqTMK6QET3hIJfjwnTN+9bMPabXl6YvX7PKcUEFR+nveGCZs8xVpEhFFIXXbMRqkb45VzGaXs1zvKKuWumkJowAVRgOqbs43V79LGCl8JZnPlkjPYzbLSbMM6wxRHAI+q9WOd99b07cgq4TVYkMYOqTXkW9q2lpyfDFgNd+yvCuoyhIpFZ4n6Q8StPbotOFP/+Al7390wNFpnzRVfPPFijC2vPvBCaaznN8boHyPVy83+3hK21Hkht22IYwD3nnrHh/cexs/kITBHjGfHk6J4oRmV6AdHB5MGPUTHJZXN2u0gXtnPkkSE0cxQjg++ehbXJwdoZSkbbr9qsViy+1shScl4vrJH7uqXvP59b/g6d0fslnnNLUhy1IuL5cEUcx4EtHphtFwSlNbmnqJ9ATWObpOcnpvyosnV7StZTjOsLrk859ek6YZ2JjNqubB22M+/8kdL54V9Pop/YFHWVq0cfz93/6A3/3XL/ji5685Oe2RJDH5rqWqDGXRcnavTxj63N7kCM/j+HTAP/q7/5i3zh/uNR3h7Y+HfSOZvtkgNLolDjyMsbx8vaTRmixJ3sSJPQLf5+zkcB9ab1qUlEhfgRNvzEVQOM2uu6KyM/r9Hk3b4HkheQGet4/EnZ6NsaUgiDwmk4TZrKGpSzbzHYiYsihQviPNYuZ3G7rOEScp241l9npFvjWUBXz5iy2bjSYbJDx6d0JVwfXVhq+/uEYpy+n5mDST1FWLEB7FriLNJHEUUFYaXwpG45C/+umv8OD8bZbbHXXd4AcK3w/eXE2xF/STOEZrQddUgMfFxQlJHP8lB3MOhLe/r6MoazwBXhiiO0PbtvtEifJRQgaMeu/x7azHT7/+ZyixQkYKR0evN8BYRxA5+sMh69WKxcyQJD5ad1y+2IIzxEnM069uGQwHjCYJTWNJYokUHZdPShazDikbhCe5/zBDt5rb1yVvv3eILyV/9ieXTI8S7t2PyfoBzx/nbNf1m94myHc10vdxDqwTvHj9ii+fPqEuOsq64vT4iMFAYo2jblrWuyXb3Y40UhyNewRxShwEtNqyzXcEgc96s8UBy9WO1WbH0cGIJIkxes/xwjDYI+m6LgnTA0R3RZaMmI4tu/YWz2+wneRwPObzL75gdldy7+EpwgnqsmU1r2kaQZom7PKGdz+4x+Mv57RtywffGfDVn8+5eVWjfJ9H76Z4QiCVYH7X4nmWr75Y8PSbFUJ4VGVH15V88Ys5Zxd9QLFZ16Spj2BvA5m2o2kNz5/NiNOEb148Y3ZTgXDMljsCf493wjCirGour65RnuPibEpnIAxTmnZ/2cnZ8QF38yV1u78A5eZ2AWKvcX/3w7d5/90HpHGE9CSqbg1BT5IGZyTxmNpsyIuQqtgiPIXWGuWFtG1D2ouIQ8lylpOmKb1BxeGxDxauXxXEoQIhef2yYrds6VqPzari4kFI1zqcFbS1YXQQUVV7CbRrGwajhPWyxfMUXeeoyoqDw4QwCqiKjrrW1G8kjLOLPqP+hBcv5tzebsnLkqazWGNRvqKfpfi+h+8JAiX48c++JggTzk5O0LpDSsXL17dIIVlvCoQH5ydT7hZr6qZ749rMGPRS8qJCxdmQrq1J4yGhiLl+tqYxHUHYB9Xx5PlT6sbieftd88ViiVQRaSCIIrVv1rblYBqwWSqEB1Hos1oYqsKRpjHLWUPaj3nxfEUQSLabCoCmtvT6iqY29IcBxbbBao2vBEXeEoSSuu4Iwv3y7WQSMR6Pmb0WbDa3RFGA50mapt6DOva7qEpJfCUY9mOiUJL1x9y/OKZuGvbXnIj94m4v4/HzSxbrjvOT6R4gI7i9W7Jeb8nLCrVfJJMYrYjCEcNxD21Tcj1js9nQVBrnJN/68Igk8bi7bglCQdKPODsbsVw01IWh2FW0nUO3jj9+cUtTQxRLXl/l9HoBm80OENx/NMQTBucktzc7Do9ivvlqg+4sYeCR6pDlvCTrS+5utljjkDIgiiVREmGBKFHMZzl5VSLEPqqnlL//XXesNyUuVUShZLsrqbVgk9dsdiVdt89yJ3GEH4QUVc2on3J+OiWK9rcxTMcDsjRGeB7KWqibkt5gzMXhr1Hnkln5JXZhWO4KQl/jREiR1zTNku225uJ+j7vbGl/BYlbT1qA7i1Iem3XDfNaRZRFVYTk6CZnfNZS5pTcMWa8KmlozPcxYL/eUwxpHU3ccHPbpWo0fSMrSMBgFWGPxA0EQKqqqBc8xGIeIV2Aah/L3frwQAq1bAuXwhWbc63Hv+IBndoF2il3RMFvlOOuw1mCXW4IwZNTLEAievryh7TqUUhyOhzRtQxQGqCiOWC5uyMoxoa84OHyPpIk4jt7Gb3/BNnhM2a559XSJEx69/oC6aUizEM9Z6rJlfguTw5imbrl8XpOkIUJCVWhUqPCkIEo9hqMArTvKsuWbL+coFTAchUSxQXgO3TmMNkgfmlxTFhC+eX/TaKLYYzjok+cObffyaxD4GOuQUv3lzQnaOB6/WvDyZoVB4USA8BSeJ/ZxZ0+B8FBKkdcN9c2C+XLLZNxn0Ev55tlLoiimbVvUfLFiuZzTGxwyuv8WvcGIxUyyreZMj5Y02+e0Xkc2MJSFx+FRj9ndEl/5LG92rOY18zuH70ui2KPTjii2DEchZd5xc1USRgE4Q9aTFIVGCI+udUQxrFY1xc7QdYbBUIBwTA5ihLBMpjHWeMxmBdq0HB6fc3sVMr+z+CrGOUfxxl/3lU8cx1jrqMriL0W5IIqwiL135u0ziVEUIqWPNvvcY6Akga/QFja7grv5Gj+oiUMfL037jMbHzGdXVGVOWRYIl+FFIcvyOXm1RneKfAtXz9c8+2aF9EJ+/uNrVitHr58RxyHGOqbHMYN+wOWLgjiL+f6vnvHt7x5SFR1aW25vSrrOYc1fZA4Vvb5PGAlOLzKkciQ9ge/vNwyFMKTZPtJ7etojjYYs54Km2d+UUDftfv9Md1R1TVlWNE2LM4aurhmlCb0kQhuNw6KkxFeKwPfx/f2uSBIFJFFI3bSAI4qCvbZU10zGAzxPeozO7+PilPliRpnnCBVTtAu0s1xMf4h0e4Vvt+64uSyQynHv4R4UWuuoq5btyvDkyw0qFFw8yLh8subZ1yuG45CDowgpBU1tWdw15NuO8TQCLGEoOToJ6Q88nDWMhjF1bTDG7RNgWuCcZTxOCYMeUbx3H7o3vnr8l7xK/uV9ZUIpgqxH3hm2Rb1XOz2FCmLCOCEIIoxxOCzL7Y7ZakPbaQK1l1yH/Ywg8LHOomxvhJSS83ePWF4/h6oiiR2+GfL+23+V3aqinc55+fKSwI9oasHTL3N0a7i52uFLn8EoYH7XIoRC+h4Hg5D/7w9uSNOG/tAnCAXjaUjXOPJdSxB5XNzv8fXnG/pDi/TADwwH04irlzXbbcFoHLFYtDjbcO/eiMnkgs26+Uu+5VxHFMQcjEYgoCgbjLF4HgjhYfFotMa5DoFA+QFhGDDspWRZQlO3bLc7Vrsc7SxhGHK33LLa5HjSI45D7p8d8f8Dd6JB/2WkCSQAAAAASUVORK5CYII=';

    const defaultLang=()=>{
      const l=String(navigator.language||'fr').toLowerCase();
      return l.startsWith('es')?'es':l.startsWith('en')?'en':'fr';
    };

    const plugin=window.plugin.redactedBannerLab={};

    plugin.state={
      v:6,pid:'',name:'BannerLab',c:0,n:0,ppm:6,
      lang:defaultLang(),
      m:[[]],
      direct:true,
      askAction:false,
      classic:true,
      carry:true,
      advanceMode:'ask',
      showOther:true,
      objective:'HACK_PORTAL',
      question:'',
      answer:'',
      panelWidth:300,
      panelX:null,
      panelY:null,
      passSkips:{}
    };

    plugin.collapsed=false;
    plugin.optionsOpen=false;
    plugin.statsOpen=false;
    plugin.statsLoading=false;
    plugin.pendingAdvance=false;
    plugin.selectedGuid=null;
    plugin.lastDirectGuid=null;
    plugin.lastDirectAt=0;

    const enc=obj=>{
      const b=new TextEncoder().encode(JSON.stringify(obj));
      let s='';
      for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));
      return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    };
    const dec=raw=>{
      let s=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');
      while(s.length%4)s+='=';
      const bin=atob(s),b=Uint8Array.from(bin,c=>c.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(b));
    };

    const normalizePortal=p=>{
      if(!Array.isArray(p))return null;
      return [
        String(p[0]||''),String(p[1]||'Portal'),
        Number(p[2])||0,Number(p[3])||0,String(p[4]||''),
        String(p[5]||'HACK_PORTAL'),String(p[6]||''),String(p[7]||'')
      ];
    };

    const normalize=st=>{
      st=st&&typeof st==='object'?st:{};
      const rawN=parseInt(st.n);
      const knownTotal=!!String(st.pid||'')&&Number.isFinite(rawN)&&rawN>=1;
      const n=knownTotal?rawN:0;
      const source=Array.isArray(st.m)?st.m:[];
      const count=Math.max(1,n||source.length||1);
      const missions=source.slice(0,count).map(m=>(Array.isArray(m)?m:[]).map(normalizePortal).filter(Boolean));
      while(missions.length<count)missions.push([]);

      return {
        v:6,
        pid:String(st.pid||''),
        name:String(st.name||'BannerLab'),
        c:Math.max(0,Math.min(missions.length-1,parseInt(st.c)||0)),
        n,
        ppm:Math.max(6,Math.min(24,parseInt(st.ppm)||6)),
        lang:['fr','en','es'].includes(st.lang)?st.lang:defaultLang(),
        m:missions,
        direct:st.direct!==false,
        askAction:st.askAction===true,
        classic:st.classic!==false,
        carry:st.carry!==false,
        advanceMode:['auto','ask'].includes(st.advanceMode)?st.advanceMode:'ask',
        showOther:st.showOther!==false,
        objective:String(st.objective||'HACK_PORTAL'),
        question:String(st.question||''),
        answer:String(st.answer||''),
        panelWidth:Math.max(230,Math.min(390,Number(st.panelWidth)||300)),
        panelX:Number.isFinite(Number(st.panelX))?Number(st.panelX):null,
        panelY:Number.isFinite(Number(st.panelY))?Number(st.panelY):null,
        passSkips:st.passSkips&&typeof st.passSkips==='object'?st.passSkips:{}
      };
    };

    const TXT={
      fr:{passIncomplete:'Passphrase incomplète',passIncompleteHelp:'Renseigne la question et la réponse avant de quitter ce portail.',completePass:'Compléter',continuePass:'Continuer',skipPass:'Passer tout de même',
        touch:'Touche un portail sur la carte',add:'Ajouter',save:'Enregistrer',remove:'Retirer',
        prev:'Mission',next:'Mission',sync:'Synchroniser BannerLab',options:'Options',hideOptions:'Masquer options',
        direct:'Ajout direct au toucher',askAction:'Demander l’action avant ajout',classic:'Mode bannière classique',
        classicHelp:'1er portail = passphrase · suivants = hack',carry:'Fin précédente → début suivante',
        progression:'Mission complète',askAdvance:'Me demander',autoAdvance:'Passer automatiquement',
        showOther:'Afficher les autres missions',language:'Langue',panelSize:'Largeur du panneau',resetPos:'Recentrer le panneau',
        stats:'Stats parfaitement inutiles',hideStats:'Masquer les stats',action:'Action',
        hack:'Hack',mod:'Installer un mod',capture:'Capture / upgrade',link:'Créer un lien',field:'Créer un champ',
        pass:'Passphrase',question:'Question',answer:'Réponse',missionNumberQuestion:'Quel est le numéro de la mission ?',mission:'Mission',linked:'Projet lié',unknown:'Total inconnu',
        selectedExisting:'Déjà dans cette mission · tu peux modifier son action',duplicateMission:'Déjà présent dans cette mission',
        added:'Portail ajouté',updated:'Action du portail mise à jour',empty:'Mission vide',
        complete:'Mission complète',stay:'Rester ici',goNext:'Mission suivante',chooseAction:'Choisis l’action puis Ajouter',
        carryAdded:'Passphrase de départ reprise automatiquement',routeUnavailable:'Routage piéton indisponible',
        portals:'portails',completeMissions:'missions complètes',activeWalk:'mission à pied',activeTime:'temps mission',
        bannerWalk:'fresque à pied',theoryTime:'temps théorique',transitions:'liaisons missions',civilization:'détour civilisation',
        sporty:'Mission la plus sportive',longestStep:'Étape la plus longue',avgMission:'Moyenne / mission',
        metersPortal:'Mètres / portail',portalsKm:'Portails / km',straight:'Vol d’oiseau cumulé',
        recalc:'Recalculer les stats piétonnes',estimate:'Estimation Valhalla + OpenStreetMap · pas un GPS',
        cached:'Résultat en cache',calculated:'Calculé maintenant',needTwo:'Ajoute au moins deux portails',
        otherRoutes:'Autres missions',activeRoute:'Mission sélectionnée'
      },
      en:{passIncomplete:'Incomplete passphrase',passIncompleteHelp:'Enter the question and answer before leaving this portal.',completePass:'Complete',continuePass:'Continue',skipPass:'Skip anyway',
        touch:'Tap a portal on the map',add:'Add',save:'Save',remove:'Remove',
        prev:'Mission',next:'Mission',sync:'Sync BannerLab',options:'Options',hideOptions:'Hide options',
        direct:'Direct add on tap',askAction:'Ask action before adding',classic:'Classic banner mode',
        classicHelp:'1st portal = passphrase · next = hack',carry:'Previous end → next start',
        progression:'When mission is complete',askAdvance:'Ask me',autoAdvance:'Advance automatically',
        showOther:'Show other missions',language:'Language',panelSize:'Panel width',resetPos:'Reset panel position',
        stats:'Perfectly useless stats',hideStats:'Hide stats',action:'Action',
        hack:'Hack',mod:'Install mod',capture:'Capture / upgrade',link:'Create link',field:'Create field',
        pass:'Passphrase',question:'Question',answer:'Answer',missionNumberQuestion:'What is the mission number?',mission:'Mission',linked:'Linked project',unknown:'Unknown total',
        selectedExisting:'Already in this mission · edit its action here',duplicateMission:'Already in this mission',
        added:'Portal added',updated:'Portal action updated',empty:'Empty mission',
        complete:'Mission complete',stay:'Stay here',goNext:'Next mission',chooseAction:'Choose the action, then Add',
        carryAdded:'Starting passphrase reused automatically',routeUnavailable:'Walking route unavailable',
        portals:'portals',completeMissions:'complete missions',activeWalk:'mission walking',activeTime:'mission time',
        bannerWalk:'banner walking',theoryTime:'theoretical time',transitions:'between missions',civilization:'civilization detour',
        sporty:'Longest mission',longestStep:'Longest leg',avgMission:'Average / mission',
        metersPortal:'Meters / portal',portalsKm:'Portals / km',straight:'Straight-line total',
        recalc:'Recalculate walking stats',estimate:'Valhalla + OpenStreetMap estimate · not GPS',
        cached:'Cached result',calculated:'Calculated now',needTwo:'Add at least two portals',
        otherRoutes:'Other missions',activeRoute:'Selected mission'
      },
      es:{passIncomplete:'Contraseña incompleta',passIncompleteHelp:'Rellena la pregunta y la respuesta antes de salir de este portal.',completePass:'Completar',continuePass:'Continuar',skipPass:'Continuar de todos modos',
        touch:'Toca un portal en el mapa',add:'Añadir',save:'Guardar',remove:'Quitar',
        prev:'Misión',next:'Misión',sync:'Sincronizar BannerLab',options:'Opciones',hideOptions:'Ocultar opciones',
        direct:'Añadir directamente al tocar',askAction:'Preguntar acción antes de añadir',classic:'Modo banner clásico',
        classicHelp:'1er portal = contraseña · siguientes = hack',carry:'Final anterior → inicio siguiente',
        progression:'Al completar la misión',askAdvance:'Preguntarme',autoAdvance:'Pasar automáticamente',
        showOther:'Mostrar otras misiones',language:'Idioma',panelSize:'Ancho del panel',resetPos:'Restablecer posición',
        stats:'Estadísticas perfectamente inútiles',hideStats:'Ocultar estadísticas',action:'Acción',
        hack:'Hackear',mod:'Instalar mod',capture:'Capturar / mejorar',link:'Crear enlace',field:'Crear campo',
        pass:'Contraseña',question:'Pregunta',answer:'Respuesta',missionNumberQuestion:'¿Cuál es el número de la misión?',mission:'Misión',linked:'Proyecto vinculado',unknown:'Total desconocido',
        selectedExisting:'Ya está en esta misión · puedes modificar su acción',duplicateMission:'Ya está en esta misión',
        added:'Portal añadido',updated:'Acción del portal actualizada',empty:'Misión vacía',
        complete:'Misión completa',stay:'Quedarme aquí',goNext:'Misión siguiente',chooseAction:'Elige la acción y pulsa Añadir',
        carryAdded:'Contraseña inicial reutilizada automáticamente',routeUnavailable:'Ruta peatonal no disponible',
        portals:'portales',completeMissions:'misiones completas',activeWalk:'misión a pie',activeTime:'tiempo misión',
        bannerWalk:'banner a pie',theoryTime:'tiempo teórico',transitions:'entre misiones',civilization:'desvío civilización',
        sporty:'Misión más larga',longestStep:'Tramo más largo',avgMission:'Media / misión',
        metersPortal:'Metros / portal',portalsKm:'Portales / km',straight:'Total en línea recta',
        recalc:'Recalcular estadísticas a pie',estimate:'Estimación Valhalla + OpenStreetMap · no es GPS',
        cached:'Resultado en caché',calculated:'Calculado ahora',needTwo:'Añade al menos dos portales',
        otherRoutes:'Otras misiones',activeRoute:'Misión seleccionada'
      }
    };

    plugin.t=k=>(TXT[plugin.state.lang]||TXT.fr)[k]||TXT.fr[k]||k;

    plugin.objectiveOptions=()=>[
      ['HACK_PORTAL',plugin.t('hack')],
      ['INSTALL_MOD',plugin.t('mod')],
      ['CAPTURE_PORTAL',plugin.t('capture')],
      ['CREATE_LINK',plugin.t('link')],
      ['CREATE_FIELD',plugin.t('field')],
      ['PASSPHRASE',plugin.t('pass')]
    ];

    plugin.defaultMissionPassphrase=()=>({type:'PASSPHRASE',question:plugin.t('missionNumberQuestion'),answer:String(plugin.state.c+1)});
    plugin.fillPassphraseDefaults=obj=>{
      if(!obj||String(obj.type||'')!=='PASSPHRASE')return obj;
      const d=plugin.defaultMissionPassphrase();
      if(!String(obj.question||'').trim())obj.question=d.question;
      if(!String(obj.answer||'').trim())obj.answer=d.answer;
      return obj;
    };

    plugin.save=()=>{
      try{localStorage.setItem(KEY,JSON.stringify(plugin.state))}catch(e){}
    };

    plugin.load=()=>{
      try{
        const u=new URL(location.href);
        const hm=u.hash.match(/(?:^|[?#&])rbl=([^&]+)/);
        const raw=u.searchParams.get('rbl')||(hm?.[1]?decodeURIComponent(hm[1]):'');
        if(raw){
          const incoming=normalize(dec(raw));
          // Une ouverture depuis BannerLab doit transmettre langue/projet/mission,
          // mais conserve les préférences UI locales lorsque l'app ne les connaît pas.
          const localRaw=localStorage.getItem(KEY);
          const local=localRaw?normalize(JSON.parse(localRaw)):null;
          if(local){
            incoming.panelWidth=local.panelWidth;
            incoming.panelX=local.panelX;
            incoming.panelY=local.panelY;
            incoming.showOther=local.showOther;
            incoming.advanceMode=local.advanceMode;
            incoming.classic=local.classic;
            incoming.askAction=local.askAction;
            incoming.direct=local.direct;
          }
          plugin.state=incoming;
          plugin.save();
          return;
        }
        const current=localStorage.getItem(KEY);
        if(current){
          plugin.state=normalize(JSON.parse(current));
          return;
        }
        const oldState=localStorage.getItem(OLD_KEY);
        if(oldState){
          plugin.state=normalize(JSON.parse(oldState));
          plugin.save();
        }
      }catch(e){console.warn('[BannerLab] load',e)}
    };

    plugin.ensureMission=i=>{
      while(plugin.state.m.length<=i)plugin.state.m.push([]);
      return plugin.state.m[i];
    };
    plugin.current=()=>plugin.ensureMission(plugin.state.c);
    plugin.hasKnownTotal=()=>plugin.state.n>0;
    plugin.totalLabel=()=>plugin.hasKnownTotal()?String(plugin.state.n):'?';
    plugin.totalMissionCount=()=>plugin.state.n||plugin.state.m.length||1;

    plugin.findMarker=guid=>guid&&window.portals&&window.portals[guid];

    plugin.currentIndexOfGuid=guid=>{
      if(!guid)return -1;
      return plugin.current().findIndex(p=>p&&p[0]===guid);
    };

    plugin.readObjectiveUi=()=>{
      const type=document.getElementById('rbl-objective')?.value||plugin.state.objective||'HACK_PORTAL';
      const question=document.getElementById('rbl-question')?.value||'';
      const answer=document.getElementById('rbl-answer')?.value||'';
      plugin.state.objective=type;
      plugin.state.question=question;
      plugin.state.answer=answer;
      return {type,question,answer};
    };

    plugin.portalFromMarker=(marker,obj)=>{
      if(!marker)return null;
      const d=marker.options&&marker.options.data||{};
      const ll=marker.getLatLng();
      const o=obj||plugin.readObjectiveUi();
      return [
        String(marker.options&&marker.options.guid||''),
        String(d.title||'Portal'),
        Number(ll.lat),Number(ll.lng),String(d.image||''),
        String(o.type||'HACK_PORTAL'),String(o.question||''),String(o.answer||'')
      ];
    };

    plugin.defaultObjectiveForNew=()=>{
      if(!plugin.state.classic)return plugin.readObjectiveUi();
      const arr=plugin.current();
      return arr.length===0
        ?plugin.defaultMissionPassphrase()
        :{type:'HACK_PORTAL',question:'',answer:''};
    };

    plugin.loadExistingObjective=idx=>{
      const p=plugin.current()[idx];
      if(!p)return;
      plugin.state.objective=String(p[5]||'HACK_PORTAL');
      plugin.state.question=String(p[6]||'');
      plugin.state.answer=String(p[7]||'');
      if(plugin.state.objective==='PASSPHRASE'){
        const d=plugin.defaultMissionPassphrase();
        if(!plugin.state.question.trim())plugin.state.question=d.question;
        if(!plugin.state.answer.trim())plugin.state.answer=d.answer;
      }
    };

    plugin.updateExistingObjective=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx<0)return false;
      const o=plugin.fillPassphraseDefaults(plugin.readObjectiveUi());
      const p=plugin.current()[idx];
      p[5]=o.type;p[6]=o.question;p[7]=o.answer;
      plugin.clearPassSkipIfComplete(plugin.state.c,idx);
      localStorage.removeItem(STATS_KEY);
      plugin.save();
      plugin.flash(plugin.t('updated'));
      return true;
    };


    plugin.passSkipKey=(mi,guid)=>String(mi)+':'+String(guid||'');
    plugin.isPassphraseIncomplete=(mi,idx)=>{
      const p=plugin.state.m?.[mi]?.[idx];
      if(!p||String(p[5]||'')!=='PASSPHRASE')return false;
      const key=plugin.passSkipKey(mi,p[0]);
      if(plugin.state.passSkips?.[key])return false;
      return !String(p[6]||'').trim()||!String(p[7]||'').trim();
    };
    plugin.selectedIncompletePassphrase=()=>{
      const guid=plugin.selectedGuid||window.selectedPortal;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx<0||!plugin.isPassphraseIncomplete(plugin.state.c,idx))return null;
      return {mi:plugin.state.c,idx,guid:String(guid)};
    };
    plugin.clearPassSkipIfComplete=(mi,idx)=>{
      const p=plugin.state.m?.[mi]?.[idx];
      if(!p)return;
      if(String(p[6]||'').trim()&&String(p[7]||'').trim()){
        delete plugin.state.passSkips[plugin.passSkipKey(mi,p[0])];
      }
    };
    plugin.beginPassGuard=(current,nextGuid)=>{
      plugin.passGuard={
        mi:current.mi,
        idx:current.idx,
        guid:current.guid,
        nextGuid:String(nextGuid||'')
      };
      plugin.selectedGuid=current.guid;
      plugin.loadExistingObjective(current.idx);
      plugin.render();
      setTimeout(()=>{
        const q=document.getElementById('rbl-question');
        const a=document.getElementById('rbl-answer');
        if(q&&!q.value.trim())q.focus();
        else if(a&&!a.value.trim())a.focus();
      },60);
    };
    plugin.resumePassGuard=(skip=false)=>{
      const g=plugin.passGuard;
      if(!g)return;
      const p=plugin.state.m?.[g.mi]?.[g.idx];
      if(!p){plugin.passGuard=null;plugin.render();return}

      if(!skip){
        const o=plugin.readObjectiveUi();
        p[5]=o.type;p[6]=o.question;p[7]=o.answer;
        if(!String(p[6]||'').trim()||!String(p[7]||'').trim()){
          plugin.flash(plugin.t('passIncompleteHelp'));
          plugin.render();
          return;
        }
        delete plugin.state.passSkips[plugin.passSkipKey(g.mi,p[0])];
      }else{
        plugin.state.passSkips[plugin.passSkipKey(g.mi,p[0])]=true;
      }

      const nextGuid=g.nextGuid;
      plugin.passGuard=null;
      plugin.save();

      if(nextGuid){
        plugin.selectedGuid=nextGuid;
        const marker=plugin.findMarker(nextGuid);
        plugin.render();
        if(plugin.state.direct&&marker){
          setTimeout(()=>plugin.addMarker(marker),40);
        }else{
          plugin.renderSelectedOnly();
        }
      }else{
        plugin.render();
      }
    };

    plugin.canCreateNext=()=>!plugin.hasKnownTotal()||plugin.state.c<plugin.state.n-1;

    plugin.carryIntoCurrent=()=>{
      if(!plugin.state.carry||plugin.state.c<=0)return false;
      const current=plugin.current();
      if(current.length)return false;
      const prev=plugin.state.m[plugin.state.c-1]||[];
      const p=prev[prev.length-1];
      if(!p)return false;
      const clone=[...p];
      if(plugin.state.classic){
        const d=plugin.defaultMissionPassphrase();
        clone[5]='PASSPHRASE';
        clone[6]=d.question;
        clone[7]=d.answer;
      }
      current.push(clone);
      plugin.selectedGuid=clone[0]||plugin.selectedGuid;
      plugin.state.objective=clone[5]||'PASSPHRASE';
      plugin.state.question=clone[6]||'';
      plugin.state.answer=clone[7]||'';
      return true;
    };

    plugin.goNext=(withCarry=true)=>{
      if(plugin.hasKnownTotal()&&plugin.state.c>=plugin.state.n-1)return false;
      plugin.state.c++;
      plugin.ensureMission(plugin.state.c);
      if(withCarry&&plugin.carryIntoCurrent())plugin.flash(plugin.t('carryAdded'));
      return true;
    };

    plugin.finishAdvance=()=>{
      plugin.pendingAdvance=false;
      if(!plugin.goNext(true)){
        plugin.flash(plugin.t('complete'));
        plugin.render();plugin.drawRoutes();return;
      }
      localStorage.removeItem(STATS_KEY);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.onMissionReachedTarget=()=>{
      if(plugin.state.advanceMode==='auto'){
        plugin.finishAdvance();
      }else{
        plugin.pendingAdvance=true;
        plugin.save();plugin.render();plugin.drawRoutes();
      }
    };

    plugin.addMarker=(marker,explicitObjective=null)=>{
      const guid=String(marker?.options?.guid||'');
      if(!guid)return;

      // Le même portail est autorisé dans d'autres missions.
      // Il est interdit uniquement deux fois dans la mission courante.
      const existing=plugin.currentIndexOfGuid(guid);
      if(existing>=0){
        plugin.selectedGuid=guid;
        plugin.loadExistingObjective(existing);
        plugin.render();
        plugin.flash(plugin.t('selectedExisting'));
        return;
      }

      if(plugin.pendingAdvance){
        plugin.flash(plugin.t('complete'));
        return;
      }

      const objective=plugin.fillPassphraseDefaults(explicitObjective||(
        plugin.state.askAction ? plugin.readObjectiveUi() : plugin.defaultObjectiveForNew()
      ));

      const p=plugin.portalFromMarker(marker,objective);
      if(!p)return;
      const arr=plugin.current();
      arr.push(p);
      plugin.selectedGuid=guid;
      plugin.loadExistingObjective(arr.length-1);

      localStorage.removeItem(STATS_KEY);
      plugin.save();
      plugin.drawRoutes();

      if(arr.length===plugin.state.ppm){
        plugin.onMissionReachedTarget();
      }else{
        plugin.render();
        plugin.flash(plugin.t('added'));
      }
    };

    plugin.addSelected=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const marker=plugin.findMarker(guid);
      if(!marker){plugin.flash(plugin.t('touch'));return}

      const idx=plugin.currentIndexOfGuid(guid);
      if(idx>=0){
        plugin.updateExistingObjective();
        plugin.render();plugin.drawRoutes();
        return;
      }
      plugin.addMarker(marker,plugin.readObjectiveUi());
    };

    plugin.removeSelectedOrLast=()=>{
      const arr=plugin.current();
      if(!arr.length){plugin.flash(plugin.t('empty'));return}
      const guid=window.selectedPortal||plugin.selectedGuid;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx>=0)arr.splice(idx,1);
      else arr.pop();
      plugin.pendingAdvance=false;
      localStorage.removeItem(STATS_KEY);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.prev=()=>{
      plugin.pendingAdvance=false;
      if(plugin.state.c>0)plugin.state.c--;
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.next=()=>{
      plugin.pendingAdvance=false;
      if(plugin.goNext(true)){
        plugin.save();plugin.render();plugin.drawRoutes();
      }
    };

    plugin.selectMission=i=>{
      const max=plugin.totalMissionCount()-1;
      i=Math.max(0,Math.min(max,Number(i)||0));
      plugin.pendingAdvance=false;
      plugin.state.c=i;
      plugin.ensureMission(i);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.sync=()=>{
      plugin.save();
      const payload={
        ...plugin.state,
        v:4,
        n:plugin.state.n||plugin.state.m.length,
        auto:plugin.state.advanceMode==='auto',
        pv:'0.6.3',
        direct:undefined,
        panelWidth:undefined,panelX:undefined,panelY:undefined,
        showOther:undefined,optionsOpen:undefined,
        passSkips:undefined
      };
      window.location.href='redactedbannerlab://sync?data='+encodeURIComponent(enc(payload));
    };

    plugin.flash=msg=>{
      const el=document.getElementById('rbl-flash');
      if(!el)return;
      el.textContent=msg;
      el.classList.add('show');
      clearTimeout(plugin.flashTimer);
      plugin.flashTimer=setTimeout(()=>el.classList.remove('show'),1800);
    };

    plugin.handlePortalSelected=data=>{
      const newGuid=String(data?.selectedPortalGuid||window.selectedPortal||'');
      const oldGuid=String(plugin.selectedGuid||'');

      // Avant de quitter un portail déjà enregistré en passphrase, on exige
      // question + réponse, sauf si l'utilisateur choisit explicitement de passer.
      if(oldGuid&&newGuid&&oldGuid!==newGuid&&!plugin.passGuard){
        const current=plugin.selectedIncompletePassphrase();
        if(current){
          plugin.beginPassGuard(current,newGuid);
          return;
        }
      }

      plugin.selectedGuid=newGuid||null;

      const idx=plugin.currentIndexOfGuid(newGuid);
      if(idx>=0){
        plugin.loadExistingObjective(idx);
        plugin.render();
        plugin.flash(plugin.t('selectedExisting'));
        return;
      }

      plugin.renderSelectedOnly();

      if(!plugin.state.direct||!newGuid)return;
      if(plugin.pendingAdvance){plugin.flash(plugin.t('complete'));return}
      if(plugin.state.askAction){plugin.flash(plugin.t('chooseAction'));return}

      const now=Date.now();
      if(plugin.lastDirectGuid===newGuid&&now-plugin.lastDirectAt<700)return;
      plugin.lastDirectGuid=newGuid;
      plugin.lastDirectAt=now;

      const marker=plugin.findMarker(newGuid);
      if(!marker)return;

      setTimeout(()=>{
        const currentMarker=plugin.findMarker(newGuid);
        if(currentMarker)plugin.addMarker(currentMarker);
      },40);
    };

    plugin.renderSelectedOnly=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const marker=plugin.findMarker(guid);
      const el=document.getElementById('rbl-selected');
      if(!el)return;
      if(!marker){el.textContent=plugin.t('touch');return}
      const d=marker.options&&marker.options.data||{};
      el.textContent=String(d.title||'Portal');
    };

    // ---------- TRAÇÉS MULTI-MISSIONS ----------
    plugin.drawRoutes=()=>{
      if(!window.L||!window.map)return;
      if(!plugin.routeLayer)plugin.routeLayer=L.layerGroup().addTo(map);
      plugin.routeLayer.clearLayers();

      const missions=plugin.state.m||[];
      const total=plugin.totalMissionCount();

      missions.forEach((arr,mi)=>{
        if(!Array.isArray(arr)||!arr.length)return;
        if(mi!==plugin.state.c&&!plugin.state.showOther)return;

        const pts=arr.map(p=>[Number(p[2]),Number(p[3])])
          .filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
        const active=mi===plugin.state.c;
        const color=active?'#36f08a':'#69a8c7';

        if(pts.length>1){
          L.polyline(pts,{
            color,
            weight:active?5:3,
            opacity:active?.9:.55,
            lineJoin:'round',
            dashArray:active?null:'7 7'
          }).addTo(plugin.routeLayer);
        }

        if(active){
          pts.forEach((ll,i)=>{
            const ic=L.divIcon({
              className:'rbl-route-dot',
              html:'<span class="active">'+(i+1)+'</span>',
              iconSize:[26,26],iconAnchor:[13,13]
            });
            L.marker(ll,{icon:ic,interactive:false}).addTo(plugin.routeLayer);
          });
        }else if(pts[0]){
          const ic=L.divIcon({
            className:'rbl-route-dot',
            html:'<span class="other">M'+(mi+1)+'</span>',
            iconSize:[28,22],iconAnchor:[14,11]
          });
          L.marker(pts[0],{icon:ic,interactive:false}).addTo(plugin.routeLayer);
        }
      });
    };

    // ---------- STATS ----------
    plugin.rad=x=>x*Math.PI/180;
    plugin.haversine=(a,b)=>{
      const lat1=Number(a?.[2]),lon1=Number(a?.[3]),lat2=Number(b?.[2]),lon2=Number(b?.[3]);
      if(![lat1,lon1,lat2,lon2].every(Number.isFinite))return 0;
      const dlat=plugin.rad(lat2-lat1),dlon=plugin.rad(lon2-lon1);
      const s=Math.sin(dlat/2)**2+
        Math.cos(plugin.rad(lat1))*Math.cos(plugin.rad(lat2))*Math.sin(dlon/2)**2;
      return 6371*2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
    };
    plugin.formatKm=km=>{
      km=Number(km)||0;
      return km<1?Math.round(km*1000)+' m':km.toFixed(km<10?2:1)+' km';
    };
    plugin.formatTime=sec=>{
      sec=Math.max(0,Math.round(Number(sec)||0));
      const h=Math.floor(sec/3600),m=Math.round((sec%3600)/60);
      return h?h+' h '+String(m).padStart(2,'0'):m+' min';
    };

    plugin.directStats=()=>{
      const missions=plugin.state.m||[];
      const perMission=missions.map((arr,mi)=>{
        let km=0,longest=0,longestNames=null;
        for(let i=0;i<arr.length-1;i++){
          const d=plugin.haversine(arr[i],arr[i+1]);
          km+=d;
          if(d>longest){longest=d;longestNames=[arr[i]?.[1]||'Portal',arr[i+1]?.[1]||'Portal']}
        }
        return {mi,km,portals:arr.length,longest,longestNames};
      });

      let total=0,transitions=0,longest=0,longestNames=null;
      perMission.forEach(x=>{
        total+=x.km;
        if(x.longest>longest){longest=x.longest;longestNames=x.longestNames}
      });

      for(let mi=0;mi<missions.length-1;mi++){
        const a=missions[mi]||[],b=missions[mi+1]||[];
        if(a.length&&b.length){
          const d=plugin.haversine(a[a.length-1],b[0]);
          transitions+=d;total+=d;
          if(d>longest){longest=d;longestNames=[a[a.length-1]?.[1]||'Portal',b[0]?.[1]||'Portal']}
        }
      }

      const portals=missions.reduce((n,m)=>n+m.length,0);
      const started=missions.filter(m=>m.length>0).length;
      const complete=missions.filter(m=>m.length>=plugin.state.ppm).length;
      return {perMission,total,transitions,portals,started,complete,longest,longestNames};
    };

    plugin.routeSignature=()=>{
      const pts=[];
      plugin.state.m.forEach((m,mi)=>m.forEach((p,pi)=>pts.push([mi,pi,p[0],p[2],p[3]])));
      return JSON.stringify(pts);
    };

    plugin.loadStatsCache=()=>{
      try{
        const obj=JSON.parse(localStorage.getItem(STATS_KEY)||'null');
        return obj&&obj.sig===plugin.routeSignature()?obj:null;
      }catch(e){return null}
    };

    plugin.saveStatsCache=walking=>{
      try{
        localStorage.setItem(STATS_KEY,JSON.stringify({
          sig:plugin.routeSignature(),walking,at:Date.now()
        }));
      }catch(e){}
    };

    plugin.flattenRoute=()=>{
      const flat=[];
      plugin.state.m.forEach((mission,mi)=>{
        mission.forEach((p,pi)=>flat.push({p,mi,pi}));
      });
      return flat;
    };

    plugin.fetchChunk=async chunk=>{
      const ctrl=new AbortController();
      const timer=setTimeout(()=>ctrl.abort(),18000);
      try{
        const lang=plugin.state.lang==='en'?'en-US':plugin.state.lang==='es'?'es-ES':'fr-FR';
        const body={
          locations:chunk.map(x=>({lat:Number(x.p[2]),lon:Number(x.p[3]),type:'break'})),
          costing:'pedestrian',
          units:'kilometers',
          directions_options:{units:'kilometers',language:lang}
        };
        const r=await fetch(VALHALLA,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify(body),
          signal:ctrl.signal
        });
        if(!r.ok)throw new Error('Valhalla HTTP '+r.status);
        const data=await r.json();
        const legs=data?.trip?.legs||[];
        if(legs.length!==Math.max(0,chunk.length-1))throw new Error('Incomplete route');
        return legs.map(leg=>({
          km:Number(leg?.summary?.length)||0,
          sec:Number(leg?.summary?.time)||0
        }));
      }finally{
        clearTimeout(timer);
      }
    };

    plugin.walkStats=async()=>{
      const direct=plugin.directStats();
      const flat=plugin.flattenRoute();
      if(flat.length<2)return {direct,walking:null,error:plugin.t('needTwo')};

      const cached=plugin.loadStatsCache();
      if(cached?.walking)return {direct,walking:cached.walking,cached:true};

      const missionKm=plugin.state.m.map(()=>0);
      const missionSec=plugin.state.m.map(()=>0);
      let totalKm=0,totalSec=0,transitionKm=0,transitionSec=0;
      let longestKm=0,longestNames=null,longestMission=null;

      let start=0;
      while(start<flat.length-1){
        const end=Math.min(flat.length,start+MAX_ROUTE_POINTS);
        const chunk=flat.slice(start,end);
        const legs=await plugin.fetchChunk(chunk);

        legs.forEach((leg,i)=>{
          const a=chunk[i],b=chunk[i+1];
          totalKm+=leg.km;totalSec+=leg.sec;
          if(a.mi===b.mi){
            missionKm[a.mi]=(missionKm[a.mi]||0)+leg.km;
            missionSec[a.mi]=(missionSec[a.mi]||0)+leg.sec;
          }else{
            transitionKm+=leg.km;transitionSec+=leg.sec;
          }
          if(leg.km>longestKm){
            longestKm=leg.km;
            longestNames=[a.p?.[1]||'Portal',b.p?.[1]||'Portal'];
          }
        });

        if(end>=flat.length)break;
        start=end-1;
        await new Promise(r=>setTimeout(r,160));
      }

      missionKm.forEach((km,mi)=>{
        if(km>0&&(!longestMission||km>longestMission.km)){
          longestMission={mi,km,sec:missionSec[mi]||0};
        }
      });

      const walking={
        totalKm,totalSec,transitionKm,transitionSec,
        missionKm,missionSec,longestKm,longestNames,longestMission
      };
      plugin.saveStatsCache(walking);
      return {direct,walking,cached:false};
    };

    plugin.renderStats=async(force=false)=>{
      const box=document.getElementById('rbl-stats-box');
      if(!box)return;
      const direct=plugin.directStats();
      const current=direct.perMission[plugin.state.c]||{km:0};
      const totalMissions=plugin.totalMissionCount();

      box.innerHTML=`
        <div class="rbl-stats-grid">
          <div><b>${direct.portals}</b><span>${plugin.t('portals')}</span></div>
          <div><b>${direct.complete}/${totalMissions}</b><span>${plugin.t('completeMissions')}</span></div>
          <div><b>${plugin.formatKm(current.km)}</b><span>${plugin.t('straight')}</span></div>
          <div><b>${plugin.formatKm(direct.total)}</b><span>${plugin.t('straight')}</span></div>
        </div>
        <div class="rbl-stats-note">…</div>`;

      if(plugin.statsLoading)return;
      plugin.statsLoading=true;

      try{
        if(force)localStorage.removeItem(STATS_KEY);
        const result=await plugin.walkStats();
        if(!result.walking){
          box.innerHTML+=`<div class="rbl-stats-error">${result.error}</div>`;
          return;
        }

        const w=result.walking;
        const activeKm=w.missionKm[plugin.state.c]||0;
        const activeSec=w.missionSec[plugin.state.c]||0;
        const detour=direct.total>0?((w.totalKm/direct.total)-1)*100:0;
        const walkPerPortal=direct.portals?w.totalKm/direct.portals:0;
        const portalsPerKm=w.totalKm?direct.portals/w.totalKm:0;
        const avgMission=direct.started?w.totalKm/direct.started:0;
        const lm=w.longestMission
          ?`M${w.longestMission.mi+1} · ${plugin.formatKm(w.longestMission.km)}`
          :'—';
        const ls=w.longestNames
          ?`${plugin.formatKm(w.longestKm)} · ${w.longestNames[0]} → ${w.longestNames[1]}`
          :'—';

        box.innerHTML=`
          <div class="rbl-stats-grid">
            <div><b>${direct.portals}</b><span>${plugin.t('portals')}</span></div>
            <div><b>${direct.complete}/${totalMissions}</b><span>${plugin.t('completeMissions')}</span></div>
            <div><b>${plugin.formatKm(activeKm)}</b><span>${plugin.t('activeWalk')}</span></div>
            <div><b>${plugin.formatTime(activeSec)}</b><span>${plugin.t('activeTime')}</span></div>
            <div><b>${plugin.formatKm(w.totalKm)}</b><span>${plugin.t('bannerWalk')}</span></div>
            <div><b>${plugin.formatTime(w.totalSec)}</b><span>${plugin.t('theoryTime')}</span></div>
            <div><b>${plugin.formatKm(w.transitionKm)}</b><span>${plugin.t('transitions')}</span></div>
            <div><b>+${Math.max(0,detour).toFixed(0)}%</b><span>${plugin.t('civilization')}</span></div>
          </div>
          <div class="rbl-fun">
            <div><span>${plugin.t('sporty')}</span><b>${lm}</b></div>
            <div><span>${plugin.t('longestStep')}</span><b>${ls}</b></div>
            <div><span>${plugin.t('avgMission')}</span><b>${plugin.formatKm(avgMission)}</b></div>
            <div><span>${plugin.t('metersPortal')}</span><b>${Math.round(walkPerPortal*1000)} m</b></div>
            <div><span>${plugin.t('portalsKm')}</span><b>${portalsPerKm.toFixed(1)}</b></div>
            <div><span>${plugin.t('straight')}</span><b>${plugin.formatKm(direct.total)}</b></div>
          </div>
          <div class="rbl-stats-note">${result.cached?plugin.t('cached'):plugin.t('calculated')} · ${plugin.t('estimate')}</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ ${plugin.t('recalc')}</button>`;
        document.getElementById('rbl-stats-refresh').onclick=()=>plugin.renderStats(true);
      }catch(e){
        console.warn('[BannerLab Stats]',e);
        box.innerHTML+=`
          <div class="rbl-stats-error">${plugin.t('routeUnavailable')}</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ ${plugin.t('recalc')}</button>`;
        document.getElementById('rbl-stats-refresh').onclick=()=>plugin.renderStats(true);
      }finally{
        plugin.statsLoading=false;
      }
    };

    // ---------- UI ----------
    plugin.applyGeometry=()=>{
      const root=document.getElementById('rbl-companion');
      if(!root)return;

      const safeTop=58;
      const side=6;
      const width=Math.max(230,Math.min(390,plugin.state.panelWidth||300));
      root.style.width=Math.min(width,window.innerWidth-side*2)+'px';
      root.style.maxHeight=Math.max(220,window.innerHeight-safeTop-10)+'px';

      if(plugin.state.panelX==null||plugin.state.panelY==null){
        root.style.left='auto';
        root.style.right='8px';
        root.style.bottom='auto';
        root.style.top=safeTop+'px';
        return;
      }

      const maxX=Math.max(side,window.innerWidth-root.offsetWidth-side);
      const maxY=Math.max(safeTop,window.innerHeight-root.offsetHeight-side);
      const x=Math.max(side,Math.min(maxX,plugin.state.panelX));
      const y=Math.max(safeTop,Math.min(maxY,plugin.state.panelY));

      plugin.state.panelX=x;
      plugin.state.panelY=y;
      root.style.right='auto';
      root.style.bottom='auto';
      root.style.left=x+'px';
      root.style.top=y+'px';
    };

    plugin.resetGeometry=()=>{
      const root=document.getElementById('rbl-companion');
      if(!root)return;
      const safeTop=58;
      plugin.applyGeometry();
      const w=root.offsetWidth;
      const h=root.offsetHeight;
      plugin.state.panelX=Math.max(6,(window.innerWidth-w)/2);
      plugin.state.panelY=Math.max(safeTop,safeTop+(window.innerHeight-safeTop-h)/2);
      plugin.save();
      plugin.applyGeometry();
    };

    plugin.installDrag=()=>{
      const root=document.getElementById('rbl-companion');
      const head=document.getElementById('rbl-drag');
      if(!root||!head)return;

      head.onpointerdown=e=>{
        if(e.target.closest('button'))return;
        const r=root.getBoundingClientRect();
        let sx=e.clientX,sy=e.clientY,ox=r.left,oy=r.top;
        head.setPointerCapture?.(e.pointerId);

        const move=ev=>{
          const x=ox+(ev.clientX-sx),y=oy+(ev.clientY-sy);
          const maxX=Math.max(4,window.innerWidth-root.offsetWidth-4);
          const safeTop=58;
          const maxY=Math.max(safeTop,window.innerHeight-root.offsetHeight-6);
          plugin.state.panelX=Math.max(4,Math.min(maxX,x));
          plugin.state.panelY=Math.max(safeTop,Math.min(maxY,y));
          plugin.applyGeometry();
        };

        const up=()=>{
          head.onpointermove=null;
          head.onpointerup=null;
          head.onpointercancel=null;
          plugin.save();
        };

        head.onpointermove=move;
        head.onpointerup=up;
        head.onpointercancel=up;
      };
    };

    plugin.missionChips=()=>{
      const count=plugin.totalMissionCount();
      let html='';
      for(let i=0;i<count;i++){
        const m=plugin.state.m[i]||[];
        const active=i===plugin.state.c;
        const complete=m.length>=plugin.state.ppm;
        html+=`<button class="rbl-mchip ${active?'active':''} ${complete?'complete':''}" data-mi="${i}">
          <b>${i+1}</b><span>${m.length}/${plugin.state.ppm}</span>
        </button>`;
      }
      return html;
    };

    plugin.optionsHtml=()=>{
      const langs=[
        ['fr','🇫🇷 Français'],
        ['en','🇬🇧 English'],
        ['es','🇪🇸 Español']
      ].map(([v,l])=>`<option value="${v}" ${plugin.state.lang===v?'selected':''}>${l}</option>`).join('');

      return `
        <div class="rbl-options">
          <label>${plugin.t('language')}
            <select id="rbl-lang">${langs}</select>
          </label>

          <label>${plugin.t('progression')}
            <select id="rbl-advance">
              <option value="ask" ${plugin.state.advanceMode==='ask'?'selected':''}>${plugin.t('askAdvance')}</option>
              <option value="auto" ${plugin.state.advanceMode==='auto'?'selected':''}>${plugin.t('autoAdvance')}</option>
            </select>
          </label>

          <label class="rbl-check"><input id="rbl-classic" type="checkbox" ${plugin.state.classic?'checked':''}>
            <span><b>${plugin.t('classic')}</b><small>${plugin.t('classicHelp')}</small></span>
          </label>

          <label class="rbl-check"><input id="rbl-carry" type="checkbox" ${plugin.state.carry?'checked':''}>
            <span>${plugin.t('carry')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-direct" type="checkbox" ${plugin.state.direct?'checked':''}>
            <span>${plugin.t('direct')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-ask-action" type="checkbox" ${plugin.state.askAction?'checked':''}>
            <span>${plugin.t('askAction')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-show-other" type="checkbox" ${plugin.state.showOther?'checked':''}>
            <span>${plugin.t('showOther')}</span>
          </label>

          <label>${plugin.t('panelSize')}
            <input id="rbl-width" type="range" min="230" max="390" step="10" value="${plugin.state.panelWidth}">
          </label>

          <button id="rbl-reset-pos" class="rbl-reset">${plugin.t('resetPos')}</button>

          <div class="rbl-legend">
            <span><i class="active"></i>${plugin.t('activeRoute')}</span>
            <span><i class="other"></i>${plugin.t('otherRoutes')}</span>
          </div>
        </div>`;
    };

    plugin.render=()=>{
      let root=document.getElementById('rbl-companion');
      if(!root){
        root=document.createElement('div');
        root.id='rbl-companion';
        document.body.appendChild(root);
      }

      const arr=plugin.current(),total=plugin.totalLabel();

      if(plugin.collapsed){
        root.innerHTML=`<button id="rbl-open" class="rbl-mini">
          <img src="${ICON}">
          <span>M${plugin.state.c+1}/${total} · ${arr.length}/${plugin.state.ppm}</span>
        </button>`;
        plugin.applyGeometry();
        document.getElementById('rbl-open').onclick=()=>{plugin.collapsed=false;plugin.render()};
        return;
      }

      const selected=window.selectedPortal||plugin.selectedGuid;
      const existingIdx=plugin.currentIndexOfGuid(selected);
      if(existingIdx>=0)plugin.loadExistingObjective(existingIdx);

      const actionOpts=plugin.objectiveOptions().map(([v,l])=>
        `<option value="${v}" ${plugin.state.objective===v?'selected':''}>${l}</option>`
      ).join('');
      const showPass=plugin.state.objective==='PASSPHRASE';

      root.innerHTML=`
        <div class="rbl-head" id="rbl-drag">
          <span class="rbl-grip">⋮⋮</span>
          <img src="${ICON}">
          <div>
            <b>BannerLab <small>0.6.3</small></b>
            <span>${plugin.t('mission')} ${plugin.state.c+1}/${total} · ${arr.length}/${plugin.state.ppm}</span>
          </div>
          <button id="rbl-collapse" title="Réduire">−</button>
        </div>

        <div class="rbl-missions">${plugin.missionChips()}</div>

        <div id="rbl-selected" class="rbl-selected">${plugin.t('touch')}</div>

        <div class="rbl-actionbox">
          <label>${plugin.t('action')}</label>
          <select id="rbl-objective">${actionOpts}</select>
          <div id="rbl-passbox" class="rbl-passbox" ${showPass?'':'hidden'}>
            <input id="rbl-question" placeholder="${plugin.t('question')}" value="${String(plugin.state.question||'').replaceAll('"','&quot;')}">
            <input id="rbl-answer" placeholder="${plugin.t('answer')}" value="${String(plugin.state.answer||'').replaceAll('"','&quot;')}">
          </div>
          ${existingIdx>=0?`<div class="rbl-existing">${plugin.t('selectedExisting')}</div>`:''}
        </div>

        ${plugin.passGuard?`
          <div class="rbl-passguard">
            <b>⚠ ${plugin.t('passIncomplete')}</b>
            <span>${plugin.t('passIncompleteHelp')}</span>
            <div>
              <button id="rbl-pass-continue">${plugin.t('continuePass')}</button>
              <button id="rbl-pass-skip">${plugin.t('skipPass')}</button>
            </div>
          </div>`:''}

        ${plugin.pendingAdvance?`
          <div class="rbl-advance">
            <b>${plugin.t('complete')} · ${arr.length}/${plugin.state.ppm}</b>
            <div>
              <button id="rbl-stay">${plugin.t('stay')}</button>
              <button id="rbl-go-next">${plugin.t('goNext')}</button>
            </div>
          </div>`:''}

        <div class="rbl-grid">
          <button id="rbl-add">${existingIdx>=0?'✓ '+plugin.t('save'):'＋ '+plugin.t('add')}</button>
          <button id="rbl-remove">↶ ${plugin.t('remove')}</button>
          <button id="rbl-prev" ${plugin.state.c===0?'disabled':''}>‹ ${plugin.t('prev')}</button>
          <button id="rbl-next" ${plugin.hasKnownTotal()&&plugin.state.c===plugin.state.n-1?'disabled':''}>${plugin.t('next')} ›</button>
        </div>

        <div class="rbl-tools">
          <button id="rbl-stats">📊 ${plugin.statsOpen?plugin.t('hideStats'):plugin.t('stats')}</button>
          <button id="rbl-options">⚙️ ${plugin.optionsOpen?plugin.t('hideOptions'):plugin.t('options')}</button>
        </div>

        ${plugin.statsOpen?'<div id="rbl-stats-box" class="rbl-stats-box"><div class="rbl-stats-note">…</div></div>':''}
        ${plugin.optionsOpen?plugin.optionsHtml():''}

        <button id="rbl-sync" class="rbl-sync">↩ ${plugin.t('sync')}</button>
        <div id="rbl-flash" class="rbl-flash"></div>`;

      plugin.applyGeometry();
      plugin.installDrag();

      document.getElementById('rbl-collapse').onclick=()=>{plugin.collapsed=true;plugin.render()};
      document.querySelectorAll('.rbl-mchip').forEach(b=>b.onclick=()=>plugin.selectMission(Number(b.dataset.mi)));

      const obj=document.getElementById('rbl-objective');
      const q=document.getElementById('rbl-question');
      const a=document.getElementById('rbl-answer');

      obj.onchange=e=>{
        plugin.state.objective=e.target.value;
        const isPass=e.target.value==='PASSPHRASE';
        document.getElementById('rbl-passbox').hidden=!isPass;
        if(isPass){
          const d=plugin.defaultMissionPassphrase();
          if(!String(plugin.state.question||'').trim())plugin.state.question=d.question;
          if(!String(plugin.state.answer||'').trim())plugin.state.answer=d.answer;
          q.value=plugin.state.question;a.value=plugin.state.answer;
        }
        plugin.save();
        if(plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid)>=0)plugin.updateExistingObjective();
      };
      q.oninput=e=>{
        plugin.state.question=e.target.value;plugin.save();
        const idx=plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid);
        if(idx>=0){
          const p=plugin.current()[idx];p[6]=e.target.value;plugin.clearPassSkipIfComplete(plugin.state.c,idx);plugin.save();
        }
      };
      a.oninput=e=>{
        plugin.state.answer=e.target.value;plugin.save();
        const idx=plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid);
        if(idx>=0){
          const p=plugin.current()[idx];p[7]=e.target.value;plugin.clearPassSkipIfComplete(plugin.state.c,idx);plugin.save();
        }
      };

      document.getElementById('rbl-add').onclick=plugin.addSelected;
      document.getElementById('rbl-remove').onclick=plugin.removeSelectedOrLast;

      if(plugin.passGuard){
        document.getElementById('rbl-pass-continue').onclick=()=>plugin.resumePassGuard(false);
        document.getElementById('rbl-pass-skip').onclick=()=>plugin.resumePassGuard(true);
      }
      document.getElementById('rbl-prev').onclick=plugin.prev;
      document.getElementById('rbl-next').onclick=plugin.next;

      if(plugin.pendingAdvance){
        document.getElementById('rbl-stay').onclick=()=>{
          plugin.pendingAdvance=false;plugin.save();plugin.render();
        };
        document.getElementById('rbl-go-next').onclick=plugin.finishAdvance;
      }

      document.getElementById('rbl-stats').onclick=()=>{
        plugin.statsOpen=!plugin.statsOpen;plugin.render();
      };
      document.getElementById('rbl-options').onclick=()=>{
        plugin.optionsOpen=!plugin.optionsOpen;plugin.render();
      };
      document.getElementById('rbl-sync').onclick=plugin.sync;

      if(plugin.optionsOpen){
        document.getElementById('rbl-lang').onchange=e=>{
          plugin.state.lang=e.target.value;plugin.save();plugin.render();
        };
        document.getElementById('rbl-advance').onchange=e=>{
          plugin.state.advanceMode=e.target.value;plugin.save();
        };
        document.getElementById('rbl-classic').onchange=e=>{
          plugin.state.classic=e.target.checked;plugin.save();plugin.render();
        };
        document.getElementById('rbl-carry').onchange=e=>{
          plugin.state.carry=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-direct').onchange=e=>{
          plugin.state.direct=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-ask-action').onchange=e=>{
          plugin.state.askAction=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-show-other').onchange=e=>{
          plugin.state.showOther=e.target.checked;plugin.save();plugin.drawRoutes();
        };
        document.getElementById('rbl-width').oninput=e=>{
          plugin.state.panelWidth=Number(e.target.value)||300;
          plugin.applyGeometry();
        };
        document.getElementById('rbl-width').onchange=plugin.save;
        document.getElementById('rbl-reset-pos').onclick=()=>{
          plugin.resetGeometry();
        };
      }

      plugin.renderSelectedOnly();
      if(plugin.statsOpen)setTimeout(()=>plugin.renderStats(false),0);
    };

    function setup(){
      const css=document.createElement('style');
      css.textContent=`
        #rbl-companion{
          position:fixed;z-index:10000;right:8px;bottom:66px;
          width:min(300px,calc(100vw - 12px));
          font-family:system-ui,-apple-system,sans-serif;color:#f3fff8;
          filter:drop-shadow(0 10px 28px rgba(0,0,0,.45));
          max-height:calc(100vh - 68px);overflow-y:auto;overflow-x:hidden;
          overscroll-behavior:contain;scrollbar-width:thin
        }
        #rbl-companion *{box-sizing:border-box}
        .rbl-head{
          display:flex;align-items:center;gap:8px;background:#07150e;
          border:1px solid rgba(54,240,138,.38);border-bottom:0;
          border-radius:15px 15px 0 0;padding:7px 8px;touch-action:none;
          position:sticky;top:0;z-index:4
        }
        .rbl-grip{font-weight:900;color:#5b806a;letter-spacing:-3px;cursor:move}
        .rbl-head img{width:36px;height:36px;border-radius:10px;object-fit:cover}
        .rbl-head div{min-width:0;flex:1}
        .rbl-head b{font-size:13px;display:block}.rbl-head b small{font-size:9px;color:#58f69d}
        .rbl-head span:not(.rbl-grip){font-size:10px;color:#9bb6a7}
        .rbl-head button{width:32px;height:32px;border:0;border-radius:9px;background:#10291b;color:#fff;font-size:20px}

        .rbl-missions{
          display:flex;gap:5px;overflow-x:auto;padding:5px 7px;background:#0b1d13;
          border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);
          scrollbar-width:none
        }
        .rbl-missions::-webkit-scrollbar{display:none}
        .rbl-mchip{flex:0 0 auto;min-width:42px;border:1px solid #294a37;border-radius:8px;background:#10271b;color:#a9c1b2;padding:4px 6px}
        .rbl-mchip b{display:block;font-size:11px}.rbl-mchip span{font-size:8px}
        .rbl-mchip.complete{border-color:#4f86a2;color:#a9d8ef;background:#10222a}
        .rbl-mchip.active{background:#36f08a;color:#06150c;border-color:#36f08a}

        .rbl-selected{
          background:#091910;padding:7px 9px;border-left:1px solid rgba(54,240,138,.35);
          border-right:1px solid rgba(54,240,138,.35);white-space:nowrap;overflow:hidden;
          text-overflow:ellipsis;font-size:11px;font-weight:750
        }
        .rbl-actionbox{background:#07150e;padding:6px 8px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-actionbox label,.rbl-options>label{display:block;font-size:9px;color:#83a58f;margin-bottom:3px}
        .rbl-actionbox select,.rbl-passbox input,.rbl-options select{
          width:100%;min-height:33px;border:1px solid #244b34;border-radius:8px;background:#0e2519;color:#fff;padding:5px 7px;font-size:11px
        }
        .rbl-passbox{display:grid;gap:4px;margin-top:4px}.rbl-passbox[hidden]{display:none}
        .rbl-existing{margin-top:5px;padding:5px 7px;border-radius:7px;background:#102a38;color:#b8ddf0;font-size:9px}

        .rbl-passguard{padding:7px 8px;background:#2a1710;border-left:1px solid #8a4d2d;border-right:1px solid #8a4d2d}
        .rbl-passguard>b{display:block;font-size:10px;color:#ffcfad}.rbl-passguard>span{display:block;font-size:8px;color:#dcae91;margin-top:2px;line-height:1.35}
        .rbl-passguard>div{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:6px}
        .rbl-passguard button{min-height:34px;border:1px solid #754129;border-radius:8px;background:#1c100b;color:#fff;font-weight:750;font-size:9px}
        .rbl-passguard button:first-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-advance{padding:7px 8px;background:#2a2310;border-left:1px solid #6e5d23;border-right:1px solid #6e5d23}
        .rbl-advance>b{font-size:10px;color:#ffe59a}.rbl-advance>div{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:5px}
        .rbl-advance button{min-height:34px;border:1px solid #6e5d23;border-radius:8px;background:#1d1a0d;color:#fff;font-weight:750}
        .rbl-advance button:last-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;background:#07150e;padding:6px 7px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-grid button{min-height:38px;border:1px solid #244b34;border-radius:9px;background:#10291b;color:#f3fff8;font-weight:750;font-size:11px}
        .rbl-grid button:disabled{opacity:.35}.rbl-grid button:first-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-tools{display:grid;grid-template-columns:1fr 1fr;gap:5px;background:#07150e;padding:0 7px 6px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-tools button{min-height:34px;border:1px solid #244b34;border-radius:8px;background:#0e2519;color:#a8e8c2;font-weight:750;font-size:10px}

        .rbl-options{background:#07150e;padding:7px 9px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-options>label{margin:0 0 8px}
        .rbl-check{display:flex!important;align-items:center;gap:7px;background:#0b2015;border-radius:8px;padding:6px!important;color:#cee5d6!important}
        .rbl-check input{width:17px;height:17px;accent-color:#36f08a}.rbl-check span{font-size:10px}.rbl-check b{display:block}.rbl-check small{display:block;color:#7fa08c;font-size:8px}
        #rbl-width{width:100%;accent-color:#36f08a}.rbl-reset{width:100%;min-height:32px;border:1px solid #244b34;border-radius:8px;background:#10291b;color:#d8eee0;font-weight:700}
        .rbl-legend{display:flex;gap:10px;margin-top:7px;font-size:8px;color:#8da895}.rbl-legend span{display:flex;align-items:center;gap:4px}
        .rbl-legend i{width:14px;height:3px;border-radius:2px}.rbl-legend i.active{background:#36f08a}.rbl-legend i.other{background:#69a8c7}

        .rbl-stats-box{background:#07150e;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);padding:7px}
        .rbl-stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px}.rbl-stats-grid div{background:#0d2418;border:1px solid #1e432e;border-radius:8px;padding:6px;min-width:0}
        .rbl-stats-grid b{display:block;font-size:12px}.rbl-stats-grid span{display:block;color:#8cae9a;font-size:7px;margin-top:2px}
        .rbl-fun{margin-top:6px;border-top:1px dashed #214a32;padding-top:4px}.rbl-fun div{display:flex;justify-content:space-between;gap:6px;padding:2px 0;font-size:8px}
        .rbl-fun span{color:#87a794}.rbl-fun b{color:#dff9e9;text-align:right;max-width:64%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .rbl-stats-note{font-size:7px;line-height:1.35;color:#6f927c;margin-top:5px}.rbl-stats-error{font-size:8px;color:#ffb9a8;margin-top:5px}
        .rbl-stats-refresh{width:100%;min-height:30px;margin-top:5px;border:1px solid #27563a;border-radius:7px;background:#10291b;color:#8ff2b8;font-weight:750}

        .rbl-sync{width:100%;min-height:38px;border:1px solid rgba(54,240,138,.35);border-radius:0 0 15px 15px;background:#163c28;color:#58f69d;font-weight:800;font-size:11px}
        .rbl-flash{position:absolute;left:8px;right:8px;bottom:-32px;background:#020a05;color:#fff;border-radius:8px;padding:6px;font-size:10px;text-align:center;opacity:0;pointer-events:none;transition:.18s}
        .rbl-flash.show{opacity:1}
        .rbl-mini{display:flex;align-items:center;gap:7px;border:1px solid rgba(54,240,138,.45);border-radius:999px;background:#07150e;color:#fff;padding:4px 9px 4px 4px;font-weight:800}
        .rbl-mini img{width:34px;height:34px;border-radius:50%;object-fit:cover}

        .rbl-route-dot{background:transparent!important;border:0!important}
        .rbl-route-dot span{display:grid;place-items:center;color:#fff;font:bold 10px system-ui;box-shadow:0 2px 7px #000}
        .rbl-route-dot .active{width:26px;height:26px;border-radius:50%;background:#07150e;border:2px solid #36f08a}
        .rbl-route-dot .other{min-width:28px;height:22px;padding:0 4px;border-radius:999px;background:#112936;border:2px solid #69a8c7;font-size:8px}
      `;
      document.head.appendChild(css);

      plugin.load();
      plugin.render();
      plugin.drawRoutes();

      window.addHook('portalSelected',plugin.handlePortalSelected);
      window.addHook('mapDataRefreshEnd',plugin.drawRoutes);
      window.addEventListener('resize',()=>{plugin.applyGeometry();plugin.drawRoutes()});

      if(window.IITC&&IITC.toolbox&&IITC.toolbox.addButton){
        IITC.toolbox.addButton({
          label:'BannerLab',
          title:'Redacted BannerLab Companion',
          action:()=>{plugin.collapsed=!plugin.collapsed;plugin.render()}
        });
      }
    }

    setup.info={script:{name:'Redacted BannerLab IITC Companion',version:'0.6.3'}};
    window.bootPlugins=window.bootPlugins||[];
    window.bootPlugins.push(setup);
    if(window.iitcLoaded)setup();
  }

  const s=document.createElement('script');
  s.textContent='('+wrapper+')();';
  (document.body||document.head||document.documentElement).appendChild(s);
})();
