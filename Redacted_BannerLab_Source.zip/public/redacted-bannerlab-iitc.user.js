// ==UserScript==
// @name         Redacted BannerLab IITC Bridge
// @id           redacted-bannerlab-bridge
// @category     Mission
// @version      0.1.0
// @description  Envoie le portail IITC sélectionné vers Redacted BannerLab Android.
// @match        https://intel.ingress.com/*
// @grant        none
// ==/UserScript==
(function(){
  function wrapper(){
    if(typeof window.plugin!=='function') window.plugin=function(){};
    window.plugin.redactedBannerLabBridge={};
    const plugin=window.plugin.redactedBannerLabBridge;
    plugin.send=function(){
      const guid=window.selectedPortal;
      const marker=guid&&window.portals&&window.portals[guid];
      if(!marker){alert('Sélectionne d’abord un portail.');return;}
      const data=marker.options&&marker.options.data||{};
      const ll=marker.getLatLng();
      const q=new URLSearchParams({
        guid:String(guid||''),
        title:String(data.title||'Portail'),
        lat:String(ll.lat),
        lng:String(ll.lng),
        image:String(data.image||'')
      });
      window.location.href='redactedbannerlab://portal?'+q.toString();
    };
    function setup(){
      if(window.IITC&&IITC.toolbox&&IITC.toolbox.addButton){
        IITC.toolbox.addButton({label:'→ BannerLab',title:'Envoyer le portail sélectionné vers Redacted BannerLab',action:plugin.send});
      }else{
        const tb=document.querySelector('#toolbox');
        if(tb&&!document.querySelector('#redacted-bannerlab-send')){
          const a=document.createElement('a');a.id='redacted-bannerlab-send';a.textContent=' → BannerLab';a.href='#';a.addEventListener('click',e=>{e.preventDefault();plugin.send()});tb.appendChild(a);
        }
      }
    }
    setup.info={script:{name:'Redacted BannerLab IITC Bridge',version:'0.1.0'}};
    window.bootPlugins=window.bootPlugins||[];window.bootPlugins.push(setup);
    if(window.iitcLoaded)setup();
  }
  const s=document.createElement('script');s.textContent='('+wrapper+')();';(document.body||document.head||document.documentElement).appendChild(s);
})();
