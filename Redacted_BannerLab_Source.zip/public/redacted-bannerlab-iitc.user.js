// ==UserScript==
// @name         Redacted BannerLab IITC Companion
// @id           redacted-bannerlab-bridge
// @category     Mission
// @version      0.6.7
// @description  Companion BannerLab : édition de missions, passphrases, tracés multi-missions, stats piétonnes et synchronisation Android.
// @match        https://intel.ingress.com/*
// @grant        none
// ==/UserScript==
(function(){
  function wrapper(){
    if(typeof window.plugin!=='function') window.plugin=function(){};

    const KEY='redactedBannerLabCompanionV3';
    const OLD_KEY='redactedBannerLabCompanionV2';
    const STATS_KEY='redactedBannerLabStatsV1';
    const SNAPSHOT_KEY='redactedBannerLabLastRblSnapshotV1';
    const PROGRESS_KEY='redactedBannerLabProgressV2';
    const SESSIONS_KEY='redactedBannerLabSessionsV1';
    const AUTOSAVE_KEY='redactedBannerLabAutoSaveV1';
    const AUTOSAVE_BACKUP_KEY='redactedBannerLabAutoSaveBackupV1';
    const VALHALLA='https://valhalla1.openstreetmap.de/route';
    const MAX_ROUTE_POINTS=45;
    const ICON='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAABMWlDQ1BJQ0MgUHJvZmlsZQAAeJx9kD9Lw0AYxn+Wgv8H0dEhYxelKqiDLlUMOkmsYHVK07QV2hqSlFJw8wv4IQRnR0Ho6uAgCK76EcTBtT5JkGSJ7/He/e65h7t7XyhMoSiWodsLfcusGGe1c2PykwmNOGwn8MgPuX7eE+/byj++vJhuuIGj9UvZ8PW4rqyKl1oJtyOuJ3wd8SD0QvFtxH7V2hPfiUutDNcz7Hh+5H8R73Q7fSf9N3Nu7/RE64FymX0uCfDoYDPE4JgNzaZ2XfqE4oEcIW1RgKWTiqiKL0dPShNXTNS/5ImbD9gdjcfjp1Q7GsHDFsw8plppGxZm4TmjpT31bN+OpaKy0GzC9z3M12DxVfdc/DUypzYjrs3kSqOl2lwph/qvw6ponTJrbP4CGDVN6D4vo30AADTOSURBVHjaRbxJjGxZet/3O/ecO9+YM3LON9XQNXR1dVV1s5ukJFIkNRiyAMm2ZBqwIYGGN4Y3XnvTW2+9MeCFlloINgzLG2s0KJLi5Fazu9k1vjlfvhxijrjzPYMX8UgtEpHIRCzixne+7z99R/wnf/szN181+JOP+OjgjHdty+dNxeDeR7T5l9zOfsZ2uyP0feomJEynTMaHHAjJw/4hzra82l4y2804vTigtSUvX92yXldMx+dUnaC0gtHRW/ie5q0HF4wmx7zaxajxByg/pmtzqs0ton8K8RjnHM45YP8qAGctbx36PDpQdLrD9ywCi+dZmqajrhsQ4AmBcw5rHZ12dBZAIKWPkhInBBbFtvWptaDWgrJzWASdtgQSHh0oToY+eW2RSqofxb0T2k6T5Cve8lNCbXgvyqjyV9zkl3Rakxfgi4iR8pB1Qds2COkw9RpDQd6VCGWpTMur6w2dETz84AeEowcIP+LD976FEjWP//w/ELiYxh8iygVi/g3V6iXF5jV+OkYlIxyAEAhACIEQAicETefYVoa8tpSNpenAlwJnDdYYnHMYazHGoLWh7TRtpzHG4KxDKkk/CcgiRRx4jFJFawTbxoFzHPYVbx8FXEx8sliyLgyqqiripuXw4dukZUHgBLrcYhczTr0B1/GUqi9Yr1vWd3Penkw5CPr84uZLNtUlSRQilMVTjq9f3LDcNCgv5PzRxxy+9zcYHV7Q83YMAs3nP8/ZHT7Cqh7r1z/DFHfEThANRhxOLyBOaPCQwuEAJwSeEOyfmKOzjkVpCX0PiUB6UGhHqhTKWYQzWKsxBjrroe2+kpyzODSy6yhqSaEhDEKORoqx0eQ1jHoB33u7xzCVWAuh8hj2Y1SvN0DYgt38a6rBIZ93c+Zyw4u7OaEBN8oIwpjAu+Hg8Jzd4IJXV49Z5SvGyZTSWby2IUkijPU4Co45HR3xfL3mdrbg5OQCUVxzeT2nsT7R5B7z3Yqrp3+I7mr6fsqDXsTF6QHqOOPJTtNogScF0lP4zRbR1eh0gudJHB4Wi3WgrWBZGkop8WVE5Bpk29KoAI2PdoCwOOEASdl6uNbDCcFZ7BEpwTTzSIOAk4OE80mI1o6q1QgBg1SiBof3qcs1YdjnOs953VQo4GAgydsKN2s48s4JVMr4W38TsmPU+ob300/Y+JK1yNnMXnK3mhMEEfcuHlBsc7rdDcsv/jnPumeYcsa8qFDZEcVmi85v0G3FarMjVyX2Vcgv/frf5t6DIb0N3G4cr7cOz2m6659i6pzRw++TKp8Gj0YGdCokpCWq1mAc2vMo0VgnqZMeVuwrYV+L4AGRhFDCYV9y78An8gWB8hilHqEybPMKa6FuDTvn8JVEhXGfqtxSFSW6bSi2C7CGKDnAD0Ou6orZ7Q2jkynTOMFWLzgb9fludM4X1Y6r5edoIyh3hsF4TCt9brsF04MJtHf8+Z/8nwhAqTGnxzHlbs5qdUmrG8LAZzAYcXx4Thb3ULrlvOcTuYbNqqRcXJK/+kNM23EWRKTpgLprcUFCmo5ITEu+eIntWrSuUWffRo/uYfAQbv9g2Ld4RongYqzIQkmoLIE0gEUJkB6YzpBrAc7hHDgnqDuNioXg0bu/zE/+7N9wtbhmOj3lKMnQueHV9o7p+ccsF1dkWrB++VNMc01lDGFlKP2EpqgoG81gMGIYJlw/e0orc5Jpj7yq2VQVQRjQa1vS1RaH5XXX4UuF1g1xmqKU4o9+9//h/OQhQdZjtV4yu76hym9pd3OEc6xehixUwqzNgY6T7Ajf77E0JXVX43k+4yAGP8CzGpwHOKxzJL7gwYHi4WEIQFF1GGOQnkeWBPi+ous0TWcomw6tNVIqhJCoX56c8q2Dd5g8XPO/7/4VMZpfOn5EIBX/pv4pdy9/znq3JY1TytUNyiv5+PA+s2LGT29fsMpzrHDQs8y9Bcs8pzYl1rMoJdnsKuIGkoHmprmjbBuM6dDWIhB0bctseUOxmXN39QVCCHbFlqosiMOIIIyR0me1vsSqDOdLis1zbosF3lu/QjR6H19FBP0jVP8YJxwWDyEcke8w1jGIBUd9RRZJ2s4iU5/QD3Fvmr+xhqbrKKuGsu6oGw2AlB7q55c/Y7W8YrbZ8u70jPcOz5n4Kdo47mcDQn/OLtfcXT8lDSWBstzFd3jCZ1UXbOuCYZZQd447U9NhcCrgZrbl4vyck5Mx+XyFJwXXzYxdXjFJUqwA60ccDA8R1rJez1iu54BDeIJh1iMJYrrWsO4qNi4nDhPSNEJ3DW4QEZ++jZ+MMOEILx6C8LDWkIYwCB2Zb/EAX4G1hvmmIlQe/SzAV5KialisC4qypu0M2jiMsbRvYII1BjVO+9x5G7Rq+MHBQ47SEZ0VPFlc0QnNex99i49/0Off/d6/Z7lY0ctiXu1m+CogixIGwQAPS2kMCEdnNIPBkF52zvnZCaF0vDY1uzyncZbzi0cMZESlayZnD8AYbq9ekhclbWvJyxrheyg/wGqLri2dtRhnac2KUS9jOjri/OhbiHJDIgMYnFF7AosgkIL7B5LDxFHVBhC0xvFq2WKt42Qg6bRGG0tZNRR1izGWumnRWmOsxRpHpw1ad6iBTrC+xR/GVJXh+XJGbTo60TI6nhDEIVmi+Pb7j/jTn3xJ0xmqxqCURxKEZC4BKzmNfGpb8rTOCehQtqTNb6h0gx+GeH5Ez49Jh0fMF3c403A/jEn9kKdff85qsybwfRCCoqiZO0fgK7rWcDI85rA3YFmssdZwEB/wMDvj5e0lrtjimhLdPyKZ3CPxHT3R4jnQzf6162DRBgjPoxdqqsZSdw5nDaGvCHxB22qMsVhn0cZirUXgIV2if/T1zSWz3YrWGW7yJVflnLPhlIKK2+0dSinGowlt17Le5aw3OY22FHXFutzSuRYhBQZD2g9569EpWhfsthua1hJlB7z13qdo63j89c9Yzq8RTrPbzNnmc5o2Z1eUWCfwJCglOJ2ccjQ5wRce0/4RB/0D7g0mDCOf+W7NercjbzZ0XU1brQnxSGyLzG/pdhvqpmVzc8Xm5oa2k+RejBOghMWX4BB40iPwJR7Q6j32CfyAKIrI0oQsTVAvNzPAMd+uma93JFmfo3TCclewrNbIvk9edlzdXHJ7t6KXpHRtR13XBL7Cw0PLhmi4nwpFayjLHGscu7JjNJ7gqwAfRWxjEhEwODgEa3l9+xoVvhnEwuIJxWFvjDOaadZHyAiiPlEUY2iIgwjtAspuhS5ekalTQgJ6OiG+u6FZ3NFkA3QUYp9XbKsVZnzM5HDAIPOx1hCFPpO+pGoNi8KxKQRSGKTz8KREeh5KSpRS+yo6Px04IQXWOsqyZTwaM+0PuZdO8YcZs3qGH3jMFmseP74kTUIGvRRjzR6ACYkfSN46PmTa73G1nVOUHbqxHKQ9BsMBDTAcT/jeb5xTFR3//l8+Yzmfo5whDQOscwziMRWOfpCgu5ZFsaRuNKEM6Q/6aFHiS2jaDl0bfBmxqCrieMx704f0lIdTMX46xgmBOjjk6P33mJweMRpmDBOPrnOEviCQ0GjLtoabraWoNZFo8GyDNgZrLbo11G2LcgJMtx/JOMtuu2UQZyyVwOxKbm9mFOUaqRRhqPCVIg1TOr3HC03XUTQNX+kbutOOqtVsNhVJHJMkMc42zBYbjj8UvPtbQ8LmgKY+4V/8HzccTcd4jaVsW9KsxzDoMdUBJtK8Wt0yz9ckYYj2G+quwVjLwegYrTpWuzWeDGi6knU1p/QN803OID7g/N3vMXz0PsloyDC0TEKNLyW26zAdNNYDBJkPF0OoOoU2HlYr2ralbjpwHqEA1TSaOA4RzjEaZrS1oZ8OSFXM7fyatq0Jw4BeGuNXirJuuFutOZlMGA1j5vkGxB4zVF1LECikUog2pGkdIoC60jgcu2XB1WzOd379Abb9mD/6f/8cJT2KtmVx84JJMkCoPlfbBcvNDq0tq25H2dTgIIlipAhBSQJRoGSIAS4Xr+n3ErwgREYBsWngyS94+nXBM9XxzocfMTi9R607uroE1xFGGZ5KkRJ83ydQAQTqDeF1pElI4Euk8MyPHA4caG3AQS/JGKQZVV2xzFdMRiMmvSHrfIdxUFY1SiqQjkZrotAHHE3XMooyPpm8x3f7b1PtWpZ6SzL2GI57hCPLptlQVwV+Jqg3ktcv1jgjkNbQCz2MMHx5c0ndNkjhYXE4J6i6DmMtTZUTCEcsQ4qypGkrQk/hOYFyAmcaYjTF6jV3r56SVwXje++g4gHL1Zxf/Pz3+bOf/AF50eL5GZ0R5GVLpzs84ei0peksoS/Jkgh1fnBI3lRs8pLQV/SSBKTlbvOavCkIA4lw0Gq7F6PsHlssdhs2VU6gFNuiwGGJYp+/dvGAvz76hKVeEXxU88lHQw5OIvAcdVORRgF//OMvmd8VXNx7l95lRqwUwvpsNwV325fIMOAgzijKAiEVaZSw2q7QRrMpCyLp0c8OKDzohz3eP/uAMEixwuFEw7R3yNPbS26KBX/tV3+V4/MLrID14oqf/dkfUpUFeb7FDwMu7n8H7TzqVlPVHcLz0MaCs3gC5H/7vb/1o4PhkLt6jfA8jDFY19KLe4yzIU5orHVs8g3KV3upQewJHQ4624IQhKFP4oVI6XH8aUz4W1se/npMbwidrghDsLrEFyFZ2icMAzZ5wTvfvc8nvz7m/kcZxlc8/6bEF4o4Dmm6hq5r8YVHGvoEStEPY85GB4yzIWnsczo6puk0vh+xyJesijmegrxp8fyQ45Mp0leUdclXX/0JV5dP95/D7HC2wVoIwhSpIlpt6PReXOs6Q1Vr5NvT6Y8qaeg8S1k3COFIoph3z99Feh6v5q/Y1TnbqqRpO4ZZRhqH5FVJlkTcnxyhfIHnBO+8e8yv/MMThp+1BKlDGYFu9tOuKiuKoiXrhaSRz6if8e47Z0wmAUIY4h58+Okx9x5MaO408+stKIfHfsJKCaNswLuHDxilfVZlwdHgiFEy5eXiFda0zHd33O1uWZZz1sUa08Bqdo0RhsY2XL78Gdv1HZttCQjiMOTo9G2mR/eJooRAeUSBTxr7GAtFo5Enp4MflV1D3XYUZUkUBWhtKaqa096Qpmt4Z3zOD86+xfVujRWW4SDhcDLib337B/zDt/86ta45+37Cf/qP3+LiYY9EJXhA07YYo5FCAh69fooQHk2jCUNF5Eu2yw1PvrliMBgSRxI/zXnn42PaTvDsq1uatsNhsdbxRnSmbBsiP2OU9rjbLvlm9hiJprMdt9sVrTas8w3gcdQ/oq23fPHNn7Jc3FE3Busiev0x211Of3jB+PCcIIhRShJFPlkSoKSHQyDH4+xH1+s5nekwzgIWHBRNzd12iY/PZ+N3eJQdse4K5t2WKPb5jYef8Un2Nl6/Y/qblo9/44AsCXHWYkxD07Y4BEYbnLM0dYX0BG3b0XYt1jiqqiHLUobjAXHskEIzu8vZ7DZ88OkJo4M+z75ckkYhnTYYa+locEqzqysu5ze8WLxiU65JwoBBcsCq2iI8R6hCAumjvAjpfGgMm7xgW5Z0ukJ6muvXN7y6fEWWJQwGQ3w/QGBp6hrlWXqxQiaZ+JE2jnWeIwPF2emU/iBCKsEurxmrHtiOu+2a8XhEehhRbWvOggHTT0H++orhPQ+hBWVdsZzP0MYiPIVzFpyh6VqapsPzJEVeo5Sk0waLxZgKYzq6tqMsO/70D59RFrBdN7z/8THn9w746R9f0umORMUEviJLQ+brJfPNjkGa8fDwnPvjtxgmU+62c2bbJRKJLwVlXdI0mklvjKcM1isII0nT1qxWFYfTE959dI5Hha53SFPRlmucLrFtjnz30dGPiqpFCp9R3CcNEsZHAy4m53wy+Bad7vhm+xrrgfVhXmzI+oqP/4sh0x8K4kBR5yWN3rPhujZ4gCcFRrc457Fa5GS9BG0sUnmoQNA2NcZq2kpTlYZXLzbMbkrG0zH9UYrpYLnIufdwRJJGPP9qQaAUnTFo29JLInwZM8lGnAxOyMIBq3LN5eKSttN02tKZDiFgW+X4KmAymHByeEgQB1RdSVt3aLuXVvP1LYu7l5g2R7mO3fqO66unyDjxfyQ8wenwkLPeFFF59EzG33n0S3x3/IhVnfOHV59zWy55dn3N/Q8G/PZ//z733u4Tipi2a1G+pOs6nGXfc6REeB6B7+GcwDqPJPVpm466rijzGtNZukbj+wHLWc1209LrZ1zcH7FZ7UhTnzxvefL4lh/+2iN07fj6qxtqU1O3LZ7w9iJXo7ldz3l695zbzR1t2xEHCb2ojzZuTz6DiEDF3D98xHH/nE1esGuXZJnP7G7JN4+f0nUtbVtT1xW3d9c8ffwLbi8fI2XAj456Y0LpY7Bo3ZF5Eaeqx83ihl1T8jy/Zlnk/PA3z/lH/8OnTA5irLYYOqwzOGspywpnzBsfS+IHiqap8JXCGItUgsVsS77rCPwQP1A451gvKxbzmuFBQhT7lEXD7HbLZlVyc71lvqhYrXPe++iYq2c7dpsaX0l2dUXdaIwzrIsNrWkQQqC8AIRDSUGtG1rdEvsJZV3hrCNRKZt6y836huUqZ7utCHyfNEno9/qMR31mt69ZXb8mEg714ekjfCTDMENqj51Xsm63/PH1V/gOStcgBDy4d8hv/853SVNJnheoQFJtC6yzJEmGNgbpOToNVmvqqqJrNYu2REhJvoPlvCaMY4I4YH67ocg7rIYwDLi53GHclunhkNeXObtdR5QE7LYNT79ZIpzHB5+dU+YdpnEgPLSwe/btKVrd0pkdgQzwlUDIEOsMre5oTUPm93lxe8m8mGPDlsV6x2ZdEviSo8MEY0pubm5RoqMudsS+xEmDPJ2MfnS1mrHIt4S+QnuaVbNl21W0nuW2W7HalvyNv/8tvverp+T5llY3GF2zXu1wbl8ts9sFZd7SaUuaZXz15TVJL2Ozrsl6PaqyI4gCRuOU9WqHkJKjozHFruP19Zbb65JeL2W7rnjxbIV10LaWpjYEgU9ZtkSZjy8CduuKwWBPhbZ5Sac1XVfTGY3nCTyh8FBoY2m7DmcN/XiIQ/J88YKob5hOUsbjhOPjHkoJtBZk6RjPUwhrGI8mZJMx6s+vnu698DeN9Ww4pjINh8lkP1Zrx2/93ff4O//wXVbLBcZ2KKmoypKs18c6qKuKqtDESUh/mHL5ckaSJkyPMuqqZTxNiCKJsRpPOqyxJIlicTdHGzg/n3B0KKjbjlfPd6hAYq2l0w4/UFhnaVvDbL4h7accTPq0Xbf/0fVev/E9rAVrHW2rwUo8qeglPTzfkrdbxskJUZVQN5rhsE8UO5R0vHy5xrqEB99+xOHBlEjBeDTBOYuapH2iIMBTkrNsRCYjIhWSxBHLbc7J+z3+3u+8jdYFm82WrBdRVQ1t40j7jmrX4L2xitMsxDlNkXecXwxZrTbkecF6uWS7qRj0M6rK4nmSy+crDo5HjCLINx2bTUWedwCkacRqUewpgbV0bYdVFk95EFmmhwOePL6k6VrSOKKf9rE4Wt3QtB0SgcXg4dHr94hiCTpChYaekwwmfR5cvM+r169ZrOZkw2x/ZN0K7UK0iQjDkMPpAerD8wfUbcOi3XFTLYijkEZ1/MnlF4wOevw3v/NXKKstTW3A24PIsqyJopC2aREeVFWHHwZYHOvZCuVLnLBI4ZFkAbPbNVL65EVJVbRIGVBVmsCHP/r9F0ymfdrOsVlVXF9uOTkbItWeF5oOPM9DOUsU+jRdhRABbdPhSYiC8E0TrrEGtNZ4SqLU3tJRQmK1oBcmHEwHKEp644jxJGa2UshGMRhFKOVRmQWXdytcl1Aaj9qBWpuC2XbFtq7wlcT4exYqpOM3//5DpieCq1cbuq4hywL8yCe1MU1dEkUhu+2O/rBHGBnapgV8duuKtq44POnRNYa71znDccZ6UdM0hrotyTcNv/dvn5L1Y7briqo0dK3j0bempKmPChR3NxuElCgp8JXHdlPgeY40cpwcHuz1nU7TtNV+SjmHMIowCpn0h9RN95dfrGBL4hROgaZjUV0yPILh8cFezxICKdUb26lHkIUsdxvUts5pjeHi6JSq2jPp5WbDZ3/1Pr/6W6fc3szxA0XXNWjjKIqc1V1DXuSMpz086RNEitVii0BRN5qT8wGPv7xjcuRR5i1F4dHWFSrw8KTPYBjwzS92VGXL0YnH46+WHJ312a4aHJrF3OEJhbMC4RxOWrrWIaUHAkSoSZKIOEhYF3f4StIfhbSdRm86tO2wWE4e9pGRBCkQ1iOaGOIgQCoPK1pkIJCet4cm3t6CFkhas2O9+gW2sKgsjglEwLQ/YiEMVad558MT/s4/eJfNZk2nG5q6Ik5TgjDEGANyb+UcHo/YrkqefXXF5dMdRWFIeiHn91sOjhNG4xRnHFcvd3Stz/3TAfm24uuf37FeFrz13hSsw8OjzDscsF7VZFnIbldhrSCO/L2s0ml6g5i6aslVxWze0FlNmiTsioq8LPHk3jYy2lE2NRfjAePTBDyB0RaEA7w98X0zmIyzOLf/l8UipY/wLC0btDN442zAeJTx/PYli92WWtf84DdOGB45ZndrhJBUdYtz0HUdcRwCjjgWXF+uaBrL3W1LnA0wLkGbkKePd1R1w3ZT8PLpHYt5yXJR4XBsNxVXVwWToxQhHHfXOWWh6WqLs/vAVFu16EYThB5124EFqy3FrsYaQ6dbVApWGiyGKA04v38BDoJA4YRDSEkY9ojCMUZbjNtb3sZorN37XwiH2AsECCzWdGhTo02L8xx+z0c1m5badax2Ozpj+c6nD/jg4wl3t3cMBhnKdwg84iQiCODu9R1Pv55zfu8QpRzbdc5mbTiYBnz03QOMrVitBFkv4+42Z7ezDEYZ62XDelkSJzFZL6I/iFmvaoxzHJ6lGG0Jwv1It05gHVRFixMSJQ0OUNLDdAZPWMaHA5pakvT6nJ2c8t573+bf/dt/x263I02HjA8OeOfhZ4RxwNP8J2gDnpQYbWjaFt9X2I49bpICayVaG4wzb5JtICWottMgPZz1mBxk/NbffYuo1/HV4xsmkzEyUIwPenRtzde/uMFaj/c+esTV5YrxIMBZyfK25p//0z9lNErAwflbfT75geDt9w958WTN1fM1KoiYTPtURc3xSUYQSe6ud4SxR1cbdOfwfUe5M6AknhIo5SGlJO2FmM7sj4mDum6ZDBRHB/cIopTIl1xdLpge3efkVGIR3Lt3wSff/oyqrunFMWEokVKyWK65vr3l/vkp0vP29pUA4e3zRNbt5Rm3L2dUeBwRxSkfHsZ8/zdGvPORJN+1JEmMtZa21lR5w2yWc3A45cGjQ26vVxwdjQiCAOFpFjc1//i//h9xCP7JP/lf6dqCX/tb7/Dq5R2zu4Kj8zH9YcTrV3OaqgNP8PzJmt2uo+d8qnKfL5zd1CSJwjpHGHsIPHbrlsVdzvQw+4+9w4Y4ofn0009Yrmpu727QRcPDR2+TpQkvL18RRSFJlqICn7qLCUKBkj5Nqzkn4uNvfUgY7KEJvIn5CUB4OBzOOhwO9e5b9/j6+Uve/zTjO9/P6LqGstpxcDTEGkuxrXBCcXZ+TJwofv5nXxGFGXES0LSWqjTMrzvuHszYbCo6G/FLv3bCaGL4D39SYLTi4Chms2q4eZXTH4U0VUechiRZxKtnW5wT+JHHcJrS1Zqq1FA5RpOYrnUgJDJQ5MuC/jDGGMdidUd1uuXk5CFxmnBzfYsQewsnS1N8pfgL4fzHP/8Jl9ePaWtIVcZb994hv3+OjfZ2tBBiH1p4E7oybo/IHaBuFit2zYqzd2L8yNC1Fuc0dbXHGGEUM+ln6E7z6sUNSqdM3QO6/grhO7782Rw/VPzrf/HPaTvL4XHEo2+NwUk++u45o/EG6UdkaUwUSZ4+XnFzlZOlAYenPY7OMtarhjgWSOkwat9/4sTHVx5xLNmsO9aLkije/00bh+/7lPWWh/f6vP32BT/92edsNju0Njx8eJ/RqIezDk9I1jPD1ZOWh2fHfPzOI0ajCV1T0XkOpRQIgduf3jcR5H3CzOFQ882c3/x7x4yOPKqqZLXagpNsNzmDccbd7QwZKFbzLZt1x9tvD5mOFdcbzdNv7nj+fMHJg4j1rOX97x3xn//OB4RBSRAmDAYZ/UGPxXJHU+WchWOaWvLWw1Mclqwf8uSbGWWxZX7bMZqEeFIRpz7WaHTn2Kw0V5dbzu/3GE8S8rzDmIZgmnI9f8633/urnBwdUbxV8c2T53TaMB4NiaKAtq1xODabiizO+OVPv8PF+THWOrQx5GW1T5J5Yp8tcmCdw9i/aNIS9d0fHnJ40uC02qeqlMdqtkOqAKMdVeFo647VoiDJMharHZevr7h8suTZk4JPfvAeFw+mfPjJhm9/fMb4ELQOiKMIYwynp2OODsdIz+BJn48/M/T6iq7WhJHPz34y5l/rJ1w8GPKzn14xvymw2nJwlJIXmvldCU5QlobloiTthwgBu12F580py71DcXx8xNXrO/KiYDhImS/WVPmW0SDBcx2+knzz4oonlzc4BA6FNg6LQ/kK6cn/aF9FEUkckkQBajAxhFFIkvhsdxs8T6JNS5JlrG4r6hqefnPDcq45OUswXc0XP1/jhxGf/vCCT75/gdYdj956SBQ4ttsd1gkWswUH0wPSJARb0zYNu6JlOBjQVpauMdy8XtI0O/6z//I97j0c8skPTikLQ+A5BoOI6+sd/9vVj3n2eEfS+owOUpxz5FUHDvq9lLrRWOfI0hRPKtabHavVis1qxdMnj5kME7IIIhmzWC73KTLrUdSaqjU4t9ejhPDwfcVkNGB6MMTzPOqmQSkp6bqGujZEccxuvSUMUnabjtWqpCod09M+VblCdyFVteODjx/y7genSA+yJCEIFEJYimKH1aD8gMPjI8JAspjPKPJ2DxkA00EofZ48e81209G0HnU5Z3o0YjIKMOaao6Me8+trxgcZv/073+N/+Z//DaM3hLLIK/zAw8PSdRptOnTXksQRYSCZL5Z89fkv8KXl1auXfPHlDpyg0Za61UjpE0UpCA/j9oBSGQ/PkwjkXpmwljD09zHgg8OAzqxADNhtdmyWmsPjKT//8QvSXkYYw2gU89bbMXXTce/hmEdv32M0yGjqjq5twFnquiNLMoRXoPyAsthyd7OhKjQH0wllWaO1wZMxs/mKVy9WfPjx2yjfp9iafVV1sFlZrl9dc/1qx/SoJUkT/qvf+ZTXr5aURY0zliD2aRpL3TZ0usFpjScso35C11S8vtlydtBn3Itoq4Kq1bRtS9MYoshHKUkYhjStxji3zyRgAMdmkyMEexmln6KsKOhlB7RtB3gEQcJmXiB9SdZPkEqhdce9R0MCFZBkGb6UtE1NHEeEsWKzWgH7kgzCgM1qy9dfPOPg8JgoCVivV0jlE6mYstpQNZYHD8/pZRHL9Y4g9PdB7xiawlGXivF4TBr1ePb4lgcPJ3z/B5/xz/7pH9M0NTKQ+L5E647Vas2zFy+4ODtiNEyZL27506fPGfazfYXpDucsnpQM+gOyLMMYQ13XOMS+8sKIvGowxrAtCuarDY+fXeH7Psr3YvatqiPf1qxXGil8JtM+g1GMEA1ZekAv6+Mpx/RggG4NQeiz2iwIwpjlak1VtYxGQ0IdsNuWJGmP7W6HwHB4MsETliCQdLWmaxr6wxFNY9huKupqQ1nWGN2Aldy/N+Lq5YLtuubqcgd4jCdDLu4dUO5qqrIjyRRxFLNcLvn93/1XfPitB5yennP/aIiupvuNICXwVYQnBEEYkg0GCOGz25V73cjz6FqNY/9w9ha3QymJ5wmCwEd9/Nbf5CdP/i+qtmKzqHn2uOSjTy+YHg3QnWE8POTi4oiiqsD5NKVGOI9VtSQvK7rVhqbR1GWLN3bcvJ6B80jSiOvXc84fHJOkPjevFhyfhWyWO16/2HDxUFHmHVVpuP9gys3rNWEYcjBNuHyxoqkNB9OE8bjPYJCiW00vC0j7CYvZDqsN1gq0dthWM7+7o8xzDocpnB9gjEHgqNqO5bYET5Ile0VCKYV7I/yVdYNrGhACa/fiXJqm+9UpC+qo94CD3glPr7+mqjRdA+vljgcPDukf9tjlOc+fXxKnMZPRhPVyg5KS2jQYo8nziteXC5S/H5ueVGxXJVk/ZDwe0ssUVy9es9toAl/y8tmC7dowmjTc3aw4Pp+w25W8eLHk7GxCsyx58WLF9DAh60XEseTRowG9LMA5QRzHJEn1JstUc3n5hN2q5Oun+9UoATRNi5KCMAwIwxBtBdtdhfDW9HoZre7wfR/P8/A8D20tkVJ4UlK+2T2TngQEKgmOSZMxN9czfL/Pp798CFbStIaqrJH4iNCn18soii27co33pgS3m5zlYkPWG6ICi7UGnGW7LoiTkLQXsrhdoPyQIAjwVUrWb3j2zQ3jg5woDYhjn+urDUka07Qdm3XDyUnGYNAjzxt++CvvsFnOuXu9Jc9bJgcpTVPQtQbrHC9fvNon2YTAA5TycG4/4cAx6PUYjYakSUxZ1ZRVg+9L0jSl7fQ+YGEdbbM/cn7okybh3oyoO1SSnPBo8hmu/peEWcDR0YAg8hkNxsxnd0gv4HgyZbte0HYdQRhw+eKWri3xlE9daU7OfJTvsVrMmN1sibMJdaPRXY2zhnc+uODV8xlNVxOGjk9/+SFN1SCFwxhNr+8jMBR5S1V1fPLZ+V6g9xxPvrqmyEuqqmU5b/krv/kWxychf/QHj0mSjDT1cLZm0E/BOvKqRhvwfclw0KPf6yGEQngKpSRxtIcLwvOo6oaqbhgM+iRRhHOOwaBHL03Z5gVt26HKrqOXvMN/9w/+J37/z/5vqmpLGMZEoSLLYqaHR3R1Q13WNG/8pyhKKYqa2A8YT1KKomDQ79HUju1O0x/6CBxhHBCGPXa7HZ2usdpS5hVNXaG1h9EebetQAcxua/wgwto9AVaB4eXza4T0ub0rGPYT2rak2DQ8+2aOQNBL+nz3O+csZltGvZi6qri6XdBpw/HhhOnBlCTNmK9z5osN49GANImYLTegIQxDpFejPI/RoE8QSJI4pmk6emnC8eEEJbAUjWLUe4/P3t/y5c3vYYDVaouvQoqi3HOlxRzrQuq6o65qjk9PiGKP2d2C1XKL7jqkDLh4MKWtaqYnQ5JY0LYV87sdbQOLu5y28nj2zYokS7n3YLrPIltJUbQc9QY8+XrG6VmfXj/ipz+5YTLt8Rt/+wN+/O9fsts0XL8qKfKGRxfv0w/usXYbhmlIFEjQinE/xfMUZ6cnqCBhV9ZobTHGssurfcB8U6KdQykfTyo2eYWQa3wlgQ0IwfnJIQeTMWqzeA34vFg8peA1ddeyWGyI4oCT4xM8LEZbDo9PWMy3tI2maxuUcjjbEUYxcWRRKmaz3rHb5ATK5+R8hJSC7SpndrPi3qMLrl4UXL8sOD49BOEYjFLKXcd6UzA+6PH461s225bZrCCIY9arhu//8AzrNkgpmUz7lFXLO2/fI/PfZzsr2CyWFGWBkpKmM3uJ1lO0r27xVIDWbo+SBdze3gECoXySLCMKQvq9lE5rAhUQxyFSSqyD9a6ienaFEtbhPImUHbt8jjaGwWCAtQ03d9ccHUypin1UJY5C6qoiTfuUhWU4lgS+YzBMGU16pGnAMooIAonVLYvbai9ldj6L2x3LeYXuJFXZkmQ+P//JK3QniGLJcBRzem9E0xr6/YjLpwvO7/cYHYS8fLplt22xzrBc7JiO3iLqjfni7iVXs7056SvvTeylYzo5QHqKIAiIQ5+201hjiOOINE33eg977jXo91BSUpQNnvCYjAakScpivaPpOpTpWqLBCNUFWKnfjNEInKYoCqLIo6wq1qsVXSd48WTLaDIh6Rnubgo63bJZFuB1OGPoDxRGC26u1+SbCiEE89mO29ct/cGAl0+uWS5q6kpzfDZgMu3TNQ3zuw2nDyb8yq/d5/Hnd3z5ixmnFwlV2XF3U/Py2Y4wCUhixXh4Sl60PLu8Q3cC4SfUuqGsNHHkMxyOmE4n7PKa5WZH2zRYp8nSlDRNKesObaHVhqJsCcOQsu4oy4rZakeSxnstyVMoKX2Es6zza15dvSKMfJq2wLT7c3tzfUec9InShJunc5Iso2t9PCHwfVjMSoIwZLMs0J1G+VDmjg8+esg321ckaUYYdJy/e8RuXYHzcM7jO5+ds91UNHVDmiYY6+Mr2Kw2JJlCScXVyx1lYWgbgQx96towHiWsdtd8+fmSuq5Qb3wt5zwePTjnu99+F6V8tnnFbb2mqgrqqiIMfaT0WCw3FLUmCEM8z6MoGrrO4HlibxnVjqbTeH+Bg4Tn8JAk0RCHwTqPyA9wStDWHnXtKKsN08MeQlxxfHbEw/vvsljf0bQ74lS9wR4G6RS+CgiiiuVyjrH7I3Xv4b4fffWLaybTlLZxlEVHvx/xe//2BSD47vemzG5XnJwN+fGf3LFZVrz34RFNbdCmYTiMwXoUec3l1WPqOqTMK6QET3hIJfjwnTN+9bMPabXl6YvX7PKcUEFR+nveGCZs8xVpEhFFIXXbMRqkb45VzGaXs1zvKKuWumkJowAVRgOqbs43V79LGCl8JZnPlkjPYzbLSbMM6wxRHAI+q9WOd99b07cgq4TVYkMYOqTXkW9q2lpyfDFgNd+yvCuoyhIpFZ4n6Q8StPbotOFP/+Al7390wNFpnzRVfPPFijC2vPvBCaaznN8boHyPVy83+3hK21Hkht22IYwD3nnrHh/cexs/kITBHjGfHk6J4oRmV6AdHB5MGPUTHJZXN2u0gXtnPkkSE0cxQjg++ehbXJwdoZSkbbr9qsViy+1shScl4vrJH7uqXvP59b/g6d0fslnnNLUhy1IuL5cEUcx4EtHphtFwSlNbmnqJ9ATWObpOcnpvyosnV7StZTjOsLrk859ek6YZ2JjNqubB22M+/8kdL54V9Pop/YFHWVq0cfz93/6A3/3XL/ji5685Oe2RJDH5rqWqDGXRcnavTxj63N7kCM/j+HTAP/q7/5i3zh/uNR3h7Y+HfSOZvtkgNLolDjyMsbx8vaTRmixJ3sSJPQLf5+zkcB9ab1qUlEhfgRNvzEVQOM2uu6KyM/r9Hk3b4HkheQGet4/EnZ6NsaUgiDwmk4TZrKGpSzbzHYiYsihQviPNYuZ3G7rOEScp241l9npFvjWUBXz5iy2bjSYbJDx6d0JVwfXVhq+/uEYpy+n5mDST1FWLEB7FriLNJHEUUFYaXwpG45C/+umv8OD8bZbbHXXd4AcK3w/eXE2xF/STOEZrQddUgMfFxQlJHP8lB3MOhLe/r6MoazwBXhiiO0PbtvtEifJRQgaMeu/x7azHT7/+ZyixQkYKR0evN8BYRxA5+sMh69WKxcyQJD5ad1y+2IIzxEnM069uGQwHjCYJTWNJYokUHZdPShazDikbhCe5/zBDt5rb1yVvv3eILyV/9ieXTI8S7t2PyfoBzx/nbNf1m94myHc10vdxDqwTvHj9ii+fPqEuOsq64vT4iMFAYo2jblrWuyXb3Y40UhyNewRxShwEtNqyzXcEgc96s8UBy9WO1WbH0cGIJIkxes/xwjDYI+m6LgnTA0R3RZaMmI4tu/YWz2+wneRwPObzL75gdldy7+EpwgnqsmU1r2kaQZom7PKGdz+4x+Mv57RtywffGfDVn8+5eVWjfJ9H76Z4QiCVYH7X4nmWr75Y8PSbFUJ4VGVH15V88Ys5Zxd9QLFZ16Spj2BvA5m2o2kNz5/NiNOEb148Y3ZTgXDMljsCf493wjCirGour65RnuPibEpnIAxTmnZ/2cnZ8QF38yV1u78A5eZ2AWKvcX/3w7d5/90HpHGE9CSqbg1BT5IGZyTxmNpsyIuQqtgiPIXWGuWFtG1D2ouIQ8lylpOmKb1BxeGxDxauXxXEoQIhef2yYrds6VqPzari4kFI1zqcFbS1YXQQUVV7CbRrGwajhPWyxfMUXeeoyoqDw4QwCqiKjrrW1G8kjLOLPqP+hBcv5tzebsnLkqazWGNRvqKfpfi+h+8JAiX48c++JggTzk5O0LpDSsXL17dIIVlvCoQH5ydT7hZr6qZ749rMGPRS8qJCxdmQrq1J4yGhiLl+tqYxHUHYB9Xx5PlT6sbieftd88ViiVQRaSCIIrVv1rblYBqwWSqEB1Hos1oYqsKRpjHLWUPaj3nxfEUQSLabCoCmtvT6iqY29IcBxbbBao2vBEXeEoSSuu4Iwv3y7WQSMR6Pmb0WbDa3RFGA50mapt6DOva7qEpJfCUY9mOiUJL1x9y/OKZuGvbXnIj94m4v4/HzSxbrjvOT6R4gI7i9W7Jeb8nLCrVfJJMYrYjCEcNxD21Tcj1js9nQVBrnJN/68Igk8bi7bglCQdKPODsbsVw01IWh2FW0nUO3jj9+cUtTQxRLXl/l9HoBm80OENx/NMQTBucktzc7Do9ivvlqg+4sYeCR6pDlvCTrS+5utljjkDIgiiVREmGBKFHMZzl5VSLEPqqnlL//XXesNyUuVUShZLsrqbVgk9dsdiVdt89yJ3GEH4QUVc2on3J+OiWK9rcxTMcDsjRGeB7KWqibkt5gzMXhr1Hnkln5JXZhWO4KQl/jREiR1zTNku225uJ+j7vbGl/BYlbT1qA7i1Iem3XDfNaRZRFVYTk6CZnfNZS5pTcMWa8KmlozPcxYL/eUwxpHU3ccHPbpWo0fSMrSMBgFWGPxA0EQKqqqBc8xGIeIV2Aah/L3frwQAq1bAuXwhWbc63Hv+IBndoF2il3RMFvlOOuw1mCXW4IwZNTLEAievryh7TqUUhyOhzRtQxQGqCiOWC5uyMoxoa84OHyPpIk4jt7Gb3/BNnhM2a559XSJEx69/oC6aUizEM9Z6rJlfguTw5imbrl8XpOkIUJCVWhUqPCkIEo9hqMArTvKsuWbL+coFTAchUSxQXgO3TmMNkgfmlxTFhC+eX/TaKLYYzjok+cObffyaxD4GOuQUv3lzQnaOB6/WvDyZoVB4USA8BSeJ/ZxZ0+B8FBKkdcN9c2C+XLLZNxn0Ev55tlLoiimbVvUfLFiuZzTGxwyuv8WvcGIxUyyreZMj5Y02+e0Xkc2MJSFx+FRj9ndEl/5LG92rOY18zuH70ui2KPTjii2DEchZd5xc1USRgE4Q9aTFIVGCI+udUQxrFY1xc7QdYbBUIBwTA5ihLBMpjHWeMxmBdq0HB6fc3sVMr+z+CrGOUfxxl/3lU8cx1jrqMriL0W5IIqwiL135u0ziVEUIqWPNvvcY6Akga/QFja7grv5Gj+oiUMfL037jMbHzGdXVGVOWRYIl+FFIcvyOXm1RneKfAtXz9c8+2aF9EJ+/uNrVitHr58RxyHGOqbHMYN+wOWLgjiL+f6vnvHt7x5SFR1aW25vSrrOYc1fZA4Vvb5PGAlOLzKkciQ9ge/vNwyFMKTZPtJ7etojjYYs54Km2d+UUDftfv9Md1R1TVlWNE2LM4aurhmlCb0kQhuNw6KkxFeKwPfx/f2uSBIFJFFI3bSAI4qCvbZU10zGAzxPeozO7+PilPliRpnnCBVTtAu0s1xMf4h0e4Vvt+64uSyQynHv4R4UWuuoq5btyvDkyw0qFFw8yLh8subZ1yuG45CDowgpBU1tWdw15NuO8TQCLGEoOToJ6Q88nDWMhjF1bTDG7RNgWuCcZTxOCYMeUbx3H7o3vnr8l7xK/uV9ZUIpgqxH3hm2Rb1XOz2FCmLCOCEIIoxxOCzL7Y7ZakPbaQK1l1yH/Ywg8LHOomxvhJSS83ePWF4/h6oiiR2+GfL+23+V3aqinc55+fKSwI9oasHTL3N0a7i52uFLn8EoYH7XIoRC+h4Hg5D/7w9uSNOG/tAnCAXjaUjXOPJdSxB5XNzv8fXnG/pDi/TADwwH04irlzXbbcFoHLFYtDjbcO/eiMnkgs26+Uu+5VxHFMQcjEYgoCgbjLF4HgjhYfFotMa5DoFA+QFhGDDspWRZQlO3bLc7Vrsc7SxhGHK33LLa5HjSI45D7p8d8f8Dd6JB/2WkCSQAAAAASUVORK5CYII=';

    const LANG_META={
      fr:['🇫🇷','Français','fr-FR'],en:['🇬🇧','English','en-GB'],es:['🇪🇸','Español','es-ES'],
      pt:['🇵🇹','Português','pt-PT'],de:['🇩🇪','Deutsch','de-DE'],it:['🇮🇹','Italiano','it-IT'],
      nl:['🇳🇱','Nederlands','nl-NL'],pl:['🇵🇱','Polski','pl-PL'],cs:['🇨🇿','Čeština','cs-CZ'],
      ro:['🇷🇴','Română','ro-RO'],tr:['🇹🇷','Türkçe','tr-TR'],ru:['🇷🇺','Русский','ru-RU'],
      uk:['🇺🇦','Українська','uk-UA'],ja:['🇯🇵','日本語','ja-JP'],ko:['🇰🇷','한국어','ko-KR'],
      'zh-Hans':['🇨🇳','简体中文','zh-CN'],'zh-Hant':['🇹🇼','繁體中文','zh-TW'],yue:['🇭🇰','廣東話','zh-HK'],
      ar:['🇸🇦','العربية','ar-SA'],id:['🇮🇩','Bahasa Indonesia','id-ID']
    };
    const SUPPORTED_LANGS=Object.keys(LANG_META);
    const normalizeLang=raw=>{
      const l=String(raw||'').trim();
      const low=l.toLowerCase();
      if(low==='zh-cn'||low==='zh-hans'||low.startsWith('zh-hans-')||low==='zh-sg')return 'zh-Hans';
      if(low==='zh-tw'||low==='zh-hant'||low.startsWith('zh-hant-'))return 'zh-Hant';
      if(low==='yue'||low.startsWith('yue-')||low==='zh-hk'||low==='zh-mo')return 'yue';
      const short=low.split('-')[0];
      return SUPPORTED_LANGS.includes(short)?short:(SUPPORTED_LANGS.includes(l)?l:'en');
    };
    const defaultLang=()=>normalizeLang(navigator.language||'en');

    const plugin=window.plugin.redactedBannerLab={};

    plugin.state={
      v:7,sid:'',pid:'',name:'BannerLab',c:0,n:0,ppm:6,
      lang:defaultLang(),
      m:[[]],
      direct:true,
      askAction:false,
      classic:true,
      carry:true,
      advanceMode:'ask',
      showOther:true,
      objective:'HACK_PORTAL',
      question:'',
      answer:'',
      panelWidth:300,
      panelX:null,
      panelY:null,
      passSkips:{}
    };

    plugin.collapsed=false;
    plugin.optionsOpen=false;
    plugin.statsOpen=false;
    plugin.statsLoading=false;
    plugin.pendingAdvance=false;
    plugin.selectedGuid=null;
    plugin.lastDirectGuid=null;
    plugin.lastDirectAt=0;
    plugin.reloadRblArmed=false;
    plugin.resetProgressArmed=false;

    const enc=obj=>{
      const b=new TextEncoder().encode(JSON.stringify(obj));
      let s='';
      for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));
      return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    };
    const dec=raw=>{
      let s=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');
      while(s.length%4)s+='=';
      const bin=atob(s),b=Uint8Array.from(bin,c=>c.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(b));
    };

    const normalizePortal=p=>{
      if(!Array.isArray(p))return null;
      return [
        String(p[0]||''),String(p[1]||'Portal'),
        Number(p[2])||0,Number(p[3])||0,String(p[4]||''),
        String(p[5]||'HACK_PORTAL'),String(p[6]||''),String(p[7]||'')
      ];
    };

    const routeSignature=st=>{
      try{
        const n=Math.max(0,parseInt(st?.n)||0);
        const ppm=Math.max(0,parseInt(st?.ppm)||0);
        const missions=Array.isArray(st?.m)?st.m:[];
        const raw=[n,ppm,...missions.map((m,mi)=>`${mi}:`+(Array.isArray(m)?m.map(p=>Array.isArray(p)?String(p[0]||''):'').join(','):''))].join('|');
        let h=2166136261;
        for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
        return 'r'+(h>>>0).toString(16).padStart(8,'0');
      }catch(e){return ''}
    };

    const normalize=st=>{
      st=st&&typeof st==='object'?st:{};
      const rawN=parseInt(st.n);
      const knownTotal=!!String(st.pid||'')&&Number.isFinite(rawN)&&rawN>=1;
      const n=knownTotal?rawN:0;
      const source=Array.isArray(st.m)?st.m:[];
      const count=Math.max(1,n||source.length||1);
      const missions=source.slice(0,count).map(m=>(Array.isArray(m)?m:[]).map(normalizePortal).filter(Boolean));
      while(missions.length<count)missions.push([]);

      return {
        v:7,
        sid:String(st.sid||''),
        pid:String(st.pid||''),
        sourceSig:String(st.sourceSig||routeSignature(st)||''),
        name:String(st.name||'BannerLab'),
        c:Math.max(0,Math.min(missions.length-1,parseInt(st.c)||0)),
        n,
        ppm:Math.max(6,Math.min(24,parseInt(st.ppm)||6)),
        lang:normalizeLang(st.lang||defaultLang()),
        m:missions,
        direct:st.direct!==false,
        askAction:st.askAction===true,
        classic:st.classic!==false,
        carry:st.carry!==false,
        advanceMode:['auto','ask'].includes(st.advanceMode)?st.advanceMode:'ask',
        showOther:st.showOther!==false,
        objective:String(st.objective||'HACK_PORTAL'),
        question:String(st.question||''),
        answer:String(st.answer||''),
        panelWidth:Math.max(230,Math.min(390,Number(st.panelWidth)||300)),
        panelX:Number.isFinite(Number(st.panelX))?Number(st.panelX):null,
        panelY:Number.isFinite(Number(st.panelY))?Number(st.panelY):null,
        passSkips:st.passSkips&&typeof st.passSkips==='object'?st.passSkips:{},
        updatedAt:Number(st.updatedAt)||0
      };
    };

    const TXT={
      fr:{passIncomplete:'Passphrase incomplète',passIncompleteHelp:'Renseigne la question et la réponse avant de quitter ce portail.',completePass:'Compléter',continuePass:'Continuer',skipPass:'Passer tout de même',
        touch:'Touche un portail sur la carte',add:'Ajouter',save:'Enregistrer',remove:'Retirer',
        prev:'Mission',next:'Mission',sync:'Synchroniser BannerLab',options:'Options',hideOptions:'Masquer options',
        direct:'Ajout direct au toucher',askAction:'Demander l’action avant ajout',classic:'Mode bannière classique',
        classicHelp:'1er portail = passphrase · suivants = hack',carry:'Fin précédente → début suivante',
        progression:'Mission complète',askAdvance:'Me demander',autoAdvance:'Passer automatiquement',
        showOther:'Afficher les autres missions',language:'Langue',panelSize:'Largeur du panneau',resetPos:'Recentrer le panneau',
        stats:'Stats parfaitement inutiles',hideStats:'Masquer les stats',action:'Action',
        hack:'Hack',mod:'Installer un mod',capture:'Capture / upgrade',link:'Créer un lien',field:'Créer un champ',
        pass:'Passphrase',question:'Question',answer:'Réponse',missionNumberQuestion:'Quel est le numéro de la mission ?',mission:'Mission',linked:'Projet lié',unknown:'Total inconnu',
        selectedExisting:'Déjà dans cette mission · tu peux modifier son action',duplicateMission:'Déjà présent dans cette mission',
        added:'Portail ajouté',updated:'Action du portail mise à jour',empty:'Mission vide',
        complete:'Mission complète',stay:'Rester ici',goNext:'Mission suivante',chooseAction:'Choisis l’action puis Ajouter',
        carryAdded:'Passphrase de départ reprise automatiquement',routeUnavailable:'Routage piéton indisponible',
        portals:'portails',completeMissions:'missions complètes',activeWalk:'mission à pied',activeTime:'temps mission',
        bannerWalk:'fresque à pied',theoryTime:'temps théorique',transitions:'liaisons missions',civilization:'détour civilisation',
        sporty:'Mission la plus sportive',longestStep:'Étape la plus longue',avgMission:'Moyenne / mission',
        metersPortal:'Mètres / portail',portalsKm:'Portails / km',straight:'Vol d’oiseau cumulé',
        recalc:'Recalculer les stats piétonnes',estimate:'Estimation Valhalla + OpenStreetMap · pas un GPS',
        cached:'Résultat en cache',calculated:'Calculé maintenant',needTwo:'Ajoute au moins deux portails',
        otherRoutes:'Autres missions',activeRoute:'Mission sélectionnée'
      },
      en:{passIncomplete:'Incomplete passphrase',passIncompleteHelp:'Enter the question and answer before leaving this portal.',completePass:'Complete',continuePass:'Continue',skipPass:'Skip anyway',
        touch:'Tap a portal on the map',add:'Add',save:'Save',remove:'Remove',
        prev:'Mission',next:'Mission',sync:'Sync BannerLab',options:'Options',hideOptions:'Hide options',
        direct:'Direct add on tap',askAction:'Ask action before adding',classic:'Classic banner mode',
        classicHelp:'1st portal = passphrase · next = hack',carry:'Previous end → next start',
        progression:'When mission is complete',askAdvance:'Ask me',autoAdvance:'Advance automatically',
        showOther:'Show other missions',language:'Language',panelSize:'Panel width',resetPos:'Reset panel position',
        stats:'Perfectly useless stats',hideStats:'Hide stats',action:'Action',
        hack:'Hack',mod:'Install mod',capture:'Capture / upgrade',link:'Create link',field:'Create field',
        pass:'Passphrase',question:'Question',answer:'Answer',missionNumberQuestion:'What is the mission number?',mission:'Mission',linked:'Linked project',unknown:'Unknown total',
        selectedExisting:'Already in this mission · edit its action here',duplicateMission:'Already in this mission',
        added:'Portal added',updated:'Portal action updated',empty:'Empty mission',
        complete:'Mission complete',stay:'Stay here',goNext:'Next mission',chooseAction:'Choose the action, then Add',
        carryAdded:'Starting passphrase reused automatically',routeUnavailable:'Walking route unavailable',
        portals:'portals',completeMissions:'complete missions',activeWalk:'mission walking',activeTime:'mission time',
        bannerWalk:'banner walking',theoryTime:'theoretical time',transitions:'between missions',civilization:'civilization detour',
        sporty:'Longest mission',longestStep:'Longest leg',avgMission:'Average / mission',
        metersPortal:'Meters / portal',portalsKm:'Portals / km',straight:'Straight-line total',
        recalc:'Recalculate walking stats',estimate:'Valhalla + OpenStreetMap estimate · not GPS',
        cached:'Cached result',calculated:'Calculated now',needTwo:'Add at least two portals',
        otherRoutes:'Other missions',activeRoute:'Selected mission'
      },
      es:{passIncomplete:'Contraseña incompleta',passIncompleteHelp:'Rellena la pregunta y la respuesta antes de salir de este portal.',completePass:'Completar',continuePass:'Continuar',skipPass:'Continuar de todos modos',
        touch:'Toca un portal en el mapa',add:'Añadir',save:'Guardar',remove:'Quitar',
        prev:'Misión',next:'Misión',sync:'Sincronizar BannerLab',options:'Opciones',hideOptions:'Ocultar opciones',
        direct:'Añadir directamente al tocar',askAction:'Preguntar acción antes de añadir',classic:'Modo banner clásico',
        classicHelp:'1er portal = contraseña · siguientes = hack',carry:'Final anterior → inicio siguiente',
        progression:'Al completar la misión',askAdvance:'Preguntarme',autoAdvance:'Pasar automáticamente',
        showOther:'Mostrar otras misiones',language:'Idioma',panelSize:'Ancho del panel',resetPos:'Restablecer posición',
        stats:'Estadísticas perfectamente inútiles',hideStats:'Ocultar estadísticas',action:'Acción',
        hack:'Hackear',mod:'Instalar mod',capture:'Capturar / mejorar',link:'Crear enlace',field:'Crear campo',
        pass:'Contraseña',question:'Pregunta',answer:'Respuesta',missionNumberQuestion:'¿Cuál es el número de la misión?',mission:'Misión',linked:'Proyecto vinculado',unknown:'Total desconocido',
        selectedExisting:'Ya está en esta misión · puedes modificar su acción',duplicateMission:'Ya está en esta misión',
        added:'Portal añadido',updated:'Acción del portal actualizada',empty:'Misión vacía',
        complete:'Misión completa',stay:'Quedarme aquí',goNext:'Misión siguiente',chooseAction:'Elige la acción y pulsa Añadir',
        carryAdded:'Contraseña inicial reutilizada automáticamente',routeUnavailable:'Ruta peatonal no disponible',
        portals:'portales',completeMissions:'misiones completas',activeWalk:'misión a pie',activeTime:'tiempo misión',
        bannerWalk:'banner a pie',theoryTime:'tiempo teórico',transitions:'entre misiones',civilization:'desvío civilización',
        sporty:'Misión más larga',longestStep:'Tramo más largo',avgMission:'Media / misión',
        metersPortal:'Metros / portal',portalsKm:'Portales / km',straight:'Total en línea recta',
        recalc:'Recalcular estadísticas a pie',estimate:'Estimación Valhalla + OpenStreetMap · no es GPS',
        cached:'Resultado en caché',calculated:'Calculado ahora',needTwo:'Añade al menos dos portales',
        otherRoutes:'Otras misiones',activeRoute:'Misión seleccionada'
      }
    };

    Object.assign(TXT,{"pt":{"passIncomplete":"Passphrase incompleta","passIncompleteHelp":"Preenche a pergunta e a resposta antes de saíres deste portal.","completePass":"Completar","continuePass":"Continuar","skipPass":"Continuar na mesma","touch":"Toca num portal no mapa","add":"Adicionar","save":"Guardar","remove":"Remover","prev":"Missão","next":"Missão","sync":"Sincronizar BannerLab","options":"Opções","hideOptions":"Ocultar opções","direct":"Adicionar diretamente ao tocar","askAction":"Perguntar a ação antes de adicionar","classic":"Modo banner clássico","classicHelp":"1.º portal = passphrase · seguintes = hack","carry":"Fim anterior → início seguinte","progression":"Quando a missão estiver completa","askAdvance":"Perguntar-me","autoAdvance":"Avançar automaticamente","showOther":"Mostrar outras missões","language":"Idioma","panelSize":"Largura do painel","resetPos":"Recentrar o painel","stats":"Estatísticas perfeitamente inúteis","hideStats":"Ocultar estatísticas","action":"Ação","hack":"Hack","mod":"Instalar mod","capture":"Capturar / melhorar","link":"Criar ligação","field":"Criar campo","pass":"Passphrase","question":"Pergunta","answer":"Resposta","missionNumberQuestion":"Qual é o número da missão?","mission":"Missão","linked":"Projeto associado","unknown":"Total desconhecido","selectedExisting":"Já está nesta missão · podes alterar a ação aqui","duplicateMission":"Já está nesta missão","added":"Portal adicionado","updated":"Ação do portal atualizada","empty":"Missão vazia","complete":"Missão completa","stay":"Ficar aqui","goNext":"Missão seguinte","chooseAction":"Escolhe a ação e depois toca em Adicionar","carryAdded":"Passphrase inicial reutilizada automaticamente","routeUnavailable":"Percurso pedonal indisponível","portals":"portais","completeMissions":"missões completas","activeWalk":"percurso da missão","activeTime":"tempo da missão","bannerWalk":"percurso do banner","theoryTime":"tempo teórico","transitions":"entre missões","civilization":"desvio pela civilização","sporty":"Missão mais longa","longestStep":"Troço mais longo","avgMission":"Média / missão","metersPortal":"Metros / portal","portalsKm":"Portais / km","straight":"Total em linha reta","recalc":"Recalcular estatísticas pedonais","estimate":"Estimativa Valhalla + OpenStreetMap · não é GPS","cached":"Resultado em cache","calculated":"Calculado agora","needTwo":"Adiciona pelo menos dois portais","otherRoutes":"Outras missões","activeRoute":"Missão selecionada"},"de":{"passIncomplete":"Unvollständige Passphrase","passIncompleteHelp":"Trage Frage und Antwort ein, bevor du dieses Portal verlässt.","completePass":"Vervollständigen","continuePass":"Weiter","skipPass":"Trotzdem fortfahren","touch":"Tippe auf ein Portal auf der Karte","add":"Hinzufügen","save":"Speichern","remove":"Entfernen","prev":"Mission","next":"Mission","sync":"BannerLab synchronisieren","options":"Optionen","hideOptions":"Optionen ausblenden","direct":"Beim Antippen direkt hinzufügen","askAction":"Vor dem Hinzufügen nach der Aktion fragen","classic":"Klassischer Banner-Modus","classicHelp":"1. Portal = Passphrase · weitere = Hack","carry":"Vorheriges Ende → nächster Start","progression":"Wenn die Mission vollständig ist","askAdvance":"Nachfragen","autoAdvance":"Automatisch weiter","showOther":"Andere Missionen anzeigen","language":"Sprache","panelSize":"Panelbreite","resetPos":"Panel zurücksetzen","stats":"Herrlich nutzlose Statistiken","hideStats":"Statistiken ausblenden","action":"Aktion","hack":"Hacken","mod":"Mod installieren","capture":"Erobern / aufwerten","link":"Link erstellen","field":"Feld erstellen","pass":"Passphrase","question":"Frage","answer":"Antwort","missionNumberQuestion":"Wie lautet die Missionsnummer?","mission":"Mission","linked":"Verknüpftes Projekt","unknown":"Gesamtzahl unbekannt","selectedExisting":"Bereits in dieser Mission · Aktion hier bearbeiten","duplicateMission":"Bereits in dieser Mission","added":"Portal hinzugefügt","updated":"Portalaktion aktualisiert","empty":"Leere Mission","complete":"Mission abgeschlossen","stay":"Hier bleiben","goNext":"Nächste Mission","chooseAction":"Aktion auswählen und dann Hinzufügen tippen","carryAdded":"Start-Passphrase automatisch übernommen","routeUnavailable":"Fußwegroute nicht verfügbar","portals":"Portale","completeMissions":"abgeschlossene Missionen","activeWalk":"Fußweg der Mission","activeTime":"Missionszeit","bannerWalk":"Fußweg des Banners","theoryTime":"theoretische Zeit","transitions":"zwischen Missionen","civilization":"Umweg durch die Zivilisation","sporty":"Längste Mission","longestStep":"Längster Abschnitt","avgMission":"Durchschnitt / Mission","metersPortal":"Meter / Portal","portalsKm":"Portale / km","straight":"Luftlinie gesamt","recalc":"Fußweg-Statistiken neu berechnen","estimate":"Schätzung mit Valhalla + OpenStreetMap · kein GPS","cached":"Zwischengespeichertes Ergebnis","calculated":"Gerade berechnet","needTwo":"Füge mindestens zwei Portale hinzu","otherRoutes":"Andere Missionen","activeRoute":"Ausgewählte Mission"},"it":{"passIncomplete":"Passphrase incompleta","passIncompleteHelp":"Inserisci domanda e risposta prima di lasciare questo portale.","completePass":"Completa","continuePass":"Continua","skipPass":"Continua comunque","touch":"Tocca un portale sulla mappa","add":"Aggiungi","save":"Salva","remove":"Rimuovi","prev":"Missione","next":"Missione","sync":"Sincronizza BannerLab","options":"Opzioni","hideOptions":"Nascondi opzioni","direct":"Aggiungi direttamente al tocco","askAction":"Chiedi l'azione prima di aggiungere","classic":"Modalità banner classica","classicHelp":"1° portale = passphrase · successivi = hack","carry":"Fine precedente → inizio successivo","progression":"Quando la missione è completa","askAdvance":"Chiedimelo","autoAdvance":"Avanza automaticamente","showOther":"Mostra altre missioni","language":"Lingua","panelSize":"Larghezza pannello","resetPos":"Ricentra pannello","stats":"Statistiche perfettamente inutili","hideStats":"Nascondi statistiche","action":"Azione","hack":"Hack","mod":"Installa mod","capture":"Cattura / potenzia","link":"Crea link","field":"Crea campo","pass":"Passphrase","question":"Domanda","answer":"Risposta","missionNumberQuestion":"Qual è il numero della missione?","mission":"Missione","linked":"Progetto collegato","unknown":"Totale sconosciuto","selectedExisting":"Già in questa missione · modifica qui l'azione","duplicateMission":"Già presente in questa missione","added":"Portale aggiunto","updated":"Azione del portale aggiornata","empty":"Missione vuota","complete":"Missione completa","stay":"Resta qui","goNext":"Missione successiva","chooseAction":"Scegli l'azione, poi premi Aggiungi","carryAdded":"Passphrase iniziale riutilizzata automaticamente","routeUnavailable":"Percorso pedonale non disponibile","portals":"portali","completeMissions":"missioni complete","activeWalk":"percorso missione","activeTime":"tempo missione","bannerWalk":"percorso banner","theoryTime":"tempo teorico","transitions":"tra missioni","civilization":"deviazione civiltà","sporty":"Missione più lunga","longestStep":"Tratto più lungo","avgMission":"Media / missione","metersPortal":"Metri / portale","portalsKm":"Portali / km","straight":"Totale in linea d'aria","recalc":"Ricalcola statistiche a piedi","estimate":"Stima Valhalla + OpenStreetMap · non è un GPS","cached":"Risultato in cache","calculated":"Calcolato ora","needTwo":"Aggiungi almeno due portali","otherRoutes":"Altre missioni","activeRoute":"Missione selezionata"},"nl":{"passIncomplete":"Onvolledige passphrase","passIncompleteHelp":"Vul de vraag en het antwoord in voordat je dit portal verlaat.","completePass":"Aanvullen","continuePass":"Doorgaan","skipPass":"Toch doorgaan","touch":"Tik op een portal op de kaart","add":"Toevoegen","save":"Opslaan","remove":"Verwijderen","prev":"Missie","next":"Missie","sync":"BannerLab synchroniseren","options":"Opties","hideOptions":"Opties verbergen","direct":"Direct toevoegen bij tikken","askAction":"Actie vragen vóór toevoegen","classic":"Klassieke bannermodus","classicHelp":"1e portal = passphrase · volgende = hack","carry":"Vorig einde → volgende start","progression":"Wanneer de missie compleet is","askAdvance":"Vraag het mij","autoAdvance":"Automatisch doorgaan","showOther":"Andere missies tonen","language":"Taal","panelSize":"Paneelbreedte","resetPos":"Paneel opnieuw centreren","stats":"Volkomen nutteloze statistieken","hideStats":"Statistieken verbergen","action":"Actie","hack":"Hack","mod":"Mod installeren","capture":"Veroveren / upgraden","link":"Link maken","field":"Veld maken","pass":"Passphrase","question":"Vraag","answer":"Antwoord","missionNumberQuestion":"Wat is het missienummer?","mission":"Missie","linked":"Gekoppeld project","unknown":"Totaal onbekend","selectedExisting":"Staat al in deze missie · pas de actie hier aan","duplicateMission":"Staat al in deze missie","added":"Portal toegevoegd","updated":"Portalactie bijgewerkt","empty":"Lege missie","complete":"Missie compleet","stay":"Hier blijven","goNext":"Volgende missie","chooseAction":"Kies de actie en tik daarna op Toevoegen","carryAdded":"Startpassphrase automatisch hergebruikt","routeUnavailable":"Wandelroute niet beschikbaar","portals":"portals","completeMissions":"voltooide missies","activeWalk":"wandeling missie","activeTime":"missietijd","bannerWalk":"wandeling banner","theoryTime":"theoretische tijd","transitions":"tussen missies","civilization":"omweg door de beschaving","sporty":"Langste missie","longestStep":"Langste traject","avgMission":"Gemiddelde / missie","metersPortal":"Meter / portal","portalsKm":"Portals / km","straight":"Totale hemelsbrede afstand","recalc":"Wandelstatistieken opnieuw berekenen","estimate":"Schatting via Valhalla + OpenStreetMap · geen GPS","cached":"Resultaat uit cache","calculated":"Zojuist berekend","needTwo":"Voeg minstens twee portals toe","otherRoutes":"Andere missies","activeRoute":"Geselecteerde missie"},"pl":{"passIncomplete":"Niekompletna passphrase","passIncompleteHelp":"Uzupełnij pytanie i odpowiedź przed opuszczeniem tego portalu.","completePass":"Uzupełnij","continuePass":"Dalej","skipPass":"Mimo to kontynuuj","touch":"Dotknij portalu na mapie","add":"Dodaj","save":"Zapisz","remove":"Usuń","prev":"Misja","next":"Misja","sync":"Synchronizuj BannerLab","options":"Opcje","hideOptions":"Ukryj opcje","direct":"Dodawaj bezpośrednio po dotknięciu","askAction":"Pytaj o akcję przed dodaniem","classic":"Klasyczny tryb bannera","classicHelp":"1. portal = passphrase · kolejne = hack","carry":"Poprzedni koniec → następny start","progression":"Po ukończeniu misji","askAdvance":"Zapytaj mnie","autoAdvance":"Przejdź automatycznie","showOther":"Pokaż inne misje","language":"Język","panelSize":"Szerokość panelu","resetPos":"Wyśrodkuj panel","stats":"Idealnie bezużyteczne statystyki","hideStats":"Ukryj statystyki","action":"Akcja","hack":"Hack","mod":"Zainstaluj mod","capture":"Przejmij / ulepsz","link":"Utwórz link","field":"Utwórz pole","pass":"Passphrase","question":"Pytanie","answer":"Odpowiedź","missionNumberQuestion":"Jaki jest numer misji?","mission":"Misja","linked":"Powiązany projekt","unknown":"Nieznana liczba","selectedExisting":"Już jest w tej misji · tutaj możesz zmienić akcję","duplicateMission":"Już jest w tej misji","added":"Portal dodany","updated":"Akcja portalu zaktualizowana","empty":"Pusta misja","complete":"Misja ukończona","stay":"Zostań tutaj","goNext":"Następna misja","chooseAction":"Wybierz akcję, a potem Dodaj","carryAdded":"Początkowa passphrase użyta ponownie automatycznie","routeUnavailable":"Trasa piesza niedostępna","portals":"portale","completeMissions":"ukończone misje","activeWalk":"trasa misji","activeTime":"czas misji","bannerWalk":"trasa bannera","theoryTime":"czas teoretyczny","transitions":"między misjami","civilization":"objazd przez cywilizację","sporty":"Najdłuższa misja","longestStep":"Najdłuższy odcinek","avgMission":"Średnio / misję","metersPortal":"Metry / portal","portalsKm":"Portale / km","straight":"Łącznie w linii prostej","recalc":"Przelicz statystyki piesze","estimate":"Szacunek Valhalla + OpenStreetMap · to nie GPS","cached":"Wynik z pamięci podręcznej","calculated":"Obliczono teraz","needTwo":"Dodaj co najmniej dwa portale","otherRoutes":"Inne misje","activeRoute":"Wybrana misja"},"cs":{"passIncomplete":"Neúplná passphrase","passIncompleteHelp":"Než tento portál opustíš, vyplň otázku i odpověď.","completePass":"Doplnit","continuePass":"Pokračovat","skipPass":"Přesto pokračovat","touch":"Klepni na portál na mapě","add":"Přidat","save":"Uložit","remove":"Odebrat","prev":"Mise","next":"Mise","sync":"Synchronizovat BannerLab","options":"Možnosti","hideOptions":"Skrýt možnosti","direct":"Přidat rovnou po klepnutí","askAction":"Před přidáním se zeptat na akci","classic":"Klasický režim banneru","classicHelp":"1. portál = passphrase · další = hack","carry":"Předchozí konec → další start","progression":"Po dokončení mise","askAdvance":"Zeptat se mě","autoAdvance":"Přejít automaticky","showOther":"Zobrazit ostatní mise","language":"Jazyk","panelSize":"Šířka panelu","resetPos":"Vycentrovat panel","stats":"Dokonale zbytečné statistiky","hideStats":"Skrýt statistiky","action":"Akce","hack":"Hack","mod":"Nainstalovat mod","capture":"Obsadit / vylepšit","link":"Vytvořit link","field":"Vytvořit pole","pass":"Passphrase","question":"Otázka","answer":"Odpověď","missionNumberQuestion":"Jaké je číslo mise?","mission":"Mise","linked":"Propojený projekt","unknown":"Neznámý celkový počet","selectedExisting":"Už je v této misi · akci můžeš upravit zde","duplicateMission":"Už je v této misi","added":"Portál přidán","updated":"Akce portálu aktualizována","empty":"Prázdná mise","complete":"Mise dokončena","stay":"Zůstat zde","goNext":"Další mise","chooseAction":"Vyber akci a potom klepni na Přidat","carryAdded":"Úvodní passphrase použita automaticky znovu","routeUnavailable":"Pěší trasa není dostupná","portals":"portály","completeMissions":"dokončené mise","activeWalk":"pěší trasa mise","activeTime":"čas mise","bannerWalk":"pěší trasa banneru","theoryTime":"teoretický čas","transitions":"mezi misemi","civilization":"civilizační zacházka","sporty":"Nejdelší mise","longestStep":"Nejdelší úsek","avgMission":"Průměr / mise","metersPortal":"Metry / portál","portalsKm":"Portály / km","straight":"Celkem vzdušnou čarou","recalc":"Přepočítat pěší statistiky","estimate":"Odhad Valhalla + OpenStreetMap · není to GPS","cached":"Výsledek z mezipaměti","calculated":"Právě spočítáno","needTwo":"Přidej alespoň dva portály","otherRoutes":"Ostatní mise","activeRoute":"Vybraná mise"},"ro":{"passIncomplete":"Passphrase incompletă","passIncompleteHelp":"Completează întrebarea și răspunsul înainte să părăsești acest portal.","completePass":"Completează","continuePass":"Continuă","skipPass":"Continuă oricum","touch":"Atinge un portal pe hartă","add":"Adaugă","save":"Salvează","remove":"Elimină","prev":"Misiune","next":"Misiune","sync":"Sincronizează BannerLab","options":"Opțiuni","hideOptions":"Ascunde opțiunile","direct":"Adaugă direct la atingere","askAction":"Întreabă acțiunea înainte de adăugare","classic":"Mod banner clasic","classicHelp":"primul portal = passphrase · următoarele = hack","carry":"Sfârșitul anterior → începutul următor","progression":"Când misiunea este completă","askAdvance":"Întreabă-mă","autoAdvance":"Treci automat","showOther":"Arată celelalte misiuni","language":"Limbă","panelSize":"Lățimea panoului","resetPos":"Recentrează panoul","stats":"Statistici perfect inutile","hideStats":"Ascunde statisticile","action":"Acțiune","hack":"Hack","mod":"Instalează mod","capture":"Capturează / îmbunătățește","link":"Creează link","field":"Creează câmp","pass":"Passphrase","question":"Întrebare","answer":"Răspuns","missionNumberQuestion":"Care este numărul misiunii?","mission":"Misiune","linked":"Proiect asociat","unknown":"Total necunoscut","selectedExisting":"Este deja în această misiune · poți modifica acțiunea aici","duplicateMission":"Este deja în această misiune","added":"Portal adăugat","updated":"Acțiunea portalului a fost actualizată","empty":"Misiune goală","complete":"Misiune completă","stay":"Rămâi aici","goNext":"Misiunea următoare","chooseAction":"Alege acțiunea, apoi apasă Adaugă","carryAdded":"Passphrase de început reutilizată automat","routeUnavailable":"Ruta pietonală nu este disponibilă","portals":"portaluri","completeMissions":"misiuni complete","activeWalk":"traseul misiunii","activeTime":"timpul misiunii","bannerWalk":"traseul bannerului","theoryTime":"timp teoretic","transitions":"între misiuni","civilization":"ocol prin civilizație","sporty":"Cea mai lungă misiune","longestStep":"Cel mai lung segment","avgMission":"Medie / misiune","metersPortal":"Metri / portal","portalsKm":"Portaluri / km","straight":"Total în linie dreaptă","recalc":"Recalculează statisticile de mers","estimate":"Estimare Valhalla + OpenStreetMap · nu este GPS","cached":"Rezultat din cache","calculated":"Calculat acum","needTwo":"Adaugă cel puțin două portaluri","otherRoutes":"Alte misiuni","activeRoute":"Misiunea selectată"},"tr":{"passIncomplete":"Eksik passphrase","passIncompleteHelp":"Bu portaldan ayrılmadan önce soru ve cevabı doldur.","completePass":"Tamamla","continuePass":"Devam et","skipPass":"Yine de devam et","touch":"Haritadaki bir portala dokun","add":"Ekle","save":"Kaydet","remove":"Kaldır","prev":"Görev","next":"Görev","sync":"BannerLab'i eşitle","options":"Seçenekler","hideOptions":"Seçenekleri gizle","direct":"Dokununca doğrudan ekle","askAction":"Eklemeden önce eylemi sor","classic":"Klasik banner modu","classicHelp":"1. portal = passphrase · sonrakiler = hack","carry":"Önceki bitiş → sonraki başlangıç","progression":"Görev tamamlandığında","askAdvance":"Bana sor","autoAdvance":"Otomatik ilerle","showOther":"Diğer görevleri göster","language":"Dil","panelSize":"Panel genişliği","resetPos":"Paneli yeniden ortala","stats":"Mükemmel derecede gereksiz istatistikler","hideStats":"İstatistikleri gizle","action":"Eylem","hack":"Hack","mod":"Mod yükle","capture":"Ele geçir / yükselt","link":"Link oluştur","field":"Alan oluştur","pass":"Passphrase","question":"Soru","answer":"Cevap","missionNumberQuestion":"Görev numarası nedir?","mission":"Görev","linked":"Bağlı proje","unknown":"Toplam bilinmiyor","selectedExisting":"Bu görevde zaten var · eylemini buradan değiştirebilirsin","duplicateMission":"Bu görevde zaten var","added":"Portal eklendi","updated":"Portal eylemi güncellendi","empty":"Boş görev","complete":"Görev tamamlandı","stay":"Burada kal","goNext":"Sonraki görev","chooseAction":"Eylemi seç, ardından Ekle'ye dokun","carryAdded":"Başlangıç passphrase'i otomatik yeniden kullanıldı","routeUnavailable":"Yürüyüş rotası kullanılamıyor","portals":"portal","completeMissions":"tamamlanan görev","activeWalk":"görev yürüyüşü","activeTime":"görev süresi","bannerWalk":"banner yürüyüşü","theoryTime":"teorik süre","transitions":"görevler arası","civilization":"medeniyet sapması","sporty":"En uzun görev","longestStep":"En uzun etap","avgMission":"Ortalama / görev","metersPortal":"Metre / portal","portalsKm":"Portal / km","straight":"Toplam kuş uçuşu","recalc":"Yürüyüş istatistiklerini yeniden hesapla","estimate":"Valhalla + OpenStreetMap tahmini · GPS değildir","cached":"Önbellekteki sonuç","calculated":"Şimdi hesaplandı","needTwo":"En az iki portal ekle","otherRoutes":"Diğer görevler","activeRoute":"Seçili görev"},"ru":{"passIncomplete":"Неполная passphrase","passIncompleteHelp":"Заполни вопрос и ответ, прежде чем покинуть этот портал.","completePass":"Заполнить","continuePass":"Продолжить","skipPass":"Всё равно продолжить","touch":"Нажми на портал на карте","add":"Добавить","save":"Сохранить","remove":"Удалить","prev":"Миссия","next":"Миссия","sync":"Синхронизировать BannerLab","options":"Настройки","hideOptions":"Скрыть настройки","direct":"Добавлять сразу по нажатию","askAction":"Спрашивать действие перед добавлением","classic":"Классический режим баннера","classicHelp":"1-й портал = passphrase · следующие = hack","carry":"Предыдущий финиш → следующий старт","progression":"Когда миссия завершена","askAdvance":"Спросить меня","autoAdvance":"Переходить автоматически","showOther":"Показывать другие миссии","language":"Язык","panelSize":"Ширина панели","resetPos":"Вернуть панель в центр","stats":"Совершенно бесполезная статистика","hideStats":"Скрыть статистику","action":"Действие","hack":"Хак","mod":"Установить мод","capture":"Захватить / улучшить","link":"Создать линк","field":"Создать поле","pass":"Passphrase","question":"Вопрос","answer":"Ответ","missionNumberQuestion":"Какой номер миссии?","mission":"Миссия","linked":"Связанный проект","unknown":"Общее число неизвестно","selectedExisting":"Уже есть в этой миссии · действие можно изменить здесь","duplicateMission":"Уже есть в этой миссии","added":"Портал добавлен","updated":"Действие портала обновлено","empty":"Пустая миссия","complete":"Миссия завершена","stay":"Остаться здесь","goNext":"Следующая миссия","chooseAction":"Выбери действие, затем нажми «Добавить»","carryAdded":"Стартовая passphrase автоматически использована повторно","routeUnavailable":"Пешеходный маршрут недоступен","portals":"порталы","completeMissions":"завершённые миссии","activeWalk":"путь миссии","activeTime":"время миссии","bannerWalk":"путь баннера","theoryTime":"теоретическое время","transitions":"между миссиями","civilization":"обход по цивилизации","sporty":"Самая длинная миссия","longestStep":"Самый длинный участок","avgMission":"Среднее / миссия","metersPortal":"Метры / портал","portalsKm":"Порталы / км","straight":"Всего по прямой","recalc":"Пересчитать статистику ходьбы","estimate":"Оценка Valhalla + OpenStreetMap · это не GPS","cached":"Результат из кэша","calculated":"Рассчитано сейчас","needTwo":"Добавь хотя бы два портала","otherRoutes":"Другие миссии","activeRoute":"Выбранная миссия"},"uk":{"passIncomplete":"Неповна passphrase","passIncompleteHelp":"Заповни питання й відповідь, перш ніж залишити цей портал.","completePass":"Заповнити","continuePass":"Продовжити","skipPass":"Усе одно продовжити","touch":"Торкнися порталу на карті","add":"Додати","save":"Зберегти","remove":"Видалити","prev":"Місія","next":"Місія","sync":"Синхронізувати BannerLab","options":"Налаштування","hideOptions":"Сховати налаштування","direct":"Додавати одразу після дотику","askAction":"Запитувати дію перед додаванням","classic":"Класичний режим банера","classicHelp":"1-й портал = passphrase · наступні = hack","carry":"Попередній фініш → наступний старт","progression":"Коли місію завершено","askAdvance":"Запитати мене","autoAdvance":"Переходити автоматично","showOther":"Показувати інші місії","language":"Мова","panelSize":"Ширина панелі","resetPos":"Відцентрувати панель","stats":"Абсолютно непотрібна статистика","hideStats":"Сховати статистику","action":"Дія","hack":"Хак","mod":"Встановити мод","capture":"Захопити / покращити","link":"Створити лінк","field":"Створити поле","pass":"Passphrase","question":"Питання","answer":"Відповідь","missionNumberQuestion":"Який номер місії?","mission":"Місія","linked":"Пов’язаний проєкт","unknown":"Загальна кількість невідома","selectedExisting":"Уже є в цій місії · дію можна змінити тут","duplicateMission":"Уже є в цій місії","added":"Портал додано","updated":"Дію порталу оновлено","empty":"Порожня місія","complete":"Місію завершено","stay":"Залишитися тут","goNext":"Наступна місія","chooseAction":"Обери дію, потім натисни «Додати»","carryAdded":"Стартову passphrase автоматично використано повторно","routeUnavailable":"Пішохідний маршрут недоступний","portals":"портали","completeMissions":"завершені місії","activeWalk":"шлях місії","activeTime":"час місії","bannerWalk":"шлях банера","theoryTime":"теоретичний час","transitions":"між місіями","civilization":"обхід через цивілізацію","sporty":"Найдовша місія","longestStep":"Найдовший відрізок","avgMission":"Середнє / місія","metersPortal":"Метри / портал","portalsKm":"Портали / км","straight":"Усього по прямій","recalc":"Перерахувати статистику ходьби","estimate":"Оцінка Valhalla + OpenStreetMap · це не GPS","cached":"Результат із кешу","calculated":"Щойно обчислено","needTwo":"Додай щонайменше два портали","otherRoutes":"Інші місії","activeRoute":"Вибрана місія"},"ja":{"passIncomplete":"パスフレーズが未完成です","passIncompleteHelp":"このポータルを離れる前に、質問と答えを入力してください。","completePass":"入力する","continuePass":"続ける","skipPass":"そのまま続ける","touch":"地図上のポータルをタップ","add":"追加","save":"保存","remove":"削除","prev":"ミッション","next":"ミッション","sync":"BannerLabと同期","options":"オプション","hideOptions":"オプションを隠す","direct":"タップしたポータルを直接追加","askAction":"追加前にアクションを確認","classic":"クラシック・バナーモード","classicHelp":"最初のポータル = パスフレーズ · 以降 = ハック","carry":"前の終了 → 次の開始","progression":"ミッション完了時","askAdvance":"確認する","autoAdvance":"自動で次へ","showOther":"ほかのミッションを表示","language":"言語","panelSize":"パネル幅","resetPos":"パネルを中央に戻す","stats":"見事に役に立たない統計","hideStats":"統計を隠す","action":"アクション","hack":"ハック","mod":"MODを設置","capture":"キャプチャ / アップグレード","link":"リンクを作成","field":"フィールドを作成","pass":"パスフレーズ","question":"質問","answer":"答え","missionNumberQuestion":"ミッション番号は？","mission":"ミッション","linked":"リンク中のプロジェクト","unknown":"合計不明","selectedExisting":"このミッションに登録済み · ここでアクションを変更できます","duplicateMission":"このミッションに登録済み","added":"ポータルを追加しました","updated":"ポータルのアクションを更新しました","empty":"空のミッション","complete":"ミッション完了","stay":"ここに留まる","goNext":"次のミッション","chooseAction":"アクションを選んでから「追加」をタップ","carryAdded":"開始パスフレーズを自動で引き継ぎました","routeUnavailable":"徒歩ルートを取得できません","portals":"ポータル","completeMissions":"完了ミッション","activeWalk":"ミッション徒歩距離","activeTime":"ミッション所要時間","bannerWalk":"バナー徒歩距離","theoryTime":"理論上の時間","transitions":"ミッション間","civilization":"文明的な遠回り","sporty":"最長ミッション","longestStep":"最長区間","avgMission":"平均 / ミッション","metersPortal":"メートル / ポータル","portalsKm":"ポータル / km","straight":"直線距離の合計","recalc":"徒歩統計を再計算","estimate":"Valhalla + OpenStreetMapによる推定 · GPSではありません","cached":"キャッシュ済み","calculated":"今計算しました","needTwo":"ポータルを2つ以上追加してください","otherRoutes":"ほかのミッション","activeRoute":"選択中のミッション"},"ko":{"passIncomplete":"패스프레이즈가 완성되지 않았습니다","passIncompleteHelp":"이 포털을 떠나기 전에 질문과 답을 입력하세요.","completePass":"완성","continuePass":"계속","skipPass":"그냥 계속","touch":"지도에서 포털을 탭하세요","add":"추가","save":"저장","remove":"삭제","prev":"미션","next":"미션","sync":"BannerLab 동기화","options":"옵션","hideOptions":"옵션 숨기기","direct":"탭하면 바로 추가","askAction":"추가 전에 액션 묻기","classic":"클래식 배너 모드","classicHelp":"첫 포털 = 패스프레이즈 · 이후 = 해킹","carry":"이전 종료 → 다음 시작","progression":"미션 완료 시","askAdvance":"물어보기","autoAdvance":"자동으로 이동","showOther":"다른 미션 표시","language":"언어","panelSize":"패널 너비","resetPos":"패널 위치 초기화","stats":"완벽하게 쓸모없는 통계","hideStats":"통계 숨기기","action":"액션","hack":"해킹","mod":"모드 설치","capture":"점령 / 업그레이드","link":"링크 생성","field":"필드 생성","pass":"패스프레이즈","question":"질문","answer":"답","missionNumberQuestion":"미션 번호는 무엇인가요?","mission":"미션","linked":"연결된 프로젝트","unknown":"전체 수 미상","selectedExisting":"이미 이 미션에 있습니다 · 여기서 액션을 수정할 수 있습니다","duplicateMission":"이미 이 미션에 있습니다","added":"포털 추가됨","updated":"포털 액션 업데이트됨","empty":"빈 미션","complete":"미션 완료","stay":"여기에 있기","goNext":"다음 미션","chooseAction":"액션을 선택한 다음 추가를 탭하세요","carryAdded":"시작 패스프레이즈를 자동으로 재사용했습니다","routeUnavailable":"도보 경로를 사용할 수 없습니다","portals":"포털","completeMissions":"완료된 미션","activeWalk":"미션 도보 거리","activeTime":"미션 시간","bannerWalk":"배너 도보 거리","theoryTime":"이론 시간","transitions":"미션 사이","civilization":"문명 우회","sporty":"가장 긴 미션","longestStep":"가장 긴 구간","avgMission":"평균 / 미션","metersPortal":"미터 / 포털","portalsKm":"포털 / km","straight":"직선거리 합계","recalc":"도보 통계 다시 계산","estimate":"Valhalla + OpenStreetMap 추정치 · GPS가 아닙니다","cached":"캐시된 결과","calculated":"방금 계산됨","needTwo":"포털을 두 개 이상 추가하세요","otherRoutes":"다른 미션","activeRoute":"선택된 미션"},"zh-Hans":{"passIncomplete":"口令未填写完整","passIncompleteHelp":"离开这个传送门前，请先填写问题和答案。","completePass":"补全","continuePass":"继续","skipPass":"仍然继续","touch":"点击地图上的传送门","add":"添加","save":"保存","remove":"移除","prev":"任务","next":"任务","sync":"同步 BannerLab","options":"选项","hideOptions":"隐藏选项","direct":"点击时直接添加","askAction":"添加前询问动作","classic":"经典 Banner 模式","classicHelp":"第 1 个传送门 = 口令 · 后续 = Hack","carry":"上一任务终点 → 下一任务起点","progression":"任务完成时","askAdvance":"询问我","autoAdvance":"自动进入下一任务","showOther":"显示其他任务","language":"语言","panelSize":"面板宽度","resetPos":"重置面板位置","stats":"完美无用的统计","hideStats":"隐藏统计","action":"动作","hack":"Hack","mod":"安装 Mod","capture":"占领 / 升级","link":"创建链接","field":"创建控制场","pass":"口令","question":"问题","answer":"答案","missionNumberQuestion":"任务编号是多少？","mission":"任务","linked":"已关联项目","unknown":"总数未知","selectedExisting":"已在此任务中 · 可在这里修改动作","duplicateMission":"已在此任务中","added":"已添加传送门","updated":"已更新传送门动作","empty":"空任务","complete":"任务完成","stay":"留在这里","goNext":"下一任务","chooseAction":"先选择动作，再点击“添加”","carryAdded":"已自动沿用起始口令","routeUnavailable":"无法获取步行路线","portals":"传送门","completeMissions":"已完成任务","activeWalk":"任务步行距离","activeTime":"任务时间","bannerWalk":"Banner 步行距离","theoryTime":"理论时间","transitions":"任务之间","civilization":"文明绕行","sporty":"最长任务","longestStep":"最长路段","avgMission":"平均 / 任务","metersPortal":"米 / 传送门","portalsKm":"传送门 / km","straight":"直线距离总计","recalc":"重新计算步行统计","estimate":"Valhalla + OpenStreetMap 估算 · 不是 GPS","cached":"缓存结果","calculated":"刚刚计算","needTwo":"至少添加两个传送门","otherRoutes":"其他任务","activeRoute":"已选任务"},"zh-Hant":{"passIncomplete":"密語尚未填完整","passIncompleteHelp":"離開這個傳送門前，請先填寫問題和答案。","completePass":"補全","continuePass":"繼續","skipPass":"仍然繼續","touch":"點選地圖上的傳送門","add":"新增","save":"儲存","remove":"移除","prev":"任務","next":"任務","sync":"同步 BannerLab","options":"選項","hideOptions":"隱藏選項","direct":"點選時直接新增","askAction":"新增前詢問動作","classic":"經典 Banner 模式","classicHelp":"第 1 個傳送門 = 密語 · 之後 = Hack","carry":"上一任務終點 → 下一任務起點","progression":"任務完成時","askAdvance":"詢問我","autoAdvance":"自動前往下一任務","showOther":"顯示其他任務","language":"語言","panelSize":"面板寬度","resetPos":"重設面板位置","stats":"完美地沒什麼用的統計","hideStats":"隱藏統計","action":"動作","hack":"Hack","mod":"安裝 Mod","capture":"佔領 / 升級","link":"建立連結","field":"建立控制場","pass":"密語","question":"問題","answer":"答案","missionNumberQuestion":"任務編號是多少？","mission":"任務","linked":"已連結專案","unknown":"總數未知","selectedExisting":"已在此任務中 · 可在這裡修改動作","duplicateMission":"已在此任務中","added":"已新增傳送門","updated":"已更新傳送門動作","empty":"空任務","complete":"任務完成","stay":"留在這裡","goNext":"下一個任務","chooseAction":"先選動作，再點「新增」","carryAdded":"已自動沿用起始密語","routeUnavailable":"無法取得步行路線","portals":"傳送門","completeMissions":"已完成任務","activeWalk":"任務步行距離","activeTime":"任務時間","bannerWalk":"Banner 步行距離","theoryTime":"理論時間","transitions":"任務之間","civilization":"文明繞路","sporty":"最長任務","longestStep":"最長路段","avgMission":"平均 / 任務","metersPortal":"公尺 / 傳送門","portalsKm":"傳送門 / km","straight":"直線距離總計","recalc":"重新計算步行統計","estimate":"Valhalla + OpenStreetMap 估算 · 不是 GPS","cached":"快取結果","calculated":"剛剛計算","needTwo":"至少新增兩個傳送門","otherRoutes":"其他任務","activeRoute":"已選任務"},"yue":{"passIncomplete":"Passphrase 未填完整","passIncompleteHelp":"離開呢個 Portal 之前，記得填埋問題同答案。","completePass":"填完整","continuePass":"繼續","skipPass":"照繼續","touch":"撳地圖上一個 Portal","add":"加入","save":"儲存","remove":"移除","prev":"任務","next":"任務","sync":"同步 BannerLab","options":"選項","hideOptions":"收起選項","direct":"撳 Portal 就直接加入","askAction":"加入之前先問動作","classic":"經典 Banner 模式","classicHelp":"第 1 個 Portal = Passphrase · 之後 = Hack","carry":"上一個終點 → 下一個起點","progression":"任務完成嗰陣","askAdvance":"問一問我","autoAdvance":"自動去下一個","showOther":"顯示其他任務","language":"語言","panelSize":"面板闊度","resetPos":"面板返去中間","stats":"完美地冇乜用嘅統計","hideStats":"收起統計","action":"動作","hack":"Hack","mod":"裝 Mod","capture":"佔領 / 升級","link":"開 Link","field":"開 Field","pass":"Passphrase","question":"問題","answer":"答案","missionNumberQuestion":"任務係幾號？","mission":"任務","linked":"已連結項目","unknown":"總數未知","selectedExisting":"已經喺呢個任務入面 · 可以喺度改動作","duplicateMission":"已經喺呢個任務入面","added":"Portal 已加入","updated":"Portal 動作已更新","empty":"空任務","complete":"任務完成","stay":"留喺度","goNext":"下一個任務","chooseAction":"揀好動作，再撳「加入」","carryAdded":"起始 Passphrase 已自動沿用","routeUnavailable":"搵唔到步行路線","portals":"Portals","completeMissions":"已完成任務","activeWalk":"任務步行距離","activeTime":"任務時間","bannerWalk":"Banner 步行距離","theoryTime":"理論時間","transitions":"任務之間","civilization":"文明繞路","sporty":"最長任務","longestStep":"最長一段","avgMission":"平均 / 任務","metersPortal":"米 / Portal","portalsKm":"Portals / km","straight":"直線距離總計","recalc":"重新計步行統計","estimate":"Valhalla + OpenStreetMap 估算 · 唔係 GPS","cached":"快取結果","calculated":"啱啱計好","needTwo":"最少加兩個 Portal","otherRoutes":"其他任務","activeRoute":"而家揀緊嘅任務"},"ar":{"passIncomplete":"عبارة المرور غير مكتملة","passIncompleteHelp":"أدخل السؤال والإجابة قبل مغادرة هذه البوابة.","completePass":"إكمال","continuePass":"متابعة","skipPass":"المتابعة على أي حال","touch":"اضغط على بوابة في الخريطة","add":"إضافة","save":"حفظ","remove":"إزالة","prev":"مهمة","next":"مهمة","sync":"مزامنة BannerLab","options":"الخيارات","hideOptions":"إخفاء الخيارات","direct":"إضافة مباشرة عند الضغط","askAction":"اسأل عن الإجراء قبل الإضافة","classic":"وضع البانر الكلاسيكي","classicHelp":"البوابة الأولى = عبارة مرور · الباقي = Hack","carry":"نهاية السابقة → بداية التالية","progression":"عند اكتمال المهمة","askAdvance":"اسألني","autoAdvance":"الانتقال تلقائيًا","showOther":"إظهار المهام الأخرى","language":"اللغة","panelSize":"عرض اللوحة","resetPos":"إعادة اللوحة إلى الوسط","stats":"إحصاءات عديمة الفائدة بشكل مثالي","hideStats":"إخفاء الإحصاءات","action":"الإجراء","hack":"Hack","mod":"تثبيت Mod","capture":"استيلاء / ترقية","link":"إنشاء رابط","field":"إنشاء حقل","pass":"عبارة المرور","question":"السؤال","answer":"الإجابة","missionNumberQuestion":"ما رقم المهمة؟","mission":"المهمة","linked":"المشروع المرتبط","unknown":"الإجمالي غير معروف","selectedExisting":"موجود بالفعل في هذه المهمة · يمكنك تعديل الإجراء هنا","duplicateMission":"موجود بالفعل في هذه المهمة","added":"تمت إضافة البوابة","updated":"تم تحديث إجراء البوابة","empty":"مهمة فارغة","complete":"المهمة مكتملة","stay":"البقاء هنا","goNext":"المهمة التالية","chooseAction":"اختر الإجراء ثم اضغط «إضافة»","carryAdded":"تمت إعادة استخدام عبارة مرور البداية تلقائيًا","routeUnavailable":"مسار المشي غير متاح","portals":"بوابات","completeMissions":"مهام مكتملة","activeWalk":"مسافة مشي المهمة","activeTime":"وقت المهمة","bannerWalk":"مسافة مشي البانر","theoryTime":"الوقت النظري","transitions":"بين المهام","civilization":"التفاف الحضارة","sporty":"أطول مهمة","longestStep":"أطول مقطع","avgMission":"المتوسط / مهمة","metersPortal":"أمتار / بوابة","portalsKm":"بوابات / كم","straight":"إجمالي الخط المستقيم","recalc":"إعادة حساب إحصاءات المشي","estimate":"تقدير Valhalla + OpenStreetMap · ليس GPS","cached":"نتيجة مخزنة مؤقتًا","calculated":"حُسبت الآن","needTwo":"أضف بوابتين على الأقل","otherRoutes":"مهام أخرى","activeRoute":"المهمة المحددة"},"id":{"passIncomplete":"Passphrase belum lengkap","passIncompleteHelp":"Isi pertanyaan dan jawaban sebelum meninggalkan portal ini.","completePass":"Lengkapi","continuePass":"Lanjutkan","skipPass":"Tetap lanjutkan","touch":"Ketuk portal di peta","add":"Tambah","save":"Simpan","remove":"Hapus","prev":"Misi","next":"Misi","sync":"Sinkronkan BannerLab","options":"Opsi","hideOptions":"Sembunyikan opsi","direct":"Tambah langsung saat diketuk","askAction":"Tanyakan aksi sebelum menambahkan","classic":"Mode banner klasik","classicHelp":"portal pertama = passphrase · berikutnya = hack","carry":"Akhir sebelumnya → awal berikutnya","progression":"Saat misi selesai","askAdvance":"Tanyakan kepada saya","autoAdvance":"Lanjut otomatis","showOther":"Tampilkan misi lain","language":"Bahasa","panelSize":"Lebar panel","resetPos":"Pusatkan ulang panel","stats":"Statistik yang benar-benar tidak berguna","hideStats":"Sembunyikan statistik","action":"Aksi","hack":"Hack","mod":"Pasang mod","capture":"Rebut / tingkatkan","link":"Buat link","field":"Buat field","pass":"Passphrase","question":"Pertanyaan","answer":"Jawaban","missionNumberQuestion":"Berapa nomor misinya?","mission":"Misi","linked":"Proyek tertaut","unknown":"Total tidak diketahui","selectedExisting":"Sudah ada di misi ini · aksi bisa diubah di sini","duplicateMission":"Sudah ada di misi ini","added":"Portal ditambahkan","updated":"Aksi portal diperbarui","empty":"Misi kosong","complete":"Misi selesai","stay":"Tetap di sini","goNext":"Misi berikutnya","chooseAction":"Pilih aksi, lalu ketuk Tambah","carryAdded":"Passphrase awal digunakan kembali secara otomatis","routeUnavailable":"Rute jalan kaki tidak tersedia","portals":"portal","completeMissions":"misi selesai","activeWalk":"jalan kaki misi","activeTime":"waktu misi","bannerWalk":"jalan kaki banner","theoryTime":"waktu teoritis","transitions":"antar misi","civilization":"memutar lewat peradaban","sporty":"Misi terpanjang","longestStep":"Segmen terpanjang","avgMission":"Rata-rata / misi","metersPortal":"Meter / portal","portalsKm":"Portal / km","straight":"Total garis lurus","recalc":"Hitung ulang statistik jalan kaki","estimate":"Perkiraan Valhalla + OpenStreetMap · bukan GPS","cached":"Hasil cache","calculated":"Baru dihitung","needTwo":"Tambahkan setidaknya dua portal","otherRoutes":"Misi lain","activeRoute":"Misi yang dipilih"}});

    const RECOVERY_TXT={
      fr:{progressRecovery:'Avancée & récupération',progressRecoveryHelp:'L’avancée est sauvegardée automatiquement sur ce téléphone. Recharger depuis BannerLab restaure le dernier état reçu de l’application.',reloadRbl:'Recharger depuis BannerLab',reloadRblConfirm:'Confirmer le rechargement',reloadRblDone:'État BannerLab rechargé',reloadRblMissing:'Aucun état BannerLab reçu à restaurer',resetProgress:'Réinitialiser l’avancée',resetProgressConfirm:'Confirmer la réinitialisation',resetProgressDone:'Avancée réinitialisée'},
      en:{progressRecovery:'Progress & recovery',progressRecoveryHelp:'Progress is saved automatically on this device. Reload from BannerLab restores the latest state received from the app.',reloadRbl:'Reload from BannerLab',reloadRblConfirm:'Confirm reload',reloadRblDone:'BannerLab state reloaded',reloadRblMissing:'No BannerLab state is available to restore',resetProgress:'Reset progress',resetProgressConfirm:'Confirm reset',resetProgressDone:'Progress reset'},
      es:{progressRecovery:'Progreso y recuperación',progressRecoveryHelp:'El progreso se guarda automáticamente en este dispositivo. Recargar desde BannerLab restaura el último estado recibido de la aplicación.',reloadRbl:'Recargar desde BannerLab',reloadRblConfirm:'Confirmar recarga',reloadRblDone:'Estado de BannerLab recargado',reloadRblMissing:'No hay ningún estado de BannerLab para restaurar',resetProgress:'Reiniciar progreso',resetProgressConfirm:'Confirmar reinicio',resetProgressDone:'Progreso reiniciado'},
      pt:{progressRecovery:'Progresso e recuperação',progressRecoveryHelp:'O progresso é guardado automaticamente neste dispositivo. Recarregar a partir do BannerLab repõe o último estado recebido da aplicação.',reloadRbl:'Recarregar do BannerLab',reloadRblConfirm:'Confirmar recarregamento',reloadRblDone:'Estado do BannerLab recarregado',reloadRblMissing:'Não existe nenhum estado do BannerLab para restaurar',resetProgress:'Repor o progresso',resetProgressConfirm:'Confirmar reposição',resetProgressDone:'Progresso reposto'},
      de:{progressRecovery:'Fortschritt & Wiederherstellung',progressRecoveryHelp:'Dein Fortschritt wird automatisch auf diesem Gerät gespeichert. „Aus BannerLab neu laden“ stellt den zuletzt von der App empfangenen Stand wieder her.',reloadRbl:'Aus BannerLab neu laden',reloadRblConfirm:'Neuladen bestätigen',reloadRblDone:'BannerLab-Stand neu geladen',reloadRblMissing:'Kein BannerLab-Stand zum Wiederherstellen vorhanden',resetProgress:'Fortschritt zurücksetzen',resetProgressConfirm:'Zurücksetzen bestätigen',resetProgressDone:'Fortschritt zurückgesetzt'},
      it:{progressRecovery:'Avanzamento e recupero',progressRecoveryHelp:'L’avanzamento viene salvato automaticamente su questo dispositivo. Ricaricare da BannerLab ripristina l’ultimo stato ricevuto dall’app.',reloadRbl:'Ricarica da BannerLab',reloadRblConfirm:'Conferma ricaricamento',reloadRblDone:'Stato BannerLab ricaricato',reloadRblMissing:'Nessuno stato BannerLab disponibile da ripristinare',resetProgress:'Azzera avanzamento',resetProgressConfirm:'Conferma azzeramento',resetProgressDone:'Avanzamento azzerato'},
      nl:{progressRecovery:'Voortgang & herstel',progressRecoveryHelp:'Je voortgang wordt automatisch op dit apparaat opgeslagen. Opnieuw laden vanuit BannerLab herstelt de laatst ontvangen stand uit de app.',reloadRbl:'Opnieuw laden vanuit BannerLab',reloadRblConfirm:'Opnieuw laden bevestigen',reloadRblDone:'BannerLab-status opnieuw geladen',reloadRblMissing:'Geen BannerLab-status beschikbaar om te herstellen',resetProgress:'Voortgang resetten',resetProgressConfirm:'Reset bevestigen',resetProgressDone:'Voortgang gereset'},
      pl:{progressRecovery:'Postęp i odzyskiwanie',progressRecoveryHelp:'Postęp jest automatycznie zapisywany na tym urządzeniu. Ponowne wczytanie z BannerLab przywraca ostatni stan odebrany z aplikacji.',reloadRbl:'Wczytaj ponownie z BannerLab',reloadRblConfirm:'Potwierdź ponowne wczytanie',reloadRblDone:'Stan BannerLab został wczytany',reloadRblMissing:'Brak stanu BannerLab do przywrócenia',resetProgress:'Wyzeruj postęp',resetProgressConfirm:'Potwierdź wyzerowanie',resetProgressDone:'Postęp wyzerowany'},
      cs:{progressRecovery:'Postup a obnovení',progressRecoveryHelp:'Postup se automaticky ukládá na tomto zařízení. Znovunačtení z BannerLabu obnoví poslední stav přijatý z aplikace.',reloadRbl:'Znovu načíst z BannerLabu',reloadRblConfirm:'Potvrdit znovunačtení',reloadRblDone:'Stav BannerLabu byl znovu načten',reloadRblMissing:'Není k dispozici žádný stav BannerLabu k obnovení',resetProgress:'Vynulovat postup',resetProgressConfirm:'Potvrdit vynulování',resetProgressDone:'Postup byl vynulován'},
      ro:{progressRecovery:'Progres și recuperare',progressRecoveryHelp:'Progresul este salvat automat pe acest dispozitiv. Reîncărcarea din BannerLab restaurează ultima stare primită din aplicație.',reloadRbl:'Reîncarcă din BannerLab',reloadRblConfirm:'Confirmă reîncărcarea',reloadRblDone:'Starea BannerLab a fost reîncărcată',reloadRblMissing:'Nu există nicio stare BannerLab de restaurat',resetProgress:'Resetează progresul',resetProgressConfirm:'Confirmă resetarea',resetProgressDone:'Progres resetat'},
      tr:{progressRecovery:'İlerleme ve kurtarma',progressRecoveryHelp:'İlerlemen bu cihazda otomatik olarak kaydedilir. BannerLab’den yeniden yükleme, uygulamadan alınan son durumu geri getirir.',reloadRbl:'BannerLab’den yeniden yükle',reloadRblConfirm:'Yeniden yüklemeyi onayla',reloadRblDone:'BannerLab durumu yeniden yüklendi',reloadRblMissing:'Geri yüklenecek BannerLab durumu yok',resetProgress:'İlerlemeyi sıfırla',resetProgressConfirm:'Sıfırlamayı onayla',resetProgressDone:'İlerleme sıfırlandı'},
      ru:{progressRecovery:'Прогресс и восстановление',progressRecoveryHelp:'Прогресс автоматически сохраняется на этом устройстве. «Загрузить из BannerLab» восстановит последнее состояние, полученное из приложения.',reloadRbl:'Загрузить из BannerLab',reloadRblConfirm:'Подтвердить загрузку',reloadRblDone:'Состояние BannerLab загружено',reloadRblMissing:'Нет состояния BannerLab для восстановления',resetProgress:'Сбросить прогресс',resetProgressConfirm:'Подтвердить сброс',resetProgressDone:'Прогресс сброшен'},
      uk:{progressRecovery:'Прогрес і відновлення',progressRecoveryHelp:'Прогрес автоматично зберігається на цьому пристрої. «Завантажити з BannerLab» відновить останній стан, отриманий із застосунку.',reloadRbl:'Завантажити з BannerLab',reloadRblConfirm:'Підтвердити завантаження',reloadRblDone:'Стан BannerLab завантажено',reloadRblMissing:'Немає стану BannerLab для відновлення',resetProgress:'Скинути прогрес',resetProgressConfirm:'Підтвердити скидання',resetProgressDone:'Прогрес скинуто'},
      ja:{progressRecovery:'進行状況と復元',progressRecoveryHelp:'進行状況はこの端末に自動保存されます。「BannerLabから再読み込み」は、アプリから最後に受け取った状態へ戻します。',reloadRbl:'BannerLabから再読み込み',reloadRblConfirm:'再読み込みを確認',reloadRblDone:'BannerLabの状態を再読み込みしました',reloadRblMissing:'復元できるBannerLabの状態がありません',resetProgress:'進行状況をリセット',resetProgressConfirm:'リセットを確認',resetProgressDone:'進行状況をリセットしました'},
      ko:{progressRecovery:'진행 상황 및 복구',progressRecoveryHelp:'진행 상황은 이 기기에 자동 저장됩니다. BannerLab에서 다시 불러오면 앱에서 마지막으로 받은 상태로 복원됩니다.',reloadRbl:'BannerLab에서 다시 불러오기',reloadRblConfirm:'다시 불러오기 확인',reloadRblDone:'BannerLab 상태를 다시 불러왔습니다',reloadRblMissing:'복원할 BannerLab 상태가 없습니다',resetProgress:'진행 상황 초기화',resetProgressConfirm:'초기화 확인',resetProgressDone:'진행 상황이 초기화되었습니다'},
      'zh-Hans':{progressRecovery:'进度与恢复',progressRecoveryHelp:'进度会自动保存在此设备上。“从 BannerLab 重新加载”会恢复应用最后一次传来的状态。',reloadRbl:'从 BannerLab 重新加载',reloadRblConfirm:'确认重新加载',reloadRblDone:'已重新加载 BannerLab 状态',reloadRblMissing:'没有可恢复的 BannerLab 状态',resetProgress:'重置进度',resetProgressConfirm:'确认重置',resetProgressDone:'进度已重置'},
      'zh-Hant':{progressRecovery:'進度與復原',progressRecoveryHelp:'進度會自動儲存在此裝置上。「從 BannerLab 重新載入」會還原應用程式最後一次傳來的狀態。',reloadRbl:'從 BannerLab 重新載入',reloadRblConfirm:'確認重新載入',reloadRblDone:'已重新載入 BannerLab 狀態',reloadRblMissing:'沒有可復原的 BannerLab 狀態',resetProgress:'重設進度',resetProgressConfirm:'確認重設',resetProgressDone:'進度已重設'},
      yue:{progressRecovery:'進度同復原',progressRecoveryHelp:'進度會自動儲存喺呢部裝置。「由 BannerLab 重新載入」會還原 App 最後一次傳過嚟嘅狀態。',reloadRbl:'由 BannerLab 重新載入',reloadRblConfirm:'確認重新載入',reloadRblDone:'已重新載入 BannerLab 狀態',reloadRblMissing:'冇 BannerLab 狀態可以還原',resetProgress:'重設進度',resetProgressConfirm:'確認重設',resetProgressDone:'進度已重設'},
      ar:{progressRecovery:'التقدم والاستعادة',progressRecoveryHelp:'يُحفظ تقدمك تلقائيًا على هذا الجهاز. إعادة التحميل من BannerLab تستعيد آخر حالة وصلت من التطبيق.',reloadRbl:'إعادة التحميل من BannerLab',reloadRblConfirm:'تأكيد إعادة التحميل',reloadRblDone:'تمت إعادة تحميل حالة BannerLab',reloadRblMissing:'لا توجد حالة BannerLab متاحة للاستعادة',resetProgress:'إعادة ضبط التقدم',resetProgressConfirm:'تأكيد إعادة الضبط',resetProgressDone:'تمت إعادة ضبط التقدم'},
      id:{progressRecovery:'Progres & pemulihan',progressRecoveryHelp:'Progres disimpan otomatis di perangkat ini. Muat ulang dari BannerLab akan memulihkan kondisi terakhir yang diterima dari aplikasi.',reloadRbl:'Muat ulang dari BannerLab',reloadRblConfirm:'Konfirmasi muat ulang',reloadRblDone:'Kondisi BannerLab dimuat ulang',reloadRblMissing:'Tidak ada kondisi BannerLab yang bisa dipulihkan',resetProgress:'Reset progres',resetProgressConfirm:'Konfirmasi reset',resetProgressDone:'Progres direset'}
    };
    Object.entries(RECOVERY_TXT).forEach(([lang,txt])=>Object.assign(TXT[lang]||(TXT[lang]={}),txt));
    const AUTOSAVE_TXT={
      fr:{autoSaveLabel:'Sauvegarde auto'},en:{autoSaveLabel:'Autosave'},de:{autoSaveLabel:'Autospeicherung'},
      nl:{autoSaveLabel:'Automatisch opslaan'},pt:{autoSaveLabel:'Gravação automática'},es:{autoSaveLabel:'Guardado automático'},
      it:{autoSaveLabel:'Salvataggio automatico'}
    };
    Object.entries(AUTOSAVE_TXT).forEach(([lang,txt])=>Object.assign(TXT[lang]||(TXT[lang]={}),txt));

    plugin.t=k=>(TXT[normalizeLang(plugin.state.lang)]||TXT.en)[k]||TXT.en[k]||TXT.fr[k]||k;

    plugin.objectiveOptions=()=>[
      ['HACK_PORTAL',plugin.t('hack')],
      ['INSTALL_MOD',plugin.t('mod')],
      ['CAPTURE_PORTAL',plugin.t('capture')],
      ['CREATE_LINK',plugin.t('link')],
      ['CREATE_FIELD',plugin.t('field')],
      ['PASSPHRASE',plugin.t('pass')]
    ];

    plugin.defaultMissionPassphrase=()=>({type:'PASSPHRASE',question:plugin.t('missionNumberQuestion'),answer:String(plugin.state.c+1)});
    plugin.fillPassphraseDefaults=obj=>{
      if(!obj||String(obj.type||'')!=='PASSPHRASE')return obj;
      const d=plugin.defaultMissionPassphrase();
      if(!String(obj.question||'').trim())obj.question=d.question;
      if(!String(obj.answer||'').trim())obj.answer=d.answer;
      return obj;
    };

    plugin.readAutoSaveRecord=()=>{
      let best=null;
      for(const key of [AUTOSAVE_KEY,AUTOSAVE_BACKUP_KEY]){
        try{
          const raw=localStorage.getItem(key);
          if(!raw)continue;
          const rec=JSON.parse(raw);
          if(!rec||typeof rec!=='object'||!rec.state)continue;
          if(!best||Number(rec.savedAt||0)>Number(best.savedAt||0))best=rec;
        }catch(e){}
      }
      return best;
    };
    plugin.readAutoSaveState=()=>{
      const rec=plugin.readAutoSaveRecord();
      try{return rec?.state?normalize(rec.state):null}catch(e){return null}
    };
    plugin.autoSaveIdentityMatch=(incoming,saved)=>{
      if(!incoming||!saved)return false;
      const isid=String(incoming.sid||'').trim(), ssid=String(saved.sid||'').trim();
      const ipid=String(incoming.pid||'').trim(), spid=String(saved.pid||'').trim();
      if(isid&&ssid&&isid===ssid)return true;
      if(ipid&&spid&&ipid!=='current'&&spid!=='current'&&ipid===spid)return true;
      // Filet de sécurité volontairement simple : si RBL recrée par erreur ses identifiants,
      // le même nom + le même nombre de missions + la même taille de mission reste le même parcours.
      const iname=String(incoming.name||'').trim().toLowerCase();
      const sname=String(saved.name||'').trim().toLowerCase();
      const inCount=Number(incoming.n||incoming.m?.length||0), saveCount=Number(saved.n||saved.m?.length||0);
      const sameShape=!!iname&&iname===sname&&inCount===saveCount&&Number(incoming.ppm||0)===Number(saved.ppm||0);
      return sameShape;
    };
    plugin.writeAutoSave=(st,reason='change')=>{
      try{
        if(!st)return;
        const previous=localStorage.getItem(AUTOSAVE_KEY);
        if(previous)localStorage.setItem(AUTOSAVE_BACKUP_KEY,previous);
        const rec={savedAt:Date.now(),reason:String(reason||'change'),state:normalize(st)};
        localStorage.setItem(AUTOSAVE_KEY,JSON.stringify(rec));
        plugin.lastAutoSaveAt=rec.savedAt;
      }catch(e){console.warn('[BannerLab] autosave',e)}
    };
    plugin.autoSaveStatus=()=>{
      const rec=plugin.readAutoSaveRecord();
      if(!rec?.state)return `💾 ${plugin.t('autoSaveLabel')} · —`;
      const c=Math.max(0,Number(rec.state.c)||0)+1;
      let tm='';
      try{tm=new Date(Number(rec.savedAt)||Date.now()).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})}catch(e){}
      return `💾 ${plugin.t('autoSaveLabel')} · M${c}${tm?' · '+tm:''} ✓`;
    };
    plugin.autoSaveShortStatus=()=>{
      const rec=plugin.readAutoSaveRecord();
      if(!rec?.state)return '💾 —';
      return `💾 M${Math.max(0,Number(rec.state.c)||0)+1} ✓`;
    };

    plugin.progressKeys=st=>{
      const keys=[];
      if(String(st?.sid||'').trim())keys.push('sid:'+String(st.sid).trim());
      if(String(st?.pid||'').trim())keys.push('pid:'+String(st.pid).trim());
      // Une signature d'un parcours encore vide n'identifie rien : 18 missions vides
      // ressemblent à toutes les autres bannières de 18 missions.
      if(plugin.routeAnchor(st)&&String(st?.sourceSig||'').trim())keys.push('sig:'+String(st.sourceSig).trim());
      return [...new Set(keys)];
    };
    plugin.readSessions=()=>{
      try{const x=JSON.parse(localStorage.getItem(SESSIONS_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch(e){return {}}
    };
    plugin.sessionKeys=st=>{
      const keys=[];
      if(String(st?.sid||'').trim())keys.push('sid:'+String(st.sid).trim());
      if(String(st?.pid||'').trim()&&String(st.pid).trim()!=='current')keys.push('pid:'+String(st.pid).trim());
      if(plugin.routeAnchor(st)&&String(st?.sourceSig||'').trim())keys.push('sig:'+String(st.sourceSig).trim());
      const name=String(st?.name||'').trim().toLowerCase();
      if(name)keys.push(`legacy:${name}|${Number(st?.n||st?.m?.length||0)}|${Number(st?.ppm||0)}`);
      return [...new Set(keys)];
    };
    plugin.saveSessionState=st=>{
      try{
        if(!st)return;
        const map=plugin.readSessions(),snap=normalize(st);
        plugin.sessionKeys(st).forEach(k=>map[k]=snap);
        const rows=Object.entries(map).sort((a,b)=>Number(b[1]?.updatedAt||0)-Number(a[1]?.updatedAt||0)).slice(0,30);
        localStorage.setItem(SESSIONS_KEY,JSON.stringify(Object.fromEntries(rows)));
      }catch(e){}
    };
    plugin.restoreSessionState=incoming=>{
      try{
        const map=plugin.readSessions();
        for(const k of plugin.sessionKeys(incoming)){
          const x=map[k];
          if(x&&typeof x==='object')return normalize(x);
        }
      }catch(e){}
      return null;
    };
    plugin.readProgressMap=()=>{
      try{const x=JSON.parse(localStorage.getItem(PROGRESS_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch(e){return {}}
    };
    plugin.saveProgressCheckpoint=st=>{
      try{
        if(!st)return;
        const map=plugin.readProgressMap();
        const checkpoint={c:Math.max(0,parseInt(st.c)||0),sid:String(st.sid||''),pid:String(st.pid||''),sourceSig:String(st.sourceSig||''),updatedAt:Date.now()};
        plugin.progressKeys(st).forEach(k=>map[k]=checkpoint);
        localStorage.setItem(PROGRESS_KEY,JSON.stringify(map));
      }catch(e){}
    };
    plugin.restoreProgressCheckpoint=st=>{
      try{
        const map=plugin.readProgressMap();
        let best=null;
        for(const k of plugin.progressKeys(st)){
          const x=map[k];
          if(x&&Number.isFinite(Number(x.c))&&(!best||Number(x.updatedAt||0)>Number(best.updatedAt||0)))best=x;
        }
        if(!best)return false;
        const max=Math.max(0,(Array.isArray(st.m)?st.m.length:1)-1);
        st.c=Math.max(0,Math.min(max,Number(best.c)||0));
        return true;
      }catch(e){return false}
    };

    plugin.save=(reason='change')=>{
      try{
        plugin.state.updatedAt=Date.now();
        localStorage.setItem(KEY,JSON.stringify(plugin.state));
        plugin.saveProgressCheckpoint(plugin.state);
        plugin.saveSessionState(plugin.state);
        plugin.writeAutoSave(plugin.state,reason);
      }catch(e){console.warn('[BannerLab] save',e)}
    };

    plugin.hasProgress=st=>Number(st?.c)>0||(Array.isArray(st?.m)&&st.m.some(m=>Array.isArray(m)&&m.length>0));
    plugin.copyUiPrefs=(target,local)=>{
      if(!local)return target;
      target.panelWidth=local.panelWidth;
      target.panelX=local.panelX;
      target.panelY=local.panelY;
      target.showOther=local.showOther;
      target.advanceMode=local.advanceMode;
      target.classic=local.classic;
      target.askAction=local.askAction;
      target.direct=local.direct;
      return target;
    };
    plugin.routeAnchor=st=>{
      const missions=Array.isArray(st?.m)?st.m:[];
      for(const m of missions)for(const p of (Array.isArray(m)?m:[])){
        const guid=Array.isArray(p)?String(p[0]||''):'';
        if(guid)return guid;
      }
      return '';
    };
    plugin.sameSession=(incoming,local)=>{
      if(!incoming||!local)return false;
      const sameSid=!!incoming.sid&&!!local.sid&&incoming.sid===local.sid;
      const samePid=!!incoming.pid&&!!local.pid&&incoming.pid===local.pid;
      const ia=plugin.routeAnchor(incoming),la=plugin.routeAnchor(local);
      const sameSig=!!ia&&!!la&&!!incoming.sourceSig&&!!local.sourceSig&&incoming.sourceSig===local.sourceSig;
      const sameLegacyRoute=!!ia&&ia===la&&String(incoming.name||'')===String(local.name||'')&&Number(incoming.n||incoming.m?.length||0)===Number(local.n||local.m?.length||0);
      // Migration des 0.6.5/0.6.6 : un parcours construit dans IITC peut avoir une
      // empreinte différente de l'état encore vide de BannerLab. Si aucun SID ne permet
      // encore de trancher, nom + nombre de missions + taille de mission servent de pont.
      const sameLegacyShape=!local.sid && String(incoming.name||'')===String(local.name||'') && Number(incoming.n||incoming.m?.length||0)===Number(local.n||local.m?.length||0) && Number(incoming.ppm||0)===Number(local.ppm||0);
      return sameSid||samePid||sameSig||sameLegacyRoute||sameLegacyShape;
    };
    plugin.keepLocalProgress=(incoming,local,force=false)=>{
      // Même parcours : la réouverture depuis BannerLab est une REPRISE, jamais un reset.
      // L'autosave a déjà sa propre vérification d'identité et peut donc forcer cette reprise.
      if(!force&&!plugin.sameSession(incoming,local))return incoming;
      incoming.m=local.m;
      incoming.c=Math.max(0,Math.min(incoming.m.length-1,Number(local.c)||0));
      incoming.passSkips=local.passSkips||{};
      incoming.objective=local.objective||incoming.objective;
      incoming.question=local.question||'';
      incoming.answer=local.answer||'';
      incoming.updatedAt=local.updatedAt||0;
      incoming.sid=incoming.sid||local.sid||'';
      incoming.pid=incoming.pid||local.pid||'';
      incoming.sourceSig=incoming.sourceSig||local.sourceSig||'';
      return incoming;
    };

    plugin.load=()=>{
      try{
        const u=new URL(location.href);
        const hm=u.hash.match(/(?:^|[?#&])rbl=([^&]+)/);
        const raw=u.searchParams.get('rbl')||(hm?.[1]?decodeURIComponent(hm[1]):'');
        if(raw){
          const incoming=normalize(dec(raw));
          // Toujours conserver le dernier état réellement reçu de BannerLab :
          // il sert uniquement au bouton explicite « Recharger depuis BannerLab ».
          try{localStorage.setItem(SNAPSHOT_KEY,JSON.stringify(incoming))}catch(e){}
          const localRaw=localStorage.getItem(KEY);
          const globalLocal=localRaw?normalize(JSON.parse(localRaw)):null;
          const autoLocal=plugin.readAutoSaveState();
          const sessionLocal=plugin.restoreSessionState(incoming);
          // L'autosave est la source prioritaire d'une REPRISE. Le payload de RBL sert à ouvrir
          // le parcours, pas à remettre la mission courante à zéro.
          const autoMatched=!!(autoLocal&&plugin.autoSaveIdentityMatch(incoming,autoLocal));
          const local=autoMatched
            ? autoLocal
            : (sessionLocal||(plugin.sameSession(incoming,globalLocal)?globalLocal:null));
          plugin.copyUiPrefs(incoming,local||globalLocal||autoLocal);
          if(local)plugin.keepLocalProgress(incoming,local,autoMatched);
          else plugin.restoreProgressCheckpoint(incoming);
          plugin.state=incoming;
          plugin.save('resume');
          return;
        }
        const autoLocal=plugin.readAutoSaveState();
        if(autoLocal){
          plugin.state=autoLocal;
          plugin.restoreProgressCheckpoint(plugin.state);
          plugin.save('startup-autosave');
          return;
        }
        const current=localStorage.getItem(KEY);
        if(current){
          plugin.state=normalize(JSON.parse(current));
          plugin.restoreProgressCheckpoint(plugin.state);
          plugin.save('startup');
          return;
        }
        const oldState=localStorage.getItem(OLD_KEY);
        if(oldState){
          plugin.state=normalize(JSON.parse(oldState));
          plugin.save();
        }
      }catch(e){console.warn('[BannerLab] load',e)}
    };

    plugin.reloadFromBannerLab=()=>{
      try{
        const raw=localStorage.getItem(SNAPSHOT_KEY);
        if(!raw){plugin.flash(plugin.t('reloadRblMissing'));return false}
        const incoming=normalize(JSON.parse(raw));
        plugin.copyUiPrefs(incoming,plugin.state);
        plugin.state=incoming;
        plugin.pendingAdvance=false;
        plugin.selectedGuid=null;
        plugin.reloadRblArmed=false;
        plugin.resetProgressArmed=false;
        localStorage.removeItem(STATS_KEY);
        plugin.save('explicit-reload-rbl');
        plugin.render();
        plugin.drawRoutes();
        plugin.flash(plugin.t('reloadRblDone'));
        return true;
      }catch(e){console.warn('[BannerLab] reload snapshot',e);plugin.flash(plugin.t('reloadRblMissing'));return false}
    };

    plugin.resetProgress=()=>{
      const count=plugin.totalMissionCount();
      plugin.state.m=Array.from({length:count},()=>[]);
      plugin.state.c=0;
      plugin.state.passSkips={};
      plugin.state.objective='HACK_PORTAL';
      plugin.state.question='';
      plugin.state.answer='';
      plugin.pendingAdvance=false;
      plugin.selectedGuid=null;
      plugin.reloadRblArmed=false;
      plugin.resetProgressArmed=false;
      localStorage.removeItem(STATS_KEY);
      plugin.save('explicit-reset');
      plugin.render();
      plugin.drawRoutes();
      plugin.flash(plugin.t('resetProgressDone'));
    };

    plugin.ensureMission=i=>{
      while(plugin.state.m.length<=i)plugin.state.m.push([]);
      return plugin.state.m[i];
    };
    plugin.current=()=>plugin.ensureMission(plugin.state.c);
    plugin.hasKnownTotal=()=>plugin.state.n>0;
    plugin.totalLabel=()=>plugin.hasKnownTotal()?String(plugin.state.n):'?';
    plugin.totalMissionCount=()=>plugin.state.n||plugin.state.m.length||1;

    plugin.findMarker=guid=>guid&&window.portals&&window.portals[guid];

    plugin.currentIndexOfGuid=guid=>{
      if(!guid)return -1;
      return plugin.current().findIndex(p=>p&&p[0]===guid);
    };

    plugin.readObjectiveUi=()=>{
      const type=document.getElementById('rbl-objective')?.value||plugin.state.objective||'HACK_PORTAL';
      const question=document.getElementById('rbl-question')?.value||'';
      const answer=document.getElementById('rbl-answer')?.value||'';
      plugin.state.objective=type;
      plugin.state.question=question;
      plugin.state.answer=answer;
      return {type,question,answer};
    };

    plugin.portalFromMarker=(marker,obj)=>{
      if(!marker)return null;
      const d=marker.options&&marker.options.data||{};
      const ll=marker.getLatLng();
      const o=obj||plugin.readObjectiveUi();
      return [
        String(marker.options&&marker.options.guid||''),
        String(d.title||'Portal'),
        Number(ll.lat),Number(ll.lng),String(d.image||''),
        String(o.type||'HACK_PORTAL'),String(o.question||''),String(o.answer||'')
      ];
    };

    plugin.defaultObjectiveForNew=()=>{
      if(!plugin.state.classic)return plugin.readObjectiveUi();
      const arr=plugin.current();
      return arr.length===0
        ?plugin.defaultMissionPassphrase()
        :{type:'HACK_PORTAL',question:'',answer:''};
    };

    plugin.loadExistingObjective=idx=>{
      const p=plugin.current()[idx];
      if(!p)return;
      plugin.state.objective=String(p[5]||'HACK_PORTAL');
      plugin.state.question=String(p[6]||'');
      plugin.state.answer=String(p[7]||'');
      if(plugin.state.objective==='PASSPHRASE'){
        const d=plugin.defaultMissionPassphrase();
        if(!plugin.state.question.trim())plugin.state.question=d.question;
        if(!plugin.state.answer.trim())plugin.state.answer=d.answer;
      }
    };

    plugin.updateExistingObjective=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx<0)return false;
      const o=plugin.fillPassphraseDefaults(plugin.readObjectiveUi());
      const p=plugin.current()[idx];
      p[5]=o.type;p[6]=o.question;p[7]=o.answer;
      plugin.clearPassSkipIfComplete(plugin.state.c,idx);
      localStorage.removeItem(STATS_KEY);
      plugin.save();
      plugin.flash(plugin.t('updated'));
      return true;
    };


    plugin.passSkipKey=(mi,guid)=>String(mi)+':'+String(guid||'');
    plugin.isPassphraseIncomplete=(mi,idx)=>{
      const p=plugin.state.m?.[mi]?.[idx];
      if(!p||String(p[5]||'')!=='PASSPHRASE')return false;
      const key=plugin.passSkipKey(mi,p[0]);
      if(plugin.state.passSkips?.[key])return false;
      return !String(p[6]||'').trim()||!String(p[7]||'').trim();
    };
    plugin.selectedIncompletePassphrase=()=>{
      const guid=plugin.selectedGuid||window.selectedPortal;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx<0||!plugin.isPassphraseIncomplete(plugin.state.c,idx))return null;
      return {mi:plugin.state.c,idx,guid:String(guid)};
    };
    plugin.clearPassSkipIfComplete=(mi,idx)=>{
      const p=plugin.state.m?.[mi]?.[idx];
      if(!p)return;
      if(String(p[6]||'').trim()&&String(p[7]||'').trim()){
        delete plugin.state.passSkips[plugin.passSkipKey(mi,p[0])];
      }
    };
    plugin.beginPassGuard=(current,nextGuid)=>{
      plugin.passGuard={
        mi:current.mi,
        idx:current.idx,
        guid:current.guid,
        nextGuid:String(nextGuid||'')
      };
      plugin.selectedGuid=current.guid;
      plugin.loadExistingObjective(current.idx);
      plugin.render();
      setTimeout(()=>{
        const q=document.getElementById('rbl-question');
        const a=document.getElementById('rbl-answer');
        if(q&&!q.value.trim())q.focus();
        else if(a&&!a.value.trim())a.focus();
      },60);
    };
    plugin.resumePassGuard=(skip=false)=>{
      const g=plugin.passGuard;
      if(!g)return;
      const p=plugin.state.m?.[g.mi]?.[g.idx];
      if(!p){plugin.passGuard=null;plugin.render();return}

      if(!skip){
        const o=plugin.readObjectiveUi();
        p[5]=o.type;p[6]=o.question;p[7]=o.answer;
        if(!String(p[6]||'').trim()||!String(p[7]||'').trim()){
          plugin.flash(plugin.t('passIncompleteHelp'));
          plugin.render();
          return;
        }
        delete plugin.state.passSkips[plugin.passSkipKey(g.mi,p[0])];
      }else{
        plugin.state.passSkips[plugin.passSkipKey(g.mi,p[0])]=true;
      }

      const nextGuid=g.nextGuid;
      plugin.passGuard=null;
      plugin.save();

      if(nextGuid){
        plugin.selectedGuid=nextGuid;
        const marker=plugin.findMarker(nextGuid);
        plugin.render();
        if(plugin.state.direct&&marker){
          setTimeout(()=>plugin.addMarker(marker),40);
        }else{
          plugin.renderSelectedOnly();
        }
      }else{
        plugin.render();
      }
    };

    plugin.canCreateNext=()=>!plugin.hasKnownTotal()||plugin.state.c<plugin.state.n-1;

    plugin.carryIntoCurrent=()=>{
      if(!plugin.state.carry||plugin.state.c<=0)return false;
      const current=plugin.current();
      if(current.length)return false;
      const prev=plugin.state.m[plugin.state.c-1]||[];
      const p=prev[prev.length-1];
      if(!p)return false;
      const clone=[...p];
      if(plugin.state.classic){
        const d=plugin.defaultMissionPassphrase();
        clone[5]='PASSPHRASE';
        clone[6]=d.question;
        clone[7]=d.answer;
      }
      current.push(clone);
      plugin.selectedGuid=clone[0]||plugin.selectedGuid;
      plugin.state.objective=clone[5]||'PASSPHRASE';
      plugin.state.question=clone[6]||'';
      plugin.state.answer=clone[7]||'';
      return true;
    };

    plugin.goNext=(withCarry=true)=>{
      if(plugin.hasKnownTotal()&&plugin.state.c>=plugin.state.n-1)return false;
      plugin.state.c++;
      plugin.ensureMission(plugin.state.c);
      if(withCarry&&plugin.carryIntoCurrent())plugin.flash(plugin.t('carryAdded'));
      return true;
    };

    plugin.finishAdvance=()=>{
      plugin.pendingAdvance=false;
      if(!plugin.goNext(true)){
        plugin.flash(plugin.t('complete'));
        plugin.render();plugin.drawRoutes();return;
      }
      localStorage.removeItem(STATS_KEY);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.onMissionReachedTarget=()=>{
      if(plugin.state.advanceMode==='auto'){
        plugin.finishAdvance();
      }else{
        plugin.pendingAdvance=true;
        plugin.save();plugin.render();plugin.drawRoutes();
      }
    };

    plugin.addMarker=(marker,explicitObjective=null)=>{
      const guid=String(marker?.options?.guid||'');
      if(!guid)return;

      // Le même portail est autorisé dans d'autres missions.
      // Il est interdit uniquement deux fois dans la mission courante.
      const existing=plugin.currentIndexOfGuid(guid);
      if(existing>=0){
        plugin.selectedGuid=guid;
        plugin.loadExistingObjective(existing);
        plugin.render();
        plugin.flash(plugin.t('selectedExisting'));
        return;
      }

      if(plugin.pendingAdvance){
        plugin.flash(plugin.t('complete'));
        return;
      }

      const objective=plugin.fillPassphraseDefaults(explicitObjective||(
        plugin.state.askAction ? plugin.readObjectiveUi() : plugin.defaultObjectiveForNew()
      ));

      const p=plugin.portalFromMarker(marker,objective);
      if(!p)return;
      const arr=plugin.current();
      arr.push(p);
      plugin.selectedGuid=guid;
      plugin.loadExistingObjective(arr.length-1);

      localStorage.removeItem(STATS_KEY);
      plugin.save();
      plugin.drawRoutes();

      if(arr.length===plugin.state.ppm){
        plugin.onMissionReachedTarget();
      }else{
        plugin.render();
        plugin.flash(plugin.t('added'));
      }
    };

    plugin.addSelected=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const marker=plugin.findMarker(guid);
      if(!marker){plugin.flash(plugin.t('touch'));return}

      const idx=plugin.currentIndexOfGuid(guid);
      if(idx>=0){
        plugin.updateExistingObjective();
        plugin.render();plugin.drawRoutes();
        return;
      }
      plugin.addMarker(marker,plugin.readObjectiveUi());
    };

    plugin.removeSelectedOrLast=()=>{
      const arr=plugin.current();
      if(!arr.length){plugin.flash(plugin.t('empty'));return}
      const guid=window.selectedPortal||plugin.selectedGuid;
      const idx=plugin.currentIndexOfGuid(guid);
      if(idx>=0)arr.splice(idx,1);
      else arr.pop();
      plugin.pendingAdvance=false;
      localStorage.removeItem(STATS_KEY);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.prev=()=>{
      plugin.pendingAdvance=false;
      if(plugin.state.c>0)plugin.state.c--;
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.next=()=>{
      plugin.pendingAdvance=false;
      if(plugin.goNext(true)){
        plugin.save();plugin.render();plugin.drawRoutes();
      }
    };

    plugin.selectMission=i=>{
      const max=plugin.totalMissionCount()-1;
      i=Math.max(0,Math.min(max,Number(i)||0));
      plugin.pendingAdvance=false;
      plugin.state.c=i;
      plugin.ensureMission(i);
      plugin.save();plugin.render();plugin.drawRoutes();
    };

    plugin.sync=()=>{
      plugin.save();
      const payload={
        ...plugin.state,
        v:4,
        n:plugin.state.n||plugin.state.m.length,
        auto:plugin.state.advanceMode==='auto',
        pv:'0.6.7',
        direct:undefined,
        panelWidth:undefined,panelX:undefined,panelY:undefined,
        showOther:undefined,optionsOpen:undefined,
        passSkips:undefined
      };
      window.location.href='redactedbannerlab://sync?data='+encodeURIComponent(enc(payload));
    };

    plugin.flash=msg=>{
      const el=document.getElementById('rbl-flash');
      if(!el)return;
      el.textContent=msg;
      el.classList.add('show');
      clearTimeout(plugin.flashTimer);
      plugin.flashTimer=setTimeout(()=>el.classList.remove('show'),1800);
    };

    plugin.handlePortalSelected=data=>{
      const newGuid=String(data?.selectedPortalGuid||window.selectedPortal||'');
      const oldGuid=String(plugin.selectedGuid||'');

      // Avant de quitter un portail déjà enregistré en passphrase, on exige
      // question + réponse, sauf si l'utilisateur choisit explicitement de passer.
      if(oldGuid&&newGuid&&oldGuid!==newGuid&&!plugin.passGuard){
        const current=plugin.selectedIncompletePassphrase();
        if(current){
          plugin.beginPassGuard(current,newGuid);
          return;
        }
      }

      plugin.selectedGuid=newGuid||null;

      const idx=plugin.currentIndexOfGuid(newGuid);
      if(idx>=0){
        plugin.loadExistingObjective(idx);
        plugin.render();
        plugin.flash(plugin.t('selectedExisting'));
        return;
      }

      plugin.renderSelectedOnly();

      if(!plugin.state.direct||!newGuid)return;
      if(plugin.pendingAdvance){plugin.flash(plugin.t('complete'));return}
      if(plugin.state.askAction){plugin.flash(plugin.t('chooseAction'));return}

      const now=Date.now();
      if(plugin.lastDirectGuid===newGuid&&now-plugin.lastDirectAt<700)return;
      plugin.lastDirectGuid=newGuid;
      plugin.lastDirectAt=now;

      const marker=plugin.findMarker(newGuid);
      if(!marker)return;

      setTimeout(()=>{
        const currentMarker=plugin.findMarker(newGuid);
        if(currentMarker)plugin.addMarker(currentMarker);
      },40);
    };

    plugin.renderSelectedOnly=()=>{
      const guid=window.selectedPortal||plugin.selectedGuid;
      const marker=plugin.findMarker(guid);
      const el=document.getElementById('rbl-selected');
      if(!el)return;
      if(!marker){el.textContent=plugin.t('touch');return}
      const d=marker.options&&marker.options.data||{};
      el.textContent=String(d.title||'Portal');
    };

    // ---------- TRAÇÉS MULTI-MISSIONS ----------
    plugin.drawRoutes=()=>{
      if(!window.L||!window.map)return;
      if(!plugin.routeLayer)plugin.routeLayer=L.layerGroup().addTo(map);
      plugin.routeLayer.clearLayers();

      const missions=plugin.state.m||[];
      const total=plugin.totalMissionCount();

      missions.forEach((arr,mi)=>{
        if(!Array.isArray(arr)||!arr.length)return;
        if(mi!==plugin.state.c&&!plugin.state.showOther)return;

        const pts=arr.map(p=>[Number(p[2]),Number(p[3])])
          .filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
        const active=mi===plugin.state.c;
        const color=active?'#36f08a':'#69a8c7';

        if(pts.length>1){
          L.polyline(pts,{
            color,
            weight:active?5:3,
            opacity:active?.9:.55,
            lineJoin:'round',
            dashArray:active?null:'7 7'
          }).addTo(plugin.routeLayer);
        }

        if(active){
          pts.forEach((ll,i)=>{
            const ic=L.divIcon({
              className:'rbl-route-dot',
              html:'<span class="active">'+(i+1)+'</span>',
              iconSize:[26,26],iconAnchor:[13,13]
            });
            L.marker(ll,{icon:ic,interactive:false}).addTo(plugin.routeLayer);
          });
        }else if(pts[0]){
          const ic=L.divIcon({
            className:'rbl-route-dot',
            html:'<span class="other">M'+(mi+1)+'</span>',
            iconSize:[28,22],iconAnchor:[14,11]
          });
          L.marker(pts[0],{icon:ic,interactive:false}).addTo(plugin.routeLayer);
        }
      });
    };

    // ---------- STATS ----------
    plugin.rad=x=>x*Math.PI/180;
    plugin.haversine=(a,b)=>{
      const lat1=Number(a?.[2]),lon1=Number(a?.[3]),lat2=Number(b?.[2]),lon2=Number(b?.[3]);
      if(![lat1,lon1,lat2,lon2].every(Number.isFinite))return 0;
      const dlat=plugin.rad(lat2-lat1),dlon=plugin.rad(lon2-lon1);
      const s=Math.sin(dlat/2)**2+
        Math.cos(plugin.rad(lat1))*Math.cos(plugin.rad(lat2))*Math.sin(dlon/2)**2;
      return 6371*2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
    };
    plugin.formatKm=km=>{
      km=Number(km)||0;
      return km<1?Math.round(km*1000)+' m':km.toFixed(km<10?2:1)+' km';
    };
    plugin.formatTime=sec=>{
      sec=Math.max(0,Math.round(Number(sec)||0));
      const h=Math.floor(sec/3600),m=Math.round((sec%3600)/60);
      return h?h+' h '+String(m).padStart(2,'0'):m+' min';
    };

    plugin.directStats=()=>{
      const missions=plugin.state.m||[];
      const perMission=missions.map((arr,mi)=>{
        let km=0,longest=0,longestNames=null;
        for(let i=0;i<arr.length-1;i++){
          const d=plugin.haversine(arr[i],arr[i+1]);
          km+=d;
          if(d>longest){longest=d;longestNames=[arr[i]?.[1]||'Portal',arr[i+1]?.[1]||'Portal']}
        }
        return {mi,km,portals:arr.length,longest,longestNames};
      });

      let total=0,transitions=0,longest=0,longestNames=null;
      perMission.forEach(x=>{
        total+=x.km;
        if(x.longest>longest){longest=x.longest;longestNames=x.longestNames}
      });

      for(let mi=0;mi<missions.length-1;mi++){
        const a=missions[mi]||[],b=missions[mi+1]||[];
        if(a.length&&b.length){
          const d=plugin.haversine(a[a.length-1],b[0]);
          transitions+=d;total+=d;
          if(d>longest){longest=d;longestNames=[a[a.length-1]?.[1]||'Portal',b[0]?.[1]||'Portal']}
        }
      }

      const portals=missions.reduce((n,m)=>n+m.length,0);
      const started=missions.filter(m=>m.length>0).length;
      const complete=missions.filter(m=>m.length>=plugin.state.ppm).length;
      return {perMission,total,transitions,portals,started,complete,longest,longestNames};
    };

    plugin.routeSignature=()=>{
      const pts=[];
      plugin.state.m.forEach((m,mi)=>m.forEach((p,pi)=>pts.push([mi,pi,p[0],p[2],p[3]])));
      return JSON.stringify(pts);
    };

    plugin.loadStatsCache=()=>{
      try{
        const obj=JSON.parse(localStorage.getItem(STATS_KEY)||'null');
        return obj&&obj.sig===plugin.routeSignature()?obj:null;
      }catch(e){return null}
    };

    plugin.saveStatsCache=walking=>{
      try{
        localStorage.setItem(STATS_KEY,JSON.stringify({
          sig:plugin.routeSignature(),walking,at:Date.now()
        }));
      }catch(e){}
    };

    plugin.flattenRoute=()=>{
      const flat=[];
      plugin.state.m.forEach((mission,mi)=>{
        mission.forEach((p,pi)=>flat.push({p,mi,pi}));
      });
      return flat;
    };

    plugin.fetchChunk=async chunk=>{
      const ctrl=new AbortController();
      const timer=setTimeout(()=>ctrl.abort(),18000);
      try{
        const lang=LANG_META[normalizeLang(plugin.state.lang)]?.[2]||'en-GB';
        const body={
          locations:chunk.map(x=>({lat:Number(x.p[2]),lon:Number(x.p[3]),type:'break'})),
          costing:'pedestrian',
          units:'kilometers',
          directions_options:{units:'kilometers',language:lang}
        };
        const r=await fetch(VALHALLA,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify(body),
          signal:ctrl.signal
        });
        if(!r.ok)throw new Error('Valhalla HTTP '+r.status);
        const data=await r.json();
        const legs=data?.trip?.legs||[];
        if(legs.length!==Math.max(0,chunk.length-1))throw new Error('Incomplete route');
        return legs.map(leg=>({
          km:Number(leg?.summary?.length)||0,
          sec:Number(leg?.summary?.time)||0
        }));
      }finally{
        clearTimeout(timer);
      }
    };

    plugin.walkStats=async()=>{
      const direct=plugin.directStats();
      const flat=plugin.flattenRoute();
      if(flat.length<2)return {direct,walking:null,error:plugin.t('needTwo')};

      const cached=plugin.loadStatsCache();
      if(cached?.walking)return {direct,walking:cached.walking,cached:true};

      const missionKm=plugin.state.m.map(()=>0);
      const missionSec=plugin.state.m.map(()=>0);
      let totalKm=0,totalSec=0,transitionKm=0,transitionSec=0;
      let longestKm=0,longestNames=null,longestMission=null;

      let start=0;
      while(start<flat.length-1){
        const end=Math.min(flat.length,start+MAX_ROUTE_POINTS);
        const chunk=flat.slice(start,end);
        const legs=await plugin.fetchChunk(chunk);

        legs.forEach((leg,i)=>{
          const a=chunk[i],b=chunk[i+1];
          totalKm+=leg.km;totalSec+=leg.sec;
          if(a.mi===b.mi){
            missionKm[a.mi]=(missionKm[a.mi]||0)+leg.km;
            missionSec[a.mi]=(missionSec[a.mi]||0)+leg.sec;
          }else{
            transitionKm+=leg.km;transitionSec+=leg.sec;
          }
          if(leg.km>longestKm){
            longestKm=leg.km;
            longestNames=[a.p?.[1]||'Portal',b.p?.[1]||'Portal'];
          }
        });

        if(end>=flat.length)break;
        start=end-1;
        await new Promise(r=>setTimeout(r,160));
      }

      missionKm.forEach((km,mi)=>{
        if(km>0&&(!longestMission||km>longestMission.km)){
          longestMission={mi,km,sec:missionSec[mi]||0};
        }
      });

      const walking={
        totalKm,totalSec,transitionKm,transitionSec,
        missionKm,missionSec,longestKm,longestNames,longestMission
      };
      plugin.saveStatsCache(walking);
      return {direct,walking,cached:false};
    };

    plugin.renderStats=async(force=false)=>{
      const box=document.getElementById('rbl-stats-box');
      if(!box)return;
      const direct=plugin.directStats();
      const current=direct.perMission[plugin.state.c]||{km:0};
      const totalMissions=plugin.totalMissionCount();

      box.innerHTML=`
        <div class="rbl-stats-grid">
          <div><b>${direct.portals}</b><span>${plugin.t('portals')}</span></div>
          <div><b>${direct.complete}/${totalMissions}</b><span>${plugin.t('completeMissions')}</span></div>
          <div><b>${plugin.formatKm(current.km)}</b><span>${plugin.t('straight')}</span></div>
          <div><b>${plugin.formatKm(direct.total)}</b><span>${plugin.t('straight')}</span></div>
        </div>
        <div class="rbl-stats-note">…</div>`;

      if(plugin.statsLoading)return;
      plugin.statsLoading=true;

      try{
        if(force)localStorage.removeItem(STATS_KEY);
        const result=await plugin.walkStats();
        if(!result.walking){
          box.innerHTML+=`<div class="rbl-stats-error">${result.error}</div>`;
          return;
        }

        const w=result.walking;
        const activeKm=w.missionKm[plugin.state.c]||0;
        const activeSec=w.missionSec[plugin.state.c]||0;
        const detour=direct.total>0?((w.totalKm/direct.total)-1)*100:0;
        const walkPerPortal=direct.portals?w.totalKm/direct.portals:0;
        const portalsPerKm=w.totalKm?direct.portals/w.totalKm:0;
        const avgMission=direct.started?w.totalKm/direct.started:0;
        const lm=w.longestMission
          ?`M${w.longestMission.mi+1} · ${plugin.formatKm(w.longestMission.km)}`
          :'—';
        const ls=w.longestNames
          ?`${plugin.formatKm(w.longestKm)} · ${w.longestNames[0]} → ${w.longestNames[1]}`
          :'—';

        box.innerHTML=`
          <div class="rbl-stats-grid">
            <div><b>${direct.portals}</b><span>${plugin.t('portals')}</span></div>
            <div><b>${direct.complete}/${totalMissions}</b><span>${plugin.t('completeMissions')}</span></div>
            <div><b>${plugin.formatKm(activeKm)}</b><span>${plugin.t('activeWalk')}</span></div>
            <div><b>${plugin.formatTime(activeSec)}</b><span>${plugin.t('activeTime')}</span></div>
            <div><b>${plugin.formatKm(w.totalKm)}</b><span>${plugin.t('bannerWalk')}</span></div>
            <div><b>${plugin.formatTime(w.totalSec)}</b><span>${plugin.t('theoryTime')}</span></div>
            <div><b>${plugin.formatKm(w.transitionKm)}</b><span>${plugin.t('transitions')}</span></div>
            <div><b>+${Math.max(0,detour).toFixed(0)}%</b><span>${plugin.t('civilization')}</span></div>
          </div>
          <div class="rbl-fun">
            <div><span>${plugin.t('sporty')}</span><b>${lm}</b></div>
            <div><span>${plugin.t('longestStep')}</span><b>${ls}</b></div>
            <div><span>${plugin.t('avgMission')}</span><b>${plugin.formatKm(avgMission)}</b></div>
            <div><span>${plugin.t('metersPortal')}</span><b>${Math.round(walkPerPortal*1000)} m</b></div>
            <div><span>${plugin.t('portalsKm')}</span><b>${portalsPerKm.toFixed(1)}</b></div>
            <div><span>${plugin.t('straight')}</span><b>${plugin.formatKm(direct.total)}</b></div>
          </div>
          <div class="rbl-stats-note">${result.cached?plugin.t('cached'):plugin.t('calculated')} · ${plugin.t('estimate')}</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ ${plugin.t('recalc')}</button>`;
        document.getElementById('rbl-stats-refresh').onclick=()=>plugin.renderStats(true);
      }catch(e){
        console.warn('[BannerLab Stats]',e);
        box.innerHTML+=`
          <div class="rbl-stats-error">${plugin.t('routeUnavailable')}</div>
          <button id="rbl-stats-refresh" class="rbl-stats-refresh">↻ ${plugin.t('recalc')}</button>`;
        document.getElementById('rbl-stats-refresh').onclick=()=>plugin.renderStats(true);
      }finally{
        plugin.statsLoading=false;
      }
    };

    // ---------- UI ----------
    plugin.applyGeometry=()=>{
      const root=document.getElementById('rbl-companion');
      if(!root)return;

      const safeTop=58;
      const side=6;
      const width=Math.max(230,Math.min(390,plugin.state.panelWidth||300));
      root.style.width=Math.min(width,window.innerWidth-side*2)+'px';
      root.style.maxHeight=Math.max(220,window.innerHeight-safeTop-10)+'px';

      if(plugin.state.panelX==null||plugin.state.panelY==null){
        root.style.left='auto';
        root.style.right='8px';
        root.style.bottom='auto';
        root.style.top=safeTop+'px';
        return;
      }

      const maxX=Math.max(side,window.innerWidth-root.offsetWidth-side);
      const maxY=Math.max(safeTop,window.innerHeight-root.offsetHeight-side);
      const x=Math.max(side,Math.min(maxX,plugin.state.panelX));
      const y=Math.max(safeTop,Math.min(maxY,plugin.state.panelY));

      plugin.state.panelX=x;
      plugin.state.panelY=y;
      root.style.right='auto';
      root.style.bottom='auto';
      root.style.left=x+'px';
      root.style.top=y+'px';
    };

    plugin.resetGeometry=()=>{
      const root=document.getElementById('rbl-companion');
      if(!root)return;
      const safeTop=58;
      plugin.applyGeometry();
      const w=root.offsetWidth;
      const h=root.offsetHeight;
      plugin.state.panelX=Math.max(6,(window.innerWidth-w)/2);
      plugin.state.panelY=Math.max(safeTop,safeTop+(window.innerHeight-safeTop-h)/2);
      plugin.save();
      plugin.applyGeometry();
    };

    plugin.installDrag=()=>{
      const root=document.getElementById('rbl-companion');
      const head=document.getElementById('rbl-drag');
      if(!root||!head)return;

      head.onpointerdown=e=>{
        if(e.target.closest('button'))return;
        const r=root.getBoundingClientRect();
        let sx=e.clientX,sy=e.clientY,ox=r.left,oy=r.top;
        head.setPointerCapture?.(e.pointerId);

        const move=ev=>{
          const x=ox+(ev.clientX-sx),y=oy+(ev.clientY-sy);
          const maxX=Math.max(4,window.innerWidth-root.offsetWidth-4);
          const safeTop=58;
          const maxY=Math.max(safeTop,window.innerHeight-root.offsetHeight-6);
          plugin.state.panelX=Math.max(4,Math.min(maxX,x));
          plugin.state.panelY=Math.max(safeTop,Math.min(maxY,y));
          plugin.applyGeometry();
        };

        const up=()=>{
          head.onpointermove=null;
          head.onpointerup=null;
          head.onpointercancel=null;
          plugin.save();
        };

        head.onpointermove=move;
        head.onpointerup=up;
        head.onpointercancel=up;
      };
    };

    plugin.missionChips=()=>{
      const count=plugin.totalMissionCount();
      let html='';
      for(let i=0;i<count;i++){
        const m=plugin.state.m[i]||[];
        const active=i===plugin.state.c;
        const complete=m.length>=plugin.state.ppm;
        html+=`<button class="rbl-mchip ${active?'active':''} ${complete?'complete':''}" data-mi="${i}">
          <b>${i+1}</b><span>${m.length}/${plugin.state.ppm}</span>
        </button>`;
      }
      return html;
    };

    plugin.optionsHtml=()=>{
      const langs=SUPPORTED_LANGS.map(v=>{
        const [flag,name]=LANG_META[v];
        return `<option value="${v}" ${normalizeLang(plugin.state.lang)===v?'selected':''}>${flag} ${name}</option>`;
      }).join('');

      return `
        <div class="rbl-options">
          <label>${plugin.t('language')}
            <select id="rbl-lang">${langs}</select>
          </label>

          <label>${plugin.t('progression')}
            <select id="rbl-advance">
              <option value="ask" ${plugin.state.advanceMode==='ask'?'selected':''}>${plugin.t('askAdvance')}</option>
              <option value="auto" ${plugin.state.advanceMode==='auto'?'selected':''}>${plugin.t('autoAdvance')}</option>
            </select>
          </label>

          <label class="rbl-check"><input id="rbl-classic" type="checkbox" ${plugin.state.classic?'checked':''}>
            <span><b>${plugin.t('classic')}</b><small>${plugin.t('classicHelp')}</small></span>
          </label>

          <label class="rbl-check"><input id="rbl-carry" type="checkbox" ${plugin.state.carry?'checked':''}>
            <span>${plugin.t('carry')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-direct" type="checkbox" ${plugin.state.direct?'checked':''}>
            <span>${plugin.t('direct')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-ask-action" type="checkbox" ${plugin.state.askAction?'checked':''}>
            <span>${plugin.t('askAction')}</span>
          </label>

          <label class="rbl-check"><input id="rbl-show-other" type="checkbox" ${plugin.state.showOther?'checked':''}>
            <span>${plugin.t('showOther')}</span>
          </label>

          <label>${plugin.t('panelSize')}
            <input id="rbl-width" type="range" min="230" max="390" step="10" value="${plugin.state.panelWidth}">
          </label>

          <button id="rbl-reset-pos" class="rbl-reset">${plugin.t('resetPos')}</button>

          <div class="rbl-recovery">
            <b>${plugin.t('progressRecovery')}</b>
            <small>${plugin.t('progressRecoveryHelp')}</small>
            <small class="rbl-autosave-status">${plugin.autoSaveStatus()}</small>
            <button id="rbl-reload-rbl" class="rbl-reload">${plugin.reloadRblArmed?'⚠ '+plugin.t('reloadRblConfirm'):'↻ '+plugin.t('reloadRbl')}</button>
            <button id="rbl-reset-progress" class="rbl-reset-progress">${plugin.resetProgressArmed?'⚠ '+plugin.t('resetProgressConfirm'):'⌫ '+plugin.t('resetProgress')}</button>
          </div>

          <div class="rbl-legend">
            <span><i class="active"></i>${plugin.t('activeRoute')}</span>
            <span><i class="other"></i>${plugin.t('otherRoutes')}</span>
          </div>
        </div>`;
    };

    plugin.render=()=>{
      let root=document.getElementById('rbl-companion');
      if(!root){
        root=document.createElement('div');
        root.id='rbl-companion';
        document.body.appendChild(root);
      }

      const arr=plugin.current(),total=plugin.totalLabel();

      if(plugin.collapsed){
        root.innerHTML=`<button id="rbl-open" class="rbl-mini">
          <img src="${ICON}">
          <span>M${plugin.state.c+1}/${total} · ${arr.length}/${plugin.state.ppm}</span>
        </button>`;
        plugin.applyGeometry();
        document.getElementById('rbl-open').onclick=()=>{plugin.collapsed=false;plugin.render()};
        return;
      }

      const selected=window.selectedPortal||plugin.selectedGuid;
      const existingIdx=plugin.currentIndexOfGuid(selected);
      if(existingIdx>=0)plugin.loadExistingObjective(existingIdx);

      const actionOpts=plugin.objectiveOptions().map(([v,l])=>
        `<option value="${v}" ${plugin.state.objective===v?'selected':''}>${l}</option>`
      ).join('');
      const showPass=plugin.state.objective==='PASSPHRASE';

      root.innerHTML=`
        <div class="rbl-head" id="rbl-drag">
          <span class="rbl-grip">⋮⋮</span>
          <img src="${ICON}">
          <div>
            <b>BannerLab <small>0.6.7</small></b>
            <span>${plugin.t('mission')} ${plugin.state.c+1}/${total} · ${arr.length}/${plugin.state.ppm} · ${plugin.autoSaveShortStatus()}</span>
          </div>
          <button id="rbl-collapse" title="Réduire">−</button>
        </div>

        <div class="rbl-missions">${plugin.missionChips()}</div>

        <div id="rbl-selected" class="rbl-selected">${plugin.t('touch')}</div>

        <div class="rbl-actionbox">
          <label>${plugin.t('action')}</label>
          <select id="rbl-objective">${actionOpts}</select>
          <div id="rbl-passbox" class="rbl-passbox" ${showPass?'':'hidden'}>
            <input id="rbl-question" placeholder="${plugin.t('question')}" value="${String(plugin.state.question||'').replaceAll('"','&quot;')}">
            <input id="rbl-answer" placeholder="${plugin.t('answer')}" value="${String(plugin.state.answer||'').replaceAll('"','&quot;')}">
          </div>
          ${existingIdx>=0?`<div class="rbl-existing">${plugin.t('selectedExisting')}</div>`:''}
        </div>

        ${plugin.passGuard?`
          <div class="rbl-passguard">
            <b>⚠ ${plugin.t('passIncomplete')}</b>
            <span>${plugin.t('passIncompleteHelp')}</span>
            <div>
              <button id="rbl-pass-continue">${plugin.t('continuePass')}</button>
              <button id="rbl-pass-skip">${plugin.t('skipPass')}</button>
            </div>
          </div>`:''}

        ${plugin.pendingAdvance?`
          <div class="rbl-advance">
            <b>${plugin.t('complete')} · ${arr.length}/${plugin.state.ppm}</b>
            <div>
              <button id="rbl-stay">${plugin.t('stay')}</button>
              <button id="rbl-go-next">${plugin.t('goNext')}</button>
            </div>
          </div>`:''}

        <div class="rbl-grid">
          <button id="rbl-add">${existingIdx>=0?'✓ '+plugin.t('save'):'＋ '+plugin.t('add')}</button>
          <button id="rbl-remove">↶ ${plugin.t('remove')}</button>
          <button id="rbl-prev" ${plugin.state.c===0?'disabled':''}>‹ ${plugin.t('prev')}</button>
          <button id="rbl-next" ${plugin.hasKnownTotal()&&plugin.state.c===plugin.state.n-1?'disabled':''}>${plugin.t('next')} ›</button>
        </div>

        <div class="rbl-tools">
          <button id="rbl-stats">📊 ${plugin.statsOpen?plugin.t('hideStats'):plugin.t('stats')}</button>
          <button id="rbl-options">⚙️ ${plugin.optionsOpen?plugin.t('hideOptions'):plugin.t('options')}</button>
        </div>

        ${plugin.statsOpen?'<div id="rbl-stats-box" class="rbl-stats-box"><div class="rbl-stats-note">…</div></div>':''}
        ${plugin.optionsOpen?plugin.optionsHtml():''}

        <button id="rbl-sync" class="rbl-sync">↩ ${plugin.t('sync')}</button>
        <div id="rbl-flash" class="rbl-flash"></div>`;

      plugin.applyGeometry();
      plugin.installDrag();

      document.getElementById('rbl-collapse').onclick=()=>{plugin.collapsed=true;plugin.render()};
      document.querySelectorAll('.rbl-mchip').forEach(b=>b.onclick=()=>plugin.selectMission(Number(b.dataset.mi)));

      const obj=document.getElementById('rbl-objective');
      const q=document.getElementById('rbl-question');
      const a=document.getElementById('rbl-answer');

      obj.onchange=e=>{
        plugin.state.objective=e.target.value;
        const isPass=e.target.value==='PASSPHRASE';
        document.getElementById('rbl-passbox').hidden=!isPass;
        if(isPass){
          const d=plugin.defaultMissionPassphrase();
          if(!String(plugin.state.question||'').trim())plugin.state.question=d.question;
          if(!String(plugin.state.answer||'').trim())plugin.state.answer=d.answer;
          q.value=plugin.state.question;a.value=plugin.state.answer;
        }
        plugin.save();
        if(plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid)>=0)plugin.updateExistingObjective();
      };
      q.oninput=e=>{
        plugin.state.question=e.target.value;plugin.save();
        const idx=plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid);
        if(idx>=0){
          const p=plugin.current()[idx];p[6]=e.target.value;plugin.clearPassSkipIfComplete(plugin.state.c,idx);plugin.save();
        }
      };
      a.oninput=e=>{
        plugin.state.answer=e.target.value;plugin.save();
        const idx=plugin.currentIndexOfGuid(window.selectedPortal||plugin.selectedGuid);
        if(idx>=0){
          const p=plugin.current()[idx];p[7]=e.target.value;plugin.clearPassSkipIfComplete(plugin.state.c,idx);plugin.save();
        }
      };

      document.getElementById('rbl-add').onclick=plugin.addSelected;
      document.getElementById('rbl-remove').onclick=plugin.removeSelectedOrLast;

      if(plugin.passGuard){
        document.getElementById('rbl-pass-continue').onclick=()=>plugin.resumePassGuard(false);
        document.getElementById('rbl-pass-skip').onclick=()=>plugin.resumePassGuard(true);
      }
      document.getElementById('rbl-prev').onclick=plugin.prev;
      document.getElementById('rbl-next').onclick=plugin.next;

      if(plugin.pendingAdvance){
        document.getElementById('rbl-stay').onclick=()=>{
          plugin.pendingAdvance=false;plugin.save();plugin.render();
        };
        document.getElementById('rbl-go-next').onclick=plugin.finishAdvance;
      }

      document.getElementById('rbl-stats').onclick=()=>{
        plugin.statsOpen=!plugin.statsOpen;plugin.render();
      };
      document.getElementById('rbl-options').onclick=()=>{
        plugin.optionsOpen=!plugin.optionsOpen;plugin.render();
      };
      document.getElementById('rbl-sync').onclick=plugin.sync;

      if(plugin.optionsOpen){
        document.getElementById('rbl-lang').onchange=e=>{
          plugin.state.lang=normalizeLang(e.target.value);plugin.save();plugin.render();
        };
        document.getElementById('rbl-advance').onchange=e=>{
          plugin.state.advanceMode=e.target.value;plugin.save();
        };
        document.getElementById('rbl-classic').onchange=e=>{
          plugin.state.classic=e.target.checked;plugin.save();plugin.render();
        };
        document.getElementById('rbl-carry').onchange=e=>{
          plugin.state.carry=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-direct').onchange=e=>{
          plugin.state.direct=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-ask-action').onchange=e=>{
          plugin.state.askAction=e.target.checked;plugin.save();
        };
        document.getElementById('rbl-show-other').onchange=e=>{
          plugin.state.showOther=e.target.checked;plugin.save();plugin.drawRoutes();
        };
        document.getElementById('rbl-width').oninput=e=>{
          plugin.state.panelWidth=Number(e.target.value)||300;
          plugin.applyGeometry();
        };
        document.getElementById('rbl-width').onchange=plugin.save;
        document.getElementById('rbl-reset-pos').onclick=()=>{
          plugin.resetGeometry();
        };
        document.getElementById('rbl-reload-rbl').onclick=()=>{
          if(plugin.reloadRblArmed){plugin.reloadFromBannerLab();return}
          plugin.reloadRblArmed=true;plugin.resetProgressArmed=false;plugin.render();
          setTimeout(()=>{if(plugin.reloadRblArmed){plugin.reloadRblArmed=false;if(plugin.optionsOpen)plugin.render()}},5000);
        };
        document.getElementById('rbl-reset-progress').onclick=()=>{
          if(plugin.resetProgressArmed){plugin.resetProgress();return}
          plugin.resetProgressArmed=true;plugin.reloadRblArmed=false;plugin.render();
          setTimeout(()=>{if(plugin.resetProgressArmed){plugin.resetProgressArmed=false;if(plugin.optionsOpen)plugin.render()}},5000);
        };
      }

      plugin.renderSelectedOnly();
      if(plugin.statsOpen)setTimeout(()=>plugin.renderStats(false),0);
    };

    function setup(){
      const css=document.createElement('style');
      css.textContent=`
        #rbl-companion{
          position:fixed;z-index:10000;right:8px;bottom:66px;
          width:min(300px,calc(100vw - 12px));
          font-family:system-ui,-apple-system,sans-serif;color:#f3fff8;
          filter:drop-shadow(0 10px 28px rgba(0,0,0,.45));
          max-height:calc(100vh - 68px);overflow-y:auto;overflow-x:hidden;
          overscroll-behavior:contain;scrollbar-width:thin
        }
        #rbl-companion *{box-sizing:border-box}
        .rbl-head{
          display:flex;align-items:center;gap:8px;background:#07150e;
          border:1px solid rgba(54,240,138,.38);border-bottom:0;
          border-radius:15px 15px 0 0;padding:7px 8px;touch-action:none;
          position:sticky;top:0;z-index:4
        }
        .rbl-grip{font-weight:900;color:#5b806a;letter-spacing:-3px;cursor:move}
        .rbl-head img{width:36px;height:36px;border-radius:10px;object-fit:cover}
        .rbl-head div{min-width:0;flex:1}
        .rbl-head b{font-size:13px;display:block}.rbl-head b small{font-size:9px;color:#58f69d}
        .rbl-head span:not(.rbl-grip){font-size:10px;color:#9bb6a7}
        .rbl-head button{width:32px;height:32px;border:0;border-radius:9px;background:#10291b;color:#fff;font-size:20px}

        .rbl-missions{
          display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:5px;padding:5px 7px;background:#0b1d13;
          border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)
        }
        .rbl-mchip{min-width:0;width:100%;border:1px solid #294a37;border-radius:8px;background:#10271b;color:#a9c1b2;padding:4px 2px}
        .rbl-mchip b{display:block;font-size:11px}.rbl-mchip span{font-size:8px}
        .rbl-mchip.complete{border-color:#4f86a2;color:#a9d8ef;background:#10222a}
        .rbl-mchip.active{background:#36f08a;color:#06150c;border-color:#36f08a}

        .rbl-selected{
          background:#091910;padding:7px 9px;border-left:1px solid rgba(54,240,138,.35);
          border-right:1px solid rgba(54,240,138,.35);white-space:nowrap;overflow:hidden;
          text-overflow:ellipsis;font-size:11px;font-weight:750
        }
        .rbl-actionbox{background:#07150e;padding:6px 8px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-actionbox label,.rbl-options>label{display:block;font-size:9px;color:#83a58f;margin-bottom:3px}
        .rbl-actionbox select,.rbl-passbox input,.rbl-options select{
          width:100%;min-height:33px;border:1px solid #244b34;border-radius:8px;background:#0e2519;color:#fff;padding:5px 7px;font-size:11px
        }
        .rbl-passbox{display:grid;gap:4px;margin-top:4px}.rbl-passbox[hidden]{display:none}
        .rbl-existing{margin-top:5px;padding:5px 7px;border-radius:7px;background:#102a38;color:#b8ddf0;font-size:9px}

        .rbl-passguard{padding:7px 8px;background:#2a1710;border-left:1px solid #8a4d2d;border-right:1px solid #8a4d2d}
        .rbl-passguard>b{display:block;font-size:10px;color:#ffcfad}.rbl-passguard>span{display:block;font-size:8px;color:#dcae91;margin-top:2px;line-height:1.35}
        .rbl-passguard>div{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:6px}
        .rbl-passguard button{min-height:34px;border:1px solid #754129;border-radius:8px;background:#1c100b;color:#fff;font-weight:750;font-size:9px}
        .rbl-passguard button:first-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-advance{padding:7px 8px;background:#2a2310;border-left:1px solid #6e5d23;border-right:1px solid #6e5d23}
        .rbl-advance>b{font-size:10px;color:#ffe59a}.rbl-advance>div{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:5px}
        .rbl-advance button{min-height:34px;border:1px solid #6e5d23;border-radius:8px;background:#1d1a0d;color:#fff;font-weight:750}
        .rbl-advance button:last-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;background:#07150e;padding:6px 7px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-grid button{min-height:38px;border:1px solid #244b34;border-radius:9px;background:#10291b;color:#f3fff8;font-weight:750;font-size:11px}
        .rbl-grid button:disabled{opacity:.35}.rbl-grid button:first-child{background:#36f08a;color:#05130b;border-color:#36f08a}

        .rbl-tools{display:grid;grid-template-columns:1fr 1fr;gap:5px;background:#07150e;padding:0 7px 6px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-tools button{min-height:34px;border:1px solid #244b34;border-radius:8px;background:#0e2519;color:#a8e8c2;font-weight:750;font-size:10px}

        .rbl-options{background:#07150e;padding:7px 9px;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35)}
        .rbl-options>label{margin:0 0 8px}
        .rbl-check{display:flex!important;align-items:center;gap:7px;background:#0b2015;border-radius:8px;padding:6px!important;color:#cee5d6!important}
        .rbl-check input{width:17px;height:17px;accent-color:#36f08a}.rbl-check span{font-size:10px}.rbl-check b{display:block}.rbl-check small{display:block;color:#7fa08c;font-size:8px}
        #rbl-width{width:100%;accent-color:#36f08a}.rbl-reset{width:100%;min-height:32px;border:1px solid #244b34;border-radius:8px;background:#10291b;color:#d8eee0;font-weight:700}
        .rbl-recovery{margin-top:8px;padding:7px;border:1px solid #244b34;border-radius:9px;background:#091a11;display:grid;gap:5px}
        .rbl-recovery>b{font-size:10px;color:#c9f5d9}.rbl-recovery>small{font-size:8px;line-height:1.35;color:#83a58f}
        .rbl-recovery .rbl-autosave-status{color:#58f69d;font-weight:800}
        .rbl-recovery button{width:100%;min-height:32px;border:1px solid #2a5a3c;border-radius:8px;background:#10291b;color:#e5fff0;font-weight:750;font-size:9px}
        .rbl-recovery .rbl-reset-progress{border-color:#704038;background:#281411;color:#ffd8d1}
        .rbl-legend{display:flex;gap:10px;margin-top:7px;font-size:8px;color:#8da895}.rbl-legend span{display:flex;align-items:center;gap:4px}
        .rbl-legend i{width:14px;height:3px;border-radius:2px}.rbl-legend i.active{background:#36f08a}.rbl-legend i.other{background:#69a8c7}

        .rbl-stats-box{background:#07150e;border-left:1px solid rgba(54,240,138,.35);border-right:1px solid rgba(54,240,138,.35);padding:7px}
        .rbl-stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px}.rbl-stats-grid div{background:#0d2418;border:1px solid #1e432e;border-radius:8px;padding:6px;min-width:0}
        .rbl-stats-grid b{display:block;font-size:12px}.rbl-stats-grid span{display:block;color:#8cae9a;font-size:7px;margin-top:2px}
        .rbl-fun{margin-top:6px;border-top:1px dashed #214a32;padding-top:4px}.rbl-fun div{display:flex;justify-content:space-between;gap:6px;padding:2px 0;font-size:8px}
        .rbl-fun span{color:#87a794}.rbl-fun b{color:#dff9e9;text-align:right;max-width:64%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .rbl-stats-note{font-size:7px;line-height:1.35;color:#6f927c;margin-top:5px}.rbl-stats-error{font-size:8px;color:#ffb9a8;margin-top:5px}
        .rbl-stats-refresh{width:100%;min-height:30px;margin-top:5px;border:1px solid #27563a;border-radius:7px;background:#10291b;color:#8ff2b8;font-weight:750}

        .rbl-sync{width:100%;min-height:38px;border:1px solid rgba(54,240,138,.35);border-radius:0 0 15px 15px;background:#163c28;color:#58f69d;font-weight:800;font-size:11px}
        .rbl-flash{position:absolute;left:8px;right:8px;bottom:-32px;background:#020a05;color:#fff;border-radius:8px;padding:6px;font-size:10px;text-align:center;opacity:0;pointer-events:none;transition:.18s}
        .rbl-flash.show{opacity:1}
        .rbl-mini{display:flex;align-items:center;gap:7px;border:1px solid rgba(54,240,138,.45);border-radius:999px;background:#07150e;color:#fff;padding:4px 9px 4px 4px;font-weight:800}
        .rbl-mini img{width:34px;height:34px;border-radius:50%;object-fit:cover}

        .rbl-route-dot{background:transparent!important;border:0!important}
        .rbl-route-dot span{display:grid;place-items:center;color:#fff;font:bold 10px system-ui;box-shadow:0 2px 7px #000}
        .rbl-route-dot .active{width:26px;height:26px;border-radius:50%;background:#07150e;border:2px solid #36f08a}
        .rbl-route-dot .other{min-width:28px;height:22px;padding:0 4px;border-radius:999px;background:#112936;border:2px solid #69a8c7;font-size:8px}
      `;
      document.head.appendChild(css);

      plugin.load();
      plugin.render();
      plugin.drawRoutes();

      window.addHook('portalSelected',plugin.handlePortalSelected);
      window.addHook('mapDataRefreshEnd',plugin.drawRoutes);
      window.addEventListener('resize',()=>{plugin.applyGeometry();plugin.drawRoutes()});

      if(window.IITC&&IITC.toolbox&&IITC.toolbox.addButton){
        IITC.toolbox.addButton({
          label:'BannerLab',
          title:'Redacted BannerLab Companion',
          action:()=>{plugin.collapsed=!plugin.collapsed;plugin.render()}
        });
      }
    }

    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')plugin.save('hidden')});
    window.addEventListener('pagehide',()=>plugin.save('pagehide'));
    window.addEventListener('beforeunload',()=>plugin.save('beforeunload'));
    // Redondance volontaire : même si Android tue la WebView sans événement de fermeture,
    // l'état courant est réécrit périodiquement tant que le Companion est vivant.
    setInterval(()=>{if(plugin.state)plugin.save('heartbeat')},3000);

    setup.info={script:{name:'Redacted BannerLab IITC Companion',version:'0.6.7'}};
    window.bootPlugins=window.bootPlugins||[];
    window.bootPlugins.push(setup);
    if(window.iitcLoaded)setup();
  }

  const s=document.createElement('script');
  s.textContent='('+wrapper+')();';
  (document.body||document.head||document.documentElement).appendChild(s);
})();
