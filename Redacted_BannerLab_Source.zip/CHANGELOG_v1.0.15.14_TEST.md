# Redacted BannerLab 1.0.15.14 TEST · build 11515

## Visuels Arcade / Redacted

- Les portraits **IGOR**, **RITA** et **REDACTED** utilisés dans l’Arcade sont désormais basés directement sur les trois visuels carrés fournis pour cette série.
- Les trois fichiers Arcade sont normalisés à **1536 × 1536 px** et utilisent exactement le même cadrage CSS dans les cartes.
- Le vieux Redacted détouré a été retiré des interfaces de réglages / tutoriels : ces zones utilisent maintenant le **launcher/logo Redacted actuel**.
- Le vieux sprite détouré reste uniquement là où il est nécessaire au gameplay de Faction Drop.
- Aucune image n’a été générée.
