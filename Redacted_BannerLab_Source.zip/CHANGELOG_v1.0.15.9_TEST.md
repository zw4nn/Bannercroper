# Redacted BannerLab 1.0.15.9 TEST · build 11510

## Arcade — présentation de REDACTED harmonisée

- Le mini-jeu de Redacted utilise désormais explicitement la **vignette launcher/logo** de l’application pour représenter REDACTED.
- Harmonisation du titrage avec les autres cartes : **REDACTED · Faction Drop**.
- Harmonisation du nom affiché dans les dialogues et briefings : **REDACTED** en capitales.
