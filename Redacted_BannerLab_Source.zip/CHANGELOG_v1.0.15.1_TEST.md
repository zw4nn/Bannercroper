# Redacted BannerLab 1.0.15.1 TEST · build 11502

## 🕹️ L’Arcade du Lab

Un easter egg complet remplace l’ancienne animation secrète.

- **7 pressions sur Redacted** dans l’en-tête ouvrent désormais une entrée cachée du laboratoire.
- Redacted apparaît et propose d’ouvrir **l’Arcade du Lab**.
- 5 mini-jeux tactiles embarqués, sans serveur et sans connexion :
  - **IGOR · Portal Panic** : stabiliser les portails actifs et éviter les anomalies.
  - **MILO · Launch Sequence** : toucher les missions 1 → 6 dans le bon ordre, le plus vite possible.
  - **RITA · Signal Storm** : intercepter les bons signaux et laisser passer les paquets corrompus.
  - **Redacted · Lab Escape** : changer de voie, récupérer les cellules et éviter les caisses du laboratoire.
  - **Lab Memory** : retrouver les paires du personnel du Lab.
- Records conservés uniquement en local sur l’appareil.
- Sons synthétiques légers activables/désactivables et retours haptiques quand Android les autorise.
- Interface plein écran néon/terminal cohérente avec le Lab.
- Ajout de l’avatar **RITA** existant au paquet de l’application, sans nouvelle génération d’image.

Version de test uniquement. IGOR 0.6.10 et MILO 0.5.1 restent inchangés.
