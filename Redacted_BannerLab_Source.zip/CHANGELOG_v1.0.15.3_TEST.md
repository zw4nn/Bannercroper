# Redacted BannerLab 1.0.15.3 TEST · build 11504

## Portal Blaster — jouabilité revue

- Déplacement plus fluide avec **joystick horizontal** et **flèches latérales**.
- Les ennemis principaux sont désormais ceux de la **faction adverse**.
- Les objets de la **faction du joueur** apparaissent moins souvent et servent de **bonus**.
- Ajout d’un **compteur de points de vie** visible sur les ennemis.
- Les ennemis deviennent plus résistants avec le niveau.
- Les ennemis **Machina rouges** sont plus durs : points de vie environ doublés + explosion à la destruction.
