import './leon.css';
import { Capacitor, CapacitorHttp } from '@capacitor/core';
import { LEON_TEXT_OVERRIDES, LEON_ACTION_TRANSLATIONS, LEON_LOCALES } from './leon-i18n.js';
import { leonTimerText } from './leon-timers-i18n.js';

const PREF_KEY='rbl-leon-v1';
const EVENTS_URL='https://prod-ingress.ingress.com/plfe/events';

const LEVELS=[
  {level:1,ap:0,medals:'—'},
  {level:2,ap:2500,medals:'—'},
  {level:3,ap:20000,medals:'—'},
  {level:4,ap:70000,medals:'—'},
  {level:5,ap:150000,medals:'—'},
  {level:6,ap:300000,medals:'—'},
  {level:7,ap:600000,medals:'—'},
  {level:8,ap:1200000,medals:'—'},
  {level:9,ap:2400000,medals:'1 Gold + 4 Silver'},
  {level:10,ap:4000000,medals:'2 Gold + 5 Silver'},
  {level:11,ap:6000000,medals:'4 Gold + 6 Silver'},
  {level:12,ap:8400000,medals:'6 Gold + 7 Silver'},
  {level:13,ap:12000000,medals:'1 Platinum + 7 Gold'},
  {level:14,ap:17000000,medals:'2 Platinum'},
  {level:15,ap:24000000,medals:'3 Platinum'},
  {level:16,ap:40000000,medals:'2 Onyx + 4 Platinum'}
];

// Valeurs AP de base. Les bundles évitent les comptes absurdes du style
// « capture + premier réso » comptés deux fois.
export const LEON_AP_ACTIONS=[
  {id:'fullCapture',ap:1925,icon:'◉',labelFr:'Capturer + déployer entièrement un portail neutre',labelEn:'Capture + fully deploy a neutral Portal',shortFr:'portail(s) capturé(s) et entièrement déployé(s)',shortEn:'Portal(s) captured and fully deployed',default:true,effort:4.4},
  {id:'capture',ap:800,icon:'◎',labelFr:'Capturer un portail neutre (capture + 1er résonateur)',labelEn:'Capture a neutral Portal (capture + first Resonator)',shortFr:'portail(s) neutre(s) capturé(s)',shortEn:'neutral Portal(s) captured',default:true,effort:1.7},
  {id:'resonator',ap:125,icon:'◆',labelFr:'Poser un résonateur',labelEn:'Deploy a Resonator',shortFr:'résonateur(s) posé(s)',shortEn:'Resonator(s) deployed',default:true,effort:.72},
  {id:'mod',ap:125,icon:'▣',labelFr:'Poser un mod',labelEn:'Deploy a Portal Mod',shortFr:'mod(s) posé(s)',shortEn:'Portal Mod(s) deployed',default:true,effort:.68},
  {id:'link',ap:313,icon:'↗',labelFr:'Tirer un lien simple',labelEn:'Create a simple Link',shortFr:'lien(s) simple(s) tiré(s)',shortEn:'simple Link(s) created',default:true,effort:.85},
  {id:'field',ap:1563,icon:'△',labelFr:'Tirer un lien qui ferme 1 field (313 + 1 250)',labelEn:'Create a Link that closes 1 Field (313 + 1,250)',shortFr:'lien(s) fermant 1 field',shortEn:'Link(s) closing 1 Field',default:true,effort:.92},
  {id:'doubleField',ap:2813,icon:'◇',labelFr:'Tirer un lien qui ferme 2 fields (313 + 2 × 1 250)',labelEn:'Create a Link that closes 2 Fields (313 + 2 × 1,250)',shortFr:'lien(s) fermant 2 fields',shortEn:'Link(s) closing 2 Fields',default:false,effort:.96},
  {id:'upgrade',ap:65,icon:'↑',labelFr:"Upgrader le résonateur d’un autre Agent",labelEn:"Upgrade another Agent's Resonator",shortFr:'résonateur(s) allié(s) upgradé(s)',shortEn:'allied Resonator(s) upgraded',default:true,effort:.78},
  {id:'hackFriendly',ap:100,icon:'⌁',labelFr:'Hacker un portail allié',labelEn:'Hack a friendly Portal',shortFr:'hack(s) allié(s)',shortEn:'friendly hack(s)',default:false,effort:1.45},
  {id:'hackEnemy',ap:200,icon:'⌁',labelFr:'Hacker un portail ennemi',labelEn:'Hack an enemy Portal',shortFr:'hack(s) ennemi(s)',shortEn:'enemy hack(s)',default:false,effort:1.35},
  {id:'destroyRes',ap:75,icon:'✕',labelFr:'Détruire un résonateur ennemi',labelEn:'Destroy an enemy Resonator',shortFr:'résonateur(s) ennemi(s) détruit(s)',shortEn:'enemy Resonator(s) destroyed',default:true,effort:.62},
  {id:'destroyMod',ap:80,icon:'✕',labelFr:'Détruire un mod ennemi',labelEn:'Destroy an enemy Portal Mod',shortFr:'mod(s) ennemi(s) détruit(s)',shortEn:'enemy Portal Mod(s) destroyed',default:false,effort:.62},
  {id:'destroyLink',ap:187,icon:'╱',labelFr:'Détruire un lien ennemi',labelEn:'Destroy an enemy Link',shortFr:'lien(s) ennemi(s) détruit(s)',shortEn:'enemy Link(s) destroyed',default:true,effort:.64},
  {id:'destroyField',ap:750,icon:'▽',labelFr:'Détruire un field ennemi',labelEn:'Destroy an enemy Field',shortFr:'field(s) ennemi(s) détruit(s)',shortEn:'enemy Field(s) destroyed',default:true,effort:.66}
];

const ACTIONS=LEON_AP_ACTIONS;

const FALLBACK_EVENTS=[
  {name:'Operation Luna 2026',start:'2026-09-01T18:00:00Z',end:'2026-09-30T18:00:00Z',factor:1,noteFr:'Campagnes et récompenses AP fixes, sans multiplicateur AP global annoncé.',noteEn:'Campaigns and fixed AP rewards; no global AP multiplier announced.'},
  {name:'Apollo Global Op',start:'2026-08-26T18:00:00Z',end:'2026-09-16T18:00:00Z',factor:1,noteFr:'Opération globale active, sans multiplicateur AP global annoncé.',noteEn:'Global operation active; no global AP multiplier announced.'},
  {name:'Autumn Equinox 2026',start:'2026-09-01T18:00:00Z',end:'2026-09-30T18:00:00Z',factor:1,noteFr:'Campagne globale active, sans multiplicateur AP global annoncé.',noteEn:'Global campaign active; no global AP multiplier announced.'}
];

const TXT={
  fr:{
    title:'LEON',sub:'Leveling & Exact Operations Navigator',job:'Employé du Lab · Comptable pathologique des AP',intro:"Donne-moi ton AP. Je te donne le chemin. Et quand je dis tout pile, tu ne touches plus au Scanner.",
    current:'AP actuels',target:'Objectif',custom:'AP personnalisé',sourceInput:'Votre AP ou vos statistiques Ingress',sourceHint:'Tape simplement ton nombre d’AP ou colle directement le texte « Partager les statistiques » du Scanner. LEON détecte tout seul ce que tu lui donnes.',parsed:'Stats reconnues',apDetected:'AP détectés',parseFail:"LEON n’arrive pas à reconnaître ces données. Entre un nombre d’AP ou colle le partage texte complet du Scanner.",
    exact:'🎯 TOUT PILE',
    actions:'Actions disponibles',network:'Événements & bonus AP',checking:'LEON vérifie le calendrier officiel Ingress…',refresh:'Actualiser',official:'Calendrier officiel Ingress',offline:'Vérification en ligne impossible. Données de secours affichées.',sourceOfficial:'🟢 Données officielles en ligne',sourceFallback:'🟠 Données de secours',
    noBonus:'Aucun multiplicateur AP global détecté actuellement.',eventBonus:'Bonus événement détecté',manualFactor:'Bonus événement',apex:'Apex actif',apexNormal:'×2',totalFactor:'Multiplicateur total',calculate:'CALCULER LE TOUT PILE',
    remaining:'AP à gagner',plan:'PLAN DE LEON',base:'AP de base',withBonus:'avec bonus',result:'Résultat',exactHit:'OBJECTIF EXACT',dontTouch:'NE TOUCHE PLUS À RIEN.',impossible:'TOUT PILE IMPOSSIBLE AVEC CE MULTIPLICATEUR',impossibleText:'Le reste n’est pas divisible par le multiplicateur AP actuel. LEON peut t’amener au plus près en dessous, puis terminer quand le bonus change.',
    already:'Objectif déjà atteint. LEON refuse de fabriquer des AP négatifs, même pour te faire plaisir.',invalid:'Entre un AP actuel et un objectif valides.',recharge:'Ajustement par recharge',rechargeDetail:'AP via recharge (environ {xm} XM si la recharge permet ce montant)',
    medals:'Condition médailles',medalWarn:'Les statistiques partagées ne donnent pas toutes les médailles. À partir du L9, vérifie aussi cette condition dans le Scanner.',
    eventFixed:'Récompense AP fixe éventuelle non incluse dans le calcul tant qu’elle n’est pas réclamée.',
    live:'EN COURS',upcoming:'À VENIR',sourceTime:'Vérifié',close:'Fermer',reset:'Réinitialiser',
    apPerAction:'AP',selectedCount:'{n} actions activées',actionsHint:'LEON n’a qu’un mode : TOUT PILE. Il cherche d’abord un résultat exactement égal à l’objectif puis, parmi les solutions exactes, privilégie le plan estimé le plus rapide avec les actions cochées. Les petites actions et la recharge servent uniquement à la finition.',closest:'Plan au plus près',missing:'reste',
    noPlan:"Je n’ai pas trouvé de combinaison pratique avec les actions cochées. Active la recharge ou davantage d’actions.",
    rechargeToggle:'Autoriser la recharge pour l’ajustement final',rechargeMax:'Ajustement recharge max.',
    exactNote:'Les bundles « field » incluent le lien qui le crée. « Capture complète » inclut capture + 8 résonateurs + bonus du 8e, pour éviter de compter deux fois.',
    eventAuto:'AUTO',eventManual:'manuel',statsCurrent:'Current AP',level:'Niveau',agent:'Agent'
  },
  en:{
    title:'LEON',sub:'Leveling & Exact Operations Navigator',job:'Lab employee · Pathological AP accountant',intro:'Give me your AP. I give you the route. And when I say exact, stop touching the Scanner.',
    current:'Current AP',target:'Target',custom:'Custom AP',sourceInput:'Your AP or Ingress statistics',sourceHint:'Type your AP number or paste the Scanner “Share statistics” text. LEON automatically detects what you gave it.',parsed:'Stats recognized',apDetected:'AP detected',parseFail:'LEON cannot recognize these data. Enter an AP number or paste the full Scanner text export.',
    exact:'🎯 EXACT',actions:'Available actions',network:'Events & AP bonuses',checking:'LEON is checking the official Ingress calendar…',refresh:'Refresh',official:'Official Ingress calendar',offline:'Online check failed. Showing built-in fallback data.',sourceOfficial:'🟢 Official online data',sourceFallback:'🟠 Fallback data',noBonus:'No global AP multiplier detected right now.',eventBonus:'Event bonus detected',manualFactor:'Event bonus',apex:'Apex active',apexNormal:'×2',totalFactor:'Total multiplier',calculate:'CALCULATE EXACT PLAN',remaining:'AP to earn',plan:"LEON'S PLAN",base:'base AP',withBonus:'with bonus',result:'Result',exactHit:'EXACT TARGET',dontTouch:'STOP TOUCHING ANYTHING.',impossible:'EXACT TARGET IMPOSSIBLE WITH THIS MULTIPLIER',impossibleText:'The remaining AP is not divisible by the current AP multiplier. LEON can bring you just below it, then finish when the bonus changes.',already:'Target already reached. LEON refuses to manufacture negative AP.',invalid:'Enter valid current AP and target values.',recharge:'Recharge adjustment',rechargeDetail:'AP via recharge (about {xm} XM if enough charge is missing)',medals:'Medal requirement',medalWarn:'Shared stats do not include every medal. From L9 onward, verify this requirement in the Scanner too.',eventFixed:'Potential fixed campaign AP rewards are not included until claimed.',live:'LIVE',upcoming:'UPCOMING',sourceTime:'Checked',close:'Close',reset:'Reset',apPerAction:'AP',selectedCount:'{n} actions enabled',actionsHint:'LEON has one mode only: EXACT. It first requires a result exactly equal to the target, then chooses the estimated fastest exact plan using the checked actions. Small actions and recharge are only used for final adjustment.',closest:'Closest plan',missing:'remaining',noPlan:'No practical combination found with the enabled actions. Enable recharge or more actions.',rechargeToggle:'Allow recharge for final adjustment',rechargeMax:'Max recharge adjustment',exactNote:'Field bundles include the Link that creates them. “Full capture” includes capture + 8 Resonators + the 8th Resonator bonus, avoiding double counting.',eventAuto:'AUTO',eventManual:'manual',statsCurrent:'Current AP',level:'Level',agent:'Agent'
  }
};

Object.assign(TXT.fr,{timeOptimized:'optimisé pour le temps',pasteStats:'ou colle ici « Partager les statistiques »',fallbackEventNote:'Événement actif, sans multiplicateur AP global annoncé.'});
Object.assign(TXT.en,{timeOptimized:'time-optimized',pasteStats:'or paste “Share statistics” here',fallbackEventNote:'Active event; no global AP multiplier announced.'});
for(const [code,pack] of Object.entries(LEON_TEXT_OVERRIDES))TXT[code]=Object.assign(TXT[code]||{},pack);

let root=null;
let lang='fr';
let t=TXT.fr;
let eventState={factor:1,apexFactor:2,events:[],checkedAt:null,source:'none',error:false};

function esc(v=''){return String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
function num(v){const n=Number(String(v??'').replace(/[^0-9.-]/g,''));return Number.isFinite(n)?Math.max(0,Math.trunc(n)):0}
function fmt(n){return new Intl.NumberFormat(LEON_LOCALES[lang]||'en-US').format(Math.max(0,Math.trunc(n||0)))}
function actionText(a,kind='label'){const local=LEON_ACTION_TRANSLATIONS[a.id]?.[lang]?.[kind];if(local)return local;return lang==='fr'?(kind==='short'?a.shortFr:a.labelFr):(kind==='short'?a.shortEn:a.labelEn)}
function tr(k,vars={}){let s=t[k]??TXT.en[k]??k;for(const [a,b] of Object.entries(vars))s=String(s).replaceAll(`{${a}}`,String(b));return s}
function currentLevelForAp(ap){let out=LEVELS[0];for(const l of LEVELS)if(ap>=l.ap)out=l;return out}
function savePref(){if(!root)return;try{localStorage.setItem(PREF_KEY,JSON.stringify(readForm()))}catch{}}
function loadPref(){try{return JSON.parse(localStorage.getItem(PREF_KEY)||'{}')||{}}catch{return{}}}
function parseNumberLoose(v=''){const digits=String(v).replace(/[\s,._']/g,'').replace(/[^0-9-]/g,'');const n=Number(digits);return Number.isFinite(n)?Math.max(0,Math.trunc(n)):null}

function parseStats(raw){
  const text=String(raw||'').trim();
  if(!text)return null;
  const lines=text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  let data={};
  for(let i=0;i<lines.length;i++){
    if(/Current AP/i.test(lines[i])&&lines[i].includes('\t')){
      const headers=lines[i].split('\t').map(s=>s.trim());
      const values=(lines[i+1]||'').split('\t').map(s=>s.trim());
      if(values.length>=Math.min(3,headers.length))headers.forEach((h,j)=>{data[h]=values[j]??''});
      break;
    }
  }
  if(!Object.keys(data).length&&lines.length>=2&&lines[0].includes('\t')){
    const headers=lines[0].split('\t').map(s=>s.trim());
    const idx=headers.findIndex(h=>/^Current AP$/i.test(h));
    if(idx>=0){const values=lines[1].split('\t').map(s=>s.trim());headers.forEach((h,j)=>{data[h]=values[j]??''})}
  }
  const get=(names)=>{for(const n of names){const key=Object.keys(data).find(k=>k.toLowerCase()===n.toLowerCase());if(key&&data[key]!==undefined)return data[key]}return''};
  let current=parseNumberLoose(get(['Current AP']));
  let level=parseNumberLoose(get(['Level']));
  let agent=get(['Agent Name','Agent']);
  let faction=get(['Agent Faction','Faction']);
  if(current===null){
    const m=text.match(/Current\s*AP[^0-9]{0,12}([0-9][0-9\s,._']*)/i);if(m)current=parseNumberLoose(m[1]);
  }
  if(level===null){const m=text.match(/(?:^|\n|\t)Level[^0-9]{0,8}([0-9]{1,2})(?:\D|$)/i);if(m)level=parseNumberLoose(m[1])}
  if(current===null)return null;
  return {current,level:level||currentLevelForAp(current).level,agent:String(agent||''),faction:String(faction||'')};
}

function dateFromIsoText(s=''){
  const m=String(s).match(/(20\d\d-\d\d-\d\dT\d\d:\d\d(?::\d\d)?)/);if(!m)return null;
  const d=new Date(`${m[1]}Z`);return Number.isNaN(d.getTime())?null:d;
}
function cleanHtmlToLines(html=''){
  const doc=new DOMParser().parseFromString(String(html),'text/html');
  return (doc.body?.innerText||doc.body?.textContent||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
}
function titleBefore(lines,idx){
  const reject=/^(?:START|END|DURATION|LOCATION|LOCATIONS|REGISTRATION|NIANTIC|RESISTANCE|ENLIGHTENED|LIVE|UPCOMING|PAST|Image:)/i;
  for(let i=idx-1;i>=Math.max(0,idx-12);i--){const s=lines[i];if(!reject.test(s)&&s.length>3&&s.length<160)return s}
  return 'Ingress Event';
}
function parseOfficialEvents(html){
  const lines=cleanHtmlToLines(html);const out=[];
  for(let i=0;i<lines.length;i++){
    if(!/^START:?$/i.test(lines[i])&&!/^START:/i.test(lines[i]))continue;
    let start=null,startIdx=i,end=null,endIdx=-1;
    for(let j=i;j<Math.min(lines.length,i+4);j++){start=dateFromIsoText(lines[j]);if(start)break}
    for(let j=i+1;j<Math.min(lines.length,i+14);j++){if(/^END:?$/i.test(lines[j])||/^END:/i.test(lines[j])){for(let k=j;k<Math.min(lines.length,j+4);k++){end=dateFromIsoText(lines[k]);if(end){endIdx=k;break}}break}}
    if(!start||!end)continue;
    const before=Math.max(0,i-10),after=Math.min(lines.length,(endIdx>0?endIdx:i+8)+12);
    const contentBlock=lines.slice(before,(endIdx>0?endIdx:i+6)+1).join('\n');
    const metaBlock=lines.slice(i,Math.min(lines.length,(endIdx>0?endIdx:i+6)+8)).join('\n');
    const block=contentBlock;
    let name=titleBefore(lines,startIdx);
    // A title like "First Saturday 2x AP" is often the nearest useful line.
    for(let j=i-1;j>=Math.max(0,i-8);j--)if(lines[j].length<=72&&/AP|Operation|Week|Saturday|Campaign|Anomal/i.test(lines[j])&&!/^(?:START|END|DURATION|LOCATION|REGISTRATION)/i.test(lines[j])){name=lines[j];break}
    const mults=[...block.matchAll(/\b(\d+(?:\.\d+)?)\s*[x×]\s*AP\b/gi)].map(m=>Number(m[1])).filter(n=>n>=1&&n<=20);
    let factor=mults.length?Math.max(...mults):1;
    // "doubled to 4x AP with Apex" must not turn the event base factor into x4.
    if(/Apex/i.test(block)&&factor>1){const direct=block.match(/(?:earn|enjoy|award(?:ed)?|all actions)[^\n.]{0,80}?(\d+(?:\.\d+)?)\s*[x×]\s*AP/i);if(direct)factor=Number(direct[1])||factor;else if(/First Saturday/i.test(block)&&/2\s*[x×]\s*AP/i.test(block))factor=2}
    let apexFactor=2;
    const ax=block.match(/Apex[^\n.]{0,120}?(\d+(?:\.\d+)?)\s*[x×]/i);if(ax){const total=Number(ax[1]);if(total>factor&&factor>0)apexFactor=total/factor}
    const global=/LOCATION(?:S)?:?\s*Global/i.test(metaBlock)||/\bGlobal\b/i.test(metaBlock);
    out.push({name,start,end,factor:Number.isFinite(factor)?factor:1,apexFactor:Number.isFinite(apexFactor)&&apexFactor>=1?apexFactor:2,global,block});
    i=endIdx>i?endIdx:i;
  }
  return out;
}
async function fetchText(url){
  if(Capacitor.isNativePlatform()){
    const r=await CapacitorHttp.get({url,headers:{Accept:'text/html'}});if(Number(r?.status||0)!==200)throw new Error(`HTTP ${r?.status||'?'}`);return typeof r.data==='string'?r.data:JSON.stringify(r.data||'');
  }
  const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw new Error(`HTTP ${r.status}`);return await r.text();
}
function fallbackLiveEvents(now=new Date()){
  return FALLBACK_EVENTS.map(e=>({...e,start:new Date(e.start),end:new Date(e.end),global:true,apexFactor:2})).filter(e=>now>=e.start&&now<=e.end);
}
async function refreshEvents(){
  const status=root?.querySelector('.leonEventStatus');if(status)status.innerHTML=`<span class="leonSpinner"></span>${esc(tr('checking'))}`;
  const now=new Date();
  try{
    const html=await fetchText(EVENTS_URL);const all=parseOfficialEvents(html);const live=all.filter(e=>now>=e.start&&now<=e.end);
    const globalLive=live.filter(e=>e.global);
    const bonus=globalLive.filter(e=>e.factor>1).sort((a,b)=>b.factor-a.factor)[0];
    eventState={factor:bonus?.factor||1,apexFactor:bonus?.apexFactor||2,events:live,checkedAt:now,source:'official',error:false};
  }catch(e){
    console.warn('[LEON events]',e);const live=fallbackLiveEvents(now);eventState={factor:Math.max(1,...live.map(x=>x.factor||1)),apexFactor:2,events:live,checkedAt:now,source:'fallback',error:true};
  }
  applyAutoFactor();renderEventStatus();recalculate();
}
function applyAutoFactor(){
  const sel=root?.querySelector('#leonEventFactor');if(!sel)return;
  if(sel.dataset.manual==='1')return;
  const f=String(eventState.factor||1);
  if(![...sel.options].some(o=>o.value===f)){const opt=document.createElement('option');opt.value=f;opt.textContent=`×${f}`;sel.appendChild(opt)}
  sel.value=f;
  const apexLabel=root.querySelector('.leonApexFactor');if(apexLabel)apexLabel.textContent=`×${eventState.apexFactor||2}`;
}
function renderEventStatus(){
  const box=root?.querySelector('.leonEventStatus');if(!box)return;
  const now=new Date();const live=eventState.events||[];
  const rows=live.length?live.map(e=>{
    const bonus=e.factor>1?`<b>×${e.factor} AP</b>`:`<b>AP ×1</b>`;
    const note=eventState.source==='fallback'?tr('fallbackEventNote'):(lang==='fr'?(e.noteFr||''):(e.noteEn||''));
    return `<div class="leonEvent"><span>${esc(e.name)}</span>${bonus}${note?`<small>${esc(note)}</small>`:''}</div>`;
  }).join(''):`<div class="leonNoBonus">${esc(tr('noBonus'))}</div>`;
  const stamp=eventState.checkedAt?eventState.checkedAt.toLocaleTimeString(LEON_LOCALES[lang]||'en-US',{hour:'2-digit',minute:'2-digit'}):'—';
  const sourceLabel=eventState.source==='official'?tr('sourceOfficial'):tr('sourceFallback');
  box.innerHTML=`<div class="leonEventSource ${eventState.source==='official'?'ok':'fallback'}">${esc(sourceLabel)}</div>${eventState.error?`<div class="leonEventWarn">${esc(tr('offline'))}</div>`:''}${rows}<div class="leonEventFoot"><span>${esc(tr('sourceTime'))} ${esc(stamp)}</span><span>${esc(tr('eventFixed'))}</span></div>`;
}

function readForm(){
  const enabled={};root?.querySelectorAll('[data-leon-action]').forEach(x=>enabled[x.dataset.leonAction]=!!x.checked);
  return {
    current:num(root?.querySelector('#leonCurrent')?.value),targetMode:root?.querySelector('#leonTarget')?.value||'16',custom:num(root?.querySelector('#leonCustom')?.value),eventFactor:Number(root?.querySelector('#leonEventFactor')?.value||1),eventManual:root?.querySelector('#leonEventFactor')?.dataset.manual==='1',apex:!!root?.querySelector('#leonApex')?.checked,recharge:!!root?.querySelector('#leonRecharge')?.checked,rechargeMax:Math.min(5000,Math.max(0,num(root?.querySelector('#leonRechargeMax')?.value)||500)),enabled
  };
}
function targetAp(form){return form.targetMode==='custom'?form.custom:(LEVELS.find(x=>String(x.level)===String(form.targetMode))?.ap||0)}
function targetLevel(form){return form.targetMode==='custom'?null:LEVELS.find(x=>String(x.level)===String(form.targetMode))||null}
function totalMultiplier(form){return Math.max(1,form.eventFactor||1)*(form.apex?(eventState.apexFactor||2):1)}

function enabledActions(form){return ACTIONS.filter(a=>form.enabled[a.id]!==false)}
function actionCost(a){return Number(a.effort||1)}
function cloneCounts(c){return {...c}}
function addCount(c,id,n=1){const x=cloneCounts(c);x[id]=(x[id]||0)+n;return x}

// Solveur limité à la « queue » du calcul. Pour un objectif de plusieurs millions,
// une action de masse est prise en gros puis le solveur ajuste les derniers AP.
function buildDp(limit,actions){
  limit=Math.max(0,Math.trunc(limit));
  const cost=new Float64Array(limit+1);cost.fill(Number.POSITIVE_INFINITY);cost[0]=0;
  const prevAmt=new Int32Array(limit+1);prevAmt.fill(-1);
  const prevAct=new Int16Array(limit+1);prevAct.fill(-1);
  for(let x=0;x<=limit;x++){
    if(!Number.isFinite(cost[x]))continue;
    for(let i=0;i<actions.length;i++){
      const a=actions[i],nx=x+a.ap;if(nx>limit)continue;
      const nc=cost[x]+actionCost(a);
      if(nc+1e-9<cost[nx]){cost[nx]=nc;prevAmt[nx]=x;prevAct[nx]=i}
    }
  }
  return {limit,cost,prevAmt,prevAct,actions};
}
function extractDp(dp,target,rechargeAllowed,rechargeMax){
  target=Math.max(0,Math.trunc(target));if(target>dp.limit)return null;
  const maxR=rechargeAllowed?Math.min(rechargeMax,target):0;
  let best=null;
  for(let r=0;r<=maxR;r++){
    const a=target-r;if(a<0||!Number.isFinite(dp.cost[a]))continue;
    // La recharge sert de tournevis de précision, pas de centrale électrique.
    const totalCost=dp.cost[a]+r*.08+(r?1.8:0);
    if(!best||totalCost<best.score)best={amount:a,recharge:r,score:totalCost};
  }
  if(!best)return null;
  const counts={};let x=best.amount,guard=0;
  while(x>0&&guard++<100000){const ai=dp.prevAct[x];if(ai<0)break;const a=dp.actions[ai];counts[a.id]=(counts[a.id]||0)+1;x=dp.prevAmt[x]}
  if(x!==0)return null;
  return {counts,recharge:best.recharge,cost:best.score};
}
function solveBase(target,form){
  const actions=enabledActions(form);if(!actions.length&&!form.recharge)return null;
  const T=Math.max(0,Math.trunc(target));
  const TAIL=50000;
  if(T<=TAIL){const dp=buildDp(T,actions);return extractDp(dp,T,form.recharge,form.rechargeMax)}
  const ranked=[...actions].sort((a,b)=>(actionCost(a)/a.ap)-(actionCost(b)/b.ap)).slice(0,6);
  if(!ranked.length)return null;
  const maxPrimary=Math.max(...ranked.map(a=>a.ap));
  const maxTail=TAIL+maxPrimary*80;
  const dp=buildDp(maxTail,actions);
  let best=null;
  for(const primary of ranked){
    const nominal=Math.max(0,Math.floor((T-TAIL)/primary.ap));
    const back=Math.min(nominal,80);
    for(let d=0;d<=back;d++){
      const n=nominal-d,rem=T-n*primary.ap;if(rem<0||rem>dp.limit)continue;
      const tail=extractDp(dp,rem,form.recharge,form.rechargeMax);if(!tail)continue;
      const counts=cloneCounts(tail.counts);if(n)counts[primary.id]=(counts[primary.id]||0)+n;
      const score=tail.cost+n*actionCost(primary);
      if(!best||score<best.cost)best={counts,recharge:tail.recharge,cost:score};
    }
  }
  return best;
}
function planBaseAp(plan){if(!plan)return 0;let n=plan.recharge||0;for(const [id,count] of Object.entries(plan.counts||{})){const a=ACTIONS.find(x=>x.id===id);if(a)n+=a.ap*count}return n}
function planRows(plan,mult){
  if(!plan)return'';const rows=[];
  const entries=Object.entries(plan.counts||{}).filter(([,n])=>n>0).sort((a,b)=>{
    const aa=ACTIONS.find(x=>x.id===a[0]),bb=ACTIONS.find(x=>x.id===b[0]);return (bb?.ap||0)-(aa?.ap||0)
  });
  for(const [id,count] of entries){const a=ACTIONS.find(x=>x.id===id);if(!a)continue;const base=a.ap*count,total=base*mult;rows.push(`<div class="leonPlanRow"><span class="leonActionIcon">${esc(a.icon)}</span><div><strong>${fmt(count)} × ${esc(actionText(a,'short'))}</strong><small>${fmt(a.ap)} ${tr('apPerAction')} × ${fmt(count)}${mult!==1?` × ${mult}`:''}</small></div><b>+${fmt(total)}</b></div>`)}
  if(plan.recharge){const base=plan.recharge,total=base*mult;rows.push(`<div class="leonPlanRow leonRechargeRow"><span class="leonActionIcon">⚡</span><div><strong>${esc(tr('recharge'))}</strong><small>${esc(tr('rechargeDetail',{xm:fmt(base*100)}))}${mult!==1?` · ×${mult}`:''}</small></div><b>+${fmt(total)}</b></div>`)}
  return rows.join('');
}

function recalculate(){
  if(!root)return;const form=readForm(),out=root.querySelector('.leonResult');const current=form.current,target=targetAp(form),mult=totalMultiplier(form);
  updateSummary(form,mult);
  if(target<=0){out.innerHTML=`<div class="leonEmptyResult">${esc(tr('invalid'))}</div>`;savePref();return}
  const remaining=target-current;
  if(remaining<=0){out.innerHTML=`<div class="leonAlready">✓ ${esc(tr('already'))}</div>`;savePref();return}
  const exactDiv=Number.isInteger(remaining/mult);
  let baseTarget=Math.floor(remaining/mult),remainder=remaining-baseTarget*mult;
  let plan=solveBase(baseTarget,form);
  if(!plan){out.innerHTML=`<div class="leonAlready">${esc(tr('noPlan'))}</div>`;savePref();return}
  const earned=planBaseAp(plan)*mult,total=current+earned,exact=exactDiv&&total===target;
  const lvl=targetLevel(form);
  out.innerHTML=`
    ${!exactDiv?`<div class="leonImpossible"><strong>${esc(tr('impossible'))}</strong><span>${esc(tr('impossibleText'))}</span></div>`:''}
    <div class="leonPlanHead"><div><small>${esc(tr('remaining'))}</small><strong>${fmt(remaining)} AP</strong></div><div><small>${esc(tr('totalFactor'))}</small><strong>×${mult}</strong></div></div>
    <div class="leonPlanTitle"><span>🧮</span><div><b>${esc(tr('plan'))}</b><small>${esc(tr('exact'))} · ${esc(tr('timeOptimized'))}</small></div></div>
    <div class="leonPlanRows">${planRows(plan,mult)}</div>
    <div class="leonPlanTotal"><span>${esc(tr('result'))}</span><b>${fmt(total)} AP</b></div>
    ${exact?`<div class="leonExact"><b>✓ ${esc(tr('exactHit'))}</b><span>${esc(tr('dontTouch'))}</span></div>`:`<div class="leonClosest"><b>${esc(tr('closest'))}: ${fmt(total)} AP</b><span>${fmt(Math.max(0,target-total))} AP ${esc(tr('missing'))}${remainder?` · modulo ×${mult}: ${fmt(remainder)}`:''}</span></div>`}
    ${lvl&&lvl.level>=9?`<div class="leonMedal"><strong>🏅 ${esc(tr('medals'))} · L${lvl.level}</strong><b>${esc(lvl.medals)}</b><small>${esc(tr('medalWarn'))}</small></div>`:''}
    <div class="leonMathNote">${esc(tr('exactNote'))}</div>`;
  savePref();
}
function updateSummary(form,mult){
  const target=targetAp(form),remain=Math.max(0,target-form.current);const r=root.querySelector('.leonTopNumbers');if(r)r.innerHTML=`<div><span>${esc(tr('current'))}</span><b>${fmt(form.current)} AP</b></div><i>→</i><div><span>${esc(tr('target'))}</span><b>${fmt(target)} AP</b></div><div class="leonRemain"><span>${esc(tr('remaining'))}</span><b>${fmt(remain)} AP · ×${mult}</b></div>`;
  const count=Object.values(form.enabled).filter(Boolean).length;const c=root.querySelector('.leonActionCount');if(c)c.textContent=tr('selectedCount',{n:count});
  const tf=root.querySelector('.leonTotalFactor');if(tf)tf.textContent=`×${mult}`;
  const tl=targetLevel(form);const med=root.querySelector('.leonMedalInline');if(med)med.textContent=tl?.level>=9?`${tr('medals')}: ${tl.medals}`:'';
}

function actionsHtml(pref){return ACTIONS.map(a=>{const on=pref.enabled?.[a.id]!==undefined?pref.enabled[a.id]:a.default;return `<label class="leonAction"><input type="checkbox" data-leon-action="${a.id}" ${on?'checked':''}><span class="leonActionIcon">${esc(a.icon)}</span><span><b>${esc(actionText(a,'label'))}</b><small>${fmt(a.ap)} AP</small></span></label>`}).join('')}
function levelOptions(selected){return LEVELS.filter(l=>l.level>=2).map(l=>`<option value="${l.level}" ${String(selected)===String(l.level)?'selected':''}>L${l.level} · ${fmt(l.ap)} AP</option>`).join('')+`<option value="custom" ${selected==='custom'?'selected':''}>${esc(tr('custom'))}</option>`}
function panelHtml(pref){
  const current=pref.current||0,targetMode=pref.targetMode||String(Math.min(16,Math.max(2,currentLevelForAp(current).level+1))),custom=pref.custom||0,factor=String(pref.eventFactor||1),apex=!!pref.apex,recharge=pref.recharge!==false,rechargeMax=pref.rechargeMax||500;
  return `<div class="leonBack" role="dialog" aria-modal="true" aria-label="LEON"><section class="leonPanel">
    <header class="leonToolHeader"><button type="button" class="leonClose" aria-label="${esc(tr('close'))}">← LEON</button><div><strong>${esc(leonTimerText(lang,'calcDoor'))}</strong><span>${esc(leonTimerText(lang,'calcDoorSub'))}</span></div></header>
    <div class="leonTopNumbers"></div>
    <section class="leonCard leonSourceCard">
      <label class="leonSourceLabel"><span>📋 ${esc(tr('sourceInput'))}</span><small>${esc(tr('sourceHint'))}</small><textarea id="leonSourceInput" rows="3" spellcheck="false" inputmode="text" autocapitalize="off" autocomplete="off" placeholder="25 579 173

${esc(tr('pasteStats'))}">${current?String(current):''}</textarea></label>
      <input id="leonCurrent" type="hidden" value="${current||''}">
      <div class="leonSourceResult" aria-live="polite"></div>
    </section>
    <section class="leonCard leonTargetCard"><label><span>${esc(tr('target'))}</span><select id="leonTarget">${levelOptions(targetMode)}</select></label><label class="leonCustomWrap" ${targetMode==='custom'?'':'hidden'}><span>${esc(tr('custom'))}</span><input id="leonCustom" type="number" min="1" step="1" inputmode="numeric" value="${custom||''}" placeholder="17000000"></label><div class="leonMedalInline"></div></section>
    <section class="leonCard"><div class="leonCardTitle"><strong>${esc(tr('network'))}</strong><button type="button" class="leonTiny leonRefresh">↻ ${esc(tr('refresh'))}</button></div><div class="leonEventStatus"><span class="leonSpinner"></span>${esc(tr('checking'))}</div><div class="leonBonusGrid"><label><span>${esc(tr('manualFactor'))}</span><select id="leonEventFactor" data-manual="${pref.eventManual?'1':'0'}"><option value="1" ${factor==='1'?'selected':''}>×1</option><option value="2" ${factor==='2'?'selected':''}>×2</option><option value="3" ${factor==='3'?'selected':''}>×3</option><option value="4" ${factor==='4'?'selected':''}>×4</option><option value="6" ${factor==='6'?'selected':''}>×6</option></select><small class="leonAutoMark">${pref.eventManual?tr('eventManual'):tr('eventAuto')}</small></label><label class="leonSwitch"><input id="leonApex" type="checkbox" ${apex?'checked':''}><span><b>${esc(tr('apex'))}</b><small class="leonApexFactor">×2</small></span></label><div class="leonFactor"><span>${esc(tr('totalFactor'))}</span><b class="leonTotalFactor">×1</b></div></div></section>
    <details class="leonCard leonActions" open><summary><span>${esc(tr('actions'))}</span><small class="leonActionCount"></small></summary><p class="leonActionsHint">${esc(tr('actionsHint'))}</p><div class="leonActionList">${actionsHtml(pref)}</div><div class="leonRechargeOpt"><label class="leonSwitch"><input id="leonRecharge" type="checkbox" ${recharge?'checked':''}><span><b>${esc(tr('rechargeToggle'))}</b><small>1 AP / 100 XM · minimum 1 AP par recharge</small></span></label><label><span>${esc(tr('rechargeMax'))}</span><input id="leonRechargeMax" type="number" min="0" max="5000" step="25" value="${rechargeMax}"></label></div></details>
    <button type="button" class="leonCalculate">${esc(tr('calculate'))}</button>
    <section class="leonResult" aria-live="polite"></section>
    <footer class="leonFooter"><span>AP rules · TEST-17</span><a href="${EVENTS_URL}" target="_blank" rel="noreferrer">${esc(tr('official'))} ↗</a></footer>
  </section></div>`;
}

function bind(){
  const back=root;back.querySelector('.leonClose').addEventListener('click',closeLeon);back.addEventListener('click',e=>{if(e.target===back)closeLeon()});
  back.querySelector('.leonCalculate').addEventListener('click',recalculate);
  back.querySelector('.leonRefresh').addEventListener('click',()=>{const sel=back.querySelector('#leonEventFactor');sel.dataset.manual='0';back.querySelector('.leonAutoMark').textContent=tr('eventAuto');refreshEvents()});
  back.querySelector('#leonTarget').addEventListener('change',e=>{back.querySelector('.leonCustomWrap').hidden=e.target.value!=='custom';recalculate()});
  back.querySelector('#leonEventFactor').addEventListener('change',e=>{e.target.dataset.manual='1';back.querySelector('.leonAutoMark').textContent=tr('eventManual');recalculate()});
  back.querySelectorAll('input,select').forEach(el=>el.addEventListener('change',recalculate));
  back.querySelector('#leonCustom').addEventListener('input',()=>{const f=readForm();updateSummary(f,totalMultiplier(f))});
  const source=back.querySelector('#leonSourceInput');
  const sourceResult=back.querySelector('.leonSourceResult');
  let sourceTimer=0;
  const detectSource=({forceTarget=false}={})=>{
    clearTimeout(sourceTimer);
    const raw=String(source.value||'').trim();
    if(!raw){
      back.querySelector('#leonCurrent').value='';
      sourceResult.className='leonSourceResult';sourceResult.textContent='';
      const f=readForm();updateSummary(f,totalMultiplier(f));savePref();return;
    }
    // Un simple nombre = AP. Tout le reste passe dans le parseur du partage Scanner.
    const numericOnly=/^[\d\s,._']+$/.test(raw);
    if(numericOnly){
      const ap=parseNumberLoose(raw);
      if(ap!==null){
        back.querySelector('#leonCurrent').value=String(ap);
        const detectedLevel=currentLevelForAp(ap).level;
        sourceResult.className='leonSourceResult ok';
        sourceResult.innerHTML=`<b>✓ ${esc(tr('apDetected'))}</b> · ${fmt(ap)} AP · L${detectedLevel}`;
        const f=readForm();updateSummary(f,totalMultiplier(f));savePref();return;
      }
    }
    const parsed=parseStats(raw);
    if(!parsed){
      back.querySelector('#leonCurrent').value='';
      sourceResult.className='leonSourceResult bad';sourceResult.textContent=tr('parseFail');
      const f=readForm();updateSummary(f,totalMultiplier(f));savePref();return;
    }
    back.querySelector('#leonCurrent').value=String(parsed.current);
    if(forceTarget){
      const suggested=Math.min(16,Math.max(2,(parsed.level||currentLevelForAp(parsed.current).level)+1));
      back.querySelector('#leonTarget').value=String(suggested);back.querySelector('.leonCustomWrap').hidden=true;
    }
    sourceResult.className='leonSourceResult ok';
    sourceResult.innerHTML=`<b>✓ ${esc(tr('parsed'))}</b>${parsed.agent?` · ${esc(parsed.agent)}`:''}${parsed.faction?` · ${esc(parsed.faction)}`:''} · L${fmt(parsed.level)} · ${fmt(parsed.current)} AP`;
    const f=readForm();updateSummary(f,totalMultiplier(f));savePref();
  };
  source.addEventListener('input',()=>{clearTimeout(sourceTimer);sourceTimer=setTimeout(()=>detectSource(),220)});
  source.addEventListener('paste',()=>{clearTimeout(sourceTimer);sourceTimer=setTimeout(()=>detectSource({forceTarget:!loadPref().targetMode}),0)});
  detectSource();
  document.addEventListener('keydown',onKey,{capture:true});
  const pref=readForm();updateSummary(pref,totalMultiplier(pref));renderEventStatus();
}
function onKey(e){if(e.key==='Escape'&&root)closeLeon()}
export function closeLeon(notify=true){const had=!!root;document.removeEventListener('keydown',onKey,{capture:true});root?.remove();root=null;if(had&&notify)window.dispatchEvent(new CustomEvent('rbl:floor-exit',{detail:{floor:'leon'}}))}
export function openLeon(language='fr'){
  closeLeon(false);{const requested=String(language||'fr').toLowerCase().split(/[-_]/)[0];lang=TXT[requested]?requested:'en'}t=TXT[lang]||TXT.en;
  const wrap=document.createElement('div');wrap.innerHTML=panelHtml(loadPref());root=wrap.firstElementChild;document.body.appendChild(root);bind();refreshEvents();recalculate();
}
