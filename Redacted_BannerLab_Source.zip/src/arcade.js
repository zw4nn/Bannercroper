import './arcade.css';

const SCORE_KEY = 'rbl-lab-arcade-scores-v2';
const SETTINGS_KEY = 'rbl-lab-arcade-settings-v2';

let root = null;
let cleanupGame = null;
let audioCtx = null;
let activeLang = 'en';

const TXT = {
  fr: {
    access: 'ACCÈS NON DOCUMENTÉ',
    found: 'Tu as trouvé une porte qui n’était pas dans le manuel.',
    gateTitle: 'Redacted a quelque chose à te montrer.',
    gateText: 'IGOR, MILO et RITA ont manifestement utilisé du temps de calcul pour fabriquer une salle d’arcade. Personne n’a signé la demande.',
    enter: 'Lancer les mini-jeux',
    leave: 'Retour au Lab',
    arcade: 'ARCADE DU LAB',
    arcadeSub: '6 expériences parfaitement inutiles, donc indispensables.',
    best: 'Record',
    play: 'Jouer',
    back: 'Arcade',
    close: 'Fermer',
    sound: 'Son',
    newBest: 'NOUVEAU RECORD',
    score: 'Score',
    again: 'Rejouer',
    menu: 'Menu',
    time: 'Temps',
    lives: 'Vies',
    combo: 'Combo',
    round: 'Série',
    moves: 'Coups',
    level: 'Niveau',
    power: 'Puissance',
    faction: 'Couleur',
    tutorial: 'Tutoriel',
    start: 'Démarrer',
    startMission: 'Entrer dans la simulation',
    ready: 'PRÊT ?',
    go: 'GO',
    gameOver: 'FIN DE PARTIE',
    cleared: 'LAB SÉCURISÉ',
    perfect: 'SÉQUENCE COMPLÈTE',
    missed: 'Signal perdu',
    corrupt: 'Paquet corrompu',
    wrong: 'Mauvais ordre',
    stabilized: 'Portail stabilisé',
    noBest: '—',
    hidden: 'DOSSIER CLASSÉ',
    hiddenText: 'Cette zone reste invisible dans l’application normale. Elle ne s’ouvre qu’après 7 pressions sur Redacted.',
    briefing: 'Briefing',
    tutorialTitle: 'Mode d’emploi du mini-jeu',
    chooseFaction: 'Choisis ton camp avant de lancer la simulation.',
    enl: 'ENL',
    res: 'RES',
    machina: 'Machina',
    boss: 'Boss',
    bonus: 'Bonus',
    nextMission: 'Mission suivante',

    igorTitle: 'IGOR · Portal Panic',
    igorDesc: 'Stabilise la route en touchant les portails actifs. Les nœuds rouges sont des anomalies.',
    igorHelp: 'Touche le portail vert dès qu’il apparaît. Plus tu enchaînes vite, plus le combo monte. Évite les anomalies rouges.',

    miloTitle: 'MILO · Launch Sequence',
    miloDesc: 'Publie les missions dans le bon ordre avant que MILO ne perde patience.',
    miloHelp: 'Touche les missions 1 → 6 dans l’ordre. Chaque nouvelle série est mélangée. Une erreur casse le combo.',

    ritaTitle: 'RITA · Signal Storm',
    ritaDesc: 'Trie les signaux du Lab avant qu’ils ne se perdent dans le bruit Telegram.',
    ritaHelp: 'Intercepte les paquets cyan/verts avant le bas de l’écran. Laisse passer les paquets rouges corrompus.',

    dinoTitle: 'Redacted · Faction Drop',
    dinoDesc: 'Aide Redacted à traverser le laboratoire et à récupérer les bonnes caisses de faction.',
    dinoHelp: 'Choisis ENL ou RES. Ramasse les caisses de ta couleur, évite la couleur adverse et fuis les caisses Machina rouges qui explosent autour d’elles.',

    blasterTitle: 'RITA · Portal Blaster',
    blasterDesc: 'Un mini shoot arcade façon labo spatial : ta faction affronte l’autre couleur, avec portails, résonateurs Machina, niveaux et boss.',
    blasterHelp: 'Déplace ton vaisseau avec le doigt. Le tir est automatique. Détruis les portails adverses, récupère les bonus de ta couleur et fais attention aux cœurs Machina rouges : ils explosent autour d’eux.',

    memoryTitle: 'Lab Memory',
    memoryDesc: 'Retrouve les paires du personnel du Lab. Oui, ils ont tous accepté. Enfin, presque.',
    memoryHelp: 'Retourne deux cartes. Trouve toutes les paires avec le moins de coups possible.'
  },
  en: {
    access: 'UNDOCUMENTED ACCESS',
    found: 'You found a door that was not in the manual.',
    gateTitle: 'Redacted has something to show you.',
    gateText: 'IGOR, MILO and RITA apparently used compute time to build an arcade. Nobody signed the request.',
    enter: 'Launch mini-games',
    leave: 'Back to the Lab',
    arcade: 'LAB ARCADE',
    arcadeSub: '6 perfectly useless experiments, therefore essential.',
    best: 'Best',
    play: 'Play',
    back: 'Arcade',
    close: 'Close',
    sound: 'Sound',
    newBest: 'NEW HIGH SCORE',
    score: 'Score',
    again: 'Play again',
    menu: 'Menu',
    time: 'Time',
    lives: 'Lives',
    combo: 'Combo',
    round: 'Round',
    moves: 'Moves',
    level: 'Level',
    power: 'Power',
    faction: 'Faction',
    tutorial: 'Tutorial',
    start: 'Start',
    startMission: 'Enter simulation',
    ready: 'READY?',
    go: 'GO',
    gameOver: 'GAME OVER',
    cleared: 'LAB SECURED',
    perfect: 'SEQUENCE COMPLETE',
    missed: 'Signal lost',
    corrupt: 'Corrupted packet',
    wrong: 'Wrong order',
    stabilized: 'Portal stabilized',
    noBest: '—',
    hidden: 'CLASSIFIED FILE',
    hiddenText: 'This area stays invisible during normal use. It only opens after 7 taps on Redacted.',
    briefing: 'Briefing',
    tutorialTitle: 'How to play',
    chooseFaction: 'Choose your side before launching the simulation.',
    enl: 'ENL',
    res: 'RES',
    machina: 'Machina',
    boss: 'Boss',
    bonus: 'Bonus',
    nextMission: 'Next mission',

    igorTitle: 'IGOR · Portal Panic',
    igorDesc: 'Stabilize the route by tapping active portals. Red nodes are anomalies.',
    igorHelp: 'Tap the green portal as soon as it appears. Fast chains build combo. Avoid red anomalies.',

    miloTitle: 'MILO · Launch Sequence',
    miloDesc: 'Publish missions in the right order before MILO loses patience.',
    miloHelp: 'Tap missions 1 → 6 in order. Every round is shuffled. One mistake breaks the combo.',

    ritaTitle: 'RITA · Signal Storm',
    ritaDesc: 'Sort Lab signals before they disappear into Telegram noise.',
    ritaHelp: 'Intercept cyan/green packets before the bottom. Let red corrupted packets pass.',

    dinoTitle: 'Redacted · Faction Drop',
    dinoDesc: 'Help Redacted cross the lab and collect the right faction crates.',
    dinoHelp: 'Choose ENL or RES. Collect crates in your color, avoid the opposite color, and stay away from red Machina crates: they explode around themselves.',

    blasterTitle: 'RITA · Portal Blaster',
    blasterDesc: 'A tiny lab-flavored space shooter: your faction faces the other color with portals, Machina resonators, levels and bosses.',
    blasterHelp: 'Move your ship with your finger. Shooting is automatic. Destroy enemy portals, collect bonuses in your color, and beware of red Machina cores: they explode around themselves.',

    memoryTitle: 'Lab Memory',
    memoryDesc: 'Match the Lab staff pairs. Everyone consented. More or less.',
    memoryHelp: 'Flip two cards. Find every pair in as few moves as possible.'
  }
};

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const rand = (min, max) => min + Math.random() * (max - min);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

function langPack(lang) {
  return TXT[String(lang || '').toLowerCase()] || TXT.en;
}
function esc(v = '') {
  return String(v)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
function loadScores() {
  try { return JSON.parse(localStorage.getItem(SCORE_KEY) || '{}') || {}; }
  catch { return {}; }
}
function saveScore(id, score, lowerBetter = false) {
  const scores = loadScores();
  const prev = Number(scores[id] || 0);
  const better = lowerBetter ? (prev <= 0 || score < prev) : score > prev;
  if (better) {
    scores[id] = score;
    localStorage.setItem(SCORE_KEY, JSON.stringify(scores));
  }
  return { best: better ? score : prev, isBest: better };
}
function loadSettings() {
  try {
    return {
      sound: true,
      faction: 'enl',
      ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')
    };
  } catch {
    return { sound: true, faction: 'enl' };
  }
}
function saveSettings(v) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(v));
}
function buzz(ms = 16) { try { navigator.vibrate?.(ms); } catch {} }
function tone(freq = 440, dur = 0.05, vol = 0.025) {
  const st = loadSettings();
  if (!st.sound) return;
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.frequency.value = freq;
    o.type = 'sine';
    g.gain.value = vol;
    o.connect(g);
    g.connect(audioCtx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
    o.stop(audioCtx.currentTime + dur);
  } catch {}
}
function successFx() {
  tone(720, 0.06, 0.035);
  setTimeout(() => tone(980, 0.07, 0.025), 55);
  buzz(20);
}
function failFx() {
  tone(150, 0.11, 0.035);
  buzz([25, 35, 25]);
}
function clearGame() {
  try { cleanupGame?.(); } catch {}
  cleanupGame = null;
}
function setScreen(html) {
  clearGame();
  if (!root) return null;
  const body = root.querySelector('.labArcadeBody');
  body.innerHTML = html;
  return body;
}
function btnEvents(scope = root) {
  scope?.querySelectorAll('[data-arc-close]').forEach(b => (b.onclick = closeLabArcade));
  scope?.querySelectorAll('[data-arc-menu]').forEach(b => (b.onclick = showMenu));
}
function scoreLabel(id, score, t) {
  if (!score) return t.noBest;
  if (id === 'memory') return `${score} ${t.moves.toLowerCase()}`;
  return Number(score).toLocaleString();
}

export function openLabArcade(lang = 'en') {
  closeLabArcade();
  activeLang = String(lang || 'en').toLowerCase();
  const t = langPack(activeLang);
  root = document.createElement('div');
  root.className = 'labArcadeRoot';
  root.innerHTML = `
    <div class="labArcadeScan"></div>
    <div class="labArcadeShell">
      <header class="labArcadeTop">
        <div class="labArcadeMark">RBL<span>//ARCADE</span></div>
        <button class="labArcadeIcon" data-arc-close aria-label="${esc(t.close)}">×</button>
      </header>
      <div class="labArcadeBody"></div>
    </div>`;
  document.body.appendChild(root);
  root.querySelector('[data-arc-close]').onclick = closeLabArcade;
  showGate(t);
}

export function closeLabArcade() {
  clearGame();
  root?.remove();
  root = null;
}

function showGate(t) {
  const body = setScreen(`
    <section class="labArcadeGate">
      <div class="labGateNoise"></div>
      <div class="labGateBadge">${esc(t.access)}</div>
      <div class="labGateDino"><div class="labGateGlow"></div><img src="/redacted-dino-cutout.png" alt="Redacted"></div>
      <div class="labGateCopy">
        <small>${esc(t.found)}</small>
        <h2>${esc(t.gateTitle)}</h2>
        <p>${esc(t.gateText)}</p>
      </div>
      <div class="labGateActions">
        <button class="labArcadePrimary" data-enter>${esc(t.enter)}</button>
        <button class="labArcadeSecondary" data-arc-close>${esc(t.leave)}</button>
      </div>
    </section>`);
  btnEvents(body);
  body.querySelector('[data-enter]').onclick = () => {
    tone(520, 0.05);
    showMenu();
  };
}

function gamesFor(t) {
  return [
    { id: 'igor', title: t.igorTitle, desc: t.igorDesc, img: '/igor.png', cls: 'igor' },
    { id: 'milo', title: t.miloTitle, desc: t.miloDesc, img: '/assets/milo.jpg', cls: 'milo' },
    { id: 'rita', title: t.ritaTitle, desc: t.ritaDesc, img: '/rita.png', cls: 'rita' },
    { id: 'dino', title: t.dinoTitle, desc: t.dinoDesc, img: '/redacted-dino-cutout.png', cls: 'dino' },
    { id: 'blaster', title: t.blasterTitle, desc: t.blasterDesc, img: '/rita.png', cls: 'blaster' },
    { id: 'memory', title: t.memoryTitle, desc: t.memoryDesc, img: '/redacted-logo-512.png', cls: 'memory' }
  ];
}

function showMenu() {
  if (!root) return;
  const t = langPack(activeLang);
  const scores = loadScores();
  const settings = loadSettings();
  const cards = gamesFor(t)
    .map(g => `
      <button class="labGameCard ${g.cls}" data-game="${g.id}">
        <div class="labGameArt"><img src="${g.img}" alt=""><span class="labGamePulse"></span></div>
        <div class="labGameCopy">
          <small>${esc(t.best)} · ${esc(scoreLabel(g.id, scores[g.id], t))}</small>
          <strong>${esc(g.title)}</strong>
          <p>${esc(g.desc)}</p>
          <span>${esc(t.play)} ›</span>
        </div>
      </button>`)
    .join('');
  const body = setScreen(`
    <section class="labArcadeMenu">
      <div class="labMenuHero">
        <div>
          <small>${esc(t.hidden)}</small>
          <h2>${esc(t.arcade)}</h2>
          <p>${esc(t.arcadeSub)}</p>
        </div>
        <div class="labMenuControls">
          <button class="labSoundToggle ${settings.sound ? 'on' : ''}" data-sound>◉ ${esc(t.sound)}</button>
        </div>
      </div>
      <div class="labGameGrid">${cards}</div>
      <div class="labClassified"><span>⌁</span><p><b>${esc(t.hidden)}</b><br>${esc(t.hiddenText)}</p></div>
    </section>`);
  body.querySelectorAll('[data-game]').forEach(b => (b.onclick = () => launchGame(b.dataset.game, t)));
  body.querySelector('[data-sound]').onclick = e => {
    const st = loadSettings();
    st.sound = !st.sound;
    saveSettings(st);
    e.currentTarget.classList.toggle('on', st.sound);
    if (st.sound) tone(640, 0.05);
  };
}

function launchGame(id, t) {
  if (id === 'igor') return gameIgor(t);
  if (id === 'milo') return gameMilo(t);
  if (id === 'rita') return gameRita(t);
  if (id === 'dino') return gameDino(t);
  if (id === 'blaster') return gameBlaster(t);
  if (id === 'memory') return gameMemory(t);
}

function gameFrame({ title, help, img, t, extra = '', arenaClass = '' }) {
  return `
    <section class="labGameScreen">
      <div class="labGameHead">
        <button class="labBack" data-arc-menu>‹ ${esc(t.back)}</button>
        <div class="labGameIdentity">
          <img src="${img}" alt="">
          <div>
            <small>RBL // EXPERIMENT</small>
            <strong>${esc(title)}</strong>
          </div>
        </div>
      </div>
      ${help ? `<p class="labGameHelp">${esc(help)}</p>` : ''}
      ${extra}
      <div class="labGameArena ${arenaClass}"></div>
    </section>`;
}
function hud(t, parts) {
  return `<div class="labHud">${parts
    .map(([label, val, cls = '']) => `<div class="${cls}"><small>${esc(label)}</small><b data-hud="${esc(val.key)}">${esc(val.value)}</b></div>`)
    .join('')}</div>`;
}
function endPanel({ t, id, score, title, lowerBetter = false, detail = '', restart }) {
  const result = saveScore(id, score, lowerBetter);
  successFx();
  const body = root.querySelector('.labArcadeBody');
  const pane = document.createElement('div');
  pane.className = 'labEndPanel';
  pane.innerHTML = `
    <div class="labEndBurst"></div>
    <small>${result.isBest ? esc(t.newBest) : esc(title)}</small>
    <strong>${esc(id === 'memory' ? `${score} ${t.moves.toLowerCase()}` : Number(score).toLocaleString())}</strong>
    ${detail ? `<p>${esc(detail)}</p>` : ''}
    <div>
      <button class="labArcadePrimary" data-again>${esc(t.again)}</button>
      <button class="labArcadeSecondary" data-arc-menu>${esc(t.menu)}</button>
    </div>`;
  body.appendChild(pane);
  pane.querySelector('[data-again]').onclick = restart;
  pane.querySelector('[data-arc-menu]').onclick = showMenu;
}

function countdown(arena, t, go) {
  let n = 3;
  arena.innerHTML = `<div class="labCountdown"><small>${esc(t.ready)}</small><b>${n}</b></div>`;
  const iv = setInterval(() => {
    n -= 1;
    const b = arena.querySelector('.labCountdown b');
    if (!b) return;
    if (n > 0) {
      b.textContent = n;
      tone(390 + n * 80, 0.035);
    } else {
      clearInterval(iv);
      b.textContent = t.go;
      tone(760, 0.07);
      setTimeout(go, 330);
    }
  }, 520);
  cleanupGame = () => clearInterval(iv);
}

function showBriefing({ t, title, img, speakers = [], tutorial = [], onStart, factionPicker = false, accent = 'green' }) {
  const st = loadSettings();
  const selectedFaction = st.faction === 'res' ? 'res' : 'enl';
  const speakerHtml = speakers
    .map(s => `
      <div class="labSpeak ${esc(s.accent || accent)}">
        <img src="${s.img}" alt="${esc(s.name)}">
        <div class="labBubble">
          <small>${esc(s.name)}</small>
          <p>${esc(s.text)}</p>
        </div>
      </div>`)
    .join('');
  const tutorialHtml = tutorial.length
    ? `
      <div class="labTutorialPanel" hidden>
        <small>${esc(t.tutorialTitle)}</small>
        <ul>${tutorial.map(line => `<li>${esc(line)}</li>`).join('')}</ul>
      </div>`
    : '';
  const factionHtml = factionPicker
    ? `
      <div class="labFactionBlock">
        <small>${esc(t.chooseFaction)}</small>
        <div class="labFactionPicker" data-faction-picker>
          <button class="labFactionButton enl ${selectedFaction === 'enl' ? 'active' : ''}" data-faction="enl">${esc(t.enl)}</button>
          <button class="labFactionButton res ${selectedFaction === 'res' ? 'active' : ''}" data-faction="res">${esc(t.res)}</button>
        </div>
      </div>`
    : '';
  const body = setScreen(`
    <section class="labGameScreen briefingOnly">
      <div class="labGameHead">
        <button class="labBack" data-arc-menu>‹ ${esc(t.back)}</button>
        <div class="labGameIdentity">
          <img src="${img}" alt="">
          <div>
            <small>RBL // BRIEFING</small>
            <strong>${esc(title)}</strong>
          </div>
        </div>
      </div>
      <div class="labBriefingCard ${esc(accent)}">
        <div class="labBriefingTitle">
          <small>${esc(t.briefing)}</small>
          <h3>${esc(title)}</h3>
        </div>
        <div class="labSpeakList">${speakerHtml}</div>
        ${factionHtml}
        ${tutorialHtml}
        <div class="labBriefingActions">
          ${tutorial.length ? `<button class="labArcadeSecondary" data-open-tutorial>${esc(t.tutorial)}</button>` : ''}
          <button class="labArcadePrimary" data-start-briefing>${esc(t.startMission)}</button>
        </div>
      </div>
    </section>`);
  btnEvents(body);
  const tut = body.querySelector('.labTutorialPanel');
  const tutBtn = body.querySelector('[data-open-tutorial]');
  if (tut && tutBtn) {
    tutBtn.onclick = () => {
      const hidden = tut.hasAttribute('hidden');
      if (hidden) tut.removeAttribute('hidden');
      else tut.setAttribute('hidden', 'hidden');
      tone(hidden ? 680 : 280, 0.04, 0.02);
    };
  }
  body.querySelectorAll('[data-faction]').forEach(btn => {
    btn.onclick = () => {
      body.querySelectorAll('[data-faction]').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      const next = btn.dataset.faction === 'res' ? 'res' : 'enl';
      const nextSettings = loadSettings();
      nextSettings.faction = next;
      saveSettings(nextSettings);
      tone(next === 'res' ? 460 : 560, 0.04, 0.025);
    };
  });
  body.querySelector('[data-start-briefing]').onclick = () => {
    const faction = body.querySelector('[data-faction].active')?.dataset.faction || selectedFaction;
    tone(540, 0.05);
    onStart?.(faction);
  };
}

function gameIgor(t) {
  showBriefing({
    t,
    title: t.igorTitle,
    img: '/igor.png',
    accent: 'green',
    speakers: [
      { name: 'IGOR', img: '/igor.png', text: 'Je surveille le réseau de portails. Quand l’un s’active, touche-le immédiatement.', accent: 'green' },
      { name: 'Redacted', img: '/redacted-dino-cutout.png', text: 'Les nœuds rouges sont des anomalies. Si tu les touches, tu casses ton combo. Bravo le labo.', accent: 'amber' }
    ],
    tutorial: [
      'Un seul portail actif apparaît à la fois.',
      'Les portails verts rapportent des points et montent le combo.',
      'Les anomalies rouges font perdre des points et remettent le combo à ×1.'
    ],
    onStart: () => startIgor(t)
  });
}

function startIgor(t) {
  const body = setScreen(gameFrame({
    title: t.igorTitle,
    help: t.igorHelp,
    img: '/igor.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: '25' }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let combo = 1;
    let time = 25;
    let active = null;
    let timer = null;
    let spawnTimer = null;
    let ended = false;
    arena.innerHTML = `<div class="igorGrid">${Array.from({ length: 16 }, (_, i) => `<button data-cell="${i}" aria-label="portal"><span></span></button>`).join('')}</div><div class="igorRouteLine"></div>`;
    const cells = [...arena.querySelectorAll('[data-cell]')];
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const timeEl = body.querySelector('[data-hud="time"]');
    const spawn = () => {
      if (ended) return;
      cells.forEach(c => { c.className = ''; c.disabled = false; });
      const idx = Math.floor(Math.random() * cells.length);
      const anomaly = Math.random() < 0.2;
      active = { idx, anomaly, at: performance.now() };
      cells[idx].className = anomaly ? 'anomaly' : 'active';
      spawnTimer = setTimeout(() => {
        if (!ended && active?.idx === idx) {
          if (!anomaly) {
            combo = 1;
            comboEl.textContent = '×1';
          }
          spawn();
        }
      }, Math.max(430, 1050 - score / 40));
    };
    cells.forEach((c, i) => {
      c.onclick = () => {
        if (!active || i !== active.idx) return;
        clearTimeout(spawnTimer);
        const elapsed = performance.now() - active.at;
        if (active.anomaly) {
          score = Math.max(0, score - 180);
          combo = 1;
          failFx();
          c.classList.add('hitbad');
        } else {
          const gain = Math.max(55, 160 - Math.floor(elapsed / 12)) * combo;
          score += gain;
          combo = Math.min(8, combo + 1);
          successFx();
          c.classList.add('hitgood');
        }
        scoreEl.textContent = score;
        comboEl.textContent = `×${combo}`;
        active = null;
        setTimeout(spawn, 80);
      };
    });
    spawn();
    timer = setInterval(() => {
      time -= 1;
      timeEl.textContent = time;
      if (time <= 0) {
        ended = true;
        clearInterval(timer);
        clearTimeout(spawnTimer);
        cells.forEach(c => (c.disabled = true));
        endPanel({ t, id: 'igor', score, title: t.gameOver, restart: () => gameIgor(t) });
      }
    }, 1000);
    cleanupGame = () => {
      ended = true;
      clearInterval(timer);
      clearTimeout(spawnTimer);
    };
  });
}

function gameMilo(t) {
  showBriefing({
    t,
    title: t.miloTitle,
    img: '/assets/milo.jpg',
    accent: 'green',
    speakers: [
      { name: 'MILO', img: '/assets/milo.jpg', text: 'On publie proprement. Les missions doivent partir dans l’ordre, sans improvisation cosmique.', accent: 'green' },
      { name: 'RITA', img: '/rita.png', text: 'Si tu cliques la mauvaise mission, je note officiellement que c’est de ta faute.', accent: 'cyan' }
    ],
    tutorial: [
      'Repère la mission attendue dans le badge central.',
      'Toujours taper 1 → 6 dans l’ordre.',
      'Une série complète donne un bonus puis un nouveau tirage.'
    ],
    onStart: () => startMilo(t)
  });
}

function startMilo(t) {
  const body = setScreen(gameFrame({
    title: t.miloTitle,
    help: t.miloHelp,
    img: '/assets/milo.jpg',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.round, { key: 'round', value: '1' }],
      [t.time, { key: 'time', value: '30' }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let round = 1;
    let next = 1;
    let time = 30;
    let ended = false;
    let timer = null;
    let roundStarted = performance.now();
    arena.innerHTML = `<div class="miloStatus"><span>${esc(t.nextMission)}</span><b data-next>1</b></div><div class="miloGrid"></div>`;
    const grid = arena.querySelector('.miloGrid');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const roundEl = body.querySelector('[data-hud="round"]');
    const timeEl = body.querySelector('[data-hud="time"]');
    const nextEl = arena.querySelector('[data-next]');
    const tap = (n, b) => {
      if (ended) return;
      if (n !== next) {
        score = Math.max(0, score - 100);
        scoreEl.textContent = score;
        failFx();
        b.classList.add('bad');
        setTimeout(() => b.classList.remove('bad'), 240);
        return;
      }
      successFx();
      b.classList.add('done');
      b.disabled = true;
      score += 120 + Math.max(0, 180 - Math.floor((performance.now() - roundStarted) / 35));
      scoreEl.textContent = score;
      next += 1;
      if (next <= 6) {
        nextEl.textContent = next;
        return;
      }
      score += 600;
      scoreEl.textContent = score;
      round += 1;
      roundEl.textContent = round;
      nextEl.textContent = '✓';
      setTimeout(shuffle, 420);
    };
    const shuffle = () => {
      const nums = [1, 2, 3, 4, 5, 6].sort(() => Math.random() - 0.5);
      grid.innerHTML = nums.map(n => `<button data-n="${n}"><small>M</small><b>${String(n).padStart(2, '0')}</b><span>READY</span></button>`).join('');
      grid.querySelectorAll('button').forEach(b => (b.onclick = () => tap(Number(b.dataset.n), b)));
      next = 1;
      nextEl.textContent = '1';
      roundStarted = performance.now();
    };
    shuffle();
    timer = setInterval(() => {
      time -= 1;
      timeEl.textContent = time;
      if (time <= 0) {
        ended = true;
        clearInterval(timer);
        grid.querySelectorAll('button').forEach(b => (b.disabled = true));
        endPanel({ t, id: 'milo', score, title: t.perfect, restart: () => gameMilo(t) });
      }
    }, 1000);
    cleanupGame = () => {
      ended = true;
      clearInterval(timer);
    };
  });
}

function gameRita(t) {
  showBriefing({
    t,
    title: t.ritaTitle,
    img: '/rita.png',
    accent: 'cyan',
    speakers: [
      { name: 'RITA', img: '/rita.png', text: 'Les signaux utiles doivent être récupérés avant qu’ils ne plongent dans le bruit.', accent: 'cyan' },
      { name: 'IGOR', img: '/igor.png', text: 'Les paquets rouges sont corrompus. Laisse-les tomber, sauf si tu aimes saboter le réseau.', accent: 'green' }
    ],
    tutorial: [
      'Tape les paquets cyan ou verts avant la ligne au sol.',
      'Ne touche jamais les paquets rouges corrompus.',
      'Les bons paquets augmentent ton combo et ton score.'
    ],
    onStart: () => startRita(t)
  });
}

function startRita(t) {
  const body = setScreen(gameFrame({
    title: t.ritaTitle,
    help: t.ritaHelp,
    img: '/rita.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: '25' }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let combo = 1;
    let time = 25;
    let ended = false;
    let timer = null;
    let spawnIv = null;
    let raf = 0;
    let last = performance.now();
    let packets = [];
    arena.innerHTML = `<div class="ritaField"><div class="ritaAntenna">RITA // RX</div><div class="ritaFloor"></div></div>`;
    const field = arena.querySelector('.ritaField');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const timeEl = body.querySelector('[data-hud="time"]');
    const spawn = () => {
      if (ended) return;
      const bad = Math.random() < 0.27;
      const goodGreen = !bad && Math.random() < 0.35;
      const el = document.createElement('button');
      el.className = `ritaPacket ${bad ? 'bad' : goodGreen ? 'green' : 'good'}`;
      el.innerHTML = `<span>${bad ? '×' : '↧'}</span><small>${bad ? 'CORRUPT' : 'SIGNAL'}</small>`;
      const x = 8 + Math.random() * 78;
      el.style.left = `${x}%`;
      field.appendChild(el);
      const p = { el, y: -12, speed: 16 + Math.random() * 14, bad };
      packets.push(p);
      el.onclick = () => {
        if (ended) return;
        if (bad) {
          score = Math.max(0, score - 180);
          combo = 1;
          failFx();
          el.classList.add('burstbad');
        } else {
          score += 110 * combo;
          combo = Math.min(7, combo + 1);
          successFx();
          el.classList.add('burstgood');
        }
        scoreEl.textContent = score;
        comboEl.textContent = `×${combo}`;
        setTimeout(() => el.remove(), 180);
        packets = packets.filter(q => q !== p);
      };
    };
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      for (const p of [...packets]) {
        p.y += p.speed * dt;
        p.el.style.transform = `translateY(${p.y}vh)`;
        if (p.y > 66) {
          if (!p.bad) {
            combo = 1;
            comboEl.textContent = '×1';
            score = Math.max(0, score - 60);
            scoreEl.textContent = score;
            failFx();
          }
          p.el.remove();
          packets = packets.filter(q => q !== p);
        }
      }
      if (!ended) raf = requestAnimationFrame(loop);
    };
    spawn();
    spawnIv = setInterval(spawn, 520);
    raf = requestAnimationFrame(loop);
    timer = setInterval(() => {
      time -= 1;
      timeEl.textContent = time;
      if (time <= 0) {
        ended = true;
        clearInterval(timer);
        clearInterval(spawnIv);
        cancelAnimationFrame(raf);
        packets.forEach(p => p.el.remove());
        endPanel({ t, id: 'rita', score, title: t.cleared, restart: () => gameRita(t) });
      }
    }, 1000);
    cleanupGame = () => {
      ended = true;
      clearInterval(timer);
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
    };
  });
}

function factionNames(t, faction) {
  return faction === 'res' ? t.res : t.enl;
}
function oppositeFaction(faction) {
  return faction === 'res' ? 'enl' : 'res';
}

function gameDino(t) {
  showBriefing({
    t,
    title: t.dinoTitle,
    img: '/redacted-dino-cutout.png',
    accent: 'amber',
    factionPicker: true,
    speakers: [
      { name: 'Redacted', img: '/redacted-dino-cutout.png', text: 'Très bien. On fait tomber des caisses. Tu récupères celles de ta couleur et tu me laisses entier, idéalement.', accent: 'amber' },
      { name: 'RITA', img: '/rita.png', text: 'Les caisses Machina rouges explosent autour d’elles. La faction opposée n’est pas à ramasser non plus.', accent: 'cyan' }
    ],
    tutorial: [
      'Choisis ENL ou RES avant le départ.',
      'Déplace Redacted sur trois voies en touchant la gauche ou la droite.',
      'Récupère les caisses de ta couleur, évite la couleur adverse et les Machina rouges explosives.'
    ],
    onStart: faction => startDino(t, faction)
  });
}

function startDino(t, faction = 'enl') {
  const help = faction === 'res'
    ? 'Ramasse les caisses bleues RES. Évite les vertes ENL et les Machina rouges explosives.'
    : 'Ramasse les caisses vertes ENL. Évite les bleues RES et les Machina rouges explosives.';
  const body = setScreen(gameFrame({
    title: `${t.dinoTitle} · ${factionNames(t, faction)}`,
    help,
    img: '/redacted-dino-cutout.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.lives, { key: 'lives', value: '♥♥♥' }],
      [t.time, { key: 'time', value: '30' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let lives = 3;
    let time = 30;
    let lane = 1;
    let ended = false;
    let objs = [];
    let spawnIv = null;
    let timer = null;
    let raf = 0;
    let last = performance.now();
    let invul = 0;
    const enemyFaction = oppositeFaction(faction);
    arena.innerHTML = `
      <div class="dinoField ${faction}">
        <div class="dinoLane l0"></div>
        <div class="dinoLane l1"></div>
        <div class="dinoLane l2"></div>
        <img class="dinoPlayer" src="/redacted-dino-cutout.png" alt="Redacted">
        <button class="dinoTap left" aria-label="left"></button>
        <button class="dinoTap right" aria-label="right"></button>
      </div>`;
    const field = arena.querySelector('.dinoField');
    const player = arena.querySelector('.dinoPlayer');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const livesEl = body.querySelector('[data-hud="lives"]');
    const timeEl = body.querySelector('[data-hud="time"]');
    const move = dir => {
      lane = Math.max(0, Math.min(2, lane + dir));
      player.dataset.lane = lane;
      player.style.left = `${16.66 + lane * 33.33}%`;
      tone(320 + lane * 80, 0.03, 0.018);
    };
    const removeObj = o => {
      o.el.remove();
      objs = objs.filter(q => q !== o);
    };
    const explodeAt = source => {
      source.el.classList.add('exploding');
      const shock = document.createElement('div');
      shock.className = 'dinoShock';
      shock.style.left = source.el.style.left;
      shock.style.top = `${source.y}%`;
      field.appendChild(shock);
      setTimeout(() => shock.remove(), 260);
      for (const o of [...objs]) {
        if (o === source) continue;
        if (Math.abs(o.y - source.y) < 18 && Math.abs(o.lane - source.lane) <= 1) {
          if (o.type === 'faction') {
            o.el.classList.add('collected');
            setTimeout(() => removeObj(o), 120);
          } else if (o.type === 'enemy') {
            o.el.classList.add('enemyhit');
            setTimeout(() => removeObj(o), 120);
          }
        }
      }
      setTimeout(() => removeObj(source), 160);
    };
    arena.querySelector('.dinoTap.left').onclick = () => move(-1);
    arena.querySelector('.dinoTap.right').onclick = () => move(1);
    move(0);
    const spawn = () => {
      if (ended) return;
      const roll = Math.random();
      const l = Math.floor(Math.random() * 3);
      const el = document.createElement('div');
      let type = 'faction';
      let kind = faction;
      if (roll < 0.42) {
        type = 'faction';
        kind = faction;
        el.className = `dinoObject crate ${faction}`;
        el.innerHTML = `<span>${faction === 'res' ? 'RES' : 'ENL'}</span>`;
      } else if (roll < 0.78) {
        type = 'enemy';
        kind = enemyFaction;
        el.className = `dinoObject crate ${enemyFaction}`;
        el.innerHTML = `<span>${enemyFaction === 'res' ? 'RES' : 'ENL'}</span>`;
      } else {
        type = 'machina';
        kind = 'machina';
        el.className = 'dinoObject crate machina';
        el.innerHTML = `<span>MX</span>`;
      }
      el.style.left = `${16.66 + l * 33.33}%`;
      field.appendChild(el);
      objs.push({ el, lane: l, y: -10, speed: 19 + Math.random() * 13, type, kind, hit: false });
    };
    const hitEnemy = () => {
      if (invul > 0) return;
      lives -= 1;
      invul = 0.9;
      livesEl.textContent = '♥'.repeat(Math.max(0, lives)) + '♡'.repeat(Math.max(0, 3 - lives));
      failFx();
      player.classList.add('ouch');
      setTimeout(() => player.classList.remove('ouch'), 420);
      if (lives <= 0) finish();
    };
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      invul = Math.max(0, invul - dt);
      for (const o of [...objs]) {
        o.y += o.speed * dt;
        o.el.style.top = `${o.y}%`;
        if (!o.hit && o.y > 72 && o.y < 90 && o.lane === lane) {
          o.hit = true;
          if (o.type === 'faction') {
            score += 180;
            scoreEl.textContent = score;
            successFx();
            o.el.classList.add('collected');
            setTimeout(() => removeObj(o), 160);
          } else if (o.type === 'enemy') {
            hitEnemy();
            o.el.classList.add('enemyhit');
            setTimeout(() => removeObj(o), 160);
          } else {
            hitEnemy();
            failFx();
            explodeAt(o);
          }
        } else if (o.y > 105) {
          if (o.type === 'faction') {
            score = Math.max(0, score - 35);
            scoreEl.textContent = score;
          }
          removeObj(o);
        }
      }
      if (!ended) raf = requestAnimationFrame(loop);
    };
    const finish = () => {
      if (ended) return;
      ended = true;
      clearInterval(timer);
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
      objs.forEach(o => o.el.remove());
      endPanel({ t, id: 'dino', score, title: t.gameOver, restart: () => gameDino(t) });
    };
    spawnIv = setInterval(spawn, 520);
    spawn();
    raf = requestAnimationFrame(loop);
    timer = setInterval(() => {
      time -= 1;
      timeEl.textContent = time;
      score += 18;
      scoreEl.textContent = score;
      if (time <= 0) finish();
    }, 1000);
    cleanupGame = () => {
      ended = true;
      clearInterval(timer);
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
    };
  });
}

function gameBlaster(t) {
  showBriefing({
    t,
    title: t.blasterTitle,
    img: '/rita.png',
    accent: 'violet',
    factionPicker: true,
    speakers: [
      { name: 'RITA', img: '/rita.png', text: 'Bienvenue dans la version totalement raisonnable du labo : un shoot arcade avec ta faction, des portails ennemis et des bonus.', accent: 'cyan' },
      { name: 'IGOR', img: '/igor.png', text: 'Les cibles normales appartiennent à la couleur adverse. Les cœurs Machina rouges explosent autour d’eux. Les bonus de ta couleur peuvent augmenter la puissance de tir.', accent: 'green' },
      { name: 'Redacted', img: '/redacted-dino-cutout.png', text: 'Il y a aussi des boss. C’était obligatoire, apparemment.', accent: 'amber' }
    ],
    tutorial: [
      'Choisis ENL ou RES, puis lance la simulation.',
      'Glisse ou touche l’arène pour déplacer ton vaisseau.',
      'Le tir est automatique. Détruis les portails adverses pour monter de niveau.',
      'Récupère les bonus de ta couleur pour gagner des points et de la puissance.',
      'Les Machina rouges explosent autour d’eux. Tous les trois niveaux, un boss apparaît.'
    ],
    onStart: faction => startBlaster(t, faction)
  });
}

function startBlaster(t, faction = 'enl') {
  const enemyFaction = oppositeFaction(faction);
  const body = setScreen(gameFrame({
    title: `${t.blasterTitle} · ${factionNames(t, faction)}`,
    help: t.blasterHelp,
    img: '/rita.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.level, { key: 'level', value: '1' }],
      [t.power, { key: 'power', value: '1' }],
      [t.lives, { key: 'lives', value: '♥♥♥' }]
    ]),
    arenaClass: 'blasterArena'
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let level = 1;
    let power = 1;
    let lives = 3;
    let ended = false;
    let width = 0;
    let height = 0;
    let kills = 0;
    let killsToAdvance = 9;
    let bullets = [];
    let enemies = [];
    let pickups = [];
    let enemyShots = [];
    let boss = null;
    let raf = 0;
    let last = performance.now();
    let fireCd = 0;
    let spawnCd = 0.45;
    let bossShotCd = 1.1;
    let invul = 0;
    arena.innerHTML = `
      <div class="blasterField ${faction}">
        <div class="blasterStars"></div>
        <div class="blasterFactionBadge ${faction}">${esc(factionNames(t, faction))}</div>
        <div class="blasterBossBar" hidden><i></i></div>
        <div class="blasterPlayer ${faction}"><span></span></div>
      </div>`;
    const field = arena.querySelector('.blasterField');
    const playerEl = arena.querySelector('.blasterPlayer');
    const bossBar = arena.querySelector('.blasterBossBar');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const levelEl = body.querySelector('[data-hud="level"]');
    const powerEl = body.querySelector('[data-hud="power"]');
    const livesEl = body.querySelector('[data-hud="lives"]');
    const player = { x: 0, y: 0, w: 54, h: 44, targetX: 0 };

    const refreshHud = () => {
      scoreEl.textContent = score;
      levelEl.textContent = level;
      powerEl.textContent = power;
      livesEl.textContent = '♥'.repeat(Math.max(0, lives)) + '♡'.repeat(Math.max(0, 3 - lives));
    };
    const resize = () => {
      const r = field.getBoundingClientRect();
      width = r.width;
      height = r.height;
      player.y = height - 54;
      if (!player.x) player.x = width / 2;
      if (!player.targetX) player.targetX = width / 2;
    };
    resize();
    window.addEventListener('resize', resize);

    const setTarget = clientX => {
      const r = field.getBoundingClientRect();
      player.targetX = clamp(clientX - r.left, 28, width - 28);
    };
    field.onpointerdown = e => {
      setTarget(e.clientX);
      try { field.setPointerCapture?.(e.pointerId); } catch {}
    };
    field.onpointermove = e => {
      if (e.buttons) setTarget(e.clientX);
    };
    field.onclick = e => setTarget(e.clientX);

    const rectFor = o => ({ l: o.x - o.w / 2, r: o.x + o.w / 2, t: o.y - o.h / 2, b: o.y + o.h / 2 });
    const overlaps = (a, b) => a.l < b.r && a.r > b.l && a.t < b.b && a.b > b.t;
    const removeItem = (arr, item) => {
      const i = arr.indexOf(item);
      if (i >= 0) arr.splice(i, 1);
      item.el?.remove();
    };
    const makeEl = (cls, text = '') => {
      const el = document.createElement('div');
      el.className = cls;
      el.innerHTML = text;
      field.appendChild(el);
      return el;
    };
    const explodeAt = (x, y, radius = 84, canDamagePlayer = true) => {
      const boom = makeEl('blasterExplosion', '');
      boom.style.left = `${x}px`;
      boom.style.top = `${y}px`;
      setTimeout(() => boom.remove(), 260);
      for (const enemy of [...enemies]) {
        const dist = Math.hypot(enemy.x - x, enemy.y - y);
        if (dist < radius && !enemy._dead) {
          enemy.hp -= enemy.kind === 'boss' ? 2 : 999;
          if (enemy.hp <= 0) destroyEnemy(enemy, true);
        }
      }
      if (canDamagePlayer && invul <= 0) {
        const d = Math.hypot(player.x - x, player.y - y);
        if (d < radius * 0.7) damagePlayer();
      }
    };
    const spawnPickupAt = (x, y, forcedFaction = faction) => {
      const good = forcedFaction === faction;
      const el = makeEl(`blasterPickup ${good ? faction : enemyFaction}`, `<span>${good ? '+' : '−'}</span>`);
      pickups.push({ x, y, w: 26, h: 26, vy: rand(56, 90), faction: forcedFaction, good, el });
    };
    const spawnEnemy = () => {
      if (ended || boss) return;
      const roll = Math.random();
      if (roll < 0.14) {
        spawnPickupAt(rand(30, width - 30), -10, Math.random() < 0.8 ? faction : enemyFaction);
        return;
      }
      if (roll < 0.36) {
        const el = makeEl('blasterEnemy machina', '<span>MX</span>');
        enemies.push({ kind: 'machina', x: rand(34, width - 34), y: -30, w: 42, h: 42, vy: rand(70, 110), sway: rand(0.6, 1.3), hp: 2, el });
        return;
      }
      const shape = Math.random() < 0.5 ? 'portal' : 'resonator';
      const el = makeEl(`blasterEnemy ${enemyFaction} ${shape}`, `<span>${shape === 'portal' ? '◉' : '⬢'}</span>`);
      enemies.push({ kind: 'enemy', x: rand(34, width - 34), y: -30, w: 48, h: 48, vy: rand(64, 96) + level * 4, sway: rand(0.8, 1.8), hp: 1 + (Math.random() < 0.18 ? 1 : 0), el, shape, seed: Math.random() * 10 });
    };
    const spawnBoss = () => {
      if (boss || ended) return;
      const hp = 26 + level * 6;
      const el = makeEl('blasterEnemy boss machina', '<span>CORE</span>');
      boss = { kind: 'boss', x: width / 2, y: 84, w: 154, h: 86, vx: 120, hp, maxHp: hp, el };
      enemies.push(boss);
      bossBar.hidden = false;
      bossShotCd = 0.9;
      successFx();
    };
    const fire = () => {
      const lanes = power >= 4 ? [-18, 0, 18] : power >= 2 ? [-10, 10] : [0];
      for (const dx of lanes) {
        const el = makeEl(`blasterShot ${faction}`, '');
        bullets.push({ x: player.x + dx, y: player.y - 18, w: 7, h: 20, vy: 460 + power * 26, el });
      }
      tone(faction === 'res' ? 500 : 580, 0.03, 0.02);
    };
    const enemyFire = () => {
      if (!boss) return;
      for (const dx of [-42, 0, 42]) {
        const el = makeEl('blasterEnemyShot', '');
        enemyShots.push({ x: boss.x + dx, y: boss.y + 18, w: 8, h: 18, vy: 220 + level * 7, el });
      }
      tone(240, 0.05, 0.02);
    };
    const levelUp = () => {
      level += 1;
      if (level % 2 === 0) power = Math.min(5, power + 1);
      score += 320;
      killsToAdvance = 9 + level * 2;
      levelEl.textContent = level;
      powerEl.textContent = power;
      scoreEl.textContent = score;
      successFx();
    };
    const destroyEnemy = (enemy, fromExplosion = false) => {
      if (!enemy || enemy._dead) return;
      enemy._dead = true;
      removeItem(enemies, enemy);
      if (enemy.kind === 'boss') {
        score += 1500;
        bossBar.hidden = true;
        boss = null;
        power = Math.min(5, power + 1);
        levelUp();
        return;
      }
      if (enemy.kind === 'machina') {
        score += 190;
        scoreEl.textContent = score;
        explodeAt(enemy.x, enemy.y, 86, false);
      } else {
        score += 110 + level * 22;
        scoreEl.textContent = score;
        if (!fromExplosion && Math.random() < 0.22) spawnPickupAt(enemy.x, enemy.y, Math.random() < 0.84 ? faction : enemyFaction);
      }
      kills += 1;
      if (!boss && kills >= killsToAdvance) {
        kills = 0;
        if (level % 3 === 0) spawnBoss();
        else levelUp();
      }
    };
    const damagePlayer = () => {
      if (invul > 0 || ended) return;
      lives -= 1;
      invul = 1;
      refreshHud();
      failFx();
      playerEl.classList.add('hurt');
      setTimeout(() => playerEl.classList.remove('hurt'), 420);
      if (lives <= 0) finish();
    };
    const finish = () => {
      if (ended) return;
      ended = true;
      cancelAnimationFrame(raf);
      bullets.forEach(x => x.el.remove());
      enemies.forEach(x => x.el.remove());
      pickups.forEach(x => x.el.remove());
      enemyShots.forEach(x => x.el.remove());
      bossBar.hidden = true;
      endPanel({ t, id: 'blaster', score, title: t.gameOver, detail: `${t.level} ${level}`, restart: () => gameBlaster(t) });
    };
    refreshHud();
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      invul = Math.max(0, invul - dt);
      fireCd -= dt;
      spawnCd -= dt;
      bossShotCd -= dt;
      if (fireCd <= 0) {
        fireCd = Math.max(0.12, 0.42 - power * 0.05);
        fire();
      }
      if (!boss && spawnCd <= 0) {
        spawnCd = Math.max(0.28, 0.84 - level * 0.04);
        spawnEnemy();
      }
      player.x += (player.targetX - player.x) * 0.18;
      playerEl.style.left = `${player.x}px`;
      playerEl.style.top = `${player.y}px`;
      if (invul > 0) playerEl.style.opacity = Math.sin(now / 70) > 0 ? '0.4' : '1';
      else playerEl.style.opacity = '1';

      if (boss) {
        boss.x += boss.vx * dt;
        if (boss.x < boss.w / 2 + 10 || boss.x > width - boss.w / 2 - 10) boss.vx *= -1;
        boss.el.style.left = `${boss.x}px`;
        boss.el.style.top = `${boss.y}px`;
        if (bossShotCd <= 0) {
          bossShotCd = Math.max(0.55, 1.05 - level * 0.03);
          enemyFire();
        }
        bossBar.querySelector('i').style.width = `${Math.max(0, (boss.hp / boss.maxHp) * 100)}%`;
      }

      for (const bullet of [...bullets]) {
        bullet.y -= bullet.vy * dt;
        bullet.el.style.left = `${bullet.x}px`;
        bullet.el.style.top = `${bullet.y}px`;
        if (bullet.y < -30) {
          removeItem(bullets, bullet);
          continue;
        }
        const bRect = rectFor(bullet);
        for (const enemy of [...enemies]) {
          if (enemy._dead) continue;
          const eRect = rectFor(enemy);
          if (overlaps(bRect, eRect)) {
            enemy.hp -= enemy.kind === 'boss' ? 1 : 1;
            removeItem(bullets, bullet);
            if (enemy.hp <= 0) destroyEnemy(enemy);
            else successFx();
            break;
          }
        }
      }

      for (const enemy of [...enemies]) {
        if (enemy.kind !== 'boss') {
          enemy.y += enemy.vy * dt;
          if (enemy.kind === 'enemy') enemy.x += Math.sin(now / 360 + (enemy.seed || 0)) * enemy.sway;
          enemy.el.style.left = `${enemy.x}px`;
          enemy.el.style.top = `${enemy.y}px`;
          if (enemy.y > height + 40) {
            removeItem(enemies, enemy);
            damagePlayer();
            continue;
          }
          if (overlaps(rectFor(enemy), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
            if (enemy.kind === 'machina') explodeAt(enemy.x, enemy.y, 86, true);
            else damagePlayer();
            removeItem(enemies, enemy);
          }
        }
      }

      for (const shot of [...enemyShots]) {
        shot.y += shot.vy * dt;
        shot.el.style.left = `${shot.x}px`;
        shot.el.style.top = `${shot.y}px`;
        if (shot.y > height + 20) {
          removeItem(enemyShots, shot);
          continue;
        }
        if (overlaps(rectFor(shot), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
          removeItem(enemyShots, shot);
          damagePlayer();
        }
      }

      for (const p of [...pickups]) {
        p.y += p.vy * dt;
        p.el.style.left = `${p.x}px`;
        p.el.style.top = `${p.y}px`;
        if (p.y > height + 20) {
          removeItem(pickups, p);
          continue;
        }
        if (overlaps(rectFor(p), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
          if (p.good) {
            score += 140;
            power = Math.min(5, power + (Math.random() < 0.5 ? 1 : 0));
            successFx();
          } else {
            score = Math.max(0, score - 90);
            damagePlayer();
          }
          refreshHud();
          removeItem(pickups, p);
        }
      }

      refreshHud();
      if (!ended) raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    cleanupGame = () => {
      ended = true;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  });
}

function gameMemory(t) {
  showBriefing({
    t,
    title: t.memoryTitle,
    img: '/redacted-logo-512.png',
    accent: 'green',
    speakers: [
      { name: 'MILO', img: '/assets/milo.jpg', text: 'Celui-ci est presque calme : il faut juste retrouver les paires sans paniquer.', accent: 'green' },
      { name: 'RITA', img: '/rita.png', text: '« Presque » calme. Le chrono tourne quand même.', accent: 'cyan' }
    ],
    tutorial: [
      'Retourne deux cartes par tour.',
      'Deux cartes identiques restent visibles.',
      'Termine le plateau avec le moins de coups possible.'
    ],
    onStart: () => startMemory(t)
  });
}

function startMemory(t) {
  const body = setScreen(gameFrame({
    title: t.memoryTitle,
    help: t.memoryHelp,
    img: '/redacted-logo-512.png',
    t,
    extra: hud(t, [
      [t.moves, { key: 'moves', value: '0' }],
      [t.time, { key: 'time', value: '0' }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    const pairs = [
      ['IGOR', '/igor.png'],
      ['MILO', '/assets/milo.jpg'],
      ['RITA', '/rita.png'],
      ['REDACTED', '/redacted-dino-cutout.png'],
      ['PORTAL', ''],
      ['LAB', '']
    ];
    const deck = [...pairs, ...pairs]
      .map((p, i) => ({ id: i, key: p[0], img: p[1] }))
      .sort(() => Math.random() - 0.5);
    let open = [];
    let matched = 0;
    let moves = 0;
    let sec = 0;
    let lock = false;
    const timer = setInterval(() => {
      sec += 1;
      body.querySelector('[data-hud="time"]').textContent = sec;
    }, 1000);
    arena.innerHTML = `<div class="memoryGrid">${deck.map((c, i) => `<button data-card="${i}"><span class="memoryBack">RBL</span><span class="memoryFront">${c.img ? `<img src="${c.img}" alt=""><b>${c.key}</b>` : `<em>${c.key === 'PORTAL' ? '◉' : '⌬'}</em><b>${c.key}</b>`}</span></button>`).join('')}</div>`;
    const movesEl = body.querySelector('[data-hud="moves"]');
    const cards = [...arena.querySelectorAll('[data-card]')];
    cards.forEach(btn => {
      btn.onclick = () => {
        if (lock || btn.classList.contains('matched') || btn.classList.contains('open')) return;
        const idx = Number(btn.dataset.card);
        btn.classList.add('open');
        open.push({ idx, btn, card: deck[idx] });
        tone(460, 0.035, 0.02);
        if (open.length < 2) return;
        moves += 1;
        movesEl.textContent = moves;
        lock = true;
        if (open[0].card.key === open[1].card.key) {
          open.forEach(x => x.btn.classList.add('matched'));
          matched += 2;
          open = [];
          lock = false;
          successFx();
          if (matched === deck.length) {
            clearInterval(timer);
            endPanel({ t, id: 'memory', score: moves, lowerBetter: true, title: t.cleared, detail: `${sec}s`, restart: () => gameMemory(t) });
          }
        } else {
          failFx();
          setTimeout(() => {
            open.forEach(x => x.btn.classList.remove('open'));
            open = [];
            lock = false;
          }, 700);
        }
      };
    });
    cleanupGame = () => clearInterval(timer);
  });
}
