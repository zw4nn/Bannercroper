import './arcade.css';

const SCORE_KEY='rbl-lab-arcade-scores-v1';
const SETTINGS_KEY='rbl-lab-arcade-settings-v1';
let root=null;
let cleanupGame=null;
let audioCtx=null;
let activeLang='en';

const TXT={
  fr:{
    access:'ACCÈS NON DOCUMENTÉ',found:'Tu as trouvé une porte qui n’était pas dans le manuel.',gateTitle:'Redacted a quelque chose à te montrer.',gateText:'IGOR, MILO et RITA ont manifestement utilisé du temps de calcul pour fabriquer une salle d’arcade. Personne n’a signé la demande.',enter:'Lancer les mini-jeux',leave:'Retour au Lab',arcade:'ARCADE DU LAB',arcadeSub:'5 expériences parfaitement inutiles, donc indispensables.',best:'Record',play:'Jouer',back:'Arcade',close:'Fermer',sound:'Son',newBest:'NOUVEAU RECORD',score:'Score',again:'Rejouer',menu:'Menu',time:'Temps',lives:'Vies',combo:'Combo',round:'Série',moves:'Coups',
    igorTitle:'IGOR · Portal Panic',igorDesc:'Stabilise la route en touchant les portails actifs. Les nœuds rouges sont des anomalies.',igorHelp:'Touche le portail vert dès qu’il apparaît. Plus tu enchaînes vite, plus le combo monte. Évite les anomalies rouges.',
    miloTitle:'MILO · Launch Sequence',miloDesc:'Publie les missions dans le bon ordre avant que MILO ne perde patience.',miloHelp:'Touche les missions 1 → 6 dans l’ordre. Chaque nouvelle série est mélangée. Une erreur casse le combo.',nextMission:'Mission suivante',
    ritaTitle:'RITA · Signal Storm',ritaDesc:'Trie les signaux du Lab avant qu’ils ne se perdent dans le bruit Telegram.',ritaHelp:'Intercepte les paquets cyan/verts avant le bas de l’écran. Laisse passer les paquets rouges corrompus.',
    dinoTitle:'Redacted · Lab Escape',dinoDesc:'Aide Redacted à traverser le laboratoire sans finir sous une caisse de matériel.',dinoHelp:'Touche à gauche ou à droite du terrain pour changer de voie. Ramasse les cellules vertes, évite les caisses rouges.',
    memoryTitle:'Lab Memory',memoryDesc:'Retrouve les paires du personnel du Lab. Oui, ils ont tous accepté. Enfin, presque.',memoryHelp:'Retourne deux cartes. Trouve toutes les paires avec le moins de coups possible.',
    start:'Démarrer',ready:'PRÊT ?',go:'GO',gameOver:'FIN DE PARTIE',cleared:'LAB SÉCURISÉ',perfect:'SÉQUENCE COMPLÈTE',missed:'Signal perdu',corrupt:'Paquet corrompu',wrong:'Mauvais ordre',stabilized:'Portail stabilisé',
    noBest:'—',hidden:'DOSSIER CLASSÉ',hiddenText:'Cette zone reste invisible dans l’application normale. Elle ne s’ouvre qu’après 7 pressions sur Redacted.',
  },
  en:{
    access:'UNDOCUMENTED ACCESS',found:'You found a door that was not in the manual.',gateTitle:'Redacted has something to show you.',gateText:'IGOR, MILO and RITA apparently used compute time to build an arcade. Nobody signed the request.',enter:'Launch mini-games',leave:'Back to the Lab',arcade:'LAB ARCADE',arcadeSub:'5 perfectly useless experiments, therefore essential.',best:'Best',play:'Play',back:'Arcade',close:'Close',sound:'Sound',newBest:'NEW HIGH SCORE',score:'Score',again:'Play again',menu:'Menu',time:'Time',lives:'Lives',combo:'Combo',round:'Round',moves:'Moves',
    igorTitle:'IGOR · Portal Panic',igorDesc:'Stabilize the route by tapping active portals. Red nodes are anomalies.',igorHelp:'Tap the green portal as soon as it appears. Fast chains build combo. Avoid red anomalies.',
    miloTitle:'MILO · Launch Sequence',miloDesc:'Publish missions in the right order before MILO loses patience.',miloHelp:'Tap missions 1 → 6 in order. Every round is shuffled. One mistake breaks the combo.',nextMission:'Next mission',
    ritaTitle:'RITA · Signal Storm',ritaDesc:'Sort Lab signals before they disappear into Telegram noise.',ritaHelp:'Intercept cyan/green packets before the bottom. Let red corrupted packets pass.',
    dinoTitle:'Redacted · Lab Escape',dinoDesc:'Get Redacted across the lab without being flattened by equipment crates.',dinoHelp:'Tap the left or right side to change lane. Collect green cells, avoid red crates.',
    memoryTitle:'Lab Memory',memoryDesc:'Match the Lab staff pairs. Everyone consented. More or less.',memoryHelp:'Flip two cards. Find every pair in as few moves as possible.',
    start:'Start',ready:'READY?',go:'GO',gameOver:'GAME OVER',cleared:'LAB SECURED',perfect:'SEQUENCE COMPLETE',missed:'Signal lost',corrupt:'Corrupted packet',wrong:'Wrong order',stabilized:'Portal stabilized',
    noBest:'—',hidden:'CLASSIFIED FILE',hiddenText:'This area stays invisible during normal use. It only opens after 7 taps on Redacted.',
  }
};

function langPack(lang){return TXT[String(lang||'').toLowerCase()]||TXT.en}
function esc(v=''){return String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
function loadScores(){try{return JSON.parse(localStorage.getItem(SCORE_KEY)||'{}')||{}}catch{return{}}}
function saveScore(id,score,lowerBetter=false){const s=loadScores();const prev=Number(s[id]||0);const better=lowerBetter?(prev<=0||score<prev):score>prev;if(better){s[id]=score;localStorage.setItem(SCORE_KEY,JSON.stringify(s))}return {best:better?score:prev,isBest:better}}
function loadSettings(){try{return {...{sound:true},...JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')}}catch{return{sound:true}}}
function saveSettings(x){localStorage.setItem(SETTINGS_KEY,JSON.stringify(x))}
function buzz(ms=16){try{navigator.vibrate?.(ms)}catch{}}
function tone(freq=440,dur=.05,vol=.025){const st=loadSettings();if(!st.sound)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=freq;o.type='sine';g.gain.value=vol;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+dur);o.stop(audioCtx.currentTime+dur)}catch{}}
function successFx(){tone(720,.06,.035);setTimeout(()=>tone(980,.07,.025),55);buzz(20)}
function failFx(){tone(150,.11,.035);buzz([25,35,25])}
function clearGame(){try{cleanupGame?.()}catch{}cleanupGame=null}
function setScreen(html){clearGame();if(!root)return;const body=root.querySelector('.labArcadeBody');body.innerHTML=html;return body}
function btnEvents(scope=root){scope?.querySelectorAll('[data-arc-close]').forEach(b=>b.onclick=closeLabArcade);scope?.querySelectorAll('[data-arc-menu]').forEach(b=>b.onclick=showMenu)}
function scoreLabel(id,score,t){if(!score)return t.noBest;if(id==='memory')return `${score} ${t.moves.toLowerCase()}`;return Number(score).toLocaleString()}

export function openLabArcade(lang='en'){
  closeLabArcade();
  activeLang=String(lang||'en').toLowerCase();
  const t=langPack(activeLang);
  root=document.createElement('div');root.className='labArcadeRoot';root.innerHTML=`
    <div class="labArcadeScan"></div>
    <div class="labArcadeShell">
      <header class="labArcadeTop"><div class="labArcadeMark">RBL<span>//ARCADE</span></div><button class="labArcadeIcon" data-arc-close aria-label="${esc(t.close)}">×</button></header>
      <div class="labArcadeBody"></div>
    </div>`;
  document.body.appendChild(root);
  root.querySelector('[data-arc-close]').onclick=closeLabArcade;
  showGate(t);
}

export function closeLabArcade(){clearGame();root?.remove();root=null}

function showGate(t){
  const body=setScreen(`<section class="labArcadeGate">
    <div class="labGateNoise"></div>
    <div class="labGateBadge">${esc(t.access)}</div>
    <div class="labGateDino"><div class="labGateGlow"></div><img src="/redacted-dino-cutout.png" alt="Redacted"></div>
    <div class="labGateCopy"><small>${esc(t.found)}</small><h2>${esc(t.gateTitle)}</h2><p>${esc(t.gateText)}</p></div>
    <div class="labGateActions"><button class="labArcadePrimary" data-enter>${esc(t.enter)}</button><button class="labArcadeSecondary" data-arc-close>${esc(t.leave)}</button></div>
  </section>`);
  btnEvents(body);body.querySelector('[data-enter]').onclick=()=>{tone(520,.05);showMenu()};
}

function gamesFor(t){return [
  {id:'igor',title:t.igorTitle,desc:t.igorDesc,img:'/igor.png',cls:'igor'},
  {id:'milo',title:t.miloTitle,desc:t.miloDesc,img:'/assets/milo.jpg',cls:'milo'},
  {id:'rita',title:t.ritaTitle,desc:t.ritaDesc,img:'/rita.png',cls:'rita'},
  {id:'dino',title:t.dinoTitle,desc:t.dinoDesc,img:'/redacted-dino-cutout.png',cls:'dino'},
  {id:'memory',title:t.memoryTitle,desc:t.memoryDesc,img:'/redacted-logo-512.png',cls:'memory'}
]}

function showMenu(){
  if(!root)return;const t=langPack(activeLang);const scores=loadScores(),settings=loadSettings();
  const cards=gamesFor(t).map(g=>`<button class="labGameCard ${g.cls}" data-game="${g.id}"><div class="labGameArt"><img src="${g.img}" alt=""><span class="labGamePulse"></span></div><div class="labGameCopy"><small>${esc(t.best)} · ${esc(scoreLabel(g.id,scores[g.id],t))}</small><strong>${esc(g.title)}</strong><p>${esc(g.desc)}</p><span>${esc(t.play)} ›</span></div></button>`).join('');
  const body=setScreen(`<section class="labArcadeMenu">
    <div class="labMenuHero"><div><small>${esc(t.hidden)}</small><h2>${esc(t.arcade)}</h2><p>${esc(t.arcadeSub)}</p></div><div class="labMenuControls"><button class="labSoundToggle ${settings.sound?'on':''}" data-sound>◉ ${esc(t.sound)}</button></div></div>
    <div class="labGameGrid">${cards}</div>
    <div class="labClassified"><span>⌁</span><p><b>${esc(t.hidden)}</b><br>${esc(t.hiddenText)}</p></div>
  </section>`);
  body.querySelectorAll('[data-game]').forEach(b=>b.onclick=()=>launchGame(b.dataset.game,t));
  body.querySelector('[data-sound]').onclick=e=>{const st=loadSettings();st.sound=!st.sound;saveSettings(st);e.currentTarget.classList.toggle('on',st.sound);if(st.sound)tone(640,.05)};
}

function launchGame(id,t){
  if(id==='igor')return gameIgor(t);
  if(id==='milo')return gameMilo(t);
  if(id==='rita')return gameRita(t);
  if(id==='dino')return gameDino(t);
  if(id==='memory')return gameMemory(t);
}

function gameFrame({title,help,img,t,extra=''}){
  return `<section class="labGameScreen"><div class="labGameHead"><button class="labBack" data-arc-menu>‹ ${esc(t.back)}</button><div class="labGameIdentity"><img src="${img}" alt=""><div><small>RBL // EXPERIMENT</small><strong>${esc(title)}</strong></div></div></div><p class="labGameHelp">${esc(help)}</p>${extra}<div class="labGameArena"></div></section>`
}
function hud(t,parts){return `<div class="labHud">${parts.map(([k,v,c=''])=>`<div class="${c}"><small>${esc(k)}</small><b data-hud="${esc(v.key)}">${esc(v.value)}</b></div>`).join('')}</div>`}
function endPanel({t,id,score,title,lowerBetter=false,detail='',restart}){const result=saveScore(id,score,lowerBetter);successFx();const body=root.querySelector('.labArcadeBody');const pane=document.createElement('div');pane.className='labEndPanel';pane.innerHTML=`<div class="labEndBurst"></div><small>${result.isBest?esc(t.newBest):esc(title)}</small><strong>${esc(id==='memory'?`${score} ${t.moves.toLowerCase()}`:Number(score).toLocaleString())}</strong>${detail?`<p>${esc(detail)}</p>`:''}<div><button class="labArcadePrimary" data-again>${esc(t.again)}</button><button class="labArcadeSecondary" data-arc-menu>${esc(t.menu)}</button></div>`;body.appendChild(pane);pane.querySelector('[data-again]').onclick=restart;pane.querySelector('[data-arc-menu]').onclick=showMenu;}

function countdown(arena,t,go){let n=3;arena.innerHTML=`<div class="labCountdown"><small>${esc(t.ready)}</small><b>${n}</b></div>`;const iv=setInterval(()=>{n--;const b=arena.querySelector('.labCountdown b');if(n>0){b.textContent=n;tone(390+n*80,.035)}else{clearInterval(iv);b.textContent=t.go;tone(760,.07);setTimeout(go,330)}},520);cleanupGame=()=>clearInterval(iv)}

function gameIgor(t){
  const body=setScreen(gameFrame({title:t.igorTitle,help:t.igorHelp,img:'/igor.png',t,extra:hud(t,[[t.score,{key:'score',value:'0'}],[t.combo,{key:'combo',value:'×1'}],[t.time,{key:'time',value:'25'}]])}));btnEvents(body);const arena=body.querySelector('.labGameArena');countdown(arena,t,()=>{
    let score=0,combo=1,time=25,active=null,timer=null,spawnTimer=null,ended=false;
    arena.innerHTML=`<div class="igorGrid">${Array.from({length:16},(_,i)=>`<button data-cell="${i}" aria-label="portal"><span></span></button>`).join('')}</div><div class="igorRouteLine"></div>`;
    const cells=[...arena.querySelectorAll('[data-cell]')],scoreEl=body.querySelector('[data-hud="score"]'),comboEl=body.querySelector('[data-hud="combo"]'),timeEl=body.querySelector('[data-hud="time"]');
    const spawn=()=>{if(ended)return;cells.forEach(c=>{c.className='';c.disabled=false});const idx=Math.floor(Math.random()*cells.length);const anomaly=Math.random()<.2;active={idx,anomaly,at:performance.now()};cells[idx].className=anomaly?'anomaly':'active';spawnTimer=setTimeout(()=>{if(!ended&&active?.idx===idx){if(!anomaly){combo=1;comboEl.textContent='×1'}spawn()}},Math.max(430,1050-score/40));};
    cells.forEach((c,i)=>c.onclick=()=>{if(!active||i!==active.idx)return;clearTimeout(spawnTimer);const elapsed=performance.now()-active.at;if(active.anomaly){score=Math.max(0,score-180);combo=1;failFx();c.classList.add('hitbad')}else{const gain=Math.max(55,160-Math.floor(elapsed/12))*combo;score+=gain;combo=Math.min(8,combo+1);successFx();c.classList.add('hitgood')}scoreEl.textContent=score;comboEl.textContent=`×${combo}`;active=null;setTimeout(spawn,80)});
    spawn();timer=setInterval(()=>{time--;timeEl.textContent=time;if(time<=0){ended=true;clearInterval(timer);clearTimeout(spawnTimer);cells.forEach(c=>c.disabled=true);endPanel({t,id:'igor',score,title:t.gameOver,restart:()=>gameIgor(t)})}},1000);
    cleanupGame=()=>{ended=true;clearInterval(timer);clearTimeout(spawnTimer)};
  });
}

function gameMilo(t){
  const body=setScreen(gameFrame({title:t.miloTitle,help:t.miloHelp,img:'/assets/milo.jpg',t,extra:hud(t,[[t.score,{key:'score',value:'0'}],[t.round,{key:'round',value:'1'}],[t.time,{key:'time',value:'30'}]])}));btnEvents(body);const arena=body.querySelector('.labGameArena');countdown(arena,t,()=>{
    let score=0,round=1,next=1,time=30,ended=false,timer=null,roundStarted=performance.now();
    arena.innerHTML=`<div class="miloStatus"><span>${esc(t.nextMission)}</span><b data-next>1</b></div><div class="miloGrid"></div>`;const grid=arena.querySelector('.miloGrid'),scoreEl=body.querySelector('[data-hud="score"]'),roundEl=body.querySelector('[data-hud="round"]'),timeEl=body.querySelector('[data-hud="time"]'),nextEl=arena.querySelector('[data-next]');
    const shuffle=()=>{const nums=[1,2,3,4,5,6].sort(()=>Math.random()-.5);grid.innerHTML=nums.map(n=>`<button data-n="${n}"><small>M</small><b>${String(n).padStart(2,'0')}</b><span>READY</span></button>`).join('');grid.querySelectorAll('button').forEach(b=>b.onclick=()=>tap(Number(b.dataset.n),b));next=1;nextEl.textContent='1';roundStarted=performance.now()};
    const tap=(n,b)=>{if(ended)return;if(n!==next){score=Math.max(0,score-100);scoreEl.textContent=score;failFx();b.classList.add('bad');setTimeout(()=>b.classList.remove('bad'),240);return}successFx();b.classList.add('done');b.disabled=true;score+=120+Math.max(0,180-Math.floor((performance.now()-roundStarted)/35));scoreEl.textContent=score;next++;if(next<=6){nextEl.textContent=next;return}score+=600;scoreEl.textContent=score;round++;roundEl.textContent=round;nextEl.textContent='✓';setTimeout(shuffle,420)};
    shuffle();timer=setInterval(()=>{time--;timeEl.textContent=time;if(time<=0){ended=true;clearInterval(timer);grid.querySelectorAll('button').forEach(b=>b.disabled=true);endPanel({t,id:'milo',score,title:t.perfect,restart:()=>gameMilo(t)})}},1000);cleanupGame=()=>{ended=true;clearInterval(timer)};
  });
}

function gameRita(t){
  const body=setScreen(gameFrame({title:t.ritaTitle,help:t.ritaHelp,img:'/rita.png',t,extra:hud(t,[[t.score,{key:'score',value:'0'}],[t.combo,{key:'combo',value:'×1'}],[t.time,{key:'time',value:'25'}]])}));btnEvents(body);const arena=body.querySelector('.labGameArena');countdown(arena,t,()=>{
    let score=0,combo=1,time=25,ended=false,spawnIv=null,timer=null,raf=0,last=performance.now(),packets=[];
    arena.innerHTML=`<div class="ritaField"><div class="ritaAntenna">RITA // RX</div><div class="ritaFloor"></div></div>`;const field=arena.querySelector('.ritaField'),scoreEl=body.querySelector('[data-hud="score"]'),comboEl=body.querySelector('[data-hud="combo"]'),timeEl=body.querySelector('[data-hud="time"]');
    const spawn=()=>{if(ended)return;const bad=Math.random()<.27,el=document.createElement('button');el.className=`ritaPacket ${bad?'bad':'good'}`;el.innerHTML=`<span>${bad?'×':'↧'}</span><small>${bad?'CORRUPT':'SIGNAL'}</small>`;const x=8+Math.random()*78;el.style.left=`${x}%`;field.appendChild(el);const p={el,y:-12,speed:16+Math.random()*14,bad};packets.push(p);el.onclick=()=>{if(ended)return;if(bad){score=Math.max(0,score-180);combo=1;failFx();el.classList.add('burstbad')}else{score+=110*combo;combo=Math.min(7,combo+1);successFx();el.classList.add('burstgood')}scoreEl.textContent=score;comboEl.textContent=`×${combo}`;setTimeout(()=>el.remove(),180);packets=packets.filter(q=>q!==p)};};
    const loop=now=>{const dt=Math.min(.05,(now-last)/1000);last=now;for(const p of [...packets]){p.y+=p.speed*dt;p.el.style.transform=`translateY(${p.y}vh)`;if(p.y>66){if(!p.bad){combo=1;comboEl.textContent='×1';score=Math.max(0,score-60);scoreEl.textContent=score;failFx()}p.el.remove();packets=packets.filter(q=>q!==p)}}if(!ended)raf=requestAnimationFrame(loop)};spawn();spawnIv=setInterval(spawn,520);raf=requestAnimationFrame(loop);timer=setInterval(()=>{time--;timeEl.textContent=time;if(time<=0){ended=true;clearInterval(timer);clearInterval(spawnIv);cancelAnimationFrame(raf);packets.forEach(p=>p.el.remove());endPanel({t,id:'rita',score,title:t.cleared,restart:()=>gameRita(t)})}},1000);cleanupGame=()=>{ended=true;clearInterval(timer);clearInterval(spawnIv);cancelAnimationFrame(raf)};
  });
}

function gameDino(t){
  const body=setScreen(gameFrame({title:t.dinoTitle,help:t.dinoHelp,img:'/redacted-dino-cutout.png',t,extra:hud(t,[[t.score,{key:'score',value:'0'}],[t.lives,{key:'lives',value:'♥♥♥'}],[t.time,{key:'time',value:'30'}]])}));btnEvents(body);const arena=body.querySelector('.labGameArena');countdown(arena,t,()=>{
    let score=0,lives=3,time=30,lane=1,ended=false,objs=[],spawnIv=null,timer=null,raf=0,last=performance.now(),invul=0;
    arena.innerHTML=`<div class="dinoField"><div class="dinoLane l0"></div><div class="dinoLane l1"></div><div class="dinoLane l2"></div><img class="dinoPlayer" src="/redacted-dino-cutout.png" alt="Redacted"><button class="dinoTap left" aria-label="left"></button><button class="dinoTap right" aria-label="right"></button></div>`;const field=arena.querySelector('.dinoField'),player=arena.querySelector('.dinoPlayer'),scoreEl=body.querySelector('[data-hud="score"]'),livesEl=body.querySelector('[data-hud="lives"]'),timeEl=body.querySelector('[data-hud="time"]');
    const move=dir=>{lane=Math.max(0,Math.min(2,lane+dir));player.dataset.lane=lane;player.style.left=`${16.66+lane*33.33}%`;tone(320+lane*80,.03,.018)};arena.querySelector('.dinoTap.left').onclick=()=>move(-1);arena.querySelector('.dinoTap.right').onclick=()=>move(1);move(0);
    const spawn=()=>{if(ended)return;const good=Math.random()<.32,l=Math.floor(Math.random()*3),el=document.createElement('div');el.className=`dinoObject ${good?'cell':'crate'}`;el.innerHTML=good?'<span>XM</span>':'<span>!</span>';el.style.left=`${16.66+l*33.33}%`;field.appendChild(el);objs.push({el,lane:l,y:-10,speed:20+Math.random()*13,good,hit:false})};
    const loop=now=>{const dt=Math.min(.05,(now-last)/1000);last=now;invul=Math.max(0,invul-dt);for(const o of [...objs]){o.y+=o.speed*dt;o.el.style.top=`${o.y}%`;if(!o.hit&&o.y>72&&o.y<90&&o.lane===lane){o.hit=true;if(o.good){score+=180;scoreEl.textContent=score;successFx();o.el.classList.add('collected')}else if(invul<=0){lives--;invul=.8;livesEl.textContent='♥'.repeat(lives)+'♡'.repeat(3-lives);failFx();player.classList.add('ouch');setTimeout(()=>player.classList.remove('ouch'),420);if(lives<=0){finish();return}}setTimeout(()=>o.el.remove(),160);objs=objs.filter(q=>q!==o)}else if(o.y>105){o.el.remove();objs=objs.filter(q=>q!==o)}}if(!ended)raf=requestAnimationFrame(loop)};
    const finish=()=>{if(ended)return;ended=true;clearInterval(timer);clearInterval(spawnIv);cancelAnimationFrame(raf);objs.forEach(o=>o.el.remove());endPanel({t,id:'dino',score,title:t.gameOver,restart:()=>gameDino(t)})};
    spawnIv=setInterval(spawn,560);spawn();raf=requestAnimationFrame(loop);timer=setInterval(()=>{time--;timeEl.textContent=time;score+=20;scoreEl.textContent=score;if(time<=0)finish()},1000);cleanupGame=()=>{ended=true;clearInterval(timer);clearInterval(spawnIv);cancelAnimationFrame(raf)};
  });
}

function gameMemory(t){
  const body=setScreen(gameFrame({title:t.memoryTitle,help:t.memoryHelp,img:'/redacted-logo-512.png',t,extra:hud(t,[[t.moves,{key:'moves',value:'0'}],[t.time,{key:'time',value:'0'}]])}));btnEvents(body);const arena=body.querySelector('.labGameArena');countdown(arena,t,()=>{
    const pairs=[['IGOR','/igor.png'],['MILO','/assets/milo.jpg'],['RITA','/rita.png'],['REDACTED','/redacted-dino-cutout.png'],['PORTAL',''],['LAB','']];let deck=[...pairs,...pairs].map((p,i)=>({id:i,key:p[0],img:p[1]})).sort(()=>Math.random()-.5),open=[],matched=0,moves=0,sec=0,lock=false,timer=setInterval(()=>{sec++;body.querySelector('[data-hud="time"]').textContent=sec},1000);arena.innerHTML=`<div class="memoryGrid">${deck.map((c,i)=>`<button data-card="${i}"><span class="memoryBack">RBL</span><span class="memoryFront">${c.img?`<img src="${c.img}" alt=""><b>${c.key}</b>`:`<em>${c.key==='PORTAL'?'◉':'⌬'}</em><b>${c.key}</b>`}</span></button>`).join('')}</div>`;const movesEl=body.querySelector('[data-hud="moves"]');
    const cards=[...arena.querySelectorAll('[data-card]')];cards.forEach(btn=>btn.onclick=()=>{if(lock||btn.classList.contains('matched')||btn.classList.contains('open'))return;const idx=Number(btn.dataset.card);btn.classList.add('open');open.push({idx,btn,card:deck[idx]});tone(460,.035,.02);if(open.length<2)return;moves++;movesEl.textContent=moves;lock=true;if(open[0].card.key===open[1].card.key){open.forEach(x=>x.btn.classList.add('matched'));matched+=2;open=[];lock=false;successFx();if(matched===deck.length){clearInterval(timer);const finalScore=moves;endPanel({t,id:'memory',score:finalScore,lowerBetter:true,title:t.cleared,detail:`${sec}s`,restart:()=>gameMemory(t)})}}else{failFx();setTimeout(()=>{open.forEach(x=>x.btn.classList.remove('open'));open=[];lock=false},700)}});cleanupGame=()=>clearInterval(timer);
  });
}
