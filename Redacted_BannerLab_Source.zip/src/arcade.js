import './arcade.css';

const SCORE_KEY = 'rbl-lab-arcade-scores-v2';
const SETTINGS_KEY = 'rbl-lab-arcade-settings-v2';

let root = null;
let cleanupGame = null;
let audioCtx = null;
let activeLang = 'en';

const TXT = {
  "fr": {
    "access": "ACCÈS NON DOCUMENTÉ",
    "found": "Tu as trouvé une porte qui n’était pas dans le manuel.",
    "gateTitle": "Redacted a quelque chose à te montrer.",
    "gateText": "IGOR, MILO et RITA ont manifestement utilisé du temps de calcul pour fabriquer une salle d’arcade. Personne n’a signé la demande.",
    "enter": "Lancer les mini-jeux",
    "leave": "Retour au Lab",
    "arcade": "ARCADE DU LAB",
    "arcadeSub": "6 expériences parfaitement inutiles, donc indispensables.",
    "best": "Record",
    "play": "Jouer",
    "back": "Arcade",
    "close": "Fermer",
    "sound": "Son",
    "newBest": "NOUVEAU RECORD",
    "score": "Score",
    "again": "Rejouer",
    "menu": "Menu",
    "time": "Temps",
    "lives": "Vies",
    "combo": "Combo",
    "round": "Série",
    "moves": "Coups",
    "level": "Niveau",
    "power": "Puissance",
    "faction": "Couleur",
    "tutorial": "Tutoriel",
    "start": "Démarrer",
    "startMission": "Entrer dans la simulation",
    "ready": "PRÊT ?",
    "readyShort": "PRÊT",
    "go": "GO",
    "gameOver": "FIN DE PARTIE",
    "cleared": "LAB SÉCURISÉ",
    "perfect": "SÉQUENCE COMPLÈTE",
    "missed": "Signal perdu",
    "corrupt": "Paquet corrompu",
    "corruptShort": "CORROMPU",
    "signalShort": "SIGNAL",
    "wrong": "Mauvais ordre",
    "stabilized": "Portail stabilisé",
    "noBest": "—",
    "hidden": "DOSSIER CLASSÉ",
    "hiddenText": "Cette zone reste invisible dans l’application normale. Elle ne s’ouvre qu’après 7 pressions sur Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPÉRIENCE",
    "tutorialTitle": "Mode d’emploi du mini-jeu",
    "chooseFaction": "Choisis ton camp avant de lancer la simulation.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Boss",
    "bonus": "Bonus",
    "nextMission": "Mission suivante",
    "levelShort": "NV",
    "superLabel": "SUPER",
    "gateBasementLine": "SOUS-SOL // SALLE 07 // ACCÈS CLASSIFIÉ",
    "gateMarqueeText": "Une salle de jeu clandestine bricolée derrière le laboratoire. Aucun budget officiel n’a été retrouvé.",
    "online": "EN LIGNE",
    "authorizedOnly": "PERSONNEL AUTORISÉ UNIQUEMENT",
    "arcadeCore": "CŒUR ARCADE",
    "unlocked": "DÉVERROUILLÉ",
    "tokens": "JETONS",
    "networkStable": "Réseau stabilisé",
    "cabinetsPowered": "Bornes sous tension.",
    "filesLoaded": "Fichiers chargés",
    "simulationsReady": "6 simulations prêtes.",
    "channelOpen": "Canal ouvert",
    "arcadeNotCertified": "Arcade non homologuée.",
    "basementAdmin": "ADMINISTRATEUR DU SOUS-SOL",
    "redactedRoomTitle": "Tu n’étais pas censé trouver cette pièce.",
    "redactedRoomText": "Maintenant que tu es là… autant jouer. IGOR, MILO et RITA ont déjà lancé les machines.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Stabilise la route en touchant les portails actifs. Les nœuds rouges sont des anomalies.",
    "igorHelp": "Touche le portail vert dès qu’il apparaît. Plus tu enchaînes vite, plus le combo monte. Évite les anomalies rouges.",
    "igorSpeak1": "Je surveille le réseau de portails. Quand l’un s’active, touche-le immédiatement.",
    "igorSpeak2": "Les nœuds rouges sont des anomalies. Si tu les touches, tu casses ton combo. Bravo le labo.",
    "igorTutorial": ["Un seul portail actif apparaît à la fois.", "Les portails verts rapportent des points et montent le combo.", "Les anomalies rouges font perdre des points et remettent le combo à ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Publie les missions dans le bon ordre avant que MILO ne perde patience.",
    "miloHelp": "Touche les missions 1 → 6 dans l’ordre. Chaque nouvelle série est mélangée. Une erreur casse le combo.",
    "miloSpeak1": "On publie proprement. Les missions doivent partir dans l’ordre, sans improvisation cosmique.",
    "miloSpeak2": "Si tu cliques la mauvaise mission, je note officiellement que c’est de ta faute.",
    "miloTutorial": ["Repère la mission attendue dans le badge central.", "Toujours taper 1 → 6 dans l’ordre.", "Une série complète donne un bonus puis un nouveau tirage."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Trie les signaux du Lab avant qu’ils ne se perdent dans le bruit Telegram.",
    "ritaHelp": "Intercepte les paquets cyan/verts avant le bas de l’écran. Laisse passer les paquets rouges corrompus.",
    "ritaSpeak1": "Les signaux utiles doivent être récupérés avant qu’ils ne plongent dans le bruit.",
    "ritaSpeak2": "Les paquets rouges sont corrompus. Laisse-les tomber, sauf si tu aimes saboter le réseau.",
    "ritaTutorial": ["Tape les paquets cyan ou verts avant la ligne au sol.", "Ne touche jamais les paquets rouges corrompus.", "Les bons paquets augmentent ton combo et ton score."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Aide Redacted à traverser le laboratoire et à récupérer les bonnes caisses de faction.",
    "dinoHelp": "Choisis ENL ou RES. Ramasse les caisses de ta couleur, évite la couleur adverse et fuis les caisses Machina rouges qui explosent autour d’elles.",
    "dinoHelpRes": "Ramasse les caisses bleues RES. Évite les vertes ENL et les Machina rouges explosives.",
    "dinoHelpEnl": "Ramasse les caisses vertes ENL. Évite les bleues RES et les Machina rouges explosives.",
    "dinoSpeak1": "Très bien. On fait tomber des caisses. Tu récupères celles de ta couleur et tu me laisses entier, idéalement.",
    "dinoSpeak2": "Les caisses Machina rouges explosent autour d’elles. La faction opposée n’est pas à ramasser non plus.",
    "dinoTutorial": ["Choisis ENL ou RES avant le départ.", "Déplace Redacted sur trois voies en touchant la gauche ou la droite.", "Récupère les caisses de ta couleur, évite la couleur adverse et les Machina rouges explosives."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Un mini shoot arcade façon labo spatial : ta faction affronte l’autre couleur, avec portails, résonateurs Machina, niveaux et boss.",
    "blasterHelp": "Utilise le joystick ou les flèches pour piloter. Le tir est automatique. Détruis les cibles adverses, charge SUPER avec les bonus de ta couleur et surveille les Machina rouges explosifs.",
    "blasterSpeak1": "Bienvenue dans la version totalement raisonnable du labo : un shoot arcade avec ta faction, des portails ennemis et des bonus.",
    "blasterSpeak2": "Les cibles normales appartiennent à la couleur adverse. Les Machina rouges encaissent environ deux fois plus. Les bonus de ta couleur chargent aussi le super tir.",
    "blasterSpeak3": "Il y a aussi des boss. C’était obligatoire, apparemment.",
    "blasterTutorial": ["Choisis ENL ou RES, puis lance la simulation.", "Utilise le joystick ou maintiens les flèches pour déplacer ton vaisseau.", "Le tir est automatique. Détruis les portails adverses pour monter de niveau.", "Récupère les bonus de ta couleur pour gagner des points, de la puissance et charger SUPER.", "Les Machina rouges sont environ deux fois plus résistants et explosent. Tous les trois niveaux, un boss apparaît."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Retrouve les paires du personnel du Lab. Oui, ils ont tous accepté. Enfin, presque.",
    "memoryHelp": "Retourne deux cartes. Trouve toutes les paires avec le moins de coups possible.",
    "memoryPortal": "Portail",
    "memoryLab": "Lab",
    "memorySpeak1": "Celui-ci est presque calme : il faut juste retrouver les paires sans paniquer.",
    "memorySpeak2": "« Presque » calme. Le chrono tourne quand même.",
    "memoryTutorial": ["Retourne deux cartes par tour.", "Deux cartes identiques restent visibles.", "Termine le plateau avec le moins de coups possible."]
  },  "en": {
    "access": "UNDOCUMENTED ACCESS",
    "found": "You found a door that was not in the manual.",
    "gateTitle": "Redacted has something to show you.",
    "gateText": "IGOR, MILO and RITA apparently used compute time to build an arcade. Nobody signed the request.",
    "enter": "Launch mini-games",
    "leave": "Back to the Lab",
    "arcade": "LAB ARCADE",
    "arcadeSub": "6 perfectly useless experiments, therefore essential.",
    "best": "Best",
    "play": "Play",
    "back": "Arcade",
    "close": "Close",
    "sound": "Sound",
    "newBest": "NEW HIGH SCORE",
    "score": "Score",
    "again": "Play again",
    "menu": "Menu",
    "time": "Time",
    "lives": "Lives",
    "combo": "Combo",
    "round": "Round",
    "moves": "Moves",
    "level": "Level",
    "power": "Power",
    "faction": "Faction",
    "tutorial": "Tutorial",
    "start": "Start",
    "startMission": "Enter simulation",
    "ready": "READY?",
    "readyShort": "READY",
    "go": "GO",
    "gameOver": "GAME OVER",
    "cleared": "LAB SECURED",
    "perfect": "SEQUENCE COMPLETE",
    "missed": "Signal lost",
    "corrupt": "Corrupted packet",
    "corruptShort": "CORRUPT",
    "signalShort": "SIGNAL",
    "wrong": "Wrong order",
    "stabilized": "Portal stabilized",
    "noBest": "—",
    "hidden": "CLASSIFIED FILE",
    "hiddenText": "This area stays invisible during normal use. It only opens after 7 taps on Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPERIMENT",
    "tutorialTitle": "How to play",
    "chooseFaction": "Choose your side before launching the simulation.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Boss",
    "bonus": "Bonus",
    "nextMission": "Next mission",
    "levelShort": "LV",
    "superLabel": "SUPER",
    "gateBasementLine": "BASEMENT // ROOM 07 // CLASSIFIED ACCESS",
    "gateMarqueeText": "A clandestine arcade assembled behind the laboratory. No official budget has been found.",
    "online": "ONLINE",
    "authorizedOnly": "AUTHORIZED PERSONNEL ONLY",
    "arcadeCore": "ARCADE CORE",
    "unlocked": "UNLOCKED",
    "tokens": "TOKENS",
    "networkStable": "Network stable",
    "cabinetsPowered": "Cabinets powered.",
    "filesLoaded": "Files loaded",
    "simulationsReady": "6 simulations ready.",
    "channelOpen": "Channel open",
    "arcadeNotCertified": "Arcade not certified.",
    "basementAdmin": "BASEMENT ADMINISTRATOR",
    "redactedRoomTitle": "You were not supposed to find this room.",
    "redactedRoomText": "Now that you are here… you might as well play. IGOR, MILO and RITA already started the machines.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Stabilize the route by tapping active portals. Red nodes are anomalies.",
    "igorHelp": "Tap the green portal as soon as it appears. Fast chains build combo. Avoid red anomalies.",
    "igorSpeak1": "I am monitoring the portal network. When one activates, tap it immediately.",
    "igorSpeak2": "Red nodes are anomalies. Touch one and your combo is gone. Excellent lab work.",
    "igorTutorial": ["Only one active portal appears at a time.", "Green portals score points and build your combo.", "Red anomalies cost points and reset the combo to ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Publish missions in the right order before MILO loses patience.",
    "miloHelp": "Tap missions 1 → 6 in order. Every round is shuffled. One mistake breaks the combo.",
    "miloSpeak1": "We publish properly. Missions go out in order, without cosmic improvisation.",
    "miloSpeak2": "If you tap the wrong mission, I will officially record that it was your fault.",
    "miloTutorial": ["Check the expected mission in the central badge.", "Always tap 1 → 6 in order.", "A complete sequence gives a bonus, then a new shuffle."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Sort Lab signals before they disappear into Telegram noise.",
    "ritaHelp": "Intercept cyan/green packets before the bottom. Let red corrupted packets pass.",
    "ritaSpeak1": "Useful signals must be recovered before they sink into the noise.",
    "ritaSpeak2": "Red packets are corrupted. Let them fall unless sabotaging the network is your hobby.",
    "ritaTutorial": ["Tap cyan or green packets before the floor line.", "Never tap corrupted red packets.", "Good packets increase your combo and score."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Help Redacted cross the lab and collect the right faction crates.",
    "dinoHelp": "Choose ENL or RES. Collect crates in your color, avoid the opposite color, and stay away from red Machina crates: they explode around themselves.",
    "dinoHelpRes": "Collect blue RES crates. Avoid green ENL crates and explosive red Machina crates.",
    "dinoHelpEnl": "Collect green ENL crates. Avoid blue RES crates and explosive red Machina crates.",
    "dinoSpeak1": "Right. Crates are falling. Collect your color and, ideally, keep me in one piece.",
    "dinoSpeak2": "Red Machina crates explode around themselves. The opposite faction is not collectible either.",
    "dinoTutorial": ["Choose ENL or RES before starting.", "Move Redacted across three lanes by tapping left or right.", "Collect your faction crates, avoid the opposite faction and explosive red Machina crates."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "A tiny lab-flavored space shooter: your faction faces the other color with portals, Machina resonators, levels and bosses.",
    "blasterHelp": "Use the joystick or arrows to steer. Shooting is automatic. Destroy enemy targets, charge SUPER with your faction bonuses, and watch the explosive red Machina units.",
    "blasterSpeak1": "Welcome to the perfectly reasonable part of the Lab: an arcade shooter with your faction, enemy portals and bonuses.",
    "blasterSpeak2": "Normal targets belong to the opposing faction. Red Machina units take roughly twice as much punishment. Your faction bonuses also charge the super shot.",
    "blasterSpeak3": "There are bosses too. Apparently that was mandatory.",
    "blasterTutorial": ["Choose ENL or RES, then launch the simulation.", "Use the joystick or hold the arrows to move your ship.", "Shooting is automatic. Destroy enemy portals to level up.", "Collect bonuses in your faction color for points, firepower and SUPER charge.", "Red Machina units are about twice as tough and explode. A boss appears every three levels."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Match the Lab staff pairs. Everyone consented. More or less.",
    "memoryHelp": "Flip two cards. Find every pair in as few moves as possible.",
    "memoryPortal": "Portal",
    "memoryLab": "Lab",
    "memorySpeak1": "This one is almost calm: just match the pairs without panicking.",
    "memorySpeak2": "“Almost” calm. The timer is still running.",
    "memoryTutorial": ["Flip two cards per turn.", "Matching cards stay visible.", "Clear the board in as few moves as possible."]
  },  "es": {
    "access": "ACCESO NO DOCUMENTADO",
    "found": "Has encontrado una puerta que no figuraba en el manual.",
    "gateTitle": "Redacted tiene algo que enseñarte.",
    "gateText": "IGOR, MILO y RITA aparentemente han usado tiempo de cálculo para montar una sala arcade. Nadie firmó la solicitud.",
    "enter": "Lanzar los minijuegos",
    "leave": "Volver al Lab",
    "arcade": "ARCADE DEL LAB",
    "arcadeSub": "6 experimentos perfectamente inútiles, por lo tanto imprescindibles.",
    "best": "Récord",
    "play": "Jugar",
    "back": "Arcade",
    "close": "Cerrar",
    "sound": "Sonido",
    "newBest": "NUEVO RÉCORD",
    "score": "Puntuación",
    "again": "Jugar de nuevo",
    "menu": "Menú",
    "time": "Tiempo",
    "lives": "Vidas",
    "combo": "Combo",
    "round": "Ronda",
    "moves": "Movimientos",
    "level": "Nivel",
    "power": "Potencia",
    "faction": "Facción",
    "tutorial": "Tutorial",
    "start": "Empezar",
    "startMission": "Entrar en la simulación",
    "ready": "¿LISTO?",
    "readyShort": "LISTO",
    "go": "YA",
    "gameOver": "FIN DE LA PARTIDA",
    "cleared": "LAB ASEGURADO",
    "perfect": "SECUENCIA COMPLETA",
    "missed": "Señal perdida",
    "corrupt": "Paquete corrupto",
    "corruptShort": "CORRUPTO",
    "signalShort": "SEÑAL",
    "wrong": "Orden incorrecto",
    "stabilized": "Portal estabilizado",
    "noBest": "—",
    "hidden": "ARCHIVO CLASIFICADO",
    "hiddenText": "Esta zona permanece invisible durante el uso normal. Solo se abre tras 7 pulsaciones sobre Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPERIMENTO",
    "tutorialTitle": "Cómo jugar",
    "chooseFaction": "Elige tu bando antes de iniciar la simulación.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Jefe",
    "bonus": "Bonus",
    "nextMission": "Siguiente misión",
    "levelShort": "NV",
    "superLabel": "SUPER",
    "gateBasementLine": "SÓTANO // SALA 07 // ACCESO CLASIFICADO",
    "gateMarqueeText": "Una sala arcade clandestina montada detrás del laboratorio. No se ha encontrado ningún presupuesto oficial.",
    "online": "EN LÍNEA",
    "authorizedOnly": "SOLO PERSONAL AUTORIZADO",
    "arcadeCore": "NÚCLEO ARCADE",
    "unlocked": "DESBLOQUEADO",
    "tokens": "FICHAS",
    "networkStable": "Red estabilizada",
    "cabinetsPowered": "Máquinas encendidas.",
    "filesLoaded": "Archivos cargados",
    "simulationsReady": "6 simulaciones listas.",
    "channelOpen": "Canal abierto",
    "arcadeNotCertified": "Arcade no homologada.",
    "basementAdmin": "ADMINISTRADOR DEL SÓTANO",
    "redactedRoomTitle": "No se suponía que encontraras esta sala.",
    "redactedRoomText": "Ahora que estás aquí… más vale jugar. IGOR, MILO y RITA ya han encendido las máquinas.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Estabiliza la ruta tocando los portales activos. Los nodos rojos son anomalías.",
    "igorHelp": "Toca el portal verde en cuanto aparezca. Las cadenas rápidas aumentan el combo. Evita las anomalías rojas.",
    "igorSpeak1": "Vigilo la red de portales. Cuando uno se active, tócalo inmediatamente.",
    "igorSpeak2": "Los nodos rojos son anomalías. Si tocas uno, pierdes el combo. Excelente trabajo de laboratorio.",
    "igorTutorial": ["Solo aparece un portal activo cada vez.", "Los portales verdes dan puntos y aumentan el combo.", "Las anomalías rojas restan puntos y reinician el combo a ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Publica las misiones en el orden correcto antes de que MILO pierda la paciencia.",
    "miloHelp": "Toca las misiones 1 → 6 en orden. Cada ronda se mezcla. Un error rompe el combo.",
    "miloSpeak1": "Publicamos bien. Las misiones salen en orden, sin improvisación cósmica.",
    "miloSpeak2": "Si tocas la misión equivocada, registraré oficialmente que ha sido culpa tuya.",
    "miloTutorial": ["Mira la misión esperada en la insignia central.", "Toca siempre 1 → 6 en orden.", "Una secuencia completa da un bonus y luego una nueva mezcla."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Clasifica las señales del Lab antes de que desaparezcan en el ruido de Telegram.",
    "ritaHelp": "Intercepta los paquetes cian/verdes antes de que lleguen abajo. Deja pasar los paquetes rojos corruptos.",
    "ritaSpeak1": "Las señales útiles deben recuperarse antes de que se hundan en el ruido.",
    "ritaSpeak2": "Los paquetes rojos están corruptos. Déjalos caer, salvo que sabotear la red sea tu afición.",
    "ritaTutorial": ["Toca los paquetes cian o verdes antes de la línea del suelo.", "Nunca toques los paquetes rojos corruptos.", "Los paquetes buenos aumentan tu combo y puntuación."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Ayuda a Redacted a cruzar el laboratorio y recoger las cajas de facción correctas.",
    "dinoHelp": "Elige ENL o RES. Recoge las cajas de tu color, evita el color contrario y aléjate de las cajas Machina rojas: explotan a su alrededor.",
    "dinoHelpRes": "Recoge las cajas azules RES. Evita las verdes ENL y las Machina rojas explosivas.",
    "dinoHelpEnl": "Recoge las cajas verdes ENL. Evita las azules RES y las Machina rojas explosivas.",
    "dinoSpeak1": "Bien. Caen cajas. Recoge las de tu color y, si puede ser, déjame de una pieza.",
    "dinoSpeak2": "Las cajas Machina rojas explotan a su alrededor. Tampoco recojas las de la facción contraria.",
    "dinoTutorial": ["Elige ENL o RES antes de empezar.", "Mueve a Redacted por tres carriles tocando izquierda o derecha.", "Recoge las cajas de tu facción, evita la contraria y las Machina rojas explosivas."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Un pequeño shooter espacial del Lab: tu facción se enfrenta al otro color con portales, resonadores Machina, niveles y jefes.",
    "blasterHelp": "Usa el joystick o las flechas para pilotar. El disparo es automático. Destruye objetivos enemigos, carga SUPER con bonus de tu facción y vigila las unidades Machina rojas explosivas.",
    "blasterSpeak1": "Bienvenido a la parte totalmente razonable del Lab: un shooter arcade con tu facción, portales enemigos y bonus.",
    "blasterSpeak2": "Los objetivos normales pertenecen a la facción contraria. Las Machina rojas aguantan aproximadamente el doble. Los bonus de tu color también cargan el superdisparo.",
    "blasterSpeak3": "También hay jefes. Al parecer era obligatorio.",
    "blasterTutorial": ["Elige ENL o RES y lanza la simulación.", "Usa el joystick o mantén pulsadas las flechas para mover la nave.", "El disparo es automático. Destruye portales enemigos para subir de nivel.", "Recoge bonus de tu color para obtener puntos, potencia y carga SUPER.", "Las Machina rojas son aproximadamente el doble de resistentes y explotan. Aparece un jefe cada tres niveles."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Encuentra las parejas del personal del Lab. Todos aceptaron. Más o menos.",
    "memoryHelp": "Gira dos cartas. Encuentra todas las parejas con el menor número de movimientos.",
    "memoryPortal": "Portal",
    "memoryLab": "Lab",
    "memorySpeak1": "Este es casi tranquilo: solo hay que encontrar las parejas sin entrar en pánico.",
    "memorySpeak2": "“Casi” tranquilo. El cronómetro sigue corriendo.",
    "memoryTutorial": ["Gira dos cartas por turno.", "Las cartas iguales permanecen visibles.", "Completa el tablero con el menor número de movimientos."]
  },  "pt": {
    "access": "ACESSO NÃO DOCUMENTADO",
    "found": "Encontraste uma porta que não estava no manual.",
    "gateTitle": "Redacted tem algo para te mostrar.",
    "gateText": "IGOR, MILO e RITA aparentemente usaram tempo de processamento para montar uma sala de arcade. Ninguém assinou o pedido.",
    "enter": "Iniciar minijogos",
    "leave": "Voltar ao Lab",
    "arcade": "ARCADE DO LAB",
    "arcadeSub": "6 experiências perfeitamente inúteis, portanto indispensáveis.",
    "best": "Recorde",
    "play": "Jogar",
    "back": "Arcade",
    "close": "Fechar",
    "sound": "Som",
    "newBest": "NOVO RECORDE",
    "score": "Pontuação",
    "again": "Jogar novamente",
    "menu": "Menu",
    "time": "Tempo",
    "lives": "Vidas",
    "combo": "Combo",
    "round": "Ronda",
    "moves": "Jogadas",
    "level": "Nível",
    "power": "Potência",
    "faction": "Facção",
    "tutorial": "Tutorial",
    "start": "Iniciar",
    "startMission": "Entrar na simulação",
    "ready": "PRONTO?",
    "readyShort": "PRONTO",
    "go": "VAI",
    "gameOver": "FIM DE JOGO",
    "cleared": "LAB SEGURO",
    "perfect": "SEQUÊNCIA COMPLETA",
    "missed": "Sinal perdido",
    "corrupt": "Pacote corrompido",
    "corruptShort": "CORROMPIDO",
    "signalShort": "SINAL",
    "wrong": "Ordem errada",
    "stabilized": "Portal estabilizado",
    "noBest": "—",
    "hidden": "FICHEIRO CLASSIFICADO",
    "hiddenText": "Esta zona fica invisível durante a utilização normal. Só abre após 7 toques em Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPERIÊNCIA",
    "tutorialTitle": "Como jogar",
    "chooseFaction": "Escolhe o teu lado antes de iniciar a simulação.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Chefe",
    "bonus": "Bónus",
    "nextMission": "Próxima missão",
    "levelShort": "NV",
    "superLabel": "SUPER",
    "gateBasementLine": "CAVE // SALA 07 // ACESSO CLASSIFICADO",
    "gateMarqueeText": "Uma sala de arcade clandestina montada atrás do laboratório. Não foi encontrado qualquer orçamento oficial.",
    "online": "ONLINE",
    "authorizedOnly": "APENAS PESSOAL AUTORIZADO",
    "arcadeCore": "NÚCLEO ARCADE",
    "unlocked": "DESBLOQUEADO",
    "tokens": "FICHAS",
    "networkStable": "Rede estabilizada",
    "cabinetsPowered": "Máquinas ligadas.",
    "filesLoaded": "Ficheiros carregados",
    "simulationsReady": "6 simulações prontas.",
    "channelOpen": "Canal aberto",
    "arcadeNotCertified": "Arcade não homologada.",
    "basementAdmin": "ADMINISTRADOR DA CAVE",
    "redactedRoomTitle": "Não era suposto encontrares esta sala.",
    "redactedRoomText": "Agora que estás aqui… mais vale jogar. IGOR, MILO e RITA já ligaram as máquinas.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Estabiliza a rota tocando nos portais ativos. Os nós vermelhos são anomalias.",
    "igorHelp": "Toca no portal verde assim que aparecer. Sequências rápidas aumentam o combo. Evita as anomalias vermelhas.",
    "igorSpeak1": "Estou a vigiar a rede de portais. Quando um ativar, toca-lhe imediatamente.",
    "igorSpeak2": "Os nós vermelhos são anomalias. Se tocares num, perdes o combo. Excelente trabalho de laboratório.",
    "igorTutorial": ["Só aparece um portal ativo de cada vez.", "Os portais verdes dão pontos e aumentam o combo.", "As anomalias vermelhas retiram pontos e repõem o combo em ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Publica as missões pela ordem correta antes que MILO perca a paciência.",
    "miloHelp": "Toca nas missões 1 → 6 pela ordem correta. Cada ronda é baralhada. Um erro quebra o combo.",
    "miloSpeak1": "Publicamos como deve ser. As missões saem por ordem, sem improvisação cósmica.",
    "miloSpeak2": "Se tocares na missão errada, vou registar oficialmente que a culpa foi tua.",
    "miloTutorial": ["Vê a missão esperada no indicador central.", "Toca sempre 1 → 6 pela ordem correta.", "Uma sequência completa dá um bónus e depois uma nova mistura."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Organiza os sinais do Lab antes de desaparecerem no ruído do Telegram.",
    "ritaHelp": "Interceta os pacotes ciano/verdes antes de chegarem ao fundo. Deixa passar os pacotes vermelhos corrompidos.",
    "ritaSpeak1": "Os sinais úteis têm de ser recuperados antes de desaparecerem no ruído.",
    "ritaSpeak2": "Os pacotes vermelhos estão corrompidos. Deixa-os cair, a menos que gostes de sabotar a rede.",
    "ritaTutorial": ["Toca nos pacotes ciano ou verdes antes da linha do chão.", "Nunca toques nos pacotes vermelhos corrompidos.", "Os bons pacotes aumentam o combo e a pontuação."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Ajuda Redacted a atravessar o laboratório e recolher as caixas da facção correta.",
    "dinoHelp": "Escolhe ENL ou RES. Recolhe as caixas da tua cor, evita a cor adversária e foge das caixas Machina vermelhas: explodem à volta delas.",
    "dinoHelpRes": "Recolhe as caixas azuis RES. Evita as verdes ENL e as Machina vermelhas explosivas.",
    "dinoHelpEnl": "Recolhe as caixas verdes ENL. Evita as azuis RES e as Machina vermelhas explosivas.",
    "dinoSpeak1": "Muito bem. Estão a cair caixas. Recolhe as da tua cor e, de preferência, deixa-me inteiro.",
    "dinoSpeak2": "As caixas Machina vermelhas explodem à volta delas. As da facção adversária também não são para recolher.",
    "dinoTutorial": ["Escolhe ENL ou RES antes de começar.", "Move Redacted entre três faixas tocando à esquerda ou à direita.", "Recolhe as caixas da tua facção, evita a facção adversária e as Machina vermelhas explosivas."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Um pequeno shooter espacial do Lab: a tua facção enfrenta a outra cor com portais, ressoadores Machina, níveis e chefes.",
    "blasterHelp": "Usa o joystick ou as setas para pilotar. O disparo é automático. Destrói alvos inimigos, carrega SUPER com bónus da tua facção e vigia as unidades Machina vermelhas explosivas.",
    "blasterSpeak1": "Bem-vindo à parte perfeitamente razoável do Lab: um shooter arcade com a tua facção, portais inimigos e bónus.",
    "blasterSpeak2": "Os alvos normais pertencem à facção adversária. As Machina vermelhas aguentam cerca do dobro. Os bónus da tua cor também carregam o superdisparo.",
    "blasterSpeak3": "Também há chefes. Pelos vistos era obrigatório.",
    "blasterTutorial": ["Escolhe ENL ou RES e inicia a simulação.", "Usa o joystick ou mantém as setas premidas para mover a nave.", "O disparo é automático. Destrói portais inimigos para subir de nível.", "Recolhe bónus da tua cor para ganhar pontos, potência e carga SUPER.", "As Machina vermelhas são cerca de duas vezes mais resistentes e explodem. Aparece um chefe a cada três níveis."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Encontra os pares da equipa do Lab. Todos concordaram. Mais ou menos.",
    "memoryHelp": "Vira duas cartas. Encontra todos os pares com o menor número de jogadas.",
    "memoryPortal": "Portal",
    "memoryLab": "Lab",
    "memorySpeak1": "Este é quase calmo: basta encontrar os pares sem entrar em pânico.",
    "memorySpeak2": "“Quase” calmo. O cronómetro continua a contar.",
    "memoryTutorial": ["Vira duas cartas por jogada.", "As cartas iguais ficam visíveis.", "Completa o tabuleiro com o menor número de jogadas."]
  },  "de": {
    "access": "NICHT DOKUMENTIERTER ZUGANG",
    "found": "Du hast eine Tür gefunden, die nicht im Handbuch steht.",
    "gateTitle": "Redacted möchte dir etwas zeigen.",
    "gateText": "IGOR, MILO und RITA haben offenbar Rechenzeit benutzt, um eine Spielhalle zu bauen. Niemand hat den Antrag unterschrieben.",
    "enter": "Minispiele starten",
    "leave": "Zurück zum Lab",
    "arcade": "LAB-ARCADE",
    "arcadeSub": "6 vollkommen nutzlose Experimente, also unverzichtbar.",
    "best": "Rekord",
    "play": "Spielen",
    "back": "Arcade",
    "close": "Schließen",
    "sound": "Ton",
    "newBest": "NEUER REKORD",
    "score": "Punkte",
    "again": "Nochmal spielen",
    "menu": "Menü",
    "time": "Zeit",
    "lives": "Leben",
    "combo": "Combo",
    "round": "Runde",
    "moves": "Züge",
    "level": "Level",
    "power": "Stärke",
    "faction": "Fraktion",
    "tutorial": "Tutorial",
    "start": "Start",
    "startMission": "Simulation starten",
    "ready": "BEREIT?",
    "readyShort": "BEREIT",
    "go": "LOS",
    "gameOver": "GAME OVER",
    "cleared": "LAB GESICHERT",
    "perfect": "SEQUENZ KOMPLETT",
    "missed": "Signal verloren",
    "corrupt": "Beschädigtes Paket",
    "corruptShort": "DEFEKT",
    "signalShort": "SIGNAL",
    "wrong": "Falsche Reihenfolge",
    "stabilized": "Portal stabilisiert",
    "noBest": "—",
    "hidden": "GEHEIME AKTE",
    "hiddenText": "Dieser Bereich bleibt im normalen Betrieb unsichtbar. Er öffnet sich erst nach 7 Tipps auf Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPERIMENT",
    "tutorialTitle": "Spielanleitung",
    "chooseFaction": "Wähle deine Seite, bevor du die Simulation startest.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Boss",
    "bonus": "Bonus",
    "nextMission": "Nächste Mission",
    "levelShort": "LV",
    "superLabel": "SUPER",
    "gateBasementLine": "KELLER // RAUM 07 // GEHEIMER ZUGANG",
    "gateMarqueeText": "Eine heimliche Spielhalle hinter dem Labor. Ein offizielles Budget wurde nicht gefunden.",
    "online": "ONLINE",
    "authorizedOnly": "NUR AUTORISIERTES PERSONAL",
    "arcadeCore": "ARCADE-KERN",
    "unlocked": "ENTSPERRT",
    "tokens": "JETONS",
    "networkStable": "Netzwerk stabil",
    "cabinetsPowered": "Automaten eingeschaltet.",
    "filesLoaded": "Dateien geladen",
    "simulationsReady": "6 Simulationen bereit.",
    "channelOpen": "Kanal offen",
    "arcadeNotCertified": "Arcade nicht zertifiziert.",
    "basementAdmin": "KELLERADMINISTRATOR",
    "redactedRoomTitle": "Du solltest diesen Raum nicht finden.",
    "redactedRoomText": "Jetzt, wo du hier bist… kannst du auch spielen. IGOR, MILO und RITA haben die Maschinen schon gestartet.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Stabilisiere die Route, indem du aktive Portale antippst. Rote Knoten sind Anomalien.",
    "igorHelp": "Tippe das grüne Portal an, sobald es erscheint. Schnelle Serien erhöhen die Combo. Meide rote Anomalien.",
    "igorSpeak1": "Ich überwache das Portalnetz. Wenn eines aktiv wird, tippe es sofort an.",
    "igorSpeak2": "Rote Knoten sind Anomalien. Ein Tipp darauf und deine Combo ist weg. Hervorragende Laborarbeit.",
    "igorTutorial": ["Es erscheint immer nur ein aktives Portal.", "Grüne Portale geben Punkte und erhöhen die Combo.", "Rote Anomalien kosten Punkte und setzen die Combo auf ×1 zurück."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Veröffentliche die Missionen in der richtigen Reihenfolge, bevor MILO die Geduld verliert.",
    "miloHelp": "Tippe Mission 1 → 6 der Reihe nach an. Jede Runde wird gemischt. Ein Fehler beendet die Combo.",
    "miloSpeak1": "Wir veröffentlichen ordentlich. Die Missionen gehen der Reihe nach raus, ohne kosmische Improvisation.",
    "miloSpeak2": "Wenn du die falsche Mission antippst, vermerke ich offiziell, dass es deine Schuld war.",
    "miloTutorial": ["Achte auf die erwartete Mission im mittleren Feld.", "Tippe immer 1 → 6 in der richtigen Reihenfolge.", "Eine komplette Sequenz gibt einen Bonus und danach eine neue Mischung."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Sortiere die Lab-Signale, bevor sie im Telegram-Rauschen verschwinden.",
    "ritaHelp": "Fange cyanfarbene/grüne Pakete ab, bevor sie unten ankommen. Lass rote beschädigte Pakete passieren.",
    "ritaSpeak1": "Nützliche Signale müssen gerettet werden, bevor sie im Rauschen versinken.",
    "ritaSpeak2": "Rote Pakete sind beschädigt. Lass sie fallen, außer Netzwerksabotage ist dein Hobby.",
    "ritaTutorial": ["Tippe cyanfarbene oder grüne Pakete vor der Bodenlinie an.", "Tippe niemals rote beschädigte Pakete an.", "Gute Pakete erhöhen Combo und Punkte."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Hilf Redacted durch das Labor und sammle die richtigen Fraktionskisten.",
    "dinoHelp": "Wähle ENL oder RES. Sammle Kisten deiner Farbe, meide die gegnerische Farbe und rote Machina-Kisten: Sie explodieren in ihrer Umgebung.",
    "dinoHelpRes": "Sammle blaue RES-Kisten. Meide grüne ENL-Kisten und explosive rote Machina-Kisten.",
    "dinoHelpEnl": "Sammle grüne ENL-Kisten. Meide blaue RES-Kisten und explosive rote Machina-Kisten.",
    "dinoSpeak1": "Gut. Kisten fallen herunter. Sammle deine Farbe und lass mich dabei möglichst ganz.",
    "dinoSpeak2": "Rote Machina-Kisten explodieren in ihrer Umgebung. Die gegnerische Fraktion ist ebenfalls kein Sammelobjekt.",
    "dinoTutorial": ["Wähle vor dem Start ENL oder RES.", "Bewege Redacted über drei Spuren, indem du links oder rechts tippst.", "Sammle deine Fraktionskisten, meide die gegnerische Fraktion und explosive rote Machina-Kisten."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Ein kleiner Lab-Weltraumshooter: Deine Fraktion kämpft gegen die andere Farbe mit Portalen, Machina-Resonatoren, Levels und Bossen.",
    "blasterHelp": "Steuere mit Joystick oder Pfeilen. Geschossen wird automatisch. Zerstöre gegnerische Ziele, lade SUPER mit Boni deiner Fraktion und achte auf explosive rote Machina-Einheiten.",
    "blasterSpeak1": "Willkommen im vollkommen vernünftigen Teil des Labs: ein Arcade-Shooter mit deiner Fraktion, gegnerischen Portalen und Boni.",
    "blasterSpeak2": "Normale Ziele gehören zur gegnerischen Fraktion. Rote Machina halten ungefähr doppelt so viel aus. Boni deiner Farbe laden außerdem den Superschuss.",
    "blasterSpeak3": "Bosse gibt es auch. Das war offenbar Pflicht.",
    "blasterTutorial": ["Wähle ENL oder RES und starte die Simulation.", "Benutze den Joystick oder halte die Pfeile gedrückt, um dein Schiff zu bewegen.", "Geschossen wird automatisch. Zerstöre gegnerische Portale, um aufzusteigen.", "Sammle Boni deiner Farbe für Punkte, Feuerkraft und SUPER-Ladung.", "Rote Machina sind ungefähr doppelt so widerstandsfähig und explodieren. Alle drei Levels erscheint ein Boss."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Finde die Paare der Lab-Crew. Alle haben zugestimmt. Mehr oder weniger.",
    "memoryHelp": "Drehe zwei Karten um. Finde alle Paare mit möglichst wenigen Zügen.",
    "memoryPortal": "Portal",
    "memoryLab": "Lab",
    "memorySpeak1": "Dieses Spiel ist fast ruhig: Du musst nur die Paare finden, ohne in Panik zu geraten.",
    "memorySpeak2": "„Fast“ ruhig. Die Uhr läuft trotzdem.",
    "memoryTutorial": ["Drehe pro Zug zwei Karten um.", "Gleiche Karten bleiben sichtbar.", "Räume das Feld mit möglichst wenigen Zügen ab."]
  },  "it": {
    "access": "ACCESSO NON DOCUMENTATO",
    "found": "Hai trovato una porta che non era nel manuale.",
    "gateTitle": "Redacted ha qualcosa da mostrarti.",
    "gateText": "IGOR, MILO e RITA hanno evidentemente usato tempo di calcolo per costruire una sala arcade. Nessuno ha firmato la richiesta.",
    "enter": "Avvia i minigiochi",
    "leave": "Torna al Lab",
    "arcade": "ARCADE DEL LAB",
    "arcadeSub": "6 esperimenti perfettamente inutili, quindi indispensabili.",
    "best": "Record",
    "play": "Gioca",
    "back": "Arcade",
    "close": "Chiudi",
    "sound": "Audio",
    "newBest": "NUOVO RECORD",
    "score": "Punteggio",
    "again": "Rigioca",
    "menu": "Menu",
    "time": "Tempo",
    "lives": "Vite",
    "combo": "Combo",
    "round": "Serie",
    "moves": "Mosse",
    "level": "Livello",
    "power": "Potenza",
    "faction": "Fazione",
    "tutorial": "Tutorial",
    "start": "Avvia",
    "startMission": "Entra nella simulazione",
    "ready": "PRONTO?",
    "readyShort": "PRONTO",
    "go": "VIA",
    "gameOver": "FINE PARTITA",
    "cleared": "LAB SICURO",
    "perfect": "SEQUENZA COMPLETA",
    "missed": "Segnale perso",
    "corrupt": "Pacchetto corrotto",
    "corruptShort": "CORROTTO",
    "signalShort": "SEGNALE",
    "wrong": "Ordine errato",
    "stabilized": "Portale stabilizzato",
    "noBest": "—",
    "hidden": "FILE RISERVATO",
    "hiddenText": "Questa zona resta invisibile durante l’uso normale. Si apre solo dopo 7 tocchi su Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // ESPERIMENTO",
    "tutorialTitle": "Come si gioca",
    "chooseFaction": "Scegli il tuo schieramento prima di avviare la simulazione.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Boss",
    "bonus": "Bonus",
    "nextMission": "Missione successiva",
    "levelShort": "LV",
    "superLabel": "SUPER",
    "gateBasementLine": "SEMINTERRATO // SALA 07 // ACCESSO RISERVATO",
    "gateMarqueeText": "Una sala arcade clandestina costruita dietro il laboratorio. Non è stato trovato alcun budget ufficiale.",
    "online": "ONLINE",
    "authorizedOnly": "SOLO PERSONALE AUTORIZZATO",
    "arcadeCore": "NUCLEO ARCADE",
    "unlocked": "SBLOCCATO",
    "tokens": "GETTONI",
    "networkStable": "Rete stabilizzata",
    "cabinetsPowered": "Cabinet accesi.",
    "filesLoaded": "File caricati",
    "simulationsReady": "6 simulazioni pronte.",
    "channelOpen": "Canale aperto",
    "arcadeNotCertified": "Arcade non certificata.",
    "basementAdmin": "AMMINISTRATORE DEL SEMINTERRATO",
    "redactedRoomTitle": "Non avresti dovuto trovare questa stanza.",
    "redactedRoomText": "Ora che sei qui… tanto vale giocare. IGOR, MILO e RITA hanno già acceso le macchine.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Stabilizza il percorso toccando i portali attivi. I nodi rossi sono anomalie.",
    "igorHelp": "Tocca il portale verde appena appare. Le sequenze rapide aumentano la combo. Evita le anomalie rosse.",
    "igorSpeak1": "Sto sorvegliando la rete dei portali. Quando uno si attiva, toccalo subito.",
    "igorSpeak2": "I nodi rossi sono anomalie. Se ne tocchi uno, perdi la combo. Ottimo lavoro da laboratorio.",
    "igorTutorial": ["Appare un solo portale attivo alla volta.", "I portali verdi danno punti e aumentano la combo.", "Le anomalie rosse fanno perdere punti e riportano la combo a ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Pubblica le missioni nell’ordine corretto prima che MILO perda la pazienza.",
    "miloHelp": "Tocca le missioni 1 → 6 in ordine. Ogni serie viene mescolata. Un errore interrompe la combo.",
    "miloSpeak1": "Pubblichiamo come si deve. Le missioni partono in ordine, senza improvvisazioni cosmiche.",
    "miloSpeak2": "Se tocchi la missione sbagliata, registrerò ufficialmente che è colpa tua.",
    "miloTutorial": ["Controlla la missione attesa nell’indicatore centrale.", "Tocca sempre 1 → 6 in ordine.", "Una sequenza completa dà un bonus e poi una nuova mescolata."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Ordina i segnali del Lab prima che scompaiano nel rumore di Telegram.",
    "ritaHelp": "Intercetta i pacchetti ciano/verdi prima che arrivino in fondo. Lascia passare i pacchetti rossi corrotti.",
    "ritaSpeak1": "I segnali utili devono essere recuperati prima che sprofondino nel rumore.",
    "ritaSpeak2": "I pacchetti rossi sono corrotti. Lasciali cadere, a meno che sabotare la rete non sia il tuo hobby.",
    "ritaTutorial": ["Tocca i pacchetti ciano o verdi prima della linea a terra.", "Non toccare mai i pacchetti rossi corrotti.", "I pacchetti corretti aumentano combo e punteggio."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Aiuta Redacted ad attraversare il laboratorio e raccogliere le casse della fazione giusta.",
    "dinoHelp": "Scegli ENL o RES. Raccogli le casse del tuo colore, evita il colore avversario e stai lontano dalle casse Machina rosse: esplodono attorno a sé.",
    "dinoHelpRes": "Raccogli le casse blu RES. Evita le verdi ENL e le Machina rosse esplosive.",
    "dinoHelpEnl": "Raccogli le casse verdi ENL. Evita le blu RES e le Machina rosse esplosive.",
    "dinoSpeak1": "Bene. Stanno cadendo casse. Raccogli quelle del tuo colore e, possibilmente, lasciami intero.",
    "dinoSpeak2": "Le casse Machina rosse esplodono attorno a sé. Anche quelle della fazione avversaria non vanno raccolte.",
    "dinoTutorial": ["Scegli ENL o RES prima di iniziare.", "Sposta Redacted su tre corsie toccando a sinistra o a destra.", "Raccogli le casse della tua fazione, evita la fazione avversaria e le Machina rosse esplosive."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Un piccolo shooter spaziale del Lab: la tua fazione affronta l’altro colore con portali, risonatori Machina, livelli e boss.",
    "blasterHelp": "Usa il joystick o le frecce per pilotare. Il fuoco è automatico. Distruggi i bersagli nemici, carica SUPER con i bonus della tua fazione e fai attenzione alle unità Machina rosse esplosive.",
    "blasterSpeak1": "Benvenuto nella parte perfettamente ragionevole del Lab: uno shooter arcade con la tua fazione, portali nemici e bonus.",
    "blasterSpeak2": "I bersagli normali appartengono alla fazione avversaria. Le Machina rosse resistono circa il doppio. I bonus del tuo colore caricano anche il super colpo.",
    "blasterSpeak3": "Ci sono anche i boss. A quanto pare era obbligatorio.",
    "blasterTutorial": ["Scegli ENL o RES e avvia la simulazione.", "Usa il joystick o tieni premute le frecce per muovere la nave.", "Il fuoco è automatico. Distruggi i portali nemici per salire di livello.", "Raccogli i bonus del tuo colore per ottenere punti, potenza e carica SUPER.", "Le Machina rosse sono circa due volte più resistenti ed esplodono. Ogni tre livelli appare un boss."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Trova le coppie del personale del Lab. Hanno accettato tutti. Più o meno.",
    "memoryHelp": "Gira due carte. Trova tutte le coppie con il minor numero di mosse possibile.",
    "memoryPortal": "Portale",
    "memoryLab": "Lab",
    "memorySpeak1": "Questo è quasi tranquillo: devi solo trovare le coppie senza andare nel panico.",
    "memorySpeak2": "“Quasi” tranquillo. Il cronometro continua comunque.",
    "memoryTutorial": ["Gira due carte per turno.", "Le carte uguali restano visibili.", "Completa il tabellone con il minor numero di mosse possibile."]
  },  "nl": {
    "access": "NIET-GEDOCUMENTEERDE TOEGANG",
    "found": "Je hebt een deur gevonden die niet in de handleiding stond.",
    "gateTitle": "Redacted wil je iets laten zien.",
    "gateText": "IGOR, MILO en RITA hebben blijkbaar rekentijd gebruikt om een arcade te bouwen. Niemand heeft het verzoek ondertekend.",
    "enter": "Minigames starten",
    "leave": "Terug naar het Lab",
    "arcade": "LAB-ARCADE",
    "arcadeSub": "6 volkomen nutteloze experimenten, dus onmisbaar.",
    "best": "Record",
    "play": "Spelen",
    "back": "Arcade",
    "close": "Sluiten",
    "sound": "Geluid",
    "newBest": "NIEUW RECORD",
    "score": "Score",
    "again": "Opnieuw spelen",
    "menu": "Menu",
    "time": "Tijd",
    "lives": "Levens",
    "combo": "Combo",
    "round": "Ronde",
    "moves": "Zetten",
    "level": "Level",
    "power": "Kracht",
    "faction": "Factie",
    "tutorial": "Tutorial",
    "start": "Start",
    "startMission": "Start de simulatie",
    "ready": "KLAAR?",
    "readyShort": "KLAAR",
    "go": "GO",
    "gameOver": "GAME OVER",
    "cleared": "LAB BEVEILIGD",
    "perfect": "REEKS VOLTOOID",
    "missed": "Signaal verloren",
    "corrupt": "Beschadigd pakket",
    "corruptShort": "CORRUPT",
    "signalShort": "SIGNAAL",
    "wrong": "Verkeerde volgorde",
    "stabilized": "Portaal gestabiliseerd",
    "noBest": "—",
    "hidden": "GECLASSIFICEERD BESTAND",
    "hiddenText": "Dit gebied blijft tijdens normaal gebruik onzichtbaar. Het opent pas na 7 tikken op Redacted.",
    "briefing": "Briefing",
    "briefingLabel": "RBL // BRIEFING",
    "experimentLabel": "RBL // EXPERIMENT",
    "tutorialTitle": "Zo speel je",
    "chooseFaction": "Kies je kant voordat je de simulatie start.",
    "enl": "ENL",
    "res": "RES",
    "machina": "Machina",
    "boss": "Boss",
    "bonus": "Bonus",
    "nextMission": "Volgende missie",
    "levelShort": "LV",
    "superLabel": "SUPER",
    "gateBasementLine": "KELDER // KAMER 07 // GECLASSIFICEERDE TOEGANG",
    "gateMarqueeText": "Een clandestiene arcade achter het laboratorium. Er is geen officieel budget teruggevonden.",
    "online": "ONLINE",
    "authorizedOnly": "ALLEEN BEVOEGD PERSONEEL",
    "arcadeCore": "ARCADE-KERN",
    "unlocked": "ONTGRENDELD",
    "tokens": "FICHES",
    "networkStable": "Netwerk stabiel",
    "cabinetsPowered": "Kasten ingeschakeld.",
    "filesLoaded": "Bestanden geladen",
    "simulationsReady": "6 simulaties klaar.",
    "channelOpen": "Kanaal open",
    "arcadeNotCertified": "Arcade niet gecertificeerd.",
    "basementAdmin": "KELDERBEHEERDER",
    "redactedRoomTitle": "Het was niet de bedoeling dat je deze kamer vond.",
    "redactedRoomText": "Nu je hier toch bent… kun je net zo goed spelen. IGOR, MILO en RITA hebben de machines al aangezet.",
    "igorTitle": "IGOR · Portal Panic",
    "igorDesc": "Stabiliseer de route door actieve portalen aan te tikken. Rode knooppunten zijn anomalieën.",
    "igorHelp": "Tik op het groene portaal zodra het verschijnt. Snelle reeksen verhogen de combo. Vermijd rode anomalieën.",
    "igorSpeak1": "Ik bewaak het portaalnetwerk. Zodra er één actief wordt, tik je erop.",
    "igorSpeak2": "Rode knooppunten zijn anomalieën. Tik erop en je combo is weg. Uitstekend labwerk.",
    "igorTutorial": ["Er verschijnt telkens maar één actief portaal.", "Groene portalen leveren punten op en verhogen je combo.", "Rode anomalieën kosten punten en zetten de combo terug op ×1."],
    "miloTitle": "MILO · Launch Sequence",
    "miloDesc": "Publiceer de missies in de juiste volgorde voordat MILO zijn geduld verliest.",
    "miloHelp": "Tik missies 1 → 6 in de juiste volgorde aan. Elke ronde wordt geschud. Eén fout verbreekt de combo.",
    "miloSpeak1": "We publiceren netjes. Missies gaan in volgorde de deur uit, zonder kosmische improvisatie.",
    "miloSpeak2": "Als je de verkeerde missie aantikt, noteer ik officieel dat het jouw schuld was.",
    "miloTutorial": ["Bekijk de verwachte missie in de middelste badge.", "Tik altijd 1 → 6 in de juiste volgorde.", "Een complete reeks geeft een bonus en daarna een nieuwe shuffle."],
    "ritaTitle": "RITA · Signal Storm",
    "ritaDesc": "Sorteer de Lab-signalen voordat ze verdwijnen in Telegram-ruis.",
    "ritaHelp": "Onderschep cyaan/groene pakketten voordat ze onderaan komen. Laat rode beschadigde pakketten voorbijgaan.",
    "ritaSpeak1": "Nuttige signalen moeten worden opgepikt voordat ze in de ruis verdwijnen.",
    "ritaSpeak2": "Rode pakketten zijn beschadigd. Laat ze vallen, tenzij netwerksabotage je hobby is.",
    "ritaTutorial": ["Tik cyaan of groene pakketten aan vóór de vloerlijn.", "Tik nooit op rode beschadigde pakketten.", "Goede pakketten verhogen je combo en score."],
    "dinoTitle": "REDACTED - Faction Drop",
    "dinoDesc": "Help Redacted door het laboratorium en verzamel de juiste factiekratten.",
    "dinoHelp": "Kies ENL of RES. Verzamel kratten van jouw kleur, vermijd de andere kleur en blijf uit de buurt van rode Machina-kratten: die ontploffen rondom zich.",
    "dinoHelpRes": "Verzamel blauwe RES-kratten. Vermijd groene ENL-kratten en explosieve rode Machina-kratten.",
    "dinoHelpEnl": "Verzamel groene ENL-kratten. Vermijd blauwe RES-kratten en explosieve rode Machina-kratten.",
    "dinoSpeak1": "Goed. Er vallen kratten. Verzamel jouw kleur en laat mij bij voorkeur heel.",
    "dinoSpeak2": "Rode Machina-kratten ontploffen rondom zich. De andere factie is ook niet om op te rapen.",
    "dinoTutorial": ["Kies ENL of RES voordat je begint.", "Verplaats Redacted over drie banen door links of rechts te tikken.", "Verzamel kratten van jouw factie, vermijd de tegenpartij en explosieve rode Machina-kratten."],
    "blasterTitle": "RITA · Portal Blaster",
    "blasterDesc": "Een kleine Lab-ruimteshooter: jouw factie neemt het op tegen de andere kleur met portalen, Machina-resonators, levels en bosses.",
    "blasterHelp": "Stuur met de joystick of pijlen. Vuren gaat automatisch. Vernietig vijandelijke doelen, laad SUPER met bonussen van jouw factie en let op explosieve rode Machina-eenheden.",
    "blasterSpeak1": "Welkom in het volkomen redelijke deel van het Lab: een arcade-shooter met jouw factie, vijandelijke portalen en bonussen.",
    "blasterSpeak2": "Normale doelen horen bij de andere factie. Rode Machina kunnen ongeveer twee keer zoveel hebben. Bonussen van jouw kleur laden ook het superschot.",
    "blasterSpeak3": "Er zijn ook bosses. Dat was blijkbaar verplicht.",
    "blasterTutorial": ["Kies ENL of RES en start de simulatie.", "Gebruik de joystick of houd de pijlen ingedrukt om je schip te bewegen.", "Vuren gaat automatisch. Vernietig vijandelijke portalen om te levelen.", "Verzamel bonussen van jouw kleur voor punten, vuurkracht en SUPER-lading.", "Rode Machina zijn ongeveer twee keer zo sterk en ontploffen. Elke drie levels verschijnt een boss."],
    "memoryTitle": "REDACTED - Lab Memory",
    "memoryDesc": "Vind de paren van het Lab-team. Iedereen heeft ingestemd. Min of meer.",
    "memoryHelp": "Draai twee kaarten om. Vind alle paren met zo weinig mogelijk zetten.",
    "memoryPortal": "Portaal",
    "memoryLab": "Lab",
    "memorySpeak1": "Deze is bijna rustig: je hoeft alleen de paren te vinden zonder in paniek te raken.",
    "memorySpeak2": "“Bijna” rustig. De timer loopt nog steeds.",
    "memoryTutorial": ["Draai per beurt twee kaarten om.", "Gelijke kaarten blijven zichtbaar.", "Maak het bord leeg in zo weinig mogelijk zetten."]
  }
};

// v1.0.15.16 — arcade/training modes + faction selection on every game.
Object.assign(TXT.fr,{
  chooseMode:'Choisis ton mode de jeu.',arcadeMode:'Arcade',arcadeModeText:'Chrono actif · les combos rendent du temps · records activés.',trainingMode:'Entraînement',trainingModeText:'Pas de chrono · pas de record · idéal pour apprendre tranquillement.',mode:'Mode',timeBonus:'Temps +{n}s',trainingBadge:'ENTRAÎNEMENT',arcadeBadge:'ARCADE',commonEnemy:'Machina rouge = ennemi commun',comboTimeHint:'Plus ton combo monte, plus tu récupères de temps.',teamHint:'Ta couleur sert de référence. Les rouges restent hostiles aux deux camps.'
});
Object.assign(TXT.en,{
  chooseMode:'Choose your game mode.',arcadeMode:'Arcade',arcadeModeText:'Timer on · combos give time back · records enabled.',trainingMode:'Training',trainingModeText:'No timer · no records · learn at your own pace.',mode:'Mode',timeBonus:'Time +{n}s',trainingBadge:'TRAINING',arcadeBadge:'ARCADE',commonEnemy:'Red Machina = common enemy',comboTimeHint:'The higher your combo, the more time you earn back.',teamHint:'Your faction color is your reference. Red stays hostile to both sides.'
});
Object.assign(TXT.es,{
  chooseMode:'Elige tu modo de juego.',arcadeMode:'Arcade',arcadeModeText:'Cronómetro activo · los combos devuelven tiempo · récords activados.',trainingMode:'Entrenamiento',trainingModeText:'Sin cronómetro · sin récords · aprende a tu ritmo.',mode:'Modo',timeBonus:'Tiempo +{n}s',trainingBadge:'ENTRENAMIENTO',arcadeBadge:'ARCADE',commonEnemy:'Machina roja = enemigo común',comboTimeHint:'Cuanto mayor sea el combo, más tiempo recuperas.',teamHint:'El color de tu facción es la referencia. El rojo sigue siendo hostil para ambos bandos.'
});
Object.assign(TXT.pt,{
  chooseMode:'Escolhe o modo de jogo.',arcadeMode:'Arcade',arcadeModeText:'Cronómetro ativo · combos devolvem tempo · recordes ativados.',trainingMode:'Treino',trainingModeText:'Sem cronómetro · sem recordes · aprende ao teu ritmo.',mode:'Modo',timeBonus:'Tempo +{n}s',trainingBadge:'TREINO',arcadeBadge:'ARCADE',commonEnemy:'Machina vermelha = inimigo comum',comboTimeHint:'Quanto maior o combo, mais tempo recuperas.',teamHint:'A cor da tua facção é a referência. O vermelho continua hostil aos dois lados.'
});
Object.assign(TXT.de,{
  chooseMode:'Wähle deinen Spielmodus.',arcadeMode:'Arcade',arcadeModeText:'Timer aktiv · Combos geben Zeit zurück · Rekorde aktiv.',trainingMode:'Training',trainingModeText:'Kein Timer · keine Rekorde · in Ruhe üben.',mode:'Modus',timeBonus:'Zeit +{n}s',trainingBadge:'TRAINING',arcadeBadge:'ARCADE',commonEnemy:'Rote Machina = gemeinsamer Gegner',comboTimeHint:'Je höher dein Combo, desto mehr Zeit bekommst du zurück.',teamHint:'Deine Fraktionsfarbe ist deine Referenz. Rot bleibt für beide Seiten feindlich.'
});
Object.assign(TXT.it,{
  chooseMode:'Scegli la modalità di gioco.',arcadeMode:'Arcade',arcadeModeText:'Timer attivo · le combo restituiscono tempo · record attivi.',trainingMode:'Allenamento',trainingModeText:'Nessun timer · nessun record · impara con calma.',mode:'Modalità',timeBonus:'Tempo +{n}s',trainingBadge:'ALLENAMENTO',arcadeBadge:'ARCADE',commonEnemy:'Machina rossa = nemico comune',comboTimeHint:'Più sale la combo, più tempo recuperi.',teamHint:'Il colore della tua fazione è il riferimento. Il rosso resta ostile a entrambi i lati.'
});
Object.assign(TXT.nl,{
  chooseMode:'Kies je spelmodus.',arcadeMode:'Arcade',arcadeModeText:'Timer actief · combo’s geven tijd terug · records actief.',trainingMode:'Training',trainingModeText:'Geen timer · geen records · rustig oefenen.',mode:'Modus',timeBonus:'Tijd +{n}s',trainingBadge:'TRAINING',arcadeBadge:'ARCADE',commonEnemy:'Rode Machina = gezamenlijke vijand',comboTimeHint:'Hoe hoger je combo, hoe meer tijd je terugverdient.',teamHint:'Je factiekleur is je referentie. Rood blijft vijandig voor beide kampen.'
});

Object.assign(TXT.fr,{igorHelp:'Touche le portail de ta faction dès qu’il apparaît. Plus tu enchaînes vite, plus le combo monte. Les anomalies Machina rouges sont hostiles aux deux camps.',igorTutorial:['Un seul portail de ta faction apparaît à la fois.','Les bonnes cibles rapportent des points et montent le combo.','Les anomalies Machina rouges font perdre des points, du temps et cassent le combo.'],ritaHelp:'Intercepte les paquets de ta faction avant le bas de l’écran. Laisse passer les paquets Machina rouges corrompus.',ritaTutorial:['Tape les paquets de ta faction avant la ligne au sol.','Ne touche jamais les paquets Machina rouges corrompus.','Les bons paquets augmentent ton combo, ton score et peuvent rendre du temps.'],memorySpeak2:'En mode Arcade, le chrono tourne. En Entraînement, tu peux prendre ton temps.'});
Object.assign(TXT.en,{igorHelp:'Tap your faction portal as soon as it appears. Fast chains build combo. Red Machina anomalies are hostile to both sides.',igorTutorial:['Only one portal from your faction appears at a time.','Correct targets score points and build combo.','Red Machina anomalies cost points, time and reset the combo.'],ritaHelp:'Intercept packets from your faction before they reach the bottom. Let corrupted red Machina packets pass.',ritaTutorial:['Tap your faction packets before the floor line.','Never tap corrupted red Machina packets.','Good packets build combo, score and can give time back.'],memorySpeak2:'In Arcade mode the timer runs. In Training mode you can take your time.'});
Object.assign(TXT.es,{igorHelp:'Toca el portal de tu facción en cuanto aparezca. Las cadenas rápidas aumentan el combo. Las anomalías Machina rojas son hostiles para ambos bandos.',igorTutorial:['Solo aparece un portal de tu facción cada vez.','Los objetivos correctos dan puntos y aumentan el combo.','Las anomalías Machina rojas restan puntos, tiempo y reinician el combo.'],ritaHelp:'Intercepta los paquetes de tu facción antes de que lleguen abajo. Deja pasar los paquetes Machina rojos corruptos.',ritaTutorial:['Toca los paquetes de tu facción antes de la línea del suelo.','Nunca toques los paquetes Machina rojos corruptos.','Los paquetes buenos aumentan combo y puntuación y pueden devolver tiempo.'],memorySpeak2:'En modo Arcade corre el cronómetro. En Entrenamiento puedes tomarte tu tiempo.'});
Object.assign(TXT.pt,{igorHelp:'Toca no portal da tua fação assim que aparecer. Sequências rápidas aumentam o combo. As anomalias Machina vermelhas são hostis aos dois lados.',igorTutorial:['Só aparece um portal da tua fação de cada vez.','Os alvos corretos dão pontos e aumentam o combo.','As anomalias Machina vermelhas retiram pontos, tempo e reiniciam o combo.'],ritaHelp:'Interceta os pacotes da tua fação antes de chegarem ao fundo. Deixa passar os pacotes Machina vermelhos corrompidos.',ritaTutorial:['Toca nos pacotes da tua fação antes da linha no chão.','Nunca toques nos pacotes Machina vermelhos corrompidos.','Os bons pacotes aumentam combo e pontuação e podem devolver tempo.'],memorySpeak2:'No modo Arcade o cronómetro corre. No Treino podes jogar com calma.'});
Object.assign(TXT.de,{igorHelp:'Tippe das Portal deiner Fraktion an, sobald es erscheint. Schnelle Serien erhöhen den Combo. Rote Machina-Anomalien sind für beide Seiten feindlich.',igorTutorial:['Es erscheint immer nur ein Portal deiner Fraktion.','Richtige Ziele geben Punkte und erhöhen den Combo.','Rote Machina-Anomalien kosten Punkte und Zeit und setzen den Combo zurück.'],ritaHelp:'Fange Pakete deiner Fraktion ab, bevor sie unten ankommen. Lass beschädigte rote Machina-Pakete passieren.',ritaTutorial:['Tippe Pakete deiner Fraktion vor der Bodenlinie an.','Tippe niemals beschädigte rote Machina-Pakete an.','Gute Pakete erhöhen Combo und Punkte und können Zeit zurückgeben.'],memorySpeak2:'Im Arcade-Modus läuft die Uhr. Im Training kannst du dir Zeit lassen.'});
Object.assign(TXT.it,{igorHelp:'Tocca il portale della tua fazione appena appare. Le serie rapide aumentano la combo. Le anomalie Machina rosse sono ostili a entrambi gli schieramenti.',igorTutorial:['Appare un solo portale della tua fazione alla volta.','I bersagli corretti danno punti e aumentano la combo.','Le anomalie Machina rosse fanno perdere punti e tempo e azzerano la combo.'],ritaHelp:'Intercetta i pacchetti della tua fazione prima che arrivino in fondo. Lascia passare i pacchetti Machina rossi corrotti.',ritaTutorial:['Tocca i pacchetti della tua fazione prima della linea a terra.','Non toccare mai i pacchetti Machina rossi corrotti.','I pacchetti corretti aumentano combo e punteggio e possono restituire tempo.'],memorySpeak2:'In modalità Arcade il timer scorre. In Allenamento puoi prenderti tutto il tempo.'});
Object.assign(TXT.nl,{igorHelp:'Tik op het portaal van je factie zodra het verschijnt. Snelle reeksen bouwen combo op. Rode Machina-anomalieën zijn voor beide kampen vijandig.',igorTutorial:['Er verschijnt telkens één portaal van je factie.','Juiste doelen leveren punten op en verhogen de combo.','Rode Machina-anomalieën kosten punten en tijd en resetten de combo.'],ritaHelp:'Onderschep pakketten van je factie voordat ze de onderkant bereiken. Laat corrupte rode Machina-pakketten passeren.',ritaTutorial:['Tik op pakketten van je factie vóór de vloerlijn.','Tik nooit op corrupte rode Machina-pakketten.','Goede pakketten verhogen combo en score en kunnen tijd teruggeven.'],memorySpeak2:'In Arcade loopt de timer. In Training kun je rustig de tijd nemen.'});

Object.assign(TXT.fr,{memoryTutorial:['Retourne deux cartes par tour.','Deux cartes identiques restent visibles et font monter le combo.','Les cartes Machina rouges sont des pièges : elles font perdre du temps et ne forment aucune paire.','Trouve toutes les vraies paires avant la fin du chrono.']});
Object.assign(TXT.en,{memoryTutorial:['Flip two cards per turn.','Matching cards stay visible and build combo.','Red Machina cards are traps: they cost time and never form a pair.','Find every real pair before the timer runs out.']});
Object.assign(TXT.es,{memoryTutorial:['Gira dos cartas por turno.','Las parejas correctas quedan visibles y aumentan el combo.','Las cartas Machina rojas son trampas: restan tiempo y nunca forman pareja.','Encuentra todas las parejas reales antes de que termine el tiempo.']});
Object.assign(TXT.pt,{memoryTutorial:['Vira duas cartas por jogada.','Os pares corretos ficam visíveis e aumentam o combo.','As cartas Machina vermelhas são armadilhas: retiram tempo e nunca formam um par.','Encontra todos os pares reais antes de o tempo acabar.']});
Object.assign(TXT.de,{memoryTutorial:['Drehe pro Zug zwei Karten um.','Richtige Paare bleiben sichtbar und erhöhen den Combo.','Rote Machina-Karten sind Fallen: Sie kosten Zeit und bilden niemals ein Paar.','Finde alle echten Paare, bevor die Zeit abläuft.']});
Object.assign(TXT.it,{memoryTutorial:['Gira due carte per turno.','Le coppie corrette restano visibili e aumentano la combo.','Le carte Machina rosse sono trappole: fanno perdere tempo e non formano mai una coppia.','Trova tutte le coppie vere prima che scada il tempo.']});
Object.assign(TXT.nl,{memoryTutorial:['Draai per beurt twee kaarten om.','Goede paren blijven zichtbaar en verhogen de combo.','Rode Machina-kaarten zijn vallen: ze kosten tijd en vormen nooit een paar.','Vind alle echte paren voordat de tijd op is.']});

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const rand = (min, max) => min + Math.random() * (max - min);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

function langPack(lang) {
  return TXT[String(lang || '').toLowerCase()] || TXT.en;
}
function esc(v = '') {
  return String(v)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
function loadScores() {
  try { return JSON.parse(localStorage.getItem(SCORE_KEY) || '{}') || {}; }
  catch { return {}; }
}
function saveScore(id, score, lowerBetter = false) {
  const scores = loadScores();
  const prev = Number(scores[id] || 0);
  const better = lowerBetter ? (prev <= 0 || score < prev) : score > prev;
  if (better) {
    scores[id] = score;
    localStorage.setItem(SCORE_KEY, JSON.stringify(scores));
  }
  return { best: better ? score : prev, isBest: better };
}
function loadSettings() {
  try {
    return {
      sound: true,
      faction: 'enl',
      mode: 'arcade',
      ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')
    };
  } catch {
    return { sound: true, faction: 'enl', mode: 'arcade' };
  }
}
function saveSettings(v) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(v));
}
function buzz(ms = 16) { try { navigator.vibrate?.(ms); } catch {} }
function tone(freq = 440, dur = 0.05, vol = 0.025) {
  const st = loadSettings();
  if (!st.sound) return;
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.frequency.value = freq;
    o.type = 'sine';
    g.gain.value = vol;
    o.connect(g);
    g.connect(audioCtx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
    o.stop(audioCtx.currentTime + dur);
  } catch {}
}
function successFx() {
  tone(720, 0.06, 0.035);
  setTimeout(() => tone(980, 0.07, 0.025), 55);
  buzz(20);
}
function failFx() {
  tone(150, 0.11, 0.035);
  buzz([25, 35, 25]);
}
function clearGame() {
  try { cleanupGame?.(); } catch {}
  cleanupGame = null;
}
function setScreen(html) {
  clearGame();
  if (!root) return null;
  const body = root.querySelector('.labArcadeBody');
  body.innerHTML = html;
  return body;
}
function btnEvents(scope = root) {
  scope?.querySelectorAll('[data-arc-close]').forEach(b => (b.onclick = closeLabArcade));
  scope?.querySelectorAll('[data-arc-menu]').forEach(b => (b.onclick = showMenu));
}
function scoreLabel(id, score, t) {
  if (!score) return t.noBest;
  if (id === 'memory') return `${score} ${t.moves.toLowerCase()}`;
  return Number(score).toLocaleString();
}

export function openLabArcade(lang = 'en') {
  closeLabArcade();
  activeLang = String(lang || 'en').toLowerCase();
  const t = langPack(activeLang);
  root = document.createElement('div');
  root.className = 'labArcadeRoot';
  root.innerHTML = `
    <div class="labArcadeScan"></div>
    <div class="labArcadeShell">
      <header class="labArcadeTop">
        <div class="labArcadeMark">REDACTED BANNER <s>LAB</s><span>ARCADE</span></div>
        <button class="labArcadeIcon" data-arc-close aria-label="${esc(t.close)}">×</button>
      </header>
      <div class="labArcadeBody"></div>
    </div>`;
  document.body.appendChild(root);
  root.querySelector('[data-arc-close]').onclick = closeLabArcade;
  showGate(t);
}

export function closeLabArcade() {
  clearGame();
  root?.remove();
  root = null;
}

function showGate(t) {
  const body = setScreen(`
    <section class="labArcadeGate backroomGate">
      <div class="labGateNoise"></div>
      <div class="labGateFog"></div>
      <div class="labBackroomCables" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
      <div class="labGateBadge">${esc(t.access)}</div>

      <div class="labGateMarquee labGateMarqueeSign">
        <small>${esc(t.gateBasementLine)}</small>
        <strong class="labGateBrand">REDACTED BANNER <span class="labGateLabSwap"><del>LAB</del><ins>ARCADE</ins></span></strong>
        <p>${esc(t.gateMarqueeText)}</p>
      </div>

      <div class="labGateScene labGateSceneBackroom">
        <div class="labGateCabinet left">
          <span>IGOR</span>
          <div class="labGateCabScreen"><img src="/igor.png" alt=""><em>${esc(t.online)}</em></div>
          <i></i><i></i><i></i>
          <b>PORTAL PANIC</b>
        </div>
        <div class="labGateCenter labGateCenterBackroom">
          <div class="labGateCeiling"></div>
          <div class="labGateFloor"></div>
          <div class="labBackroomDoor"><span>${esc(t.authorizedOnly)}</span><b>07</b><i></i></div>
          <div class="labBackroomTerminal">
            <small>${esc(t.arcadeCore)}</small>
            <strong>${esc(t.unlocked)}</strong>
            <p>IGOR ✓ &nbsp; MILO ✓ &nbsp; RITA ✓</p>
          </div>
          <div class="labGateTokens"><span>${esc(t.tokens)}</span><b>∞</b><i></i><i></i><i></i></div>
        </div>
        <div class="labGateCabinet right cyan">
          <span>RITA</span>
          <div class="labGateCabScreen"><img src="/rita.png" alt=""><em>RX</em></div>
          <i></i><i></i><i></i>
          <b>SIGNAL STORM</b>
        </div>
      </div>

      <div class="labGateCrew">
        <div class="labGateCrewCard green">
          <img src="/igor.png" alt="IGOR">
          <div><small>IGOR</small><b>${esc(t.networkStable)}</b><p>${esc(t.cabinetsPowered)}</p></div>
        </div>
        <div class="labGateCrewCard amber">
          <img src="/assets/milo.jpg" alt="MILO">
          <div><small>MILO</small><b>${esc(t.filesLoaded)}</b><p>${esc(t.simulationsReady)}</p></div>
        </div>
        <div class="labGateCrewCard cyan">
          <img src="/rita.png" alt="RITA">
          <div><small>RITA</small><b>${esc(t.channelOpen)}</b><p>${esc(t.arcadeNotCertified)}</p></div>
        </div>
      </div>

      <div class="labRedactedSpeak">
        <div class="labRedactedAvatar"><img src="/icon-512.png" alt="Redacted"></div>
        <div class="labRedactedBubble">
          <small>REDACTED // ${esc(t.basementAdmin)}</small>
          <strong>${esc(t.redactedRoomTitle)}</strong>
          <p>${esc(t.redactedRoomText)}</p>
        </div>
      </div>

      <div class="labGateActions">
        <button class="labArcadePrimary" data-enter>${esc(t.enter)}</button>
        <button class="labArcadeSecondary" data-arc-close>${esc(t.leave)}</button>
      </div>
    </section>`);
  btnEvents(body);
  body.querySelector('[data-enter]').onclick = () => {
    tone(520, 0.05);
    showMenu();
  };
}

function gamesFor(t) {
  return [
    { id: 'igor', title: t.igorTitle, desc: t.igorDesc, img: '/arcade/igor.png', cls: 'igor' },
    { id: 'milo', title: t.miloTitle, desc: t.miloDesc, img: '/assets/milo.jpg', cls: 'milo' },
    { id: 'rita', title: t.ritaTitle, desc: t.ritaDesc, img: '/arcade/rita.png', cls: 'rita' },
    { id: 'dino', title: t.dinoTitle, desc: t.dinoDesc, img: '/arcade/redacted.png', cls: 'dino' },
    { id: 'blaster', title: t.blasterTitle, desc: t.blasterDesc, img: '/arcade/rita.png', cls: 'blaster' },
    { id: 'memory', title: t.memoryTitle, desc: t.memoryDesc, img: '/arcade/redacted.png', cls: 'memory' }
  ];
}

function showMenu() {
  if (!root) return;
  const t = langPack(activeLang);
  const scores = loadScores();
  const settings = loadSettings();
  const cards = gamesFor(t)
    .map(g => `
      <button class="labGameCard ${g.cls}" data-game="${g.id}">
        <div class="labGameArt ${g.cls}"><img src="${g.img}" alt=""><span class="labGamePulse"></span></div>
        <div class="labGameCopy">
          <small>${esc(t.best)} · ${esc(scoreLabel(g.id, scores[g.id], t))}</small>
          <strong>${esc(g.title)}</strong>
          <p>${esc(g.desc)}</p>
          <span>${esc(t.play)} ›</span>
        </div>
      </button>`)
    .join('');
  const body = setScreen(`
    <section class="labArcadeMenu">
      <div class="labMenuHero">
        <div>
          <small>${esc(t.hidden)}</small>
          <h2>${esc(t.arcade)}</h2>
          <p>${esc(t.arcadeSub)}</p>
        </div>
        <div class="labMenuControls">
          <button class="labSoundToggle ${settings.sound ? 'on' : ''}" data-sound>◉ ${esc(t.sound)}</button>
        </div>
      </div>
      <div class="labGameGrid">${cards}</div>
      <div class="labClassified"><span>⌁</span><p><b>${esc(t.hidden)}</b><br>${esc(t.hiddenText)}</p></div>
    </section>`);
  body.querySelectorAll('[data-game]').forEach(b => (b.onclick = () => launchGame(b.dataset.game, t)));
  body.querySelector('[data-sound]').onclick = e => {
    const st = loadSettings();
    st.sound = !st.sound;
    saveSettings(st);
    e.currentTarget.classList.toggle('on', st.sound);
    if (st.sound) tone(640, 0.05);
  };
}

function launchGame(id, t) {
  if (id === 'igor') return gameIgor(t);
  if (id === 'milo') return gameMilo(t);
  if (id === 'rita') return gameRita(t);
  if (id === 'dino') return gameDino(t);
  if (id === 'blaster') return gameBlaster(t);
  if (id === 'memory') return gameMemory(t);
}

function gameFrame({ title, help, img, t, extra = '', arenaClass = '' }) {
  return `
    <section class="labGameScreen">
      <div class="labGameHead">
        <button class="labBack" data-arc-menu>‹ ${esc(t.back)}</button>
        <div class="labGameIdentity">
          <img src="${img}" alt="">
          <div>
            <small>${esc(t.experimentLabel)}</small>
            <strong>${esc(title)}</strong>
          </div>
        </div>
      </div>
      ${help ? `<p class="labGameHelp">${esc(help)}</p>` : ''}
      ${extra}
      <div class="labGameArena ${arenaClass}"></div>
    </section>`;
}
function hud(t, parts) {
  return `<div class="labHud">${parts
    .map(([label, val, cls = '']) => `<div class="${cls}"><small>${esc(label)}</small><b data-hud="${esc(val.key)}">${esc(val.value)}</b></div>`)
    .join('')}</div>`;
}
function endPanel({ t, id, score, title, lowerBetter = false, detail = '', restart, record = true }) {
  const result = record ? saveScore(id, score, lowerBetter) : { best: 0, isBest: false };
  successFx();
  const body = root.querySelector('.labArcadeBody');
  const pane = document.createElement('div');
  pane.className = 'labEndPanel';
  pane.innerHTML = `
    <div class="labEndBurst"></div>
    <small>${result.isBest ? esc(t.newBest) : esc(title)}</small>
    <strong>${esc(id === 'memory' ? `${score} ${t.moves.toLowerCase()}` : Number(score).toLocaleString())}</strong>
    ${detail ? `<p>${esc(detail)}</p>` : ''}
    <div>
      <button class="labArcadePrimary" data-again>${esc(t.again)}</button>
      <button class="labArcadeSecondary" data-arc-menu>${esc(t.menu)}</button>
    </div>`;
  body.appendChild(pane);
  pane.querySelector('[data-again]').onclick = restart;
  pane.querySelector('[data-arc-menu]').onclick = showMenu;
}

function comboTimeBonus(combo) {
  const c = Number(combo) || 0;
  if (c >= 10) return 4;
  if (c >= 7) return 3;
  if (c >= 4) return 2;
  if (c >= 2) return 1;
  return 0;
}
function showTimeBonus(scope, t, seconds) {
  if (!scope || !seconds) return;
  const hudTime = scope.querySelector('[data-hud="time"]')?.closest('div');
  if (!hudTime) return;
  const tag = document.createElement('span');
  tag.className = 'labTimeBonus';
  tag.textContent = String(t.timeBonus || 'Time +{n}s').replace('{n}', seconds);
  hudTime.appendChild(tag);
  setTimeout(() => tag.remove(), 720);
}
function makeArcadeClock({ body, t, mode = 'arcade', seconds = 30, onExpire }) {
  let time = seconds;
  let timer = null;
  let stopped = false;
  const timeEl = body.querySelector('[data-hud="time"]');
  const render = () => { if (timeEl) timeEl.textContent = mode === 'training' ? '∞' : Math.max(0, Math.ceil(time)); };
  const stop = () => { stopped = true; clearInterval(timer); };
  const add = amount => {
    if (mode !== 'arcade' || stopped) return 0;
    const n = Math.max(0, Math.round(Number(amount) || 0));
    if (!n) return 0;
    time = Math.min(99, time + n);
    render();
    showTimeBonus(body, t, n);
    return n;
  };
  const penalize = amount => {
    if (mode !== 'arcade' || stopped) return 0;
    const n = Math.max(0, Math.round(Number(amount) || 0));
    if (!n) return 0;
    time = Math.max(0, time - n);
    render();
    const hudTime = body.querySelector('[data-hud="time"]')?.closest('div');
    if (hudTime) {
      const tag = document.createElement('span');
      tag.className = 'labTimeBonus penalty';
      tag.textContent = `−${n}s`;
      hudTime.appendChild(tag);
      setTimeout(() => tag.remove(), 720);
    }
    if (time <= 0) { stop(); onExpire?.(); }
    return n;
  };
  if (mode === 'arcade') {
    timer = setInterval(() => {
      time -= 1;
      render();
      if (time <= 0) {
        stop();
        onExpire?.();
      }
    }, 1000);
  }
  render();
  return { add, penalize, stop, value: () => time, mode };
}
function arcadeModeLabel(t, mode) { return mode === 'training' ? t.trainingBadge : t.arcadeBadge; }

function countdown(arena, t, go) {
  let n = 3;
  arena.innerHTML = `<div class="labCountdown"><small>${esc(t.ready)}</small><b>${n}</b></div>`;
  const iv = setInterval(() => {
    n -= 1;
    const b = arena.querySelector('.labCountdown b');
    if (!b) return;
    if (n > 0) {
      b.textContent = n;
      tone(390 + n * 80, 0.035);
    } else {
      clearInterval(iv);
      b.textContent = t.go;
      tone(760, 0.07);
      setTimeout(go, 330);
    }
  }, 520);
  cleanupGame = () => clearInterval(iv);
}

function showBriefing({ t, title, img, speakers = [], tutorial = [], onStart, factionPicker = true, modePicker = true, accent = 'green' }) {
  const st = loadSettings();
  const selectedFaction = st.faction === 'res' ? 'res' : 'enl';
  const selectedMode = st.mode === 'training' ? 'training' : 'arcade';
  const speakerHtml = speakers
    .map(s => `
      <div class="labSpeak ${esc(s.accent || accent)}">
        <img src="${s.img}" alt="${esc(s.name)}">
        <div class="labBubble">
          <small>${esc(s.name)}</small>
          <p>${esc(s.text)}</p>
        </div>
      </div>`)
    .join('');
  const tutorialHtml = tutorial.length
    ? `
      <div class="labTutorialPanel" hidden>
        <small>${esc(t.tutorialTitle)}</small>
        <ul>${tutorial.map(line => `<li>${esc(line)}</li>`).join('')}</ul>
      </div>`
    : '';
  const factionHtml = factionPicker
    ? `
      <div class="labFactionBlock">
        <small>${esc(t.chooseFaction)}</small>
        <div class="labFactionPicker" data-faction-picker>
          <button class="labFactionButton enl ${selectedFaction === 'enl' ? 'active' : ''}" data-faction="enl"><b>${esc(t.enl)}</b><span>ENLIGHTENED</span></button>
          <button class="labFactionButton res ${selectedFaction === 'res' ? 'active' : ''}" data-faction="res"><b>${esc(t.res)}</b><span>RESISTANCE</span></button>
        </div>
        <p class="labFactionHint">${esc(t.teamHint)} · ${esc(t.commonEnemy)}</p>
      </div>`
    : '';
  const modeHtml = modePicker
    ? `
      <div class="labModeBlock">
        <small>${esc(t.chooseMode)}</small>
        <div class="labModePicker" data-mode-picker>
          <button class="labModeButton arcade ${selectedMode === 'arcade' ? 'active' : ''}" data-mode="arcade"><b>🕹 ${esc(t.arcadeMode)}</b><span>${esc(t.arcadeModeText)}</span></button>
          <button class="labModeButton training ${selectedMode === 'training' ? 'active' : ''}" data-mode="training"><b>⚙ ${esc(t.trainingMode)}</b><span>${esc(t.trainingModeText)}</span></button>
        </div>
      </div>`
    : '';
  const body = setScreen(`
    <section class="labGameScreen briefingOnly">
      <div class="labGameHead">
        <button class="labBack" data-arc-menu>‹ ${esc(t.back)}</button>
        <div class="labGameIdentity">
          <img src="${img}" alt="">
          <div>
            <small>${esc(t.briefingLabel)}</small>
            <strong>${esc(title)}</strong>
          </div>
        </div>
      </div>
      <div class="labBriefingCard ${esc(accent)}">
        <div class="labBriefingTitle">
          <small>${esc(t.briefing)}</small>
          <h3>${esc(title)}</h3>
        </div>
        <div class="labSpeakList">${speakerHtml}</div>
        ${factionHtml}
        ${modeHtml}
        ${tutorialHtml}
        <div class="labBriefingActions">
          ${tutorial.length ? `<button class="labArcadeSecondary" data-open-tutorial>${esc(t.tutorial)}</button>` : ''}
          <button class="labArcadePrimary" data-start-briefing>${esc(t.startMission)}</button>
        </div>
      </div>
    </section>`);
  btnEvents(body);
  const tut = body.querySelector('.labTutorialPanel');
  const tutBtn = body.querySelector('[data-open-tutorial]');
  if (tut && tutBtn) {
    tutBtn.onclick = () => {
      const hidden = tut.hasAttribute('hidden');
      if (hidden) tut.removeAttribute('hidden');
      else tut.setAttribute('hidden', 'hidden');
      tone(hidden ? 680 : 280, 0.04, 0.02);
    };
  }
  body.querySelectorAll('[data-faction]').forEach(btn => {
    btn.onclick = () => {
      body.querySelectorAll('[data-faction]').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      const next = btn.dataset.faction === 'res' ? 'res' : 'enl';
      const nextSettings = loadSettings();
      nextSettings.faction = next;
      saveSettings(nextSettings);
      tone(next === 'res' ? 460 : 560, 0.04, 0.025);
    };
  });
  body.querySelectorAll('[data-mode]').forEach(btn => {
    btn.onclick = () => {
      body.querySelectorAll('[data-mode]').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      const next = btn.dataset.mode === 'training' ? 'training' : 'arcade';
      const nextSettings = loadSettings();
      nextSettings.mode = next;
      saveSettings(nextSettings);
      tone(next === 'arcade' ? 720 : 420, 0.04, 0.022);
    };
  });
  body.querySelector('[data-start-briefing]').onclick = () => {
    const faction = body.querySelector('[data-faction].active')?.dataset.faction || selectedFaction;
    const mode = body.querySelector('[data-mode].active')?.dataset.mode || selectedMode;
    tone(540, 0.05);
    onStart?.(faction, mode);
  };
}

function gameIgor(t) {
  showBriefing({
    t,
    title: t.igorTitle,
    img: '/arcade/igor.png',
    accent: 'green',
    speakers: [
      { name: 'IGOR', img: '/arcade/igor.png', text: t.igorSpeak1, accent: 'green' },
      { name: 'REDACTED', img: '/arcade/redacted.png', text: t.igorSpeak2, accent: 'amber' }
    ],
    tutorial: [...t.igorTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startIgor(t, faction, mode)
  });
}

function startIgor(t, faction = 'enl', mode = 'arcade') {
  const body = setScreen(gameFrame({
    title: `${t.igorTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help: t.igorHelp,
    img: '/arcade/igor.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '24' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  arena.classList.add(`team-${faction}`);
  countdown(arena, t, () => {
    let score = 0;
    let combo = 1;
    let active = null;
    let spawnTimer = null;
    let ended = false;
    let clock = null;
    arena.innerHTML = `<div class="igorGrid team-${faction}">${Array.from({ length: 16 }, (_, i) => `<button data-cell="${i}" aria-label="portal"><span></span></button>`).join('')}</div><div class="igorRouteLine"></div>`;
    const cells = [...arena.querySelectorAll('[data-cell]')];
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const finish = () => {
      if (ended) return;
      ended = true;
      clock?.stop();
      clearTimeout(spawnTimer);
      cells.forEach(c => (c.disabled = true));
      endPanel({ t, id: 'igor', score, title: t.gameOver, restart: () => gameIgor(t), record: mode === 'arcade' });
    };
    clock = makeArcadeClock({ body, t, mode, seconds: 24, onExpire: finish });
    const spawn = () => {
      if (ended) return;
      cells.forEach(c => { c.className = ''; c.disabled = false; });
      const idx = Math.floor(Math.random() * cells.length);
      const anomaly = Math.random() < 0.22;
      active = { idx, anomaly, at: performance.now() };
      cells[idx].className = anomaly ? 'anomaly' : `active ${faction}`;
      spawnTimer = setTimeout(() => {
        if (!ended && active?.idx === idx) {
          if (!anomaly) {
            combo = 1;
            comboEl.textContent = '×1';
          }
          spawn();
        }
      }, Math.max(520, 1120 - score / 55));
    };
    cells.forEach((c, i) => {
      c.onclick = () => {
        if (!active || i !== active.idx || ended) return;
        clearTimeout(spawnTimer);
        const elapsed = performance.now() - active.at;
        if (active.anomaly) {
          score = Math.max(0, score - 180);
          combo = 1;
          clock?.penalize(2);
          failFx();
          c.classList.add('hitbad');
        } else {
          const gain = Math.max(55, 160 - Math.floor(elapsed / 12)) * combo;
          score += gain;
          combo = Math.min(12, combo + 1);
          const bonus = comboTimeBonus(combo);
          if (bonus) clock.add(bonus);
          successFx();
          c.classList.add('hitgood');
        }
        scoreEl.textContent = score;
        comboEl.textContent = `×${combo}`;
        active = null;
        setTimeout(spawn, 90);
      };
    });
    spawn();
    cleanupGame = () => {
      ended = true;
      clock?.stop();
      clearTimeout(spawnTimer);
    };
  });
}

function gameMilo(t) {
  showBriefing({
    t,
    title: t.miloTitle,
    img: '/assets/milo.jpg',
    accent: 'green',
    speakers: [
      { name: 'MILO', img: '/assets/milo.jpg', text: t.miloSpeak1, accent: 'green' },
      { name: 'RITA', img: '/arcade/rita.png', text: t.miloSpeak2, accent: 'cyan' }
    ],
    tutorial: [...t.miloTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startMilo(t, faction, mode)
  });
}

function startMilo(t, faction = 'enl', mode = 'arcade') {
  const body = setScreen(gameFrame({
    title: `${t.miloTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help: t.miloHelp,
    img: '/assets/milo.jpg',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '30' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  arena.classList.add(`team-${faction}`);
  countdown(arena, t, () => {
    let score = 0;
    let round = 1;
    let next = 1;
    let combo = 1;
    let ended = false;
    let roundStarted = performance.now();
    let clock = null;
    let hazardTimer = null;
    let hazardHide = null;
    arena.innerHTML = `<div class="miloStatus ${faction}"><span>${esc(t.nextMission)}</span><b data-next>1</b><em data-round>${esc(t.round)} 1</em></div><div class="miloGrid team-${faction}"></div><button class="miloHazard" data-milo-hazard hidden><b>MX</b><span>${esc(t.machina)}</span></button>`;
    const grid = arena.querySelector('.miloGrid');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const nextEl = arena.querySelector('[data-next]');
    const roundEl = arena.querySelector('[data-round]');
    const hazardEl = arena.querySelector('[data-milo-hazard]');
    const finish = () => {
      if (ended) return;
      ended = true;
      clock?.stop();
      clearInterval(hazardTimer);
      clearTimeout(hazardHide);
      grid.querySelectorAll('button').forEach(b => (b.disabled = true));
      endPanel({ t, id: 'milo', score, title: t.gameOver, restart: () => gameMilo(t), record: mode === 'arcade' });
    };
    clock = makeArcadeClock({ body, t, mode, seconds: 30, onExpire: finish });
    const tap = (n, b) => {
      if (ended) return;
      if (n !== next) {
        score = Math.max(0, score - 100);
        combo = 1;
        comboEl.textContent = '×1';
        scoreEl.textContent = score;
        failFx();
        b.classList.add('bad');
        setTimeout(() => b.classList.remove('bad'), 240);
        return;
      }
      successFx();
      b.classList.add('done');
      b.disabled = true;
      score += (120 + Math.max(0, 180 - Math.floor((performance.now() - roundStarted) / 35))) * combo;
      combo = Math.min(12, combo + 1);
      const bonus = comboTimeBonus(combo);
      if (bonus) clock.add(bonus);
      scoreEl.textContent = score;
      comboEl.textContent = `×${combo}`;
      next += 1;
      if (next <= 6) {
        nextEl.textContent = next;
        return;
      }
      score += 600 * Math.max(1, combo - 2);
      if (mode === 'arcade') clock.add(3);
      scoreEl.textContent = score;
      round += 1;
      roundEl.textContent = `${t.round} ${round}`;
      nextEl.textContent = '✓';
      setTimeout(shuffle, 420);
    };
    const shuffle = () => {
      if (ended) return;
      const nums = [1, 2, 3, 4, 5, 6].sort(() => Math.random() - 0.5);
      grid.innerHTML = nums.map(n => `<button class="${faction}" data-n="${n}"><small>M</small><b>${String(n).padStart(2, '0')}</b><span>${esc(t.readyShort)}</span></button>`).join('');
      grid.querySelectorAll('button').forEach(b => (b.onclick = () => tap(Number(b.dataset.n), b)));
      next = 1;
      nextEl.textContent = '1';
      roundStarted = performance.now();
    };
    const flashHazard = () => {
      if (ended || !hazardEl) return;
      hazardEl.hidden = false;
      hazardEl.style.left = `${12 + Math.random() * 68}%`;
      hazardEl.style.top = `${24 + Math.random() * 52}%`;
      clearTimeout(hazardHide);
      hazardHide = setTimeout(() => { if (hazardEl) hazardEl.hidden = true; }, 1050);
    };
    hazardEl.onclick = () => {
      if (ended || hazardEl.hidden) return;
      hazardEl.hidden = true;
      combo = 1;
      comboEl.textContent = '×1';
      score = Math.max(0, score - 160);
      scoreEl.textContent = score;
      clock?.penalize(2);
      failFx();
    };
    shuffle();
    hazardTimer = setInterval(flashHazard, 2800);
    cleanupGame = () => {
      ended = true;
      clock?.stop();
      clearInterval(hazardTimer);
      clearTimeout(hazardHide);
    };
  });
}

function gameRita(t) {
  showBriefing({
    t,
    title: t.ritaTitle,
    img: '/arcade/rita.png',
    accent: 'cyan',
    speakers: [
      { name: 'RITA', img: '/arcade/rita.png', text: t.ritaSpeak1, accent: 'cyan' },
      { name: 'IGOR', img: '/arcade/igor.png', text: t.ritaSpeak2, accent: 'green' }
    ],
    tutorial: [...t.ritaTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startRita(t, faction, mode)
  });
}

function startRita(t, faction = 'enl', mode = 'arcade') {
  const body = setScreen(gameFrame({
    title: `${t.ritaTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help: t.ritaHelp,
    img: '/arcade/rita.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '26' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  arena.classList.add(`team-${faction}`);
  countdown(arena, t, () => {
    let score = 0;
    let combo = 1;
    let ended = false;
    let spawnIv = null;
    let raf = 0;
    let last = performance.now();
    let packets = [];
    let clock = null;
    arena.innerHTML = `<div class="ritaField team-${faction}"><div class="ritaAntenna">RITA // RX · ${esc(factionNames(t, faction))}</div><div class="ritaFloor"></div></div>`;
    const field = arena.querySelector('.ritaField');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const finish = () => {
      if (ended) return;
      ended = true;
      clock?.stop();
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
      packets.forEach(p => p.el.remove());
      endPanel({ t, id: 'rita', score, title: t.gameOver, restart: () => gameRita(t), record: mode === 'arcade' });
    };
    clock = makeArcadeClock({ body, t, mode, seconds: 26, onExpire: finish });
    const spawn = () => {
      if (ended) return;
      const bad = Math.random() < 0.28;
      const el = document.createElement('button');
      el.className = `ritaPacket ${bad ? 'bad' : faction}`;
      el.innerHTML = `<span>${bad ? '×' : '↧'}</span><small>${esc(bad ? t.corruptShort : t.signalShort)}</small>`;
      const x = 8 + Math.random() * 78;
      el.style.left = `${x}%`;
      field.appendChild(el);
      const p = { el, y: -12, speed: 15 + Math.random() * 12, bad };
      packets.push(p);
      el.onclick = () => {
        if (ended) return;
        if (bad) {
          score = Math.max(0, score - 180);
          combo = 1;
          clock?.penalize(2);
          failFx();
          el.classList.add('burstbad');
        } else {
          score += 110 * combo;
          combo = Math.min(12, combo + 1);
          const bonus = comboTimeBonus(combo);
          if (bonus) clock.add(bonus);
          successFx();
          el.classList.add('burstgood');
        }
        scoreEl.textContent = score;
        comboEl.textContent = `×${combo}`;
        setTimeout(() => el.remove(), 180);
        packets = packets.filter(q => q !== p);
      };
    };
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      for (const p of [...packets]) {
        p.y += p.speed * dt;
        p.el.style.transform = `translateY(${p.y}vh)`;
        if (p.y > 66) {
          if (!p.bad) {
            combo = 1;
            comboEl.textContent = '×1';
            score = Math.max(0, score - 60);
            scoreEl.textContent = score;
            failFx();
          }
          p.el.remove();
          packets = packets.filter(q => q !== p);
        }
      }
      if (!ended) raf = requestAnimationFrame(loop);
    };
    spawn();
    spawnIv = setInterval(spawn, 600);
    raf = requestAnimationFrame(loop);
    cleanupGame = () => {
      ended = true;
      clock?.stop();
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
    };
  });
}

function factionNames(t, faction) {
  return faction === 'res' ? t.res : t.enl;
}
function oppositeFaction(faction) {
  return faction === 'res' ? 'enl' : 'res';
}

function gameDino(t) {
  showBriefing({
    t,
    title: t.dinoTitle,
    img: '/arcade/redacted.png',
    accent: 'amber',
    speakers: [
      { name: 'REDACTED', img: '/arcade/redacted.png', text: t.dinoSpeak1, accent: 'amber' },
      { name: 'RITA', img: '/arcade/rita.png', text: t.dinoSpeak2, accent: 'cyan' }
    ],
    tutorial: [...t.dinoTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startDino(t, faction, mode)
  });
}

function startDino(t, faction = 'enl', mode = 'arcade') {
  const help = faction === 'res' ? t.dinoHelpRes : t.dinoHelpEnl;
  const body = setScreen(gameFrame({
    title: `${t.dinoTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help,
    img: '/arcade/redacted.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '32' }],
      [t.lives, { key: 'lives', value: mode === 'training' ? '∞' : '♥♥♥' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let lives = 3;
    let combo = 1;
    let lane = 1;
    let ended = false;
    let objs = [];
    let spawnIv = null;
    let raf = 0;
    let last = performance.now();
    let invul = 0;
    let clock = null;
    const enemyFaction = oppositeFaction(faction);
    arena.innerHTML = `
      <div class="dinoField ${faction}">
        <div class="dinoLane l0"></div><div class="dinoLane l1"></div><div class="dinoLane l2"></div>
        <img class="dinoPlayer" src="/redacted-dino-cutout.png" alt="Redacted">
        <button class="dinoTap left" aria-label="left"></button><button class="dinoTap right" aria-label="right"></button>
      </div>`;
    const field = arena.querySelector('.dinoField');
    const player = arena.querySelector('.dinoPlayer');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const livesEl = body.querySelector('[data-hud="lives"]');
    const finish = () => {
      if (ended) return;
      ended = true;
      clock?.stop();
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
      objs.forEach(o => o.el.remove());
      endPanel({ t, id: 'dino', score, title: t.gameOver, restart: () => gameDino(t), record: mode === 'arcade' });
    };
    clock = makeArcadeClock({ body, t, mode, seconds: 32, onExpire: finish });
    const move = dir => {
      lane = Math.max(0, Math.min(2, lane + dir));
      player.dataset.lane = lane;
      player.style.left = `${16.66 + lane * 33.33}%`;
      tone(320 + lane * 80, 0.03, 0.018);
    };
    const removeObj = o => {
      o.el.remove();
      objs = objs.filter(q => q !== o);
    };
    const explodeAt = source => {
      source.el.classList.add('exploding');
      const shock = document.createElement('div');
      shock.className = 'dinoShock';
      shock.style.left = source.el.style.left;
      shock.style.top = `${source.y}%`;
      field.appendChild(shock);
      setTimeout(() => shock.remove(), 260);
      for (const o of [...objs]) {
        if (o === source) continue;
        if (Math.abs(o.y - source.y) < 18 && Math.abs(o.lane - source.lane) <= 1) {
          o.el.classList.add(o.type === 'faction' ? 'collected' : 'enemyhit');
          setTimeout(() => removeObj(o), 120);
        }
      }
      setTimeout(() => removeObj(source), 160);
    };
    arena.querySelector('.dinoTap.left').onclick = () => move(-1);
    arena.querySelector('.dinoTap.right').onclick = () => move(1);
    move(0);
    const spawn = () => {
      if (ended) return;
      const roll = Math.random();
      const l = Math.floor(Math.random() * 3);
      const el = document.createElement('div');
      let type = 'faction';
      let kind = faction;
      if (roll < 0.43) {
        type = 'faction'; kind = faction;
        el.className = `dinoObject crate ${faction}`;
        el.innerHTML = `<span>${faction === 'res' ? 'RES' : 'ENL'}</span>`;
      } else if (roll < 0.77) {
        type = 'enemy'; kind = enemyFaction;
        el.className = `dinoObject crate ${enemyFaction}`;
        el.innerHTML = `<span>${enemyFaction === 'res' ? 'RES' : 'ENL'}</span>`;
      } else {
        type = 'machina'; kind = 'machina';
        el.className = 'dinoObject crate machina';
        el.innerHTML = `<span>MX</span>`;
      }
      el.style.left = `${16.66 + l * 33.33}%`;
      field.appendChild(el);
      objs.push({ el, lane: l, y: -10, speed: 18 + Math.random() * 11, type, kind, hit: false });
    };
    const hitEnemy = (penalty = 2) => {
      combo = 1;
      comboEl.textContent = '×1';
      if (invul > 0) return;
      invul = 0.9;
      clock?.penalize(penalty);
      failFx();
      player.classList.add('ouch');
      setTimeout(() => player.classList.remove('ouch'), 420);
      if (mode === 'training') return;
      lives -= 1;
      livesEl.textContent = '♥'.repeat(Math.max(0, lives)) + '♡'.repeat(Math.max(0, 3 - lives));
      if (lives <= 0) finish();
    };
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      invul = Math.max(0, invul - dt);
      for (const o of [...objs]) {
        o.y += o.speed * dt;
        o.el.style.top = `${o.y}%`;
        if (!o.hit && o.y > 72 && o.y < 90 && o.lane === lane) {
          o.hit = true;
          if (o.type === 'faction') {
            score += 180 * combo;
            combo = Math.min(12, combo + 1);
            const bonus = comboTimeBonus(combo);
            if (bonus) clock.add(bonus);
            scoreEl.textContent = score;
            comboEl.textContent = `×${combo}`;
            successFx();
            o.el.classList.add('collected');
            setTimeout(() => removeObj(o), 160);
          } else if (o.type === 'enemy') {
            hitEnemy();
            o.el.classList.add('enemyhit');
            setTimeout(() => removeObj(o), 160);
          } else {
            hitEnemy(3);
            explodeAt(o);
          }
        } else if (o.y > 105) {
          if (o.type === 'faction') {
            combo = 1;
            comboEl.textContent = '×1';
            score = Math.max(0, score - 35);
            scoreEl.textContent = score;
          }
          removeObj(o);
        }
      }
      if (!ended) raf = requestAnimationFrame(loop);
    };
    spawnIv = setInterval(spawn, 610);
    spawn();
    raf = requestAnimationFrame(loop);
    cleanupGame = () => {
      ended = true;
      clock?.stop();
      clearInterval(spawnIv);
      cancelAnimationFrame(raf);
    };
  });
}

function gameBlaster(t) {
  showBriefing({
    t,
    title: t.blasterTitle,
    img: '/arcade/rita.png',
    accent: 'violet',
    factionPicker: true,
    speakers: [
      { name: 'RITA', img: '/arcade/rita.png', text: t.blasterSpeak1, accent: 'cyan' },
      { name: 'IGOR', img: '/arcade/igor.png', text: t.blasterSpeak2, accent: 'green' },
      { name: 'REDACTED', img: '/arcade/redacted.png', text: t.blasterSpeak3, accent: 'amber' }
    ],
    tutorial: [...t.blasterTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startBlaster(t, faction, mode)
  });
}

function startBlaster(t, faction = 'enl', mode = 'arcade') {
  const enemyFaction = oppositeFaction(faction);
  const body = setScreen(gameFrame({
    title: `${t.blasterTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help: t.blasterHelp,
    img: '/arcade/rita.png',
    t,
    extra: hud(t, [
      [t.score, { key: 'score', value: '0' }],
      [t.level, { key: 'level', value: '1' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '45' }],
      [t.power, { key: 'power', value: '1' }],
      [t.lives, { key: 'lives', value: mode === 'training' ? '∞' : '♥♥♥' }]
    ]),
    arenaClass: 'blasterArena'
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  countdown(arena, t, () => {
    let score = 0;
    let level = 1;
    let power = 1;
    let lives = 3;
    let combo = 1;
    let superCharge = 0;
    let ended = false;
    let width = 0;
    let height = 0;
    let kills = 0;
    let killsToAdvance = 10;
    let bullets = [];
    let enemies = [];
    let pickups = [];
    let enemyShots = [];
    let boss = null;
    let raf = 0;
    let last = performance.now();
    let fireCd = 0;
    let spawnCd = 0.4;
    let bossShotCd = 1.1;
    let invul = 0;
    let moveInput = 0;
    let joyInput = 0;
    let joyPointer = null;
    let formationIndex = 0;
    let clock = null;

    arena.innerHTML = `
      <div class="blasterField ${faction}">
        <div class="blasterStars"></div>
        <div class="blasterFactionBadge ${faction}">${esc(factionNames(t, faction))}</div>
        <div class="blasterBossBar ${enemyFaction}" hidden><i></i></div>
        <div class="blasterLevelProgress"><span>${esc(t.levelShort)} 1</span><div><i></i></div></div>
        <button class="blasterSuper ${faction}" data-super disabled><small>${esc(t.superLabel)}</small><b>0%</b></button>
        <div class="blasterPlayer ${faction}"><span></span></div>
        <div class="blasterControls">
          <button class="blasterArrow left" data-dir="left" aria-label="left">◀</button>
          <div class="blasterJoystick" data-joy><div class="blasterJoystickTrack"></div><div class="blasterJoystickThumb"></div></div>
          <button class="blasterArrow right" data-dir="right" aria-label="right">▶</button>
        </div>
      </div>`;

    const field = arena.querySelector('.blasterField');
    const playerEl = arena.querySelector('.blasterPlayer');
    const bossBar = arena.querySelector('.blasterBossBar');
    const levelProgress = arena.querySelector('.blasterLevelProgress');
    const levelProgressFill = levelProgress.querySelector('i');
    const levelProgressLabel = levelProgress.querySelector('span');
    const superBtn = arena.querySelector('[data-super]');
    const superValue = superBtn.querySelector('b');
    const scoreEl = body.querySelector('[data-hud="score"]');
    const levelEl = body.querySelector('[data-hud="level"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const powerEl = body.querySelector('[data-hud="power"]');
    const livesEl = body.querySelector('[data-hud="lives"]');
    const joy = arena.querySelector('[data-joy]');
    const joyThumb = arena.querySelector('.blasterJoystickThumb');
    const player = { x: 0, y: 0, w: 54, h: 44, vx: 0 };

    const refreshHud = () => {
      scoreEl.textContent = score;
      levelEl.textContent = level;
      comboEl.textContent = `×${combo}`;
      powerEl.textContent = power;
      livesEl.textContent = mode === 'training' ? '∞' : ('♥'.repeat(Math.max(0, lives)) + '♡'.repeat(Math.max(0, 3 - lives)));
      const progress = boss ? 100 : clamp((kills / Math.max(1, killsToAdvance)) * 100, 0, 100);
      levelProgressFill.style.width = `${progress}%`;
      levelProgressLabel.textContent = `LV ${level}`;
      superValue.textContent = `${Math.round(superCharge)}%`;
      superBtn.disabled = superCharge < 100 || ended;
      superBtn.classList.toggle('ready', superCharge >= 100 && !ended);
    };
    const resize = () => {
      const r = field.getBoundingClientRect();
      width = r.width;
      height = r.height;
      player.y = height - 105;
      if (!player.x) player.x = width / 2;
    };
    resize();
    window.addEventListener('resize', resize);

    const setJoyVisual = value => { joyThumb.style.left = `${50 + value * 42}%`; };
    setJoyVisual(0);
    const stopJoy = () => {
      joyInput = 0;
      joyPointer = null;
      setJoyVisual(0);
    };
    const updateJoy = clientX => {
      const r = joy.getBoundingClientRect();
      joyInput = clamp((((clientX - r.left) / r.width) * 2) - 1, -1, 1);
      setJoyVisual(joyInput);
    };
    joy.onpointerdown = e => {
      joyPointer = e.pointerId;
      updateJoy(e.clientX);
      try { joy.setPointerCapture?.(e.pointerId); } catch {}
    };
    joy.onpointermove = e => { if (joyPointer === e.pointerId) updateJoy(e.clientX); };
    joy.onpointerup = e => { if (joyPointer === e.pointerId) stopJoy(); };
    joy.onpointercancel = e => { if (joyPointer === e.pointerId) stopJoy(); };

    const setArrow = (dir, down) => {
      const v = dir === 'left' ? -1 : 1;
      if (down) moveInput = v;
      else if (moveInput === v) moveInput = 0;
    };
    arena.querySelectorAll('[data-dir]').forEach(btn => {
      const dir = btn.dataset.dir;
      btn.onpointerdown = e => { e.preventDefault(); setArrow(dir, true); btn.classList.add('active'); };
      btn.onpointerup = () => { setArrow(dir, false); btn.classList.remove('active'); };
      btn.onpointercancel = () => { setArrow(dir, false); btn.classList.remove('active'); };
      btn.onpointerleave = e => {
        if (e.buttons === 0) {
          setArrow(dir, false);
          btn.classList.remove('active');
        }
      };
    });

    const rectFor = o => ({ l: o.x - o.w / 2, r: o.x + o.w / 2, t: o.y - o.h / 2, b: o.y + o.h / 2 });
    const overlaps = (a, b) => a.l < b.r && a.r > b.l && a.t < b.b && a.b > b.t;
    const removeItem = (arr, item) => {
      const i = arr.indexOf(item);
      if (i >= 0) arr.splice(i, 1);
      item.el?.remove();
    };
    const makeEl = (cls, html = '') => {
      const el = document.createElement('div');
      el.className = cls;
      el.innerHTML = html;
      field.appendChild(el);
      return el;
    };
    const updateEnemyLabel = enemy => {
      const tag = enemy.el?.querySelector('.hp');
      if (tag) tag.textContent = String(Math.max(0, enemy.hp));
    };
    const addSuper = amount => {
      superCharge = clamp(superCharge + amount, 0, 100);
      refreshHud();
    };
    const burstFx = (x, y, kind = enemyFaction, big = false) => {
      const wrap = makeEl(`blasterBurst ${kind} ${big ? 'big' : ''}`);
      wrap.style.left = `${x}px`;
      wrap.style.top = `${y}px`;
      const count = big ? 14 : 8;
      for (let i = 0; i < count; i += 1) {
        const particle = document.createElement('i');
        particle.style.setProperty('--a', `${Math.round((360 / count) * i + rand(-14, 14))}deg`);
        particle.style.setProperty('--d', `${Math.round(rand(big ? 42 : 24, big ? 86 : 54))}px`);
        wrap.appendChild(particle);
      }
      setTimeout(() => wrap.remove(), 430);
    };
    const baseEnemyHp = () => clamp(
      1 + Math.floor((level - 1) / 2) + (Math.random() < Math.min(0.14 + level * 0.035, 0.55) ? 1 : 0),
      1,
      10
    );
    const createStandardEnemy = (x, y = -30, path = 'drift', hpBoost = 0) => {
      const shape = Math.random() < 0.5 ? 'portal' : 'resonator';
      const hp = clamp(baseEnemyHp() + hpBoost, 1, 12);
      const symbol = shape === 'portal' ? '◉' : '⬢';
      const el = makeEl(`blasterEnemy ${enemyFaction} ${shape}`, `<span>${symbol}</span><b class="hp">${hp}</b>`);
      const enemy = {
        kind: 'enemy', x, baseX: x, y, w: 48, h: 48,
        vy: rand(56, 78) + Math.min(level, 10) * 2.2, sway: rand(12, 28), hp, el, shape,
        path, seed: Math.random() * 10
      };
      enemies.push(enemy);
      return enemy;
    };
    const createMachina = (x, y = -30) => {
      const hp = Math.max(2, baseEnemyHp() * 2);
      const el = makeEl('blasterEnemy machina', `<span>MX</span><b class="hp">${hp}</b>`);
      const enemy = {
        kind: 'machina', x, baseX: x, y, w: 44, h: 44,
        vy: rand(60, 84) + Math.min(level, 10) * 1.6, sway: rand(10, 22), hp, el,
        path: 'zigzag', seed: Math.random() * 10
      };
      enemies.push(enemy);
      return enemy;
    };
    const explodeAt = (x, y, radius = 92, canDamagePlayer = true) => {
      burstFx(x, y, 'machina', true);
      const boom = makeEl('blasterExplosion', '');
      boom.style.left = `${x}px`;
      boom.style.top = `${y}px`;
      setTimeout(() => boom.remove(), 300);
      for (const enemy of [...enemies]) {
        const dist = Math.hypot(enemy.x - x, enemy.y - y);
        if (dist < radius && !enemy._dead) {
          enemy.hp -= enemy.kind === 'boss' ? 3 : 2;
          updateEnemyLabel(enemy);
          if (enemy.hp <= 0) destroyEnemy(enemy, true);
        }
      }
      if (canDamagePlayer && invul <= 0) {
        const d = Math.hypot(player.x - x, player.y - y);
        if (d < radius * 0.72) damagePlayer();
      }
    };
    const spawnPickupAt = (x, y) => {
      const el = makeEl(`blasterPickup ${faction}`, '<span>+</span>');
      pickups.push({ x, y, w: 26, h: 26, vy: rand(52, 82), faction, good: true, el });
    };
    const spawnFormation = () => {
      if (ended || boss) return;
      formationIndex = (formationIndex + 1) % 3;
      const top = -34;
      if (formationIndex === 0) {
        const xs = [0.22, 0.5, 0.78];
        xs.forEach((ratio, i) => createStandardEnemy(width * ratio, top - i * 28, 'line'));
      } else if (formationIndex === 1) {
        const offsets = [-72, -36, 0, 36, 72];
        offsets.forEach((dx, i) => createStandardEnemy(clamp(width / 2 + dx, 32, width - 32), top - Math.abs(i - 2) * 26, 'wave'));
      } else {
        const count = Math.min(3 + Math.floor(level / 2), 6);
        for (let i = 0; i < count; i += 1) {
          createStandardEnemy(i % 2 ? width * 0.72 : width * 0.28, top - i * 42, 'zigzag');
        }
      }
    };
    const spawnEnemy = () => {
      if (ended || boss) return;
      const roll = Math.random();
      if (roll < 0.075) {
        spawnPickupAt(rand(30, width - 30), -10);
        return;
      }
      if (roll < 0.25) {
        createMachina(rand(34, width - 34));
        return;
      }
      if (roll > 0.82 && enemies.length < 8) {
        spawnFormation();
        return;
      }
      createStandardEnemy(rand(34, width - 34), -30, pick(['drift', 'wave', 'zigzag']));
    };
    const spawnBoss = () => {
      if (boss || ended) return;
      const hp = 28 + level * 8;
      const el = makeEl(`blasterEnemy boss ${enemyFaction}`, `<span>${esc(t.boss.toUpperCase())}</span><b class="hp">${hp}</b>`);
      boss = { kind: 'boss', x: width / 2, baseX: width / 2, y: 84, w: 154, h: 86, vx: 120, hp, maxHp: hp, el };
      enemies.push(boss);
      bossBar.className = `blasterBossBar ${enemyFaction}`;
      bossBar.hidden = false;
      bossShotCd = 0.85;
      burstFx(width / 2, 84, enemyFaction, true);
      successFx();
    };
    const fire = () => {
      const lanes = power >= 5 ? [-40, -20, 0, 20, 40] : power >= 4 ? [-18, 0, 18] : power >= 2 ? [-10, 10] : [0];
      for (const dx of lanes) {
        const el = makeEl(`blasterShot ${faction}`, '');
        bullets.push({ x: player.x + dx, y: player.y - 18, w: 7, h: 20, vy: 470 + power * 30, el, damage: 1 });
      }
      tone(faction === 'res' ? 500 : 580, 0.03, 0.018);
    };
    const fireSuper = () => {
      if (superCharge < 100 || ended) return;
      superCharge = 0;
      const beam = makeEl(`blasterSuperBeam ${faction}`, '');
      beam.style.left = `${player.x}px`;
      beam.style.top = `${Math.max(60, player.y / 2)}px`;
      setTimeout(() => beam.remove(), 360);
      tone(980, 0.18, 0.05);
      buzz([25, 20, 55]);
      for (const enemy of [...enemies]) {
        if (enemy._dead) continue;
        enemy.hp -= enemy.kind === 'boss' ? 8 : 6;
        updateEnemyLabel(enemy);
        burstFx(enemy.x, enemy.y, enemy.kind === 'machina' ? 'machina' : enemyFaction, false);
        if (enemy.hp <= 0) destroyEnemy(enemy, true);
      }
      score += 250;
      refreshHud();
    };
    superBtn.onclick = fireSuper;
    const enemyFire = () => {
      if (!boss) return;
      const spreads = level >= 6 ? [-56, -28, 0, 28, 56] : [-42, 0, 42];
      for (const dx of spreads) {
        const el = makeEl(`blasterEnemyShot ${enemyFaction}`, '');
        enemyShots.push({ x: boss.x + dx, y: boss.y + 18, w: 8, h: 18, vy: 230 + level * 8, el });
      }
      tone(240, 0.05, 0.02);
    };
    const levelUp = () => {
      level += 1;
      if (level % 2 === 0) power = Math.min(5, power + 1);
      score += 320;
      killsToAdvance = 10 + level * 2;
      burstFx(width / 2, 120, faction, true);
      successFx();
      refreshHud();
    };
    const destroyEnemy = (enemy, fromExplosion = false) => {
      if (!enemy || enemy._dead) return;
      enemy._dead = true;
      const x = enemy.x;
      const y = enemy.y;
      const kind = enemy.kind;
      removeItem(enemies, enemy);
      if (kind === 'boss') {
        score += 1800 * Math.max(1, combo);
        combo = Math.min(15, combo + 2);
        if (mode === 'arcade') clock?.add(5 + comboTimeBonus(combo));
        bossBar.hidden = true;
        boss = null;
        power = Math.min(5, power + 1);
        addSuper(35);
        burstFx(x, y, enemyFaction, true);
        levelUp();
        return;
      }
      if (kind === 'machina') {
        score += 230;
        addSuper(14);
        if (!fromExplosion) explodeAt(x, y, 92, false);
        else burstFx(x, y, 'machina', false);
      } else {
        score += 110 + level * 24;
        addSuper(9);
        burstFx(x, y, enemyFaction, false);
        if (!fromExplosion && Math.random() < 0.13) spawnPickupAt(x, y);
      }
      combo = Math.min(15, combo + 1);
      const timeBack = comboTimeBonus(combo) + (kind === 'machina' && combo >= 4 ? 1 : 0);
      if (timeBack) clock?.add(timeBack);
      kills += 1;
      if (!boss && kills >= killsToAdvance) {
        kills = 0;
        if (level % 3 === 0) spawnBoss();
        else levelUp();
      }
      refreshHud();
    };
    const damagePlayer = () => {
      if (invul > 0 || ended) return;
      combo = 1;
      invul = 1;
      superCharge = Math.max(0, superCharge - 20);
      clock?.penalize(3);
      if (mode !== 'training') lives -= 1;
      refreshHud();
      failFx();
      playerEl.classList.add('hurt');
      setTimeout(() => playerEl.classList.remove('hurt'), 420);
      if (mode !== 'training' && lives <= 0) finish();
    };
    const finish = () => {
      if (ended) return;
      ended = true;
      clock?.stop();
      cancelAnimationFrame(raf);
      bullets.forEach(x => x.el.remove());
      enemies.forEach(x => x.el.remove());
      pickups.forEach(x => x.el.remove());
      enemyShots.forEach(x => x.el.remove());
      bossBar.hidden = true;
      endPanel({ t, id: 'blaster', score, title: t.gameOver, detail: `${t.level} ${level}`, restart: () => gameBlaster(t), record: mode === 'arcade' });
    };

    clock = makeArcadeClock({ body, t, mode, seconds: 45, onExpire: finish });
    refreshHud();
    const loop = now => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      invul = Math.max(0, invul - dt);
      fireCd -= dt;
      spawnCd -= dt;
      bossShotCd -= dt;

      if (fireCd <= 0) {
        fireCd = Math.max(0.11, 0.4 - power * 0.045);
        fire();
      }
      if (!boss && spawnCd <= 0) {
        spawnCd = Math.max(0.42, 0.92 - Math.min(level, 10) * 0.035);
        spawnEnemy();
      }

      const desired = Math.abs(joyInput) > 0.02 ? joyInput : moveInput;
      const accel = desired ? 1160 : 800;
      const maxSpeed = 360;
      if (desired) player.vx = clamp(player.vx + desired * accel * dt, -maxSpeed, maxSpeed);
      else if (player.vx > 0) player.vx = Math.max(0, player.vx - accel * dt);
      else player.vx = Math.min(0, player.vx + accel * dt);
      player.x = clamp(player.x + player.vx * dt, 28, width - 28);
      playerEl.style.left = `${player.x}px`;
      playerEl.style.top = `${player.y}px`;
      playerEl.style.opacity = invul > 0 && Math.sin(now / 70) > 0 ? '0.4' : '1';

      if (boss) {
        boss.x += boss.vx * dt;
        if (boss.x < boss.w / 2 + 10 || boss.x > width - boss.w / 2 - 10) boss.vx *= -1;
        boss.el.style.left = `${boss.x}px`;
        boss.el.style.top = `${boss.y}px`;
        updateEnemyLabel(boss);
        if (bossShotCd <= 0) {
          bossShotCd = Math.max(0.46, 1.0 - level * 0.035);
          enemyFire();
        }
        bossBar.querySelector('i').style.width = `${Math.max(0, (boss.hp / boss.maxHp) * 100)}%`;
      }

      for (const bullet of [...bullets]) {
        bullet.y -= bullet.vy * dt;
        bullet.el.style.left = `${bullet.x}px`;
        bullet.el.style.top = `${bullet.y}px`;
        if (bullet.y < -30) {
          removeItem(bullets, bullet);
          continue;
        }
        const bRect = rectFor(bullet);
        for (const enemy of [...enemies]) {
          if (enemy._dead) continue;
          if (overlaps(bRect, rectFor(enemy))) {
            enemy.hp -= bullet.damage || 1;
            updateEnemyLabel(enemy);
            removeItem(bullets, bullet);
            if (enemy.hp <= 0) destroyEnemy(enemy);
            else tone(640, 0.018, 0.012);
            break;
          }
        }
      }

      for (const enemy of [...enemies]) {
        if (enemy.kind === 'boss') continue;
        enemy.y += enemy.vy * dt;
        const phase = now / 420 + (enemy.seed || 0);
        if (enemy.path === 'wave') enemy.x = clamp(enemy.baseX + Math.sin(phase) * enemy.sway, 28, width - 28);
        else if (enemy.path === 'zigzag') enemy.x = clamp(enemy.baseX + Math.sin(now / 220 + (enemy.seed || 0)) * enemy.sway * 2, 28, width - 28);
        else if (enemy.path === 'drift') enemy.x = clamp(enemy.baseX + Math.sin(phase) * enemy.sway * 0.55, 28, width - 28);
        enemy.el.style.left = `${enemy.x}px`;
        enemy.el.style.top = `${enemy.y}px`;
        updateEnemyLabel(enemy);
        if (enemy.y > height + 40) {
          removeItem(enemies, enemy);
          damagePlayer();
          continue;
        }
        if (overlaps(rectFor(enemy), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
          if (enemy.kind === 'machina') explodeAt(enemy.x, enemy.y, 92, true);
          else damagePlayer();
          removeItem(enemies, enemy);
        }
      }

      for (const shot of [...enemyShots]) {
        shot.y += shot.vy * dt;
        shot.el.style.left = `${shot.x}px`;
        shot.el.style.top = `${shot.y}px`;
        if (shot.y > height + 20) {
          removeItem(enemyShots, shot);
          continue;
        }
        if (overlaps(rectFor(shot), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
          removeItem(enemyShots, shot);
          damagePlayer();
        }
      }

      for (const p of [...pickups]) {
        p.y += p.vy * dt;
        p.el.style.left = `${p.x}px`;
        p.el.style.top = `${p.y}px`;
        if (p.y > height + 20) {
          removeItem(pickups, p);
          continue;
        }
        if (overlaps(rectFor(p), { l: player.x - player.w / 2, r: player.x + player.w / 2, t: player.y - player.h / 2, b: player.y + player.h / 2 })) {
          score += 160;
          power = Math.min(5, power + (Math.random() < 0.55 ? 1 : 0));
          addSuper(28);
          burstFx(p.x, p.y, faction, false);
          successFx();
          removeItem(pickups, p);
        }
      }

      refreshHud();
      if (!ended) raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    cleanupGame = () => {
      ended = true;
      clock?.stop();
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  });
}

function gameMemory(t) {
  showBriefing({
    t,
    title: t.memoryTitle,
    img: '/arcade/redacted.png',
    accent: 'green',
    speakers: [
      { name: 'MILO', img: '/assets/milo.jpg', text: t.memorySpeak1, accent: 'green' },
      { name: 'RITA', img: '/arcade/rita.png', text: t.memorySpeak2, accent: 'cyan' }
    ],
    tutorial: [...t.memoryTutorial, t.comboTimeHint],
    onStart: (faction, mode) => startMemory(t, faction, mode)
  });
}

function startMemory(t, faction = 'enl', mode = 'arcade') {
  const body = setScreen(gameFrame({
    title: `${t.memoryTitle} · ${factionNames(t, faction)} · ${arcadeModeLabel(t, mode)}`,
    help: t.memoryHelp,
    img: '/arcade/redacted.png',
    t,
    extra: hud(t, [
      [t.moves, { key: 'moves', value: '0' }],
      [t.combo, { key: 'combo', value: '×1' }],
      [t.time, { key: 'time', value: mode === 'training' ? '∞' : '45' }],
      [t.faction, { key: 'faction', value: factionNames(t, faction) }]
    ])
  }));
  btnEvents(body);
  const arena = body.querySelector('.labGameArena');
  arena.classList.add(`team-${faction}`);
  countdown(arena, t, () => {
    const pairs = [
      ['IGOR', 'IGOR', '/arcade/igor.png'],
      ['MILO', 'MILO', '/assets/milo.jpg'],
      ['RITA', 'RITA', '/arcade/rita.png'],
      ['REDACTED', 'REDACTED', '/arcade/redacted.png'],
      ['PORTAL', t.memoryPortal, '']
    ];
    const normalCards = [...pairs, ...pairs].map((p, i) => ({ id: i, key: p[0], label: p[1], img: p[2], hazard: false }));
    const hazards = [0, 1].map((_, i) => ({ id: normalCards.length + i, key: `MACHINA_${i}`, label: t.machina, img: '', hazard: true }));
    const deck = [...normalCards, ...hazards].sort(() => Math.random() - 0.5);
    const targetMatched = normalCards.length;
    let open = [];
    let matched = 0;
    let moves = 0;
    let combo = 1;
    let lock = false;
    let ended = false;
    let clock = null;
    arena.innerHTML = `<div class="memoryGrid team-${faction}">${deck.map((c, i) => `<button data-card="${i}" class="${c.hazard ? 'machinaCard' : ''}"><span class="memoryBack">${faction === 'res' ? 'RES' : 'ENL'}</span><span class="memoryFront">${c.img ? `<img src="${c.img}" alt=""><b>${c.label}</b>` : `<em>${c.hazard ? 'MX' : '◉'}</em><b>${c.label}</b>`}</span></button>`).join('')}</div>`;
    const movesEl = body.querySelector('[data-hud="moves"]');
    const comboEl = body.querySelector('[data-hud="combo"]');
    const cards = [...arena.querySelectorAll('[data-card]')];
    const finishTimeout = () => {
      if (ended) return;
      ended = true;
      lock = true;
      cards.forEach(c => (c.disabled = true));
      clock?.stop();
      endPanel({ t, id: 'memory', score: moves, title: t.gameOver, detail: `${matched / 2}/${targetMatched / 2}`, restart: () => gameMemory(t), record: false });
    };
    clock = makeArcadeClock({ body, t, mode, seconds: 45, onExpire: finishTimeout });
    cards.forEach(btn => {
      btn.onclick = () => {
        if (ended || lock || btn.classList.contains('matched') || btn.classList.contains('open')) return;
        const idx = Number(btn.dataset.card);
        const chosen = deck[idx];
        btn.classList.add('open');
        open.push({ idx, btn, card: chosen });
        tone(chosen.hazard ? 210 : (faction === 'res' ? 430 : 520), 0.035, 0.02);
        if (chosen.hazard) {
          open = open.filter(x => x.btn !== btn);
          combo = 1;
          comboEl.textContent = '×1';
          btn.classList.add('dangerOpen');
          clock?.penalize(3);
          failFx();
          const timeEl = body.querySelector('[data-hud="time"]');
          if (timeEl) timeEl.classList.add('dangerTick');
          setTimeout(() => {
            btn.classList.remove('open', 'dangerOpen');
            timeEl?.classList.remove('dangerTick');
          }, 420);
          return;
        }
        if (open.length < 2) return;
        moves += 1;
        movesEl.textContent = moves;
        lock = true;
        if (open[0].card.key === open[1].card.key) {
          open.forEach(x => x.btn.classList.add('matched'));
          matched += 2;
          open = [];
          lock = false;
          combo = Math.min(12, combo + 1);
          comboEl.textContent = `×${combo}`;
          const bonus = comboTimeBonus(combo);
          if (bonus) clock.add(bonus);
          successFx();
          if (matched === targetMatched) {
            ended = true;
            clock.stop();
            endPanel({ t, id: 'memory', score: moves, lowerBetter: true, title: t.cleared, detail: `${arcadeModeLabel(t, mode)} · ${factionNames(t, faction)}`, restart: () => gameMemory(t), record: mode === 'arcade' });
          }
        } else {
          combo = 1;
          comboEl.textContent = '×1';
          failFx();
          setTimeout(() => {
            open.forEach(x => x.btn.classList.remove('open', 'dangerOpen'));
            open = [];
            lock = false;
          }, 700);
        }
      };
    });
    cleanupGame = () => {
      ended = true;
      clock?.stop();
    };
  });
}
