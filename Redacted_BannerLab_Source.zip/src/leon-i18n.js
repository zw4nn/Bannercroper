export const LEON_TEXT_OVERRIDES = {
  "es": {
    "title": "LEON",
    "sub": "Leveling & Exact Operations Navigator",
    "job": "Empleado del Lab · Contable patológico de AP",
    "intro": "Dame tus AP. Yo te doy el camino. Y cuando diga exacto, deja de tocar el Scanner.",
    "current": "AP actuales",
    "target": "Objetivo",
    "custom": "AP personalizados",
    "sourceInput": "Tus AP o estadísticas de Ingress",
    "sourceHint": "Escribe tu cantidad de AP o pega directamente el texto «Compartir estadísticas» del Scanner. LEON detecta automáticamente lo que le das.",
    "parsed": "Estadísticas reconocidas",
    "apDetected": "AP detectados",
    "parseFail": "LEON no puede reconocer estos datos. Introduce una cantidad de AP o pega el texto completo compartido por el Scanner.",
    "exact": "🎯 EXACTO",
    "actions": "Acciones disponibles",
    "network": "Eventos y bonificaciones de AP",
    "checking": "LEON está consultando el calendario oficial de Ingress…",
    "refresh": "Actualizar",
    "official": "Calendario oficial de Ingress",
    "offline": "No se ha podido comprobar en línea. Se muestran datos de respaldo.",
    "sourceOfficial": "🟢 Datos oficiales en línea",
    "sourceFallback": "🟠 Datos de respaldo",
    "noBonus": "No se detecta ningún multiplicador global de AP en este momento.",
    "eventBonus": "Bonificación de evento detectada",
    "manualFactor": "Bonificación de evento",
    "apex": "Apex activo",
    "apexNormal": "×2",
    "totalFactor": "Multiplicador total",
    "calculate": "CALCULAR PLAN EXACTO",
    "remaining": "AP por ganar",
    "plan": "PLAN DE LEON",
    "base": "AP base",
    "withBonus": "con bonificación",
    "result": "Resultado",
    "exactHit": "OBJETIVO EXACTO",
    "dontTouch": "NO TOQUES NADA MÁS.",
    "impossible": "OBJETIVO EXACTO IMPOSIBLE CON ESTE MULTIPLICADOR",
    "impossibleText": "Los AP restantes no son divisibles por el multiplicador actual. LEON puede dejarte justo por debajo y terminar cuando cambie la bonificación.",
    "already": "Objetivo ya alcanzado. LEON se niega a fabricar AP negativos.",
    "invalid": "Introduce AP actuales y un objetivo válidos.",
    "recharge": "Ajuste mediante recarga",
    "rechargeDetail": "AP mediante recarga (unos {xm} XM si falta suficiente carga)",
    "medals": "Requisito de medallas",
    "medalWarn": "Las estadísticas compartidas no incluyen todas las medallas. A partir de L9, comprueba también este requisito en el Scanner.",
    "eventFixed": "Las posibles recompensas fijas de AP de campaña no se incluyen hasta que se reclamen.",
    "live": "EN CURSO",
    "upcoming": "PRÓXIMAMENTE",
    "sourceTime": "Comprobado",
    "close": "Cerrar",
    "reset": "Restablecer",
    "apPerAction": "AP",
    "selectedCount": "{n} acciones activadas",
    "actionsHint": "LEON solo tiene un modo: EXACTO. Primero exige un resultado exactamente igual al objetivo y, entre las soluciones exactas, prioriza el plan estimado más rápido con las acciones marcadas. Las acciones pequeñas y la recarga solo sirven para el ajuste final.",
    "closest": "Plan más cercano",
    "missing": "restante",
    "noPlan": "No he encontrado una combinación práctica con las acciones activadas. Activa la recarga o más acciones.",
    "rechargeToggle": "Permitir recarga para el ajuste final",
    "rechargeMax": "Ajuste máximo por recarga",
    "exactNote": "Los paquetes «field» incluyen el Link que los crea. «Captura completa» incluye captura + 8 Resonators + bonificación del 8.º Resonator, para evitar contar dos veces.",
    "eventAuto": "AUTO",
    "eventManual": "manual",
    "statsCurrent": "AP actuales",
    "level": "Nivel",
    "agent": "Agente",
    "timeOptimized": "optimizado por tiempo",
    "pasteStats": "o pega aquí «Compartir estadísticas»",
    "fallbackEventNote": "Evento activo; no se ha anunciado ningún multiplicador global de AP."
  },
  "pt": {
    "title": "LEON",
    "sub": "Leveling & Exact Operations Navigator",
    "job": "Funcionário do Lab · Contabilista patológico de AP",
    "intro": "Dá-me os teus AP. Eu dou-te o caminho. E quando disser exato, deixa de mexer no Scanner.",
    "current": "AP atuais",
    "target": "Objetivo",
    "custom": "AP personalizado",
    "sourceInput": "Os teus AP ou estatísticas Ingress",
    "sourceHint": "Escreve simplesmente o teu número de AP ou cola diretamente o texto «Partilhar estatísticas» do Scanner. O LEON deteta automaticamente o que lhe deste.",
    "parsed": "Estatísticas reconhecidas",
    "apDetected": "AP detetados",
    "parseFail": "O LEON não consegue reconhecer estes dados. Introduz um número de AP ou cola o texto completo partilhado pelo Scanner.",
    "exact": "🎯 EXATO",
    "actions": "Ações disponíveis",
    "network": "Eventos e bónus de AP",
    "checking": "O LEON está a verificar o calendário oficial do Ingress…",
    "refresh": "Atualizar",
    "official": "Calendário oficial do Ingress",
    "offline": "Não foi possível verificar online. São apresentados dados de contingência.",
    "sourceOfficial": "🟢 Dados oficiais online",
    "sourceFallback": "🟠 Dados de contingência",
    "noBonus": "Nenhum multiplicador global de AP detetado neste momento.",
    "eventBonus": "Bónus de evento detetado",
    "manualFactor": "Bónus de evento",
    "apex": "Apex ativo",
    "apexNormal": "×2",
    "totalFactor": "Multiplicador total",
    "calculate": "CALCULAR PLANO EXATO",
    "remaining": "AP a ganhar",
    "plan": "PLANO DO LEON",
    "base": "AP base",
    "withBonus": "com bónus",
    "result": "Resultado",
    "exactHit": "OBJETIVO EXATO",
    "dontTouch": "NÃO MEXAS EM MAIS NADA.",
    "impossible": "OBJETIVO EXATO IMPOSSÍVEL COM ESTE MULTIPLICADOR",
    "impossibleText": "Os AP restantes não são divisíveis pelo multiplicador atual. O LEON pode deixar-te imediatamente abaixo e terminar quando o bónus mudar.",
    "already": "Objetivo já atingido. O LEON recusa-se a fabricar AP negativos.",
    "invalid": "Introduz AP atuais e um objetivo válidos.",
    "recharge": "Ajuste por recarga",
    "rechargeDetail": "AP por recarga (cerca de {xm} XM se faltar carga suficiente)",
    "medals": "Requisito de medalhas",
    "medalWarn": "As estatísticas partilhadas não incluem todas as medalhas. A partir do L9, verifica também este requisito no Scanner.",
    "eventFixed": "Possíveis recompensas fixas de AP de campanha não são incluídas até serem reclamadas.",
    "live": "EM CURSO",
    "upcoming": "EM BREVE",
    "sourceTime": "Verificado",
    "close": "Fechar",
    "reset": "Repor",
    "apPerAction": "AP",
    "selectedCount": "{n} ações ativadas",
    "actionsHint": "O LEON só tem um modo: EXATO. Primeiro exige um resultado exatamente igual ao objetivo e, entre as soluções exatas, privilegia o plano estimado mais rápido com as ações marcadas. As pequenas ações e a recarga servem apenas para o ajuste final.",
    "closest": "Plano mais próximo",
    "missing": "restante",
    "noPlan": "Não encontrei uma combinação prática com as ações ativadas. Ativa a recarga ou mais ações.",
    "rechargeToggle": "Permitir recarga para o ajuste final",
    "rechargeMax": "Ajuste máximo por recarga",
    "exactNote": "Os conjuntos «field» incluem o Link que os cria. «Captura completa» inclui captura + 8 Resonators + bónus do 8.º Resonator, evitando contar duas vezes.",
    "eventAuto": "AUTO",
    "eventManual": "manual",
    "statsCurrent": "AP atuais",
    "level": "Nível",
    "agent": "Agente",
    "timeOptimized": "otimizado por tempo",
    "pasteStats": "ou cola aqui «Partilhar estatísticas»",
    "fallbackEventNote": "Evento ativo; não foi anunciado nenhum multiplicador global de AP."
  },
  "de": {
    "title": "LEON",
    "sub": "Leveling & Exact Operations Navigator",
    "job": "Lab-Mitarbeiter · Pathologischer AP-Buchhalter",
    "intro": "Gib mir deine AP. Ich gebe dir den Weg. Und wenn ich exakt sage, hör auf, den Scanner anzufassen.",
    "current": "Aktuelle AP",
    "target": "Ziel",
    "custom": "Benutzerdefinierte AP",
    "sourceInput": "Deine AP oder Ingress-Statistiken",
    "sourceHint": "Gib einfach deine AP-Zahl ein oder füge den Text „Statistiken teilen“ aus dem Scanner ein. LEON erkennt automatisch, was du ihm gibst.",
    "parsed": "Statistiken erkannt",
    "apDetected": "AP erkannt",
    "parseFail": "LEON kann diese Daten nicht erkennen. Gib eine AP-Zahl ein oder füge den vollständigen Scanner-Text ein.",
    "exact": "🎯 EXAKT",
    "actions": "Verfügbare Aktionen",
    "network": "Events & AP-Boni",
    "checking": "LEON prüft den offiziellen Ingress-Kalender…",
    "refresh": "Aktualisieren",
    "official": "Offizieller Ingress-Kalender",
    "offline": "Online-Prüfung fehlgeschlagen. Ersatzdaten werden angezeigt.",
    "sourceOfficial": "🟢 Offizielle Online-Daten",
    "sourceFallback": "🟠 Ersatzdaten",
    "noBonus": "Derzeit kein globaler AP-Multiplikator erkannt.",
    "eventBonus": "Event-Bonus erkannt",
    "manualFactor": "Event-Bonus",
    "apex": "Apex aktiv",
    "apexNormal": "×2",
    "totalFactor": "Gesamtmultiplikator",
    "calculate": "EXAKTEN PLAN BERECHNEN",
    "remaining": "Noch benötigte AP",
    "plan": "LEONS PLAN",
    "base": "Basis-AP",
    "withBonus": "mit Bonus",
    "result": "Ergebnis",
    "exactHit": "EXAKTES ZIEL",
    "dontTouch": "NICHTS MEHR ANFASSEN.",
    "impossible": "EXAKTES ZIEL MIT DIESEM MULTIPLIKATOR NICHT MÖGLICH",
    "impossibleText": "Die verbleibenden AP sind nicht durch den aktuellen AP-Multiplikator teilbar. LEON kann dich knapp darunter bringen und abschließen, wenn sich der Bonus ändert.",
    "already": "Ziel bereits erreicht. LEON weigert sich, negative AP herzustellen.",
    "invalid": "Gib gültige aktuelle AP und ein gültiges Ziel ein.",
    "recharge": "Anpassung durch Aufladen",
    "rechargeDetail": "AP durch Aufladen (etwa {xm} XM, wenn genügend Ladung fehlt)",
    "medals": "Medaillenanforderung",
    "medalWarn": "Geteilte Statistiken enthalten nicht alle Medaillen. Ab L9 musst du diese Anforderung zusätzlich im Scanner prüfen.",
    "eventFixed": "Mögliche feste AP-Kampagnenbelohnungen werden erst nach dem Einlösen eingerechnet.",
    "live": "AKTIV",
    "upcoming": "BEVORSTEHEND",
    "sourceTime": "Geprüft",
    "close": "Schließen",
    "reset": "Zurücksetzen",
    "apPerAction": "AP",
    "selectedCount": "{n} Aktionen aktiviert",
    "actionsHint": "LEON kennt nur einen Modus: EXAKT. Zuerst verlangt er ein Ergebnis genau auf dem Ziel und wählt unter den exakten Lösungen den geschätzt schnellsten Plan mit den aktivierten Aktionen. Kleine Aktionen und Aufladen dienen nur der Feinabstimmung.",
    "closest": "Nächstliegender Plan",
    "missing": "verbleibend",
    "noPlan": "Keine praktische Kombination mit den aktivierten Aktionen gefunden. Aktiviere Aufladen oder weitere Aktionen.",
    "rechargeToggle": "Aufladen für die letzte Anpassung erlauben",
    "rechargeMax": "Maximale Auflade-Anpassung",
    "exactNote": "Field-Pakete enthalten den Link, der sie erzeugt. „Vollständige Eroberung“ enthält Eroberung + 8 Resonatoren + Bonus des 8. Resonators, damit nichts doppelt gezählt wird.",
    "eventAuto": "AUTO",
    "eventManual": "manuell",
    "statsCurrent": "Aktuelle AP",
    "level": "Level",
    "agent": "Agent",
    "timeOptimized": "zeitoptimiert",
    "pasteStats": "oder hier „Statistiken teilen“ einfügen",
    "fallbackEventNote": "Aktives Event; kein globaler AP-Multiplikator angekündigt."
  },
  "it": {
    "title": "LEON",
    "sub": "Leveling & Exact Operations Navigator",
    "job": "Dipendente del Lab · Contabile patologico degli AP",
    "intro": "Dammi i tuoi AP. Io ti do la strada. E quando dico esatto, smetti di toccare lo Scanner.",
    "current": "AP attuali",
    "target": "Obiettivo",
    "custom": "AP personalizzati",
    "sourceInput": "I tuoi AP o le statistiche Ingress",
    "sourceHint": "Digita semplicemente il tuo numero di AP oppure incolla il testo «Condividi statistiche» dello Scanner. LEON riconosce automaticamente ciò che gli dai.",
    "parsed": "Statistiche riconosciute",
    "apDetected": "AP rilevati",
    "parseFail": "LEON non riesce a riconoscere questi dati. Inserisci un numero di AP oppure incolla il testo completo condiviso dallo Scanner.",
    "exact": "🎯 ESATTO",
    "actions": "Azioni disponibili",
    "network": "Eventi e bonus AP",
    "checking": "LEON sta controllando il calendario ufficiale di Ingress…",
    "refresh": "Aggiorna",
    "official": "Calendario ufficiale Ingress",
    "offline": "Controllo online non riuscito. Visualizzo i dati di riserva.",
    "sourceOfficial": "🟢 Dati ufficiali online",
    "sourceFallback": "🟠 Dati di riserva",
    "noBonus": "Nessun moltiplicatore AP globale rilevato al momento.",
    "eventBonus": "Bonus evento rilevato",
    "manualFactor": "Bonus evento",
    "apex": "Apex attivo",
    "apexNormal": "×2",
    "totalFactor": "Moltiplicatore totale",
    "calculate": "CALCOLA PIANO ESATTO",
    "remaining": "AP da guadagnare",
    "plan": "PIANO DI LEON",
    "base": "AP base",
    "withBonus": "con bonus",
    "result": "Risultato",
    "exactHit": "OBIETTIVO ESATTO",
    "dontTouch": "NON TOCCARE PIÙ NIENTE.",
    "impossible": "OBIETTIVO ESATTO IMPOSSIBILE CON QUESTO MOLTIPLICATORE",
    "impossibleText": "Gli AP rimanenti non sono divisibili per il moltiplicatore AP attuale. LEON può portarti appena sotto e completare quando il bonus cambia.",
    "already": "Obiettivo già raggiunto. LEON si rifiuta di fabbricare AP negativi.",
    "invalid": "Inserisci AP attuali e obiettivo validi.",
    "recharge": "Regolazione tramite ricarica",
    "rechargeDetail": "AP tramite ricarica (circa {xm} XM se manca abbastanza carica)",
    "medals": "Requisito medaglie",
    "medalWarn": "Le statistiche condivise non includono tutte le medaglie. Dal L9 in poi verifica questo requisito anche nello Scanner.",
    "eventFixed": "Le eventuali ricompense AP fisse delle campagne non vengono incluse finché non vengono riscosse.",
    "live": "IN CORSO",
    "upcoming": "IN ARRIVO",
    "sourceTime": "Verificato",
    "close": "Chiudi",
    "reset": "Reimposta",
    "apPerAction": "AP",
    "selectedCount": "{n} azioni attivate",
    "actionsHint": "LEON ha un solo modo: ESATTO. Prima richiede un risultato esattamente uguale all'obiettivo e, tra le soluzioni esatte, privilegia il piano stimato più rapido con le azioni selezionate. Le piccole azioni e la ricarica servono solo per la rifinitura finale.",
    "closest": "Piano più vicino",
    "missing": "rimanenti",
    "noPlan": "Non ho trovato una combinazione pratica con le azioni attivate. Abilita la ricarica o altre azioni.",
    "rechargeToggle": "Consenti ricarica per la regolazione finale",
    "rechargeMax": "Regolazione massima tramite ricarica",
    "exactNote": "I pacchetti «field» includono il Link che li crea. «Cattura completa» include cattura + 8 Resonator + bonus dell'8° Resonator, evitando il doppio conteggio.",
    "eventAuto": "AUTO",
    "eventManual": "manuale",
    "statsCurrent": "AP attuali",
    "level": "Livello",
    "agent": "Agente",
    "timeOptimized": "ottimizzato per tempo",
    "pasteStats": "oppure incolla qui «Condividi statistiche»",
    "fallbackEventNote": "Evento attivo; nessun moltiplicatore AP globale annunciato."
  },
  "nl": {
    "title": "LEON",
    "sub": "Leveling & Exact Operations Navigator",
    "job": "Lab-medewerker · Pathologische AP-boekhouder",
    "intro": "Geef me je AP. Ik geef je de route. En als ik exact zeg, blijf dan van de Scanner af.",
    "current": "Huidige AP",
    "target": "Doel",
    "custom": "Aangepaste AP",
    "sourceInput": "Je AP of Ingress-statistieken",
    "sourceHint": "Typ gewoon je AP-aantal of plak de tekst ‘Statistieken delen’ uit de Scanner. LEON herkent automatisch wat je hem geeft.",
    "parsed": "Statistieken herkend",
    "apDetected": "AP gedetecteerd",
    "parseFail": "LEON kan deze gegevens niet herkennen. Voer een AP-aantal in of plak de volledige gedeelde Scanner-tekst.",
    "exact": "🎯 EXACT",
    "actions": "Beschikbare acties",
    "network": "Evenementen & AP-bonussen",
    "checking": "LEON controleert de officiële Ingress-kalender…",
    "refresh": "Vernieuwen",
    "official": "Officiële Ingress-kalender",
    "offline": "Online controle mislukt. Reservegegevens worden weergegeven.",
    "sourceOfficial": "🟢 Officiële online gegevens",
    "sourceFallback": "🟠 Reservegegevens",
    "noBonus": "Momenteel geen globale AP-vermenigvuldiger gedetecteerd.",
    "eventBonus": "Evenementbonus gedetecteerd",
    "manualFactor": "Evenementbonus",
    "apex": "Apex actief",
    "apexNormal": "×2",
    "totalFactor": "Totale vermenigvuldiger",
    "calculate": "EXACT PLAN BEREKENEN",
    "remaining": "Nog te verdienen AP",
    "plan": "LEONS PLAN",
    "base": "basis-AP",
    "withBonus": "met bonus",
    "result": "Resultaat",
    "exactHit": "EXACT DOEL",
    "dontTouch": "BLIJF NU OVERAL VAN AF.",
    "impossible": "EXACT DOEL ONMOGELIJK MET DEZE VERMENIGVULDIGER",
    "impossibleText": "De resterende AP is niet deelbaar door de huidige AP-vermenigvuldiger. LEON kan je net eronder brengen en afronden wanneer de bonus verandert.",
    "already": "Doel al bereikt. LEON weigert negatieve AP te fabriceren.",
    "invalid": "Voer geldige huidige AP en een geldig doel in.",
    "recharge": "Aanpassing via opladen",
    "rechargeDetail": "AP via opladen (ongeveer {xm} XM als er voldoende lading ontbreekt)",
    "medals": "Medailevereiste",
    "medalWarn": "Gedeelde statistieken bevatten niet elke medaille. Controleer vanaf L9 deze vereiste ook in de Scanner.",
    "eventFixed": "Mogelijke vaste AP-beloningen van campagnes worden pas meegerekend nadat ze zijn geclaimd.",
    "live": "ACTIEF",
    "upcoming": "BINNENKORT",
    "sourceTime": "Gecontroleerd",
    "close": "Sluiten",
    "reset": "Resetten",
    "apPerAction": "AP",
    "selectedCount": "{n} acties actief",
    "actionsHint": "LEON heeft maar één modus: EXACT. Eerst eist hij een resultaat precies gelijk aan het doel en tussen de exacte oplossingen kiest hij het naar schatting snelste plan met de aangevinkte acties. Kleine acties en opladen worden alleen gebruikt voor de laatste afwerking.",
    "closest": "Dichtstbijzijnde plan",
    "missing": "resterend",
    "noPlan": "Geen praktische combinatie gevonden met de ingeschakelde acties. Schakel opladen of meer acties in.",
    "rechargeToggle": "Opladen toestaan voor de laatste aanpassing",
    "rechargeMax": "Maximale aanpassing via opladen",
    "exactNote": "Field-bundels bevatten de Link die ze maakt. ‘Volledige capture’ bevat capture + 8 Resonators + bonus van de 8e Resonator, zodat niets dubbel wordt geteld.",
    "eventAuto": "AUTO",
    "eventManual": "handmatig",
    "statsCurrent": "Huidige AP",
    "level": "Level",
    "agent": "Agent",
    "timeOptimized": "tijdgeoptimaliseerd",
    "pasteStats": "of plak hier ‘Statistieken delen’",
    "fallbackEventNote": "Actief evenement; geen globale AP-vermenigvuldiger aangekondigd."
  }
};

export const LEON_ACTION_TRANSLATIONS = {
  "fullCapture": {
    "es": {
      "label": "Capturar y desplegar por completo un Portal neutral",
      "short": "Portal(es) capturado(s) y desplegado(s) por completo"
    },
    "pt": {
      "label": "Capturar e implementar totalmente um Portal neutro",
      "short": "Portal(is) capturado(s) e totalmente implementado(s)"
    },
    "de": {
      "label": "Neutrales Portal erobern und vollständig bestücken",
      "short": "Portal(e) erobert und vollständig bestückt"
    },
    "it": {
      "label": "Cattura e dispiega completamente un Portal neutrale",
      "short": "Portal catturati e completamente dispiegati"
    },
    "nl": {
      "label": "Een neutrale Portal capturen en volledig deployen",
      "short": "Portal(s) gecaptured en volledig gedeployed"
    }
  },
  "capture": {
    "es": {
      "label": "Capturar un Portal neutral (captura + primer Resonator)",
      "short": "Portal(es) neutral(es) capturado(s)"
    },
    "pt": {
      "label": "Capturar um Portal neutro (captura + primeiro Resonator)",
      "short": "Portal(is) neutro(s) capturado(s)"
    },
    "de": {
      "label": "Neutrales Portal erobern (Eroberung + erster Resonator)",
      "short": "neutrale Portal(e) erobert"
    },
    "it": {
      "label": "Cattura un Portal neutrale (cattura + primo Resonator)",
      "short": "Portal neutrali catturati"
    },
    "nl": {
      "label": "Een neutrale Portal capturen (capture + eerste Resonator)",
      "short": "neutrale Portal(s) gecaptured"
    }
  },
  "resonator": {
    "es": {
      "label": "Desplegar un Resonator",
      "short": "Resonator(es) desplegado(s)"
    },
    "pt": {
      "label": "Implementar um Resonator",
      "short": "Resonator(es) implementado(s)"
    },
    "de": {
      "label": "Resonator setzen",
      "short": "Resonator(en) gesetzt"
    },
    "it": {
      "label": "Dispiegare un Resonator",
      "short": "Resonator dispiegati"
    },
    "nl": {
      "label": "Een Resonator deployen",
      "short": "Resonator(s) gedeployed"
    }
  },
  "mod": {
    "es": {
      "label": "Instalar un Portal Mod",
      "short": "Portal Mod(s) instalado(s)"
    },
    "pt": {
      "label": "Instalar um Portal Mod",
      "short": "Portal Mod(s) instalado(s)"
    },
    "de": {
      "label": "Portal-Mod installieren",
      "short": "Portal-Mod(s) installiert"
    },
    "it": {
      "label": "Installare un Portal Mod",
      "short": "Portal Mod installati"
    },
    "nl": {
      "label": "Een Portal Mod plaatsen",
      "short": "Portal Mod(s) geplaatst"
    }
  },
  "link": {
    "es": {
      "label": "Crear un Link simple",
      "short": "Link(s) simple(s) creado(s)"
    },
    "pt": {
      "label": "Criar um Link simples",
      "short": "Link(s) simples criado(s)"
    },
    "de": {
      "label": "Einfachen Link erstellen",
      "short": "einfache Link(s) erstellt"
    },
    "it": {
      "label": "Creare un Link semplice",
      "short": "Link semplici creati"
    },
    "nl": {
      "label": "Een eenvoudige Link maken",
      "short": "eenvoudige Link(s) gemaakt"
    }
  },
  "field": {
    "es": {
      "label": "Crear un Link que cierre 1 Field (313 + 1.250)",
      "short": "Link(s) que cierran 1 Field"
    },
    "pt": {
      "label": "Criar um Link que feche 1 Field (313 + 1 250)",
      "short": "Link(s) que fecham 1 Field"
    },
    "de": {
      "label": "Link erstellen, der 1 Field schließt (313 + 1.250)",
      "short": "Link(s), die 1 Field schließen"
    },
    "it": {
      "label": "Creare un Link che chiude 1 Field (313 + 1.250)",
      "short": "Link che chiudono 1 Field"
    },
    "nl": {
      "label": "Een Link maken die 1 Field sluit (313 + 1.250)",
      "short": "Link(s) die 1 Field sluiten"
    }
  },
  "doubleField": {
    "es": {
      "label": "Crear un Link que cierre 2 Fields (313 + 2 × 1.250)",
      "short": "Link(s) que cierran 2 Fields"
    },
    "pt": {
      "label": "Criar um Link que feche 2 Fields (313 + 2 × 1 250)",
      "short": "Link(s) que fecham 2 Fields"
    },
    "de": {
      "label": "Link erstellen, der 2 Fields schließt (313 + 2 × 1.250)",
      "short": "Link(s), die 2 Fields schließen"
    },
    "it": {
      "label": "Creare un Link che chiude 2 Fields (313 + 2 × 1.250)",
      "short": "Link che chiudono 2 Fields"
    },
    "nl": {
      "label": "Een Link maken die 2 Fields sluit (313 + 2 × 1.250)",
      "short": "Link(s) die 2 Fields sluiten"
    }
  },
  "upgrade": {
    "es": {
      "label": "Mejorar el Resonator de otro Agente",
      "short": "Resonator(es) aliado(s) mejorado(s)"
    },
    "pt": {
      "label": "Melhorar o Resonator de outro Agente",
      "short": "Resonator(es) aliado(s) melhorado(s)"
    },
    "de": {
      "label": "Resonator eines anderen Agenten upgraden",
      "short": "verbündete Resonator(en) upgegradet"
    },
    "it": {
      "label": "Potenziare il Resonator di un altro Agente",
      "short": "Resonator alleati potenziati"
    },
    "nl": {
      "label": "De Resonator van een andere Agent upgraden",
      "short": "bevriende Resonator(s) geüpgraded"
    }
  },
  "hackFriendly": {
    "es": {
      "label": "Hackear un Portal aliado",
      "short": "hack(s) aliado(s)"
    },
    "pt": {
      "label": "Hackear um Portal aliado",
      "short": "hack(s) aliado(s)"
    },
    "de": {
      "label": "Verbündetes Portal hacken",
      "short": "verbündete Hack(s)"
    },
    "it": {
      "label": "Hackerare un Portal alleato",
      "short": "hack alleati"
    },
    "nl": {
      "label": "Een bevriende Portal hacken",
      "short": "bevriende hack(s)"
    }
  },
  "hackEnemy": {
    "es": {
      "label": "Hackear un Portal enemigo",
      "short": "hack(s) enemigo(s)"
    },
    "pt": {
      "label": "Hackear um Portal inimigo",
      "short": "hack(s) inimigo(s)"
    },
    "de": {
      "label": "Feindliches Portal hacken",
      "short": "feindliche Hack(s)"
    },
    "it": {
      "label": "Hackerare un Portal nemico",
      "short": "hack nemici"
    },
    "nl": {
      "label": "Een vijandige Portal hacken",
      "short": "vijandige hack(s)"
    }
  },
  "destroyRes": {
    "es": {
      "label": "Destruir un Resonator enemigo",
      "short": "Resonator(es) enemigo(s) destruido(s)"
    },
    "pt": {
      "label": "Destruir um Resonator inimigo",
      "short": "Resonator(es) inimigo(s) destruído(s)"
    },
    "de": {
      "label": "Feindlichen Resonator zerstören",
      "short": "feindliche Resonator(en) zerstört"
    },
    "it": {
      "label": "Distruggere un Resonator nemico",
      "short": "Resonator nemici distrutti"
    },
    "nl": {
      "label": "Een vijandige Resonator vernietigen",
      "short": "vijandige Resonator(s) vernietigd"
    }
  },
  "destroyMod": {
    "es": {
      "label": "Destruir un Portal Mod enemigo",
      "short": "Portal Mod(s) enemigo(s) destruido(s)"
    },
    "pt": {
      "label": "Destruir um Portal Mod inimigo",
      "short": "Portal Mod(s) inimigo(s) destruído(s)"
    },
    "de": {
      "label": "Feindlichen Portal-Mod zerstören",
      "short": "feindliche Portal-Mod(s) zerstört"
    },
    "it": {
      "label": "Distruggere un Portal Mod nemico",
      "short": "Portal Mod nemici distrutti"
    },
    "nl": {
      "label": "Een vijandige Portal Mod vernietigen",
      "short": "vijandige Portal Mod(s) vernietigd"
    }
  },
  "destroyLink": {
    "es": {
      "label": "Destruir un Link enemigo",
      "short": "Link(s) enemigo(s) destruido(s)"
    },
    "pt": {
      "label": "Destruir um Link inimigo",
      "short": "Link(s) inimigo(s) destruído(s)"
    },
    "de": {
      "label": "Feindlichen Link zerstören",
      "short": "feindliche Link(s) zerstört"
    },
    "it": {
      "label": "Distruggere un Link nemico",
      "short": "Link nemici distrutti"
    },
    "nl": {
      "label": "Een vijandige Link vernietigen",
      "short": "vijandige Link(s) vernietigd"
    }
  },
  "destroyField": {
    "es": {
      "label": "Destruir un Field enemigo",
      "short": "Field(s) enemigo(s) destruido(s)"
    },
    "pt": {
      "label": "Destruir um Field inimigo",
      "short": "Field(s) inimigo(s) destruído(s)"
    },
    "de": {
      "label": "Feindliches Field zerstören",
      "short": "feindliche Field(s) zerstört"
    },
    "it": {
      "label": "Distruggere un Field nemico",
      "short": "Field nemici distrutti"
    },
    "nl": {
      "label": "Een vijandige Field vernietigen",
      "short": "vijandige Field(s) vernietigd"
    }
  }
};

export const LEON_LOCALES = {
  "fr": "fr-FR",
  "en": "en-US",
  "es": "es-ES",
  "pt": "pt-PT",
  "de": "de-DE",
  "it": "it-IT",
  "nl": "nl-NL"
};
