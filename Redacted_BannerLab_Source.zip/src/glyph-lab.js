import './glyph-lab.css';

/*
 * Glyph geometry / dictionary values adapted from gm9/ingress-glyph-tools
 * Copyright (c) 2014 gm9, MIT License.
 * Original project: https://github.com/gm9/ingress-glyph-tools
 * Redacted BannerLab UI/game logic below is original integration code.
 */

const RT3 = Math.sqrt(3);
const NODE_POS = [
  [0,-1],[RT3/2,-1/2],[RT3/2,1/2],[0,1],[-RT3/2,1/2],[-RT3/2,-1/2],
  [RT3/4,-1/4],[RT3/4,1/4],[-RT3/4,1/4],[-RT3/4,-1/4],[0,0]
];

const RAW_GLYPHS = [
  ['89',['1']],['696a787a',['3']],['1634486a8a',['Abandon']],['587a8a',['Adapt']],['0949',['Advance']],
  ['1216276a7a',['After']],['49676a898a',['Again','Repeat']],['010512233445',['All']],['67697a',['Answer']],
  ['06092649',['Attack','War']],['05061617',['Avoid']],['0a277a',['Barrier','Obstacle']],['4548598a9a',['Before']],
  ['083738',['Begin']],['3738676989',['Being','Human']],['696a9a',['Body','Shell']],['16596a9a',['Breathe','Live']],
  ['1734487a8a',['Capture']],['373a8a',['Change','Modify']],['01051638456a8a',['Chaos','Disorder']],['0a3a',['Clear']],
  ['01050a1223343a45',['Clear All']],['698a9a',['Complex']],['2649677889',['Conflict']],['27597889',['Consequence']],
  ['011223386a899a',['Contemplate']],['497889',['Courage']],['16486a8a',['Create','Creation']],
  ['1216274548597a9a',['Creativity','Idea','Thought']],['093a9a',['Danger']],['06386a8a',['Data','Signal']],
  ['17373858',['Defend']],['38676a789a',['Destiny']],['1223',['Destination']],['27597a9a',['Destroy','Destruction']],
  ['488a9a',['Deteriorate','Erode']],['386a8a',['Easy']],['27487a8a',['Die','Death']],['16677a8a',['Difficult']],
  ['122334',['Discover']],['0545',['Distance','Outside']],['010a17373a',['End','Close']],['01091223696a9a',['Enlightened','Enlightenment']],
  ['676989',['Equal']],['01166989',['Escape']],['0a899a',['Evolution','Progress','Success']],['0a676a',['Failure']],
  ['176769',['Fear']],['1517373858',['Field']],['061216',['Follow']],['48',['Forget']],['162767',['Future']],['58',['Gain']],
  ['1659677889',['Civilization','Structure']],['4989',['Grow']],['0609276a7a9a',['Harm']],['060937386a7a8a9a',['Harmony','Peace']],
  ['387a8a',['Have']],['59788a9a',['Help']],['16176978',['Hide']],['363969',['I','Me']],['27',['Ignore']],
  ['6a898a9a',['Imperfect']],['166a7a',['Improve']],['3a898a9a',['Impure']],['16486a899a',['Intelligence']],
  ['0a3a4548598a9a',['Interrupt']],['163445596a9a',['Journey']],['3a676a7a898a9a',['Key']],['36396a9a',['Knowledge']],
  ['7889',['L']],['05384548',['Lead']],['0105162748596789',['Legacy']],['6a9a',['Less']],['0116496a9a',['Liberate']],
  ['676a7a899a',['Lie']],['15',['Link']],['16496a898a',['Live Again','Reincarnate']],['17',['Lose']],
  ['17497a9a',['Message','Notification']],['383a899a',['Mind']],['7a8a',['More']],['0609596989',['Mystery']],
  ['677a899a',['N']],['06090a3a6a9a',["N'Zeer"]],['2748676989',['Nature']],['1516242748596a7a8a9a',['Nemesis']],
  ['2767',['New']],['6769',['Not','Inside']],['343a488a',['Nourish']],['5989',['Old']],['373878',['Open','Accept']],
  ['010512233437384578',['Open All']],['0609242649696a9a',['Osiris']],['1216274548596978',['Portal']],['485989',['Past']],
  ['0a488a',['Path']],['0a232734487a8a',['Balance','Perfection']],['060927486a7a8a9a',['Perspective']],
  ['0a12277a',['Potential']],['3738676a78899a',['Presence']],['677889',['Present','Now']],['0a676a7a',['Pure']],
  ['060959',['Pursue']],['066989',['Question']],['27697a9a',['React']],['1216586a8a',['Rebel']],['050a599a',['Recharge','Repair']],
  ['090a383a69',['Resistance','Struggle']],['2327597a9a',['Restraint']],['0626',['Retreat']],['264969',['Safety']],
  ['177a8a',['Save']],['09',['See']],['696a7889',['Search']],['2334',['Self','Individual']],['2759676a898a',['Separate']],
  ['060927486789',['Shapers','Collective']],['27344878',['Share']],['060937386789',['Shield']],['78',['Simple']],
  ['373a676a',['Soul']],['274878',['Stability','Stay']],['0a16273a48596a7a8a9a',['Star']],['67697889',['Strong']],
  ['16276a7a898a9a',['Technology']],['0878',['Them']],['48696a8a9a',['Together']],['676a7a898a9a',['Truth']],
  ['010517233445696a7889',['Unbounded']],['177a',['Use']],['06093639',['Victory']],['373848',['Want']],['3669',['We','Us']],
  ['596769',['Weak']],['17587a8a',['Worth']],['67697a898a',['XM']],['070878',['You','Your','Other']]
];

const GLYPHS = RAW_GLYPHS.map(([code,names])=>({code,names,key:names[0].toLowerCase().replaceAll(' ','_')}));
const BY_WORD = new Map();
for(const g of GLYPHS) for(const name of g.names) BY_WORD.set(name.toLowerCase(), g);
const word = s => BY_WORD.get(String(s).toLowerCase());

const COMMON_SINGLE = ['portal','link','field','capture','hack','xm','human','shapers','truth','future','past','more','less','create','destroy','attack','defend','recharge','key','mind','soul','journey','resistance','enlightenment']
  .map(word).filter(Boolean);
const PAIRS = [
  ['less','more'],['attack','defend'],['create','destroy'],['future','past'],['gain','lose'],['advance','retreat'],
  ['pure','impure'],['courage','fear'],['new','old'],['capture','liberate'],['civilization','nature'],['improve','deteriorate']
].map(a=>a.map(word).filter(Boolean)).filter(a=>a.length===2);
const SEQ3 = [
  ['advance','human','enlightenment'],['advance','human','resistance'],['attack','capture','link'],['attack','shapers','portal'],
  ['capture','shapers','portal'],['change','human','future'],['civilization','attack','chaos'],['complex','journey','future'],
  ['contemplate','journey','distance'],['create','new','future'],['discover','pure','truth'],['escape','shapers','harm'],
  ['follow','pure','journey'],['journey','harmony','path'],['mind','equal','truth'],['open','human','weak'],
  ['past','equal','future'],['potential','truth','harmony'],['question','human','truth'],['search','xm','portal']
];
const SEQ4 = [
  ['attack','not','worth','consequence'],['clear','mind','open','mind'],['discover','balance','safety','all'],['help','gain','create','pursue'],
  ['human','past','present','future'],['less','mind','more','soul'],['less','soul','more','mind'],['more','data','gain','portal'],
  ['portal','change','truth','data'],['question','truth','gain','future'],['shapers','mind','complex','harmony'],['together','discover','harmony','equal'],
  ['truth','idea','discover','xm'],['defend','message','answer','idea'],['nourish','portal','avoid','weak'],['recharge','soul','less','human']
];
const SEQ5 = [
  ['want','truth','pursue','difficult','path'],['strong','together','attack','together','chaos'],['strong','together','attack','together','destiny'],
  ['react','rebel','question','shapers','lie'],['mind','body','soul','pure','human'],['shapers','lead','human','complex','journey'],
  ['portal','attack','danger','pursue','safety'],['create','separate','path','end','journey'],['help','human','civilization','pursue','destiny'],
  ['human','not','together','civilization','deteriorate'],['search','destiny','create','pure','future'],['stability','strong','together','defend','resistance']
];

const UI = {
  fr:{title:'GLYPH LAB',sub:'Annexe expérimentale du sous-sol',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Dictionnaire',free:'Dessin libre',
    intro:'Deux façons de s’entraîner : Arcade pour jouer contre le chrono, Simple pour travailler à ton rythme.',
    speed:'Vitesse démo',slow:'Lente',normal:'Scanner',fast:'Rapide',start:'Commencer',restart:'Recommencer',nextSeq:'Séquence suivante',replay:'Revoir',watch:'OBSERVE',yourTurn:'À TOI',
    glyph:'Glyph',correct:'Correct',wrong:'Raté · nouvelle séquence.',complete:'Séquence validée',search:'Chercher un glyph…',draw:'Trace un glyph sur la matrice.',
    unknown:'Glyph non identifié',clear:'Effacer',source:'Outil non officiel · entraînement local · données de glyphs communautaires',
    noTimer:'SANS CHRONO',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Tracer en plein écran',closePad:'Fermer',release:'Relâche pour valider',drawAgain:'Trace le glyph suivant',nodes:'nœuds',demoHere:'Observe le glyph ici',
    arcadeIntro:'30 secondes au départ. Chaque séquence réussie ajoute du temps. Les séquences montent progressivement de 1 à 5 glyphs.',
    simpleIntro:'Choisis une longueur de 1 à 5 glyphs. Aucun chrono. Quand tu valides, passe à la séquence suivante quand tu veux.',
    length:'Longueur',time:'TEMPS',score:'GLYPHS',record:'RECORD',round:'SÉRIE',bonus:'Bonus temps',penalty:'Erreur : -3 s',timeUp:'Temps écoulé',ready:'Prêt ?',autoNext:'Séquence suivante…',getReady:'Prépare-toi'},
  en:{title:'GLYPH LAB',sub:'Experimental basement annex',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Dictionary',free:'Free draw',
    intro:'Two ways to train: Arcade against the clock, Simple at your own pace.',
    speed:'Demo speed',slow:'Slow',normal:'Scanner',fast:'Fast',start:'Start',restart:'Restart',nextSeq:'Next sequence',replay:'Replay',watch:'WATCH',yourTurn:'YOUR TURN',
    glyph:'Glyph',correct:'Correct',wrong:'Missed · new sequence.',complete:'Sequence complete',search:'Search a glyph…',draw:'Trace a glyph on the matrix.',
    unknown:'Unknown glyph',clear:'Clear',source:'Unofficial tool · local training · community glyph data',
    noTimer:'NO TIMER',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Draw fullscreen',closePad:'Close',release:'Release to validate',drawAgain:'Draw the next glyph',nodes:'nodes',demoHere:'Watch the glyph here',
    arcadeIntro:'Start with 30 seconds. Each completed sequence adds time. Sequences progressively grow from 1 to 5 glyphs.',
    simpleIntro:'Choose a sequence length from 1 to 5 glyphs. No timer. After success, move on whenever you want.',
    length:'Length',time:'TIME',score:'GLYPHS',record:'RECORD',round:'ROUND',bonus:'Time bonus',penalty:'Mistake: -3 s',timeUp:'Time up',ready:'Ready?',autoNext:'Next sequence…',getReady:'Get ready'}
 };
Object.assign(UI,{
es:{title:'GLYPH LAB',sub:'Anexo experimental del sótano',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Diccionario',free:'Dibujo libre',intro:'Dos formas de entrenar: Arcade contra el reloj o Simple a tu ritmo.',speed:'Velocidad de demo',slow:'Lenta',normal:'Scanner',fast:'Rápida',start:'Empezar',restart:'Reiniciar',nextSeq:'Secuencia siguiente',replay:'Repetir',watch:'OBSERVA',yourTurn:'TU TURNO',glyph:'Glyph',correct:'Correcto',wrong:'Fallado · nueva secuencia.',complete:'Secuencia validada',search:'Buscar un glyph…',draw:'Traza un glyph en la matriz.',unknown:'Glyph no identificado',clear:'Borrar',source:'Herramienta no oficial · entrenamiento local · datos comunitarios de glyphs',noTimer:'SIN CRONO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Dibujar a pantalla completa',closePad:'Cerrar',release:'Suelta para validar',drawAgain:'Traza el siguiente glyph',nodes:'nodos',demoHere:'Observa aquí el glyph',arcadeIntro:'Empiezas con 30 segundos. Cada secuencia completada añade tiempo. Las secuencias crecen progresivamente de 1 a 5 glyphs.',simpleIntro:'Elige una longitud de 1 a 5 glyphs. Sin cronómetro. Tras acertar, pasa a la siguiente cuando quieras.',length:'Longitud',time:'TIEMPO',score:'GLYPHS',record:'RÉCORD',round:'SERIE',bonus:'Bonus de tiempo',penalty:'Error: -3 s',timeUp:'Tiempo agotado',ready:'¿Listo?',autoNext:'Secuencia siguiente…',getReady:'Prepárate'},
pt:{title:'GLYPH LAB',sub:'Anexo experimental da cave',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simples',dictionary:'Dicionário',free:'Desenho livre',intro:'Duas formas de treinar: Arcade contra o relógio ou Simples ao teu ritmo.',speed:'Velocidade da demo',slow:'Lenta',normal:'Scanner',fast:'Rápida',start:'Começar',restart:'Recomeçar',nextSeq:'Sequência seguinte',replay:'Rever',watch:'OBSERVA',yourTurn:'A TUA VEZ',glyph:'Glyph',correct:'Correto',wrong:'Falhou · nova sequência.',complete:'Sequência validada',search:'Procurar um glyph…',draw:'Traça um glyph na matriz.',unknown:'Glyph não identificado',clear:'Limpar',source:'Ferramenta não oficial · treino local · dados comunitários de glyphs',noTimer:'SEM CRONÓMETRO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Desenhar em ecrã inteiro',closePad:'Fechar',release:'Solta para validar',drawAgain:'Traça o glyph seguinte',nodes:'nós',demoHere:'Observa o glyph aqui',arcadeIntro:'Começas com 30 segundos. Cada sequência concluída acrescenta tempo. As sequências crescem progressivamente de 1 a 5 glyphs.',simpleIntro:'Escolhe uma sequência de 1 a 5 glyphs. Sem cronómetro. Depois de acertares, avança quando quiseres.',length:'Comprimento',time:'TEMPO',score:'GLYPHS',record:'RECORDE',round:'SÉRIE',bonus:'Bónus de tempo',penalty:'Erro: -3 s',timeUp:'Tempo esgotado',ready:'Pronto?',autoNext:'Sequência seguinte…',getReady:'Prepara-te'},
de:{title:'GLYPH LAB',sub:'Experimenteller Kelleranbau',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Einfach',dictionary:'Wörterbuch',free:'Freies Zeichnen',intro:'Zwei Trainingsarten: Arcade gegen die Uhr oder Einfach in deinem Tempo.',speed:'Demo-Geschwindigkeit',slow:'Langsam',normal:'Scanner',fast:'Schnell',start:'Starten',restart:'Neu starten',nextSeq:'Nächste Sequenz',replay:'Nochmal ansehen',watch:'BEOBACHTEN',yourTurn:'DU BIST DRAN',glyph:'Glyph',correct:'Richtig',wrong:'Daneben · neue Sequenz.',complete:'Sequenz geschafft',search:'Glyph suchen…',draw:'Zeichne einen Glyph auf der Matrix.',unknown:'Glyph nicht erkannt',clear:'Löschen',source:'Inoffizielles Werkzeug · lokales Training · Community-Glyphdaten',noTimer:'OHNE TIMER',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Vollbild zeichnen',closePad:'Schließen',release:'Loslassen zum Bestätigen',drawAgain:'Zeichne den nächsten Glyph',nodes:'Knoten',demoHere:'Glyph hier beobachten',arcadeIntro:'Du startest mit 30 Sekunden. Jede geschaffte Sequenz gibt zusätzliche Zeit. Die Sequenzen wachsen schrittweise von 1 auf 5 Glyphs.',simpleIntro:'Wähle eine Länge von 1 bis 5 Glyphs. Kein Timer. Nach einem Erfolg gehst du weiter, wann du willst.',length:'Länge',time:'ZEIT',score:'GLYPHS',record:'REKORD',round:'RUNDE',bonus:'Zeitbonus',penalty:'Fehler: -3 s',timeUp:'Zeit abgelaufen',ready:'Bereit?',autoNext:'Nächste Sequenz…',getReady:'Mach dich bereit'},
it:{title:'GLYPH LAB',sub:'Annesso sperimentale del seminterrato',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Semplice',dictionary:'Dizionario',free:'Disegno libero',intro:'Due modi per allenarti: Arcade contro il tempo o Semplice al tuo ritmo.',speed:'Velocità demo',slow:'Lenta',normal:'Scanner',fast:'Rapida',start:'Inizia',restart:'Ricomincia',nextSeq:'Sequenza successiva',replay:'Rivedi',watch:'OSSERVA',yourTurn:'TOCCA A TE',glyph:'Glyph',correct:'Corretto',wrong:'Errore · nuova sequenza.',complete:'Sequenza completata',search:'Cerca un glyph…',draw:'Traccia un glyph sulla matrice.',unknown:'Glyph non identificato',clear:'Cancella',source:'Strumento non ufficiale · allenamento locale · dati glyph della community',noTimer:'SENZA CRONOMETRO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Disegna a schermo intero',closePad:'Chiudi',release:'Rilascia per convalidare',drawAgain:'Traccia il glyph successivo',nodes:'nodi',demoHere:'Osserva qui il glyph',arcadeIntro:'Parti con 30 secondi. Ogni sequenza completata aggiunge tempo. Le sequenze crescono gradualmente da 1 a 5 glyph.',simpleIntro:'Scegli una lunghezza da 1 a 5 glyph. Nessun cronometro. Dopo un successo, passa alla successiva quando vuoi.',length:'Lunghezza',time:'TEMPO',score:'GLYPHS',record:'RECORD',round:'SERIE',bonus:'Bonus tempo',penalty:'Errore: -3 s',timeUp:'Tempo scaduto',ready:'Pronto?',autoNext:'Sequenza successiva…',getReady:'Preparati'},
nl:{title:'GLYPH LAB',sub:'Experimentele kelderbijlage',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Eenvoudig',dictionary:'Woordenboek',free:'Vrij tekenen',intro:'Twee manieren om te trainen: Arcade tegen de klok of Eenvoudig op je eigen tempo.',speed:'Demosnelheid',slow:'Langzaam',normal:'Scanner',fast:'Snel',start:'Starten',restart:'Opnieuw',nextSeq:'Volgende reeks',replay:'Opnieuw bekijken',watch:'KIJK',yourTurn:'JOUW BEURT',glyph:'Glyph',correct:'Goed',wrong:'Gemist · nieuwe reeks.',complete:'Reeks voltooid',search:'Glyph zoeken…',draw:'Teken een glyph op de matrix.',unknown:'Glyph niet herkend',clear:'Wissen',source:'Onofficiële tool · lokale training · community-glyphgegevens',noTimer:'ZONDER TIMER',arcadeBadge:'ARCADE',phrase:'Zin',openPad:'Volledig scherm tekenen',closePad:'Sluiten',release:'Loslaten om te bevestigen',drawAgain:'Teken de volgende glyph',nodes:'knooppunten',demoHere:'Bekijk de glyph hier',arcadeIntro:'Je start met 30 seconden. Elke voltooide reeks geeft extra tijd. Reeksen groeien geleidelijk van 1 naar 5 glyphs.',simpleIntro:'Kies een lengte van 1 tot 5 glyphs. Geen timer. Na een succes ga je verder wanneer je wilt.',length:'Lengte',time:'TIJD',score:'GLYPHS',record:'RECORD',round:'REEKS',bonus:'Tijdbonus',penalty:'Fout: -3 s',timeUp:'Tijd voorbij',ready:'Klaar?',autoNext:'Volgende reeks…',getReady:'Maak je klaar'}
});
const tr = lang => UI[String(lang||'').toLowerCase()] || UI.en;
const esc = s => String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const pick = a => a[Math.floor(Math.random()*a.length)];
const sleep = ms => new Promise(r=>setTimeout(r,ms));

function idx(ch){ return parseInt(ch,11); }
function nodeXY(i,size=240){
  const [x,y]=NODE_POS[i]; const r=size*.39,c=size/2;
  return [c+r*x,c+r*y];
}
function edges(code){
  const out=[]; for(let i=0;i+1<code.length;i+=2) out.push([idx(code[i]),idx(code[i+1])]); return out;
}
function glyphSvg(g, size=210, cls=''){
  if(!g) return '';
  const ls=edges(g.code).map(([a,b])=>{const [x1,y1]=nodeXY(a,size),[x2,y2]=nodeXY(b,size);return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`;}).join('');
  const ns=NODE_POS.map((_,i)=>{const [x,y]=nodeXY(i,size);return `<circle cx="${x}" cy="${y}" r="${Math.max(3,size*.018)}"/>`;}).join('');
  return `<svg class="glyphLabGlyph ${esc(cls)}" viewBox="0 0 ${size} ${size}" aria-label="${esc(g.names[0])}"><g class="glyphLabLines">${ls}</g><g class="glyphLabNodes">${ns}</g></svg>`;
}
function canonicalFromPath(path){
  const seen=new Set();
  for(let i=1;i<path.length;i++){
    let a=path[i-1],b=path[i]; if(a===b)continue; if(a>b)[a,b]=[b,a];
    seen.add(`${a.toString(11)}${b.toString(11)}`);
  }
  return [...seen].sort((x,y)=>{const ax=idx(x[0]),bx=idx(x[1]),ay=idx(y[0]),by=idx(y[1]);return ax-ay||bx-by;}).join('');
}
function glyphByCode(code){ return GLYPHS.find(g=>g.code===code) || null; }
function sequenceForLength(len){
  len=Math.max(1,Math.min(5,Number(len)||1));
  if(len===1) return [pick(COMMON_SINGLE.length?COMMON_SINGLE:GLYPHS)];
  if(len===2) return pick(PAIRS);
  const bank=len===3?SEQ3:len===4?SEQ4:SEQ5;
  const seq=pick(bank).map(word).filter(Boolean);
  if(seq.length===len)return seq;
  return Array.from({length:len},()=>pick(COMMON_SINGLE.length?COMMON_SINGLE:GLYPHS));
}

export function glyphLabMarkup(lang='fr'){
  const t=tr(lang);
  return `<section class="glyphLabScreen labGameScreen">
    <div class="glyphLabTop">
      <button class="labBack" data-arc-menu>${esc(t.back)}</button>
      <div><small>${esc(t.sub)}</small><h2>${esc(t.title)}</h2></div>
      <span class="glyphLabNoTimer arcade" data-glyph-mode-badge>${esc(t.arcadeBadge)}</span>
    </div>
    <p class="glyphLabIntro">${esc(t.intro)}</p>
    <div class="glyphLabTabs" role="tablist">
      <button class="active" data-glyph-tab="arcade">◉ ${esc(t.arcade)}</button>
      <button data-glyph-tab="simple">⌁ ${esc(t.simpleMode)}</button>
      <button data-glyph-tab="dictionary">◫ ${esc(t.dictionary)}</button>
      <button data-glyph-tab="free">✎ ${esc(t.free)}</button>
    </div>
    <div class="glyphLabPane" data-glyph-pane></div>
    <footer class="glyphLabSource">${esc(t.source)}</footer>
  </section>`;
}

function makePad(host,{onStroke,t}){
  host.innerHTML=`<button class="glyphPadLaunch" type="button" data-pad-open>✎ <span>${esc(t.openPad)}</span></button>`;
  const launch=host.querySelector('[data-pad-open]');
  const overlay=document.createElement('div');
  overlay.className='glyphPadOverlay';
  overlay.innerHTML=`
    <div class="glyphPadFullscreenTop">
      <button type="button" class="glyphPadClose" data-pad-close>×</button>
      <div><small>GLYPH LAB</small><strong data-pad-hint>${esc(t.release)}</strong></div>
      <span class="glyphPadFullscreenBadge" data-pad-badge>${esc(t.noTimer)}</span>
    </div>
    <div class="glyphPadStage">
      <div class="glyphPadWrap fullscreen">
        <svg class="glyphPad" viewBox="0 0 300 300" data-pad aria-label="Glyph input">
          <g class="glyphPadDemoGlow" data-demo-glow></g>
          <g class="glyphPadDemoInk" data-demo-ink></g>
          <g class="glyphPadTrace">
            <path class="glyphPadGlow" data-trace-glow fill="none"></path>
            <path class="glyphPadInk" data-trace-ink fill="none"></path>
          </g>
          <g class="glyphPadNodes">${NODE_POS.map((_,i)=>{const [x,y]=nodeXY(i,300);return `<circle data-node="${i}" cx="${x}" cy="${y}" r="7"/>`;}).join('')}</g>
        </svg>
        <div class="glyphPadFooter">
          <span data-pad-count>0 / 11 ${esc(t.nodes)}</span>
          <button type="button" class="glyphPadClear" data-pad-clear>${esc(t.clear)}</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const svg=overlay.querySelector('[data-pad]');
  const ink=overlay.querySelector('[data-trace-ink]');
  const glow=overlay.querySelector('[data-trace-glow]');
  const demoGlow=overlay.querySelector('[data-demo-glow]');
  const demoInk=overlay.querySelector('[data-demo-ink]');
  const hint=overlay.querySelector('[data-pad-hint]');
  const count=overlay.querySelector('[data-pad-count]');
  const badge=overlay.querySelector('[data-pad-badge]');
  let path=[],drawing=false,disabled=false,raf=0,lastPointerId=null,currentPoint=null,demoMode=false;
  const MAX_NODES=NODE_POS.length;
  const MAX_TRANSITIONS=48;

  const pointFromEvent=ev=>{
    const r=svg.getBoundingClientRect();
    return {x:(ev.clientX-r.left)*300/r.width,y:(ev.clientY-r.top)*300/r.height};
  };
  const distToSegment=(p,a,b)=>{
    const vx=b.x-a.x,vy=b.y-a.y,wx=p.x-a.x,wy=p.y-a.y;
    const vv=vx*vx+vy*vy;
    const q=vv?Math.max(0,Math.min(1,(wx*vx+wy*vy)/vv)):0;
    const x=a.x+q*vx,y=a.y+q*vy;
    return {d:Math.hypot(p.x-x,p.y-y),q};
  };
  const captureAlong=(a,b)=>{
    if(path.length>=MAX_TRANSITIONS)return;
    const hits=[];
    NODE_POS.forEach((_,i)=>{
      const [x,y]=nodeXY(i,300),h=distToSegment({x,y},a,b);
      if(h.d<=20)hits.push([h.q,i]);
    });
    hits.sort((x,y)=>x[0]-y[0]);
    for(const [,i] of hits){
      if(path.length>=MAX_TRANSITIONS)break;
      if(path[path.length-1]!==i)path.push(i);
    }
  };
  const traceD=()=>{
    if(!path.length)return '';
    const pts=path.map(i=>{const [x,y]=nodeXY(i,300);return {x,y};});
    let d=`M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
    for(let i=1;i<pts.length;i++)d+=` L ${pts[i].x.toFixed(1)} ${pts[i].y.toFixed(1)}`;
    if(drawing&&currentPoint&&path.length<MAX_TRANSITIONS){
      d+=` L ${currentPoint.x.toFixed(1)} ${currentPoint.y.toFixed(1)}`;
    }
    return d;
  };
  const render=()=>{
    raf=0;const d=traceD();ink.setAttribute('d',d);glow.setAttribute('d',d);
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.toggle('used',path.includes(Number(n.dataset.node))));
    count.textContent=`${new Set(path).size} / ${MAX_NODES} ${t.nodes}`;
  };
  const queueRender=()=>{if(!raf)raf=requestAnimationFrame(render)};
  let lastRaw=null;
  const addPoint=p=>{
    if(demoMode||disabled)return;
    if(lastRaw)captureAlong(lastRaw,p);else captureAlong(p,p);
    lastRaw=p;currentPoint=p;queueRender();
  };
  const clearTrace=()=>{
    path=[];lastRaw=null;currentPoint=null;ink.setAttribute('d','');glow.setAttribute('d','');
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('used'));
    count.textContent=`0 / ${MAX_NODES} ${t.nodes}`;
  };
  const clearDemo=()=>{
    demoGlow.innerHTML='';demoInk.innerHTML='';
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('demo-used'));
    overlay.classList.remove('demoing');demoMode=false;
  };
  const openOverlay=()=>{
    overlay.classList.add('open');document.documentElement.classList.add('glyphInputOpen');document.body?.classList.add('glyphInputOpen');
  };
  const close=()=>{
    drawing=false;lastPointerId=null;currentPoint=null;overlay.classList.remove('open');document.documentElement.classList.remove('glyphInputOpen');document.body?.classList.remove('glyphInputOpen');
  };
  const open=()=>{
    if(disabled)return;clearDemo();clearTrace();openOverlay();requestAnimationFrame(()=>svg.focus?.());
  };
  const setHint=text=>{hint.textContent=String(text||t.release)};
  const setBadge=text=>{badge.textContent=String(text||t.noTimer)};
  const setDisabled=v=>{disabled=!!v;launch.disabled=disabled;svg.classList.toggle('disabled',disabled);if(disabled&&!demoMode)close();};
  const showDemo=(g,label='')=>{
    disabled=true;launch.disabled=true;demoMode=true;drawing=false;clearTrace();overlay.classList.add('demoing');openOverlay();
    const used=new Set();
    const lines=edges(g.code).map(([a,b])=>{
      used.add(a);used.add(b);const [x1,y1]=nodeXY(a,300),[x2,y2]=nodeXY(b,300);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`;
    }).join('');
    demoGlow.innerHTML=lines;demoInk.innerHTML=lines;
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.toggle('demo-used',used.has(Number(n.dataset.node))));
    count.textContent=label||t.demoHere;setHint(label||t.demoHere);
  };
  const showGap=(label='')=>{
    demoGlow.innerHTML='';demoInk.innerHTML='';svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('demo-used'));
    count.textContent=label||t.watch;setHint(label||t.watch);openOverlay();
  };
  const beginInput=(label='')=>{
    clearDemo();disabled=false;launch.disabled=false;svg.classList.remove('disabled');clearTrace();setHint(label||t.release);openOverlay();
  };

  launch.onclick=open;
  overlay.querySelector('[data-pad-close]').onclick=close;
  overlay.querySelector('[data-pad-clear]').onclick=()=>{if(!demoMode)clearTrace();};
  overlay.addEventListener('pointerdown',ev=>{if(ev.target===overlay)ev.preventDefault();});
  svg.addEventListener('contextmenu',ev=>ev.preventDefault());
  svg.addEventListener('pointerdown',ev=>{
    if(disabled||demoMode)return;ev.preventDefault();drawing=true;lastPointerId=ev.pointerId;clearTrace();svg.setPointerCapture?.(ev.pointerId);addPoint(pointFromEvent(ev));
  });
  svg.addEventListener('pointermove',ev=>{
    if(!drawing||ev.pointerId!==lastPointerId||demoMode)return;ev.preventDefault();
    const events=typeof ev.getCoalescedEvents==='function'?ev.getCoalescedEvents():[ev];
    for(const e of events)addPoint(pointFromEvent(e));
  });
  const end=ev=>{
    if(!drawing||ev.pointerId!==lastPointerId||demoMode)return;ev.preventDefault();addPoint(pointFromEvent(ev));drawing=false;lastPointerId=null;currentPoint=null;queueRender();
    const code=canonicalFromPath(path);if(code)onStroke?.({code,path:[...path],match:glyphByCode(code)});else setHint(t.unknown);
  };
  svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
  return {clear:clearTrace,open,close,setHint,setBadge,disable:setDisabled,showDemo,showGap,beginInput,destroy(){close();if(raf)cancelAnimationFrame(raf);overlay.remove();}};
}

export function mountGlyphLab(body,{lang='fr',tone=()=>{},buzz=()=>{}}={}){
  const t=tr(lang); const pane=body.querySelector('[data-glyph-pane]');
  const modeBadge=body.querySelector('[data-glyph-mode-badge]');
  let active='arcade',destroyed=false,demoToken=0,timerId=null,lastTick=0;
  const BEST_KEY='rbl-glyph-arcade-best-v1';
  const state={simpleLen:3,speed:'normal',sequence:[],index:0,pad:null,
    arcade:{running:false,paused:true,time:30,score:0,round:0,best:Number(localStorage.getItem(BEST_KEY)||0)}};
  const speedMs=()=>state.speed==='slow'?900:state.speed==='fast'?360:590;
  const arcadeSpeedMs=()=>Math.max(330,720-state.arcade.round*38);
  const stopTimer=()=>{if(timerId){clearInterval(timerId);timerId=null;}lastTick=0;};
  const fmtTime=n=>Math.max(0,n).toFixed(n<10?1:0);
  const syncArcadeHud=()=>{
    const a=state.arcade;
    pane.querySelectorAll('[data-arc-time]').forEach(x=>x.textContent=fmtTime(a.time));
    pane.querySelectorAll('[data-arc-score]').forEach(x=>x.textContent=String(a.score));
    pane.querySelectorAll('[data-arc-round]').forEach(x=>x.textContent=String(a.round+1));
    pane.querySelectorAll('[data-arc-best]').forEach(x=>x.textContent=String(a.best));
    if(state.pad&&active==='arcade')state.pad.setBadge(`⏱ ${fmtTime(a.time)} s`);
  };
  const gameOver=()=>{
    const a=state.arcade;if(!a.running)return;a.running=false;a.paused=true;a.time=0;stopTimer();syncArcadeHud();
    state.pad?.close();
    const status=pane.querySelector('[data-status]');if(status){status.className='glyphStatus bad';status.textContent=`${t.timeUp} · ${a.score} glyph${a.score>1?'s':''}`;}
    const start=pane.querySelector('[data-arc-start]');if(start){start.textContent=t.restart;start.disabled=false;}
  };
  const startTimer=()=>{
    stopTimer();lastTick=performance.now();timerId=setInterval(()=>{
      const now=performance.now(),dt=(now-lastTick)/1000;lastTick=now;
      const a=state.arcade;if(!a.running||a.paused){syncArcadeHud();return;}
      a.time=Math.max(0,a.time-dt);syncArcadeHud();if(a.time<=0)gameOver();
    },80);
  };
  const setTopBadge=mode=>{
    if(!modeBadge)return;
    const arcade=mode==='arcade';modeBadge.textContent=arcade?t.arcadeBadge:t.noTimer;modeBadge.classList.toggle('arcade',arcade);
  };

  const wirePad=(mode,{status,phrase,demo,onSequenceDone,onSequenceFail})=>{
    state.pad=makePad(pane.querySelector('[data-pad-host]'),{t,onStroke:({code})=>{
      if(!state.sequence.length||state.index>=state.sequence.length)return;
      const target=state.sequence[state.index];
      if(code===target.code){
        tone(720,0.045,0.02,'sine',920);status.className='glyphStatus ok';status.textContent=`✓ ${t.correct} · ${target.names[0]}`;state.index+=1;state.pad.clear();
        if(state.index>=state.sequence.length){
          phrase.innerHTML=`<b>${esc(t.phrase)}</b> · ${state.sequence.map(g=>esc(g.names[0].toUpperCase())).join(' · ')}`;
          status.textContent=`✓ ${t.complete}`;demo.innerHTML=`<strong>${esc(t.complete)}</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
          state.pad.setHint(`✓ ${t.complete}`);tone(520,0.08,0.024,'triangle',880);onSequenceDone?.();
        }else{
          state.pad.setHint(`${t.yourTurn} · ${t.glyph} ${state.index+1}/${state.sequence.length}`);
          setTimeout(()=>{if(!destroyed&&state.pad){status.className='glyphStatus';status.textContent=`${t.yourTurn} · ${t.glyph} ${state.index+1}/${state.sequence.length}`;}},180);
        }
      }else{
        buzz(30);tone(170,0.07,0.02,'square',110);status.className='glyphStatus bad';
        if(mode==='arcade'){
          state.arcade.paused=true;state.arcade.time=Math.max(0,state.arcade.time-3);status.textContent=`✕ ${t.wrong} · -3 s`;syncArcadeHud();state.pad.setHint(`✕ ${t.wrong}`);state.pad.disable(true);state.pad.clear();if(state.arcade.time<=0){gameOver();return;}onSequenceFail?.();return;
        }else status.textContent=t.wrong;
        state.pad.setHint(t.wrong);state.pad.clear();
      }
    }});
    state.pad.disable(true);state.pad.setBadge(mode==='arcade'?`⏱ ${fmtTime(state.arcade.time)} s`:t.noTimer);
  };

  const playDemo=async({mode,ms})=>{
    const token=++demoToken;state.index=0;state.pad.disable(true);
    if(mode==='arcade')state.arcade.paused=true;
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    status.className='glyphStatus';status.textContent=t.watch;phrase.textContent='';
    for(let i=0;i<state.sequence.length;i++){
      if(destroyed||token!==demoToken)return;
      const g=state.sequence[i],label=`${t.watch} · ${t.glyph} ${i+1}/${state.sequence.length}`;
      demo.innerHTML=`<strong>${esc(t.watch)}</strong><span>${esc(t.glyph)} ${i+1}/${state.sequence.length} · ${esc(t.demoHere)}</span>`;
      state.pad.showDemo(g,label);tone(340+i*36,0.035,0.012,'sine');await sleep(ms());
      if(destroyed||token!==demoToken)return;state.pad.showGap(`${t.watch} · ${i+1}/${state.sequence.length}`);await sleep(Math.max(110,ms()*.24));
    }
    if(destroyed||token!==demoToken)return;
    if(mode==='arcade'){
      for(const n of [3,2,1]){if(destroyed||token!==demoToken)return;demo.innerHTML=`<strong class="glyphCountdown">${n}</strong><span>${esc(t.getReady)}</span>`;status.className='glyphStatus countdown';status.textContent=String(n);state.pad.setHint(String(n));tone(260+n*70,0.04,0.012,'sine');await sleep(420);}
    }
    demo.innerHTML=`<strong>${esc(t.yourTurn)}</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
    status.className='glyphStatus';status.textContent=`${t.yourTurn} · ${t.glyph} 1/${state.sequence.length}`;
    state.pad.beginInput(`${t.yourTurn} · ${t.glyph} 1/${state.sequence.length}`);
    if(mode==='arcade'){state.arcade.paused=false;lastTick=performance.now();syncArcadeHud();}
  };

  const renderArcade=()=>{
    setTopBadge('arcade');stopTimer();
    const a=state.arcade;a.running=false;a.paused=true;
    pane.innerHTML=`<div class="glyphModeIntro arcade"><strong>◉ ${esc(t.arcade)}</strong><p>${esc(t.arcadeIntro)}</p></div>
      <div class="glyphArcadeHud"><div><small>${esc(t.time)}</small><b data-arc-time>30</b><span>s</span></div><div><small>${esc(t.score)}</small><b data-arc-score>${a.score}</b></div><div><small>${esc(t.round)}</small><b data-arc-round>1</b></div><div><small>${esc(t.record)}</small><b data-arc-best>${a.best}</b></div></div>
      <div class="glyphExercise"><div class="glyphDemo" data-demo><strong>${esc(t.ready)}</strong><span>1 → 5 glyphs</span></div><div class="glyphPhrase" data-phrase></div><div class="glyphStatus" data-status></div><div class="glyphPadHost" data-pad-host></div><div class="glyphActions single"><button class="labArcadePrimary" data-arc-start>${esc(t.start)}</button></div></div>`;
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    const nextRound=()=>{
      if(!a.running)return;
      const len=Math.min(5,a.round+1);state.sequence=sequenceForLength(len);state.index=0;
      status.className='glyphStatus';status.textContent=`${t.round} ${a.round+1} · ${len} glyph${len>1?'s':''}`;
      playDemo({mode:'arcade',ms:arcadeSpeedMs});
    };
    wirePad('arcade',{status,phrase,demo,onSequenceDone:()=>{
      a.paused=true;a.score+=state.sequence.length;a.round+=1;
      const bonus=2+state.sequence.length;a.time=Math.min(60,a.time+bonus);
      if(a.score>a.best){a.best=a.score;localStorage.setItem(BEST_KEY,String(a.best));}
      syncArcadeHud();status.className='glyphStatus ok';status.textContent=`✓ ${t.complete} · +${bonus} s`;state.pad.setHint(`+${bonus} s`);
      setTimeout(()=>{if(a.running&&!destroyed)nextRound();},650);
    },onSequenceFail:()=>{
      demo.innerHTML=`<strong class="glyphFailMark">✕</strong><span>${esc(t.wrong)}</span>`;status.className='glyphStatus bad';status.textContent=`✕ ${t.wrong} · -3 s`;
      setTimeout(()=>{if(a.running&&!destroyed)nextRound();},700);
    }});
    pane.querySelector('[data-arc-start]').onclick=e=>{
      demoToken++;a.running=true;a.paused=true;a.time=30;a.score=0;a.round=0;state.sequence=[];state.index=0;e.currentTarget.disabled=true;e.currentTarget.textContent='ARCADE EN COURS';syncArcadeHud();startTimer();nextRound();
    };
    syncArcadeHud();
  };

  const renderSimple=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;state.arcade.paused=true;
    pane.innerHTML=`<div class="glyphModeIntro"><strong>⌁ ${esc(t.simpleMode)}</strong><p>${esc(t.simpleIntro)}</p></div>
      <div class="glyphLabControls"><div class="glyphCtl"><label>${esc(t.length)}</label><div class="glyphLengths">${[1,2,3,4,5].map(n=>`<button class="${n===state.simpleLen?'active':''}" data-length="${n}">${n}</button>`).join('')}</div></div>
      <div class="glyphCtl"><label>${esc(t.speed)}</label><div class="glyphSpeeds"><button data-speed="slow" class="${state.speed==='slow'?'active':''}">${esc(t.slow)}</button><button data-speed="normal" class="${state.speed==='normal'?'active':''}">${esc(t.normal)}</button><button data-speed="fast" class="${state.speed==='fast'?'active':''}">${esc(t.fast)}</button></div></div></div>
      <div class="glyphExercise"><div class="glyphDemo" data-demo><span>${esc(t.ready)}</span></div><div class="glyphPhrase" data-phrase></div><div class="glyphStatus" data-status></div><div class="glyphPadHost" data-pad-host></div><div class="glyphActions"><button class="labArcadePrimary" data-next-seq>${esc(t.start)}</button><button class="labArcadeSecondary" data-replay disabled>${esc(t.replay)}</button></div></div>`;
    pane.querySelectorAll('[data-length]').forEach(b=>b.onclick=()=>{state.simpleLen=Number(b.dataset.length)||3;render();});
    pane.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>{state.speed=b.dataset.speed;render();});
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    const nextBtn=pane.querySelector('[data-next-seq]'),replay=pane.querySelector('[data-replay]');
    wirePad('simple',{status,phrase,demo,onSequenceDone:()=>{
      setTimeout(()=>state.pad?.close(),420);nextBtn.disabled=false;nextBtn.textContent=t.nextSeq;replay.disabled=false;
    }});
    const launch=()=>{state.sequence=sequenceForLength(state.simpleLen);nextBtn.disabled=true;replay.disabled=false;playDemo({mode:'simple',ms:speedMs});};
    nextBtn.onclick=launch;replay.onclick=()=>{if(state.sequence.length)playDemo({mode:'simple',ms:speedMs});};
  };

  const renderDictionary=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;
    pane.innerHTML=`<div class="glyphDictHead"><input type="search" data-glyph-search placeholder="${esc(t.search)}" autocomplete="off"><span>${GLYPHS.length} glyphs</span></div><div class="glyphDictionary" data-glyph-list></div>`;
    const list=pane.querySelector('[data-glyph-list]'),input=pane.querySelector('[data-glyph-search]');
    const fill=()=>{const q=input.value.trim().toLowerCase();const rows=GLYPHS.filter(g=>!q||g.names.some(n=>n.toLowerCase().includes(q))).sort((a,b)=>a.names[0].localeCompare(b.names[0])).map(g=>`<article class="glyphDictCard">${glyphSvg(g,120)}<div><strong>${esc(g.names[0])}</strong>${g.names.length>1?`<small>${g.names.slice(1).map(esc).join(' · ')}</small>`:''}</div></article>`).join('');list.innerHTML=rows||'<p class="glyphEmpty">∅</p>';};
    input.oninput=fill;fill();
  };

  const renderFree=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;
    pane.innerHTML=`<div class="glyphFree"><p>${esc(t.draw)}</p><div class="glyphFreeResult" data-free-result>?</div><div class="glyphPadHost" data-pad-host></div></div>`;
    const result=pane.querySelector('[data-free-result]');
    state.pad=makePad(pane.querySelector('[data-pad-host]'),{t,onStroke:({match})=>{if(match){result.className='glyphFreeResult known';result.innerHTML=`${glyphSvg(match,105)}<div><strong>${esc(match.names[0])}</strong>${match.names.length>1?`<small>${match.names.slice(1).map(esc).join(' · ')}</small>`:''}</div>`;state.pad?.setHint(`✓ ${match.names[0]}`);tone(660,0.05,0.018,'sine',840);}else{result.className='glyphFreeResult unknown';result.textContent=t.unknown;state.pad?.setHint(t.unknown);tone(160,0.06,0.018,'square',120);}}});
    state.pad.setBadge(t.noTimer);
  };

  const render=()=>{demoToken++;stopTimer();state.pad?.destroy?.();state.pad=null;if(active==='dictionary')renderDictionary();else if(active==='free')renderFree();else if(active==='simple')renderSimple();else renderArcade();};
  body.querySelectorAll('[data-glyph-tab]').forEach(b=>b.onclick=()=>{active=b.dataset.glyphTab;body.querySelectorAll('[data-glyph-tab]').forEach(x=>x.classList.toggle('active',x===b));render();});
  render();
  return ()=>{destroyed=true;demoToken++;stopTimer();state.pad?.destroy?.();state.pad=null;};
}

