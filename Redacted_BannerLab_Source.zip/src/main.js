import './style.css';
import JSZip from 'jszip';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';

const APP_VERSION = '0.6.0';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  name: 'Ma fresque',
  rows: 3,
  showGrid: true,
  showCircles: true,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0 },
  texts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    currentMission: 0,
    missions: []
  }
};

let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand">
        <div class="brandmark"><img src="/redacted-logo-512.png" alt="Redacted"></div>
        <div><h1>Redacted BannerLab</h1><small>Fresques Ingress Prime · v${APP_VERSION}</small></div>
      </div>
      <div class="grow"></div><button class="iconbtn" id="infoBtn" aria-label="Infos">${icon('info')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div class="projectidentity"><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> missions · source ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>Projets</span></button>
        <div class="rowpick"><span>Rangées</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>Fresque</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>Parcours</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>Missions</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>Publier</span></button>
      </div>
      <div class="card workspace">
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">Fresque entière</button>
          <button class="modebtn" data-editmode="mission">Une mission</button>
          <div class="missionstatus" id="missionStatus">Aucune mission sélectionnée</div>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>Ajoute ton image</strong>Elle sera cadrée directement sur la géométrie Prime.</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">Cercles Prime</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">Grille 512</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">Numéros</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} Agrandir mission</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>Réinitialiser mission</button>
        </div>
        <div class="hint" id="gestureHint"><b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <input id="ummInput" type="file" accept="application/json,.json" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>Image</span></button>
      <button class="tool active" data-tool="move">${icon('move')}<span>Cadrage</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>Texte</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>Aperçu</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>Exporter</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawBaseWorld(c){
  if(state.bg.image){
    const b=state.bg;
    c.save();c.translate(b.x,b.y);c.rotate(b.rotation);c.scale(b.scale,b.scale);
    c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
  }
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  const lines=(t.text||'Texte').split('\n');
  c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  const lineH=t.fontSize*1.08;
  lines.forEach((line,i)=>{const y=(i-(lines.length-1)/2)*lineH;if(t.strokeWidth>0){c.lineWidth=t.strokeWidth;c.strokeStyle=t.strokeColor;c.strokeText(line,0,y)}c.fillStyle=t.color;c.fillText(line,0,y)});
  c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseWorld(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseWorld(c);
    c.restore();
  }
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=state.bg.image?'none':'grid';
  updateMissionUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission'||!state.active.startsWith('text:'))return;
  const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
  c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;
  const lines=t.text.split('\n');const w=Math.max(...lines.map(x=>c.measureText(x).width),40)+36;const h=lines.length*t.fontSize*1.08+28;
  c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  $$('.tool').forEach(b=>b.classList.toggle('active',(b.dataset.tool==='move'&&a==='background')||(b.dataset.tool==='text'&&a.startsWith('text:'))));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=`Mission ${missionNumber(rc.row,rc.col)} sélectionnée`;
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent='Touche un médaillon';reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML='<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi la déplacer directement ici à 1 doigt.';
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML='<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.';
  }
}

async function loadImageFile(file){
  if(!file)return;
  if(file.size>45*1024*1024)toast('Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.');
  const img=await blobToImage(file);state.bg.blob=file;state.bg.image=img;
  fitBackground();setEditMode('fresco');setActive('background');scheduleSave();render();toast(`${img.naturalWidth} × ${img.naturalHeight} px importés`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight)}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasPointToMission(clientX,clientY){
  const rect=canvas.getBoundingClientRect();const scale=rect.width/WORLD_W;
  const x=(clientX-rect.left)/scale,y=(clientY-rect.top)/scale;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

canvas.addEventListener('pointerdown',e=>{
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(pointers.size===1){gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,isMission:state.editMode==='mission'}}
  else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:state.editMode==='mission'}}
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(pointers.size===1&&gesture?.mode==='one'){
    const dx=(e.clientX-gesture.startX)/getCssScale(),dy=(e.clientY-gesture.startY)/getCssScale();
    if(state.editMode==='mission'){obj.dx=gesture.objX+dx;obj.dy=gesture.objY+dy}else{obj.x=gesture.objX+dx;obj.y=gesture.objY+dy}
    render();
  } else if(pointers.size===2){
    const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1])};return}
    const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);
    obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),state.editMode==='mission'?.2:.02,state.editMode==='mission'?5:30);obj.rotation=gesture.objRot+(a-gesture.angle);
    const x=gesture.objX+(m.x-gesture.mid.x)/getCssScale(),y=gesture.objY+(m.y-gesture.mid.y)/getCssScale();
    if(state.editMode==='mission'){obj.dx=x;obj.dy=y}else{obj.x=x;obj.y=y}
    render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){gesture=null;scheduleSave()}
  else if(pointers.size===1){const p=[...pointers.values()][0],obj=selectedObj();if(obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:state.editMode==='mission'?(obj.dx||0):obj.x,objY:state.editMode==='mission'?(obj.dy||0):obj.y}}
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||'Ma fresque';ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>changeRows(+e.target.value));
function changeRows(rows){
  const oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>setEditMode(btn.dataset.editmode)));
$('#resetMissionBtn').addEventListener('click',resetSelectedMission);
$('#openMissionEditorBtn').addEventListener('click',openMissionEditor);

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(t==='image')$('#fileInput').click();
  if(t==='move')openTransformSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#infoBtn').addEventListener('click',openInfoSheet);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  $$('.flowstep').forEach(x=>x.classList.toggle('on',x===btn));
  const flow=btn.dataset.flow;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}));
$('#ummInput').addEventListener('change',e=>{const file=e.target.files?.[0];e.target.value='';if(file)importUmmFile(file)});

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}

function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast('Touche d’abord la mission que tu veux recadrer.');return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>Mission ${n}</h2><p>Ce cadrage ne touche qu’à ce médaillon.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>Zoom local <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>Rotation <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} Réinitialiser cette mission</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:');
  const baseScale=state.bg.image?Math.max(WORLD_W/state.bg.image.naturalWidth,worldH()/state.bg.image.naturalHeight):1;
  const zoomValue=Math.round((isText?o.scale:o.scale/baseScale)*100);
  const sh=openSheet(`<div class="sheethead"><div><h2>${isText?'Transformer le texte':'Cadrer l’image'}</h2><p>Le geste à deux doigts reste disponible directement sur la fresque.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Zoom</label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>Rotation <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">Centrer</button><button class="secondary" id="resetBtn">${icon('reset')} Réinitialiser</button>${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} Supprimer</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};
  $('#zoom',sh).oninput=e=>{if(isText)o.scale=+e.target.value/100;else if(state.bg.image)o.scale=baseScale*(+e.target.value/100);render();scheduleSave()};
  $('#centerBtn',sh).onclick=()=>{o.x=WORLD_W/2;o.y=worldH()/2;render();scheduleSave()};
  $('#resetBtn',sh).onclick=()=>{if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else fitBackground();closeSheet();render();scheduleSave()};
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast('Sélectionne d’abord une mission.');return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="Fermer">${icon('close')}</button>
      <div><strong id="missionEditorTitle">Mission ${n}</strong><span>Recadrage individuel · 512 × 512</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="Aperçu cercle">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>1 doigt</b> déplacer · <b>2 doigts</b> zoomer et tourner</div>
    <section class="missioneditorcontrols">
      <div class="missionnav">
        <button class="secondary missionprev">‹ Mission précédente</button>
        <button class="secondary missionnext">Mission suivante ›</button>
      </div>
      <div class="field"><label>Zoom <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>Rotation <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} Réinitialiser</button><button class="primary missiondone">Terminé</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();scheduleSave();};
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=`Mission ${n}`;
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){missionEditorGesture=null;scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0];missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();scheduleSave();toast(`Mission ${missionNumber(rc.row,rc.col)} réinitialisée`);
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();scheduleSave();toast('Texte supprimé');
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>Texte</h2><p>Chaque texte reste un calque indépendant, modifiable ou supprimable.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Calque</label><select id="textLayer"><option value="new">+ Nouveau texte</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);const box=$('#textEditor',sh);
    box.innerHTML=`<div class="field"><label>Texte</label><input id="txt" value="${escapeAttr(t?.text||'GREEN RILLETTES 7')}" maxlength="120"></div>
      <div class="grid2"><div class="field"><label>Taille</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>Contour</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div></div>
      <div class="grid2"><div class="field"><label>Couleur</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div><div class="field"><label>Couleur contour</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?'Mettre à jour':'Ajouter'}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} Supprimer</button>`:''}</div>`;
    $('#saveText',box).onclick=()=>{
      if(!t){t={id:uid(),text:$('#txt',box).value||'Texte',x:WORLD_W/2,y:worldH()/2,fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,scale:1,rotation:0};state.texts.push(t)}
      else Object.assign(t,{text:$('#txt',box).value||'Texte',fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0});
      setActive('text:'+t.id);scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Aperçu Prime</h2><p>Les recadrages individuels sont déjà appliqués.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseWorld(cc);cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>Exporter ${count} missions</h2><p>Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!state.bg.image?'<div class="rule warning"><span class="dot"></span><span>Aucune image de fond n’est chargée.</span></div>':''}
    <div class="field"><label>Format des missions</label><select id="exportFormat"><option value="jpeg" selected>JPG rapide · qualité élevée</option><option value="png">PNG sans perte · plus lent</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.</span></div><div class="rule"><span class="dot"></span><span>Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.</span></div><div class="rule"><span class="dot"></span><span>${adjusted} mission(s) avec recadrage individuel.</span></div><div class="rule warning"><span class="dot"></span><span>Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">Prêt.</div>
    <div class="actions"><button class="primary" id="doExport" ${!state.bg.image?'disabled':''}>Créer le ZIP</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent='Assemblage du ZIP…';bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`Assemblage du ZIP… ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent='ZIP créé.';
      await Share.share({title:'Export Redacted BannerLab',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:'Enregistrer ou partager le ZIP'});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent='ZIP téléchargé.';
    }
    toast(`Export ${jpeg?'JPG rapide':'PNG'} terminé`);
  }catch(err){console.error(err);txt.textContent='Erreur : '+(err?.message||err);toast('L’export a échoué.')}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}\n${state.name}\n${state.rows} rangée(s) · ${state.rows*6} missions\n\nOrdre de création :\n`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false);s+=`${String(n).padStart(3,'0')}.${ext} : rangée ${row+1} depuis le haut, colonne ${col+1} depuis la gauche${o&&!isIdentityOverride(o)?' · recadrage individuel':''}\n`}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('Canvas export impossible')),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const OBJECTIVE_LABELS={
  HACK_PORTAL:'Hack portal',
  INSTALL_MOD:'Installer un mod',
  CAPTURE_PORTAL:'Capturer / améliorer',
  CREATE_LINK:'Créer un lien',
  CREATE_FIELD:'Créer un champ',
  PASSPHRASE:'Passphrase'
};

function normalizePlanner(p={}){
  const planner={
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||6,1,24),
    autoAdvance: p.autoAdvance!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||'Portail'),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||'Fresque';
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function duplicateGuidCount(){
  const counts={};for(const m of state.planner.missions)for(const p of m.portals||[])if(p.guid)counts[p.guid]=(counts[p.guid]||0)+1;
  return Object.values(counts).filter(n=>n>1).length;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):'Départ';
  const opts=Object.entries(OBJECTIVE_LABELS).map(([v,l])=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${l}</option>`).join('');
  const badGuid=!p.guid;
  return `<div class="portalrow" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||'Portail sans nom')}</strong><span>${dist}${badGuid?' · GUID manquant':''}</span><select class="portalobjective">${opts}</select></div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="Monter">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="Descendre">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="Supprimer">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>Parcours · Mission ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} portails · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ Précédente</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>Suivante ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?'Mission complète':'Encore '+Math.max(0,need-count)+' portail(s)'}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion">
      <div class="iitccompanion-head"><img src="/redacted-logo-512.png" alt="Redacted"><div><b>IITC Companion</b><span>Construis le parcours directement sur la carte IITC, sans revenir dans BannerLab après chaque portail.</span></div><span class="beta">v2</span></div>
      <div class="iitcfeatureline"><span>●</span><div><b>Ajout direct</b><small>Un tap sur un portail peut l'ajouter à la mission courante.</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>Tracé visible</b><small>Le plugin dessine la mission en cours et numérote ses portails.</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>Navigation sans quitter IITC</b><small>Mission précédente/suivante, retirer le dernier portail puis synchroniser à la fin.</small></div></div>
      <div class="actions companionactions"><button class="primary openintel">${icon('globe')} Ouvrir IITC Companion</button><button class="secondary tutorialiitc">${icon('info')} Tutoriel</button></div>
      <div class="actions companionsecondary"><button class="secondary sharebridge">Installer / mettre à jour le plugin IITC</button></div>
    </div>
    <div class="actions routeactions"><button class="secondary addportal">${icon('plus')} Ajouter un portail manuellement</button></div>
    <div class="routeoptions"><label class="switchline"><input type="checkbox" id="autoAdvance" ${state.planner.autoAdvance?'checked':''}> Passer automatiquement à la mission suivante à ${need} portails</label></div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${dup} portail(s) avec GUID utilisé(s) plusieurs fois dans la bannière.</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):'<div class="emptyroute">Aucun portail pour cette mission. Ouvre IITC Companion, ou ajoute-en un manuellement.</div>'}</div>
    <div class="actions"><button class="secondary carryprev" ${idx===0||!plannerMission(idx-1)?.portals?.length?'disabled':''}>Reprendre le dernier portail précédent</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('#autoAdvance',sh).onchange=e=>{state.planner.autoAdvance=e.target.checked;scheduleSave()};
  $('.openintel',sh).onclick=openIntel;
  $('.tutorialiitc',sh).onclick=openIitcTutorial;
  $('.addportal',sh).onclick=()=>openAddPortalSheet(idx);
  $('.carryprev',sh).onclick=()=>{const prev=plannerMission(idx-1)?.portals?.at(-1);if(prev){addPortalToMission(structuredClone(prev),idx);openRoutePlanner()}};
  $('.sharebridge',sh).onclick=shareIitcBridge;
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalobjective',row).onchange=e=>{m.portals[pi].objective.type=e.target.value;scheduleSave()};
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();openRoutePlanner();
}
function removePortal(mi,pi){const m=plannerMission(mi);if(!m)return;m.portals.splice(pi,1);scheduleSave();openRoutePlanner()}
function openAddPortalSheet(mi=state.planner.currentMission,prefill={}){
  const sh=openSheet(`<div class="sheethead"><div><h2>Ajouter un portail</h2><p>Mission ${mi+1}. Un GUID est nécessaire pour un export UMM prêt à importer.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Lien Intel (optionnel)</label><input id="intelUrl" placeholder="https://intel.ingress.com/intel?...&pll=47.1,-1.6" value="${escapeAttr(prefill.url||'')}"></div>
    <div class="field"><label>Nom du portail</label><input id="portalTitle" value="${escapeAttr(prefill.title||'')}"></div>
    <div class="field"><label>GUID</label><input id="portalGuid" value="${escapeAttr(prefill.guid||'')}"></div>
    <div class="grid2"><div class="field"><label>Latitude</label><input id="portalLat" inputmode="decimal" value="${escapeAttr(prefill.lat??'')}"></div><div class="field"><label>Longitude</label><input id="portalLng" inputmode="decimal" value="${escapeAttr(prefill.lng??'')}"></div></div>
    <div class="actions"><button class="secondary parseintel">Lire le lien Intel</button><button class="primary saveportal">Ajouter</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.parseintel',sh).onclick=()=>{const p=parseIntelUrl($('#intelUrl',sh).value);if(!p){toast('Je ne trouve pas de coordonnées pll dans ce lien.');return}$('#portalLat',sh).value=p.lat;$('#portalLng',sh).value=p.lng;};
  $('.saveportal',sh).onclick=()=>{
    const lat=parseFloat(String($('#portalLat',sh).value).replace(',','.')),lng=parseFloat(String($('#portalLng',sh).value).replace(',','.'));
    if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180){toast('Coordonnées invalides.');return}
    const p=normalizePortal({guid:$('#portalGuid',sh).value.trim(),title:$('#portalTitle',sh).value.trim()||'Portail',location:{latitude:lat,longitude:lng}});
    addPortalToMission(p,mi);openRoutePlanner();
  };
}
function parseIntelUrl(raw){
  try{const u=new URL(raw.trim());const pll=u.searchParams.get('pll');if(!pll)return null;const [lat,lng]=pll.split(',').map(Number);if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;return {lat,lng}}catch{return null}
}
function addPortalToMission(portal,mi=state.planner.currentMission){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  if(portal.guid&&state.planner.missions.some(x=>x.portals.some(p=>p.guid===portal.guid))){toast('Ce portail est déjà utilisé dans la bannière.');}
  m.portals.push(normalizePortal(portal));scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){state.planner.currentMission=mi+1;toast(`Mission ${mi+1} complète · passage à la ${mi+2}`)}else toast(`Portail ajouté à la mission ${mi+1}`);
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||'Portail',Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||'Portail',location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL'}})}
function bridgePlannerPayload(){
  ensurePlannerMissions();return {v:2,pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact))};
}
async function openIntel(){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  u.searchParams.set('rbl',bridgeEncode(bridgePlannerPayload()));
  try{
    if(Capacitor.isNativePlatform()){await AppLauncher.openUrl({url:u.toString()});toast('IITC Companion chargé · reste dans IITC et synchronise quand ton parcours est prêt.');}
    else window.open(u.toString(),'_blank','noopener');
  }catch(e){console.warn(e);window.open(u.toString(),'_blank','noopener')}
}
async function bridgeUserscriptText(){
  const r=await fetch('/redacted-bannerlab-iitc.user.js',{cache:'no-store'});if(!r.ok)throw new Error('Plugin IITC introuvable');return await r.text();
}
async function shareIitcBridge(){
  const name='redacted-bannerlab-iitc.user.js';
  try{
    const text=await bridgeUserscriptText();
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab · IITC Companion',text:'Installe ou remplace ce plugin utilisateur dans IITC Mobile. Il ajoute le mini panneau Redacted directement sur la carte.',url:uri.uri,dialogTitle:'Installer le plugin IITC Companion'});
    }else downloadBlob(new Blob([text],{type:'text/javascript'}),name);
  }catch(e){console.error(e);toast('Impossible de partager le plugin IITC.')}
}
function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>Une seule ouverture d’IITC pour construire plusieurs missions.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>Installe le plugin une seule fois</strong><span>Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>Ouvre IITC depuis BannerLab</strong><span>Le projet, la mission active et les portails déjà choisis sont envoyés au mini panneau Redacted.</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>Construis directement sur la carte</strong><span>Avec « Ajout direct » activé, touche simplement un portail. Tu peux retirer le dernier, changer de mission et voir le tracé sans revenir dans BannerLab.</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>Synchronise quand tu as fini</strong><span>Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>Si tu préfères contrôler chaque ajout, désactive « Ajout direct » : sélectionne le portail puis appuie sur + dans le mini panneau.</span></div>
    <div class="actions"><button class="secondary installplugin">Installer / mettre à jour</button><button class="primary launchiitc">Ouvrir IITC Companion</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}
function handleBridgeUrl(raw){
  try{
    const u=new URL(raw);if(u.protocol!=='redactedbannerlab:')return false;
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||'Portail',imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='sync'){
      const data=bridgeDecode(u.searchParams.get('data')||'');if(!data||data.v!==2||!Array.isArray(data.m))return false;
      ensurePlannerMissions();
      state.planner.portalsPerMission=clamp(parseInt(data.ppm)||state.planner.portalsPerMission,1,24);
      state.planner.autoAdvance=data.auto!==false;
      data.m.slice(0,state.planner.missions.length).forEach((portals,i)=>{if(Array.isArray(portals))state.planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean)});
      state.planner.currentMission=clamp(parseInt(data.c)||0,0,state.planner.missions.length-1);
      scheduleSave();saveProject();toast('Parcours IITC synchronisé dans BannerLab.');openRoutePlanner();return true;
    }
    return false;
  }catch(e){console.warn('bridge',e);toast('Synchronisation IITC illisible.');return false}
}
function openMissionSettings(){
  ensurePlannerMissions();const idx=state.planner.currentMission,m=plannerMission(idx);
  const sh=openSheet(`<div class="sheethead"><div><h2>Missions</h2><p>Paramètres BannerLab + export compatible UMM Extended v1.2 / format 3.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Description commune</label><textarea id="bannerDesc" rows="4">${escapeHtml(state.planner.description||'')}</textarea></div>
    <div class="field"><label>Format des titres</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><div class="small">$T = nom · $N = numéro · $M = total · $0N = zéro automatique.</div></div>
    <div class="grid2"><div class="field"><label>Type</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>Séquentielle</option><option value="0" ${!state.planner.sequential?'selected':''}>Ordre libre</option></select></div><div class="field"><label>Localisation</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>Visible</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>Cachée</option></select></div></div>
    <div class="grid2"><div class="field"><label>Portails / mission</label><input id="ppm" type="number" min="1" max="24" value="${state.planner.portalsPerMission}"></div><div class="field"><label>Mission à éditer</label><select id="missionSelect">${state.planner.missions.map((x,i)=>`<option value="${i}" ${i===idx?'selected':''}>${i+1} · ${x.portals.length} portail(s)</option>`).join('')}</select></div></div>
    <div class="missionsetcard">
      <strong>Mission ${idx+1}</strong>
      <div class="field"><label>Titre</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>Description</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="small">${m.portals.length} portail(s) · ${formatDistance(missionDistance(m))}</div>
    </div>
    <div class="actions"><button class="secondary resetTitles">Régénérer les titres</button><button class="primary openRoute">${icon('route')} Modifier le parcours</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#bannerDesc',sh).oninput=e=>{state.planner.description=e.target.value;state.planner.missions.forEach(x=>{if(!x.descriptionCustom)x.description=e.target.value});scheduleSave()};
  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();$('#missionTitle',sh).value=plannerMission(idx).title;scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';if(!state.planner.sequential){state.planner.hiddenLocation=false;$('#hidden',sh).value='0'}scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{state.planner.portalsPerMission=clamp(parseInt(e.target.value)||6,1,24);scheduleSave();openMissionSettings()};
  $('#missionSelect',sh).onchange=e=>setPlannerMission(+e.target.value,'missions');
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('.resetTitles',sh).onclick=()=>{state.planner.missions.forEach(x=>x.titleCustom=false);refreshGeneratedMissionTitles();scheduleSave();openMissionSettings()};
  $('.openRoute',sh).onclick=()=>openRoutePlanner();
}
function validatePlanner(){
  ensurePlannerMissions();const need=state.planner.portalsPerMission,issues=[];
  state.planner.missions.forEach((m,i)=>{
    if(!m.title.trim())issues.push(`Mission ${i+1} : titre vide`);
    if(!m.description.trim())issues.push(`Mission ${i+1} : description vide`);
    if(m.portals.length<need)issues.push(`Mission ${i+1} : ${m.portals.length}/${need} portails`);
    const missing=m.portals.filter(p=>!p.guid).length;if(missing)issues.push(`Mission ${i+1} : ${missing} GUID manquant(s)`);
  });
  return issues;
}
function openPublishSheet(){
  ensurePlannerMissions();const issues=validatePlanner(),complete=state.planner.missions.filter(m=>m.portals.length>=state.planner.portalsPerMission).length,total=state.planner.missions.length;
  const sh=openSheet(`<div class="sheethead"><div><h2>Publier</h2><p>${complete}/${total} missions avec assez de portails · parcours ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishscore ${issues.length?'warn':'ok'}"><b>${issues.length?`${issues.length} point(s) à vérifier`:'Projet prêt pour UMM'}</b><span>${issues.length?'La préparation peut continuer, mais le JSON ne sera pas parfaitement prêt à importer.':'Titres, descriptions et GUID sont complets.'}</span></div>
    ${issues.length?`<div class="issuebox">${issues.slice(0,24).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}${issues.length>24?`<div>… et ${issues.length-24} autre(s)</div>`:''}</div>`:''}
    <div class="actions"><button class="secondary importumm">${icon('upload')} Importer JSON UMM</button><button class="primary exportumm">${icon('download')} Exporter JSON UMM</button></div>
    <div class="rule"><span class="dot"></span><span>L’export UMM v3 inclut les images de missions générées par BannerLab en JPEG haute qualité pour accélérer la préparation.</span></div>
    <div class="actions"><button class="secondary openmat">${icon('globe')} Mission Authoring Tool</button></div>
    <div class="bridgebox"><b>Workflow actuel</b><span>BannerLab prépare le JSON. UMM Extended sur missions.ingress.com peut ensuite importer une mission, l’image et les waypoints avant que tu la soumettes toi-même.</span></div>`);
  $('.close',sh).onclick=closeSheet;$('.importumm',sh).onclick=()=>$('#ummInput').click();$('.exportumm',sh).onclick=exportUmmJson;$('.openmat',sh).onclick=openMissionAuthoring;
}
function ummStateSkeleton(){
  ensurePlannerMissions();
  return {
    missionSetName:state.name||'',
    missionSetDescription:state.planner.description||'',
    currentMission:state.planner.currentMission||0,
    plannedBannerLength:state.planner.missions.length,
    titleFormat:state.planner.titleFormat||'$T $0N / $M',
    fileFormatVersion:3,
    missions:state.planner.missions.map(m=>({missionTitle:m.title||'',missionDescription:m.description||'',portals:m.portals.map(normalizePortal),image:-1})),
    sequential:state.planner.sequential!==false,
    hiddenLocation:!!state.planner.hiddenLocation,
    layers:[],
    category:state.name||undefined,
    images:[]
  };
}
function canvasDataUrl(c,type='image/jpeg',quality=.94){return c.toDataURL(type,quality)}
async function exportUmmJson(){
  ensurePlannerMissions();const data=ummStateSkeleton();const total=data.missions.length;
  try{
    toast('Création des images UMM…');
    for(let n=1;n<=total;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      data.images.push(canvasDataUrl(c,'image/jpeg',.94));data.missions[n-1].image=n-1;
      if(n%3===0)await tick();
    }
    const blob=new Blob([JSON.stringify(data)],{type:'application/json'}),name=`${safeName(state.name)}_UMM.json`;
    if(Capacitor.isNativePlatform()){
      const text=JSON.stringify(data);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab · UMM',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:'Enregistrer ou envoyer le JSON UMM'});
    }else downloadBlob(blob,name);
    toast('JSON UMM créé');
  }catch(e){console.error(e);toast('Export UMM impossible : '+(e?.message||e))}
}
async function importUmmFile(file){
  try{
    const raw=await file.text(),d=JSON.parse(raw);
    if(!Array.isArray(d.missions))throw new Error('missions manquantes');
    const count=Math.max(1,parseInt(d.plannedBannerLength)||d.missions.length),rows=Math.ceil(count/COLS);
    state.rows=clamp(rows,1,25);state.name=String(d.missionSetName||state.name||'Fresque UMM');
    state.planner=normalizePlanner({
      description:String(d.missionSetDescription||''),
      titleFormat:String(d.titleFormat||'$T $0N / $M'),
      sequential:d.sequential!==false,hiddenLocation:!!d.hiddenLocation,portalsPerMission:6,currentMission:parseInt(d.currentMission)||0,
      missions:d.missions.map(m=>({title:m.missionTitle||'',description:m.missionDescription||'',titleCustom:true,descriptionCustom:true,portals:m.portals||[]}))
    });
    ensurePlannerMissions();refreshProjectUi();scheduleSave();toast(`UMM importé : ${d.missions.length} missions`);openRoutePlanner();
  }catch(e){console.error(e);toast('JSON UMM invalide : '+(e?.message||e))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Redacted BannerLab</h2><p>Version ${APP_VERSION} · éditeur non officiel.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span><b>Moteur Prime :</b> 6 colonnes, 544 px par cellule, zone utile 512 × 512 centrée avec 16 px de marge.</span></div><div class="rule"><span class="dot"></span><span><b>Mission Planner :</b> titres, descriptions, portails, objectifs, distances et export JSON UMM sont conservés avec chaque projet.</span></div><div class="rule"><span class="dot"></span><span><b>IITC Companion :</b> le plugin compagnon permet maintenant de construire le parcours directement dans IITC, de voir le tracé, changer de mission puis tout synchroniser vers BannerLab.</span></div><div class="rule warning"><span class="dot"></span><span>Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.</span></div></div>
    <div class="actions"><button class="secondary" id="manageProjects">${icon('folder')} Mes projets</button><button class="primary" id="newProject">${icon('plus')} Nouveau projet</button></div>`);
  $('.close',sh).onclick=closeSheet;$('#manageProjects',sh).onclick=()=>openProjectsSheet();$('#newProject',sh).onclick=()=>createNewProject();
}

function freshEditor(name='Ma fresque'){
  state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0};state.texts=[];state.active='background';state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  $('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name='Nouvelle fresque'){
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();await saveProject();closeSheet();toast('Nouveau projet créé avec Redacted');
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||'Sans nom')}</strong><span>${(d.rows||3)*6} missions${updated?' · '+escapeHtml(updated):''}</span></div>${current?'<span class="currentbadge">Ouvert</span>':''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>Ouvrir</button><button class="secondary renameproject">${icon('edit')} Renommer</button><button class="secondary duplicateproject">${icon('copy')} Copier</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||'<div class="small">Aucun projet enregistré.</div>';
  const sh=openSheet(`<div class="sheethead"><div><h2>Mes projets</h2><p>${projects.length} projet(s) enregistré(s) sur ce téléphone.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="projectlist">${cards}</div><div class="actions"><button class="primary" id="createProject">${icon('plus')} Nouveau projet</button></div>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}
async function switchProject(id){await saveProject();await loadProject(id);closeSheet();toast(`Projet ouvert : ${state.name}`)}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>Renommer le projet</h2><p>Un nom humainement reconnaissable, concept révolutionnaire.</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>Nom du projet</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||'Ma fresque')}"></div><div class="actions"><button class="secondary cancel">Annuler</button><button class="primary save">Enregistrer</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||'Ma fresque';const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;$('#projectName').value=name}closeSheet();toast('Projet renommé')};
}
async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>Supprimer ce projet ?</h2><p>${escapeHtml(rec.data?.name||'Sans nom')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>La fresque et son image enregistrée localement seront supprimées.</span></div><div class="actions"><button class="secondary cancel">Annuler</button><button class="danger confirmdelete">${icon('trash')} Supprimer</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}
async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||'Fresque'} copie`;data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob});await txDone(tx2);await loadProject(newId);closeSheet();toast('Copie créée');
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast('Projet supprimé');
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation},texts:state.texts,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject(){try{const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current')}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();await saveProject();return}
    freshEditor();state.projectId=target;
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[]});
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

if(Capacitor.isNativePlatform()){
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url)}).catch?.(()=>{});
  App.getLaunchUrl().then(r=>{if(r?.url)handleBridgeUrl(r.url)}).catch(()=>{});
}
window.addEventListener('resize',render);
if('serviceWorker' in navigator&&!Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();migrateLegacyStorage().then(()=>loadProject());
