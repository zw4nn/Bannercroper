import './style.css';
import JSZip from 'jszip';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import QRCode from 'qrcode';
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { IntentLauncher, ActivityAction } from '@capgo/capacitor-intent-launcher';

const APP_VERSION = '1.0.10';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;
const MissionOverlay = registerPlugin('MissionOverlay');
const BackupFolder = registerPlugin('BackupFolder');
const LocationStatus = registerPlugin('LocationStatus');
const BANNERGRESS_API='https://api.bannergress.com';
const VALHALLA_API='https://valhalla1.openstreetmap.de/route';
const VALHALLA_MAX_POINTS=10;
const BANNER_WALK_CACHE_PREFIX='rbl-banner-walk-v5:';
const BANNER_FAVORITES_KEY='rbl-bannergress-favorites-v1';
const PLAY_SESSION_KEY='rbl-play-session-v1';
const PLAY_PENDING_KEY='rbl-play-pending-v1';
const BANNER_TODO_KEY='rbl-bannergress-todo-v1';
const PLAY_HISTORY_KEY='rbl-play-history-v1';
const BACKUP_AUTO_KEY='rbl-backup-auto-v1';
const BACKUP_LAST_KEY='rbl-backup-last-v1';
const BACKUP_FILE_NAME='Redacted_BannerLab_Autosave.json';
const TUTORIAL_AUTO_KEY='rbl-tutorial-auto-v1';
const TUTORIAL_PROMPT_SESSION_KEY='rbl-tutorial-prompted-v1';
const TUTORIAL_SEEN_PREFIX='rbl-tutorial-seen-v1:';
let backupInProgress=false;
let backupRevision=1;
let lastBackedRevision=0;
let backupAutoTimer=null;
let backupAppActive=true;

const SUPPORTED_LANGS=['fr','en','es'];
let APP_LANG=localStorage.getItem('rbl-language')||((navigator.language||'fr').toLowerCase().startsWith('es')?'es':(navigator.language||'fr').toLowerCase().startsWith('en')?'en':'fr');
if(!SUPPORTED_LANGS.includes(APP_LANG))APP_LANG='fr';
const I18N={
  fr:{
    fresco:'Fresque',route:'Parcours',missions:'Missions',publish:'Publier',projects:'Projets',rows:'Rangées',
    image:'Images',framing:'Cadrage',layers:'Calques',text:'Texte',preview:'Aperçu',export:'Exporter',
    wholeFresco:'Fresque entière',oneMission:'Une mission',noMission:'Aucune mission sélectionnée',
    addImage:'Ajoute ton image',imageHint:'Elle sera cadrée directement sur la géométrie Prime.',
    circles:'Cercles Prime',grid:'Grille 512',numbers:'Numéros',enlarge:'Agrandir mission',resetMission:'Réinitialiser mission',
    prev:'Précédente',next:'Suivante',complete:'Mission complète',remaining:'Encore {n} portail(s)',
    openIitc:'Ouvrir IITC Companion',tutorial:'Tutoriel',installPlugin:'Installer / mettre à jour le plugin IITC',
    autoAdvance:'Passer automatiquement à la mission suivante à {n} portails',
    reuseLast:'Reprendre automatiquement le dernier portail comme premier de la mission suivante',
    noPortal:'Aucun portail pour cette mission.',
    action:'Action',hack:'Hack',mod:'Installer un mod',capture:'Capturer / améliorer',link:'Créer un lien',field:'Créer un champ',passphrase:'Passphrase',
    question:'Question',answer:'Réponse attendue',save:'Enregistrer',cancel:'Annuler',
    settings:'Réglages communs',commonDesc:'Description commune',titleFormat:'Format des titres',defaultType:'Type par défaut',
    location:'Localisation',visible:'Visible',hidden:'Cachée',sequential:'Séquentielle',anyOrder:'Ordre libre',
    portalsPerMission:'Portails / mission',editMission:'Éditer la mission',title:'Titre',description:'Description',
    missionReady:'Prête',missionIncomplete:'Incomplète',openRoute:'Modifier le parcours',
    publishPack:'Créer le pack BannerLab',openMat:'Ouvrir Mission Authoring Tool',
    ownWorkflow:'BannerLab utilise désormais son propre format de projet et son propre pack de publication.',
    language:'Langue',french:'Français',english:'English',spanish:'Español',
    companionStats:'Stats piétonnes dans IITC',companionStatsDesc:'Dans le mini panneau IITC : 📊 Stats inutiles calcule les km à pied estimés, temps, détour et autres absurdités.',
    duplicateBad:'{n} réutilisation(s) de portail à vérifier.',handoverOk:'La reprise fin → début de mission est autorisée.',
    pluginVersion:'Companion 0.6.3',
    undo:'Annuler',redo:'Rétablir'
  },
  en:{
    fresco:'Banner',route:'Route',missions:'Missions',publish:'Publish',projects:'Projects',rows:'Rows',
    image:'Images',framing:'Framing',layers:'Layers',text:'Text',preview:'Preview',export:'Export',
    wholeFresco:'Whole banner',oneMission:'One mission',noMission:'No mission selected',
    addImage:'Add your image',imageHint:'It will be framed directly on the Prime geometry.',
    circles:'Prime circles',grid:'512 grid',numbers:'Numbers',enlarge:'Enlarge mission',resetMission:'Reset mission',
    prev:'Previous',next:'Next',complete:'Mission complete',remaining:'{n} portal(s) remaining',
    openIitc:'Open IITC Companion',tutorial:'Tutorial',installPlugin:'Install / update IITC plugin',
    autoAdvance:'Automatically move to next mission at {n} portals',
    reuseLast:'Automatically reuse the last portal as the first portal of the next mission',
    noPortal:'No portal in this mission.',
    action:'Action',hack:'Hack',mod:'Install a mod',capture:'Capture / upgrade',link:'Create a link',field:'Create a field',passphrase:'Passphrase',
    question:'Question',answer:'Expected answer',save:'Save',cancel:'Cancel',
    settings:'Common settings',commonDesc:'Common description',titleFormat:'Title format',defaultType:'Default type',
    location:'Location',visible:'Visible',hidden:'Hidden',sequential:'Sequential',anyOrder:'Any order',
    portalsPerMission:'Portals / mission',editMission:'Edit mission',title:'Title',description:'Description',
    missionReady:'Ready',missionIncomplete:'Incomplete',openRoute:'Edit route',
    publishPack:'Create BannerLab pack',openMat:'Open Mission Authoring Tool',
    ownWorkflow:'BannerLab now uses its own project format and publication pack.',
    language:'Language',french:'Français',english:'English',spanish:'Español',
    companionStats:'Walking stats in IITC',companionStatsDesc:'In the IITC mini panel: 📊 Useless stats calculates estimated walking distance, time, detour and other nonsense.',
    duplicateBad:'{n} portal reuse(s) to review.',handoverOk:'Mission-end → next-start reuse is allowed.',
    pluginVersion:'Companion 0.6.3',
    undo:'Undo',redo:'Redo'
  },
  es:{
    fresco:'Mosaico',route:'Recorrido',missions:'Misiones',publish:'Publicar',projects:'Proyectos',rows:'Filas',
    image:'Imágenes',framing:'Encuadre',layers:'Capas',text:'Texto',preview:'Vista previa',export:'Exportar',
    wholeFresco:'Mosaico completo',oneMission:'Una misión',noMission:'Ninguna misión seleccionada',
    addImage:'Añade tu imagen',imageHint:'Se encuadrará directamente con la geometría Prime.',
    circles:'Círculos Prime',grid:'Cuadrícula 512',numbers:'Números',enlarge:'Ampliar misión',resetMission:'Restablecer misión',
    prev:'Anterior',next:'Siguiente',complete:'Misión completa',remaining:'Faltan {n} portal(es)',
    openIitc:'Abrir IITC Companion',tutorial:'Tutorial',installPlugin:'Instalar / actualizar plugin IITC',
    autoAdvance:'Pasar automáticamente a la siguiente misión al llegar a {n} portales',
    reuseLast:'Reutilizar automáticamente el último portal como primero de la siguiente misión',
    noPortal:'No hay portales en esta misión.',
    action:'Acción',hack:'Hackear',mod:'Instalar un mod',capture:'Capturar / mejorar',link:'Crear un enlace',field:'Crear un campo',passphrase:'Contraseña',
    question:'Pregunta',answer:'Respuesta esperada',save:'Guardar',cancel:'Cancelar',
    settings:'Ajustes comunes',commonDesc:'Descripción común',titleFormat:'Formato de títulos',defaultType:'Tipo predeterminado',
    location:'Ubicación',visible:'Visible',hidden:'Oculta',sequential:'Secuencial',anyOrder:'Cualquier orden',
    portalsPerMission:'Portales / misión',editMission:'Editar misión',title:'Título',description:'Descripción',
    missionReady:'Lista',missionIncomplete:'Incompleta',openRoute:'Editar recorrido',
    publishPack:'Crear paquete BannerLab',openMat:'Abrir Mission Authoring Tool',
    ownWorkflow:'BannerLab usa ahora su propio formato de proyecto y paquete de publicación.',
    language:'Idioma',french:'Français',english:'English',spanish:'Español',
    companionStats:'Estadísticas a pie en IITC',companionStatsDesc:'En el mini panel IITC: 📊 Stats inútiles calcula distancia a pie estimada, tiempo, desvío y otras tonterías.',
    duplicateBad:'{n} reutilización(es) de portal para revisar.',handoverOk:'Se permite reutilizar fin de misión → inicio de la siguiente.',
    pluginVersion:'Companion 0.6.3',
    undo:'Deshacer',redo:'Rehacer'
  }
};
Object.assign(I18N.fr,{"subtitle":"Fresques Ingress Prime","source":"source","bannerHelp":"<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.","missionHelp":"<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi le déplacer ici à 1 doigt.","missionSelected":"Mission {n} sélectionnée","tapMedallion":"Touche un médaillon","touchMissionFirst":"Touche d’abord la mission que tu veux recadrer.","selectMissionFirst":"Sélectionne d’abord une mission.","heavyImage":"Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.","imported":"{w} × {h} px importés","textLayerDesc":"Chaque texte reste un calque indépendant, modifiable ou supprimable.","layer":"Calque","newText":"+ Nouveau texte","size":"Taille","outline":"Contour","color":"Couleur","outlineColor":"Couleur contour","add":"Ajouter","update":"Mettre à jour","delete":"Supprimer","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotation","center":"Centrer","reset":"Réinitialiser","done":"Terminé","transformText":"Transformer le texte","frameImage":"Cadrer l’image","pinchHint":"Le geste à deux doigts reste disponible directement sur la fresque.","missionCropOnly":"Ce cadrage ne touche qu’à ce médaillon.","resetThisMission":"Réinitialiser cette mission","individualCrop":"Recadrage individuel · 512 × 512","oneFinger":"1 doigt","move":"déplacer","twoFingers":"2 doigts","zoomRotate":"zoomer et tourner","previewPrime":"Aperçu Prime","previewApplied":"Les recadrages individuels sont déjà appliqués.","previewOrder":"Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.","exportTitle":"Exporter {n} missions","exportIntro":"Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.","noBackground":"Aucune image de fond n’est chargée.","missionFormat":"Format des missions","jpgFast":"JPG rapide · qualité élevée","pngLossless":"PNG sans perte · plus lent","fastEncoding":"Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.","rowRender":"Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.","adjusted":"{n} mission(s) avec recadrage individuel.","nianticCheck":"Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.","ready":"Prêt.","createZip":"Créer le ZIP","zipAssembly":"Assemblage du ZIP…","zipCreated":"ZIP créé.","zipDownloaded":"ZIP téléchargé.","saveShareZip":"Enregistrer ou partager le ZIP","exportFinished":"Export {format} terminé","exportFailed":"L’export a échoué.","newProject":"Nouveau projet","myProjects":"Mes projets","projectsSaved":"{n} projet(s) enregistré(s) sur ce téléphone.","unnamed":"Sans nom","opened":"Ouvert","open":"Ouvrir","rename":"Renommer","copy":"Copier","noSavedProject":"Aucun projet enregistré.","renameProject":"Renommer le projet","renameHint":"Un nom humainement reconnaissable, concept révolutionnaire.","projectName":"Nom du projet","projectOpened":"Projet ouvert : {name}","projectRenamed":"Projet renommé","deleteProject":"Supprimer ce projet ?","deleteWarning":"La fresque et son image enregistrée localement seront supprimées.","copyCreated":"Copie créée","projectDeleted":"Projet supprimé","newProjectCreated":"Nouveau projet créé avec Redacted","defaultProject":"Ma fresque","defaultNewProject":"Nouvelle fresque","copySuffix":"copie","versionLabel":"Version","infoPrime":"6 colonnes · 544 px · crop 512 px.","infoPlanner":"actions portail, passphrases, reprise fin→début et pack BannerLab natif.","infoCompanion":"parcours, actions, tracés multi-missions, options et statistiques piétonnes.","disclaimer":"Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.","titleTokens":"$T = nom · $N = numéro · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.3. Dans IITC Mobile, remplace la version précédente. Si IITC refuse de l’écraser, supprime une fois l’ancien plugin puis installe ce fichier.","pluginDialog":"Installer / mettre à jour Companion 0.6.3","pluginShareFailed":"Impossible de partager le plugin IITC.","intelOpened":"IITC Mobile ouvert avec le projet BannerLab.","intelPrimeOpened":"IITC Prime ouvert avec le projet BannerLab.","intelFallback":"IITC Mobile ouvert. Le Companion utilisera son dernier état synchronisé.","intelPrimeFallback":"IITC Prime ouvert. Le Companion utilisera son dernier état synchronisé.","intelBrowser":"IITC non détecté : ouverture dans le navigateur.","tutorialIntro":"Construis toute la bannière dans IITC sans revenir dans BannerLab après chaque portail.","tut1Title":"Installe le plugin une seule fois","tut1Text":"Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.","tut2Title":"Ouvre IITC depuis BannerLab","tut2Text":"BannerLab transmet le projet, la mission active et la langue au Companion via un fragment local que le serveur Intel ne reçoit pas.","tut3Title":"Construis directement sur la carte","tut3Text":"Le Companion permet d’ajouter, modifier ou retirer des portails, changer de mission et visualiser les tracés sans revenir dans BannerLab.","tut4Title":"Synchronise quand tu as fini","tut4Text":"Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.","tutNote":"Tu peux déplacer et redimensionner le Companion et ranger ses réglages dans Options.","installUpdate":"Installer / mettre à jour","emptyTitleIssue":"Mission {n} : titre vide","emptyDescIssue":"Mission {n} : description vide","portalsIssue":"Mission {n} : {count}/{need} portails","missingGuidIssue":"Mission {n} : {count} GUID manquant(s)","passIssue":"Mission {n} : {count} passphrase(s) incomplète(s)","reviewCount":"{n} point(s) à vérifier","projectReady":"Projet BannerLab prêt","fixBeforePublish":"Corrige les éléments avant publication.","publisherDesc":"Le prochain pont remplira le Mission Authoring Tool directement depuis ce format natif. La soumission finale restera volontairement faite dans l’outil officiel.","packCreating":"Création du pack BannerLab…","packCreated":"Pack BannerLab créé","exportImpossible":"Export impossible : {error}","missionResetDone":"Mission {n} réinitialisée","textDeleted":"Texte supprimé","histImport":"Importer image","histMissionZoom":"Zoom mission","histMissionRotation":"Rotation mission","histTextRotation":"Rotation texte","histImageRotation":"Rotation image","histTextZoom":"Zoom texte","histImageZoom":"Zoom image","histCenterText":"Centrer texte","histCenterImage":"Centrer image","histResetText":"Réinitialiser texte","histResetImage":"Réinitialiser image","histResetMission":"Réinitialiser mission","histDeleteText":"Supprimer texte","histAddText":"Ajouter texte","histEditText":"Modifier texte"});
Object.assign(I18N.en,{"subtitle":"Ingress Prime banners","source":"source","bannerHelp":"<b>Banner mode:</b> 1 finger moves the selected layer. <b>2 fingers</b> zoom and rotate.","missionHelp":"<b>Mission mode:</b> tap a medallion. For comfortable editing, use <b>Enlarge mission</b>. You can also move it here with 1 finger.","missionSelected":"Mission {n} selected","tapMedallion":"Tap a medallion","touchMissionFirst":"Tap the mission you want to reframe first.","selectMissionFirst":"Select a mission first.","heavyImage":"Very large image. It may make your phone reconsider its life choices.","imported":"Imported {w} × {h} px","textLayerDesc":"Each text remains an independent layer that can be edited or deleted.","layer":"Layer","newText":"+ New text","size":"Size","outline":"Outline","color":"Color","outlineColor":"Outline color","add":"Add","update":"Update","delete":"Delete","zoom":"Zoom","localZoom":"Local zoom","rotation":"Rotation","center":"Center","reset":"Reset","done":"Done","transformText":"Transform text","frameImage":"Frame image","pinchHint":"Two-finger gestures remain available directly on the banner.","missionCropOnly":"This framing only affects this medallion.","resetThisMission":"Reset this mission","individualCrop":"Individual framing · 512 × 512","oneFinger":"1 finger","move":"move","twoFingers":"2 fingers","zoomRotate":"zoom and rotate","previewPrime":"Prime preview","previewApplied":"Individual mission adjustments are already applied.","previewOrder":"Number 1 is bottom-right, then numbering goes left and upward through the rows.","exportTitle":"Export {n} missions","exportIntro":"Choose speed or lossless PNG. Both stay at 512 × 512.","noBackground":"No background image is loaded.","missionFormat":"Mission format","jpgFast":"Fast JPG · high quality","pngLossless":"Lossless PNG · slower","fastEncoding":"Fast mode avoids PNG encoding, which is by far the slowest part on a phone.","rowRender":"The background is rendered once per row instead of being recalculated six times.","adjusted":"{n} mission(s) with individual framing.","nianticCheck":"Check Niantic rules before submission: image rights, relevant content, and no dominant single character.","ready":"Ready.","createZip":"Create ZIP","zipAssembly":"Building ZIP…","zipCreated":"ZIP created.","zipDownloaded":"ZIP downloaded.","saveShareZip":"Save or share ZIP","exportFinished":"{format} export complete","exportFailed":"Export failed.","newProject":"New project","myProjects":"My projects","projectsSaved":"{n} project(s) saved on this phone.","unnamed":"Unnamed","opened":"Open","open":"Open","rename":"Rename","copy":"Copy","noSavedProject":"No saved project.","renameProject":"Rename project","renameHint":"A human-readable name. A surprisingly advanced concept.","projectName":"Project name","projectOpened":"Project opened: {name}","projectRenamed":"Project renamed","deleteProject":"Delete this project?","deleteWarning":"The banner and its locally stored image will be deleted.","copyCreated":"Copy created","projectDeleted":"Project deleted","newProjectCreated":"New project created with Redacted","defaultProject":"My banner","defaultNewProject":"New banner","copySuffix":"copy","versionLabel":"Version","infoPrime":"6 columns · 544 px · 512 px crop.","infoPlanner":"portal actions, passphrases, end→start handover and native BannerLab pack.","infoCompanion":"routes, actions, multi-mission tracks, options and walking stats.","disclaimer":"Ingress and Ingress Prime are Niantic trademarks. Redacted BannerLab is not affiliated with or endorsed by Niantic.","titleTokens":"$T = name · $N = number · $M = total · $0N = 01, 02…","pluginShareText":"Companion plugin 0.6.0. Replace the previous version in IITC Mobile. If IITC refuses to overwrite it, remove the old plugin once and install this file.","pluginDialog":"Install / update Companion 0.6.3","pluginShareFailed":"Unable to share the IITC plugin.","intelOpened":"IITC Mobile opened with the BannerLab project.","intelPrimeOpened":"IITC Prime opened with the BannerLab project.","intelFallback":"IITC Mobile opened. The Companion will use its last synchronized state.","intelPrimeFallback":"IITC Prime opened. The Companion will use its last synchronized state.","intelBrowser":"IITC not detected: opening in browser.","tutorialIntro":"Build the whole banner in IITC without returning to BannerLab after every portal.","tut1Title":"Install the plugin once","tut1Text":"From Route, use “Install / update IITC plugin”, then add the file as a user plugin in IITC Mobile.","tut2Title":"Open IITC from BannerLab","tut2Text":"BannerLab sends the project, active mission and language to the Companion through a local fragment that the Intel server never receives.","tut3Title":"Build directly on the map","tut3Text":"The Companion lets you add, edit or remove portals, change missions and see routes without returning to BannerLab.","tut4Title":"Sync when you are done","tut4Text":"“Sync BannerLab” sends all edited missions back to the project and reopens BannerLab.","tutNote":"You can move and resize the Companion and keep its settings inside Options.","installUpdate":"Install / update","emptyTitleIssue":"Mission {n}: empty title","emptyDescIssue":"Mission {n}: empty description","portalsIssue":"Mission {n}: {count}/{need} portals","missingGuidIssue":"Mission {n}: {count} missing GUID(s)","passIssue":"Mission {n}: {count} incomplete passphrase(s)","reviewCount":"{n} item(s) to review","projectReady":"BannerLab project ready","fixBeforePublish":"Fix these items before publishing.","publisherDesc":"The next bridge will fill the Mission Authoring Tool directly from this native format. Final submission will deliberately remain in the official tool.","packCreating":"Creating BannerLab pack…","packCreated":"BannerLab pack created","exportImpossible":"Export impossible: {error}","missionResetDone":"Mission {n} reset","textDeleted":"Text deleted","histImport":"Import image","histMissionZoom":"Mission zoom","histMissionRotation":"Mission rotation","histTextRotation":"Text rotation","histImageRotation":"Image rotation","histTextZoom":"Text zoom","histImageZoom":"Image zoom","histCenterText":"Center text","histCenterImage":"Center image","histResetText":"Reset text","histResetImage":"Reset image","histResetMission":"Reset mission","histDeleteText":"Delete text","histAddText":"Add text","histEditText":"Edit text"});
Object.assign(I18N.es,{"subtitle":"Mosaicos de Ingress Prime","source":"fuente","bannerHelp":"<b>Modo mosaico:</b> 1 dedo mueve la capa seleccionada. <b>2 dedos</b> amplían y giran.","missionHelp":"<b>Modo misión:</b> toca un medallón. Para trabajar cómodamente, usa <b>Ampliar misión</b>. También puedes moverlo aquí con 1 dedo.","missionSelected":"Misión {n} seleccionada","tapMedallion":"Toca un medallón","touchMissionFirst":"Toca primero la misión que quieres reencuadrar.","selectMissionFirst":"Selecciona primero una misión.","heavyImage":"Imagen muy pesada. Puede poner de rodillas al teléfono, lo cual sería bastante humillante.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto sigue siendo una capa independiente, editable o eliminable.","layer":"Capa","newText":"+ Nuevo texto","size":"Tamaño","outline":"Contorno","color":"Color","outlineColor":"Color del contorno","add":"Añadir","update":"Actualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotación","center":"Centrar","reset":"Restablecer","done":"Hecho","transformText":"Transformar texto","frameImage":"Encuadrar imagen","pinchHint":"El gesto con dos dedos sigue disponible directamente sobre el mosaico.","missionCropOnly":"Este encuadre solo afecta a este medallón.","resetThisMission":"Restablecer esta misión","individualCrop":"Encuadre individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"ampliar y girar","previewPrime":"Vista previa Prime","previewApplied":"Los ajustes individuales de las misiones ya están aplicados.","previewOrder":"El número 1 está abajo a la derecha; después la numeración avanza hacia la izquierda y sube por las filas.","exportTitle":"Exportar {n} misiones","exportIntro":"Elige velocidad o PNG sin pérdida. Ambos siguen en 512 × 512.","noBackground":"No hay imagen de fondo cargada.","missionFormat":"Formato de las misiones","jpgFast":"JPG rápido · alta calidad","pngLossless":"PNG sin pérdida · más lento","fastEncoding":"El modo rápido evita codificar PNG, que es con diferencia la parte más lenta en el teléfono.","rowRender":"El fondo se renderiza una sola vez por fila en vez de recalcularse seis veces.","adjusted":"{n} misión(es) con encuadre individual.","nianticCheck":"Comprueba las reglas de Niantic antes de enviar: derechos de imagen, contenido pertinente y ningún carácter único dominante.","ready":"Listo.","createZip":"Crear ZIP","zipAssembly":"Montando ZIP…","zipCreated":"ZIP creado.","zipDownloaded":"ZIP descargado.","saveShareZip":"Guardar o compartir ZIP","exportFinished":"Exportación {format} terminada","exportFailed":"La exportación ha fallado.","newProject":"Nuevo proyecto","myProjects":"Mis proyectos","projectsSaved":"{n} proyecto(s) guardado(s) en este teléfono.","unnamed":"Sin nombre","opened":"Abierto","open":"Abrir","rename":"Renombrar","copy":"Copiar","noSavedProject":"No hay proyectos guardados.","renameProject":"Renombrar proyecto","renameHint":"Un nombre reconocible por humanos. Concepto sorprendentemente avanzado.","projectName":"Nombre del proyecto","projectOpened":"Proyecto abierto: {name}","projectRenamed":"Proyecto renombrado","deleteProject":"¿Eliminar este proyecto?","deleteWarning":"Se eliminarán el mosaico y su imagen guardada localmente.","copyCreated":"Copia creada","projectDeleted":"Proyecto eliminado","newProjectCreated":"Nuevo proyecto creado con Redacted","defaultProject":"Mi mosaico","defaultNewProject":"Nuevo mosaico","copySuffix":"copia","versionLabel":"Versión","infoPrime":"6 columnas · 544 px · recorte 512 px.","infoPlanner":"acciones de portal, contraseñas, continuidad fin→inicio y paquete BannerLab nativo.","infoCompanion":"recorridos, acciones, trazados multi-misión, opciones y estadísticas a pie.","disclaimer":"Ingress e Ingress Prime son marcas de Niantic. Redacted BannerLab no está afiliado ni aprobado por Niantic.","titleTokens":"$T = nombre · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.3. Sustituye la versión anterior en IITC Mobile. Si IITC se niega a sobrescribirla, elimina una vez el plugin antiguo e instala este archivo.","pluginDialog":"Instalar / actualizar Companion 0.6.3","pluginShareFailed":"No se puede compartir el plugin IITC.","intelOpened":"IITC Mobile abierto con el proyecto BannerLab.","intelPrimeOpened":"IITC Prime abierto con el proyecto BannerLab.","intelFallback":"IITC Mobile abierto. Companion usará su último estado sincronizado.","intelPrimeFallback":"IITC Prime abierto. Companion usará su último estado sincronizado.","intelBrowser":"IITC no detectado: apertura en el navegador.","tutorialIntro":"Construye todo el mosaico en IITC sin volver a BannerLab después de cada portal.","tut1Title":"Instala el plugin una sola vez","tut1Text":"En Recorrido, usa « Instalar / actualizar plugin IITC » y añade el archivo como plugin de usuario en IITC Mobile.","tut2Title":"Abre IITC desde BannerLab","tut2Text":"BannerLab transmite el proyecto, la misión activa y el idioma al Companion mediante un fragmento local que el servidor Intel nunca recibe.","tut3Title":"Construye directamente en el mapa","tut3Text":"Companion permite añadir, modificar o quitar portales, cambiar de misión y ver los trazados sin volver a BannerLab.","tut4Title":"Sincroniza al terminar","tut4Text":"« Sincronizar BannerLab » devuelve todas las misiones modificadas al proyecto y vuelve a abrir BannerLab.","tutNote":"Puedes mover y redimensionar el Companion y guardar sus ajustes dentro de Opciones.","installUpdate":"Instalar / actualizar","emptyTitleIssue":"Misión {n}: título vacío","emptyDescIssue":"Misión {n}: descripción vacía","portalsIssue":"Misión {n}: {count}/{need} portales","missingGuidIssue":"Misión {n}: {count} GUID ausente(s)","passIssue":"Misión {n}: {count} contraseña(s) incompleta(s)","reviewCount":"{n} punto(s) por revisar","projectReady":"Proyecto BannerLab listo","fixBeforePublish":"Corrige estos elementos antes de publicar.","publisherDesc":"El próximo puente rellenará Mission Authoring Tool directamente desde este formato nativo. El envío final seguirá haciéndose voluntariamente en la herramienta oficial.","packCreating":"Creando paquete BannerLab…","packCreated":"Paquete BannerLab creado","exportImpossible":"Exportación imposible: {error}","missionResetDone":"Misión {n} restablecida","textDeleted":"Texto eliminado","histImport":"Importar imagen","histMissionZoom":"Zoom de misión","histMissionRotation":"Rotación de misión","histTextRotation":"Rotación de texto","histImageRotation":"Rotación de imagen","histTextZoom":"Zoom de texto","histImageZoom":"Zoom de imagen","histCenterText":"Centrar texto","histCenterImage":"Centrar imagen","histResetText":"Restablecer texto","histResetImage":"Restablecer imagen","histResetMission":"Restablecer misión","histDeleteText":"Eliminar texto","histAddText":"Añadir texto","histEditText":"Editar texto"});
Object.assign(I18N.fr,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directement depuis le Companion.","handoverDetail":"Le dernier portail peut devenir le premier de la mission suivante sans être considéré comme un doublon fautif.","coordsMissing":"Coordonnées introuvables.","coordsInvalid":"Coordonnées invalides.","duplicateElsewhere":"Ce portail est déjà utilisé ailleurs dans la bannière.","missionCompleteAdded":"Mission {n} complète · {next}","portalAdded":"Portail ajouté · mission {n}","syncOld":"Parcours synchronisé · ancien Companion détecté : installe la version 0.6.0.","syncOk":"Parcours IITC synchronisé · Companion {v}.","portalDefault":"Portail","bannerDefault":"Fresque"});
Object.assign(I18N.en,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directly from the Companion.","handoverDetail":"The last portal can become the first of the next mission without being treated as an invalid duplicate.","coordsMissing":"Coordinates not found.","coordsInvalid":"Invalid coordinates.","duplicateElsewhere":"This portal is already used elsewhere in the banner.","missionCompleteAdded":"Mission {n} complete · {next}","portalAdded":"Portal added · mission {n}","syncOld":"Route synchronized · old Companion detected: install version 0.6.0.","syncOk":"IITC route synchronized · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner"});
Object.assign(I18N.es,{"routeActionHelp":"Hack / Mod / Captura / Link / Field / Contraseña directamente desde Companion.","handoverDetail":"El último portal puede ser el primero de la siguiente misión sin considerarse un duplicado incorrecto.","coordsMissing":"No se han encontrado coordenadas.","coordsInvalid":"Coordenadas no válidas.","duplicateElsewhere":"Este portal ya se utiliza en otra parte del mosaico.","missionCompleteAdded":"Misión {n} completa · {next}","portalAdded":"Portal añadido · misión {n}","syncOld":"Recorrido sincronizado · Companion antiguo detectado: instala la versión 0.6.0.","syncOk":"Recorrido IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Mosaico"});
Object.assign(I18N.fr,{"livePublish":"Préparer directement dans Mission Authoring","livePublishShort":"Publisher direct","livePreparing":"Préparation des {n} missions pour le Publisher…","liveReady":"Ouverture du Publisher intégré…","liveNativeOnly":"Le Publisher direct est disponible dans l’APK Android.","liveFailed":"Impossible d’ouvrir le Publisher : {error}","liveExperimental":"Expérimental : Mission Authoring s’ouvre dans une vue intégrée à RBL. La connexion Google est la première chose à valider sur ton téléphone.","backupTransfer":"Sauvegarde / transfert","exportPackBackup":"Exporter un pack BannerLab","openOfficialOnly":"Ouvrir le site officiel seulement","publisherPreparingImage":"Rendu mission {n}/{total}…"});
Object.assign(I18N.en,{"livePublish":"Prepare directly in Mission Authoring","livePublishShort":"Direct Publisher","livePreparing":"Preparing {n} missions for Publisher…","liveReady":"Opening integrated Publisher…","liveNativeOnly":"Direct Publisher is available in the Android APK.","liveFailed":"Unable to open Publisher: {error}","liveExperimental":"Experimental: Mission Authoring opens inside an RBL-controlled view. Google sign-in is the first thing to validate on your phone.","backupTransfer":"Backup / transfer","exportPackBackup":"Export BannerLab pack","openOfficialOnly":"Open official site only","publisherPreparingImage":"Rendering mission {n}/{total}…"});
Object.assign(I18N.es,{"livePublish":"Preparar directamente en Mission Authoring","livePublishShort":"Publisher directo","livePreparing":"Preparando {n} misiones para Publisher…","liveReady":"Abriendo Publisher integrado…","liveNativeOnly":"Publisher directo está disponible en la APK Android.","liveFailed":"No se puede abrir Publisher: {error}","liveExperimental":"Experimental: Mission Authoring se abre en una vista controlada por RBL. El inicio de sesión de Google es lo primero que hay que validar en tu teléfono.","backupTransfer":"Copia / transferencia","exportPackBackup":"Exportar paquete BannerLab","openOfficialOnly":"Abrir solo el sitio oficial","publisherPreparingImage":"Renderizando misión {n}/{total}…"});
Object.assign(I18N.fr,{"browserPublish":"Publier dans Firefox","browserPublishShort":"Publisher navigateur","browserSetup":"Installer / mettre à jour le Publisher navigateur","browserPreparing":"Préparation de la mission {n}/{total}…","browserOpening":"Ouverture de Firefox…","browserNeed":"Le Publisher direct utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.","browserFailed":"Impossible d’ouvrir le Publisher : {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 pour missions.ingress.com. À installer une fois dans Violentmonkey sur Firefox Android.","browserShareDialog":"Installer Publisher 0.4.0","browserShareFailed":"Impossible de partager le Publisher navigateur.","publisherUrlTooLarge":"La mission est trop lourde à transmettre au navigateur.","publisherReturn":"Retour du Publisher.","publisherNoFirefox":"Firefox n’a pas été détecté. Ouverture dans le navigateur par défaut, mais le Publisher nécessite un navigateur avec userscripts."});
Object.assign(I18N.en,{"browserPublish":"Publish in Firefox","browserPublishShort":"Browser Publisher","browserSetup":"Install / update Browser Publisher","browserPreparing":"Preparing mission {n}/{total}…","browserOpening":"Opening Firefox…","browserNeed":"Direct Publisher uses Firefox Android + Violentmonkey so Google sign-in stays in a normal browser.","browserFailed":"Unable to open Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 for missions.ingress.com. Install it once in Violentmonkey on Firefox Android.","browserShareDialog":"Install Publisher 0.4.0","browserShareFailed":"Unable to share Browser Publisher.","publisherUrlTooLarge":"This mission is too large to send to the browser.","publisherReturn":"Returned from Publisher.","publisherNoFirefox":"Firefox was not detected. Opening the default browser, but Publisher requires a browser with userscript support."});
Object.assign(I18N.es,{"browserPublish":"Publicar en Firefox","browserPublishShort":"Publisher navegador","browserSetup":"Instalar / actualizar Publisher navegador","browserPreparing":"Preparando misión {n}/{total}…","browserOpening":"Abriendo Firefox…","browserNeed":"Publisher directo usa Firefox Android + Violentmonkey para mantener el inicio de sesión de Google en un navegador normal.","browserFailed":"No se puede abrir Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 para missions.ingress.com. Instálalo una vez en Violentmonkey sobre Firefox Android.","browserShareDialog":"Instalar Publisher 0.4.0","browserShareFailed":"No se puede compartir Publisher navegador.","publisherUrlTooLarge":"La misión es demasiado pesada para enviarla al navegador.","publisherReturn":"Regreso desde Publisher.","publisherNoFirefox":"Firefox no detectado. Se abre el navegador predeterminado, pero Publisher necesita un navegador compatible con userscripts."});
Object.assign(I18N.fr,{"publisherBrowser":"Navigateur de publication","chromeMode":"Chrome","chromeModeSub":"Sans appli supplémentaire · 1 favori à lancer par mission","firefoxMode":"Firefox","firefoxModeSub":"Automatique après installation de Violentmonkey + Publisher","recommendedAuto":"Automatique","noExtraApp":"Sans appli en plus","publishSelected":"Publier la mission","chromeSetup":"Configurer Chrome","firefoxSetup":"Configurer Firefox","chromeReady":"Favori Chrome vérifié","firefoxReady":"Publisher Firefox vérifié","notConfigured":"À configurer une fois","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome ne permet pas à RBL d’ajouter le favori à ta place. On réduit donc l’installation au strict minimum.","chromeStep1":"1. Copie le code du favori RBL Publisher.","chromeStep2":"2. Ouvre Mission Authoring dans Chrome et ajoute la page aux favoris.","chromeStep3":"3. Modifie ce favori : nom « RBL Publisher » et remplace son URL par le code copié.","chromeStep4":"4. Sur la page Mission Authoring, touche la barre d’adresse, tape « RBL », puis choisis le favori pour le tester.","copyBookmarklet":"Copier le code du favori","bookmarkletCopied":"Code du favori copié","openChromeSetup":"Ouvrir Chrome pour l’installation","testChrome":"Tester le favori Chrome","chromeRunHint":"Dans Chrome : touche la barre d’adresse, tape RBL puis sélectionne « RBL Publisher ».","chromeNeedsSetup":"Configure d’abord le favori Chrome RBL Publisher.","chromeOpenFail":"Impossible d’ouvrir Chrome. Ouverture dans le navigateur par défaut.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox peut charger le Publisher automatiquement grâce à Violentmonkey. C’est le mode le plus fluide.","sharePublisher":"Partager le userscript Publisher","testFirefox":"Tester le Publisher Firefox","firefoxNeedsSetup":"Installe Violentmonkey et le Publisher dans Firefox avant le test.","browserSaved":"Navigateur de publication : {browser}","setupConfirmed":"Configuration vérifiée.","bookmarkletCopyFail":"Impossible de copier automatiquement. Le code est affiché ci-dessous.","bookmarkletLabel":"Code du favori","autoImpossibleChrome":"Chargement automatique impossible dans Chrome Android sans extension ou permission intrusive. Le favori reste nécessaire.","openChromePublish":"Ouverture dans Chrome…","openFirefoxPublish":"Ouverture dans Firefox…"});
Object.assign(I18N.en,{"publisherBrowser":"Publishing browser","chromeMode":"Chrome","chromeModeSub":"No extra app · run one bookmark per mission","firefoxMode":"Firefox","firefoxModeSub":"Automatic after installing Violentmonkey + Publisher","recommendedAuto":"Automatic","noExtraApp":"No extra app","publishSelected":"Publish mission","chromeSetup":"Set up Chrome","firefoxSetup":"Set up Firefox","chromeReady":"Chrome bookmark verified","firefoxReady":"Firefox Publisher verified","notConfigured":"One-time setup required","chromeSetupTitle":"Chrome Publisher","chromeSetupIntro":"Chrome does not let RBL add the bookmark for you. Setup is therefore reduced to the minimum possible.","chromeStep1":"1. Copy the RBL Publisher bookmark code.","chromeStep2":"2. Open Mission Authoring in Chrome and bookmark the page.","chromeStep3":"3. Edit that bookmark: name it “RBL Publisher” and replace its URL with the copied code.","chromeStep4":"4. On Mission Authoring, tap the address bar, type “RBL”, then choose the bookmark to test it.","copyBookmarklet":"Copy bookmark code","bookmarkletCopied":"Bookmark code copied","openChromeSetup":"Open Chrome for setup","testChrome":"Test Chrome bookmark","chromeRunHint":"In Chrome: tap the address bar, type RBL, then select “RBL Publisher”.","chromeNeedsSetup":"Set up the RBL Publisher Chrome bookmark first.","chromeOpenFail":"Could not open Chrome. Opening the default browser.","firefoxSetupTitle":"Firefox Publisher","firefoxSetupIntro":"Firefox can load Publisher automatically through Violentmonkey. This is the smoothest mode.","sharePublisher":"Share Publisher userscript","testFirefox":"Test Firefox Publisher","firefoxNeedsSetup":"Install Violentmonkey and Publisher in Firefox before testing.","browserSaved":"Publishing browser: {browser}","setupConfirmed":"Setup verified.","bookmarkletCopyFail":"Could not copy automatically. The code is shown below.","bookmarkletLabel":"Bookmark code","autoImpossibleChrome":"Automatic loading is not possible in Chrome Android without an extension or intrusive permission. The bookmark is still required.","openChromePublish":"Opening Chrome…","openFirefoxPublish":"Opening Firefox…"});
Object.assign(I18N.es,{"publisherBrowser":"Navegador de publicación","chromeMode":"Chrome","chromeModeSub":"Sin aplicación adicional · un favorito por misión","firefoxMode":"Firefox","firefoxModeSub":"Automático tras instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sin aplicación adicional","publishSelected":"Publicar misión","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Favorito Chrome verificado","firefoxReady":"Publisher Firefox verificado","notConfigured":"Configurar una sola vez","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome no permite que RBL añada el favorito por ti. La instalación se reduce al mínimo posible.","chromeStep1":"1. Copia el código del favorito RBL Publisher.","chromeStep2":"2. Abre Mission Authoring en Chrome y añade la página a favoritos.","chromeStep3":"3. Edita ese favorito: nombre « RBL Publisher » y sustituye la URL por el código copiado.","chromeStep4":"4. En Mission Authoring, toca la barra de direcciones, escribe « RBL » y elige el favorito para probarlo.","copyBookmarklet":"Copiar código del favorito","bookmarkletCopied":"Código del favorito copiado","openChromeSetup":"Abrir Chrome para instalar","testChrome":"Probar favorito Chrome","chromeRunHint":"En Chrome: toca la barra de direcciones, escribe RBL y selecciona « RBL Publisher ».","chromeNeedsSetup":"Configura primero el favorito Chrome RBL Publisher.","chromeOpenFail":"No se puede abrir Chrome. Se abre el navegador predeterminado.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox puede cargar Publisher automáticamente con Violentmonkey. Es el modo más fluido.","sharePublisher":"Compartir userscript Publisher","testFirefox":"Probar Publisher Firefox","firefoxNeedsSetup":"Instala Violentmonkey y Publisher en Firefox antes de probar.","browserSaved":"Navegador de publicación: {browser}","setupConfirmed":"Configuración verificada.","bookmarkletCopyFail":"No se puede copiar automáticamente. El código aparece abajo.","bookmarkletLabel":"Código del favorito","autoImpossibleChrome":"La carga automática no es posible en Chrome Android sin extensión o permiso intrusivo. El favorito sigue siendo necesario.","openChromePublish":"Abriendo Chrome…","openFirefoxPublish":"Abriendo Firefox…"});
Object.assign(I18N.fr,{"chromeModeSub":"Sans appli supplémentaire · petit favori + Autoriser si demandé","chromeWizardTitle":"Configurer Chrome","chromeWizardIntro":"Une seule configuration. RBL mémorise ta progression.","chromeFileTitle":"Enregistrer le Publisher","chromeFileText":"Enregistre le petit fichier Publisher sur ton téléphone. Dans la feuille Android, choisis Fichiers / Enregistrer et garde-le par exemple dans Téléchargements.","chromeSaveFile":"Enregistrer publisher.js","chromeFileDone":"Fichier Publisher préparé","alreadySaved":"Je l’ai déjà enregistré","chromeBookmarkTitle":"Créer le mini favori","chromeBookmarkText":"Le favori ne contient plus le Publisher entier. Il fait seulement {n} caractères et sert à charger le fichier que tu viens d’enregistrer.","chromeBookmarkName":"Nom du favori : RBL Publisher","chromeBookmarkHow":"Dans Chrome : ouvre Mission Authoring → ⋮ → Ajouter aux favoris. Modifie ensuite le favori, mets « RBL Publisher » et colle le code dans URL.","copyMiniCode":"Copier le mini code","miniCodeCopied":"Mini code copié","openChromeBookmark":"Ouvrir Mission Authoring","bookmarkCreated":"J’ai créé le favori","chromeTestTitle":"Tester et autoriser","chromeTestText":"RBL ouvre Mission Authoring. Dans la barre d’adresse, tape RBL puis touche « RBL Publisher ». La première fois, Chrome te demandera de choisir publisher.js. Les fois suivantes il pourra simplement demander Autoriser.","chromeTestButton":"Tester dans Chrome","chromeTestWaiting":"Dans Chrome : tape RBL → RBL Publisher → sélectionne publisher.js si demandé → Autoriser.","chromeSetupSuccess":"Chrome est prêt","chromeSetupSuccessText":"Le favori et le fichier Publisher fonctionnent. Pour publier : RBL ouvre Chrome, tu lances RBL Publisher et tu autorises si Chrome le demande.","publishNow":"Publier maintenant","wizardPrev":"Précédent","wizardNext":"Continuer","wizardRestart":"Recommencer la configuration","stepOf":"Étape {n}/3","chromeFileShareText":"Enregistre ce fichier publisher.js dans un dossier facile à retrouver, par exemple Téléchargements. Chrome te le demandera au premier test.","chromeFileShareDialog":"Enregistrer RBL Publisher","chromeFileShareFail":"Impossible de préparer le fichier Publisher.","chromePermissionHint":"Chrome pourra redemander l’autorisation de lire publisher.js. Tu peux simplement accepter.","chromeNotAutoFavorite":"RBL ne peut pas créer un favori Chrome automatiquement. C’est la seule étape manuelle obligatoire.","codeLength":"{n} caractères","chromeStepSaved":"Étape enregistrée","chromeResetDone":"Configuration Chrome réinitialisée","chromeSelectFileHint":"Sélectionne le fichier redacted-bannerlab-publisher.user.js enregistré à l’étape 1."});
Object.assign(I18N.en,{"chromeModeSub":"No extra app · small bookmark + Allow when requested","chromeWizardTitle":"Set up Chrome","chromeWizardIntro":"One-time setup. RBL remembers your progress.","chromeFileTitle":"Save Publisher","chromeFileText":"Save the small Publisher file on your phone. In Android's share sheet, choose Files / Save and keep it somewhere easy such as Downloads.","chromeSaveFile":"Save publisher.js","chromeFileDone":"Publisher file prepared","alreadySaved":"I already saved it","chromeBookmarkTitle":"Create the mini bookmark","chromeBookmarkText":"The bookmark no longer contains the whole Publisher. It is only {n} characters and loads the file you just saved.","chromeBookmarkName":"Bookmark name: RBL Publisher","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Add to bookmarks. Then edit the bookmark, name it “RBL Publisher” and paste the code into URL.","copyMiniCode":"Copy mini code","miniCodeCopied":"Mini code copied","openChromeBookmark":"Open Mission Authoring","bookmarkCreated":"I created the bookmark","chromeTestTitle":"Test and authorize","chromeTestText":"RBL opens Mission Authoring. In the address bar type RBL, then tap “RBL Publisher”. The first time Chrome asks you to choose publisher.js. Later it may only ask Allow.","chromeTestButton":"Test in Chrome","chromeTestWaiting":"In Chrome: type RBL → RBL Publisher → select publisher.js if requested → Allow.","chromeSetupSuccess":"Chrome is ready","chromeSetupSuccessText":"The bookmark and Publisher file work. To publish: RBL opens Chrome, you run RBL Publisher and allow access if Chrome asks.","publishNow":"Publish now","wizardPrev":"Previous","wizardNext":"Continue","wizardRestart":"Restart setup","stepOf":"Step {n}/3","chromeFileShareText":"Save this publisher.js somewhere easy to find, such as Downloads. Chrome will ask for it during the first test.","chromeFileShareDialog":"Save RBL Publisher","chromeFileShareFail":"Unable to prepare Publisher file.","chromePermissionHint":"Chrome may ask again for permission to read publisher.js. You can simply allow it.","chromeNotAutoFavorite":"RBL cannot create a Chrome bookmark automatically. This is the only mandatory manual step.","codeLength":"{n} characters","chromeStepSaved":"Step saved","chromeResetDone":"Chrome setup reset","chromeSelectFileHint":"Select the redacted-bannerlab-publisher.user.js file saved in step 1."});
Object.assign(I18N.es,{"chromeModeSub":"Sin aplicación adicional · favorito pequeño + Autorizar si se solicita","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Una sola configuración. RBL recuerda tu progreso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"Guarda el pequeño archivo Publisher en el teléfono. En la hoja de Android elige Archivos / Guardar y déjalo en un lugar fácil, por ejemplo Descargas.","chromeSaveFile":"Guardar publisher.js","chromeFileDone":"Archivo Publisher preparado","alreadySaved":"Ya lo he guardado","chromeBookmarkTitle":"Crear el mini favorito","chromeBookmarkText":"El favorito ya no contiene todo el Publisher. Solo tiene {n} caracteres y carga el archivo que acabas de guardar.","chromeBookmarkName":"Nombre del favorito: RBL Publisher","chromeBookmarkHow":"En Chrome: abre Mission Authoring → ⋮ → Añadir a favoritos. Después edita el favorito, pon « RBL Publisher » y pega el código en URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"He creado el favorito","chromeTestTitle":"Probar y autorizar","chromeTestText":"RBL abre Mission Authoring. En la barra de direcciones escribe RBL y toca « RBL Publisher ». La primera vez Chrome pedirá elegir publisher.js. Después puede pedir solo Autorizar.","chromeTestButton":"Probar en Chrome","chromeTestWaiting":"En Chrome: escribe RBL → RBL Publisher → selecciona publisher.js si se solicita → Autorizar.","chromeSetupSuccess":"Chrome está listo","chromeSetupSuccessText":"El favorito y el archivo Publisher funcionan. Para publicar: RBL abre Chrome, ejecutas RBL Publisher y autorizas si Chrome lo solicita.","publishNow":"Publicar ahora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuración","stepOf":"Paso {n}/3","chromeFileShareText":"Guarda este publisher.js en un lugar fácil de encontrar, por ejemplo Descargas. Chrome lo pedirá durante la primera prueba.","chromeFileShareDialog":"Guardar RBL Publisher","chromeFileShareFail":"No se puede preparar el archivo Publisher.","chromePermissionHint":"Chrome puede volver a pedir permiso para leer publisher.js. Basta con autorizar.","chromeNotAutoFavorite":"RBL no puede crear automáticamente un favorito de Chrome. Es la única etapa manual obligatoria.","codeLength":"{n} caracteres","chromeStepSaved":"Paso guardado","chromeResetDone":"Configuración Chrome reiniciada","chromeSelectFileHint":"Selecciona el archivo redacted-bannerlab-publisher.user.js guardado en el paso 1."});
Object.assign(I18N.fr,{"bannerDescription":"Description de la bannière","required":"Obligatoire","bannerDescriptionHint":"Cette description sert de description par défaut pour toutes les missions. Tu pourras personnaliser une mission ensuite.","bannerDescriptionRequired":"La description de la bannière est obligatoire.","describeBeforePublish":"Décris d’abord la bannière","describeBeforePublishText":"Impossible de publier tant que la bannière n’a pas de description. Elle sera appliquée par défaut à toutes les missions.","saveAndContinue":"Enregistrer et continuer","missionPublishBlocked":"Mission non publiable","missionNeedsPortals":"La mission {n} contient {count}/{need} portails. Il en faut au moins {need} pour la publier.","completeMission":"Compléter la mission","currentMissionReady":"Mission prête à publier","publishBlockedHint":"Le bouton de publication reste bloqué tant que les éléments obligatoires ne sont pas complets.","minimumSix":"Minimum : 6 portails par mission","publisherDescRequired":"Le Publisher refuse une mission sans description.","publisherPortalsRequired":"Le Publisher refuse une mission avec moins de 6 portails."});
Object.assign(I18N.en,{"bannerDescription":"Banner description","required":"Required","bannerDescriptionHint":"This is the default description for every mission. You can still customize individual missions later.","bannerDescriptionRequired":"The banner description is required.","describeBeforePublish":"Describe the banner first","describeBeforePublishText":"Publishing is blocked until the banner has a description. It will be used as the default for all missions.","saveAndContinue":"Save and continue","missionPublishBlocked":"Mission cannot be published","missionNeedsPortals":"Mission {n} has {count}/{need} portals. It needs at least {need} before publishing.","completeMission":"Complete mission","currentMissionReady":"Mission ready to publish","publishBlockedHint":"Publishing remains blocked until all mandatory items are complete.","minimumSix":"Minimum: 6 portals per mission","publisherDescRequired":"Publisher refuses missions without a description.","publisherPortalsRequired":"Publisher refuses missions with fewer than 6 portals."});
Object.assign(I18N.es,{"bannerDescription":"Descripción del mosaico","required":"Obligatorio","bannerDescriptionHint":"Esta será la descripción predeterminada de todas las misiones. Después puedes personalizar cada misión.","bannerDescriptionRequired":"La descripción del mosaico es obligatoria.","describeBeforePublish":"Describe primero el mosaico","describeBeforePublishText":"No se puede publicar hasta que el mosaico tenga una descripción. Se aplicará por defecto a todas las misiones.","saveAndContinue":"Guardar y continuar","missionPublishBlocked":"Misión no publicable","missionNeedsPortals":"La misión {n} tiene {count}/{need} portales. Necesita al menos {need} para publicarla.","completeMission":"Completar misión","currentMissionReady":"Misión lista para publicar","publishBlockedHint":"El botón de publicación permanece bloqueado hasta completar los elementos obligatorios.","minimumSix":"Mínimo: 6 portales por misión","publisherDescRequired":"Publisher rechaza una misión sin descripción.","publisherPortalsRequired":"Publisher rechaza una misión con menos de 6 portales."});
Object.assign(I18N.fr,{"playBanners":"Jouer","playHub":"Jouer une bannière","searchBannergress":"Rechercher sur Bannergress","searchPlaceholder":"Nom de bannière, ville…","search":"Rechercher","favorites":"Favoris","currentBanner":"En cours","noFavorites":"Aucune bannière favorite. Pour une fois, ton stockage local respire.","noPlaySession":"Aucune bannière en cours.","searchPrompt":"Recherche directement les bannières publiques de Bannergress.","searching":"Recherche…","searchError":"Recherche Bannergress impossible : {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favori","removeFavorite":"Retirer des favoris","playThisBanner":"Jouer cette bannière","resumeBanner":"Reprendre la bannière","stopBanner":"Arrêter l’overlay","openCurrentMission":"Ouvrir la mission actuelle","overlayPermissionTitle":"Autoriser l’overlay RBL","overlayPermissionText":"Android doit autoriser Redacted BannerLab à s’afficher par-dessus Ingress. Une seule autorisation système, ensuite notre dino fait sa vie.","overlayPermissionButton":"Autoriser l’affichage par-dessus les applis","overlayPermissionWaiting":"Reviens dans RBL après avoir autorisé l’affichage.","overlayStarted":"Overlay mission démarré.","overlayFailed":"Impossible de démarrer l’overlay : {error}","bannerLoadError":"Impossible de charger cette bannière : {error}","bannerOffline":"Cette bannière ne contient aucune mission exploitable.","bannerDisabled":"{n} mission(s) désactivée(s)","addressUnknown":"Lieu non précisé","doneMissions":"{done}/{total} terminées","deepLinkOnly":"RBL ne pilote pas Ingress : l’overlay ouvre uniquement les deeplinks officiels des missions.","bannergressCredit":"Recherche via Bannergress","publisherWholeBanner":"Préparer toute la bannière","publisherWholeHint":"Une seule session navigateur : toutes les missions et leurs images sont préparées ensemble.","publisherAllRequired":"Toutes les missions doivent être complètes avant de démarrer la session de publication.","publisherSessionCreating":"Préparation de la session Publisher {n}/{total}…","publisherSessionReady":"Session Publisher prête. Enregistre le fichier puis ouvre le navigateur.","publisherSessionFileText":"Enregistre ce fichier de session RBL. Chrome/Firefox le chargera une seule fois pour toute la bannière.","publisherSessionDialog":"Enregistrer la session Publisher","publisherSessionShareFail":"Impossible de préparer la session Publisher.","chromeSessionHint":"Chrome : lance le favori RBL Publisher une seule fois, puis sélectionne le fichier de session que tu viens d’enregistrer.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement ; charge le fichier de session une seule fois.","easterEgg":"Tu l’as cherché."});
Object.assign(I18N.en,{"playBanners":"Play","playHub":"Play a banner","searchBannergress":"Search Bannergress","searchPlaceholder":"Banner name, city…","search":"Search","favorites":"Favorites","currentBanner":"Current","noFavorites":"No favorite banners yet. Your local storage is enjoying the peace.","noPlaySession":"No banner currently running.","searchPrompt":"Search public Bannergress banners directly.","searching":"Searching…","searchError":"Bannergress search failed: {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favorite","removeFavorite":"Remove favorite","playThisBanner":"Play this banner","resumeBanner":"Resume banner","stopBanner":"Stop overlay","openCurrentMission":"Open current mission","overlayPermissionTitle":"Allow RBL overlay","overlayPermissionText":"Android must allow Redacted BannerLab to appear over Ingress. One system permission, then the dino can mind its business.","overlayPermissionButton":"Allow display over other apps","overlayPermissionWaiting":"Return to RBL after granting the permission.","overlayStarted":"Mission overlay started.","overlayFailed":"Could not start overlay: {error}","bannerLoadError":"Could not load this banner: {error}","bannerOffline":"This banner has no usable missions.","bannerDisabled":"{n} disabled mission(s)","addressUnknown":"Location not specified","doneMissions":"{done}/{total} completed","deepLinkOnly":"RBL does not control Ingress: the overlay only opens official mission deep links.","bannergressCredit":"Search via Bannergress","publisherWholeBanner":"Prepare whole banner","publisherWholeHint":"One browser session: all missions and images are prepared together.","publisherAllRequired":"Every mission must be complete before starting the publishing session.","publisherSessionCreating":"Preparing Publisher session {n}/{total}…","publisherSessionReady":"Publisher session ready. Save the file, then open the browser.","publisherSessionFileText":"Save this RBL session file. Chrome/Firefox loads it once for the entire banner.","publisherSessionDialog":"Save Publisher session","publisherSessionShareFail":"Unable to prepare Publisher session.","chromeSessionHint":"Chrome: run the RBL Publisher bookmark once, then select the session file you just saved.","firefoxSessionHint":"Firefox: Publisher loads automatically; select the session file once.","easterEgg":"You asked for this."});
Object.assign(I18N.es,{"playBanners":"Jugar","playHub":"Jugar un mosaico","searchBannergress":"Buscar en Bannergress","searchPlaceholder":"Nombre, ciudad…","search":"Buscar","favorites":"Favoritos","currentBanner":"En curso","noFavorites":"Aún no hay mosaicos favoritos. El almacenamiento local descansa.","noPlaySession":"No hay ningún mosaico en curso.","searchPrompt":"Busca directamente mosaicos públicos de Bannergress.","searching":"Buscando…","searchError":"Error al buscar en Bannergress: {error}","missionsCount":"{n} misiones","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Quitar de favoritos","playThisBanner":"Jugar este mosaico","resumeBanner":"Reanudar mosaico","stopBanner":"Detener overlay","openCurrentMission":"Abrir misión actual","overlayPermissionTitle":"Autorizar overlay RBL","overlayPermissionText":"Android debe permitir que Redacted BannerLab aparezca sobre Ingress. Un permiso del sistema y el dinosaurio queda suelto.","overlayPermissionButton":"Permitir mostrar sobre otras apps","overlayPermissionWaiting":"Vuelve a RBL después de autorizarlo.","overlayStarted":"Overlay de misión iniciado.","overlayFailed":"No se puede iniciar el overlay: {error}","bannerLoadError":"No se puede cargar el mosaico: {error}","bannerOffline":"Este mosaico no contiene misiones utilizables.","bannerDisabled":"{n} misión(es) desactivada(s)","addressUnknown":"Lugar no indicado","doneMissions":"{done}/{total} terminadas","deepLinkOnly":"RBL no controla Ingress: el overlay solo abre deeplinks oficiales de misiones.","bannergressCredit":"Búsqueda mediante Bannergress","publisherWholeBanner":"Preparar todo el mosaico","publisherWholeHint":"Una sola sesión: todas las misiones e imágenes se preparan juntas.","publisherAllRequired":"Todas las misiones deben estar completas antes de iniciar la sesión de publicación.","publisherSessionCreating":"Preparando sesión Publisher {n}/{total}…","publisherSessionReady":"Sesión Publisher lista. Guarda el archivo y abre el navegador.","publisherSessionFileText":"Guarda este archivo de sesión RBL. Chrome/Firefox lo carga una vez para todo el mosaico.","publisherSessionDialog":"Guardar sesión Publisher","publisherSessionShareFail":"No se puede preparar la sesión Publisher.","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher una sola vez y selecciona el archivo de sesión guardado.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente; carga el archivo de sesión una sola vez.","easterEgg":"Tú lo pediste."});
Object.assign(I18N.fr,{"playBanners":"Rechercher une fresque","playHub":"Rechercher une fresque","searchBannergress":"Rechercher une fresque","searchPlaceholder":"Nom ou mot-clé","bannerNameSearch":"Nom / mot-clé","citySearch":"Ville","authorSearch":"Auteur","cityPlaceholder":"Ex. Nantes","authorPlaceholder":"Ex. AgentName","nearMe":"Autour de moi","nearMeOn":"Ma position activée","nearMeHint":"La position remplace le filtre ville ; nom et auteur restent combinables.","locationGetting":"Récupération de ta position…","locationError":"Impossible de récupérer ta position : {error}","locationReady":"Position récupérée","searchCriteriaRequired":"Renseigne au moins un critère de recherche.","cityResolving":"Recherche de la ville…","cityNotFound":"Aucun lieu Bannergress trouvé pour « {city} ».","cityUsing":"Lieu retenu : {city}","searchPrompt":"Combine nom, ville et auteur, ou cherche les fresques proches de ta position.","currentBanner":"Reprendre","playThisBanner":"Lancer cette fresque","resumeBanner":"Reprendre cette fresque","bannerAuthor":"Auteur : {author}","overlayDrag":"≡  Déplacer","overlayMinimize":"Réduire","overlayClose":"Fermer","overlayMoved":"Position overlay enregistrée","searchReset":"Effacer","resultsCount":"{n} résultat(s)","searchFilters":"Filtres actifs","allPublicBanners":"Fresques publiques Bannergress"});
Object.assign(I18N.en,{"playBanners":"Find a banner","playHub":"Find a banner","searchBannergress":"Find a banner","searchPlaceholder":"Name or keyword","bannerNameSearch":"Name / keyword","citySearch":"City","authorSearch":"Author","cityPlaceholder":"e.g. Nantes","authorPlaceholder":"e.g. AgentName","nearMe":"Near me","nearMeOn":"My location enabled","nearMeHint":"Location replaces the city filter; name and author can still be combined.","locationGetting":"Getting your location…","locationError":"Could not get your location: {error}","locationReady":"Location acquired","searchCriteriaRequired":"Enter at least one search criterion.","cityResolving":"Looking up city…","cityNotFound":"No Bannergress place found for “{city}”.","cityUsing":"Using place: {city}","searchPrompt":"Combine name, city and author, or find banners near your location.","currentBanner":"Resume","playThisBanner":"Start this banner","resumeBanner":"Resume this banner","bannerAuthor":"Author: {author}","overlayDrag":"≡  Move","overlayMinimize":"Minimize","overlayClose":"Close","overlayMoved":"Overlay position saved","searchReset":"Clear","resultsCount":"{n} result(s)","searchFilters":"Active filters","allPublicBanners":"Public Bannergress banners"});
Object.assign(I18N.es,{"playBanners":"Buscar un mosaico","playHub":"Buscar un mosaico","searchBannergress":"Buscar un mosaico","searchPlaceholder":"Nombre o palabra clave","bannerNameSearch":"Nombre / palabra clave","citySearch":"Ciudad","authorSearch":"Autor","cityPlaceholder":"Ej. Nantes","authorPlaceholder":"Ej. AgentName","nearMe":"Cerca de mí","nearMeOn":"Mi ubicación activada","nearMeHint":"La ubicación sustituye la ciudad; nombre y autor se pueden combinar.","locationGetting":"Obteniendo tu ubicación…","locationError":"No se puede obtener tu ubicación: {error}","locationReady":"Ubicación obtenida","searchCriteriaRequired":"Introduce al menos un criterio de búsqueda.","cityResolving":"Buscando ciudad…","cityNotFound":"No se encontró ningún lugar Bannergress para « {city} ».","cityUsing":"Lugar usado: {city}","searchPrompt":"Combina nombre, ciudad y autor, o busca mosaicos cerca de tu ubicación.","currentBanner":"Reanudar","playThisBanner":"Iniciar este mosaico","resumeBanner":"Reanudar este mosaico","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Reducir","overlayClose":"Cerrar","overlayMoved":"Posición del overlay guardada","searchReset":"Borrar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros activos","allPublicBanners":"Mosaicos públicos Bannergress"});

Object.assign(I18N.fr,{"searchPrompt":"Recherche par nom et/ou zone géographique, avec un rayon réellement limité.","nearMeHint":"Utilise ta position actuelle à la place de la ville.","searchRadius":"Rayon de recherche","radiusHint":"Appliqué autour de la ville ou de ta position.","locationDisabled":"La localisation du téléphone est désactivée.","locationPermissionDenied":"BannerLab n’a pas l’autorisation d’utiliser ta position.","locationUnavailable":"Position indisponible. Vérifie que la localisation du téléphone est activée.","locationTimeout":"La position n’a pas pu être obtenue à temps. Vérifie que la localisation est activée.","openLocationSettings":"Activer la localisation","openAppSettings":"Ouvrir les réglages de l’app","cityNoCoordinates":"La ville « {city} » a été trouvée, mais sa position n’est pas exploitable.","cityUsingRadius":"Lieu retenu : {city} · rayon {radius} km","radiusResults":"{n} résultat(s) dans un rayon de {radius} km","distanceFromPoint":"à {distance}","locationChecking":"Vérification de la localisation…"});
Object.assign(I18N.en,{"searchPrompt":"Search by name and/or geographic area, with a real distance limit.","nearMeHint":"Uses your current position instead of a city.","searchRadius":"Search radius","radiusHint":"Applied around the city or your current position.","locationDisabled":"Location services are disabled on this phone.","locationPermissionDenied":"BannerLab is not allowed to use your location.","locationUnavailable":"Location unavailable. Check that phone location services are enabled.","locationTimeout":"Location could not be acquired in time. Check that location services are enabled.","openLocationSettings":"Enable location","openAppSettings":"Open app settings","cityNoCoordinates":"“{city}” was found, but its position cannot be used.","cityUsingRadius":"Using: {city} · {radius} km radius","radiusResults":"{n} result(s) within {radius} km","distanceFromPoint":"{distance} away","locationChecking":"Checking location services…"});
Object.assign(I18N.es,{"searchPrompt":"Busca por nombre y/o zona geográfica con un límite de distancia real.","nearMeHint":"Usa tu posición actual en lugar de una ciudad.","searchRadius":"Radio de búsqueda","radiusHint":"Se aplica alrededor de la ciudad o de tu posición.","locationDisabled":"La ubicación del teléfono está desactivada.","locationPermissionDenied":"BannerLab no tiene permiso para usar tu ubicación.","locationUnavailable":"Ubicación no disponible. Comprueba que la ubicación del teléfono esté activada.","locationTimeout":"No se pudo obtener la ubicación a tiempo. Comprueba que esté activada.","openLocationSettings":"Activar ubicación","openAppSettings":"Abrir ajustes de la app","cityNoCoordinates":"Se encontró « {city} », pero no se puede usar su posición.","cityUsingRadius":"Lugar usado: {city} · radio {radius} km","radiusResults":"{n} resultado(s) en un radio de {radius} km","distanceFromPoint":"a {distance}","locationChecking":"Comprobando ubicación…"});
Object.assign(I18N.fr,{"publisherSessionReady":"Session enregistrée dans Documents/RedactedBannerLab. Ouverture de Mission Authoring…","publisherSessionFileText":"RBL enregistre automatiquement la session dans Documents/RedactedBannerLab.","publisherSessionDialog":"Session Publisher","chromeSessionHint":"Chrome : lance le favori RBL Publisher. La première fois, choisis RBL_Current_Session.rblpub.json ; ensuite Chrome réutilise ce fichier.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement. Charge RBL_Current_Session.rblpub.json si la session courante n’est pas déjà connue.","publisherCurrentFile":"Fichier courant : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"publisherSessionReady":"Session saved in Documents/RedactedBannerLab. Opening Mission Authoring…","publisherSessionFileText":"RBL automatically saves the session in Documents/RedactedBannerLab.","publisherSessionDialog":"Publisher session","chromeSessionHint":"Chrome: run the RBL Publisher bookmark. The first time choose RBL_Current_Session.rblpub.json; Chrome will reuse that file afterwards.","firefoxSessionHint":"Firefox: Publisher opens automatically. Load RBL_Current_Session.rblpub.json if the current session is not already known.","publisherCurrentFile":"Current file: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"publisherSessionReady":"Sesión guardada en Documents/RedactedBannerLab. Abriendo Mission Authoring…","publisherSessionFileText":"RBL guarda automáticamente la sesión en Documents/RedactedBannerLab.","publisherSessionDialog":"Sesión Publisher","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. La primera vez elige RBL_Current_Session.rblpub.json; después Chrome reutilizará ese archivo.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente. Carga RBL_Current_Session.rblpub.json si la sesión actual aún no está disponible.","publisherCurrentFile":"Archivo actual: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeFileText":"RBL enregistre directement le Publisher dans Documents/RedactedBannerLab. Aucun partage Android n’est nécessaire.","chromeSaveFile":"Enregistrer le Publisher","chromeFileDone":"Publisher enregistré","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher enregistré dans Documents/RedactedBannerLab.","chromeFileWriteFail":"Impossible d’écrire le Publisher dans Documents/RedactedBannerLab.","chromeSelectFileHint":"Dans Chrome, sélectionne : Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Pour la session : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"chromeFileText":"RBL saves Publisher directly into Documents/RedactedBannerLab. No Android share sheet is needed.","chromeSaveFile":"Save Publisher","chromeFileDone":"Publisher saved","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher saved in Documents/RedactedBannerLab.","chromeFileWriteFail":"Unable to write Publisher into Documents/RedactedBannerLab.","chromeSelectFileHint":"In Chrome select: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"For the session: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"chromeFileText":"RBL guarda Publisher directamente en Documents/RedactedBannerLab. No hace falta la hoja de compartir de Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher guardado en Documents/RedactedBannerLab.","chromeFileWriteFail":"No se puede escribir Publisher en Documents/RedactedBannerLab.","chromeSelectFileHint":"En Chrome selecciona: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Para la sesión: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeSessionHint":"Chrome : lance le favori RBL Publisher. Pour chaque nouvelle bannière préparée, Chrome te demandera explicitement RBL_Current_Session.rblpub.json. Ensuite rien à refaire entre les missions.","chromeTestText":"RBL ouvre Mission Authoring. Tape RBL puis lance le favori. Chrome te demandera le Publisher, puis le JSON courant. Le JSON sera redemandé à chaque nouvelle bannière, jamais entre les missions.","chromeSetupSuccessText":"Chrome est prêt. Le Publisher reste mémorisé ; le fichier JSON de la bannière sera choisi explicitement à chaque nouvelle session pour éviter tout ancien projet fantôme.","chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.en,{"chromeSessionHint":"Chrome: run the RBL Publisher bookmark. For every newly prepared banner, Chrome will explicitly ask for RBL_Current_Session.rblpub.json. Nothing else is required between missions.","chromeTestText":"RBL opens Mission Authoring. Type RBL and run the bookmark. Chrome asks for Publisher, then the current JSON. The JSON is requested for each new banner, never between missions.","chromeSetupSuccessText":"Chrome is ready. Publisher stays remembered; the banner JSON is explicitly selected for each new session so stale projects cannot be reused silently.","chromeCurrentSessionHint":"For each new banner: choose Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.es,{"chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. Para cada nuevo mosaico preparado, Chrome pedirá explícitamente RBL_Current_Session.rblpub.json. No habrá que repetir nada entre misiones.","chromeTestText":"RBL abre Mission Authoring. Escribe RBL y ejecuta el favorito. Chrome pide Publisher y después el JSON actual. El JSON se vuelve a pedir para cada nuevo mosaico, nunca entre misiones.","chromeSetupSuccessText":"Chrome está listo. Publisher queda memorizado; el JSON del mosaico se selecciona explícitamente en cada nueva sesión para evitar proyectos antiguos.","chromeCurrentSessionHint":"Para cada nuevo mosaico: elige Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Retour au navigateur sans recharger Mission Authoring…","chromeResumeHint":"Chrome est simplement remis au premier plan. Le Publisher recharge automatiquement RBL_Current_Session.rblpub.json si l’autorisation est encore valide.","firefoxResumeHint":"Firefox est simplement remis au premier plan afin de conserver la session Mission Authoring.","browserResumeFallback":"Impossible de reprendre le navigateur existant. Ouverture de Mission Authoring en secours.","publisherAutoRefresh":"Le Publisher surveille désormais le fichier de session courant et recharge automatiquement une nouvelle bannière."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Returning to the browser without reloading Mission Authoring…","chromeResumeHint":"Chrome is only brought back to the foreground. Publisher automatically reloads RBL_Current_Session.rblpub.json while permission remains valid.","firefoxResumeHint":"Firefox is only brought back to the foreground to preserve the Mission Authoring session.","browserResumeFallback":"Could not resume the existing browser. Opening Mission Authoring as fallback.","publisherAutoRefresh":"Publisher now watches the current session file and automatically reloads a newly prepared banner."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Volviendo al navegador sin recargar Mission Authoring…","chromeResumeHint":"Chrome solo vuelve al primer plano. Publisher recarga automáticamente RBL_Current_Session.rblpub.json mientras el permiso siga válido.","firefoxResumeHint":"Firefox solo vuelve al primer plano para conservar la sesión de Mission Authoring.","browserResumeFallback":"No se puede reanudar el navegador existente. Se abre Mission Authoring como alternativa.","publisherAutoRefresh":"Publisher ahora vigila el archivo de sesión actual y recarga automáticamente una nueva pancarta."});
Object.assign(I18N.fr,{"flowLocked":"Édition de la fresque verrouillée","flowLockedText":"L’étape {step} est active. Sélectionne « 1 Fresque » pour modifier l’image, les textes ou le cadrage.","returnFresco":"Sélectionne 1 Fresque pour modifier","flowLockedToast":"Retourne sur l’étape 1 Fresque pour modifier la bannière."});
Object.assign(I18N.en,{"flowLocked":"Banner editing locked","flowLockedText":"Step {step} is active. Select “1 Banner” to edit the image, text or framing.","returnFresco":"Select 1 Banner to edit","flowLockedToast":"Return to step 1 Banner to edit the banner."});
Object.assign(I18N.es,{"flowLocked":"Edición del mosaico bloqueada","flowLockedText":"El paso {step} está activo. Selecciona « 1 Mosaico » para modificar imagen, texto o encuadre.","returnFresco":"Selecciona 1 Mosaico para editar","flowLockedToast":"Vuelve al paso 1 Mosaico para editar el mosaico."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Ouverture de l’onglet Mission Authoring RBL…","chromeResumeHint":"Chrome réutilise désormais le même onglet Mission Authoring réservé à RBL.","firefoxResumeHint":"Ouverture de Mission Authoring dans le navigateur de publication.","browserResumeFallback":"Impossible de réutiliser l’onglet RBL. Ouverture du navigateur en secours.","publisherTabReuse":"RBL utilise un identifiant d’application navigateur stable pour réutiliser le même onglet."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Opening the RBL Mission Authoring tab…","chromeResumeHint":"Chrome now reuses the same Mission Authoring tab reserved for RBL.","firefoxResumeHint":"Opening Mission Authoring in the publishing browser.","browserResumeFallback":"Could not reuse the RBL tab. Opening the browser as fallback.","publisherTabReuse":"RBL uses a stable browser application ID to reuse the same tab."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Abriendo la pestaña Mission Authoring de RBL…","chromeResumeHint":"Chrome reutiliza ahora la misma pestaña Mission Authoring reservada para RBL.","firefoxResumeHint":"Abriendo Mission Authoring en el navegador de publicación.","browserResumeFallback":"No se puede reutilizar la pestaña RBL. Abriendo el navegador como alternativa.","publisherTabReuse":"RBL usa un identificador de aplicación del navegador estable para reutilizar la misma pestaña."});
Object.assign(I18N.fr,{"todo":"À faire","history":"Historique","inProgress":"En cours","addTodo":"Ajouter à À faire","removeTodo":"Retirer de À faire","noTodo":"Aucune fresque à faire. Pour l’instant tu es raisonnable.","noHistory":"Aucune fresque jouée. Le dino s’ennuie.","bannerMap":"Carte du parcours","openMap":"Voir la carte","navigateStart":"Itinéraire vers le départ","startUnavailable":"Point de départ indisponible.","mapUnavailable":"Bannergress ne fournit pas de coordonnées exploitables pour cette fresque.","startPoint":"Départ","missionStart":"Mission {n}","shareGroup":"Partager / groupe","shareProgress":"Partager la progression","shareBanner":"Partager la fresque","shareIntro":"Le QR ouvre RBL sur la même fresque et le même numéro de mission. Aucun compte Bannergress n’est utilisé.","copyLink":"Copier le lien RBL","linkCopied":"Lien RBL copié","shareNow":"Partager","bannergressPage":"Voir sur Bannergress","joinBanner":"Rejoindre la fresque","joinAtMission":"Rejoindre à la mission {n}","sharedBannerLoaded":"Fresque partagée chargée · mission {n}","sharedBannerError":"Impossible de charger cette fresque partagée : {error}","playStats":"Stats de session","startedAt":"Début","finishedAt":"Fin","elapsed":"Durée active","estimatedDistance":"Distance estimée","missionsDone":"Missions terminées","paused":"En pause","playing":"En cours","completedBanner":"Terminée","replayBanner":"Rejouer","resumeFromHistory":"Reprendre","groupNoServer":"Mode groupe sans serveur : partage simplement le QR/lien à nouveau si le groupe change de mission.","publicOnly":"Recherche et données publiques Bannergress uniquement · aucune connexion nécessaire.","routePoints":"{n} points sur le parcours"});
Object.assign(I18N.en,{"todo":"To do","history":"History","inProgress":"In progress","addTodo":"Add to To do","removeTodo":"Remove from To do","noTodo":"No banners to do. Suspiciously reasonable.","noHistory":"No played banners yet. The dino is bored.","bannerMap":"Route map","openMap":"View map","navigateStart":"Navigate to start","startUnavailable":"Start point unavailable.","mapUnavailable":"Bannergress does not provide usable coordinates for this banner.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Share / group","shareProgress":"Share progress","shareBanner":"Share banner","shareIntro":"The QR opens RBL on the same banner and mission number. No Bannergress account is used.","copyLink":"Copy RBL link","linkCopied":"RBL link copied","shareNow":"Share","bannergressPage":"Open on Bannergress","joinBanner":"Join banner","joinAtMission":"Join at mission {n}","sharedBannerLoaded":"Shared banner loaded · mission {n}","sharedBannerError":"Could not load shared banner: {error}","playStats":"Session stats","startedAt":"Started","finishedAt":"Finished","elapsed":"Active time","estimatedDistance":"Estimated distance","missionsDone":"Missions done","paused":"Paused","playing":"In progress","completedBanner":"Completed","replayBanner":"Play again","resumeFromHistory":"Resume","groupNoServer":"Serverless group mode: share the QR/link again if the group moves to another mission.","publicOnly":"Public Bannergress search/data only · no sign-in required.","routePoints":"{n} route points"});
Object.assign(I18N.es,{"todo":"Por hacer","history":"Historial","inProgress":"En curso","addTodo":"Añadir a Por hacer","removeTodo":"Quitar de Por hacer","noTodo":"No hay mosaicos pendientes. Sospechosamente razonable.","noHistory":"No hay mosaicos jugados. El dino se aburre.","bannerMap":"Mapa del recorrido","openMap":"Ver mapa","navigateStart":"Ir al punto de inicio","startUnavailable":"Punto de inicio no disponible.","mapUnavailable":"Bannergress no proporciona coordenadas utilizables para este mosaico.","startPoint":"Inicio","missionStart":"Misión {n}","shareGroup":"Compartir / grupo","shareProgress":"Compartir progreso","shareBanner":"Compartir mosaico","shareIntro":"El QR abre RBL en el mismo mosaico y número de misión. No se usa ninguna cuenta Bannergress.","copyLink":"Copiar enlace RBL","linkCopied":"Enlace RBL copiado","shareNow":"Compartir","bannergressPage":"Abrir en Bannergress","joinBanner":"Unirse al mosaico","joinAtMission":"Unirse en la misión {n}","sharedBannerLoaded":"Mosaico compartido cargado · misión {n}","sharedBannerError":"No se puede cargar el mosaico compartido: {error}","playStats":"Estadísticas de sesión","startedAt":"Inicio","finishedAt":"Fin","elapsed":"Tiempo activo","estimatedDistance":"Distancia estimada","missionsDone":"Misiones terminadas","paused":"En pausa","playing":"En curso","completedBanner":"Terminado","replayBanner":"Jugar otra vez","resumeFromHistory":"Reanudar","groupNoServer":"Modo grupo sin servidor: comparte de nuevo el QR/enlace si el grupo cambia de misión.","publicOnly":"Solo búsqueda/datos públicos de Bannergress · no hace falta iniciar sesión.","routePoints":"{n} puntos de recorrido"});
Object.assign(I18N.fr,{"uselessStats":"Stats inutiles","loadingStats":"Calcul des trucs dont personne n’avait besoin…","statsUnavailable":"Pas assez de coordonnées pour calculer les stats inutiles.","bgDistance":"Distance Bannergress","calculatedTrack":"Tracé calculé","walkingEstimate":"Marche théorique","routeSteps":"Étapes","uniquePlaces":"Lieux distincts","revisitedPlaces":"Passages répétés","stepsPerKm":"Étapes / km","avgMissionDistance":"Moyenne / mission","longestMission":"Mission la plus longue","longestLeg":"Plus long tronçon","betweenMissions":"Transitions inter-missions","detourFactor":"Coefficient de détour","routeCoverage":"Couverture carto","missionShort":"M{n}","straightLine":"Départ → arrivée","funStatsDisclaimer":"Calculs géométriques entre les points Bannergress, pas un itinéraire routier. Donc oui, c’est scientifiquement approximatif et parfaitement satisfaisant pour des stats inutiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Stats inutiles","hideUselessStats":"Masquer les stats","statsLoaded":"Stats calculées"});
Object.assign(I18N.en,{"uselessStats":"Useless stats","loadingStats":"Calculating things nobody asked for…","statsUnavailable":"Not enough coordinates to calculate useless stats.","bgDistance":"Bannergress distance","calculatedTrack":"Calculated track","walkingEstimate":"Theoretical walking","routeSteps":"Steps","uniquePlaces":"Unique places","revisitedPlaces":"Repeated visits","stepsPerKm":"Steps / km","avgMissionDistance":"Average / mission","longestMission":"Longest mission","longestLeg":"Longest leg","betweenMissions":"Between-mission transitions","detourFactor":"Detour factor","routeCoverage":"Map coverage","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"Geometric calculations between Bannergress points, not a road route. Scientifically approximate, therefore ideal for useless stats.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Useless stats","hideUselessStats":"Hide stats","statsLoaded":"Stats calculated"});
Object.assign(I18N.es,{"uselessStats":"Estadísticas inútiles","loadingStats":"Calculando cosas que nadie necesitaba…","statsUnavailable":"No hay suficientes coordenadas para calcular estadísticas inútiles.","bgDistance":"Distancia Bannergress","calculatedTrack":"Recorrido calculado","walkingEstimate":"Caminata teórica","routeSteps":"Etapas","uniquePlaces":"Lugares distintos","revisitedPlaces":"Pasos repetidos","stepsPerKm":"Etapas / km","avgMissionDistance":"Media / misión","longestMission":"Misión más larga","longestLeg":"Tramo más largo","betweenMissions":"Transiciones entre misiones","detourFactor":"Factor de desvío","routeCoverage":"Cobertura cartográfica","missionShort":"M{n}","straightLine":"Inicio → final","funStatsDisclaimer":"Cálculos geométricos entre puntos Bannergress, no una ruta vial. Científicamente aproximado, perfecto para estadísticas inútiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Estadísticas inútiles","hideUselessStats":"Ocultar estadísticas","statsLoaded":"Estadísticas calculadas"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne RBL","walkingEstimate":"Temps piéton RBL","directGeometric":"Distance directe cumulée","routingDetour":"Détour du réseau piéton","routingSource":"Routage","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponible · estimation géométrique","routingLoading":"Calcul du vrai parcours piéton…","routingFailed":"Routage piéton indisponible, stats géométriques utilisées.","funStatsDisclaimer":"Distance piétonne calculée par Valhalla sur les chemins OpenStreetMap entre tous les points de la fresque. La distance directe reste affichée pour comparaison. Les chemins OSM peuvent évidemment être faux, parce que même les cartes ont leurs jours sans.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.en,{"calculatedTrack":"RBL walking distance","walkingEstimate":"RBL walking time","directGeometric":"Cumulative direct distance","routingDetour":"Pedestrian network detour","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla unavailable · geometric estimate","routingLoading":"Calculating actual walking route…","routingFailed":"Walking routing unavailable, geometric stats used.","funStatsDisclaimer":"Walking distance calculated by Valhalla over OpenStreetMap paths between every banner point. Direct distance remains for comparison. OSM paths can of course be wrong, because maps also enjoy chaos.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia a pie RBL","walkingEstimate":"Tiempo a pie RBL","directGeometric":"Distancia directa acumulada","routingDetour":"Desvío de la red peatonal","routingSource":"Enrutamiento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla no disponible · estimación geométrica","routingLoading":"Calculando la ruta peatonal real…","routingFailed":"Enrutamiento peatonal no disponible, se usan estadísticas geométricas.","funStatsDisclaimer":"Distancia a pie calculada por Valhalla sobre caminos OpenStreetMap entre todos los puntos del mosaico. La distancia directa se conserva para comparar. OSM también puede equivocarse, porque la perfección era demasiado pedir.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.fr,{"routingNative":"Valhalla + OSM · HTTP natif Android","routingWeb":"Valhalla + OSM · navigateur","routingErrorDetail":"Échec Valhalla : {error}"});
Object.assign(I18N.en,{"routingNative":"Valhalla + OSM · Android native HTTP","routingWeb":"Valhalla + OSM · browser","routingErrorDetail":"Valhalla failed: {error}"});
Object.assign(I18N.es,{"routingNative":"Valhalla + OSM · HTTP nativo Android","routingWeb":"Valhalla + OSM · navegador","routingErrorDetail":"Error de Valhalla: {error}"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance jouable RBL","walkingEstimate":"Temps de marche RBL","routingNative":"Valhalla + OSM · portée Ingress 40 m","routingWeb":"Valhalla + OSM · portée Ingress 40 m","routingDetour":"Écart réseau / direct","funStatsDisclaimer":"RBL cherche un chemin piéton OpenStreetMap passant à moins de 40 m de chaque portail, ce qui correspond mieux à la portée de jeu Ingress que d’obliger le trajet à atteindre la coordonnée exacte du portail. La distance directe cumulée reste affichée pour comparaison.","ingressRadius":"Portée Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.en,{"calculatedTrack":"RBL playable distance","walkingEstimate":"RBL walking time","routingNative":"Valhalla + OSM · 40 m Ingress range","routingWeb":"Valhalla + OSM · 40 m Ingress range","routingDetour":"Network / direct ratio","funStatsDisclaimer":"RBL looks for an OpenStreetMap pedestrian route passing within 40 m of every portal. This better matches actual Ingress interaction range than forcing the route to reach the portal's exact coordinate. Cumulative direct distance remains visible for comparison.","ingressRadius":"Ingress range","ingressRadiusValue":"40 m"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia jugable RBL","walkingEstimate":"Tiempo a pie RBL","routingNative":"Valhalla + OSM · alcance Ingress 40 m","routingWeb":"Valhalla + OSM · alcance Ingress 40 m","routingDetour":"Relación red / directa","funStatsDisclaimer":"RBL busca una ruta peatonal OpenStreetMap que pase a menos de 40 m de cada portal. Esto se ajusta mejor al alcance real de Ingress que obligar la ruta a llegar a la coordenada exacta del portal. La distancia directa acumulada sigue visible para comparar.","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne estimée","walkingEstimate":"Temps de marche estimé","routingNative":"Valhalla + OSM · contrôle tronçon par tronçon","routingWeb":"Valhalla + OSM · contrôle tronçon par tronçon","routingDetour":"Écart réseau / direct","correctedLegs":"Tronçons corrigés","rawValhalla":"Valhalla brut","funStatsDisclaimer":"RBL route chaque liaison portail → portail sur le réseau piéton OpenStreetMap. Chaque tronçon est contrôlé : si Valhalla propose une distance impossible ou un détour manifestement aberrant, seul ce tronçon est remplacé par sa distance directe. C’est une estimation de marche, pas une mesure GPS réelle."});
Object.assign(I18N.en,{"calculatedTrack":"Estimated walking distance","walkingEstimate":"Estimated walking time","routingNative":"Valhalla + OSM · per-leg sanity check","routingWeb":"Valhalla + OSM · per-leg sanity check","routingDetour":"Network / direct ratio","correctedLegs":"Corrected legs","rawValhalla":"Raw Valhalla","funStatsDisclaimer":"RBL routes every portal-to-portal leg on the OpenStreetMap pedestrian network. Each leg is sanity-checked: impossible shortcuts or obviously absurd detours are replaced only for that leg by direct distance. This is a walking estimate, not a GPS measurement."});
Object.assign(I18N.es,{"calculatedTrack":"Distancia peatonal estimada","walkingEstimate":"Tiempo de marcha estimado","routingNative":"Valhalla + OSM · control tramo por tramo","routingWeb":"Valhalla + OSM · control tramo por tramo","routingDetour":"Relación red / directa","correctedLegs":"Tramos corregidos","rawValhalla":"Valhalla bruto","funStatsDisclaimer":"RBL calcula cada tramo portal → portal sobre la red peatonal OpenStreetMap. Cada tramo se valida: atajos imposibles o desvíos claramente absurdos se sustituyen solo en ese tramo por la distancia directa. Es una estimación a pie, no una medición GPS real."});
Object.assign(I18N.fr,{"creditsTitle":"Crédits & remerciements","bannergressThanks":"Merci Bannergress","bannergressThanksText":"La recherche de fresques et plusieurs informations publiques affichées dans Redacted BannerLab s’appuient sur les données publiques de Bannergress. Merci à leur équipe et aux contributeurs pour l’énorme travail réalisé autour des fresques Ingress.","bannergressNoLogin":"RBL n’utilise aucun compte Bannergress : uniquement les données publiques nécessaires à la recherche et à l’affichage des fresques.","independentProject":"Redacted BannerLab est un projet indépendant et n’est ni affilié ni approuvé par Bannergress ou les services officiels Ingress.","visitBannergress":"Découvrir Bannergress","mapCredits":"Cartographie & itinéraires","mapCreditsText":"Les cartes reposent sur OpenStreetMap. Les estimations de parcours piétons utilisent le moteur de routage Valhalla.","rblCreditsFoot":"Merci à tous les outils et contributeurs qui rendent possible cet écosystème autour des missions Ingress."});
Object.assign(I18N.en,{"creditsTitle":"Credits & thanks","bannergressThanks":"Thanks Bannergress","bannergressThanksText":"Banner search and several public details displayed in Redacted BannerLab rely on public Bannergress data. Thanks to their team and contributors for the enormous amount of work around Ingress banners.","bannergressNoLogin":"RBL does not use a Bannergress account: only public data required for banner search and display.","independentProject":"Redacted BannerLab is an independent project and is not affiliated with or endorsed by Bannergress or official Ingress services.","visitBannergress":"Visit Bannergress","mapCredits":"Maps & routing","mapCreditsText":"Maps use OpenStreetMap data. Pedestrian route estimates use the Valhalla routing engine.","rblCreditsFoot":"Thanks to all the tools and contributors that make this Ingress mission ecosystem possible."});
Object.assign(I18N.es,{"creditsTitle":"Créditos y agradecimientos","bannergressThanks":"Gracias Bannergress","bannergressThanksText":"La búsqueda de mosaicos y varios datos públicos mostrados en Redacted BannerLab se apoyan en datos públicos de Bannergress. Gracias a su equipo y a sus colaboradores por el enorme trabajo realizado alrededor de los mosaicos de Ingress.","bannergressNoLogin":"RBL no utiliza ninguna cuenta Bannergress: solo los datos públicos necesarios para buscar y mostrar mosaicos.","independentProject":"Redacted BannerLab es un proyecto independiente y no está afiliado ni aprobado por Bannergress ni por los servicios oficiales de Ingress.","visitBannergress":"Visitar Bannergress","mapCredits":"Mapas y rutas","mapCreditsText":"Los mapas utilizan datos de OpenStreetMap. Las estimaciones de rutas peatonales usan el motor Valhalla.","rblCreditsFoot":"Gracias a todas las herramientas y colaboradores que hacen posible este ecosistema de misiones de Ingress."});
Object.assign(I18N.fr,{"layersTitle":"Images & calques","layersDesc":"Gère ici le fond et toutes les images superposées. Les miniatures permettent d’identifier rapidement le bon calque, puis de le sélectionner, masquer, réordonner ou grouper.","backgroundLayer":"Fond principal","addBackground":"Ajouter / remplacer le fond","addLayer":"Ajouter un calque","layerName":"Calque image","selected":"Sélectionné","visibleLayer":"Visible","hiddenLayer":"Masqué","moveUp":"Monter","moveDown":"Descendre","groupSelection":"Sélection de groupe","group":"Grouper","ungroup":"Dégrouper","groupNeedTwo":"Sélectionne au moins deux calques à grouper.","groupCreated":"Calques groupés","groupRemoved":"Groupe supprimé","deleteLayer":"Supprimer le calque","layerDeleted":"Calque supprimé","layerAdded":"Calque ajouté","backgroundReplaced":"Fond remplacé","backgroundMissing":"Aucun fond principal","backgroundFixed":"Le fond reste toujours sous les autres calques.","groupHint":"Coche plusieurs calques puis appuie sur Grouper. Un groupe se déplace, zoome et tourne ensemble.","layerOrder":"Ordre des calques","layerTransform":"Transformer le calque","groupTransform":"Transformer le groupe","renameLayer":"Renommer","duplicateLayer":"Dupliquer","layerDuplicated":"Calque dupliqué","histAddLayer":"Ajouter calque","histDeleteLayer":"Supprimer calque","histReorderLayer":"Réordonner calque","histGroupLayers":"Grouper calques","histUngroupLayers":"Dégrouper calques","histVisibilityLayer":"Visibilité calque","histRenameLayer":"Renommer calque","histDuplicateLayer":"Dupliquer calque"});
Object.assign(I18N.en,{"layersTitle":"Images & layers","layersDesc":"Manage the background and all overlaid images here. Thumbnails help identify the right layer, then select, hide, reorder or group it.","backgroundLayer":"Main background","addBackground":"Add / replace background","addLayer":"Add layer","layerName":"Image layer","selected":"Selected","visibleLayer":"Visible","hiddenLayer":"Hidden","moveUp":"Move up","moveDown":"Move down","groupSelection":"Group selection","group":"Group","ungroup":"Ungroup","groupNeedTwo":"Select at least two layers to group.","groupCreated":"Layers grouped","groupRemoved":"Group removed","deleteLayer":"Delete layer","layerDeleted":"Layer deleted","layerAdded":"Layer added","backgroundReplaced":"Background replaced","backgroundMissing":"No main background","backgroundFixed":"The background always stays below the other layers.","groupHint":"Tick several layers then tap Group. A group moves, zooms and rotates together.","layerOrder":"Layer order","layerTransform":"Transform layer","groupTransform":"Transform group","renameLayer":"Rename","duplicateLayer":"Duplicate","layerDuplicated":"Layer duplicated","histAddLayer":"Add layer","histDeleteLayer":"Delete layer","histReorderLayer":"Reorder layer","histGroupLayers":"Group layers","histUngroupLayers":"Ungroup layers","histVisibilityLayer":"Layer visibility","histRenameLayer":"Rename layer","histDuplicateLayer":"Duplicate layer"});
Object.assign(I18N.es,{"layersTitle":"Imágenes y capas","layersDesc":"Gestiona aquí el fondo y todas las imágenes superpuestas. Las miniaturas ayudan a identificar, seleccionar, ocultar, ordenar o agrupar cada capa.","backgroundLayer":"Fondo principal","addBackground":"Añadir / reemplazar fondo","addLayer":"Añadir capa","layerName":"Capa de imagen","selected":"Seleccionada","visibleLayer":"Visible","hiddenLayer":"Oculta","moveUp":"Subir","moveDown":"Bajar","groupSelection":"Selección de grupo","group":"Agrupar","ungroup":"Desagrupar","groupNeedTwo":"Selecciona al menos dos capas para agrupar.","groupCreated":"Capas agrupadas","groupRemoved":"Grupo eliminado","deleteLayer":"Eliminar capa","layerDeleted":"Capa eliminada","layerAdded":"Capa añadida","backgroundReplaced":"Fondo reemplazado","backgroundMissing":"Sin fondo principal","backgroundFixed":"El fondo siempre permanece debajo de las demás capas.","groupHint":"Marca varias capas y pulsa Agrupar. Un grupo se mueve, amplía y gira junto.","layerOrder":"Orden de capas","layerTransform":"Transformar capa","groupTransform":"Transformar grupo","renameLayer":"Renombrar","duplicateLayer":"Duplicar","layerDuplicated":"Capa duplicada","histAddLayer":"Añadir capa","histDeleteLayer":"Eliminar capa","histReorderLayer":"Reordenar capa","histGroupLayers":"Agrupar capas","histUngroupLayers":"Desagrupar capas","histVisibilityLayer":"Visibilidad capa","histRenameLayer":"Renombrar capa","histDuplicateLayer":"Duplicar capa"});
Object.assign(I18N.fr,{"layerGroupBadge":"Groupe","layerUngroup":"Dégrouper ce groupe","layerSelectHint":"Le calque sélectionné se déplace ensuite directement sur la fresque.","layerOpacity":"Opacité","layerDimensions":"{w} × {h} px","noImageContent":"Ajoute au moins une image avant d’exporter.","groupRelative":"Les réglages ci-dessous transforment tout le groupe ensemble.","groupZoom":"Zoom du groupe","groupRotation":"Rotation du groupe","clearGroupSelection":"Vider la sélection"});
Object.assign(I18N.en,{"layerGroupBadge":"Group","layerUngroup":"Ungroup this group","layerSelectHint":"The selected layer can then be moved directly on the banner.","layerOpacity":"Opacity","layerDimensions":"{w} × {h} px","noImageContent":"Add at least one image before exporting.","groupRelative":"The controls below transform the whole group together.","groupZoom":"Group zoom","groupRotation":"Group rotation","clearGroupSelection":"Clear selection"});
Object.assign(I18N.es,{"layerGroupBadge":"Grupo","layerUngroup":"Desagrupar este grupo","layerSelectHint":"La capa seleccionada se puede mover después directamente sobre el mosaico.","layerOpacity":"Opacidad","layerDimensions":"{w} × {h} px","noImageContent":"Añade al menos una imagen antes de exportar.","groupRelative":"Los controles siguientes transforman todo el grupo junto.","groupZoom":"Zoom del grupo","groupRotation":"Rotación del grupo","clearGroupSelection":"Vaciar selección"});
Object.assign(I18N.fr,{"allLayersTitle":"Calques","allLayersDesc":"Sélectionne l’élément à manipuler. Images et textes restent modifiables depuis leurs menus dédiés.","imageLayersSection":"Images","textLayersSection":"Textes","noExtraImageLayer":"Aucun calque image supplémentaire","noTextLayer":"Aucun calque texte","selectLayer":"Sélectionner","editLayer":"Modifier"});
Object.assign(I18N.en,{"allLayersTitle":"Layers","allLayersDesc":"Select the element you want to manipulate. Images and text remain editable from their dedicated menus.","imageLayersSection":"Images","textLayersSection":"Text","noExtraImageLayer":"No additional image layer","noTextLayer":"No text layer","selectLayer":"Select","editLayer":"Edit"});
Object.assign(I18N.es,{"allLayersTitle":"Capas","allLayersDesc":"Selecciona el elemento que quieres manipular. Las imágenes y los textos siguen editándose desde sus menús dedicados.","imageLayersSection":"Imágenes","textLayersSection":"Textos","noExtraImageLayer":"No hay capas de imagen adicionales","noTextLayer":"No hay capas de texto","selectLayer":"Seleccionar","editLayer":"Editar"});
Object.assign(I18N.fr,{"missionNumberQuestion":"Quel est le numéro de la mission ?"});
Object.assign(I18N.en,{"missionNumberQuestion":"What is the mission number?"});
Object.assign(I18N.es,{"missionNumberQuestion":"¿Cuál es el número de la misión?"});

Object.assign(I18N.fr,{"groupName":"Groupe {n}","groupCount":"{n} calque(s)","creatorBy":"Créé par Zw4nn","communityTitle":"Communauté & support","communityText":"Actualités, aide, bugs, suggestions et échanges autour de Redacted BannerLab.","telegramOpen":"Ouvrir Telegram","reportProblem":"Signaler un problème","reportProblemText":"Copie un diagnostic technique puis ouvre Telegram pour décrire le problème.","copyDiagnostic":"Copier le diagnostic","diagnosticCopied":"Diagnostic copié","diagnosticCopyFailed":"Impossible de copier le diagnostic","diagnosticDescription":"Description du problème :"});
Object.assign(I18N.en,{"groupName":"Group {n}","groupCount":"{n} layer(s)","creatorBy":"Created by Zw4nn","communityTitle":"Community & support","communityText":"News, help, bugs, suggestions and discussion around Redacted BannerLab.","telegramOpen":"Open Telegram","reportProblem":"Report a problem","reportProblemText":"Copy a technical diagnostic, then open Telegram to describe the problem.","copyDiagnostic":"Copy diagnostic","diagnosticCopied":"Diagnostic copied","diagnosticCopyFailed":"Unable to copy diagnostic","diagnosticDescription":"Problem description:"});
Object.assign(I18N.es,{"groupName":"Grupo {n}","groupCount":"{n} capa(s)","creatorBy":"Creado por Zw4nn","communityTitle":"Comunidad y soporte","communityText":"Noticias, ayuda, errores, sugerencias y conversaciones sobre Redacted BannerLab.","telegramOpen":"Abrir Telegram","reportProblem":"Informar de un problema","reportProblemText":"Copia un diagnóstico técnico y abre Telegram para describir el problema.","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","diagnosticCopyFailed":"No se pudo copiar el diagnóstico","diagnosticDescription":"Descripción del problema:"});
Object.assign(I18N.fr,{"portableProject":"Projet portable","portableProjectDesc":"Exporte une seule fresque avec ses images, calques, textes, polices, missions et parcours.","exportProject":"Exporter","shareProject":"Partager","importProject":"Importer un projet","projectExporting":"Préparation du projet…","projectExported":"Projet enregistré","projectShared":"Projet prêt à être partagé","projectImportSuccess":"Projet importé","projectImportInvalid":"Ce fichier n’est pas un projet Redacted BannerLab valide.","projectShareTitle":"Projet Redacted BannerLab","projectImportHint":"Le projet importé est ajouté sans modifier les autres projets.","telegramOpen":"Contacter le support","communityText":"Accède à la communauté et au support directement via le bot Redacted BannerLab.","reportProblemText":"Copie un diagnostic technique puis contacte le support via le bot."});
Object.assign(I18N.en,{"portableProject":"Portable project","portableProjectDesc":"Export one banner with its images, layers, text, fonts, missions and route.","exportProject":"Export","shareProject":"Share","importProject":"Import project","projectExporting":"Preparing project…","projectExported":"Project saved","projectShared":"Project ready to share","projectImportSuccess":"Project imported","projectImportInvalid":"This file is not a valid Redacted BannerLab project.","projectShareTitle":"Redacted BannerLab project","projectImportHint":"The imported project is added without changing your other projects.","telegramOpen":"Contact support","communityText":"Access the community and support directly through the Redacted BannerLab bot.","reportProblemText":"Copy a technical diagnostic, then contact support through the bot."});
Object.assign(I18N.es,{"portableProject":"Proyecto portátil","portableProjectDesc":"Exporta un solo mural con sus imágenes, capas, textos, fuentes, misiones y recorrido.","exportProject":"Exportar","shareProject":"Compartir","importProject":"Importar proyecto","projectExporting":"Preparando proyecto…","projectExported":"Proyecto guardado","projectShared":"Proyecto listo para compartir","projectImportSuccess":"Proyecto importado","projectImportInvalid":"Este archivo no es un proyecto Redacted BannerLab válido.","projectShareTitle":"Proyecto Redacted BannerLab","projectImportHint":"El proyecto importado se añade sin modificar los demás proyectos.","telegramOpen":"Contactar con soporte","communityText":"Accede a la comunidad y al soporte directamente a través del bot de Redacted BannerLab.","reportProblemText":"Copia un diagnóstico técnico y contacta con soporte a través del bot."});
Object.assign(I18N.fr,{"backupTitle":"Sauvegarde & restauration","backupText":"Sauvegarde tous les projets BannerLab, leurs réglages et leurs images dans un JSON portable.","backupFolder":"Dossier de sauvegarde","backupFolderChoose":"Choisir le dossier","backupFolderChange":"Changer le dossier","backupFolderNone":"Aucun dossier choisi","backupFolderReady":"Dossier configuré","backupAuto":"Sauvegarde automatique en arrière-plan","backupAutoHint":"Quand elle est active, BannerLab prépare régulièrement la sauvegarde après tes modifications et la force au passage en arrière-plan.","backupNow":"Sauvegarder maintenant","backupExport":"Exporter le JSON","backupImport":"Importer un JSON","backupWorking":"Création de la sauvegarde…","backupSaved":"Sauvegarde terminée","backupAutoSaved":"Sauvegarde automatique terminée","backupFailed":"Échec de la sauvegarde : {error}","backupNeedFolder":"Choisis d’abord un dossier de sauvegarde.","backupFolderError":"Impossible d’utiliser ce dossier.","backupImported":"Sauvegarde restaurée","backupInvalid":"Ce fichier n’est pas une sauvegarde Redacted BannerLab valide.","backupImportTitle":"Restaurer la sauvegarde","backupImportText":"{n} projet(s) trouvé(s) · sauvegarde du {date}","backupMerge":"Fusionner","backupReplace":"Remplacer tout","backupReplaceWarn":"Remplacer tout supprime les projets présents sur ce téléphone avant la restauration.","backupCancel":"Annuler","backupLast":"Dernière sauvegarde : {date}","backupNever":"Aucune sauvegarde effectuée","backupPortable":"Le JSON contient aussi les images. Il peut donc être volumineux, mais il se suffit à lui-même.","backupNativeOnly":"Le dossier automatique est disponible sur Android. L’export/import JSON reste disponible partout.","backupFolderChosen":"Dossier de sauvegarde enregistré","backupNoChanges":"Aucun changement à sauvegarder."});
Object.assign(I18N.en,{"backupTitle":"Backup & restore","backupText":"Back up all BannerLab projects, settings and images in one portable JSON file.","backupFolder":"Backup folder","backupFolderChoose":"Choose folder","backupFolderChange":"Change folder","backupFolderNone":"No folder selected","backupFolderReady":"Folder configured","backupAuto":"Automatic backup in background","backupAutoHint":"When enabled, BannerLab regularly prepares the backup after your changes and forces a final save when going to the background.","backupNow":"Back up now","backupExport":"Export JSON","backupImport":"Import JSON","backupWorking":"Creating backup…","backupSaved":"Backup complete","backupAutoSaved":"Automatic backup complete","backupFailed":"Backup failed: {error}","backupNeedFolder":"Choose a backup folder first.","backupFolderError":"Unable to use this folder.","backupImported":"Backup restored","backupInvalid":"This file is not a valid Redacted BannerLab backup.","backupImportTitle":"Restore backup","backupImportText":"{n} project(s) found · backup from {date}","backupMerge":"Merge","backupReplace":"Replace all","backupReplaceWarn":"Replace all deletes the projects currently stored on this device before restoring.","backupCancel":"Cancel","backupLast":"Last backup: {date}","backupNever":"No backup yet","backupPortable":"The JSON also contains the images. It can therefore be large, but it is fully self-contained.","backupNativeOnly":"Automatic folder backup is available on Android. JSON export/import remains available everywhere.","backupFolderChosen":"Backup folder saved","backupNoChanges":"No changes to back up."});
Object.assign(I18N.es,{"backupTitle":"Copia de seguridad y restauración","backupText":"Guarda todos los proyectos BannerLab, sus ajustes e imágenes en un JSON portátil.","backupFolder":"Carpeta de copia","backupFolderChoose":"Elegir carpeta","backupFolderChange":"Cambiar carpeta","backupFolderNone":"Ninguna carpeta seleccionada","backupFolderReady":"Carpeta configurada","backupAuto":"Copia automática en segundo plano","backupAutoHint":"Cuando está activa, BannerLab prepara regularmente la copia después de tus cambios y fuerza un guardado al pasar a segundo plano.","backupNow":"Guardar ahora","backupExport":"Exportar JSON","backupImport":"Importar JSON","backupWorking":"Creando copia…","backupSaved":"Copia terminada","backupAutoSaved":"Copia automática terminada","backupFailed":"Error de copia: {error}","backupNeedFolder":"Elige primero una carpeta de copia.","backupFolderError":"No se puede usar esta carpeta.","backupImported":"Copia restaurada","backupInvalid":"Este archivo no es una copia válida de Redacted BannerLab.","backupImportTitle":"Restaurar copia","backupImportText":"{n} proyecto(s) encontrado(s) · copia del {date}","backupMerge":"Fusionar","backupReplace":"Reemplazar todo","backupReplaceWarn":"Reemplazar todo elimina los proyectos presentes en este dispositivo antes de restaurar.","backupCancel":"Cancelar","backupLast":"Última copia: {date}","backupNever":"Aún no hay copia","backupPortable":"El JSON también contiene las imágenes. Puede ser grande, pero es completamente autónomo.","backupNativeOnly":"La copia automática en carpeta está disponible en Android. La exportación/importación JSON sigue disponible en todas partes.","backupFolderChosen":"Carpeta de copia guardada","backupNoChanges":"No hay cambios que guardar."});


Object.assign(I18N.fr,{"studioEdit":"Édition plein écran","studioTitle":"Studio d’édition","studioLayers":"Calques","studioTexts":"Textes","studioTools":"Outils","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"Tout","studioMissionMode":"Mission","studioFrescoMode":"Fresque","studioFullscreen":"Plein écran","studioRotateHint":"6 missions dans la hauteur · les rangées suivantes défilent vers la droite.","studioSelected":"Élément sélectionné","studioNoLayer":"Sélectionne un calque ou un texte sur le côté.","studioGroupSelect":"Sélection groupe","studioGroupNow":"Grouper","studioOpenFull":"Ouvrir le gestionnaire complet","studioOpacity":"Opacité","studioClose":"Quitter le studio","studioPan":"Défilement","studioAddText":"Ajouter un texte","studioNoText":"Aucun texte pour le moment.","studioEditText":"Modifier le texte","studioDuplicateText":"Dupliquer le texte"});
Object.assign(I18N.en,{"studioEdit":"Full-screen edit","studioTitle":"Editing studio","studioLayers":"Layers","studioTexts":"Text","studioTools":"Tools","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"All","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Full screen","studioRotateHint":"6 missions vertically · following rows scroll to the right.","studioSelected":"Selected item","studioNoLayer":"Select a layer or text item from the side.","studioGroupSelect":"Group selection","studioGroupNow":"Group","studioOpenFull":"Open full manager","studioOpacity":"Opacity","studioClose":"Exit studio","studioPan":"Scroll","studioAddText":"Add text","studioNoText":"No text yet.","studioEditText":"Edit text","studioDuplicateText":"Duplicate text"});
Object.assign(I18N.es,{"studioEdit":"Edición a pantalla completa","studioTitle":"Estudio de edición","studioLayers":"Capas","studioTexts":"Textos","studioTools":"Herramientas","studioFit":"6 misiones","studioFitOne":"1 misión","studioFitAll":"Todo","studioMissionMode":"Misión","studioFrescoMode":"Fresco","studioFullscreen":"Pantalla completa","studioRotateHint":"6 misiones en vertical · las filas siguientes se desplazan hacia la derecha.","studioSelected":"Elemento seleccionado","studioNoLayer":"Selecciona una capa o un texto en el lateral.","studioGroupSelect":"Selección de grupo","studioGroupNow":"Agrupar","studioOpenFull":"Abrir gestor completo","studioOpacity":"Opacidad","studioClose":"Salir del estudio","studioPan":"Desplazar","studioAddText":"Añadir texto","studioNoText":"Aún no hay textos.","studioEditText":"Editar texto","studioDuplicateText":"Duplicar texto"});
Object.assign(I18N.fr,{"font":"Police","fontWeight":"Graisse","fontItalic":"Italique","letterSpacing":"Espacement lettres","lineHeight":"Interligne","textAlign":"Alignement","alignLeft":"Gauche","alignCenter":"Centre","alignRight":"Droite","importFont":"Importer une police","fontImported":"Police importée : {name}","fontInvalid":"Cette police n’est pas prise en charge.","fontTooLarge":"Police trop volumineuse (12 Mo max).","textBackground":"Fond du texte","textBackgroundColor":"Couleur du fond","textBackgroundOpacity":"Opacité du fond","textBackgroundPadding":"Marge du fond","textBackgroundRadius":"Arrondi / radius","textTypography":"Typographie"});
Object.assign(I18N.en,{"font":"Font","fontWeight":"Weight","fontItalic":"Italic","letterSpacing":"Letter spacing","lineHeight":"Line height","textAlign":"Alignment","alignLeft":"Left","alignCenter":"Center","alignRight":"Right","importFont":"Import font","fontImported":"Font imported: {name}","fontInvalid":"This font is not supported.","fontTooLarge":"Font is too large (12 MB max).","textBackground":"Text background","textBackgroundColor":"Background color","textBackgroundOpacity":"Background opacity","textBackgroundPadding":"Background padding","textBackgroundRadius":"Corner radius","textTypography":"Typography"});
Object.assign(I18N.es,{"font":"Fuente","fontWeight":"Peso","fontItalic":"Cursiva","letterSpacing":"Espaciado de letras","lineHeight":"Interlineado","textAlign":"Alineación","alignLeft":"Izquierda","alignCenter":"Centro","alignRight":"Derecha","importFont":"Importar fuente","fontImported":"Fuente importada: {name}","fontInvalid":"Esta fuente no es compatible.","fontTooLarge":"La fuente es demasiado grande (12 MB máx.).","textBackground":"Fondo del texto","textBackgroundColor":"Color de fondo","textBackgroundOpacity":"Opacidad del fondo","textBackgroundPadding":"Margen del fondo","textBackgroundRadius":"Radio de esquinas","textTypography":"Tipografía"});
Object.assign(I18N.fr,{
  tutorialHubTitle:'Tutoriels & prise en main',tutorialHubText:'Relance une visite quand tu veux. Redacted peut expliquer seulement la partie qui t’intéresse.',
  tutorialOpen:'Voir les tutoriels',tutorialWelcomeTitle:'Bienvenue dans Redacted BannerLab',tutorialWelcomeText:'Redacted peut te faire visiter le laboratoire. Deux minutes, quelques boutons et aucun examen à la fin.',
  tutorialStart:'Commencer la visite',tutorialLater:'Plus tard',tutorialNever:'Ne plus afficher',tutorialPrevious:'Précédent',tutorialNext:'Suivant',tutorialUnderstood:'OK, j’ai compris',tutorialClose:'Fermer',tutorialDone:'Tutoriel terminé',tutorialSeen:'Déjà vu',
  tutorialQuick:'Découverte rapide',tutorialQuickDesc:'Les boutons essentiels et le parcours général de BannerLab.',tutorialBanner:'Créer une fresque',tutorialBannerDesc:'Du projet vide jusqu’à l’aperçu et l’export des missions.',
  tutorialLayers:'Images, calques & textes',tutorialLayersDesc:'Fond, images superposées, calques et atelier typographique.',tutorialIitc:'Créer le parcours avec IITC',tutorialIitcDesc:'Installer le Companion, ajouter les portails et synchroniser le tracé.',
  tutorialPublish:'Publier les missions',tutorialPublishDesc:'Préparer les missions puis utiliser le Publisher et Mission Authoring.',tutorialBackup:'Sauvegardes & projets portables',tutorialBackupDesc:'Sauvegarder BannerLab ou partager une seule fresque complète.',
  importRolesHint:'Fond principal = image de base de la fresque · Calque = image supplémentaire superposée.',
  tutProjectTitle:'Tes projets',tutProjectText:'Chaque fresque vit dans son propre projet. Tu peux ensuite l’exporter ou la partager sans embarquer tous les autres.',
  tutNameTitle:'Nom du projet',tutNameText:'Donne un nom reconnaissable à ta fresque. Oui, « test2-final-vraiment-final » fonctionne aussi, mais Redacted désapprouve.',
  tutRowsTitle:'Nombre de rangées',tutRowsText:'Une rangée contient 6 missions. Choisis ici la hauteur finale de ta fresque.',
  tutImageTitle:'Images & calques',tutImageText:'C’est ici que tu importes le fond principal et toutes les images supplémentaires. Ce même écran sert aussi à sélectionner, ordonner, masquer et grouper les calques.',
  tutBackgroundTitle:'Fond principal',tutBackgroundText:'Pour ta première vraie image, utilise Fond principal. Elle remplace l’image de base et couvre toute la fresque.',
  tutExtraLayerTitle:'Ajouter un calque',tutExtraLayerText:'Une seconde image est un calque : elle se superpose au fond et reste déplaçable, redimensionnable et masquable.',
  tutLayersTitle:'Gérer les calques image',tutLayersText:'Les miniatures te montrent immédiatement quel calque tu manipules. Tu peux le sélectionner, changer son ordre, le masquer ou cocher plusieurs images pour les grouper.',
  tutTextTitle:'Texte',tutTextText:'Ajoute du texte, choisis la police, l’espacement, le fond, le radius ou importe ta propre police.',
  tutPreviewTitle:'Aperçu',tutPreviewText:'Vérifie le rendu mission par mission avant l’export. Les recadrages individuels sont déjà appliqués.',
  tutExportTitle:'Exporter',tutExportText:'Quand tout est prêt, BannerLab génère les images 512 × 512 dans le bon ordre.',
  tutStudioTitle:'Studio plein écran',tutStudioText:'Pour les gros doigts officiellement reconnus par le laboratoire : édition plein écran, calques latéraux et navigation plus confortable.',
  tutFlowTitle:'Les 4 étapes',tutFlowText:'Fresque → Parcours → Missions → Publier. BannerLab te guide dans cet ordre sans t’obliger à tout faire d’un coup.',
  tutRouteTitle:'Parcours',tutRouteText:'Le parcours relie tes missions aux vrais portails Ingress. Le Companion IITC fait le gros du travail directement sur la carte.',
  tutCompanionTitle:'IITC Companion',tutCompanionText:'Le Companion accompagne le projet dans IITC : mission active, portails, actions et statistiques de marche.',
  tutInstallCompanionTitle:'Installer le Companion',tutInstallCompanionText:'Installe ou mets à jour le plugin une fois dans IITC Mobile. Ensuite BannerLab peut lui transmettre ton projet.',
  tutOpenIitcTitle:'Ouvrir IITC',tutOpenIitcText:'Ouvre IITC depuis BannerLab : le projet et la mission active sont transmis au Companion.',
  tutAutoRouteTitle:'Passage entre missions',tutAutoRouteText:'La mission suivante peut s’ouvrir automatiquement et reprendre le dernier portail comme premier portail. La case reste réglable ici.',
  tutPortalListTitle:'Tes portails',tutPortalListText:'Les portails ajoutés dans IITC reviennent ici avec leur GUID, coordonnées, ordre et action. Le tracé peut donc être reconstruit.',
  tutMissionsTitle:'Préparer les missions',tutMissionsText:'Avant publication, renseigne la description commune et vérifie chaque mission.',
  tutMissionDescTitle:'Description obligatoire',tutMissionDescText:'Cette description sert de base aux missions. BannerLab signale ce qui manque avant d’autoriser la publication.',
  tutPublishTitle:'Publier',tutPublishText:'Quand parcours et descriptions sont prêts, passe ici. Le Publisher prépare les missions ; la soumission finale reste volontairement dans l’outil officiel.',
  tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prépare les données et ouvre le flux de publication. Après soumission, utilise « J’ai soumis » pour vérifier l’état publié et poursuivre la synchro.',
  tutInfoTitle:'Réglages, aide & support',tutInfoText:'La roue Réglages & infos contient la langue, les sauvegardes, les tutoriels et l’accès au support via le bot Redacted BannerLab.',
  tutBackupTitle:'Sauvegarde complète',tutBackupText:'La sauvegarde JSON complète contient tous tes projets, réglages, images et polices. Sur Android, tu peux aussi choisir un dossier d’autosauvegarde.',
  tutPortableTitle:'Projet portable',tutPortableText:'Ici tu peux exporter, partager ou importer une seule fresque avec ses images, textes, polices, missions et parcours.',
  tutSupportTitle:'Besoin d’aide ?',tutSupportText:'Copie le diagnostic si nécessaire puis contacte le support. Le bot donne aussi accès au canal et au groupe de discussion.'
});
Object.assign(I18N.en,{
  tutorialHubTitle:'Tutorials & getting started',tutorialHubText:'Restart a guided tour whenever you want. Redacted can explain only the part you need.',tutorialOpen:'View tutorials',
  tutorialWelcomeTitle:'Welcome to Redacted BannerLab',tutorialWelcomeText:'Redacted can show you around the lab. Two minutes, a few buttons and no exam at the end.',tutorialStart:'Start the tour',tutorialLater:'Later',tutorialNever:'Do not show again',tutorialPrevious:'Previous',tutorialNext:'Next',tutorialUnderstood:'OK, got it',tutorialClose:'Close',tutorialDone:'Tutorial complete',tutorialSeen:'Seen',
  tutorialQuick:'Quick tour',tutorialQuickDesc:'The essential controls and the overall BannerLab workflow.',tutorialBanner:'Create a banner',tutorialBannerDesc:'From a project to previewing and exporting the missions.',tutorialLayers:'Images, layers & text',tutorialLayersDesc:'Background, overlaid images, layers and typography tools.',tutorialIitc:'Build the route with IITC',tutorialIitcDesc:'Install Companion, add portals and sync the route.',tutorialPublish:'Publish missions',tutorialPublishDesc:'Prepare missions, then use Publisher and Mission Authoring.',tutorialBackup:'Backups & portable projects',tutorialBackupDesc:'Back up BannerLab or share one complete banner.',
  importRolesHint:'Main background = base banner image · Layer = an additional overlaid image.',tutProjectTitle:'Your projects',tutProjectText:'Each banner lives in its own project. You can export or share it without taking every other project along.',tutNameTitle:'Project name',tutNameText:'Give your banner a recognizable name.',tutRowsTitle:'Number of rows',tutRowsText:'One row contains 6 missions. Choose the final banner height here.',tutImageTitle:'Images & layers',tutImageText:'Import the main background and additional images here. This same screen also selects, orders, hides and groups image layers.',tutBackgroundTitle:'Main background',tutBackgroundText:'For your first real image, use Main background. It replaces the base image and covers the banner.',tutExtraLayerTitle:'Add a layer',tutExtraLayerText:'A second image is a layer: it sits over the background and remains movable, resizable and hideable.',tutLayersTitle:'Manage image layers',tutLayersText:'Thumbnails show which image layer you are manipulating. Select it, reorder it, hide it or tick several images to group them.',tutTextTitle:'Text',tutTextText:'Add text, choose fonts, spacing, background, radius or import your own font.',tutPreviewTitle:'Preview',tutPreviewText:'Check every mission before export. Individual framing is already applied.',tutExportTitle:'Export',tutExportText:'When ready, BannerLab creates the 512 × 512 mission images in the correct order.',tutStudioTitle:'Full-screen studio',tutStudioText:'A more comfortable full-screen editor with side controls and large touch targets.',tutFlowTitle:'The 4 steps',tutFlowText:'Banner → Route → Missions → Publish. BannerLab follows this workflow.',tutRouteTitle:'Route',tutRouteText:'The route connects missions to real Ingress portals. IITC Companion does the map work.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion carries the active project, mission, portals, actions and walking stats into IITC.',tutInstallCompanionTitle:'Install Companion',tutInstallCompanionText:'Install or update the userscript once in IITC Mobile.',tutOpenIitcTitle:'Open IITC',tutOpenIitcText:'Open IITC from BannerLab so the project and active mission are passed to Companion.',tutAutoRouteTitle:'Moving between missions',tutAutoRouteText:'The next mission can open automatically and reuse the previous last portal as its first portal.',tutPortalListTitle:'Your portals',tutPortalListText:'Portals return with GUID, coordinates, order and action, so the route can be reconstructed.',tutMissionsTitle:'Prepare missions',tutMissionsText:'Before publishing, provide the common description and check each mission.',tutMissionDescTitle:'Required description',tutMissionDescText:'BannerLab reports missing information before publication is allowed.',tutPublishTitle:'Publish',tutPublishText:'When routes and descriptions are ready, continue here. Final submission stays in the official tool.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepares the mission data and publication flow. After submission, use “I submitted” to verify the published state.',tutInfoTitle:'Settings, help & support',tutInfoText:'Settings & info contains language, backups, tutorials and support through the Redacted BannerLab bot.',tutBackupTitle:'Full backup',tutBackupText:'The full JSON includes all projects, settings, images and fonts. Android can also use an automatic backup folder.',tutPortableTitle:'Portable project',tutPortableText:'Export, share or import one banner with images, text, fonts, missions and route.',tutSupportTitle:'Need help?',tutSupportText:'Copy the diagnostic if needed, then contact support. The bot also links to the channel and discussion group.'
});
Object.assign(I18N.es,{
  tutorialHubTitle:'Tutoriales y primeros pasos',tutorialHubText:'Vuelve a iniciar una visita cuando quieras. Redacted puede explicar solo la parte que necesites.',tutorialOpen:'Ver tutoriales',tutorialWelcomeTitle:'Bienvenido a Redacted BannerLab',tutorialWelcomeText:'Redacted puede enseñarte el laboratorio. Dos minutos, algunos botones y ningún examen al final.',tutorialStart:'Empezar la visita',tutorialLater:'Más tarde',tutorialNever:'No volver a mostrar',tutorialPrevious:'Anterior',tutorialNext:'Siguiente',tutorialUnderstood:'OK, entendido',tutorialClose:'Cerrar',tutorialDone:'Tutorial terminado',tutorialSeen:'Visto',tutorialQuick:'Descubrimiento rápido',tutorialQuickDesc:'Los controles esenciales y el flujo general de BannerLab.',tutorialBanner:'Crear un mosaico',tutorialBannerDesc:'Desde el proyecto hasta la vista previa y exportación.',tutorialLayers:'Imágenes, capas y textos',tutorialLayersDesc:'Fondo, imágenes superpuestas, capas y tipografía.',tutorialIitc:'Crear el recorrido con IITC',tutorialIitcDesc:'Instalar Companion, añadir portales y sincronizar.',tutorialPublish:'Publicar misiones',tutorialPublishDesc:'Preparar misiones y usar Publisher.',tutorialBackup:'Copias y proyectos portátiles',tutorialBackupDesc:'Guardar BannerLab o compartir un solo mosaico completo.',importRolesHint:'Fondo principal = imagen base · Capa = imagen adicional superpuesta.',tutProjectTitle:'Tus proyectos',tutProjectText:'Cada mosaico vive en su propio proyecto y puede exportarse por separado.',tutNameTitle:'Nombre del proyecto',tutNameText:'Pon un nombre reconocible a tu mosaico.',tutRowsTitle:'Número de filas',tutRowsText:'Una fila contiene 6 misiones. Elige aquí la altura final.',tutImageTitle:'Imágenes y capas',tutImageText:'Aquí importas el fondo principal y las imágenes adicionales. Esta misma pantalla sirve para seleccionar, ordenar, ocultar y agrupar capas.',tutBackgroundTitle:'Fondo principal',tutBackgroundText:'Para tu primera imagen real, usa Fondo principal. Sustituye la imagen base.',tutExtraLayerTitle:'Añadir capa',tutExtraLayerText:'Una segunda imagen es una capa superpuesta que se puede mover, redimensionar y ocultar.',tutLayersTitle:'Gestionar capas de imagen',tutLayersText:'Las miniaturas muestran qué capa estás manipulando. Puedes seleccionarla, cambiar el orden, ocultarla o agrupar varias imágenes.',tutTextTitle:'Texto',tutTextText:'Añade texto, cambia fuentes, espaciado, fondo, radio o importa tu propia fuente.',tutPreviewTitle:'Vista previa',tutPreviewText:'Comprueba cada misión antes de exportar.',tutExportTitle:'Exportar',tutExportText:'BannerLab genera las imágenes 512 × 512 en el orden correcto.',tutStudioTitle:'Estudio a pantalla completa',tutStudioText:'Editor más cómodo con controles laterales y objetivos táctiles grandes.',tutFlowTitle:'Las 4 etapas',tutFlowText:'Mosaico → Recorrido → Misiones → Publicar.',tutRouteTitle:'Recorrido',tutRouteText:'El recorrido enlaza las misiones con portales Ingress reales.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion lleva proyecto, misión, portales, acciones y estadísticas a IITC.',tutInstallCompanionTitle:'Instalar Companion',tutInstallCompanionText:'Instala o actualiza el plugin una vez en IITC Mobile.',tutOpenIitcTitle:'Abrir IITC',tutOpenIitcText:'Abre IITC desde BannerLab para transmitir proyecto y misión activa.',tutAutoRouteTitle:'Paso entre misiones',tutAutoRouteText:'La siguiente misión puede abrirse automáticamente y reutilizar el último portal.',tutPortalListTitle:'Tus portales',tutPortalListText:'Los portales vuelven con GUID, coordenadas, orden y acción.',tutMissionsTitle:'Preparar misiones',tutMissionsText:'Antes de publicar, completa la descripción y comprueba cada misión.',tutMissionDescTitle:'Descripción obligatoria',tutMissionDescText:'BannerLab avisa de lo que falta antes de publicar.',tutPublishTitle:'Publicar',tutPublishText:'Cuando todo esté listo, continúa aquí. El envío final se hace en la herramienta oficial.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepara los datos y el flujo de publicación y después verifica el estado publicado.',tutInfoTitle:'Ajustes, ayuda y soporte',tutInfoText:'Ajustes e información contiene idioma, copias, tutoriales y soporte mediante el bot.',tutBackupTitle:'Copia completa',tutBackupText:'El JSON completo incluye proyectos, ajustes, imágenes y fuentes.',tutPortableTitle:'Proyecto portátil',tutPortableText:'Exporta, comparte o importa un solo mosaico completo.',tutSupportTitle:'¿Necesitas ayuda?',tutSupportText:'Copia el diagnóstico si hace falta y contacta con soporte mediante el bot.'
});

Object.assign(I18N.fr,{settingsInfo:'Réglages & infos'});
Object.assign(I18N.en,{settingsInfo:'Settings & info'});
Object.assign(I18N.es,{settingsInfo:'Ajustes e información'});

Object.assign(I18N.fr,{addMissionLayer:'Sur une mission',importMissionSeries:'Importer une série',missionLayer:'Calque de mission',globalLayer:'Calque global',layerScope:'Portée du calque',wholeBanner:'Fresque entière',missionTarget:'Mission associée',fitMode:'Ajustement',fitCover:'Remplir',fitContain:'Contenir',missionBadge:'M{n}',missionLayerHint:'Ce calque reste attaché à la mission {n} et est automatiquement limité à sa case.',missionSeriesTitle:'Importer une série de missions',missionSeriesText:'Associe chaque image à une mission. BannerLab les place et les recadre automatiquement.',missionSeriesDetected:'{n} image(s) détectée(s)',missionSeriesImport:'Importer les calques',missionSeriesTooMany:'Tu as sélectionné plus d’images que de missions. Plusieurs images peuvent être associées à la même mission.',missionLayerAdded:'Image ajoutée à la mission {n}',missionSeriesAdded:'{n} calque(s) de mission ajouté(s)',missionScopeMismatch:'Pour grouper des calques de mission, ils doivent appartenir à la même mission.',missionLayerTutorialTitle:'Calques liés aux missions',missionLayerTutorialText:'Ajoute une image directement à une mission : BannerLab la place, la recadre et la limite automatiquement à cette case. « Importer une série » permet d’affecter 6, 12, 18 images ou plus en une seule fois.'});
Object.assign(I18N.en,{addMissionLayer:'On a mission',importMissionSeries:'Import a series',missionLayer:'Mission layer',globalLayer:'Global layer',layerScope:'Layer scope',wholeBanner:'Whole banner',missionTarget:'Assigned mission',fitMode:'Fit',fitCover:'Fill',fitContain:'Contain',missionBadge:'M{n}',missionLayerHint:'This layer stays attached to mission {n} and is automatically clipped to its tile.',missionSeriesTitle:'Import a mission series',missionSeriesText:'Assign each image to a mission. BannerLab places and crops them automatically.',missionSeriesDetected:'{n} image(s) detected',missionSeriesImport:'Import layers',missionSeriesTooMany:'You selected more images than missions. Multiple images can be assigned to the same mission.',missionLayerAdded:'Image added to mission {n}',missionSeriesAdded:'{n} mission layer(s) added',missionScopeMismatch:'Mission layers can only be grouped when they belong to the same mission.',missionLayerTutorialTitle:'Mission-linked layers',missionLayerTutorialText:'Add an image directly to one mission: BannerLab places, crops and clips it automatically. “Import a series” assigns 6, 12, 18 images or more in one pass.'});
Object.assign(I18N.es,{addMissionLayer:'En una misión',importMissionSeries:'Importar una serie',missionLayer:'Capa de misión',globalLayer:'Capa global',layerScope:'Alcance de la capa',wholeBanner:'Mural completo',missionTarget:'Misión asociada',fitMode:'Ajuste',fitCover:'Rellenar',fitContain:'Contener',missionBadge:'M{n}',missionLayerHint:'Esta capa queda vinculada a la misión {n} y se limita automáticamente a su casilla.',missionSeriesTitle:'Importar una serie de misiones',missionSeriesText:'Asocia cada imagen a una misión. BannerLab las coloca y recorta automáticamente.',missionSeriesDetected:'{n} imagen(es) detectada(s)',missionSeriesImport:'Importar capas',missionSeriesTooMany:'Has seleccionado más imágenes que misiones. Se pueden asociar varias imágenes a la misma misión.',missionLayerAdded:'Imagen añadida a la misión {n}',missionSeriesAdded:'{n} capa(s) de misión añadida(s)',missionScopeMismatch:'Las capas de misión solo se pueden agrupar si pertenecen a la misma misión.',missionLayerTutorialTitle:'Capas vinculadas a misiones',missionLayerTutorialText:'Añade una imagen directamente a una misión: BannerLab la coloca, recorta y limita automáticamente a esa casilla. «Importar una serie» permite asignar 6, 12, 18 imágenes o más de una vez.'});

function tr(key,vars={}){
  let s=(I18N[APP_LANG]&&I18N[APP_LANG][key])||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))s=s.replaceAll('{'+k+'}',String(v));
  return s;
}
function setAppLanguage(lang){
  if(!SUPPORTED_LANGS.includes(lang))return;
  localStorage.setItem('rbl-language',lang);
  location.reload();
}

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  projectLanguage: APP_LANG,
  name: 'Ma fresque',
  rows: 3,
  showGrid: true,
  showCircles: true,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0, visible:true, name:'' },
  imageLayers: [],
  texts: [],
  customFonts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    reuseLastPortal: true,
    currentMission: 0,
    missions: []
  }
};

let activeFlow = 'fresco';
let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;
let historyUndo = [];
let historyRedo = [];
let historyBusy = false;
const HISTORY_LIMIT = 80;

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function snapshotState(){
  const data=serializeState();
  delete data.updatedAt;delete data.customFonts;
  return {
    data:deepClone(data),
    blob:state.bg.blob,
    image:state.bg.image,
    layerMedia:state.imageLayers.map(l=>({id:l.id,blob:l.blob,image:l.image})),
    active:state.active
  };
}
function snapshotsEqual(a,b){
  if(!a||!b||a.blob!==b.blob||a.image!==b.image||a.active!==b.active||JSON.stringify(a.data)!==JSON.stringify(b.data))return false;
  const am=a.layerMedia||[],bm=b.layerMedia||[];
  return am.length===bm.length&&am.every((x,i)=>x.id===bm[i]?.id&&x.blob===bm[i]?.blob&&x.image===bm[i]?.image);
}
function beginHistory(){return historyBusy?null:snapshotState()}
function commitHistory(before,label='Modification'){
  if(historyBusy||!before)return;
  const after=snapshotState();
  if(snapshotsEqual(before,after))return;
  historyUndo.push({snapshot:before,label});
  if(historyUndo.length>HISTORY_LIMIT)historyUndo.shift();
  historyRedo.length=0;
  updateHistoryUi();
}
function resetHistory(){historyUndo=[];historyRedo=[];updateHistoryUi()}
async function restoreSnapshot(snap){
  if(!snap)return;
  historyBusy=true;
  try{
    const d=snap.data||{};
    state.name=d.name||'Ma fresque';
    state.rows=clamp(parseInt(d.rows)||3,1,25);
    state.showGrid=d.showGrid!==false;state.showCircles=d.showCircles!==false;state.showNumbers=d.showNumbers!==false;
    state.editMode=d.editMode==='mission'?'mission':'fresco';
    state.selectedMissionKey=d.selectedMissionKey||null;
    state.missionOverrides=deepClone(d.missionOverrides||{});
    state.texts=deepClone(d.texts||[]);normalizeAllTextStyles();
    state.imageLayers=deepClone(d.imageLayers||[]).map(l=>({...l,image:null,blob:null,visible:l.visible!==false}));
    const media=new Map((snap.layerMedia||[]).map(x=>[x.id,x]));
    for(const layer of state.imageLayers){
      const m=media.get(layer.id);if(m){layer.blob=m.blob||null;layer.image=m.image||null}
      if(!layer.image&&layer.blob)layer.image=await blobToImage(layer.blob);
    }
    state.active=snap.active||'background';
    state.planner=normalizePlanner(d.planner||{});ensurePlannerMissions();
    state.bg={image:snap.image||null,blob:snap.blob||null,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,visible:true,name:''};
    Object.assign(state.bg,d.bg||{});state.bg.visible=d.bg?.visible!==false;
    if(!state.bg.image&&state.bg.blob)state.bg.image=await blobToImage(state.bg.blob);
    refreshProjectUi();render();
    if(missionEditorBack)renderMissionEditor();
    scheduleSave();
  }finally{historyBusy=false;updateHistoryUi()}
}
async function undoAction(){
  const item=historyUndo.pop();if(!item)return;
  historyRedo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('undo')} · ${item.label}`);
}
async function redoAction(){
  const item=historyRedo.pop();if(!item)return;
  historyUndo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('redo')} · ${item.label}`);
}
function updateHistoryUi(){
  const undoDisabled=!historyUndo.length,redoDisabled=!historyRedo.length;
  $$('.undoActionBtn').forEach(b=>{b.disabled=undoDisabled;b.classList.toggle('disabled',undoDisabled);b.title=undoDisabled?tr('undo'):`${tr('undo')} · ${historyUndo.at(-1).label}`});
  $$('.redoActionBtn').forEach(b=>{b.disabled=redoDisabled;b.classList.toggle('disabled',redoDisabled);b.title=redoDisabled?tr('redo'):`${tr('redo')} · ${historyRedo.at(-1).label}`});
}
function historyControl(el,label){
  if(!el)return;
  let before=null;
  const begin=()=>{if(before===null)before=beginHistory()};
  const commit=()=>{if(before!==null){commitHistory(before,label);before=null}};
  el.addEventListener('pointerdown',begin);
  el.addEventListener('focus',begin);
  el.addEventListener('change',commit);
  el.addEventListener('blur',commit);
}

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    settingsGear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21H9.6v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4V9.6h.1A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6A1.7 1.7 0 0 0 10 2.5V2.4h4v.1a1.7 1.7 0 0 0 1 1.7 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.1v4h-.1a1.7 1.7 0 0 0-1.7 1Z"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2-4.5-4.4 6.2-.9L12 3Z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand">
        <button class="brandmark brandegg" id="brandEgg" aria-label="Redacted"><img src="/redacted-logo-512.png" alt="Redacted"></button>
        <div><h1>Redacted BannerLab</h1><small>${tr('subtitle')} · v${APP_VERSION}</small></div>
      </div>
      <div class="grow"></div><button class="playhubbtn" id="playHubBtn" aria-label="${tr('playBanners')}">${icon('search')}<span>${tr('playBanners')}</span></button><button class="iconbtn" id="infoBtn" aria-label="${tr('settingsInfo')}" title="${tr('settingsInfo')}">${icon('settingsGear')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div class="projectidentity"><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> ${tr('missions').toLowerCase()} · ${tr('source')} ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>${tr("projects")}</span></button>
        <div class="rowpick"><span>${tr("rows")}</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>${tr("fresco")}</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>${tr("route")}</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>${tr("missions")}</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>${tr("publish")}</span></button>
      </div>
      <div class="card workspace" id="workspaceCard">
        <div class="flowlockveil" id="flowLockVeil" hidden>
          <div class="flowlockbox">
            <strong>🔒 ${tr('flowLocked')}</strong>
            <span id="flowLockText">${tr('flowLockedText',{step:tr('route')})}</span>
            <small>${tr('returnFresco')}</small>
          </div>
        </div>
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">${tr("wholeFresco")}</button>
          <button class="modebtn" data-editmode="mission">${tr("oneMission")}</button>
          <div class="missionstatus" id="missionStatus">${tr("noMission")}</div>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>${tr("addImage")}</strong>${tr("imageHint")}</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">${tr("circles")}</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">${tr("grid")}</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">${tr("numbers")}</button>
          <button class="chip studioedit" id="openStudioEditorBtn">${icon('expand')} ${tr("studioEdit")}</button>
          <button class="chip historychip undoActionBtn" id="undoBtn" disabled>↶ ${tr("undo")}</button>
          <button class="chip historychip redoActionBtn" id="redoBtn" disabled>↷ ${tr("redo")}</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} ${tr("enlarge")}</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>${tr("resetMission")}</button>
        </div>
        <div class="hint" id="gestureHint">${tr('bannerHelp')}</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>${tr("image")}</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>${tr("text")}</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>${tr("preview")}</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>${tr("export")}</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function flowIsEditable(){return activeFlow==='fresco'}
function activeFlowLabel(){
  return activeFlow==='route'?tr('route'):activeFlow==='missions'?tr('missions'):activeFlow==='publish'?tr('publish'):tr('fresco');
}
function applyFlowLock(){
  const locked=!flowIsEditable();
  const workspace=$('#workspaceCard');
  const veil=$('#flowLockVeil');
  workspace?.classList.toggle('flowlocked',locked);
  if(veil)veil.hidden=!locked;
  const txt=$('#flowLockText');
  if(txt)txt.textContent=tr('flowLockedText',{step:activeFlowLabel()});

  const rows=$('#rowsSelect');
  if(rows)rows.disabled=locked;

  // Editing tools only. Preview/export remain usable.
  $$('.tool[data-tool="image"],.tool[data-tool="text"]').forEach(b=>{
    b.classList.toggle('flowdisabled',locked);
    b.setAttribute('aria-disabled',locked?'true':'false');
  });

  $$('.flowstep').forEach(b=>b.classList.toggle('on',b.dataset.flow===activeFlow));
}
function requireFrescoFlow(){
  if(flowIsEditable())return true;
  toast(tr('flowLockedToast'));
  return false;
}
function setFlowStep(flow,{open=true}={}){
  if(!['fresco','route','missions','publish'].includes(flow))flow='fresco';
  activeFlow=flow;
  applyFlowLock();

  if(!open)return;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawImageObject(c,b){
  if(!b?.image||b.visible===false)return;
  c.save();c.translate(b.x||0,b.y||0);c.rotate(b.rotation||0);c.scale(b.scale||1,b.scale||1);
  c.globalAlpha=clamp(Number.isFinite(+b.opacity)?+b.opacity:1,0,1);
  c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
}
function drawImageLayerObject(c,layer){normalizeImageLayerScope(layer);if(layer.scope!=='mission'){drawImageObject(c,layer);return}const r=missionLayerRect(layer);if(!r||!layer?.image||layer.visible===false)return;c.save();c.beginPath();c.rect(r.x,r.y,TILE,TILE);c.clip();drawImageObject(c,layer);c.restore()}
function drawBaseBackground(c){
  drawImageObject(c,state.bg);
  for(const layer of state.imageLayers)drawImageLayerObject(c,layer);
}
function hasImageContent(){return !!state.bg.image||state.imageLayers.some(l=>!!l.image)}
function activeImageLayer(){
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||null;
  return null;
}
function imageLayerLabel(layer,index){return layer?.name?.trim()||`${tr('layerName')} ${index+1}`}
function groupLayersFor(layer){return layer?.groupId?state.imageLayers.filter(x=>x.groupId===layer.groupId):layer?[layer]:[]}

const BUILTIN_TEXT_FONTS=[
  {value:'system-ui, sans-serif',label:'System'},
  {value:'Arial, sans-serif',label:'Arial'},
  {value:'Georgia, serif',label:'Georgia'},
  {value:'serif',label:'Serif'},
  {value:'monospace',label:'Monospace'},
  {value:'cursive',label:'Cursive'}
];
const registeredProjectFontFamilies=new Set();
function textDefaults(t={}){
  return Object.assign({fontFamily:'system-ui, sans-serif',fontWeight:800,fontItalic:false,letterSpacing:0,lineHeight:1.08,textAlign:'center',backgroundEnabled:false,backgroundColor:'#07100c',backgroundOpacity:.72,backgroundPadding:24,backgroundRadius:24},t||{});
}
function normalizeTextStyle(t){
  if(!t)return t;const d=textDefaults();
  for(const [k,v] of Object.entries(d))if(t[k]===undefined||t[k]===null)t[k]=v;
  t.fontWeight=clamp(parseInt(t.fontWeight)||800,100,900);t.letterSpacing=clamp(Number(t.letterSpacing)||0,-40,160);t.lineHeight=clamp(Number(t.lineHeight)||1.08,.7,2.4);{const op=Number(t.backgroundOpacity);t.backgroundOpacity=clamp(Number.isFinite(op)?op:.72,0,1);}t.backgroundPadding=clamp(Number(t.backgroundPadding)||0,0,180);t.backgroundRadius=clamp(Number(t.backgroundRadius)||0,0,240);if(!['left','center','right'].includes(t.textAlign))t.textAlign='center';return t;
}
function normalizeAllTextStyles(){state.texts.forEach(normalizeTextStyle)}
function textFontCss(t){normalizeTextStyle(t);return `${t.fontItalic?'italic ':'normal '}${t.fontWeight||800} ${t.fontSize||180}px ${t.fontFamily||'system-ui, sans-serif'}`}
function fontOptionsHtml(selected){
  const builtin=BUILTIN_TEXT_FONTS.map(f=>`<option value="${escapeAttr(f.value)}" ${selected===f.value?'selected':''}>${escapeHtml(f.label)}</option>`).join('');
  const custom=(state.customFonts||[]).map(f=>`<option value="${escapeAttr(f.family)}" ${selected===f.family?'selected':''}>★ ${escapeHtml(f.name||f.family)}</option>`).join('');
  return builtin+custom;
}
function bytesToBase64(bytes){let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary)}
async function registerProjectFont(rec){
  if(!rec?.family||!rec?.dataUrl)return false;if(registeredProjectFontFamilies.has(rec.family))return true;if(typeof FontFace==='undefined'||!document.fonts)return false;
  try{const face=new FontFace(rec.family,`url(${rec.dataUrl})`);await face.load();document.fonts.add(face);registeredProjectFontFamilies.add(rec.family);return true}catch(e){console.warn('custom font',rec.name,e);return false}
}
async function registerProjectFonts(){for(const rec of (state.customFonts||[]))await registerProjectFont(rec)}
async function importProjectFont(applyToText=null,onDone=null){
  const input=document.createElement('input');input.type='file';input.accept='.ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{
    const file=input.files?.[0];if(!file)return;if(file.size>12*1024*1024){toast(tr('fontTooLarge'));return}
    const ext=(file.name.split('.').pop()||'').toLowerCase();if(!['ttf','otf','woff','woff2'].includes(ext)){toast(tr('fontInvalid'));return}
    const id='font_'+uid(),family='RBLFont_'+id.replace(/[^a-z0-9_]/gi,''),mime=file.type||({ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2'}[ext]||'application/octet-stream');
    const dataUrl=`data:${mime};base64,${bytesToBase64(new Uint8Array(await file.arrayBuffer()))}`;const rec={id,name:file.name,family,mime,dataUrl};state.customFonts.push(rec);const ok=await registerProjectFont(rec);if(!ok){state.customFonts=state.customFonts.filter(x=>x.id!==id);toast(tr('fontInvalid'));return}
    if(applyToText){applyToText.fontFamily=family;normalizeTextStyle(applyToText)}scheduleSave();render();toast(tr('fontImported',{name:file.name}));if(onDone)onDone(rec);
  }catch(e){console.warn('font import',e);toast(tr('fontInvalid'))}finally{input.remove()}};input.click();
}
function measureSpacedLine(c,line,t){const chars=Array.from(String(line||''));return c.measureText(String(line||'')).width+Math.max(0,chars.length-1)*(t.letterSpacing||0)}
function textBlockMetrics(c,t){
  normalizeTextStyle(t);c.font=textFontCss(t);const lines=(t.text||tr('text')).split('\n'),lineH=(t.fontSize||180)*(t.lineHeight||1.08),widths=lines.map(line=>measureSpacedLine(c,line,t)),maxW=Math.max(40,...widths),h=Math.max(lineH,lines.length*lineH),pad=t.backgroundEnabled?(t.backgroundPadding||0):0;return {lines,lineH,widths,maxW,h,pad,bgW:maxW+pad*2,bgH:h+pad*2};
}
function roundedRectPath(c,x,y,w,h,r){r=Math.max(0,Math.min(r,Math.min(w,h)/2));c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath()}
function drawSpacedLine(c,line,x,y,t,maxW){
  const chars=Array.from(String(line||'')),spacing=t.letterSpacing||0,width=measureSpacedLine(c,line,t);let start=x-width/2;if(t.textAlign==='left')start=x-maxW/2;else if(t.textAlign==='right')start=x+maxW/2-width;
  if(Math.abs(spacing)<.001){c.textAlign=t.textAlign;const tx=t.textAlign==='left'?x-maxW/2:t.textAlign==='right'?x+maxW/2:x;if(t.strokeWidth>0)c.strokeText(line,tx,y);c.fillText(line,tx,y);return}
  c.textAlign='left';for(const ch of chars){if(t.strokeWidth>0)c.strokeText(ch,start,y);c.fillText(ch,start,y);start+=c.measureText(ch).width+spacing}
}

function drawOverlayWorld(c){
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  normalizeTextStyle(t);c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);c.font=textFontCss(t);c.textBaseline='middle';c.lineJoin='round';
  const m=textBlockMetrics(c,t);
  if(t.backgroundEnabled){c.save();c.globalAlpha=t.backgroundOpacity??.72;c.fillStyle=t.backgroundColor||'#07100c';roundedRectPath(c,-m.bgW/2,-m.bgH/2,m.bgW,m.bgH,t.backgroundRadius||0);c.fill();c.restore()}
  c.lineWidth=t.strokeWidth||0;c.strokeStyle=t.strokeColor||'#07100c';c.fillStyle=t.color||'#ffffff';
  m.lines.forEach((line,i)=>{const y=(i-(m.lines.length-1)/2)*m.lineH;drawSpacedLine(c,line,0,y,t,m.maxW)});c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseBackground(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseBackground(c);
    c.restore();
  }
  drawOverlayWorld(c);
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=hasImageContent()?'none':'grid';
  updateMissionUi();
  updateHistoryUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission')return;
  if(state.active.startsWith('text:')){
    const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
    c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
    normalizeTextStyle(t);c.font=textFontCss(t);const m=textBlockMetrics(c,t),w=(t.backgroundEnabled?m.bgW:m.maxW)+36,h=(t.backgroundEnabled?m.bgH:m.h)+28;
    c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
    return;
  }
  const layer=activeImageLayer();if(!layer?.image||layer.visible===false)return;
  const group=groupLayersFor(layer);
  for(const item of group){
    if(!item.image||item.visible===false)continue;
    c.save();c.scale(s,s);c.translate(item.x,item.y);c.rotate(item.rotation||0);c.scale(item.scale||1,item.scale||1);
    const inv=Math.max(.0001,s*(item.scale||1));
    c.strokeStyle=item===layer?'#ffcc66':'rgba(255,204,102,.55)';c.lineWidth=4/inv;c.setLineDash([14/(item.scale||1),10/(item.scale||1)]);
    c.strokeRect(-item.image.naturalWidth/2,-item.image.naturalHeight/2,item.image.naturalWidth,item.image.naturalHeight);c.restore();
  }
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}
function rowColForMissionAtRows(n,rows){n=Math.max(1,parseInt(n)||1);return {row:rows-1-Math.floor((n-1)/6),col:5-((n-1)%6)}}
function missionLayerNumber(layer){return layer?.scope==='mission'?Math.max(1,parseInt(layer.missionNumber)||1):null}
function missionLayerRect(layer,rows=state.rows){const n=missionLayerNumber(layer);if(!n||n>rows*COLS)return null;const rc=rowColForMissionAtRows(n,rows);if(rc.row<0||rc.row>=rows)return null;return {n,row:rc.row,col:rc.col,x:rc.col*STEP+PAD,y:rc.row*STEP+PAD,cx:rc.col*STEP+PAD+TILE/2,cy:rc.row*STEP+PAD+TILE/2}}
function missionLayerFitScale(layer,mode=layer?.fitMode||'cover'){if(!layer?.image)return 1;return mode==='contain'?Math.min(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight):Math.max(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight)}
function normalizeImageLayerScope(layer){if(!layer)return layer;layer.scope=layer.scope==='mission'?'mission':'global';if(layer.scope==='mission'){layer.missionNumber=Math.max(1,parseInt(layer.missionNumber)||1);layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}else{layer.missionNumber=null;layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}return layer}
function reanchorMissionLayers(oldRows,newRows){for(const l of state.imageLayers){normalizeImageLayerScope(l);if(l.scope!=='mission')continue;const n=missionLayerNumber(l),oldRc=n&&n<=oldRows*COLS?rowColForMissionAtRows(n,oldRows):null,newRc=n&&n<=newRows*COLS?rowColForMissionAtRows(n,newRows):null;if(!newRc)continue;const oldCx=oldRc?oldRc.col*STEP+PAD+TILE/2:l.x||0,oldCy=oldRc?oldRc.row*STEP+PAD+TILE/2:l.y||0,newCx=newRc.col*STEP+PAD+TILE/2,newCy=newRc.row*STEP+PAD+TILE/2;l.x=(l.x||oldCx)+(newCx-oldCx);l.y=(l.y||oldCy)+(newCy-oldCy)}}
function missionLayerBadgeHtml(layer){const n=missionLayerNumber(layer);return n?`<span class="missionLayerBadge">${escapeHtml(tr('missionBadge',{n}))}</span>`:''}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  const isImage=a==='background'||a.startsWith('image:');
  $$('.tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='layers'));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  else state.selectedMissionKey=null;
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=tr('missionSelected',{n:missionNumber(rc.row,rc.col)});
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent=tr('tapMedallion');reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML=tr('missionHelp');
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML=tr('bannerHelp');
  }
}

let pendingImageMode='background';
async function loadImageFile(file){
  if(!file)return;
  const before=beginHistory();
  if(file.size>45*1024*1024)toast(tr('heavyImage'));
  const img=await blobToImage(file);
  if(pendingImageMode==='background'){
    state.bg.blob=file;state.bg.image=img;state.bg.visible=true;state.bg.name=tr('backgroundLayer');
    fitBackground();setEditMode('fresco');setActive('background');commitHistory(before,tr('histImport'));toast(tr('backgroundReplaced'));
  }else{
    const layer={id:uid(),name:file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'global',missionNumber:null,fitMode:'cover'};
    fitImageLayer(layer);state.imageLayers.push(layer);setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));toast(tr('layerAdded'));
  }
  scheduleSave();render();if(studioEditorRoot)refreshStudioEditor();toast(`${tr('imported',{w:img.naturalWidth,h:img.naturalHeight})} · ${pendingImageMode==='background'?tr('backgroundReplaced'):tr('layerAdded')}`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight);b.visible=true;b.opacity=1}
function fitImageLayer(layer){if(!layer?.image)return;normalizeImageLayerScope(layer);if(layer.scope==='mission'){const r=missionLayerRect(layer);if(r){layer.x=r.cx;layer.y=r.cy;layer.scale=missionLayerFitScale(layer)}}else{layer.x=WORLD_W/2;layer.y=worldH()/2;layer.scale=Math.min(WORLD_W*.72/layer.image.naturalWidth,worldH()*.72/layer.image.naturalHeight)}layer.rotation=0;layer.opacity=1;layer.visible=true}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;state.bg.name=tr('backgroundLayer');state.bg.visible=true;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasClientToWorld(clientX,clientY){
  if(studioEditorRoot){
    const stage=$('.studioCanvasStage',studioEditorRoot),rect=stage?.getBoundingClientRect(),scale=Math.max(.0001,studioViewScale);
    if(rect)return {x:(clientY-rect.top)/scale,y:(rect.right-clientX)/scale};
  }
  const rect=canvas.getBoundingClientRect(),scale=rect.width/WORLD_W;return {x:(clientX-rect.left)/scale,y:(clientY-rect.top)/scale};
}
function clientDeltaToWorld(dx,dy){
  const scale=Math.max(.0001,getCssScale());return studioEditorRoot?{dx:dy/scale,dy:-dx/scale}:{dx:dx/scale,dy:dy/scale};
}
function canvasPointToMission(clientX,clientY){
  const pt=canvasClientToWorld(clientX,clientY),x=pt.x,y=pt.y;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

function frescoTransformTargets(){
  const obj=selectedObj();if(!obj)return[];
  if(state.active.startsWith('image:')&&obj.groupId)return groupLayersFor(obj);
  return [obj];
}
function captureTransformTargets(targets){return targets.map(obj=>({obj,x:obj.x||0,y:obj.y||0,scale:obj.scale??1,rotation:obj.rotation||0}))}
function transformCenter(items){if(!items.length)return{x:0,y:0};return{x:items.reduce((a,t)=>a+t.x,0)/items.length,y:items.reduce((a,t)=>a+t.y,0)/items.length}}
function makeFrescoTwoGesture(points,historyBefore){const items=captureTransformTargets(frescoTransformTargets());return{mode:'two',dist:distance(points[0],points[1]),angle:angle(points[0],points[1]),mid:mid(points[0],points[1]),items,center:transformCenter(items),historyBefore}}

canvas.addEventListener('pointerdown',e=>{
  if(!requireFrescoFlow())return;
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    const changed=state.selectedMissionKey!==hit.key;
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();
    // Le premier toucher choisit la mission sans la déplacer. Les gestes suivants
    // sur cette même mission servent ensuite à la transformer.
    if(changed){gesture=null;return}
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(state.editMode==='mission'){
    if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:beginHistory()};
    else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()}}
    return;
  }
  if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,items:captureTransformTargets(frescoTransformTargets()),historyBefore:beginHistory()};
  else if(pointers.size===2)gesture=makeFrescoTwoGesture([...pointers.values()],gesture?.historyBefore||beginHistory());
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(state.editMode==='mission'){
    if(pointers.size===1&&gesture?.mode==='one'){
      const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }else if(pointers.size===2){
      const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()};return}
      const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),.2,5);obj.rotation=gesture.objRot+(a-gesture.angle);const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }
    return;
  }
  if(pointers.size===1&&gesture?.mode==='one'){
    const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);for(const t of gesture.items||[]){t.obj.x=t.x+dxy.dx;t.obj.y=t.y+dxy.dy}render();
  }else if(pointers.size===2){
    const pts=[...pointers.values()];if(gesture?.mode!=='two'){gesture=makeFrescoTwoGesture(pts,gesture?.historyBefore||beginHistory());return}
    const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]),factor=d/Math.max(1,gesture.dist),rd=a-gesture.angle,cs=Math.cos(rd),sn=Math.sin(rd);
    const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y),nc={x:gesture.center.x+dxy.dx,y:gesture.center.y+dxy.dy};
    for(const t of gesture.items||[]){const ox=(t.x-gesture.center.x)*factor,oy=(t.y-gesture.center.y)*factor;t.obj.x=nc.x+ox*cs-oy*sn;t.obj.y=nc.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*factor,.02,30);t.obj.rotation=t.rotation+rd}render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){
    const before=gesture?.historyBefore,label=state.editMode==='mission'?tr('histResetMission'):(state.active.startsWith('text:')?tr('histEditText'):(state.active.startsWith('image:')&&selectedObj()?.groupId?tr('groupTransform'):tr('frameImage')));
    gesture=null;commitHistory(before,label);scheduleSave();
  }else if(pointers.size===1){
    const p=[...pointers.values()][0],obj=selectedObj(),before=gesture?.historyBefore;
    if(state.editMode==='mission'&&obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:before};
    else gesture={mode:'one',startX:p.x,startY:p.y,items:captureTransformTargets(frescoTransformTargets()),historyBefore:before};
  }
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return studioEditorRoot?Math.max(.0001,studioViewScale):canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||'Ma fresque';ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>{if(!requireFrescoFlow()){e.target.value=String(state.rows);return}changeRows(+e.target.value)});
$('#openStudioEditorBtn').addEventListener('click',openStudioEditor);
function changeRows(rows){
  const before=beginHistory();
  const oldRows=state.rows,oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.imageLayers.filter(l=>l.scope!=='mission').forEach(l=>l.y+=(newH/2-oldCenter));reanchorMissionLayers(oldRows,state.rows);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();commitHistory(before,tr('rows'));scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;setEditMode(btn.dataset.editmode)}));
$('#resetMissionBtn').addEventListener('click',()=>{if(requireFrescoFlow())resetSelectedMission()});
$('#openMissionEditorBtn').addEventListener('click',()=>{if(requireFrescoFlow())openMissionEditor()});

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(['image','text'].includes(t)&&!requireFrescoFlow())return;
  if(t==='image')openImageLayersSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#playHubBtn').addEventListener('click',()=>openPlayHub('search'));
let eggTaps=0,eggTimer=null;
$('#brandEgg').addEventListener('click',()=>{
  eggTaps++;clearTimeout(eggTimer);eggTimer=setTimeout(()=>{eggTaps=0},2200);
  if(eggTaps>=7){eggTaps=0;clearTimeout(eggTimer);runDinoEasterEgg()}
});
$('#infoBtn').addEventListener('click',openInfoSheet);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$('#undoBtn').addEventListener('click',()=>{if(requireFrescoFlow())undoAction()});
$('#redoBtn').addEventListener('click',()=>{if(requireFrescoFlow())redoAction()});
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  setFlowStep(btn.dataset.flow);
}));

applyFlowLock();

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}


function runDinoEasterEgg(){
  if($('.rblDinoEgg'))return;
  const wrap=document.createElement('div');wrap.className='rblDinoEgg';
  wrap.innerHTML=`<img src="/redacted-dino-cutout.png" alt=""><span>${escapeHtml(tr('easterEgg'))}</span>`;
  document.body.appendChild(wrap);
  const img=$('img',wrap);
  const done=()=>wrap.remove();
  img.addEventListener('animationend',done,{once:true});
  setTimeout(done,4300);
}

function loadBannerFavorites(){
  try{const x=JSON.parse(localStorage.getItem(BANNER_FAVORITES_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}
}
function saveBannerFavorites(items){localStorage.setItem(BANNER_FAVORITES_KEY,JSON.stringify(items.slice(0,120)));markBackupChanged()}
function isBannerFavorite(id){return loadBannerFavorites().some(x=>String(x.id)===String(id))}
function favoriteBanner(detail){
  const list=loadBannerFavorites().filter(x=>String(x.id)!==String(detail.id));
  list.unshift(compactBanner(detail));saveBannerFavorites(list);return true;
}
function unfavoriteBanner(id){saveBannerFavorites(loadBannerFavorites().filter(x=>String(x.id)!==String(id)))}
function compactBanner(detail){
  return {
    id:String(detail?.id||''),title:String(detail?.title||tr('unnamed')),
    formattedAddress:String(detail?.formattedAddress||''),lengthMeters:Number(detail?.lengthMeters||0)||0,
    numberOfMissions:Number(detail?.numberOfMissions||detail?.missions?.length||0)||0,
    numberOfDisabledMissions:Number(detail?.numberOfDisabledMissions||0)||0,
    picture:String(detail?.picture||''),author:String(detail?.author||'')
  };
}
function loadBannerTodo(){try{const x=JSON.parse(localStorage.getItem(BANNER_TODO_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function saveBannerTodo(items){localStorage.setItem(BANNER_TODO_KEY,JSON.stringify((items||[]).slice(0,160)));markBackupChanged()}
function isBannerTodo(id){return loadBannerTodo().some(x=>String(x.id)===String(id))}
function addBannerTodo(detail){const list=loadBannerTodo().filter(x=>String(x.id)!==String(detail.id));list.unshift(compactBanner(detail));saveBannerTodo(list)}
function removeBannerTodo(id){saveBannerTodo(loadBannerTodo().filter(x=>String(x.id)!==String(id)))}
function loadPlayHistory(){try{const x=JSON.parse(localStorage.getItem(PLAY_HISTORY_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function savePlayHistory(items){localStorage.setItem(PLAY_HISTORY_KEY,JSON.stringify((items||[]).slice(0,100)));markBackupChanged()}
function upsertPlayHistory(session,extra={}){
  if(!session?.bannerId)return;
  const list=loadPlayHistory();const key=String(session.bannerId);
  const old=list.find(x=>String(x.bannerId)===key)||{};
  const rec={...old,...compactBanner({id:session.bannerId,title:session.title,formattedAddress:session.address,picture:session.picture,author:session.author,lengthMeters:session.lengthMeters,numberOfMissions:session.missions?.length}),
    bannerId:key,currentIndex:Number(extra.currentIndex??session.currentIndex??old.currentIndex??0)||0,
    doneCount:Number(extra.doneCount??old.doneCount??0)||0,total:Number(session.missions?.length||old.total||0)||0,
    startedAt:Number(extra.startedAt??session.startedAt??old.startedAt??Date.now())||Date.now(),
    finishedAt:Number(extra.finishedAt??old.finishedAt??0)||0,pausedTotal:Number(extra.pausedTotal??old.pausedTotal??0)||0,
    paused:!!(extra.paused??old.paused),updatedAt:Date.now()};
  const out=[rec,...list.filter(x=>String(x.bannerId)!==key)].sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));savePlayHistory(out);return rec;
}
function activeDurationMs(x){
  const start=Number(x?.startedAt||0);if(!start)return 0;
  const end=Number(x?.finishedAt||Date.now());let paused=Number(x?.pausedTotal||0)||0;
  if(x?.paused&&x?.pausedAt)paused+=Math.max(0,Date.now()-Number(x.pausedAt));
  return Math.max(0,end-start-paused);
}
function formatPlayDuration(ms){
  const min=Math.floor(Math.max(0,ms)/60000),h=Math.floor(min/60),m=min%60;
  return h?`${h} h ${String(m).padStart(2,'0')}`:`${m} min`;
}
function formatPlayDate(ts){if(!ts)return '—';const locale=APP_LANG==='fr'?'fr-FR':APP_LANG==='es'?'es-ES':'en-GB';return new Date(ts).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'})}
function estimatedPlayedMeters(entry){const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1));return (Number(entry?.lengthMeters||0)||0)*Math.min(1,(Number(entry?.doneCount||0)||0)/total)}
function bannergressImage(picture=''){
  if(!picture)return '';
  return /^https?:/i.test(picture)?picture:`${BANNERGRESS_API}${picture.startsWith('/')?'':'/'}${picture}`;
}
function formatBannerDistance(meters){
  const m=Number(meters)||0;if(!m)return '—';return `${(m/1000).toFixed(m>=10000?0:1).replace('.',',')} km`;
}

function formatBannerMeters(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  if(m<1000)return `${Math.round(m)} m`;
  return `${(m/1000).toFixed(m<10000?2:1).replace('.',',')} km`;
}
function formatWalkSeconds(seconds){
  const total=Math.max(0,Math.round(Number(seconds)||0));
  if(!total)return '—';
  const minutes=Math.max(1,Math.round(total/60));
  if(minutes<60)return tr('minutesShort',{n:minutes});
  const h=Math.floor(minutes/60),m=minutes%60;
  return tr('hoursMinutes',{h,m:String(m).padStart(2,'0')});
}
function formatWalkEstimate(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  return formatWalkSeconds((m/4800)*3600);
}
function bannerRouteRows(detail){
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  return missions.map((m,index)=>{
    const route=Array.isArray(m?.route)?m.route.filter(p=>Number.isFinite(Number(p?.latitude))&&Number.isFinite(Number(p?.longitude))):[];
    let meters=0,longestLeg=0;
    for(let i=1;i<route.length;i++){
      const d=haversine(route[i-1],route[i]);
      meters+=d;
      longestLeg=Math.max(longestLeg,d);
    }
    return {index,route,meters,longestLeg,title:m?.title||tr('missionStart',{n:index+1})};
  });
}
function bannerFunStats(detail){
  const missionRows=bannerRouteRows(detail);
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  const withRoute=missionRows.filter(x=>x.route.length);
  const routeMeters=missionRows.reduce((s,x)=>s+x.meters,0);
  let transitionMeters=0,longestTransition=0;
  for(let i=1;i<withRoute.length;i++){
    const prev=withRoute[i-1].route.at(-1),next=withRoute[i].route[0];
    const d=haversine(prev,next);
    transitionMeters+=d;
    longestTransition=Math.max(longestTransition,d);
  }
  const geometricMeters=routeMeters+transitionMeters;
  const bgMeters=Number(detail?.lengthMeters||0)||0;

  const allPoints=missionRows.flatMap(x=>x.route);
  const uniqueKeys=new Set(allPoints.map(p=>`${Number(p.latitude).toFixed(5)},${Number(p.longitude).toFixed(5)}`));
  const uniquePlaces=uniqueKeys.size;
  const repeated=Math.max(0,allPoints.length-uniquePlaces);

  let longestMission=null,longestLeg=0;
  for(const row of missionRows){
    if(!longestMission||row.meters>longestMission.meters)longestMission=row;
    longestLeg=Math.max(longestLeg,row.longestLeg);
  }

  const start=allPoints[0]||null,end=allPoints.at(-1)||null;
  const straight=start&&end?haversine(start,end):0;
  const missionCount=Math.max(1,missions.length);
  const mappedMissionCount=withRoute.length;
  const coverage=missions.length?Math.round(mappedMissionCount/missions.length*100):0;

  return {
    bgMeters,routeMeters,transitionMeters,geometricMeters,
    points:allPoints.length,uniquePlaces,repeated,
    avgMission:routeMeters/missionCount,
    longestMission,longestLeg,longestTransition,
    straight,coverage,mappedMissionCount,totalMissions:missions.length,
    missionRows
  };
}
function bannerWalkSignature(detail){
  const rows=bannerRouteRows(detail);
  return JSON.stringify(rows.flatMap(r=>r.route.map(p=>[
    r.index,
    Number(p.latitude).toFixed(6),
    Number(p.longitude).toFixed(6)
  ])));
}
function bannerWalkCacheKey(detail){
  const id=String(detail?.id??detail?.bannerId??'unknown').replace(/[^a-zA-Z0-9_.:-]/g,'_');
  return `${BANNER_WALK_CACHE_PREFIX}${id}`;
}
function loadBannerWalkCache(detail){
  try{
    const x=JSON.parse(localStorage.getItem(bannerWalkCacheKey(detail))||'null');
    if(x?.sig===bannerWalkSignature(detail)&&x?.walking)return x.walking;
  }catch{}
  return null;
}
function saveBannerWalkCache(detail,walking){
  try{
    localStorage.setItem(bannerWalkCacheKey(detail),JSON.stringify({
      sig:bannerWalkSignature(detail),
      walking,
      at:Date.now()
    }));
  }catch{}
}
async function fetchValhallaWalkingChunk(chunk){
  const lang=APP_LANG==='en'?'en-US':APP_LANG==='es'?'es-ES':'fr-FR';
  const body={
    locations:chunk.map(x=>({
      lat:Number(x.point.latitude),
      lon:Number(x.point.longitude),
      type:'break'
    })),
    costing:'pedestrian',
    units:'kilometers',
    directions_options:{units:'kilometers',language:lang}
  };

  let data,status=0,transport='web';

  if(Capacitor.isNativePlatform()){
    transport='native';
    const response=await CapacitorHttp.post({
      url:VALHALLA_API,
      headers:{
        'Content-Type':'application/json',
        'Accept':'application/json',
        'X-Client-Id':'redacted-bannerlab'
      },
      data:body,
      connectTimeout:18000,
      readTimeout:18000,
      responseType:'json'
    });
    status=Number(response?.status)||0;
    data=response?.data;
    if(typeof data==='string'){
      try{data=JSON.parse(data)}catch{}
    }
  }else{
    // Browser/web fallback. GET with encoded json stays a simple request
    // and avoids the JSON POST preflight that can be blocked by CORS.
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),18000);
    try{
      const url=`${VALHALLA_API}?json=${encodeURIComponent(JSON.stringify(body))}`;
      const response=await fetch(url,{
        method:'GET',
        headers:{'Accept':'application/json'},
        signal:ctrl.signal
      });
      status=response.status;
      if(response.ok)data=await response.json();
      else{
        let msg='';
        try{msg=await response.text()}catch{}
        throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg.slice(0,120)}`:''}`);
      }
    }finally{
      clearTimeout(timer);
    }
  }

  if(status<200||status>=300){
    const msg=data?.error||data?.error_code||data?.status_message||'';
    throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg}`:''}`);
  }

  const legs=data?.trip?.legs||[];
  if(legs.length!==Math.max(0,chunk.length-1)){
    const msg=data?.error||data?.status_message||'incomplete route';
    throw new Error(`Valhalla ${msg} · ${legs.length}/${Math.max(0,chunk.length-1)} legs`);
  }

  return legs.map(leg=>({
    meters:(Number(leg?.summary?.length)||0)*1000,
    seconds:Number(leg?.summary?.time)||0,
    transport
  }));
}
async function calculateBannerWalkingStats(detail,{force=false}={}){
  const direct=bannerFunStats(detail);
  const flat=[];
  direct.missionRows.forEach(row=>{
    row.route.forEach((point,pointIndex)=>flat.push({
      point,
      missionIndex:row.index,
      pointIndex,
      title:point?.title||row.title||`M${row.index+1}`
    }));
  });
  if(flat.length<2)throw new Error('Not enough mapped points');

  if(!force){
    const cached=loadBannerWalkCache(detail);
    if(cached)return {...cached,cached:true};
  }

  const missionMeters=Array.from({length:direct.totalMissions},()=>0);
  const missionSeconds=Array.from({length:direct.totalMissions},()=>0);
  let totalMeters=0,totalSeconds=0,transitionMeters=0,transitionSeconds=0;
  let rawValhallaMeters=0,rawValhallaSeconds=0;
  let correctedLegs=0,tooShortLegs=0,absurdDetourLegs=0;
  let longestLegMeters=0,longestLegNames=null;
  let transport=Capacitor.isNativePlatform()?'native':'web';

  let cursor=0;
  while(cursor<flat.length-1){
    const end=Math.min(flat.length,cursor+VALHALLA_MAX_POINTS);
    const chunk=flat.slice(cursor,end);
    const legs=await fetchValhallaWalkingChunk(chunk);
    if(legs[0]?.transport)transport=legs[0].transport;

    legs.forEach((leg,i)=>{
      const a=chunk[i],b=chunk[i+1];
      const directMeters=haversine(a.point,b.point);
      const rawMeters=Math.max(0,Number(leg.meters)||0);
      const rawSeconds=Math.max(0,Number(leg.seconds)||0);

      rawValhallaMeters+=rawMeters;
      rawValhallaSeconds+=rawSeconds;

      let acceptedMeters=rawMeters;
      let acceptedSeconds=rawSeconds;

      // Same portal / nearly identical coordinate: no meaningful walking.
      if(directMeters<3){
        acceptedMeters=0;
        acceptedSeconds=0;
        if(rawMeters>15)correctedLegs++;
      }else{
        // A pedestrian-network route cannot realistically be much shorter
        // than straight-line centre-to-centre distance. This catches bad
        // snapping/correlation shortcuts.
        const impossibleShortcut=rawMeters < directMeters*0.88;

        // Catch isolated OSM/Valhalla detours without throwing away the whole
        // banner. The additive allowance is important for rivers, stations,
        // parks and other genuine obstacles.
        const maxPlausible=Math.max(directMeters*4,directMeters+350);
        const absurdDetour=rawMeters > maxPlausible;

        if(impossibleShortcut || absurdDetour || !rawMeters){
          acceptedMeters=directMeters;
          acceptedSeconds=(directMeters/4800)*3600;
          correctedLegs++;
          if(impossibleShortcut)tooShortLegs++;
          if(absurdDetour)absurdDetourLegs++;
        }
      }

      totalMeters+=acceptedMeters;
      totalSeconds+=acceptedSeconds;

      if(a.missionIndex===b.missionIndex){
        missionMeters[a.missionIndex]=(missionMeters[a.missionIndex]||0)+acceptedMeters;
        missionSeconds[a.missionIndex]=(missionSeconds[a.missionIndex]||0)+acceptedSeconds;
      }else{
        transitionMeters+=acceptedMeters;
        transitionSeconds+=acceptedSeconds;
      }

      if(acceptedMeters>longestLegMeters){
        longestLegMeters=acceptedMeters;
        longestLegNames=[a.title||'Portal',b.title||'Portal'];
      }
    });

    if(end>=flat.length)break;
    cursor=end-1;
    await new Promise(r=>setTimeout(r,160));
  }

  let longestMission=null;
  missionMeters.forEach((meters,index)=>{
    if(meters>0&&(!longestMission||meters>longestMission.meters)){
      longestMission={index,meters,seconds:missionSeconds[index]||0};
    }
  });

  const walking={
    totalMeters,totalSeconds,
    transitionMeters,transitionSeconds,
    missionMeters,missionSeconds,
    longestLegMeters,longestLegNames,longestMission,
    rawValhallaMeters,rawValhallaSeconds,
    correctedLegs,tooShortLegs,absurdDetourLegs,
    source:'valhalla-sanitized',
    transport
  };
  saveBannerWalkCache(detail,walking);
  return walking;
}
function bannerFunStatsHtml(detail,{compact=false,walking=null,routingError=false,loading=false}={}){
  const s=bannerFunStats(detail);
  if(!s.points&&!s.bgMeters)return `<div class="bannerStatsUnavailable">${tr('statsUnavailable')}</div>`;

  const effectiveMeters=walking?.totalMeters||s.geometricMeters||s.bgMeters;
  const effectiveSeconds=walking?.totalSeconds||0;
  const directKmBase=s.geometricMeters;
  const networkDetour=walking&&directKmBase>0?walking.totalMeters/directKmBase:null;

  const longestMission=walking?.longestMission?.meters>0
    ? `${tr('missionShort',{n:walking.longestMission.index+1})} · ${formatBannerMeters(walking.longestMission.meters)}`
    : s.longestMission&&s.longestMission.meters>0
      ? `${tr('missionShort',{n:s.longestMission.index+1})} · ${formatBannerMeters(s.longestMission.meters)}`
      : '—';

  const avgMission=walking?.missionMeters?.length
    ? walking.missionMeters.reduce((a,b)=>a+(Number(b)||0),0)/Math.max(1,s.totalMissions)
    : s.avgMission;

  const longestLeg=walking?.longestLegMeters||s.longestLeg;
  const between=walking?.transitionMeters??s.transitionMeters;
  const stepsPerKm=effectiveMeters>0?s.points/(effectiveMeters/1000):0;

  const items=[
    [tr('bgDistance'),formatBannerDistance(s.bgMeters),'🛣'],
    [tr('calculatedTrack'),loading?'…':formatBannerMeters(walking?.totalMeters||s.geometricMeters),'🚶'],
    [tr('walkingEstimate'),loading?'…':(walking?formatWalkSeconds(effectiveSeconds):formatWalkEstimate(effectiveMeters)),'⏱'],
    [tr('directGeometric'),formatBannerMeters(s.geometricMeters),'〰'],
    [tr('routeSteps'),String(s.points),'◉'],
    [tr('uniquePlaces'),String(s.uniquePlaces),'⌖'],
    [tr('revisitedPlaces'),String(s.repeated),'↻'],
    [tr('stepsPerKm'),stepsPerKm?String(stepsPerKm.toFixed(1)).replace('.',','):'—','⋮'],
    [tr('avgMissionDistance'),formatBannerMeters(avgMission),'÷'],
    [tr('longestMission'),longestMission,'🏆'],
    [tr('longestLeg'),formatBannerMeters(longestLeg),'↔'],
    [tr('betweenMissions'),formatBannerMeters(between),'⇢'],
    [tr('routingDetour'),networkDetour?tr('xFactor',{n:networkDetour.toFixed(2).replace('.',',')}):'—','🌀'],
    [tr('straightLine'),formatBannerMeters(s.straight),'⌁'],
    [tr('routeCoverage'),`${s.coverage} %`,'◫'],
    [tr('correctedLegs'),walking?`${walking.correctedLegs||0}`:'—','⚙'],
    [tr('rawValhalla'),walking?formatBannerMeters(walking.rawValhallaMeters):'—','V'],
    [tr('routingSource'),walking
      ?(walking.transport==='native'?tr('routingNative'):tr('routingWeb'))
      :(routingError?tr('routingFallback'):tr('routingLoading')),'OSM']
  ];

  const shown=compact
    ? [items[0],items[1],items[2],items[7],items[9],items[15]]
    : items;

  return `<div class="bannerFunStats ${compact?'compact':''} ${walking?'walkRouted':''}">
    <div class="bannerFunStatsTitle"><span>📊</span><b>${tr('uselessStats')}</b>${walking?.cached?'<em>cache</em>':''}</div>
    <div class="bannerFunStatsGrid">${shown.map(([label,value,ico])=>`<div><i>${ico}</i><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>
    ${routingError?`<div class="bannerRoutingWarn">${tr('routingFailed')}${typeof routingError==='string'?`<small>${escapeHtml(tr('routingErrorDetail',{error:routingError}))}</small>`:''}</div>`:''}
    ${compact?'':`<small>${tr('funStatsDisclaimer')}</small>`}
  </div>`;
}
async function renderBannerWalkingStats(panel,detail,{compact=false}={}){
  if(!panel)return;
  panel.innerHTML=bannerFunStatsHtml(detail,{compact,loading:true});
  try{
    const walking=await calculateBannerWalkingStats(detail);
    panel.innerHTML=bannerFunStatsHtml(detail,{compact,walking});
    return walking;
  }catch(e){
    console.warn('[Banner walking stats]',e);
    panel.innerHTML=bannerFunStatsHtml(detail,{
      compact,
      routingError:String(e?.message||e||'unknown error')
    });
    return null;
  }
}
async function toggleSearchBannerStats(button,summary){
  const wrap=button.closest('.bannergressCardWrap');
  const panel=wrap?.querySelector('.bannerSearchStats');
  if(!panel)return;
  const opening=panel.hidden;
  if(!opening){
    panel.hidden=true;
    button.textContent=tr('showUselessStats');
    return;
  }
  panel.hidden=false;
  button.disabled=true;
  button.textContent=tr('routingLoading');
  panel.innerHTML=`<div class="loadingInline">${tr('routingLoading')}</div>`;
  try{
    const detail=await fetchBannerDetail(summary);
    await renderBannerWalkingStats(panel,detail,{compact:true});
    button.textContent=tr('hideUselessStats');
  }catch(e){
    panel.innerHTML=`<div class="bannerStatsUnavailable">${escapeHtml(tr('bannerLoadError',{error:e?.message||e}))}</div>`;
    button.textContent=tr('showUselessStats');
  }finally{
    button.disabled=false;
  }
}
function bindBannerList(container,list,onOpen){
  $$('.bannergressCard',container).forEach(btn=>{
    btn.onclick=()=>{
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerId));
      if(b)(onOpen||openBannerDetail)(b);
    };
  });
  $$('.bannerStatsBtn',container).forEach(btn=>{
    btn.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerStatsId));
      if(b)toggleSearchBannerStats(btn,b);
    };
  });
}
function unwrapBannerSearch(raw){
  if(Array.isArray(raw))return raw;
  for(const candidate of [raw?.items,raw?.banners,raw?.results,raw?.data]){
    if(Array.isArray(candidate))return candidate;
    if(candidate&&typeof candidate==='object'){
      for(const key of ['banners','items','results'])if(Array.isArray(candidate[key]))return candidate[key];
    }
  }
  return [];
}
function normalizeGeoPoint(p){
  if(!p)return null;
  const lat=Number(p.latitude??p.lat??p.location?.latitude??p.location?.lat);
  const lng=Number(p.longitude??p.lng??p.lon??p.location?.longitude??p.location?.lng??p.location?.lon);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  return {latitude:lat,longitude:lng,title:String(p.title??p.name??p.portalTitle??'')};
}
function normalizeMissionList(raw){
  let list=raw?.items?.missions??raw?.missions??raw?.banner?.items?.missions??raw?.banner?.missions??[];
  if(!Array.isArray(list)&&list&&typeof list==='object')list=Object.values(list);
  if(!Array.isArray(list))return [];
  const normalized=list.map((m,i)=>{
    let steps=m?.steps??m?.waypoints??m?.points??[];
    if(!Array.isArray(steps)&&steps&&typeof steps==='object')steps=Object.values(steps);
    const route=(Array.isArray(steps)?steps:[]).map(s=>normalizeGeoPoint(s?.poi??s?.portal??s?.point??s)).filter(Boolean);
    const direct=normalizeGeoPoint(m?.startPoint??m?.startPoi??m?.poi);
    if(!route.length&&direct)route.push(direct);
    return {
      id:String(m?.id??m?.missionId??m?.guid??'').trim(),
      title:String(m?.title??m?.name??m?.missionTitle??`Mission ${i+1}`),
      order:Number(m?.order??m?.sequence??m?.position??m?.index??i),route
    };
  }).filter(m=>m.id);
  if(normalized.every(x=>Number.isFinite(x.order)))normalized.sort((a,b)=>a.order-b.order);
  return normalized.map(({id,title,route})=>({id,title,route}));
}
function normalizeBannerDetail(raw,fallback={}){
  const b=raw?.banner??raw?.item??raw?.data?.banner??raw?.data??raw??{};
  const source={...fallback,...b};
  const missions=normalizeMissionList(raw);
  return {
    id:String(source.id??fallback.id??''),
    title:String(source.title??fallback.title??tr('unnamed')),
    formattedAddress:String(source.formattedAddress??source.address??fallback.formattedAddress??''),
    lengthMeters:Number(source.lengthMeters??fallback.lengthMeters??0)||0,
    numberOfMissions:Number(source.numberOfMissions??missions.length??fallback.numberOfMissions??0)||missions.length,
    numberOfDisabledMissions:Number(source.numberOfDisabledMissions??fallback.numberOfDisabledMissions??0)||0,
    picture:String(source.picture??fallback.picture??''),
    author:String(source.author??source.authorName??source.creator?.name??source.agent?.name??fallback.author??''),
    startPoint:normalizeGeoPoint(source.startPoint??source.startPoi??source.startLocation??source.location??((source.startPointLatitude??source.startLatitude)!=null?{latitude:source.startPointLatitude??source.startLatitude,longitude:source.startPointLongitude??source.startLongitude}:null)??fallback.startPoint),
    searchDistanceMeters:Number.isFinite(Number(source.searchDistanceMeters??fallback.searchDistanceMeters))?Number(source.searchDistanceMeters??fallback.searchDistanceMeters):null,
    missions
  };
}
async function fetchBannerDetail(summary){
  if(summary?.missions?.length&&summary.missions.some(m=>m?.route?.length))return summary;
  const r=await fetch(`${BANNERGRESS_API}/bnrs/${encodeURIComponent(summary.id??summary.bannerId)}`,{headers:{Accept:'application/json'}});
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return normalizeBannerDetail(await r.json(),summary);
}
function ingressMissionUrl(id){
  const intel=`https://intel.ingress.com/mission/${id}`;
  const p=new URLSearchParams({link:intel,apn:'com.nianticproject.ingress',isi:'576505181',ibi:'com.google.ingress',ifl:'https://apps.apple.com/app/ingress/id576505181',ofl:intel});
  return `https://link.ingress.com/?${p.toString()}`;
}
async function openIngressMission(id){
  if(!id)return;
  const url=ingressMissionUrl(id);
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:url,packageName:'com.nianticproject.ingress'});
    else await AppLauncher.openUrl({url});
  }catch{
    try{await AppLauncher.openUrl({url})}catch(e){console.warn('Ingress deeplink',e)}
  }
}
function savePlaySession(session){localStorage.setItem(PLAY_SESSION_KEY,JSON.stringify(session));markBackupChanged()}
function loadPlaySession(){try{return JSON.parse(localStorage.getItem(PLAY_SESSION_KEY)||'null')}catch{return null}}
async function overlayState(){
  if(!Capacitor.isNativePlatform())return {active:false,currentIndex:loadPlaySession()?.currentIndex||0,total:loadPlaySession()?.missions?.length||0,doneJson:'[]'};
  try{return await MissionOverlay.getState()}catch(e){console.warn('overlay state',e);return {active:false}}
}
function bannerStartPoint(detail){
  for(const m of detail?.missions||[])if(m?.route?.length)return m.route[0];
  return normalizeGeoPoint(detail?.startPoint);
}
function bannerRoutePoints(detail){
  const out=[];(detail?.missions||[]).forEach((m,mi)=>(m.route||[]).forEach((p,pi)=>out.push({...p,missionIndex:mi,pointIndex:pi})));
  return out;
}
function rblGroupLink(detail,index=0){
  const id=String(detail?.id??detail?.bannerId??'');
  return `redactedbannerlab://play?banner=${encodeURIComponent(id)}&mission=${Math.max(0,Number(index)||0)}`;
}
function bannergressBannerUrl(detail){return `https://bannergress.com/banner/${encodeURIComponent(String(detail?.id??detail?.bannerId??''))}`}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);return true}catch{}
  try{
    const ta=document.createElement('textarea');ta.value=String(text);ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';ta.style.pointerEvents='none';document.body.appendChild(ta);ta.select();ta.setSelectionRange(0,ta.value.length);const ok=document.execCommand('copy');ta.remove();return !!ok;
  }catch{return false}
}
async function openGroupShareSheet(detail,index=0){
  const link=rblGroupLink(detail,index);
  let qr='';try{qr=await QRCode.toDataURL(link,{width:420,margin:1,color:{dark:'#06140b',light:'#ffffff'}})}catch(e){console.warn('QR',e)}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('shareGroup')}</h2><p>${tr('shareIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="groupShareCard">${qr?`<img class="groupQr" src="${qr}" alt="QR">`:''}<b>${escapeHtml(detail?.title||tr('unnamed'))}</b><span>${tr('missionStart',{n:Number(index)+1})}</span></div>
    <div class="shareLinkBox"><code>${escapeHtml(link)}</code></div>
    <div class="actions"><button class="secondary copygroup">${tr('copyLink')}</button><button class="primary sharegroup">${tr('shareNow')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('groupNoServer')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.copygroup',sh).onclick=async()=>{if(await copyText(link))toast(tr('linkCopied'))};
  $('.sharegroup',sh).onclick=async()=>{
    const text=`${detail?.title||'RBL'} · ${tr('missionStart',{n:Number(index)+1})}\n${link}`;
    try{await Share.share({title:detail?.title||'Redacted BannerLab',text,dialogTitle:tr('shareGroup')})}catch(e){console.warn('share group',e)}
  };
}
async function navigateToBannerStart(detail){
  const p=bannerStartPoint(detail);if(!p){toast(tr('startUnavailable'));return}
  const dest=`${p.latitude},${p.longitude}`;
  const web=`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=walking`;
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:web,packageName:'com.google.android.apps.maps'});
    else await AppLauncher.openUrl({url:web});
  }catch{try{await AppLauncher.openUrl({url:web})}catch(e){console.warn('maps',e)}}
}
function missionMapIcon(n,isStart=false){return L.divIcon({className:'rblLeafletIcon',html:`<span class="${isStart?'start':''}">${isStart?'▶':n}</span>`,iconSize:[30,30],iconAnchor:[15,15]})}
async function openBannerMap(detail){
  const points=bannerRoutePoints(detail);const start=bannerStartPoint(detail);
  if(!points.length&&!start){toast(tr('mapUnavailable'));return}
  const mapId=`rblMap_${Date.now().toString(36)}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('bannerMap')}</h2><p>${escapeHtml(detail.title||'')} · ${tr('routePoints',{n:points.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="bannerMapCanvas" id="${mapId}"></div>
    <div class="actions"><button class="primary navstart">📍 ${tr('navigateStart')}</button><button class="secondary sharemap">${tr('shareGroup')}</button></div>`);
  let map=null;
  const close=()=>{try{map?.remove()}catch{}closeSheet()};
  $('.close',sh).onclick=close;$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharemap',sh).onclick=()=>openGroupShareSheet(detail,0);
  await new Promise(r=>setTimeout(r,80));
  const el=document.getElementById(mapId);if(!el)return;
  map=L.map(el,{zoomControl:true,attributionControl:true});
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
  const bounds=[];
  (detail.missions||[]).forEach((m,mi)=>{
    const route=m.route||[];if(!route.length)return;
    const latlngs=route.map(p=>[p.latitude,p.longitude]);bounds.push(...latlngs);
    if(latlngs.length>1)L.polyline(latlngs,{color:'#31ed83',weight:4,opacity:.8}).addTo(map);
    L.marker(latlngs[0],{icon:missionMapIcon(mi+1,mi===0)}).addTo(map).bindPopup(`${mi===0?tr('startPoint')+' · ':''}${escapeHtml(m.title||tr('missionStart',{n:mi+1}))}`);
  });
  if(!bounds.length&&start)bounds.push([start.latitude,start.longitude]);
  if(bounds.length===1)map.setView(bounds[0],16);else map.fitBounds(bounds,{padding:[24,24]});
  setTimeout(()=>map.invalidateSize(),100);
}
async function joinSharedBanner(id,index=0){
  try{
    const detail=await fetchBannerDetail({id:String(id)});const i=clamp(Number(index)||0,0,Math.max(0,detail.missions.length-1));
    toast(tr('sharedBannerLoaded',{n:i+1}));openBannerDetail(detail,{startIndex:i,fromShare:true});
  }catch(e){toast(tr('sharedBannerError',{error:e?.message||e}))}
}
async function startPlaySession(detail,index=0){
  if(!detail?.missions?.length){toast(tr('bannerOffline'));return}
  const bannerId=String(detail.id??detail.bannerId??'');
  const previous=loadPlaySession();const same=String(previous?.bannerId||'')===bannerId;
  const session={format:'redacted-bannerlab-play-session',version:2,bannerId,title:detail.title,address:detail.formattedAddress??detail.address??'',picture:detail.picture||'',author:detail.author||'',lengthMeters:Number(detail.lengthMeters||0)||0,currentIndex:clamp(index,0,detail.missions.length-1),startedAt:same&&previous?.startedAt?previous.startedAt:Date.now(),missions:detail.missions};
  savePlaySession(session);upsertPlayHistory(session,{currentIndex:session.currentIndex,doneCount:same?Number(loadPlayHistory().find(x=>String(x.bannerId)===String(detail.id))?.doneCount||0):0,startedAt:session.startedAt});
  if(!Capacitor.isNativePlatform()){
    await openIngressMission(session.missions[session.currentIndex].id);return;
  }
  try{
    const p=await MissionOverlay.hasPermission();
    if(!p?.granted){
      localStorage.setItem(PLAY_PENDING_KEY,JSON.stringify(session));
      openOverlayPermissionSheet();return;
    }
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions[session.currentIndex].id),180);
  }catch(e){console.error(e);toast(tr('overlayFailed',{error:e?.message||e}))}
}
function openOverlayPermissionSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('overlayPermissionTitle')}</h2><p>${tr('overlayPermissionText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>Redacted Overlay</b><span>${tr('deepLinkOnly')}</span></div></div>
    <div class="actions"><button class="primary allowoverlay">${tr('overlayPermissionButton')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('overlayPermissionWaiting')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.allowoverlay',sh).onclick=async()=>{try{await MissionOverlay.requestPermission();toast(tr('overlayPermissionWaiting'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
}
async function resumePendingPlayOverlay(){
  if(!Capacitor.isNativePlatform())return;
  const raw=localStorage.getItem(PLAY_PENDING_KEY);if(!raw)return;
  try{
    const p=await MissionOverlay.hasPermission();if(!p?.granted)return;
    const session=JSON.parse(raw);
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    closeSheet();toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions?.[session.currentIndex||0]?.id),180);
  }catch(e){console.warn('pending overlay',e)}
}
async function stopPlayOverlay(){
  const session=loadPlaySession();let native={};try{native=await overlayState()}catch{}
  if(session){let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}upsertPlayHistory(session,{currentIndex:Number(native?.currentIndex??session.currentIndex??0),doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});}
  try{if(Capacitor.isNativePlatform())await MissionOverlay.stop()}catch(e){console.warn(e)}
  localStorage.removeItem(PLAY_SESSION_KEY);localStorage.removeItem(PLAY_PENDING_KEY);toast(tr('stopBanner'));
}
function bannerCardHtml(b){
  const img=bannergressImage(b.picture||'');
  const fav=isBannerFavorite(b.id);
  const id=escapeAttr(String(b.id));
  return `<div class="bannergressCardWrap">
    <button class="bannergressCard" data-banner-id="${id}">
      <span class="bannerPic">${img?`<img src="${escapeAttr(img)}" alt="">`:'<span>🐊</span>'}</span>
      <span class="bannerCardCopy"><b>${escapeHtml(b.title||tr('unnamed'))}</b><small>${escapeHtml(b.formattedAddress||tr('addressUnknown'))}</small>${b.author?`<small class="bannerAuthorLine">${escapeHtml(tr('bannerAuthor',{author:b.author}))}</small>`:''}<em>${tr('missionsCount',{n:b.numberOfMissions||0})} · ${formatBannerDistance(b.lengthMeters)}${Number.isFinite(Number(b.searchDistanceMeters))?` · 📍 ${formatBannerDistance(b.searchDistanceMeters)}`:''}</em></span>
      <span class="bannerFavState">${fav?'★':'›'}</span>
    </button>
    <button class="bannerStatsBtn" data-banner-stats-id="${id}">${tr('showUselessStats')}</button>
    <div class="bannerSearchStats" hidden></div>
  </div>`;
}
async function openBannerDetail(summary,opts={}){
  let detail=summary;
  try{detail=await fetchBannerDetail(summary)}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}));return}
  const fav=isBannerFavorite(detail.id),todo=isBannerTodo(detail.id),img=bannergressImage(detail.picture);
  const startIndex=clamp(Number(opts.startIndex)||0,0,Math.max(0,detail.missions.length-1));const hasMap=!!bannerStartPoint(detail);
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(detail.title)}</h2><p>${escapeHtml(detail.formattedAddress||tr('addressUnknown'))}${detail.author?` · ${escapeHtml(tr('bannerAuthor',{author:detail.author}))}`:''}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${opts.fromShare?`<div class="groupJoinNotice">🐊 <b>${tr('joinAtMission',{n:startIndex+1})}</b><span>${tr('groupNoServer')}</span></div>`:''}
    <div class="bannerDetailHero">${img?`<img src="${escapeAttr(img)}" alt="">`:''}<div><b>${tr('missionsCount',{n:detail.missions.length||detail.numberOfMissions})}</b><span>${formatBannerDistance(detail.lengthMeters)}</span>${detail.numberOfDisabledMissions?`<small>${tr('bannerDisabled',{n:detail.numberOfDisabledMissions})}</small>`:''}</div></div>
    <div class="bannerDetailStats">${bannerFunStatsHtml(detail,{loading:true})}</div>
    <div class="actions"><button class="primary playbanner" ${detail.missions.length?'':'disabled'}>▶ ${opts.fromShare?tr('joinAtMission',{n:startIndex+1}):tr('playThisBanner')}</button></div>
    <div class="bannerUtilityGrid"><button class="secondary mapbanner" ${hasMap?'':'disabled'}>🗺 ${tr('openMap')}</button><button class="secondary navstart" ${hasMap?'':'disabled'}>📍 ${tr('navigateStart')}</button><button class="secondary sharebanner">▦ ${tr('shareGroup')}</button></div>
    <div class="bannerUtilityGrid two"><button class="secondary favbanner">${fav?'★ '+tr('removeFavorite'):'☆ '+tr('favorite')}</button><button class="secondary todobanner">${todo?'✓ '+tr('removeTodo'):'+ '+tr('addTodo')}</button></div>
    <div class="missionPreviewList">${detail.missions.slice(0,18).map((m,i)=>`<div class="${i===startIndex?'current':''}"><b>${String(i+1).padStart(2,'0')}</b><span>${escapeHtml(m.title)}</span></div>`).join('')}${detail.missions.length>18?`<small>+ ${detail.missions.length-18}</small>`:''}</div>
    <div class="rule"><span class="dot"></span><span>${tr('publicOnly')} · ${tr('deepLinkOnly')}</span></div>`);
  $('.close',sh).onclick=()=>openPlayHub(opts.returnTab||'search');
  $('.playbanner',sh).onclick=()=>startPlaySession(detail,startIndex);
  $('.mapbanner',sh).onclick=()=>openBannerMap(detail);$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharebanner',sh).onclick=()=>openGroupShareSheet(detail,startIndex);
  $('.favbanner',sh).onclick=()=>{if(isBannerFavorite(detail.id))unfavoriteBanner(detail.id);else favoriteBanner(detail);closeSheet();openBannerDetail(detail,{...opts})};
  $('.todobanner',sh).onclick=()=>{if(isBannerTodo(detail.id))removeBannerTodo(detail.id);else addBannerTodo(detail);closeSheet();openBannerDetail(detail,{...opts})};
  renderBannerWalkingStats($('.bannerDetailStats',sh),detail);
}


const BANNER_SEARCH_PREFS_KEY='rbl-bannergress-search-v3';
const BANNER_SEARCH_OLD_PREFS_KEY='rbl-bannergress-search-v2';
function loadBannerSearchPrefs(){
  try{
    const current=JSON.parse(localStorage.getItem(BANNER_SEARCH_PREFS_KEY)||'null');
    if(current&&typeof current==='object')return current;
    const old=JSON.parse(localStorage.getItem(BANNER_SEARCH_OLD_PREFS_KEY)||'{}')||{};
    return {query:old.query||'',city:old.city||'',nearMe:!!old.nearMe,radiusKm:5};
  }catch{return{radiusKm:5}}
}
function saveBannerSearchPrefs(p){localStorage.setItem(BANNER_SEARCH_PREFS_KEY,JSON.stringify(p||{}));markBackupChanged()}
function normalizeTextMatch(v=''){
  return String(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim().replace(/[’'`´]/g,' ').replace(/[-_/.,;:()]+/g,' ').replace(/\s+/g,' ');
}
function canonicalCityKey(v=''){
  return normalizeTextMatch(v).replace(/\bste\b/g,'sainte').replace(/\bst\b/g,'saint').replace(/\s+/g,' ').trim();
}
function citySearchVariants(city=''){
  const raw=String(city||'').trim();if(!raw)return[];
  const expanded=raw.replace(/\bSte\.?(?=\s|-|$)/gi,'Sainte').replace(/\bSt\.?(?=\s|-|$)/gi,'Saint').replace(/[’'`´]/g,' ');
  const spaced=expanded.replace(/-/g,' ').replace(/\s+/g,' ').trim();
  const hyphen=spaced.split(' ').filter(Boolean).join('-');
  const abbreviated=spaced.replace(/^Sainte\b/i,'Ste').replace(/^Saint\b/i,'St');
  const variants=[raw,expanded,spaced,hyphen,abbreviated,abbreviated.replace(/\s+/g,'-')];
  return [...new Set(variants.map(x=>x.trim()).filter(Boolean))];
}
function placeMatchValues(p){return [p?.shortName,p?.name,p?.formattedAddress,p?.title,p?.displayName].filter(Boolean)}
function placeDisplayLabel(p,fallback=''){return String(p?.formattedAddress??p?.displayName??p?.name??p?.shortName??fallback)}
function placeCenter(p){
  if(!p)return null;
  for(const candidate of [p.center,p.location,p.point,p]){
    const direct=normalizeGeoPoint(candidate);if(direct)return direct;
  }
  const minLat=Number(p.boundaryMinLatitude??p.minLatitude??p.bounds?.minLatitude??p.bounds?.south);
  const maxLat=Number(p.boundaryMaxLatitude??p.maxLatitude??p.bounds?.maxLatitude??p.bounds?.north);
  const minLng=Number(p.boundaryMinLongitude??p.minLongitude??p.bounds?.minLongitude??p.bounds?.west);
  const maxLng=Number(p.boundaryMaxLongitude??p.maxLongitude??p.bounds?.maxLongitude??p.bounds?.east);
  if([minLat,maxLat,minLng,maxLng].every(Number.isFinite))return {latitude:(minLat+maxLat)/2,longitude:(minLng+maxLng)/2};
  const lat=Number(p.centerLatitude??p.latitude??p.lat),lng=Number(p.centerLongitude??p.longitude??p.lng??p.lon);
  return Number.isFinite(lat)&&Number.isFinite(lng)?{latitude:lat,longitude:lng}:null;
}
async function resolveBannergressPlace(city){
  const q=String(city||'').trim();if(!q)return null;
  const variants=citySearchVariants(q),found=new Map();
  for(const variant of variants){
    const u=`${BANNERGRESS_API}/places?used=true&collapsePlaces=true&query=${encodeURIComponent(variant)}&limit=40&offset=0`;
    const r=await fetch(u,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const raw=await r.json();
    const list=Array.isArray(raw)?raw:(Array.isArray(raw?.items)?raw.items:(Array.isArray(raw?.results)?raw.results:(Array.isArray(raw?.data)?raw.data:[])));
    for(const p of list){const key=String(p?.id??p?.placeId??placeMatchValues(p)[0]??Math.random());if(!found.has(key))found.set(key,p)}
    if(found.size&&variant!==q)break;
  }
  const list=[...found.values()];if(!list.length)return null;
  const target=canonicalCityKey(q);
  const score=p=>{
    const vals=placeMatchValues(p).map(canonicalCityKey);
    if(vals.some(x=>x===target))return 0;
    if(vals.some(x=>x.startsWith(target)||target.startsWith(x)))return 1;
    if(vals.some(x=>x.includes(target)||target.includes(x)))return 2;
    return 3;
  };
  return list.sort((a,b)=>score(a)-score(b))[0]||null;
}
function locationError(code,message=''){
  const e=new Error(message||String(code));e.locationCode=code;return e;
}
async function nativeLocationStatus(){
  if(!Capacitor.isNativePlatform())return null;
  try{return await LocationStatus.getStatus()}catch(e){console.warn('LocationStatus',e);return null}
}
async function openNativeLocationSettings(kind='location'){
  if(!Capacitor.isNativePlatform())return false;
  try{if(kind==='app')await LocationStatus.openAppSettings();else await LocationStatus.openLocationSettings();return true}catch(e){console.warn('location settings',e);return false}
}
async function getCurrentBannerPosition(){
  if(!navigator.geolocation)throw locationError('UNSUPPORTED','géolocalisation indisponible');
  const native=await nativeLocationStatus();
  if(native&&native.enabled===false)throw locationError('LOCATION_DISABLED',tr('locationDisabled'));
  if(navigator.permissions?.query){
    try{const perm=await navigator.permissions.query({name:'geolocation'});if(perm.state==='denied')throw locationError('PERMISSION_DENIED',tr('locationPermissionDenied'))}catch(e){if(e?.locationCode)throw e}
  }
  return new Promise((resolve,reject)=>{
    navigator.geolocation.getCurrentPosition(
      p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy}),
      e=>{
        if(e?.code===1)reject(locationError('PERMISSION_DENIED',tr('locationPermissionDenied')));
        else if(e?.code===2)reject(locationError('UNAVAILABLE',tr('locationUnavailable')));
        else if(e?.code===3)reject(locationError('TIMEOUT',tr('locationTimeout')));
        else reject(locationError('UNKNOWN',e?.message||`code ${e?.code||'?'}`));
      },
      {enableHighAccuracy:true,maximumAge:120000,timeout:8000}
    );
  });
}
function searchRadiusBounds(position,radiusKm){
  if(!position)return null;
  const km=Math.max(1,Number(radiusKm)||5),lat=Number(position.latitude),lng=Number(position.longitude);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  const latDelta=km/111.32,cos=Math.max(.08,Math.cos(lat*Math.PI/180)),lngDelta=km/(111.32*cos);
  return {minLatitude:lat-latDelta,maxLatitude:lat+latDelta,minLongitude:lng-lngDelta,maxLongitude:lng+lngDelta};
}
function buildBannergressSearchUrl({query='',position=null,radiusKm=5,placeId=''}){
  const u=new URL(`${BANNERGRESS_API}/bnrs`);
  u.searchParams.set('online','true');u.searchParams.set('limit','80');u.searchParams.set('offset','0');
  if(query.trim())u.searchParams.set('query',query.trim());
  if(placeId)u.searchParams.set('placeId',placeId);
  if(position){
    u.searchParams.set('orderBy','proximityStartPoint');u.searchParams.set('orderDirection','ASC');
    u.searchParams.set('proximityLatitude',String(position.latitude));u.searchParams.set('proximityLongitude',String(position.longitude));
    const bounds=searchRadiusBounds(position,radiusKm);
    if(bounds)for(const [key,value] of Object.entries(bounds))u.searchParams.set(key,String(value));
  }else if(query.trim()){
    u.searchParams.set('orderBy','relevance');u.searchParams.set('orderDirection','DESC');
  }else{
    u.searchParams.set('orderBy','created');u.searchParams.set('orderDirection','DESC');
  }
  return u.toString();
}
async function hydrateSearchStartPoints(list){
  const out=[...list],missing=[];
  out.forEach((b,i)=>{if(!bannerStartPoint(b))missing.push(i)});
  const concurrency=5;
  for(let start=0;start<missing.length;start+=concurrency){
    await Promise.all(missing.slice(start,start+concurrency).map(async i=>{
      try{const detail=await fetchBannerDetail(out[i]);out[i]={...out[i],startPoint:bannerStartPoint(detail)||detail.startPoint||null}}catch(e){console.warn('banner location',out[i]?.id,e)}
    }));
  }
  return out;
}
async function filterBannersByRadius(list,center,radiusKm){
  if(!center)return list;
  const hydrated=await hydrateSearchStartPoints(list),maxMeters=Math.max(1,Number(radiusKm)||5)*1000;
  return hydrated.map(b=>{
    const point=bannerStartPoint(b),distance=point?haversine(center,point):Infinity;
    return {...b,searchDistanceMeters:distance};
  }).filter(b=>Number.isFinite(b.searchDistanceMeters)&&b.searchDistanceMeters<=maxMeters+25).sort((a,b)=>a.searchDistanceMeters-b.searchDistanceMeters);
}
function locationErrorText(e){
  switch(e?.locationCode){
    case 'LOCATION_DISABLED':return tr('locationDisabled');
    case 'PERMISSION_DENIED':return tr('locationPermissionDenied');
    case 'UNAVAILABLE':return tr('locationUnavailable');
    case 'TIMEOUT':return tr('locationTimeout');
    default:return tr('locationError',{error:e?.message||e});
  }
}
function historyCardHtml(h){
  const total=Math.max(1,Number(h.total||h.numberOfMissions||1)),done=Math.min(total,Number(h.doneCount||0));const complete=done>=total;
  return `<button class="playHistoryCard" data-history-id="${escapeAttr(String(h.bannerId))}"><span class="historyState">${complete?'✓':'▶'}</span><span><b>${escapeHtml(h.title||tr('unnamed'))}</b><small>${formatPlayDate(h.startedAt)} · ${done}/${total}</small><em>${formatPlayDuration(activeDurationMs(h))} · ~${formatBannerDistance(estimatedPlayedMeters(h))}</em></span><strong>${complete?tr('completedBanner'):tr('resumeFromHistory')}</strong></button>`;
}
async function openHistoryBanner(h){
  try{const d=await fetchBannerDetail({id:h.bannerId,title:h.title,formattedAddress:h.formattedAddress,lengthMeters:h.lengthMeters,picture:h.picture,author:h.author,numberOfMissions:h.total});openBannerDetail(d,{startIndex:h.doneCount>=h.total?0:clamp(h.currentIndex,0,d.missions.length-1),returnTab:'history'})}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}))}
}
function playStatsHtml(entry){
  const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1)),done=Math.min(total,Number(entry?.doneCount||0));
  return `<div class="playStats"><b>${tr('playStats')}</b><div><span>${tr('startedAt')}</span><strong>${formatPlayDate(entry?.startedAt)}</strong></div><div><span>${tr('elapsed')}</span><strong>${formatPlayDuration(activeDurationMs(entry))}</strong></div><div><span>${tr('estimatedDistance')}</span><strong>~${formatBannerDistance(estimatedPlayedMeters(entry))}</strong></div><div><span>${tr('missionsDone')}</span><strong>${done}/${total}</strong></div>${entry?.finishedAt?`<div><span>${tr('finishedAt')}</span><strong>${formatPlayDate(entry.finishedAt)}</strong></div>`:''}</div>`;
}
async function renderPlayTab(sh,tab){
  const body=$('.playHubBody',sh);if(!body)return;
  if(tab==='todo'){
    const list=loadBannerTodo();body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">＋<b>${tr('noTodo')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b,{returnTab:'todo'}));return;
  }
  if(tab==='history'){
    const list=loadPlayHistory();body.innerHTML=list.length?`<div class="playHistoryList">${list.map(historyCardHtml).join('')}</div>`:`<div class="emptyPlayState">◷<b>${tr('noHistory')}</b></div>`;
    $$('.playHistoryCard',body).forEach(btn=>{btn.onclick=()=>{const h=list.find(x=>String(x.bannerId)===btn.dataset.historyId);if(h)openHistoryBanner(h)}});return;
  }
  if(tab==='favorites'){
    const list=loadBannerFavorites();
    body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">☆<b>${tr('noFavorites')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b));return;
  }
  if(tab==='current'){
    const session=loadPlaySession();const native=await overlayState();
    if(!session){body.innerHTML=`<div class="emptyPlayState">🐊<b>${tr('noPlaySession')}</b></div>`;return}
    let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}
    const index=clamp(Number(native?.currentIndex??session.currentIndex??0),0,Math.max(0,session.missions.length-1));
    const hist=upsertPlayHistory(session,{currentIndex:index,doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});
    body.innerHTML=`<div class="currentPlayCard"><div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>${escapeHtml(session.title)}</b><span>${tr('doneMissions',{done:done.length,total:session.missions.length})}</span></div></div>
      <div class="currentMissionLine"><strong>${index+1}/${session.missions.length}</strong><span>${escapeHtml(session.missions[index]?.title||'Mission')}</span></div>
      ${playStatsHtml(hist)}
      <div class="actions"><button class="primary resumeplay">▶ ${tr('resumeBanner')}</button><button class="secondary opencurrent">${tr('openCurrentMission')}</button></div>
      <div class="bannerUtilityGrid"><button class="secondary currentmap">🗺 ${tr('openMap')}</button><button class="secondary currentnav">📍 ${tr('navigateStart')}</button><button class="secondary currentshare">▦ ${tr('shareProgress')}</button></div>
      <button class="danger stopplay">${tr('stopBanner')}</button></div>`;
    $('.resumeplay',body).onclick=()=>startPlaySession(session,index);
    $('.opencurrent',body).onclick=()=>openIngressMission(session.missions[index]?.id);
    $('.currentmap',body).onclick=()=>openBannerMap({...session,id:session.bannerId,formattedAddress:session.address});
    $('.currentnav',body).onclick=()=>navigateToBannerStart({...session,id:session.bannerId});
    $('.currentshare',body).onclick=()=>openGroupShareSheet({...session,id:session.bannerId},index);
    $('.stopplay',body).onclick=async()=>{await stopPlayOverlay();openPlayHub('current')};return;
  }

  const prefs=loadBannerSearchPrefs();
  let nearMe=!!prefs.nearMe;
  let position=null;
  const initialRadius=clamp(Number(prefs.radiusKm)||5,1,50);
  body.innerHTML=`<div class="bannerSearchBox bannerSearchAdvanced">
      <div class="bannerSearchHeading"><div><b>${tr('searchBannergress')}</b><span>${tr('searchPrompt')}</span></div><span>BG</span></div>
      <div class="field bannerSearchField"><label>${tr('bannerNameSearch')}</label><input class="bannerNameInput" placeholder="${escapeAttr(tr('searchPlaceholder'))}" value="${escapeAttr(prefs.query||'')}"></div>
      <div class="field bannerSearchField"><label>${tr('citySearch')}</label><input class="bannerCityInput" placeholder="${escapeAttr(tr('cityPlaceholder'))}" value="${escapeAttr(prefs.city||'')}" ${nearMe?'disabled':''}></div>
      <button class="nearMeButton ${nearMe?'on':''}" type="button">📍 <span>${nearMe?tr('nearMeOn'):tr('nearMe')}</span></button>
      <small class="nearMeHelp">${tr('nearMeHint')}</small>
      <div class="bannerRadiusBox">
        <div class="bannerRadiusHead"><label>${tr('searchRadius')}</label><strong class="bannerRadiusValue">${initialRadius} km</strong></div>
        <input class="bannerRadiusRange" type="range" min="1" max="50" step="1" value="${initialRadius}">
        <small>${tr('radiusHint')}</small>
      </div>
      <button class="secondary bannerLocationSettings" type="button" hidden>⚙ ${tr('openLocationSettings')}</button>
      <div class="bannerSearchActions"><button class="secondary bannerSearchReset">${tr('searchReset')}</button><button class="primary bannerSearchBtn">${icon('search')} ${tr('search')}</button></div>
      <div class="bannerSearchStatus"></div>
    </div><div class="bannerSearchResults"></div>`;

  const qInput=$('.bannerNameInput',body),cityInput=$('.bannerCityInput',body),radiusInput=$('.bannerRadiusRange',body),radiusValue=$('.bannerRadiusValue',body);
  const nearBtn=$('.nearMeButton',body),status=$('.bannerSearchStatus',body),results=$('.bannerSearchResults',body),settingsBtn=$('.bannerLocationSettings',body);
  let locationSettingsKind='location';
  const setStatus=(txt,cls='')=>{status.textContent=txt||'';status.className='bannerSearchStatus '+cls};
  const radiusKm=()=>clamp(Number(radiusInput.value)||5,1,50);
  const savePrefs=()=>saveBannerSearchPrefs({query:qInput.value,city:cityInput.value,nearMe,radiusKm:radiusKm()});
  const updateRadius=()=>{radiusValue.textContent=`${radiusKm()} km`;const active=nearMe||!!cityInput.value.trim();radiusInput.disabled=!active;$('.bannerRadiusBox',body)?.classList.toggle('disabled',!active);savePrefs()};
  const hideLocationAction=()=>{settingsBtn.hidden=true};
  const showLocationError=e=>{
    setStatus(locationErrorText(e),'error');
    if(Capacitor.isNativePlatform()&&['LOCATION_DISABLED','UNAVAILABLE','TIMEOUT','PERMISSION_DENIED'].includes(e?.locationCode)){
      locationSettingsKind=e?.locationCode==='PERMISSION_DENIED'?'app':'location';
      settingsBtn.textContent=`⚙ ${tr(locationSettingsKind==='app'?'openAppSettings':'openLocationSettings')}`;settingsBtn.hidden=false;
    }
  };
  settingsBtn.onclick=()=>openNativeLocationSettings(locationSettingsKind);

  const acquirePosition=async()=>{
    hideLocationAction();setStatus(tr('locationChecking'),'loading');
    const pos=await getCurrentBannerPosition();position=pos;setStatus(`${tr('locationReady')}${Number.isFinite(pos.accuracy)?` · ±${Math.round(pos.accuracy)} m`:''}`,'ok');return pos;
  };
  const toggleNear=async()=>{
    nearMe=!nearMe;position=null;cityInput.disabled=nearMe;nearBtn.classList.toggle('on',nearMe);
    $('span',nearBtn).textContent=nearMe?tr('nearMeOn'):tr('nearMe');hideLocationAction();updateRadius();savePrefs();
    if(nearMe){try{await acquirePosition()}catch(e){showLocationError(e)}}else setStatus('');
  };
  nearBtn.onclick=toggleNear;
  radiusInput.oninput=updateRadius;
  cityInput.addEventListener('input',updateRadius);
  updateRadius();

  const run=async()=>{
    const query=qInput.value.trim(),city=cityInput.value.trim();savePrefs();hideLocationAction();
    if(!query&&!city&&!nearMe){setStatus(tr('searchCriteriaRequired'),'error');results.innerHTML='';return}
    results.innerHTML=`<div class="loadingPlay">${tr('searching')}</div>`;setStatus('');
    try{
      let place=null,searchCenter=null;
      if(nearMe){if(!position)await acquirePosition();searchCenter=position}
      if(city&&!nearMe){
        setStatus(tr('cityResolving'),'loading');place=await resolveBannergressPlace(city);
        if(!place){results.innerHTML='';setStatus(tr('cityNotFound',{city}),'error');return}
        searchCenter=placeCenter(place);
        if(!searchCenter){results.innerHTML='';setStatus(tr('cityNoCoordinates',{city:placeDisplayLabel(place,city)}),'error');return}
        setStatus(tr('cityUsingRadius',{city:placeDisplayLabel(place,city),radius:radiusKm()}),'ok');
      }
      const url=buildBannergressSearchUrl({query,position:searchCenter,radiusKm:radiusKm()});
      const r=await fetch(url,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
      let list=unwrapBannerSearch(await r.json()).map(b=>normalizeBannerDetail(b,b));
      if(searchCenter)list=await filterBannersByRadius(list,searchCenter,radiusKm());
      const filterBits=[];if(query)filterBits.push(`“${query}”`);if(city&&!nearMe)filterBits.push(placeDisplayLabel(place,city));if(nearMe)filterBits.push('📍');if(searchCenter)filterBits.push(`≤ ${radiusKm()} km`);
      const countText=searchCenter?tr('radiusResults',{n:list.length,radius:radiusKm()}):tr('resultsCount',{n:list.length});
      setStatus(`${countText}${filterBits.length?' · '+filterBits.join(' · '):''}`,list.length?'ok':'');
      results.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">⌕<b>0</b></div>`;
      bindBannerList(results,list,b=>openBannerDetail(b));
    }catch(e){console.error(e);if(e?.locationCode)showLocationError(e);else setStatus(tr('searchError',{error:e?.message||e}),'error');results.innerHTML=''}
  };
  $('.bannerSearchBtn',body).onclick=run;
  $('.bannerSearchReset',body).onclick=()=>{qInput.value='';cityInput.value='';radiusInput.value='5';nearMe=false;position=null;cityInput.disabled=false;nearBtn.classList.remove('on');$('span',nearBtn).textContent=tr('nearMe');hideLocationAction();updateRadius();savePrefs();setStatus('');results.innerHTML=''};
  [qInput,cityInput].forEach(inp=>inp.addEventListener('keydown',e=>{if(e.key==='Enter')run()}));
  setTimeout(()=>qInput.focus(),80);
}
function openPlayHub(tab='search'){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('playHub')}</h2><p>${tr('publicOnly')} · ${tr('deepLinkOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playTabs"><button data-playtab="search" class="${tab==='search'?'on':''}">${icon('search')} ${tr('search')}</button><button data-playtab="todo" class="${tab==='todo'?'on':''}">＋ ${tr('todo')}</button><button data-playtab="favorites" class="${tab==='favorites'?'on':''}">${icon('star')} ${tr('favorites')}</button><button data-playtab="current" class="${tab==='current'?'on':''}">🐊 ${tr('inProgress')}</button><button data-playtab="history" class="${tab==='history'?'on':''}">◷ ${tr('history')}</button></div>
    <div class="playHubBody"></div>`);
  $('.close',sh).onclick=closeSheet;
  $$('[data-playtab]',sh).forEach(btn=>btn.onclick=()=>openPlayHub(btn.dataset.playtab));
  renderPlayTab(sh,tab);
}



let studioEditorRoot=null,studioCanvasHome=null,studioZoom=1,studioOrientationLocked=false,studioPanMode=false,studioFitMode='six',studioViewScale=1;
function studioActiveLayer(){return activeImageLayer()}
function studioActiveText(){return state.active.startsWith('text:')?state.texts.find(t=>t.id===state.active.slice(5))||null:null}
function studioLayerClass(l){const g=groupInfoForLayer(l);return g?` groupColor${g.color}`:''}
function studioLayerRowsHtml(){
  normalizeLayerGroups();
  const rows=[...state.imageLayers].map((l,i)=>({l,i})).reverse().map(({l,i})=>{
    const active=state.active==='image:'+l.id,g=groupInfoForLayer(l),top=i===state.imageLayers.length-1,bottom=i===0;
    return `<div class="studioLayerRow${active?' active':''}${l.visible===false?' hidden':''}${studioLayerClass(l)}" data-studio-layer="${escapeAttr(l.id)}">
      <label class="studioGroupCheck" title="${tr('studioGroupSelect')}"><input type="checkbox" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="studioLayerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:g?'▱':'▧',alt:imageLayerLabel(l,i),studio:true})}<span><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:`${l.image?.naturalWidth||0} × ${l.image?.naturalHeight||0}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}`}</small></span></button>
      <button class="studioEye" type="button">${l.visible===false?'◌':'◉'}</button>
      <div class="studioLayerOrder"><button type="button" class="studioDown" ${bottom?'disabled':''}>↓</button><button type="button" class="studioUp" ${top?'disabled':''}>↑</button></div>
    </div>`;
  }).join('');
  return `${rows}<div class="studioLayerRow background${state.active==='background'?' active':''}${state.bg.visible===false?' hidden':''}"><span class="studioGroupLock">⌄</span><button class="studioLayerSelect studioBackground" type="button">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer'),studio:true})}<span><b>${tr('backgroundLayer')}</b><small>${state.bg.image?`${state.bg.image.naturalWidth} × ${state.bg.image.naturalHeight}`:tr('backgroundMissing')}</small></span></button><button class="studioEye studioBackgroundEye" type="button">${state.bg.visible===false?'◌':'◉'}</button><span class="studioLock">🔒</span></div>`;
}
function studioTextRowsHtml(){
  if(!state.texts.length)return `<div class="studioNoLayer">${tr('studioNoText')}</div>`;
  return state.texts.map((t,i)=>`<div class="studioTextRow${state.active==='text:'+t.id?' active':''}" data-studio-text="${escapeAttr(t.id)}"><button class="studioTextSelect" type="button"><span class="studioLayerGlyph">T</span><span><b>${escapeHtml((t.text||tr('text')).slice(0,42))}</b><small>${tr('size')} ${Math.round(t.fontSize||180)} · ${tr('rotation')} ${Math.round((t.rotation||0)*180/Math.PI)}°</small></span></button><button class="studioTextDelete" type="button">${icon('trash')}</button></div>`).join('');
}
function studioAddTextNow(){
  const before=beginHistory();const t=textDefaults({id:uid(),text:'I LOVE REDACTED',x:WORLD_W/2,y:worldH()/2,fontSize:180,color:'#ffffff',strokeColor:'#07100c',strokeWidth:14,scale:1,rotation:0});state.texts.push(t);setActive('text:'+t.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();
}
function studioDuplicateText(id){const src=state.texts.find(t=>t.id===id);if(!src)return;const before=beginHistory(),copy={...src,id:uid(),x:(src.x||0)+24,y:(src.y||0)+24,text:src.text||tr('text')};state.texts.push(copy);setActive('text:'+copy.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();}
function studioDeleteText(id){const t=state.texts.find(x=>x.id===id);if(!t)return;const before=beginHistory();state.texts=state.texts.filter(x=>x.id!==id);state.active='background';commitHistory(before,tr('histDeleteText'));scheduleSave();render();refreshStudioEditor();toast(tr('textDeleted'));}
function studioToolsHtml(){
  const txt=studioActiveText();
  if(txt){
    normalizeTextStyle(txt);return `<div class="studioSelectedCard"><b>${escapeHtml((txt.text||tr('text')).slice(0,48))}</b><small>${tr('studioSelected')} · ${tr('text')}</small></div>
      <div class="studioTextQuick">
        <label><span>${tr('text')}</span><input class="studioTextValue" maxlength="120" value="${escapeAttr(txt.text||'')}"></label>
        <div class="studioTypographyTitle">${tr('textTypography')}</div>
        <div class="studioFontLine"><label><span>${tr('font')}</span><select class="studioTextFont">${fontOptionsHtml(txt.fontFamily)}</select></label><button class="secondary studioImportFont" type="button">＋ ${tr('importFont')}</button></div>
        <div class="grid2"><label><span>${tr('size')}</span><input class="studioTextSize" type="number" min="40" max="700" value="${txt.fontSize||180}"></label><label><span>${tr('fontWeight')}</span><select class="studioTextWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${txt.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></label></div>
        <div class="grid2"><label><span>${tr('letterSpacing')}</span><input class="studioTextSpacing" type="number" min="-40" max="160" step="1" value="${txt.letterSpacing||0}"></label><label><span>${tr('lineHeight')}</span><input class="studioTextLineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${txt.lineHeight||1.08}"></label></div>
        <div class="grid2"><label><span>${tr('textAlign')}</span><select class="studioTextAlign"><option value="left" ${txt.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${txt.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${txt.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></label><label class="studioCheckLabel"><span>${tr('fontItalic')}</span><input class="studioTextItalic" type="checkbox" ${txt.fontItalic?'checked':''}></label></div>
        <div class="grid2"><label><span>${tr('outline')}</span><input class="studioTextStroke" type="number" min="0" max="60" value="${txt.strokeWidth??14}"></label><label><span>${tr('color')}</span><input class="studioTextColor" type="color" value="${txt.color||'#ffffff'}"></label></div>
        <label><span>${tr('outlineColor')}</span><input class="studioTextStrokeColor" type="color" value="${txt.strokeColor||'#07100c'}"></label>
        <label class="studioSwitch"><input class="studioTextBgEnabled" type="checkbox" ${txt.backgroundEnabled?'checked':''}><span>${tr('textBackground')}</span></label>
        <div class="studioTextBgFields" ${txt.backgroundEnabled?'':'hidden'}><div class="grid2"><label><span>${tr('textBackgroundColor')}</span><input class="studioTextBgColor" type="color" value="${txt.backgroundColor||'#07100c'}"></label><label><span>${tr('textBackgroundOpacity')}</span><input class="studioTextBgOpacity" type="number" min="0" max="100" value="${Math.round((txt.backgroundOpacity??.72)*100)}"></label></div><div class="grid2"><label><span>${tr('textBackgroundPadding')}</span><input class="studioTextBgPadding" type="number" min="0" max="180" value="${txt.backgroundPadding??24}"></label><label><span>${tr('textBackgroundRadius')}</span><input class="studioTextBgRadius" type="number" min="0" max="240" value="${txt.backgroundRadius??24}"></label></div></div>
      </div>
      <div class="studioToolGrid"><button type="button" class="studioTransform">${icon('move')}<span>${tr('transformText')}</span></button><button type="button" class="studioDuplicateText">${icon('copy')}<span>${tr('studioDuplicateText')}</span></button><button type="button" class="studioDeleteText danger">${icon('trash')}<span>${tr('delete')}</span></button></div>`;
  }
  const l=studioActiveLayer();
  if(!l)return `<div class="studioNoLayer">${tr('studioNoLayer')}</div>`;
  const isBg=l===state.bg,idx=isBg?-1:imageLayerIndex(l.id),g=!isBg?groupInfoForLayer(l):null;
  return `<div class="studioSelectedCard${g?` groupColor${g.color}`:''}"><b>${escapeHtml(isBg?tr('backgroundLayer'):imageLayerLabel(l,idx))}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:tr('studioSelected')}</small></div>
    <label class="studioOpacity"><span>${tr('studioOpacity')}</span><strong>${Math.round((l.opacity??1)*100)}%</strong><input type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></label>
    <div class="studioToolGrid">
      <button type="button" class="studioTransform">${icon('move')}<span>${g?tr('groupTransform'):tr('layerTransform')}</span></button>
      <button type="button" class="studioVisibility">${l.visible===false?'◌':'◉'}<span>${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}</span></button>
      ${isBg?'':`<button type="button" class="studioMoveDown" ${idx===0?'disabled':''}>↓<span>${tr('moveDown')}</span></button><button type="button" class="studioMoveUp" ${idx===state.imageLayers.length-1?'disabled':''}>↑<span>${tr('moveUp')}</span></button><button type="button" class="studioDuplicate">${icon('copy')}<span>${tr('duplicateLayer')}</span></button><button type="button" class="studioRename">${icon('edit')}<span>${tr('renameLayer')}</span></button>${g?`<button type="button" class="studioUngroup">⇱<span>${tr('ungroup')}</span></button>`:''}<button type="button" class="studioDelete danger">${icon('trash')}<span>${tr('deleteLayer')}</span></button>`}
    </div>`;
}
function studioMoveLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;const before=beginHistory();[state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];commitHistory(before,tr('histReorderLayer'));scheduleSave();render();refreshStudioEditor();
}
function studioToggleLayer(id){
  if(id==='background'){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  else{const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  scheduleSave();render();refreshStudioEditor();
}
function studioDeleteLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDeleted'));
}
function studioDuplicateLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDuplicated'));
}
function studioUngroupLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupRemoved'));
}
function studioGroupSelected(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));if(ids.length<2){toast(tr('groupNeedTwo'));return}const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupCreated'));
}
function studioSelectedMissionRc(){return parseMissionKey(state.selectedMissionKey)||rowColForMission(1)}
function studioMissionVisualPosition(rc,scale=studioViewScale){return {left:(worldH()-(rc.row+1)*STEP)*scale,top:rc.col*STEP*scale,size:STEP*scale}}
function studioScrollToSelectedMission(behavior='smooth'){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),rc=studioSelectedMissionRc();if(!sc||!rc)return;const p=studioMissionVisualPosition(rc);sc.scrollTo({left:Math.max(0,p.left-(sc.clientWidth-p.size)/2),top:Math.max(0,p.top-(sc.clientHeight-p.size)/2),behavior});
}
function applyStudioCanvasSize({recenter=false}={}){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),stage=$('.studioCanvasStage',studioEditorRoot);if(!sc||!stage)return;
  const availH=Math.max(220,sc.clientHeight-20),availW=Math.max(220,sc.clientWidth-20);let fit;
  if(studioFitMode==='one')fit=Math.min(availH,availW)/STEP;
  else if(studioFitMode==='all')fit=Math.min(availH/WORLD_W,availW/worldH());
  else fit=availH/WORLD_W;
  studioViewScale=Math.max(.04,fit*studioZoom);
  const cssW=WORLD_W*studioViewScale,cssH=worldH()*studioViewScale,mount=$('.studioCanvasMount',studioEditorRoot);
  stage.style.width=`${Math.round(cssH)}px`;stage.style.height=`${Math.round(cssW)}px`;
  if(mount){mount.style.width=`${Math.max(Math.round(cssH),Math.max(1,sc.clientWidth-20))}px`;mount.style.height=`${Math.max(Math.round(cssW),Math.max(1,sc.clientHeight-20))}px`;}
  canvas.style.width=`${Math.round(cssW)}px`;canvas.style.height=`${Math.round(cssH)}px`;canvas.style.position='absolute';canvas.style.left=`${Math.round(cssH)}px`;canvas.style.top='0';canvas.style.transformOrigin='0 0';canvas.style.transform='rotate(90deg)';
  if(recenter){requestAnimationFrame(()=>{if(studioFitMode==='one')studioScrollToSelectedMission('smooth');else {const scroll=$('.studioScroll',studioEditorRoot),mx=Math.max(0,((mount?.scrollWidth||0)-scroll.clientWidth)/2),my=Math.max(0,((mount?.scrollHeight||0)-scroll.clientHeight)/2);scroll?.scrollTo({left:mx,top:my,behavior:'smooth'})}})}
}
function bindStudioPanels(){
  if(!studioEditorRoot)return;const root=studioEditorRoot;
  $$('.studioLayerRow[data-studio-layer]',root).forEach(row=>{const id=row.dataset.studioLayer;$('.studioLayerSelect',row).onclick=()=>{setEditMode('fresco');setActive('image:'+id);refreshStudioEditor()};$('.studioEye',row).onclick=()=>studioToggleLayer(id);$('.studioDown',row).onclick=()=>studioMoveLayer(id,-1);$('.studioUp',row).onclick=()=>studioMoveLayer(id,1);$('input',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);refreshStudioEditor()};});
  const bg=$('.studioBackground',root),bgEye=$('.studioBackgroundEye',root);if(bg)bg.onclick=()=>{setActive('background');refreshStudioEditor()};if(bgEye)bgEye.onclick=()=>studioToggleLayer('background');
  $$('.studioTextRow[data-studio-text]',root).forEach(row=>{const id=row.dataset.studioText;$('.studioTextSelect',row).onclick=()=>{setEditMode('fresco');setActive('text:'+id);refreshStudioEditor()};$('.studioTextDelete',row).onclick=()=>studioDeleteText(id)});
  const addText=$('.studioAddText',root);if(addText)addText.onclick=studioAddTextNow;
  const groupBtn=$('.studioGroupNow',root);if(groupBtn)groupBtn.onclick=studioGroupSelected;const clear=$('.studioClearGroup',root);if(clear)clear.onclick=()=>{layerGroupSelection.clear();refreshStudioEditor()};
  const openFull=$('.studioOpenManager',root);if(openFull)openFull.onclick=()=>{closeStudioEditor();openImageLayersSheet()};
  const txt=studioActiveText();if(txt){
    normalizeTextStyle(txt);const value=$('.studioTextValue',root),size=$('.studioTextSize',root),stroke=$('.studioTextStroke',root),color=$('.studioTextColor',root),strokeColor=$('.studioTextStrokeColor',root),font=$('.studioTextFont',root),weight=$('.studioTextWeight',root),italic=$('.studioTextItalic',root),spacing=$('.studioTextSpacing',root),lineHeight=$('.studioTextLineHeight',root),align=$('.studioTextAlign',root),bgEnabled=$('.studioTextBgEnabled',root),bgColor=$('.studioTextBgColor',root),bgOpacity=$('.studioTextBgOpacity',root),bgPadding=$('.studioTextBgPadding',root),bgRadius=$('.studioTextBgRadius',root);
    const update=()=>{txt.text=value?.value||tr('text');txt.fontSize=clamp(+size?.value||180,40,700);txt.strokeWidth=clamp(+stroke?.value||0,0,60);if(color)txt.color=color.value;if(strokeColor)txt.strokeColor=strokeColor.value;if(font)txt.fontFamily=font.value;if(weight)txt.fontWeight=clamp(+weight.value||800,100,900);if(italic)txt.fontItalic=italic.checked;if(spacing)txt.letterSpacing=clamp(+spacing.value||0,-40,160);if(lineHeight)txt.lineHeight=clamp(+lineHeight.value||1.08,.7,2.4);if(align)txt.textAlign=align.value;if(bgEnabled)txt.backgroundEnabled=bgEnabled.checked;if(bgColor)txt.backgroundColor=bgColor.value;if(bgOpacity)txt.backgroundOpacity=clamp((+bgOpacity.value||0)/100,0,1);if(bgPadding)txt.backgroundPadding=clamp(+bgPadding.value||0,0,180);if(bgRadius)txt.backgroundRadius=clamp(+bgRadius.value||0,0,240);normalizeTextStyle(txt);const fields=$('.studioTextBgFields',root);if(fields)fields.hidden=!txt.backgroundEnabled;render();scheduleSave()};
    [value,size,stroke,color,strokeColor,font,weight,italic,spacing,lineHeight,align,bgEnabled,bgColor,bgOpacity,bgPadding,bgRadius].filter(Boolean).forEach(el=>el.addEventListener(el.type==='checkbox'||el.tagName==='SELECT'?'change':'input',update));
    const imp=$('.studioImportFont',root);if(imp)imp.onclick=()=>importProjectFont(txt,()=>refreshStudioEditor());
    const transform=$('.studioTransform',root),dup=$('.studioDuplicateText',root),del=$('.studioDeleteText',root);if(transform)transform.onclick=()=>openTransformSheet();if(dup)dup.onclick=()=>studioDuplicateText(txt.id);if(del)del.onclick=()=>studioDeleteText(txt.id);return;
  }
  const l=studioActiveLayer();if(!l)return;const isBg=l===state.bg,id=isBg?'background':l.id;const rng=$('.studioOpacity input',root);if(rng){rng.oninput=e=>{l.opacity=+e.target.value/100;$('.studioOpacity strong',root).textContent=`${e.target.value}%`;render();scheduleSave()};}
  const transform=$('.studioTransform',root);if(transform)transform.onclick=()=>openTransformSheet();const vis=$('.studioVisibility',root);if(vis)vis.onclick=()=>studioToggleLayer(id);
  if(!isBg){const down=$('.studioMoveDown',root),up=$('.studioMoveUp',root),dup=$('.studioDuplicate',root),ren=$('.studioRename',root),del=$('.studioDelete',root),ung=$('.studioUngroup',root);if(down)down.onclick=()=>studioMoveLayer(id,-1);if(up)up.onclick=()=>studioMoveLayer(id,1);if(dup)dup.onclick=()=>studioDuplicateLayer(id);if(del)del.onclick=()=>studioDeleteLayer(id);if(ung)ung.onclick=()=>studioUngroupLayer(id);if(ren)ren.onclick=()=>{closeStudioEditor({keepOrientation:true});renameImageLayer(id)};}
}
function refreshStudioEditor(){
  if(!studioEditorRoot)return;normalizeLayerGroups();const left=$('.studioLayerList',studioEditorRoot),texts=$('.studioTextList',studioEditorRoot),right=$('.studioToolsBody',studioEditorRoot);if(left)left.innerHTML=studioLayerRowsHtml();if(texts)texts.innerHTML=studioTextRowsHtml();if(right)right.innerHTML=studioToolsHtml();const cnt=$('.studioGroupCount',studioEditorRoot);if(cnt)cnt.textContent=String(layerGroupSelection.size);const gb=$('.studioGroupNow',studioEditorRoot);if(gb)gb.disabled=layerGroupSelection.size<2;bindStudioPanels();refreshStudioMissionControls();applyStudioCanvasSize();
}
function refreshStudioMissionControls(){
  if(!studioEditorRoot)return;const mission=$('.studioMissionMode',studioEditorRoot),fresco=$('.studioFrescoMode',studioEditorRoot),rc=parseMissionKey(state.selectedMissionKey);
  mission?.classList.toggle('on',state.editMode==='mission');fresco?.classList.toggle('on',state.editMode==='fresco');
  if(mission){const label=$('.studioMissionLabel',mission);if(label)label.textContent=state.editMode==='mission'&&rc?`M${missionNumber(rc.row,rc.col)}`:tr('studioMissionMode');mission.title=state.editMode==='mission'&&rc?tr('missionSelected',{n:missionNumber(rc.row,rc.col)}):tr('tapMedallion');}
}
async function requestStudioFullscreen(){if(!studioEditorRoot)return;try{if(document.documentElement.requestFullscreen&&!document.fullscreenElement)await document.documentElement.requestFullscreen()}catch{}setTimeout(()=>applyStudioCanvasSize(),160)}
function studioToggleDrawer(selector){if(!studioEditorRoot)return;const target=$(selector,studioEditorRoot);$$('.studioDrawer',studioEditorRoot).forEach(d=>{if(d!==target)d.classList.remove('open')});target?.classList.toggle('open')}
function openStudioEditor(){
  if(!requireFrescoFlow())return;setEditMode('fresco');if(studioEditorRoot)return;closeSheet();studioZoom=1;studioFitMode='six';studioPanMode=false;
  studioCanvasHome={parent:canvas.parentNode,next:canvas.nextSibling};const root=document.createElement('div');root.className='studioEditorBack';root.innerHTML=`<div class="studioTop"><button class="studioClose" type="button">${icon('close')}</button><div class="studioTitle"><b>${tr('studioTitle')}</b><small>${state.rows*6} ${tr('missions').toLowerCase()} · ${tr('studioRotateHint')}</small></div><div class="studioZoom"><button type="button" class="studioMissionMode" title="${tr('tapMedallion')}">🎯 <span class="studioMissionLabel">${tr('studioMissionMode')}</span></button><button type="button" class="studioFrescoMode on" title="${tr('studioFrescoMode')}">◎ <span>${tr('studioFrescoMode')}</span></button><button type="button" class="studioZoomOut" title="−">−</button><button type="button" class="studioZoomIn" title="＋">＋</button><button type="button" class="studioPan" title="${tr('studioPan')}">✋</button><button type="button" class="studioFullscreen" title="${tr('studioFullscreen')}" aria-label="${tr('studioFullscreen')}">⛶</button></div></div><div class="studioBody"><div class="studioScroll"><div class="studioCanvasMount"><div class="studioCanvasStage"></div></div></div><button class="studioEdge studioEdgeLeft" type="button">${icon('layers')}<span>${tr('studioLayers')}</span></button><button class="studioEdge studioEdgeText" type="button">${icon('text')}<span>${tr('studioTexts')}</span></button><button class="studioEdge studioEdgeRight" type="button">${icon('move')}<span>${tr('studioTools')}</span></button><aside class="studioDrawer studioDrawerLeft"><div class="studioDrawerHead"><b>${tr('studioLayers')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioLayerActions"><button class="studioAddLayer primary" type="button">＋ ${tr('addLayer')}</button><button class="studioAddMissionLayer secondary" type="button">🎯 ${tr('addMissionLayer')}</button><button class="studioImportMissionSeries secondary" type="button">▦ ${tr('importMissionSeries')}</button><button class="studioOpenManager secondary" type="button">⋯</button></div><div class="studioLayerList"></div><div class="studioGroupMini"><span>${tr('studioGroupSelect')} <b class="studioGroupCount">${layerGroupSelection.size}</b></span><div><button class="studioClearGroup" type="button">×</button><button class="studioGroupNow" type="button" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('studioGroupNow')}</button></div></div></aside><aside class="studioDrawer studioDrawerText"><div class="studioDrawerHead"><b>${tr('studioTexts')}</b><button class="studioDrawerClose" type="button">×</button></div><button class="studioAddText primary" type="button">＋ ${tr('studioAddText')}</button><div class="studioTextList"></div></aside><aside class="studioDrawer studioDrawerRight"><div class="studioDrawerHead"><b>${tr('studioTools')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioToolsBody"></div></aside></div>`;document.body.appendChild(root);studioEditorRoot=root;$('.studioCanvasStage',root).appendChild(canvas);canvas.classList.add('studioCanvas');
  $('.studioClose',root).onclick=()=>closeStudioEditor();$('.studioEdgeLeft',root).onclick=()=>studioToggleDrawer('.studioDrawerLeft');$('.studioEdgeText',root).onclick=()=>studioToggleDrawer('.studioDrawerText');$('.studioEdgeRight',root).onclick=()=>studioToggleDrawer('.studioDrawerRight');$$('.studioDrawerClose',root).forEach(b=>b.onclick=()=>b.closest('.studioDrawer').classList.remove('open'));
  $('.studioMissionMode',root).onclick=()=>{studioPanMode=false;root.classList.remove('panMode');canvas.style.pointerEvents='';$('.studioPan',root).classList.remove('on');setEditMode('mission');refreshStudioMissionControls();};
  $('.studioFrescoMode',root).onclick=()=>{setEditMode('fresco');studioFitMode='all';studioZoom=1;applyStudioCanvasSize({recenter:true});refreshStudioMissionControls();};
  $('.studioZoomOut',root).onclick=()=>{studioZoom=clamp(studioZoom-.2,.35,4);applyStudioCanvasSize()};$('.studioZoomIn',root).onclick=()=>{studioZoom=clamp(studioZoom+.2,.35,4);applyStudioCanvasSize()};$('.studioFullscreen',root).onclick=requestStudioFullscreen;$('.studioPan',root).onclick=()=>{studioPanMode=!studioPanMode;root.classList.toggle('panMode',studioPanMode);canvas.style.pointerEvents=studioPanMode?'none':'';$('.studioPan',root).classList.toggle('on',studioPanMode)};$('.studioAddLayer',root).onclick=()=>chooseImageFile('layer');$('.studioAddMissionLayer',root).onclick=chooseMissionLayerFile;$('.studioImportMissionSeries',root).onclick=chooseMissionSeriesFiles;
  refreshStudioEditor();render();setTimeout(()=>{applyStudioCanvasSize({recenter:true});requestStudioFullscreen()},50);window.addEventListener('resize',applyStudioCanvasSize);
}
function closeStudioEditor({keepOrientation=false}={}){
  if(!studioEditorRoot)return;window.removeEventListener('resize',applyStudioCanvasSize);canvas.classList.remove('studioCanvas');canvas.style.width='';canvas.style.height='';canvas.style.pointerEvents='';canvas.style.position='';canvas.style.left='';canvas.style.top='';canvas.style.transform='';canvas.style.transformOrigin='';studioPanMode=false;if(studioCanvasHome?.parent){if(studioCanvasHome.next)studioCanvasHome.parent.insertBefore(canvas,studioCanvasHome.next);else studioCanvasHome.parent.appendChild(canvas)}const root=studioEditorRoot;studioEditorRoot=null;root.remove();if(!keepOrientation){try{screen.orientation?.unlock?.()}catch{}studioOrientationLocked=false;try{if(document.fullscreenElement)document.exitFullscreen()}catch{}}render();
}


let layerGroupSelection=new Set();
function normalizeLayerGroups(){
  const counts=new Map();
  for(const l of state.imageLayers)if(l.groupId)counts.set(l.groupId,(counts.get(l.groupId)||0)+1);
  for(const l of state.imageLayers){
    if(l.groupId&&(counts.get(l.groupId)||0)<2){l.groupId=null;l.groupNumber=null;}
  }
  const validGroups=[...new Set(state.imageLayers.filter(l=>l.groupId).map(l=>l.groupId))];
  const assigned=new Map(),used=new Set();
  for(const gid of validGroups){
    const existing=state.imageLayers.find(l=>l.groupId===gid&&Number.isInteger(+l.groupNumber)&&+l.groupNumber>0&&!used.has(+l.groupNumber));
    if(existing){assigned.set(gid,+existing.groupNumber);used.add(+existing.groupNumber);}
  }
  let next=1;
  for(const gid of validGroups){
    if(!assigned.has(gid)){while(used.has(next))next++;assigned.set(gid,next);used.add(next);}
    const n=assigned.get(gid);for(const l of state.imageLayers)if(l.groupId===gid)l.groupNumber=n;
  }
}
function groupInfoForLayer(l){
  if(!l?.groupId)return null;normalizeLayerGroups();
  const n=Math.max(1,parseInt(l.groupNumber)||1),count=state.imageLayers.filter(x=>x.groupId===l.groupId).length;
  return {number:n,count,color:((n-1)%6)+1,label:tr('groupName',{n})};
}
function missionOptionsHtml(selected=1){const total=state.rows*COLS;return Array.from({length:total},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===+selected?'selected':''}>Mission ${n}</option>`).join('')}
async function createMissionImageLayer(file,{missionNumber=1,fitMode='cover',name=null}={}){if(!file)return null;if(file.size>45*1024*1024)toast(tr('heavyImage'));const img=await blobToImage(file);const layer={id:uid(),name:name||file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:0,y:0,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'mission',missionNumber:clamp(parseInt(missionNumber)||1,1,state.rows*COLS),fitMode:fitMode==='contain'?'contain':'cover'};fitImageLayer(layer);state.imageLayers.push(layer);return layer}
function chooseMissionLayerFile(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const file=input.files?.[0];input.remove();if(file)openMissionLayerImportSheet(file,{returnToStudio})};input.click()}
function openMissionLayerImportSheet(file,{returnToStudio=false}={}){const url=URL.createObjectURL(file),defaultMission=1;const sh=openSheet(`<div class="sheethead"><div><h2>🎯 ${tr('addMissionLayer')}</h2><p>${tr('missionLayerHint',{n:defaultMission})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="missionLayerImportPreview"><img src="${escapeAttr(url)}" alt=""><div><b>${escapeHtml(file.name)}</b><small>${Math.round(file.size/1024)} Ko</small></div></div><div class="field"><label>${tr('missionTarget')}</label><select class="missionLayerTarget">${missionOptionsHtml(defaultMission)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="missionLayerFit"><option value="cover">${tr('fitCover')}</option><option value="contain">${tr('fitContain')}</option></select></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('add')}</button></div>`);const cleanup=()=>URL.revokeObjectURL(url),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.missionLayerTarget',sh).onchange=e=>{$('.sheethead p',sh).textContent=tr('missionLayerHint',{n:e.target.value})};$('.import',sh).onclick=async()=>{const before=beginHistory(),n=+$('.missionLayerTarget',sh).value,fit=$('.missionLayerFit',sh).value,layer=await createMissionImageLayer(file,{missionNumber:n,fitMode:fit});if(!layer){cleanup();return}setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionLayerAdded',{n}));done()}}
function chooseMissionSeriesFiles(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.multiple=true;input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const files=[...(input.files||[])];input.remove();if(files.length)openMissionSeriesSheet(files,{returnToStudio})};input.click()}
function openMissionSeriesSheet(files,{returnToStudio=false}={}){const items=files.slice().sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})).map((file,i)=>({file,missionNumber:(i%(state.rows*COLS))+1,url:URL.createObjectURL(file)}));let fitMode='cover';const cleanup=()=>items.forEach(x=>URL.revokeObjectURL(x.url)),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};const renderSheet=()=>{const rows=items.map((x,i)=>`<div class="missionSeriesRow" data-series-index="${i}"><img src="${escapeAttr(x.url)}" alt=""><div class="missionSeriesInfo"><b>${escapeHtml(x.file.name)}</b><select class="seriesMission">${missionOptionsHtml(x.missionNumber)}</select></div><div class="missionSeriesOrder"><button type="button" class="seriesUp" ${i===0?'disabled':''}>↑</button><button type="button" class="seriesDown" ${i===items.length-1?'disabled':''}>↓</button></div></div>`).join('');const sh=openSheet(`<div class="sheethead"><div><h2>▦ ${tr('missionSeriesTitle')}</h2><p>${tr('missionSeriesText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule"><span class="dot"></span><span>${tr('missionSeriesDetected',{n:items.length})}${items.length>state.rows*COLS?` · ${tr('missionSeriesTooMany')}`:''}</span></div><div class="field"><label>${tr('fitMode')}</label><select class="seriesFit"><option value="cover" ${fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="missionSeriesList">${rows}</div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('missionSeriesImport')}</button></div>`);$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.seriesFit',sh).onchange=e=>{fitMode=e.target.value};$$('.missionSeriesRow',sh).forEach(row=>{const i=+row.dataset.seriesIndex;$('.seriesMission',row).onchange=e=>items[i].missionNumber=+e.target.value;$('.seriesUp',row).onclick=()=>{if(i<=0)return;[items[i-1],items[i]]=[items[i],items[i-1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()};$('.seriesDown',row).onclick=()=>{if(i>=items.length-1)return;[items[i+1],items[i]]=[items[i],items[i+1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()}});$('.import',sh).onclick=async()=>{const before=beginHistory(),created=[];for(const x of items){const l=await createMissionImageLayer(x.file,{missionNumber:x.missionNumber,fitMode});if(l)created.push(l)}if(created.length){setEditMode('fresco');setActive('image:'+created[created.length-1].id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionSeriesAdded',{n:created.length}))}done()}};renderSheet()}
function imageLayerIndex(id){return state.imageLayers.findIndex(l=>l.id===id)}
function chooseImageFile(mode='background'){
  pendingImageMode=mode==='background'?'background':'layer';
  const input=$('#fileInput');if(!input)return;input.value='';input.click();
}
function activateImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  setEditMode('fresco');setActive('image:'+id);render();scheduleSave();
}
function moveImageLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;
  const before=beginHistory();
  [state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];
  commitHistory(before,tr('histReorderLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleImageLayerVisibility(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;
  commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleBackgroundVisibility(){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet()}
function deleteImageLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();
  state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();
  commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDeleted'));
}
function duplicateImageLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();
  const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};
  const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;
  commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDuplicated'));
}
function renameImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameLayer')}</h2><p>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layer')}</label><input id="layerRename" maxlength="60" value="${escapeAttr(imageLayerLabel(l,imageLayerIndex(id)))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=()=>openImageLayersSheet();$('.cancel',sh).onclick=()=>openImageLayersSheet();
  $('.save',sh).onclick=()=>{const before=beginHistory();l.name=$('#layerRename',sh).value.trim()||tr('layerName');commitHistory(before,tr('histRenameLayer'));scheduleSave();openImageLayersSheet()};
}
function groupSelectedImageLayers(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));
  if(ids.length<2){toast(tr('groupNeedTwo'));return}
  const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}
  const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();
  state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupCreated'));
}
function ungroupImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();
  for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupRemoved'));
}
function setLayerOpacity(id,value){const l=state.imageLayers.find(x=>x.id===id);if(!l)return;l.opacity=clamp(value,0,1);render();scheduleSave()}
const layerPreviewUrls=new WeakMap();
function layerPreviewUrl(blob,image){
  if(blob instanceof Blob){
    let url=layerPreviewUrls.get(blob);
    if(!url){url=URL.createObjectURL(blob);layerPreviewUrls.set(blob,url)}
    return url;
  }
  const src=image?.src||'';
  return src&&!src.startsWith('blob:')?src:'';
}
function imageLayerThumbHtml(blob,image,{fallback='▧',alt='',studio=false}={}){
  const src=layerPreviewUrl(blob,image);
  if(!src)return `<span class="${studio?'studioLayerGlyph':'layerGlyph'}">${fallback}</span>`;
  return `<span class="${studio?'studioLayerThumb':'layerThumb'}"><img src="${escapeAttr(src)}" alt="" aria-label="${escapeAttr(alt)}"></span>`;
}
function openImageLayersSheet(){
  setEditMode('fresco');normalizeLayerGroups();
  for(const id of [...layerGroupSelection])if(!state.imageLayers.some(l=>l.id===id))layerGroupSelection.delete(id);
  const ordered=[...state.imageLayers].map((l,i)=>({l,i})).reverse();
  const layerRows=ordered.map(({l,i})=>{
    const active=state.active==='image:'+l.id,top=i===state.imageLayers.length-1,bottom=i===0,grouped=!!l.groupId,ginfo=groupInfoForLayer(l);
    const w=l.image?.naturalWidth||0,h=l.image?.naturalHeight||0;
    return `<div class="imageLayerRow ${active?'active':''} ${l.visible===false?'hidden':''} ${grouped?`groupedLayer groupColor${ginfo.color}`:''}" data-layer="${escapeAttr(l.id)}">
      ${grouped?`<span class="groupEdge" aria-hidden="true"></span>`:''}
      <label class="layerCheck" title="${tr('groupSelection')}"><input type="checkbox" class="layerGroupCheck" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="layerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:grouped?'▱':'▧',alt:imageLayerLabel(l,i)})}<span class="layerCopy"><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${w&&h?tr('layerDimensions',{w,h}):''}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}${grouped?` · <span class="groupInline">${tr('groupCount',{n:ginfo.count})}</span>`:''}</small>${grouped?`<span class="groupBadge">${escapeHtml(ginfo.label)}</span>`:''}</span>${active?`<em>${tr('selected')}</em>`:''}</button>
      <button class="layerEye" title="${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}">${l.visible===false?'◌':'◉'}</button>
      <div class="layerQuick"><button class="layerDown" ${bottom?'disabled':''} title="${tr('moveDown')}">↓</button><button class="layerUp" ${top?'disabled':''} title="${tr('moveUp')}">↑</button><button class="layerMore" title="${tr('layerTransform')}">⋯</button></div>
    </div>`;
  }).join('')||`<div class="layerEmpty">${tr('layersDesc')}</div>`;
  const activeLayer=activeImageLayer(),activeIsExtra=state.active.startsWith('image:'),groupedActive=activeIsExtra&&!!activeLayer?.groupId;
  const sh=openSheet(`<div class="sheethead"><div><h2>${icon('layers')} ${tr('layersTitle')}</h2><p>${tr('layersDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="layerAddGrid layerAddGrid4"><button class="primary addBackground">${icon('image')} ${tr('addBackground')}</button><button class="secondary addImageLayer">${icon('plus')} ${tr('addLayer')}</button><button class="secondary addMissionLayer">🎯 ${tr('addMissionLayer')}</button><button class="secondary importMissionSeries">▦ ${tr('importMissionSeries')}</button></div><div class="layerImportHint">${tr('importRolesHint')}</div>
    <div class="imageLayerStack">
      ${layerRows}
      <div class="imageLayerRow backgroundRow ${state.active==='background'?'active':''} ${state.bg.visible===false?'hidden':''}">
        <span class="layerCheck lock">⌄</span><button class="layerSelect selectBackground">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer')})}<span class="layerCopy"><b>${tr('backgroundLayer')}</b><small>${state.bg.image?tr('layerDimensions',{w:state.bg.image.naturalWidth,h:state.bg.image.naturalHeight}):tr('backgroundMissing')}</small></span>${state.active==='background'?`<em>${tr('selected')}</em>`:''}</button><button class="layerEye backgroundEye">${state.bg.visible===false?'◌':'◉'}</button><span class="layerBottomLock">🔒</span>
      </div>
    </div>
    <div class="layerGroupBar"><div><b>${tr('groupSelection')}</b><small>${tr('groupHint')}</small></div><span class="layerSelectionCount">${layerGroupSelection.size}</span></div>
    <div class="actions layerGroupActions"><button class="secondary clearGroup" ${layerGroupSelection.size?'':'disabled'}>${tr('clearGroupSelection')}</button><button class="primary doGroup" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('group')}</button>${groupedActive?`<button class="secondary doUngroup">${tr('layerUngroup')}</button>`:''}</div>
    <p class="small layerFooterHint">${tr('backgroundFixed')} ${tr('layerSelectHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('.addBackground',sh).onclick=()=>{closeSheet();chooseImageFile('background')};$('.addImageLayer',sh).onclick=()=>{closeSheet();chooseImageFile('layer')};$('.addMissionLayer',sh).onclick=()=>{closeSheet();chooseMissionLayerFile()};$('.importMissionSeries',sh).onclick=()=>{closeSheet();chooseMissionSeriesFiles()};
  $('.selectBackground',sh).onclick=()=>{setActive('background');openImageLayersSheet()};$('.backgroundEye',sh).onclick=toggleBackgroundVisibility;
  $$('.imageLayerRow[data-layer]',sh).forEach(row=>{
    const id=row.dataset.layer;$('.layerSelect',row).onclick=()=>{activateImageLayer(id);openImageLayersSheet()};
    $('.layerEye',row).onclick=()=>toggleImageLayerVisibility(id);$('.layerDown',row).onclick=()=>moveImageLayer(id,-1);$('.layerUp',row).onclick=()=>moveImageLayer(id,1);
    $('.layerGroupCheck',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);openImageLayersSheet()};
    $('.layerMore',row).onclick=()=>openLayerActionsSheet(id);
  });
  $('.clearGroup',sh).onclick=()=>{layerGroupSelection.clear();openImageLayersSheet()};$('.doGroup',sh).onclick=groupSelectedImageLayers;if($('.doUngroup',sh))$('.doUngroup',sh).onclick=()=>ungroupImageLayer(activeLayer.id);
}
function openLayerActionsSheet(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;activateImageLayer(id);normalizeImageLayerScope(l);
  const grouped=!!l.groupId,ginfo=groupInfoForLayer(l),missionControls=l.scope==='mission'?`<div class="field"><label>${tr('missionTarget')}</label><select class="layerMissionTarget">${missionOptionsHtml(l.missionNumber)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="layerMissionFit"><option value="cover" ${l.fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${l.fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="rule"><span class="dot"></span><span>${tr('missionLayerHint',{n:l.missionNumber})}</span></div>`:'';
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))} ${missionLayerBadgeHtml(l)}</h2><p>${grouped?`${tr('groupTransform')} · ${escapeHtml(ginfo.label)} · ${tr('groupCount',{n:ginfo.count})}`:tr('layerTransform')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layerScope')}</label><select class="layerScopeSelect"><option value="global" ${l.scope==='global'?'selected':''}>${tr('wholeBanner')}</option><option value="mission" ${l.scope==='mission'?'selected':''}>${tr('missionLayer')}</option></select></div>${missionControls}<div class="field"><label>${tr('layerOpacity')} <span class="opacityVal">${Math.round((l.opacity??1)*100)}%</span></label><input class="layerOpacityRange" type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></div><div class="layerActionGrid"><button class="secondary transformLayer">${icon('move')} ${grouped?tr('groupTransform'):tr('layerTransform')}</button><button class="secondary renameLayerBtn">${icon('edit')} ${tr('renameLayer')}</button><button class="secondary duplicateLayerBtn">${icon('copy')} ${tr('duplicateLayer')}</button>${grouped?`<button class="secondary ungroupLayerBtn">${tr('ungroup')}</button>`:''}<button class="danger deleteLayerBtn">${icon('trash')} ${tr('deleteLayer')}</button></div>`);
  $('.close',sh).onclick=openImageLayersSheet;const rng=$('.layerOpacityRange',sh);rng.oninput=e=>{setLayerOpacity(id,+e.target.value/100);$('.opacityVal',sh).textContent=`${e.target.value}%`};historyControl(rng,tr('histVisibilityLayer'));
  $('.layerScopeSelect',sh).onchange=e=>{const before=beginHistory();l.scope=e.target.value==='mission'?'mission':'global';l.groupId=null;l.groupNumber=null;if(l.scope==='mission'){l.missionNumber=clamp(parseInt(l.missionNumber)||1,1,state.rows*COLS);l.fitMode=l.fitMode==='contain'?'contain':'cover'}else l.missionNumber=null;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionTarget',sh))$('.layerMissionTarget',sh).onchange=e=>{const before=beginHistory();l.missionNumber=+e.target.value;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionFit',sh))$('.layerMissionFit',sh).onchange=e=>{const before=beginHistory();l.fitMode=e.target.value==='contain'?'contain':'cover';fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  $('.transformLayer',sh).onclick=openTransformSheet;$('.renameLayerBtn',sh).onclick=()=>renameImageLayer(id);$('.duplicateLayerBtn',sh).onclick=()=>duplicateImageLayer(id);$('.deleteLayerBtn',sh).onclick=()=>deleteImageLayer(id);if($('.ungroupLayerBtn',sh))$('.ungroupLayerBtn',sh).onclick=()=>ungroupImageLayer(id);
}
function imageFitScale(o){
  if(!o?.image)return 1;
  if(o===state.bg)return Math.max(WORLD_W/o.image.naturalWidth,worldH()/o.image.naturalHeight);
  normalizeImageLayerScope(o);if(o.scope==='mission')return missionLayerFitScale(o);
  return Math.min(WORLD_W*.72/o.image.naturalWidth,worldH()*.72/o.image.naturalHeight);
}
function shiftImageItems(items,dx,dy){for(const x of items){x.x=(x.x||0)+dx;x.y=(x.y||0)+dy}}
function groupTransformBaseline(items){
  const snap=captureTransformTargets(items),center=transformCenter(snap);return {snap,center};
}
function applyRelativeGroupTransform(base,scaleFactor,rotationDelta){
  const cs=Math.cos(rotationDelta),sn=Math.sin(rotationDelta);
  for(const t of base.snap){const ox=(t.x-base.center.x)*scaleFactor,oy=(t.y-base.center.y)*scaleFactor;t.obj.x=base.center.x+ox*cs-oy*sn;t.obj.y=base.center.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*scaleFactor,.02,30);t.obj.rotation=t.rotation+rotationDelta}
}

function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast(tr('touchMissionFirst'));return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${n}</h2><p>${tr('missionCropOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>${tr('localZoom')} <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>${tr('rotation')} <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} ${tr('resetThisMission')}</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),tr('histMissionZoom'));
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),tr('histMissionRotation'));
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:'),isImage=!isText;
  const items=isImage?frescoTransformTargets():[o],isGroup=isImage&&items.length>1,groupBase=isGroup?groupTransformBaseline(items):null;
  const fit=isImage&&!isGroup?imageFitScale(o):1,zoomValue=isGroup?100:Math.round((isText?o.scale:o.scale/Math.max(.0001,fit))*100),rotValue=isGroup?0:Math.round((o.rotation||0)*180/Math.PI);
  const title=isText?tr('transformText'):(isGroup?tr('groupTransform'):tr('layerTransform'));
  const sh=openSheet(`<div class="sheethead"><div><h2>${title}</h2><p>${isGroup?tr('groupRelative'):tr('pinchHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${isGroup?tr('groupZoom'):tr('zoom')} <span id="zoomVal">${zoomValue}%</span></label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>${isGroup?tr('groupRotation'):tr('rotation')} <span id="rotVal">${rotValue}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${rotValue}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">${tr('center')}</button>${!isGroup?`<button class="secondary" id="resetBtn">${icon('reset')} ${tr('reset')}</button>`:''}${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  if(isGroup){
    const apply=()=>{applyRelativeGroupTransform(groupBase,+$('#zoom',sh).value/100,+$('#rotation',sh).value*Math.PI/180);$('#zoomVal',sh).textContent=`${$('#zoom',sh).value}%`;$('#rotVal',sh).textContent=`${$('#rotation',sh).value}°`;render();scheduleSave()};
    $('#zoom',sh).oninput=apply;$('#rotation',sh).oninput=apply;historyControl($('#zoom',sh),tr('histImageZoom'));historyControl($('#rotation',sh),tr('histImageRotation'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory(),now=transformCenter(captureTransformTargets(items));shiftImageItems(items,WORLD_W/2-now.x,worldH()/2-now.y);render();commitHistory(before,tr('histCenterImage'));scheduleSave()};
  }else{
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),isText?tr('histTextRotation'):tr('histImageRotation'));
    $('#zoom',sh).oninput=e=>{o.scale=(isText?1:fit)*(+e.target.value/100);$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),isText?tr('histTextZoom'):tr('histImageZoom'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory();if(!isText&&o.scope==='mission'){const mr=missionLayerRect(o);if(mr){o.x=mr.cx;o.y=mr.cy}}else{o.x=WORLD_W/2;o.y=worldH()/2}render();commitHistory(before,isText?tr('histCenterText'):tr('histCenterImage'));scheduleSave()};
    $('#resetBtn',sh).onclick=()=>{const before=beginHistory();if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else if(o===state.bg)fitBackground();else fitImageLayer(o);closeSheet();render();commitHistory(before,isText?tr('histResetText'):tr('histResetImage'));scheduleSave()};
  }
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast(tr('selectMissionFirst'));return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="${tr('close')}">${icon('close')}</button>
      <div><strong id="missionEditorTitle">${tr('missions')} ${n}</strong><span>${tr('individualCrop')}</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="${tr('previewPrime')}">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>${tr('oneFinger')}</b> ${tr('move')} · <b>${tr('twoFingers')}</b> ${tr('zoomRotate')}</div>
    <section class="missioneditorcontrols">
      <div class="missionhistory"><button class="secondary undoActionBtn missionundo" disabled>↶ ${tr('undo')}</button><button class="secondary redoActionBtn missionredo" disabled>↷ ${tr('redo')}</button></div>
      <div class="missionnav">
        <button class="secondary missionprev">‹ ${tr('prev')}</button>
        <button class="secondary missionnext">${tr('next')} ›</button>
      </div>
      <div class="field"><label>${tr('zoom')} <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>${tr('rotation')} <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} ${tr('reset')}</button><button class="primary missiondone">${tr('done')}</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const before=beginHistory(),o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();commitHistory(before,tr('histResetMission'));scheduleSave();};
  $('.missionundo',back).onclick=undoAction;$('.missionredo',back).onclick=redoAction;
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorZoom',back),tr('histMissionZoom'));
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorRot',back),tr('histMissionRotation'));
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=`Mission ${n}`;
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0,historyBefore:beginHistory()};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){const before=missionEditorGesture?.historyBefore;missionEditorGesture=null;commitHistory(before,tr('histResetMission'));scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0],before=missionEditorGesture?.historyBefore;missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0,historyBefore:before};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  const before=beginHistory();
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();commitHistory(before,tr('histResetMission'));scheduleSave();toast(tr('missionResetDone',{n:missionNumber(rc.row,rc.col)}));
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  const before=beginHistory();
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();commitHistory(before,tr('histDeleteText'));scheduleSave();toast(tr('textDeleted'));
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('text')}</h2><p>${tr('textLayerDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('layer')}</label><select id="textLayer"><option value="new">${tr('newText')}</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);if(t)normalizeTextStyle(t);const box=$('#textEditor',sh),td=textDefaults(t||{});
    box.innerHTML=`<div class="field"><label>${tr('text')}</label><input id="txt" value="${escapeAttr(t?.text||'I LOVE REDACTED')}" maxlength="120"></div>
      <div class="textTypographyCard"><b>${tr('textTypography')}</b><div class="field"><label>${tr('font')}</label><div class="fontPickerLine"><select id="fontFamily">${fontOptionsHtml(td.fontFamily)}</select><button type="button" class="secondary" id="importFont">＋ ${tr('importFont')}</button></div></div>
      <div class="grid2"><div class="field"><label>${tr('size')}</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>${tr('fontWeight')}</label><select id="fontWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${td.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></div></div>
      <div class="grid2"><div class="field"><label>${tr('letterSpacing')}</label><input id="letterSpacing" type="number" min="-40" max="160" value="${td.letterSpacing||0}"></div><div class="field"><label>${tr('lineHeight')}</label><input id="lineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${td.lineHeight||1.08}"></div></div>
      <div class="grid2"><div class="field"><label>${tr('textAlign')}</label><select id="textAlign"><option value="left" ${td.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${td.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${td.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></div><label class="switchline textItalicLine"><input id="fontItalic" type="checkbox" ${td.fontItalic?'checked':''}> ${tr('fontItalic')}</label></div></div>
      <div class="grid2"><div class="field"><label>${tr('outline')}</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div><div class="field"><label>${tr('color')}</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div></div>
      <div class="field"><label>${tr('outlineColor')}</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div>
      <label class="switchline"><input id="textBgEnabled" type="checkbox" ${td.backgroundEnabled?'checked':''}> ${tr('textBackground')}</label>
      <div id="textBgFields" ${td.backgroundEnabled?'':'hidden'}><div class="grid2"><div class="field"><label>${tr('textBackgroundColor')}</label><input id="textBgColor" type="color" value="${td.backgroundColor}"></div><div class="field"><label>${tr('textBackgroundOpacity')}</label><input id="textBgOpacity" type="number" min="0" max="100" value="${Math.round(td.backgroundOpacity*100)}"></div></div><div class="grid2"><div class="field"><label>${tr('textBackgroundPadding')}</label><input id="textBgPadding" type="number" min="0" max="180" value="${td.backgroundPadding}"></div><div class="field"><label>${tr('textBackgroundRadius')}</label><input id="textBgRadius" type="number" min="0" max="240" value="${td.backgroundRadius}"></div></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?tr('update'):tr('add')}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`;
    $('#textBgEnabled',box).onchange=e=>$('#textBgFields',box).hidden=!e.target.checked;$('#importFont',box).onclick=()=>importProjectFont(t,rec=>{if(t){t.fontFamily=rec.family;drawTextEditor(t.id)}else{const select=$('#fontFamily',box);if(select){select.insertAdjacentHTML('beforeend',`<option value="${escapeAttr(rec.family)}">★ ${escapeHtml(rec.name)}</option>`);select.value=rec.family}}});
    $('#saveText',box).onclick=()=>{
      const before=beginHistory(),wasNew=!t;
      const style={text:$('#txt',box).value||tr('text'),fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,fontFamily:$('#fontFamily',box).value,fontWeight:+$('#fontWeight',box).value||800,fontItalic:$('#fontItalic',box).checked,letterSpacing:+$('#letterSpacing',box).value||0,lineHeight:+$('#lineHeight',box).value||1.08,textAlign:$('#textAlign',box).value,backgroundEnabled:$('#textBgEnabled',box).checked,backgroundColor:$('#textBgColor',box).value,backgroundOpacity:clamp((+$('#textBgOpacity',box).value||0)/100,0,1),backgroundPadding:clamp(+$('#textBgPadding',box).value||0,0,180),backgroundRadius:clamp(+$('#textBgRadius',box).value||0,0,240)};
      if(!t){t=textDefaults({id:uid(),x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,...style});state.texts.push(t)}else Object.assign(t,style);normalizeTextStyle(t);
      setActive('text:'+t.id);commitHistory(before,wasNew?tr('histAddText'):tr('histEditText'));scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('previewPrime')}</h2><p>${tr('previewApplied')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">${tr('previewOrder')}</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseBackground(cc);cc.restore();
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);drawOverlayWorld(cc);cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('exportTitle',{n:count})}</h2><p>${tr('exportIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!hasImageContent()?`<div class="rule warning"><span class="dot"></span><span>${tr('noImageContent')}</span></div>`:''}
    <div class="field"><label>${tr('missionFormat')}</label><select id="exportFormat"><option value="jpeg" selected>${tr('jpgFast')}</option><option value="png">${tr('pngLossless')}</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>${tr('fastEncoding')}</span></div><div class="rule"><span class="dot"></span><span>${tr('rowRender')}</span></div><div class="rule"><span class="dot"></span><span>${tr('adjusted',{n:adjusted})}</span></div><div class="rule warning"><span class="dot"></span><span>${tr('nianticCheck')}</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">${tr('ready')}</div>
    <div class="actions"><button class="primary" id="doExport" ${!hasImageContent()?'disabled':''}>${tr('createZip')}</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseBackground(cc);drawOverlayWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent=tr('zipAssembly');bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`${tr('zipAssembly')} ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent=tr('zipCreated');
      await Share.share({title:'Export Redacted BannerLab',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:tr('saveShareZip')});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent=tr('zipDownloaded');
    }
    toast(tr('exportFinished',{format:jpeg?'JPG':'PNG'}));
  }catch(err){console.error(err);txt.textContent='Erreur : '+(err?.message||err);toast(tr('exportFailed'))}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}\n${state.name}\n${state.rows} rangée(s) · ${state.rows*6} missions\n\nOrdre de création :\n`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false);s+=`${String(n).padStart(3,'0')}.${ext} : rangée ${row+1} depuis le haut, colonne ${col+1} depuis la gauche${o&&!isIdentityOverride(o)?' · recadrage individuel':''}\n`}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('Canvas export impossible')),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const MIN_PORTALS_PER_MISSION=6;

const OBJECTIVE_LABELS={
  HACK_PORTAL:'hack',
  INSTALL_MOD:'mod',
  CAPTURE_PORTAL:'capture',
  CREATE_LINK:'link',
  CREATE_FIELD:'field',
  PASSPHRASE:'passphrase'
};
function objectiveLabel(type){return tr(OBJECTIVE_LABELS[type]||'hack')}
function missionSequential(m){return typeof m?.sequential==='boolean'?m.sequential:state.planner.sequential!==false}
function missionHidden(m){return missionSequential(m)&&(typeof m?.hiddenLocation==='boolean'?m.hiddenLocation:!!state.planner.hiddenLocation)}

function projectLanguage(){return SUPPORTED_LANGS.includes(state.projectLanguage)?state.projectLanguage:APP_LANG}
function trProject(key,vars={}){
  let txt=(I18N[projectLanguage()]&&I18N[projectLanguage()][key])||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))txt=txt.replaceAll('{'+k+'}',String(v));
  return txt;
}
function defaultMissionPassphrase(mi){return {question:trProject('missionNumberQuestion'),answer:String(Math.max(0,Number(mi)||0)+1)}}
function fillPassphraseDefaults(portal,mi){
  if(!portal?.objective||portal.objective.type!=='PASSPHRASE')return portal;
  portal.objective.passphrase_params=portal.objective.passphrase_params||{question:'',_single_passphrase:''};
  const d=defaultMissionPassphrase(mi);
  if(!String(portal.objective.passphrase_params.question||'').trim())portal.objective.passphrase_params.question=d.question;
  if(!String(portal.objective.passphrase_params._single_passphrase||'').trim())portal.objective.passphrase_params._single_passphrase=d.answer;
  return portal;
}


function normalizePlanner(p={}){
  const planner={
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24),
    autoAdvance: p.autoAdvance!==false,
    reuseLastPortal: p.reuseLastPortal!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    sequential: typeof m.sequential==='boolean'?m.sequential:null,
    hiddenLocation: typeof m.hiddenLocation==='boolean'?m.hiddenLocation:null,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||tr('portalDefault')),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||tr('bannerDefault');
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function guidOccurrences(guid){
  const out=[];
  state.planner.missions.forEach((m,mi)=>(m.portals||[]).forEach((p,pi)=>{if(guid&&p.guid===guid)out.push({mi,pi})}));
  return out;
}
function isAllowedHandoverOccurrences(occ){
  if(occ.length!==2)return false;
  const [a,b]=occ;
  if(b.mi!==a.mi+1||b.pi!==0)return false;
  const prev=state.planner.missions[a.mi]?.portals||[];
  return a.pi===prev.length-1;
}
function duplicateGuidCount(){
  let bad=0;
  for(const m of state.planner.missions){
    const seen=new Set(),dupes=new Set();
    for(const p of (m.portals||[]))if(p.guid){if(seen.has(p.guid))dupes.add(p.guid);else seen.add(p.guid)}
    bad+=dupes.size;
  }
  return bad;
}
function canReuseAsHandover(portal,mi){
  if(!portal?.guid||mi<=0)return false;
  const cur=plannerMission(mi),prev=plannerMission(mi-1);
  return cur.portals.length===0&&prev?.portals?.at(-1)?.guid===portal.guid;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):tr('route');
  const badGuid=!p.guid,pass=p.objective?.type==='PASSPHRASE';
  const extra=pass&&p.objective?.passphrase_params?.question?` · ${escapeHtml(p.objective.passphrase_params.question)}`:'';
  return `<div class="portalrow portalrow-v2" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||tr('portalDefault'))}</strong><span>${dist}${badGuid?' · GUID ?':''}</span>
      <button class="portalactionbtn">${escapeHtml(objectiveLabel(p.objective?.type))}${extra}</button>
    </div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="↑">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="↓">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="×">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('route')} · ${tr('missions')} ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} ${tr('portalsPerMission').split(' / ')[0].toLowerCase()} · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ ${tr('prev')}</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>${tr('next')} ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?tr('complete'):tr('remaining',{n:Math.max(0,need-count)})}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion">
      <div class="iitccompanion-head"><img src="/redacted-logo-512.png" alt="Redacted"><div><b>IITC Companion</b><span>${tr('companionStats')}</span></div><span class="beta">${tr('pluginVersion')}</span></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('companionStats')}</b><small>${tr('companionStatsDesc')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('action')}</b><small>${tr('routeActionHelp')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('handoverOk')}</b><small>${tr('handoverDetail')}</small></div></div>
      <div class="actions companionactions"><button class="primary openintel">${icon('globe')} ${tr('openIitc')}</button><button class="secondary tutorialiitc">${icon('info')} ${tr('tutorial')}</button></div>
      <div class="actions companionsecondary"><button class="secondary sharebridge">${tr('installPlugin')}</button></div>
    </div>
    <div class="routeoptions">
      <label class="switchline"><input type="checkbox" id="autoAdvance" ${state.planner.autoAdvance?'checked':''}> ${tr('autoAdvance',{n:need})}</label>
      <label class="switchline"><input type="checkbox" id="reuseLastPortal" ${state.planner.reuseLastPortal?'checked':''}> ${tr('reuseLast')}</label>
    </div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${tr('duplicateBad',{n:dup})}</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):`<div class="emptyroute">${tr('noPortal')}</div>`}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('#autoAdvance',sh).onchange=e=>{state.planner.autoAdvance=e.target.checked;scheduleSave()};
  $('#reuseLastPortal',sh).onchange=e=>{state.planner.reuseLastPortal=e.target.checked;scheduleSave()};
  $('.openintel',sh).onclick=openIntel;
  $('.tutorialiitc',sh).onclick=()=>startTutorial('iitc',{manual:true});
  $('.sharebridge',sh).onclick=shareIitcBridge;
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalactionbtn',row).onclick=()=>openPortalObjectiveSheet(idx,pi);
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();openRoutePlanner();
}
function removePortal(mi,pi){const m=plannerMission(mi);if(!m)return;m.portals.splice(pi,1);scheduleSave();openRoutePlanner()}

function openPortalObjectiveSheet(mi,pi){
  const m=plannerMission(mi),p=m?.portals?.[pi];if(!p)return;
  const options=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('action')}</h2><p>${escapeHtml(p.title)}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('action')}</label><select id="objectiveType">${options}</select></div>
    <div class="passphraseFields" ${p.objective?.type==='PASSPHRASE'?'':'hidden'}>
      <div class="field"><label>${tr('question')}</label><input id="passQuestion" value="${escapeAttr(p.objective?.passphrase_params?.question||'')}"></div>
      <div class="field"><label>${tr('answer')}</label><input id="passAnswer" value="${escapeAttr(p.objective?.passphrase_params?._single_passphrase||'')}"></div>
    </div>
    <div class="actions"><button class="secondary close2">${tr('cancel')}</button><button class="primary saveobj">${tr('save')}</button></div>`);
  const update=()=>{
    const isPass=$('#objectiveType',sh).value==='PASSPHRASE';
    $('.passphraseFields',sh).hidden=!isPass;
    if(isPass){const d=defaultMissionPassphrase(mi);const q=$('#passQuestion',sh),a=$('#passAnswer',sh);if(q&&!q.value.trim())q.value=d.question;if(a&&!a.value.trim())a.value=d.answer}
  };
  $('#objectiveType',sh).onchange=update;update();
  $('.close',sh).onclick=closeSheet;$('.close2',sh).onclick=closeSheet;
  $('.saveobj',sh).onclick=()=>{
    p.objective.type=$('#objectiveType',sh).value;
    p.objective.passphrase_params.question=$('#passQuestion',sh)?.value?.trim()||'';
    p.objective.passphrase_params._single_passphrase=$('#passAnswer',sh)?.value?.trim()||'';
    fillPassphraseDefaults(p,mi);
    scheduleSave();openRoutePlanner();
  };
}

function addPortalToMission(portal,mi=state.planner.currentMission,opts={}){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  const p=normalizePortal(portal);fillPassphraseDefaults(p,mi);
  if(p.guid&&(m.portals||[]).some(x=>x.guid===p.guid)){toast(tr('duplicateElsewhere'));return false}
  m.portals.push(p);scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){
    const last=m.portals.at(-1);
    state.planner.currentMission=mi+1;
    const next=plannerMission(mi+1);
    if(state.planner.reuseLastPortal&&next.portals.length===0&&last)next.portals.push(structuredClone(last));
    scheduleSave();
    toast(tr('missionCompleteAdded',{n:mi+1,next:mi+2}));
  }else toast(tr('portalAdded',{n:mi+1}));
  return true;
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||tr('portalDefault'),Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL',p.objective?.passphrase_params?.question||'',p.objective?.passphrase_params?._single_passphrase||'']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||'Portail',location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL',passphrase_params:{question:a?.[6]||'',_single_passphrase:a?.[7]||''}}})}
function bridgePlannerPayload(){
  ensurePlannerMissions();return {v:3,pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,carry:state.planner.reuseLastPortal!==false,lang:projectLanguage(),m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact))};
}
async function openIntel(){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  u.hash='rbl='+encodeURIComponent(bridgeEncode(bridgePlannerPayload()));

  if(!Capacitor.isNativePlatform()){
    window.open(u.toString(),'_blank','noopener');
    return;
  }

  // Android : une URL https seule part dans Chrome. On cible donc explicitement
  // IITC Mobile avec ACTION_VIEW + l'URL contenant le payload BannerLab.
  const candidates=[
    'org.exarhteam.iitc_mobile',
    'org.exarhteam.iitcprime'
  ];

  for(const packageName of candidates){
    try{
      await IntentLauncher.startActivityAsync({
        action: ActivityAction.VIEW,
        data: u.toString(),
        packageName
      });
      toast(packageName.includes('iitcprime')
        ? tr('intelPrimeOpened')
        : tr('intelOpened'));
      return;
    }catch(e){
      console.warn(`IITC non ouvert via ${packageName}`,e);
    }
  }

  // Ultime secours : on ouvre IITC Mobile sans payload si Android refuse
  // l'intent ciblé, puis seulement le navigateur si IITC n'est pas installé.
  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitc_mobile'});
    toast(tr('intelFallback'));
    return;
  }catch(e){
    console.warn('IITC Mobile absent',e);
  }

  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitcprime'});
    toast(tr('intelPrimeFallback'));
    return;
  }catch(e){
    console.warn('IITC Prime absent',e);
  }

  await AppLauncher.openUrl({url:u.toString()});
  toast(tr('intelBrowser'));
}
async function bridgeUserscriptText(){
  const r=await fetch('/redacted-bannerlab-iitc.user.js',{cache:'no-store'});if(!r.ok)throw new Error('Plugin IITC introuvable');return await r.text();
}
async function shareIitcBridge(){
  const name='redacted-bannerlab-iitc.user.js';
  try{
    const text=await bridgeUserscriptText();
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab · IITC Companion 0.6.3',text:tr('pluginShareText'),url:uri.uri,dialogTitle:tr('pluginDialog')});
    }else downloadBlob(new Blob([text],{type:'text/javascript'}),name);
  }catch(e){console.error(e);toast(tr('pluginShareFailed'))}
}

function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>${tr('tutorialIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>${tr('tut1Title')}</strong><span>${tr('tut1Text')}</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>${tr('tut2Title')}</strong><span>${tr('tut2Text')}</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>${tr('tut3Title')}</strong><span>${tr('tut3Text')}</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>${tr('tut4Title')}</strong><span>${tr('tut4Text')}</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>${tr('tutNote')}</span></div>
    <div class="actions"><button class="secondary installplugin">${tr('installUpdate')}</button><button class="primary launchiitc">${tr('openIitc')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}

function handleBridgeUrl(raw){
  try{
    const u=new URL(raw);if(u.protocol!=='redactedbannerlab:')return false;
    if(u.hostname==='play'||u.hostname==='banner'){
      const id=u.searchParams.get('banner')||u.searchParams.get('id')||'';const mission=Math.max(0,parseInt(u.searchParams.get('mission')||'0')||0);
      if(!id)return false;setTimeout(()=>joinSharedBanner(id,mission),120);return true;
    }
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||'Portail',imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='publisher-chrome-ready'){
      setPublisherReady('chrome',true);
      setChromeSetupStep(4);
      setPublisherBrowser('chrome');
      toast(tr('setupConfirmed'));
      closeSheet();
      setTimeout(()=>openChromeSetupSheet(4),120);
      return true;
    }
    if(u.hostname==='publisher-firefox-ready'){
      setPublisherReady('firefox',true);
      setPublisherBrowser('firefox');
      toast(tr('setupConfirmed'));
      return true;
    }
    if(u.hostname==='publisher-next'){
      const index=clamp(parseInt(u.searchParams.get('mission'))||0,0,state.planner.missions.length-1);
      state.planner.currentMission=index;
      scheduleSave();saveProject();
      setTimeout(()=>openBrowserPublisher(index),180);
      return true;
    }
    if(u.hostname==='publisher-return'){
      toast(tr('publisherReturn'));
      return true;
    }
    if(u.hostname==='sync'){
      const data=bridgeDecode(u.searchParams.get('data')||'');if(!data||!Number.isFinite(Number(data.v))||Number(data.v)<2||!Array.isArray(data.m))return false;
      ensurePlannerMissions();
      state.planner.portalsPerMission=clamp(parseInt(data.ppm)||state.planner.portalsPerMission,MIN_PORTALS_PER_MISSION,24);
      state.planner.autoAdvance=data.auto!==false;if(typeof data.carry==='boolean')state.planner.reuseLastPortal=data.carry;
      data.m.slice(0,state.planner.missions.length).forEach((portals,i)=>{if(Array.isArray(portals))state.planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean)});
      state.planner.currentMission=clamp(parseInt(data.c)||0,0,state.planner.missions.length-1);
      scheduleSave();saveProject();
      if(!data.pv)toast(tr('syncOld'));
      else toast(tr('syncOk',{v:data.pv}));
      openRoutePlanner();return true;
    }
    return false;
  }catch(e){console.warn('bridge',e);toast('Synchronisation IITC illisible.');return false}
}
function openMissionSettings(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(m=>m.portals.length>=need).length;
  const hasDescription=!!state.planner.description.trim();

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')}</h2><p>${complete}/${state.planner.missions.length} ${tr('missionReady').toLowerCase()}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>

    <div class="requiredFieldCard ${hasDescription?'ok':'missing'}">
      <div class="requiredFieldHead">
        <div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div>
        <strong>${hasDescription?'✓':'!'}</strong>
      </div>
      <textarea id="bannerDesc" rows="4" placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
      <small>${tr('bannerDescriptionHint')}</small>
    </div>

    <details class="missiondefaults">
      <summary>${tr('settings')}</summary>
      <div class="missiondefaults-body">
        <div class="field"><label>${tr('titleFormat')}</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><small>${tr('titleTokens')}</small></div>
        <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>${tr('sequential')}</option><option value="0" ${!state.planner.sequential?'selected':''}>${tr('anyOrder')}</option></select></div>
        <div class="field"><label>${tr('location')}</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>${tr('visible')}</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>${tr('hidden')}</option></select></div></div>
        <div class="field"><label>${tr('portalsPerMission')}</label><input id="ppm" type="number" min="${MIN_PORTALS_PER_MISSION}" max="24" value="${need}"><small>${tr('minimumSix')}</small></div>
      </div>
    </details>

    <div class="missionlist-v2">${state.planner.missions.map((x,i)=>{
      const ok=x.portals.length>=need;
      return `<button class="missioncard-v2 ${ok?'ok':''}" data-mi="${i}">
        <span class="missioncard-num">${String(i+1).padStart(2,'0')}</span>
        <span class="missioncard-copy"><b>${escapeHtml(x.title||generatedMissionTitle(i))}</b><small>${x.portals.length}/${need} · ${formatDistance(missionDistance(x))}</small></span>
        <span class="missioncard-state">${ok?'✓':'!'}</span>
      </button>`;
    }).join('')}</div>`);

  $('.close',sh).onclick=closeSheet;

  $('#bannerDesc',sh).oninput=e=>{
    const value=e.target.value;
    state.planner.description=value;
    state.planner.missions.forEach(x=>{
      if(!x.descriptionCustom)x.description=value;
    });
    scheduleSave();

    const card=$('.requiredFieldCard',sh);
    const valid=!!value.trim();
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{
    state.planner.portalsPerMission=clamp(parseInt(e.target.value)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24);
    scheduleSave();
    openMissionSettings();
  };
  $$('.missioncard-v2',sh).forEach(btn=>btn.onclick=()=>openMissionDetail(+btn.dataset.mi));
}

function openMissionDetail(idx){
  ensurePlannerMissions();state.planner.currentMission=idx;const m=plannerMission(idx);
  const seq=missionSequential(m),hidden=missionHidden(m);
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${idx+1}</h2><p>${m.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(m))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionsetcard missiondetail-v2">
      <div class="field"><label>${tr('title')}</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>${tr('description')}</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="missionSeq"><option value="1" ${seq?'selected':''}>${tr('sequential')}</option><option value="0" ${!seq?'selected':''}>${tr('anyOrder')}</option></select></div>
      <div class="field"><label>${tr('location')}</label><select id="missionHidden" ${!seq?'disabled':''}><option value="0" ${!hidden?'selected':''}>${tr('visible')}</option><option value="1" ${hidden?'selected':''}>${tr('hidden')}</option></select></div></div>
      <div class="missiondetail-actions"><button class="secondary backmissions">‹ ${tr('missions')}</button><button class="primary openRoute">${icon('route')} ${tr('openRoute')}</button></div>
    </div>`);
  $('.close',sh).onclick=closeSheet;
  $('.backmissions',sh).onclick=openMissionSettings;
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('#missionSeq',sh).onchange=e=>{m.sequential=e.target.value==='1';if(!m.sequential)m.hiddenLocation=false;scheduleSave();openMissionDetail(idx)};
  $('#missionHidden',sh).onchange=e=>{m.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('.openRoute',sh).onclick=openRoutePlanner;
}
function missionPublishIssues(index=state.planner.currentMission){
  ensurePlannerMissions();
  const issues=[];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const m=state.planner.missions[clamp(index,0,state.planner.missions.length-1)];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));
  if(!m)return issues;

  if(!String(m.title||'').trim())issues.push(tr('emptyTitleIssue',{n:index+1}));
  if(!String(m.description||'').trim())issues.push(tr('emptyDescIssue',{n:index+1}));
  if((m.portals||[]).length<need){
    issues.push(tr('missionNeedsPortals',{n:index+1,count:(m.portals||[]).length,need}));
  }

  const missing=(m.portals||[]).filter(p=>!p.guid).length;
  if(missing)issues.push(tr('missingGuidIssue',{n:index+1,count:missing}));

  const badPass=(m.portals||[]).filter(p=>
    p.objective?.type==='PASSPHRASE' &&
    (!p.objective?.passphrase_params?.question?.trim() ||
     !p.objective?.passphrase_params?._single_passphrase?.trim())
  ).length;
  if(badPass)issues.push(tr('passIssue',{n:index+1,count:badPass}));

  return issues;
}

function validatePlanner(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const issues=[];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));

  state.planner.missions.forEach((m,i)=>{
    const n=i+1;
    if(!m.title.trim())issues.push(tr('emptyTitleIssue',{n}));
    if(!m.description.trim())issues.push(tr('emptyDescIssue',{n}));
    if(m.portals.length<need)issues.push(tr('portalsIssue',{n,count:m.portals.length,need}));

    const missing=m.portals.filter(p=>!p.guid).length;
    if(missing)issues.push(tr('missingGuidIssue',{n,count:missing}));

    const badPass=m.portals.filter(p=>
      p.objective?.type==='PASSPHRASE' &&
      (!p.objective?.passphrase_params?.question?.trim() ||
       !p.objective?.passphrase_params?._single_passphrase?.trim())
    ).length;
    if(badPass)issues.push(tr('passIssue',{n,count:badPass}));
  });
  return issues;
}

function openBannerDescriptionRequired(onSaved){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('describeBeforePublish')}</h2><p>${tr('describeBeforePublishText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="requiredFieldCard missing">
      <div class="requiredFieldHead"><div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div><strong>!</strong></div>
      <textarea id="requiredBannerDesc" rows="5" autofocus placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
    </div>
    <div class="actions"><button class="primary saveDesc" disabled>${tr('saveAndContinue')}</button></div>`);

  $('.close',sh).onclick=closeSheet;
  const input=$('#requiredBannerDesc',sh);
  const save=$('.saveDesc',sh);

  const update=()=>{
    const valid=!!input.value.trim();
    save.disabled=!valid;
    const card=$('.requiredFieldCard',sh);
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  input.oninput=update;
  update();
  setTimeout(()=>input.focus(),80);

  save.onclick=()=>{
    const value=input.value.trim();
    if(!value)return;
    state.planner.description=value;
    state.planner.missions.forEach(m=>{
      if(!m.descriptionCustom)m.description=value;
    });
    scheduleSave();
    saveProject();
    closeSheet();
    if(typeof onSaved==='function')setTimeout(onSaved,80);
  };
}

function missionPublisherData(m,i,imageDataUrl=''){
  return {
    number:i+1,
    title:m.title||generatedMissionTitle(i),
    description:m.description||'',
    sequential:missionSequential(m),
    hiddenLocation:missionHidden(m),
    imageDataUrl,
    portals:(m.portals||[]).map(p=>({
      guid:p.guid||'',title:p.title||tr('portalDefault'),
      latitude:Number(p.location?.latitude)||0,longitude:Number(p.location?.longitude)||0,
      imageUrl:p.imageUrl||'',description:p.description||'',
      objective:{
        type:p.objective?.type||'HACK_PORTAL',
        question:p.objective?.passphrase_params?.question||'',
        answer:p.objective?.passphrase_params?._single_passphrase||''
      }
    }))
  };
}
async function buildPublisherSession(){
  ensurePlannerMissions();
  if(!state.bg.image)throw new Error(tr('noBackground'));
  const issues=validatePlanner();
  if(issues.length){const e=new Error(issues.join('\n'));e.rblBlockingIssues=issues;throw e}
  const total=state.planner.missions.length;
  const missions=[];
  for(let index=0;index<total;index++){
    toast(tr('publisherSessionCreating',{n:index+1,total}));
    const {row,col}=rowColForMission(index+1),c=document.createElement('canvas');
    c.width=c.height=512;drawTile(c,row,col,512);
    const imageDataUrl=c.toDataURL('image/jpeg',.90);
    missions.push(missionPublisherData(state.planner.missions[index],index,imageDataUrl));
    if(index%2===1)await tick();
  }
  return {
    format:'redacted-bannerlab-publisher-session',version:2,appVersion:APP_VERSION,
    sessionId:`${state.projectId||'project'}-${Date.now()}`,
    projectId:state.projectId||'',name:state.name,language:projectLanguage(),
    portalsPerMission:Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission),
    currentIndex:0,missions
  };
}

async function savePublisherSessionFile(){
  const session=await buildPublisherSession();
  const currentName='RBL_Current_Session.rblpub.json';
  const projectName=`RBL_${safeName(state.name)}.rblpub.json`;
  const text=JSON.stringify(session);

  if(Capacitor.isNativePlatform()){
    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    // Stable filename: Chrome can remember this exact file handle and RBL
    // simply overwrites its contents when another project is prepared.
    await Filesystem.writeFile({
      path:`${folder}/${currentName}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    // Human-readable project copy, useful for manual loading/recovery.
    if(projectName!==currentName){
      await Filesystem.writeFile({
        path:`${folder}/${projectName}`,
        data:text,
        directory:Directory.Documents,
        encoding:Encoding.UTF8
      }).catch(e=>console.warn('[Publisher project copy]',e));
    }
  }else{
    downloadBlob(new Blob([text],{type:'application/json'}),projectName);
  }

  toast(tr('publisherSessionReady'));
  return {session,currentName,projectName};
}

const PUBLISH_BROWSER_KEY='rblPublisherBrowser';
const CHROME_READY_KEY='rblPublisherChromeReady';
const FIREFOX_READY_KEY='rblPublisherFirefoxReady';
const CHROME_STEP_KEY='rblPublisherChromeStep';
const CHROME_CODE_KEY='rblPublisherChromeCodeCopied';
const PUBLISHER_SETUP_VERSION='0.10.7';
const CHROME_SETUP_VERSION_KEY='rblPublisherChromeSetupVersion';
const FIREFOX_SETUP_VERSION_KEY='rblPublisherFirefoxSetupVersion';

function publisherBrowser(){
  return localStorage.getItem(PUBLISH_BROWSER_KEY)||'chrome';
}
function setPublisherBrowser(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  localStorage.setItem(PUBLISH_BROWSER_KEY,browser);
  toast(tr('browserSaved',{browser:browser==='firefox'?tr('firefoxMode'):tr('chromeMode')}));
}
function publisherReady(browser){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  return localStorage.getItem(readyKey)==='1'
    && localStorage.getItem(versionKey)===PUBLISHER_SETUP_VERSION;
}
function setPublisherReady(browser,value=true){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  localStorage.setItem(readyKey,value?'1':'0');
  if(value)localStorage.setItem(versionKey,PUBLISHER_SETUP_VERSION);
  else localStorage.removeItem(versionKey);
  if(browser==='chrome'&&value)localStorage.setItem(CHROME_STEP_KEY,'4');
}
function chromeSetupStep(){
  if(publisherReady('chrome'))return 4;
  if(localStorage.getItem(CHROME_SETUP_VERSION_KEY)!==PUBLISHER_SETUP_VERSION){
    localStorage.setItem(CHROME_STEP_KEY,'1');
    localStorage.removeItem(CHROME_CODE_KEY);
  }
  return clamp(parseInt(localStorage.getItem(CHROME_STEP_KEY))||1,1,3);
}
function setChromeSetupStep(step){
  step=clamp(parseInt(step)||1,1,4);
  localStorage.setItem(CHROME_STEP_KEY,String(step));
}
function resetChromeSetup(){
  setPublisherReady('chrome',false);
  localStorage.setItem(CHROME_STEP_KEY,'1');
  localStorage.removeItem(CHROME_CODE_KEY);
  toast(tr('chromeResetDone'));
}

async function prepareAndOpenPublisher(browser=publisherBrowser()){
  if(!Capacitor.isNativePlatform()){toast(tr('liveNativeOnly'));return}
  try{
    if(!publisherReady(browser)){
      if(browser==='firefox')openFirefoxSetupSheet();else openChromeSetupSheet();
      toast(browser==='firefox'?tr('firefoxNeedsSetup'):tr('chromeNeedsSetup'));
      return;
    }

    await saveProject();

    // Keep the stable JS file current without changing the bookmark.
    if(browser==='chrome'){
      await saveChromePublisherDirect().catch(e=>console.warn('[Publisher JS refresh]',e));
    }

    await savePublisherSessionFile();

    const packageName=browser==='firefox'?'org.mozilla.firefox':'com.android.chrome';
    const url='https://missions.ingress.com/';

    toast(tr('browserResume'));
    toast(browser==='chrome'?tr('chromeResumeHint'):tr('firefoxResumeHint'));

    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:url,
        packageName,
        // Browser.EXTRA_APPLICATION_ID:
        // Android/Chrome will associate this external-app id with a browser
        // tab and attempt to reuse that same tab on later launches.
        extra:{
          'com.android.browser.application_id':'com.bannerforge.mobile'
        },
        // Intent.FLAG_ACTIVITY_NEW_TASK
        flags:268435456
      });
    }catch(e){
      console.warn('[Publisher app-tab launch]',e);
      toast(tr('browserResumeFallback'));
      try{
        await IntentLauncher.openApplication({packageName});
      }catch(e2){
        await AppLauncher.openUrl({url});
      }
    }
  }catch(e){
    console.error('[Publisher session]',e);
    if(e?.rblBlockingIssues){openPublishSheet();return}
    toast(tr('browserFailed',{error:e?.message||e}));
  }
}
async function openChromePublisher(){return prepareAndOpenPublisher('chrome')}
async function openFirefoxPublisher(){return prepareAndOpenPublisher('firefox')}
async function openBrowserPublisher(){return prepareAndOpenPublisher(publisherBrowser())}

async function saveChromePublisherDirect(){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(!Capacitor.isNativePlatform()){
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
      return true;
    }

    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    await Filesystem.writeFile({
      path:`${folder}/${name}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    toast(tr('chromeFileSaved'));
    return true;
  }catch(e){
    console.error('[Chrome Publisher direct write]',e);
    toast(tr('chromeFileWriteFail'));
    return false;
  }
}

async function shareBrowserPublisher(forChrome=false){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({
        path:`RedactedBannerLab/${name}`,
        data:text,
        directory:Directory.Cache,
        encoding:Encoding.UTF8
      });
      const uri=await Filesystem.getUri({
        path:`RedactedBannerLab/${name}`,
        directory:Directory.Cache
      });
      await Share.share({
        title:'Redacted BannerLab Publisher 0.4.0',
        text:forChrome?tr('chromeFileShareText'):tr('browserShareText'),
        url:uri.uri,
        dialogTitle:forChrome?tr('chromeFileShareDialog'):tr('browserShareDialog')
      });
    }else{
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
    }
    return true;
  }catch(e){
    console.error('[Browser Publisher share]',e);
    toast(forChrome?tr('chromeFileShareFail'):tr('browserShareFailed'));
    return false;
  }
}

async function chromeBookmarkletText(){
  const r=await fetch('/redacted-bannerlab-chrome-bookmarklet.txt');
  if(!r.ok)throw new Error('bookmarklet '+r.status);
  return r.text();
}

async function copyChromeBookmarklet(){
  const code=await chromeBookmarkletText();
  try{
    await navigator.clipboard.writeText(code);
    localStorage.setItem(CHROME_CODE_KEY,'1');
    toast(tr('miniCodeCopied'));
    return true;
  }catch(e){
    console.warn('[Chrome bookmarklet clipboard]',e);
    return false;
  }
}

async function openChromeSetupPage(test=false){
  const url=test
    ?'https://missions.ingress.com/#rblsetup=chrome&rblpick=1'
    :'https://missions.ingress.com/';
  try{
    await IntentLauncher.startActivityAsync({
      action:ActivityAction.VIEW,
      data:url,
      packageName:'com.android.chrome'
    });
    if(test)toast(tr('chromeTestWaiting'));
  }catch(e){
    toast(tr('chromeOpenFail'));
    await AppLauncher.openUrl({url});
  }
}

async function openChromeSetupSheet(step=chromeSetupStep()){
  step=publisherReady('chrome')?4:clamp(parseInt(step)||1,1,3);
  setChromeSetupStep(step);
  const code=await chromeBookmarkletText().catch(()=> '');
  const codeCopied=localStorage.getItem(CHROME_CODE_KEY)==='1';

  let body='';
  if(step===1){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">📄</div>
      <h3>${tr('chromeFileTitle')}</h3>
      <p>${tr('chromeFileText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromeFilePath')}</span></div>
      <button class="primary savepub">${tr('chromeSaveFile')}</button>
      <button class="secondary alreadysaved">${tr('alreadySaved')}</button>
    </div>`;
  }else if(step===2){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">⭐</div>
      <h3>${tr('chromeBookmarkTitle')}</h3>
      <p>${tr('chromeBookmarkText',{n:code.length})}</p>
      <div class="chromeCodeMeta"><b>${tr('chromeBookmarkName')}</b><span>${tr('codeLength',{n:code.length})}</span></div>
      <textarea class="bookmarkcode" readonly>${escapeHtml(code)}</textarea>
      <button class="primary copybookmark">${codeCopied?'✓ ':''}${tr('copyMiniCode')}</button>
      <button class="secondary openchrome">${tr('openChromeBookmark')}</button>
      <div class="rule warning"><span class="dot"></span><span>${tr('chromeNotAutoFavorite')}</span></div>
      <p class="chromeWizardHelp">${tr('chromeBookmarkHow')}</p>
      <button class="secondary bookmarkdone">${tr('bookmarkCreated')}</button>
    </div>`;
  }else if(step===3){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">✅</div>
      <h3>${tr('chromeTestTitle')}</h3>
      <p>${tr('chromeTestText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromePermissionHint')}<br>${tr('chromeSelectFileHint')}<br>${tr('chromeCurrentSessionHint')}</span></div>
      <button class="primary testchrome">${tr('chromeTestButton')}</button>
      <p class="chromeWizardHelp">${tr('chromeTestWaiting')}</p>
    </div>`;
  }else{
    body=`<div class="chromeWizardCard success">
      <div class="chromeWizardIcon">✓</div>
      <h3>${tr('chromeSetupSuccess')}</h3>
      <p>${tr('chromeSetupSuccessText')}</p>
      <button class="primary publishnow">${tr('publishNow')}</button>
    </div>`;
  }

  const dots=[1,2,3].map(n=>`<span class="${step===n?'active':step>n?'done':''}">${step>n?'✓':n}</span>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('chromeWizardTitle')}</h2><p>${step<=3?tr('stepOf',{n:step}):tr('chromeSetupSuccess')} · ${tr('chromeWizardIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="chromeWizardProgress">${dots}</div>
    ${body}
    <div class="chromeWizardNav">
      ${step>1&&step<=3?`<button class="secondary wizardprev">← ${tr('wizardPrev')}</button>`:''}
      ${step<3?`<button class="secondary wizardnext">${tr('wizardNext')} →</button>`:''}
    </div>
    <button class="chromeRestart">${tr('wizardRestart')}</button>`);

  $('.close',sh).onclick=closeSheet;
  $('.wizardprev',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step-1)});
  $('.wizardnext',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step+1)});

  $('.savepub',sh)?.addEventListener('click',async()=>{
    const ok=await saveChromePublisherDirect();
    if(ok){
      setChromeSetupStep(2);
      closeSheet();
      openChromeSetupSheet(2);
    }
  });
  $('.alreadysaved',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(2);closeSheet();openChromeSetupSheet(2);
  });

  $('.copybookmark',sh)?.addEventListener('click',async()=>{
    if(await copyChromeBookmarklet()){
      closeSheet();openChromeSetupSheet(2);
    }else toast(tr('bookmarkletCopyFail'));
  });
  $('.openchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(false));
  $('.bookmarkdone',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(3);closeSheet();openChromeSetupSheet(3);
  });

  $('.testchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(true));
  $('.publishnow',sh)?.addEventListener('click',()=>{
    closeSheet();openChromePublisher(state.planner.currentMission);
  });

  $('.chromeRestart',sh).onclick=()=>{
    resetChromeSetup();
    closeSheet();
    openChromeSetupSheet(1);
  };
}

function openFirefoxSetupSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('firefoxSetupTitle')}</h2><p>${tr('firefoxSetupIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="actions"><button class="primary sharepublisher">${tr('sharePublisher')}</button></div>
    <div class="actions"><button class="secondary testfirefox">${tr('testFirefox')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.sharepublisher',sh).onclick=()=>shareBrowserPublisher(false);
  $('.testfirefox',sh).onclick=async()=>{
    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:'https://missions.ingress.com/#rblsetup=firefox',
        packageName:'org.mozilla.firefox'
      });
    }catch(e){
      toast(tr('publisherNoFirefox'));
    }
  };
}

function openPublishSheet(){
  ensurePlannerMissions();
  if(!state.planner.description.trim()){openBannerDescriptionRequired(openPublishSheet);return}

  const issues=validatePlanner();
  const current=state.planner.currentMission;
  const currentIssues=missionPublishIssues(current);
  const m=state.planner.missions[current];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(x=>x.portals.length>=need && String(x.description||'').trim()).length;
  const total=state.planner.missions.length;
  const mode=publisherBrowser();
  const chromeReady=publisherReady('chrome'),firefoxReady=publisherReady('firefox');
  const blocked=issues.length>0;

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('publish')}</h2><p>${complete}/${total} · ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishMissionGate ${blocked?'blocked':'ready'}">
      <div class="publishMissionGateHead"><span class="missioncard-num">${String(current+1).padStart(2,'0')}</span><div><b>${escapeHtml(m?.title||generatedMissionTitle(current))}</b><small>${m?.portals?.length||0}/${need} · ${tr('bannerDescription')} ✓</small></div><strong>${blocked?'!':'✓'}</strong></div>
      ${blocked?`<div class="publishBlockingList">${issues.slice(0,12).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}</div><div class="actions"><button class="primary completemission">${icon('route')} ${tr('completeMission')}</button></div>`:`<div class="publishReadyText">${tr('publisherWholeHint')}<small>${tr('publisherCurrentFile')}</small></div>`}
    </div>
    ${blocked?`<div class="publishscore warn"><b>${tr('reviewCount',{n:issues.length})}</b><span>${tr('publisherAllRequired')}</span></div>`:''}
    <div class="field"><label>${tr('publisherBrowser')}</label><div class="publisherchoices">
      <button class="publisherchoice chrome ${mode==='chrome'?'selected':''}" data-mode="chrome"><span class="browsericon">🌐</span><span><b>${tr('chromeMode')}</b><small>${tr('chromeModeSub')}</small><em>${chromeReady?'✓ '+tr('chromeReady'):tr('noExtraApp')}</em></span></button>
      <button class="publisherchoice firefox ${mode==='firefox'?'selected':''}" data-mode="firefox"><span class="browsericon">🦊</span><span><b>${tr('firefoxMode')}</b><small>${tr('firefoxModeSub')}</small><em>${firefoxReady?'✓ '+tr('firefoxReady'):tr('recommendedAuto')}</em></span></button>
    </div></div>
    <div class="actions"><button class="primary livepublisher" ${blocked?'disabled':''}>🚀 ${tr('publisherWholeBanner')}</button></div>
    <div class="actions"><button class="secondary setupselected">${mode==='firefox'?tr('firefoxSetup'):tr('chromeSetup')}</button></div>
    <details class="missionCommon"><summary>${tr('backupTransfer')}</summary><div class="missionCommonBody"><div class="actions"><button class="secondary exportpack">${icon('download')} ${tr('exportPackBackup')}</button></div><div class="actions"><button class="secondary openmat">${icon('globe')} ${tr('openOfficialOnly')}</button></div></div></details>`);
  $('.close',sh).onclick=closeSheet;
  $('.completemission',sh)?.addEventListener('click',()=>{closeSheet();state.planner.currentMission=current;scheduleSave();openRoutePlanner()});
  $$('.publisherchoice',sh).forEach(btn=>btn.onclick=()=>{setPublisherBrowser(btn.dataset.mode);closeSheet();openPublishSheet()});
  $('.livepublisher',sh).onclick=()=>openBrowserPublisher();
  $('.setupselected',sh).onclick=()=>publisherBrowser()==='firefox'?openFirefoxSetupSheet():openChromeSetupSheet();
  $('.exportpack',sh).onclick=exportBannerLabPack;$('.openmat',sh).onclick=openMissionAuthoring;
}

async function exportBannerLabPack(){
  ensurePlannerMissions();
  const zip=new JSZip(),imgFolder=zip.folder('missions');
  const manifest={
    format:'redacted-bannerlab',version:1,appVersion:APP_VERSION,name:state.name,
    language:projectLanguage(),portalsPerMission:state.planner.portalsPerMission,
    missions:state.planner.missions.map((m,i)=>({
      number:i+1,title:m.title,description:m.description,sequential:missionSequential(m),hiddenLocation:missionHidden(m),
      image:`missions/${String(i+1).padStart(3,'0')}.jpg`,
      portals:(m.portals||[]).map(p=>({
        guid:p.guid,title:p.title,latitude:p.location.latitude,longitude:p.location.longitude,imageUrl:p.imageUrl||'',
        objective:{type:p.objective?.type||'HACK_PORTAL',question:p.objective?.passphrase_params?.question||'',answer:p.objective?.passphrase_params?._single_passphrase||''}
      }))
    }))
  };
  try{
    toast(tr('packCreating'));
    for(let n=1;n<=manifest.missions.length;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      imgFolder.file(`${String(n).padStart(3,'0')}.jpg`,await canvasBlob(c,'image/jpeg',.94));
      if(n%4===0)await tick();
    }
    zip.file('missions.json',JSON.stringify(manifest,null,2));
    const name=`${safeName(state.name)}_BannerLab.zip`;
    if(Capacitor.isNativePlatform()){
      const b64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true});
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:b64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:`${manifest.missions.length} missions · ${state.name}`,url:uri.uri,dialogTitle:name});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
      downloadBlob(blob,name);
    }
    toast(tr('packCreated'));
  }catch(e){console.error(e);toast(tr('exportImpossible',{error:e?.message||e}))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function backupAutoEnabled(){return localStorage.getItem(BACKUP_AUTO_KEY)==='1'}
function setBackupAutoEnabled(value){localStorage.setItem(BACKUP_AUTO_KEY,value?'1':'0');if(value)queueForegroundAutoBackup(250);else{clearTimeout(backupAutoTimer);backupAutoTimer=null}}
function markBackupChanged(){backupRevision++;queueForegroundAutoBackup()}
function queueForegroundAutoBackup(delay=1800){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||!backupAppActive)return;
  // Throttle volontairement au lieu de repousser le timer à chaque mouvement :
  // une longue session d'édition produit ainsi régulièrement un snapshot complet
  // pendant que le WebView est encore actif.
  if(backupAutoTimer)return;
  backupAutoTimer=setTimeout(async()=>{
    backupAutoTimer=null;
    if(!backupAutoEnabled())return;
    await autoBackupIfNeeded('foreground');
    // Si des modifications sont arrivées pendant la création du JSON, on repasse.
    if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(2200);
  },Math.max(0,delay));
}
function backupDateText(value){
  if(!value)return tr('backupNever');
  try{return tr('backupLast',{date:new Date(value).toLocaleString(APP_LANG==='fr'?'fr-FR':APP_LANG==='es'?'es-ES':'en-GB',{dateStyle:'short',timeStyle:'short'})})}catch{return tr('backupNever')}
}
async function blobToBackupMedia(blob){
  if(!blob)return null;
  const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return {mime:blob.type||'application/octet-stream',name:blob.name||'',base64:btoa(binary)};
}
function backupMediaToBlob(media){
  if(!media?.base64)return null;
  const bin=atob(media.base64),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  try{return media.name?new File([bytes],media.name,{type:media.mime||'application/octet-stream'}):new Blob([bytes],{type:media.mime||'application/octet-stream'})}catch{return new Blob([bytes],{type:media.mime||'application/octet-stream'})}
}
function portableLocalSettings(){
  const keys=[BANNER_FAVORITES_KEY,BANNER_TODO_KEY,PLAY_HISTORY_KEY,BANNER_SEARCH_PREFS_KEY,PLAY_SESSION_KEY,'rbl-language'];
  const out={};for(const k of keys){const v=localStorage.getItem(k);if(v!==null)out[k]=v}return out;
}
async function buildFullBackup(){
  await saveProject({markBackup:false});
  const rows=await getAllProjects(),projects=[];
  for(const rec of rows){
    const background=await blobToBackupMedia(rec.blob);
    const layerBlobs=[];
    for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
    projects.push({id:rec.id,data:rec.data||{},background,layerBlobs});
    await tick();
  }
  return {format:'redacted-bannerlab-backup',schemaVersion:1,appVersion:APP_VERSION,createdAt:new Date().toISOString(),currentProjectId:localStorage.getItem('redactedBannerLabCurrentProjectId')||state.projectId||'',language:APP_LANG,settings:portableLocalSettings(),projects};
}
async function fullBackupJson(){return JSON.stringify(await buildFullBackup())}
function safeProjectFilename(name='Redacted_BannerLab'){
  const clean=String(name||'Redacted_BannerLab').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,72);
  return clean||'Redacted_BannerLab';
}
async function projectRecordById(id){
  if(id===state.projectId)await saveProject({markBackup:false});
  const db=await openDB(),tx=db.transaction('project','readonly');
  return await request(tx.objectStore('project').get(id));
}
async function buildPortableProject(id=state.projectId){
  const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
  const background=await blobToBackupMedia(rec.blob),layerBlobs=[];
  for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
  return {
    format:'redacted-bannerlab-project',schemaVersion:1,appVersion:APP_VERSION,exportedAt:new Date().toISOString(),
    originalProjectId:String(rec.id||''),
    project:{data:rec.data,background,layerBlobs},
    capabilities:{images:true,customFonts:true,planner:true,routeFromPortalCoordinates:true}
  };
}
async function portableProjectJson(id=state.projectId){return JSON.stringify(await buildPortableProject(id),null,2)}
function validatePortableProject(x){return !!(x&&x.format==='redacted-bannerlab-project'&&Number(x.schemaVersion)>=1&&x.project?.data)}
async function deliverPortableProject(id,{share=false}={}){
  try{
    toast(tr('projectExporting'));
    const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
    const text=await portableProjectJson(id),name=`Redacted_BannerLab_${safeProjectFilename(rec.data.name)}.rbl.json`;
    if(Capacitor.isNativePlatform()){
      if(share){
        // Partager garde la feuille de partage Android.
        await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
        await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
        const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
        await Share.share({title:tr('projectShareTitle'),text:rec.data.name||tr('projectShareTitle'),url:uri.uri,dialogTitle:tr('shareProject')});
      }else{
        // Exporter ouvre le sélecteur Android ACTION_CREATE_DOCUMENT :
        // l'utilisateur choisit réellement le dossier et peut modifier le nom.
        const result=await BackupFolder.saveTextFileAs({fileName:name,text,mimeType:'application/json'});
        if(result?.cancelled)return;
        if(!result?.saved)throw new Error('Unable to save project');
      }
    }else{
      downloadBlob(new Blob([text],{type:'application/json'}),name);
    }
    toast(share?tr('projectShared'):tr('projectExported'));
  }catch(e){console.error('portable project',e);toast(tr('backupFailed',{error:e?.message||e}))}
}
async function restorePortableProject(payload){
  if(!validatePortableProject(payload)){toast(tr('projectImportInvalid'));return false}
  try{
    const src=payload.project,data=JSON.parse(JSON.stringify(src.data||{})),blob=backupMediaToBlob(src.background),layerBlobs=[];
    for(const x of (src.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    data.updatedAt=new Date().toISOString();
    const id=newProjectId(),db=await openDB(),tx=db.transaction('project','readwrite');
    tx.objectStore('project').put({id,data,blob,layerBlobs});await txDone(tx);
    markBackupChanged();await loadProject(id);resetHistory();closeSheet();toast(tr('projectImportSuccess'));return true;
  }catch(e){console.error('project import',e);toast(tr('projectImportInvalid'));return false}
}
function importPortableProject(){
  const input=document.createElement('input');input.type='file';input.accept='.json,.rbl.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());await restorePortableProject(payload)}catch(e){console.warn(e);toast(tr('projectImportInvalid'))}finally{input.remove()}};
  input.click();
}

async function backupFolderInfo(){
  if(!Capacitor.isNativePlatform())return {configured:false,label:''};
  try{return await BackupFolder.getFolder()}catch(e){console.warn('backup folder',e);return {configured:false,label:''}}
}
async function chooseBackupFolder(){
  if(!Capacitor.isNativePlatform()){toast(tr('backupNativeOnly'));return null}
  try{const r=await BackupFolder.chooseFolder();if(r?.configured){toast(tr('backupFolderChosen'));return r}}catch(e){console.warn(e);toast(tr('backupFolderError'))}return null;
}
function refreshBackupLastStatus(when=localStorage.getItem(BACKUP_LAST_KEY)){
  $$('.backupLastStatus').forEach(el=>{el.textContent=backupDateText(when)});
}
async function writeBackupToFolder({automatic=false,force=false}={}){
  if(backupInProgress)return false;
  if(automatic&&!force&&lastBackedRevision===backupRevision)return false;
  const folder=await backupFolderInfo();if(!folder?.configured){if(!automatic)toast(tr('backupNeedFolder'));return false}
  const targetRevision=backupRevision;
  backupInProgress=true;
  try{
    if(!automatic)toast(tr('backupWorking'));
    const text=await fullBackupJson();
    await BackupFolder.writeTextFile({fileName:BACKUP_FILE_NAME,text});
    const when=new Date().toISOString();localStorage.setItem(BACKUP_LAST_KEY,when);lastBackedRevision=Math.max(lastBackedRevision,targetRevision);refreshBackupLastStatus(when);
    // Pas de toast pour les sauvegardes automatiques de premier plan : elles peuvent
    // arriver régulièrement et ne doivent pas interrompre l'édition.
    if(!automatic)toast(tr('backupSaved'));
    return true;
  }catch(e){console.error('backup',e);if(!automatic)toast(tr('backupFailed',{error:e?.message||e}));return false}
  finally{backupInProgress=false;if(backupAppActive&&backupAutoEnabled()&&lastBackedRevision!==backupRevision)queueForegroundAutoBackup(1200)}
}
async function exportFullBackupJson(){
  if(backupInProgress)return;backupInProgress=true;
  try{
    toast(tr('backupWorking'));const text=await fullBackupJson();const name=`Redacted_BannerLab_Backup_${new Date().toISOString().slice(0,19).replaceAll(':','-')}.json`;
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:tr('backupTitle'),url:uri.uri,dialogTitle:name});
    }else downloadBlob(new Blob([text],{type:'application/json'}),name);
    toast(tr('backupSaved'));
  }catch(e){console.error(e);toast(tr('backupFailed',{error:e?.message||e}))}finally{backupInProgress=false}
}
function validateBackupPayload(x){return !!(x&&x.format==='redacted-bannerlab-backup'&&Number(x.schemaVersion)>=1&&Array.isArray(x.projects))}
async function restoreFullBackup(payload,{replace=false}={}){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return false}
  const prepared=[];
  for(const rec of payload.projects){
    if(!rec?.id||!rec?.data)continue;
    const blob=backupMediaToBlob(rec.background),layerBlobs=[];
    for(const x of (rec.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    prepared.push({id:String(rec.id),data:rec.data,blob,layerBlobs});await tick();
  }
  if(!prepared.length){toast(tr('backupInvalid'));return false}
  const db=await openDB();const tx=db.transaction('project','readwrite'),store=tx.objectStore('project');if(replace)store.clear();for(const rec of prepared)store.put(rec);await txDone(tx);
  if(payload.settings&&typeof payload.settings==='object')for(const [k,v] of Object.entries(payload.settings))if(typeof v==='string'&&k!==BACKUP_AUTO_KEY&&k!==BACKUP_LAST_KEY)localStorage.setItem(k,v);
  if(SUPPORTED_LANGS.includes(payload.language))localStorage.setItem('rbl-language',payload.language);
  const target=prepared.some(x=>x.id===payload.currentProjectId)?payload.currentProjectId:prepared[0].id;localStorage.setItem('redactedBannerLabCurrentProjectId',target);
  localStorage.setItem('redactedBannerLabMigrationDone','1');markBackupChanged();toast(tr('backupImported'));setTimeout(()=>location.reload(),450);return true;
}
function confirmBackupImport(payload){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return}
  const date=(()=>{try{return new Date(payload.createdAt).toLocaleString(APP_LANG==='fr'?'fr-FR':APP_LANG==='es'?'es-ES':'en-GB')}catch{return payload.createdAt||'—'}})();
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('backupImportTitle')}</h2><p>${tr('backupImportText',{n:payload.projects.length,date})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('backupReplaceWarn')}</span></div><div class="actions"><button class="secondary mergeBackup">${tr('backupMerge')}</button><button class="danger replaceBackup">${tr('backupReplace')}</button></div>`);
  $('.close',sh).onclick=()=>openInfoSheet();$('.mergeBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:false});$('.replaceBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:true});
}
function importFullBackupJson(){
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());confirmBackupImport(payload)}catch(e){console.warn(e);toast(tr('backupInvalid'))}finally{input.remove()}};input.click();
}
async function autoBackupIfNeeded(reason='background'){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||backupInProgress||lastBackedRevision===backupRevision)return false;
  try{
    // Sauvegarde d'abord le projet courant dans IndexedDB, puis construit le JSON.
    await saveProject({markBackup:false});
    return await writeBackupToFolder({automatic:true});
  }catch(e){console.warn('auto backup '+reason,e);return false}
}
function autoBackupOnBackground(reason='background'){
  backupAppActive=false;
  clearTimeout(backupAutoTimer);backupAutoTimer=null;
  // On lance immédiatement le flush. En parallèle, les snapshots réguliers faits
  // au premier plan évitent de dépendre de ce court créneau avant suspension Android.
  void autoBackupIfNeeded(reason);
}
function autoBackupOnForeground(){backupAppActive=true;if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(500)}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('settingsInfo')}</h2><p>Redacted BannerLab · ${tr('versionLabel')} ${APP_VERSION}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('language')}</label><select id="appLanguage"><option value="fr" ${APP_LANG==='fr'?'selected':''}>🇫🇷 ${tr('french')}</option><option value="en" ${APP_LANG==='en'?'selected':''}>🇬🇧 ${tr('english')}</option><option value="es" ${APP_LANG==='es'?'selected':''}>🇪🇸 ${tr('spanish')}</option></select></div>
    <div class="rulelist">
      <div class="rule"><span class="dot"></span><span><b>Prime</b> · ${tr('infoPrime')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>Mission Planner</b> · ${tr('infoPlanner')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>IITC Companion 0.6.3</b> · ${tr('infoCompanion')}</span></div>
      <div class="rule warning"><span class="dot"></span><span>${tr('disclaimer')}</span></div>
    </div>

    <div class="tutorialHubSection">
      <div class="tutorialHubCard"><div class="tutorialHubHead"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><strong>🎓 ${tr('tutorialHubTitle')}</strong><p>${tr('tutorialHubText')}</p></div></div><button class="primary tutorialHubOpen">${tr('tutorialOpen')}</button></div>
    </div>

    <div class="backupSection">
      <div class="backupCard">
        <div class="backupHead"><span>💾</span><div><strong>${tr('backupTitle')}</strong><p>${tr('backupText')}</p></div></div>
        <div class="backupFolderLine"><div><b>${tr('backupFolder')}</b><small class="backupFolderStatus">${tr('backupFolderNone')}</small></div><button class="secondary chooseBackupFolder">${tr('backupFolderChoose')}</button></div>
        <label class="switchline backupAutoLine"><input type="checkbox" class="backupAutoToggle" ${backupAutoEnabled()?'checked':''} ${Capacitor.isNativePlatform()?'':'disabled'}> ${tr('backupAuto')}</label>
        <small class="backupHint">${tr('backupAutoHint')}</small>
        <div class="backupActions"><button class="primary backupNow" ${Capacitor.isNativePlatform()?'':'disabled'}>💾 ${tr('backupNow')}</button><button class="secondary backupExport">${icon('download')} ${tr('backupExport')}</button><button class="secondary backupImport">${icon('upload')} ${tr('backupImport')}</button></div>
        <small class="backupPortable">${tr('backupPortable')}</small><small class="backupLastStatus">${backupDateText(localStorage.getItem(BACKUP_LAST_KEY))}</small>
      </div>
    </div>

    <div class="creatorCommunity">
      <div class="creatorLine"><span class="creatorMark">R</span><div><strong>${tr('creatorBy')}</strong><small>Redacted BannerLab</small></div></div>
      <div class="communityCard">
        <div class="communityIcon">✈</div><div class="communityCopy"><strong>${tr('communityTitle')}</strong><p>${tr('communityText')}</p></div>
      </div>
      <div class="reportCard">
        <div><strong>🐛 ${tr('reportProblem')}</strong><p>${tr('reportProblemText')}</p></div>
        <div class="reportActions"><button class="secondary copyDiagnostic">${tr('copyDiagnostic')}</button><button class="primary reportTelegram">${tr('telegramOpen')}</button></div>
      </div>
    </div>


    <div class="creditSection">
      <div class="creditHeading">♥ ${tr('creditsTitle')}</div>
      <div class="creditCard bannergressCredit">
        <strong>${tr('bannergressThanks')}</strong>
        <p>${tr('bannergressThanksText')}</p>
        <p>${tr('bannergressNoLogin')}</p>
        <small>${tr('independentProject')}</small>
        <button class="secondary infoBannergress">↗ ${tr('visitBannergress')}</button>
      </div>
      <div class="creditCard">
        <strong>${tr('mapCredits')}</strong>
        <p>${tr('mapCreditsText')}</p>
      </div>
      <div class="creditFoot">${tr('rblCreditsFoot')}</div>
    </div>

    <div class="actions"><button class="secondary" id="manageProjects">${icon('folder')} ${tr('projects')}</button><button class="primary" id="newProject">${icon('plus')} ${tr('newProject')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#appLanguage',sh).onchange=e=>setAppLanguage(e.target.value);
  $('#manageProjects',sh).onclick=openProjectsSheet;
  $('#newProject',sh).onclick=()=>createNewProject();
  $('.tutorialHubOpen',sh).onclick=openTutorialHubSheet;
  const refreshBackupFolder=async()=>{
    const info=await backupFolderInfo(),status=$('.backupFolderStatus',sh),btn=$('.chooseBackupFolder',sh),now=$('.backupNow',sh);
    if(status)status.textContent=info?.configured?(info.label||tr('backupFolderReady')):tr('backupFolderNone');
    if(btn){btn.textContent=info?.configured?tr('backupFolderChange'):tr('backupFolderChoose');btn.disabled=!Capacitor.isNativePlatform()}
    if(now)now.disabled=!Capacitor.isNativePlatform()||!info?.configured;
  };
  refreshBackupFolder();
  $('.chooseBackupFolder',sh).onclick=async()=>{const r=await chooseBackupFolder();if(r){markBackupChanged();await refreshBackupFolder()}};
  $('.backupAutoToggle',sh).onchange=async e=>{if(e.target.checked){const info=await backupFolderInfo();if(!info?.configured){const r=await chooseBackupFolder();if(!r){e.target.checked=false;return}await refreshBackupFolder()}}setBackupAutoEnabled(e.target.checked)};
  $('.backupNow',sh).onclick=async()=>{await writeBackupToFolder({force:true});$('.backupLastStatus',sh).textContent=backupDateText(localStorage.getItem(BACKUP_LAST_KEY))};
  $('.backupExport',sh).onclick=exportFullBackupJson;
  $('.backupImport',sh).onclick=importFullBackupJson;
  $('.infoBannergress',sh).onclick=()=>{
    const url='https://bannergress.com/';
    if(Capacitor.isNativePlatform())AppLauncher.openUrl({url}).catch(()=>{});
    else window.open(url,'_blank','noopener');
  };
  const openTelegram=()=>{
    const url='https://t.me/redactedbannerlabbot';
    if(Capacitor.isNativePlatform())AppLauncher.openUrl({url}).catch(()=>{});
    else window.open(url,'_blank','noopener');
  };
  $('.reportTelegram',sh).onclick=openTelegram;
  $('.copyDiagnostic',sh).onclick=async()=>{
    const android=(navigator.userAgent.match(/Android\s+([0-9.]+)/i)||[])[1];
    const platform=Capacitor.getPlatform?Capacitor.getPlatform():(Capacitor.isNativePlatform()?'android':'web');
    const diagnostic=`Redacted BannerLab v${APP_VERSION}\nPlateforme : ${platform}${android?` · Android ${android}`:''}\nLangue : ${APP_LANG.toUpperCase()}\nIITC Companion : 0.6.3\n\n${tr('diagnosticDescription')}\n`;
    if(await copyText(diagnostic))toast(tr('diagnosticCopied'));else toast(tr('diagnosticCopyFailed'));
  };
}

/* =========================================================
   v1.0.7 — tutoriels guidés contextuels
========================================================= */
let tutorialSession=null;
let tutorialOverlay=null;
let tutorialResizeHandler=null;

function tutorialCatalog(){
  return {
    quick:{icon:'🚀',title:tr('tutorialQuick'),desc:tr('tutorialQuickDesc'),steps:[
      {prepare:'home',target:'#projectsBtn',title:tr('tutProjectTitle'),text:tr('tutProjectText')},
      {prepare:'home',target:'.tool[data-tool="image"]',title:tr('tutImageTitle'),text:tr('tutImageText')},
      {prepare:'home',target:'#rowsSelect',title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'home',target:'#openStudioEditorBtn',title:tr('tutStudioTitle'),text:tr('tutStudioText')},
      {prepare:'home',target:'[data-flow="route"]',title:tr('tutFlowTitle'),text:tr('tutFlowText')},
      {prepare:'home',target:'#infoBtn',title:tr('tutInfoTitle'),text:tr('tutInfoText')},
      {prepare:'info',target:'.reportCard',title:tr('tutSupportTitle'),text:tr('tutSupportText')}
    ]},
    banner:{icon:'🖼',title:tr('tutorialBanner'),desc:tr('tutorialBannerDesc'),steps:[
      {prepare:'home',target:'#projectName',title:tr('tutNameTitle'),text:tr('tutNameText')},
      {prepare:'home',target:'#rowsSelect',title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'image',target:'.addBackground',title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addMissionLayer',title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.importMissionSeries',title:tr('missionSeriesTitle'),text:tr('missionSeriesText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'home',target:'.tool[data-tool="text"]',title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'home',target:'.tool[data-tool="preview"]',title:tr('tutPreviewTitle'),text:tr('tutPreviewText')},
      {prepare:'home',target:'.tool[data-tool="export"]',title:tr('tutExportTitle'),text:tr('tutExportText')}
    ]},
    layers:{icon:'🎨',title:tr('tutorialLayers'),desc:tr('tutorialLayersDesc'),steps:[
      {prepare:'image',target:'.addBackground',title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addMissionLayer',title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.importMissionSeries',title:tr('missionSeriesTitle'),text:tr('missionSeriesText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'image',target:'.layerGroupBar',title:tr('groupSelection'),text:tr('groupHint')},
      {prepare:'text',target:'#txt',title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'text',target:'.textTypographyCard',title:tr('textTypography'),text:tr('tutTextText')},
      {prepare:'home',target:'#openStudioEditorBtn',title:tr('tutStudioTitle'),text:tr('tutStudioText')}
    ]},
    iitc:{icon:'🗺',title:tr('tutorialIitc'),desc:tr('tutorialIitcDesc'),steps:[
      {prepare:'home',target:'[data-flow="route"]',title:tr('tutRouteTitle'),text:tr('tutRouteText')},
      {prepare:'route',target:'.iitccompanion-head',title:tr('tutCompanionTitle'),text:tr('tutCompanionText')},
      {prepare:'route',target:'.sharebridge',title:tr('tutInstallCompanionTitle'),text:tr('tutInstallCompanionText')},
      {prepare:'route',target:'.openintel',title:tr('tutOpenIitcTitle'),text:tr('tutOpenIitcText')},
      {prepare:'route',target:'.routeoptions',title:tr('tutAutoRouteTitle'),text:tr('tutAutoRouteText')},
      {prepare:'route',target:'.portallist',title:tr('tutPortalListTitle'),text:tr('tutPortalListText')}
    ]},
    publish:{icon:'📤',title:tr('tutorialPublish'),desc:tr('tutorialPublishDesc'),steps:[
      {prepare:'home',target:'[data-flow="missions"]',title:tr('tutMissionsTitle'),text:tr('tutMissionsText')},
      {prepare:'missions',target:'.requiredFieldCard',title:tr('tutMissionDescTitle'),text:tr('tutMissionDescText')},
      {prepare:'missions',target:'.missionlist-v2',title:tr('tutMissionsTitle'),text:tr('tutMissionsText')},
      {prepare:'home',target:'[data-flow="publish"]',title:tr('tutPublishTitle'),text:tr('tutPublishText')},
      {prepare:'home',target:'[data-flow="publish"]',title:tr('tutPublisherExplainTitle'),text:tr('tutPublisherExplainText')}
    ]},
    backup:{icon:'💾',title:tr('tutorialBackup'),desc:tr('tutorialBackupDesc'),steps:[
      {prepare:'home',target:'#infoBtn',title:tr('tutInfoTitle'),text:tr('tutInfoText')},
      {prepare:'info',target:'.backupCard',title:tr('tutBackupTitle'),text:tr('tutBackupText')},
      {prepare:'projects',target:'.portableProjectIntro',title:tr('tutPortableTitle'),text:tr('tutPortableText')},
      {prepare:'info',target:'.reportCard',title:tr('tutSupportTitle'),text:tr('tutSupportText')}
    ]}
  };
}

function openTutorialHubSheet(){
  const catalog=tutorialCatalog();
  const cards=Object.entries(catalog).map(([id,t])=>{
    const seen=localStorage.getItem(TUTORIAL_SEEN_PREFIX+id)==='1';
    return `<button class="tutorialChoice" data-tutorial-id="${escapeAttr(id)}"><span class="tutorialChoiceIcon">${t.icon}</span><span><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.desc)}</small></span>${seen?`<em>✓ ${tr('tutorialSeen')}</em>`:'<i>›</i>'}</button>`;
  }).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>🎓 ${tr('tutorialHubTitle')}</h2><p>${tr('tutorialHubText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="tutorialChoiceList">${cards}</div>`);
  $('.close',sh).onclick=openInfoSheet;
  $$('.tutorialChoice',sh).forEach(btn=>btn.onclick=()=>startTutorial(btn.dataset.tutorialId,{manual:true}));
}

function showFirstTutorialPrompt(){
  sessionStorage.setItem(TUTORIAL_PROMPT_SESSION_KEY,'1');
  const sh=openSheet(`<div class="tutorialWelcome"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><h2>${tr('tutorialWelcomeTitle')}</h2><p>${tr('tutorialWelcomeText')}</p></div></div><div class="tutorialWelcomeActions"><button class="primary tutorialStart">${tr('tutorialStart')}</button><button class="secondary tutorialLater">${tr('tutorialLater')}</button><button class="ghost tutorialNever">${tr('tutorialNever')}</button></div>`);
  $('.tutorialStart',sh).onclick=()=>startTutorial('quick',{manual:false});
  $('.tutorialLater',sh).onclick=closeSheet;
  $('.tutorialNever',sh).onclick=()=>{localStorage.setItem(TUTORIAL_AUTO_KEY,'never');closeSheet()};
}

function maybeShowFirstTutorial(){
  if(localStorage.getItem(TUTORIAL_AUTO_KEY))return;
  if(sessionStorage.getItem(TUTORIAL_PROMPT_SESSION_KEY)==='1')return;
  setTimeout(showFirstTutorialPrompt,450);
}

async function prepareTutorialStep(step){
  const action=step?.prepare||'home';
  if(action==='home'){closeSheet();setFlowStep('fresco',{open:false})}
  else if(action==='image'){setFlowStep('fresco',{open:false});openImageLayersSheet()}
  else if(action==='text'){setFlowStep('fresco',{open:false});openTextSheet()}
  else if(action==='route'){setFlowStep('route')}
  else if(action==='missions'){setFlowStep('missions')}
  else if(action==='info'){openInfoSheet()}
  else if(action==='projects'){openProjectsSheet()}
  await new Promise(r=>setTimeout(r,90));
}

function startTutorial(id,{manual=false}={}){
  const t=tutorialCatalog()[id];if(!t)return;
  closeTutorial({restore:false});
  closeSheet();
  tutorialSession={id,index:0,manual,title:t.title,steps:t.steps};
  void renderTutorialStep();
}

async function renderTutorialStep(){
  if(!tutorialSession)return;
  const step=tutorialSession.steps[tutorialSession.index];if(!step)return;
  await prepareTutorialStep(step);
  if(!tutorialSession)return;
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  tutorialOverlay?.remove();
  const overlay=document.createElement('div');overlay.className='guidedTutorialOverlay';
  overlay.innerHTML=`<div class="guidedTutorialSpotlight"></div><section class="guidedTutorialBubble"><button class="guidedTutorialClose" aria-label="${escapeAttr(tr('tutorialClose'))}">×</button><div class="guidedTutorialRedacted"><img src="/redacted-dino-cutout.png" alt=""><div><small>${escapeHtml(tutorialSession.title)}</small><strong>${escapeHtml(step.title)}</strong></div></div><p>${escapeHtml(step.text)}</p><div class="guidedTutorialProgress"><span>${tutorialSession.index+1} / ${tutorialSession.steps.length}</span><div><i style="width:${Math.round((tutorialSession.index+1)/tutorialSession.steps.length*100)}%"></i></div></div><div class="guidedTutorialActions"><button class="secondary guidedTutorialPrev" ${tutorialSession.index===0?'disabled':''}>‹ ${tr('tutorialPrevious')}</button><button class="primary guidedTutorialNext">${tutorialSession.index===tutorialSession.steps.length-1?tr('tutorialUnderstood'):tr('tutorialNext')+' ›'}</button></div></section>`;
  document.body.appendChild(overlay);tutorialOverlay=overlay;
  $('.guidedTutorialClose',overlay).onclick=()=>closeTutorial();
  $('.guidedTutorialPrev',overlay).onclick=()=>{if(tutorialSession&&tutorialSession.index>0){tutorialSession.index--;void renderTutorialStep()}};
  $('.guidedTutorialNext',overlay).onclick=()=>{if(!tutorialSession)return;if(tutorialSession.index>=tutorialSession.steps.length-1){finishTutorial();return}tutorialSession.index++;void renderTutorialStep()};
  placeTutorialOverlay(step.target);
  tutorialResizeHandler=()=>placeTutorialOverlay(step.target);
  window.addEventListener('resize',tutorialResizeHandler,{passive:true});
}

function placeTutorialOverlay(selector){
  if(!tutorialOverlay)return;
  const spot=$('.guidedTutorialSpotlight',tutorialOverlay),bubble=$('.guidedTutorialBubble',tutorialOverlay);
  let target=null;try{target=selector?$(selector):null}catch{}
  if(target){try{target.scrollIntoView({behavior:'auto',block:'center',inline:'center'})}catch{target.scrollIntoView()}}
  setTimeout(()=>{
    if(!tutorialOverlay)return;
    const vw=window.innerWidth,vh=window.innerHeight,margin=10;
    if(!target||!document.body.contains(target)){
      spot.hidden=true;bubble.classList.add('centered');bubble.style.left='12px';bubble.style.right='12px';bubble.style.top='50%';bubble.style.bottom='auto';return;
    }
    spot.hidden=false;bubble.classList.remove('centered');bubble.style.right='auto';bubble.style.bottom='auto';
    const r=target.getBoundingClientRect(),pad=7;
    spot.style.left=`${Math.max(margin,r.left-pad)}px`;spot.style.top=`${Math.max(margin,r.top-pad)}px`;spot.style.width=`${Math.min(vw-margin, r.right+pad)-Math.max(margin,r.left-pad)}px`;spot.style.height=`${Math.min(vh-margin,r.bottom+pad)-Math.max(margin,r.top-pad)}px`;
    const br=bubble.getBoundingClientRect(),bw=Math.min(br.width,vw-24),bh=br.height;
    let left=Math.max(12,Math.min(vw-bw-12,r.left+(r.width-bw)/2));
    let top=r.bottom+16;
    if(top+bh>vh-12)top=r.top-bh-16;
    if(top<12){top=Math.max(12,(vh-bh)/2);left=r.right+bw+20<vw?r.right+12:Math.max(12,r.left-bw-12)}
    bubble.style.left=`${Math.round(left)}px`;bubble.style.top=`${Math.round(Math.max(12,Math.min(vh-bh-12,top)))}px`;
  },110);
}

function closeTutorial({restore=true}={}){
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  tutorialOverlay?.remove();tutorialOverlay=null;
  if(restore&&tutorialSession){closeSheet();setFlowStep('fresco',{open:false})}
  tutorialSession=null;
}

function finishTutorial(){
  if(!tutorialSession)return;
  const id=tutorialSession.id,manual=tutorialSession.manual;
  localStorage.setItem(TUTORIAL_SEEN_PREFIX+id,'1');
  if(!manual)localStorage.setItem(TUTORIAL_AUTO_KEY,'done');
  closeTutorial();toast(tr('tutorialDone'));
}


function freshEditor(name=tr('defaultProject')){
  state.projectLanguage=APP_LANG;state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0,opacity:1,visible:true,name:tr('backgroundLayer')};state.imageLayers=[];state.texts=[];state.customFonts=[];state.active='background';layerGroupSelection.clear();state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,reuseLastPortal:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  $('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name=tr('defaultNewProject')){
  setFlowStep('fresco',{open:false});
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();await saveProject();closeSheet();toast(tr('newProjectCreated'));
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const locale=APP_LANG==='es'?'es-ES':APP_LANG==='en'?'en-GB':'fr-FR';
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||tr('unnamed'))}</strong><span>${(d.rows||3)*6} ${tr('missions').toLowerCase()}${updated?' · '+escapeHtml(updated):''}</span></div>${current?`<span class="currentbadge">${tr('opened')}</span>`:''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>${tr('open')}</button><button class="secondary exportproject">${icon('download')} ${tr('exportProject')}</button><button class="secondary shareproject">${icon('upload')} ${tr('shareProject')}</button><button class="secondary renameproject">${icon('edit')} ${tr('rename')}</button><button class="secondary duplicateproject">${icon('copy')} ${tr('copy')}</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||`<div class="small">${tr('noSavedProject')}</div>`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('myProjects')}</h2><p>${tr('projectsSaved',{n:projects.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="portableProjectIntro"><b>📦 ${tr('portableProject')}</b><span>${tr('portableProjectDesc')}</span></div><div class="projectlist">${cards}</div><div class="actions projectMainActions"><button class="secondary" id="importProject">${icon('upload')} ${tr('importProject')}</button><button class="primary" id="createProject">${icon('plus')} ${tr('newProject')}</button></div><p class="small">${tr('projectImportHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();$('#importProject',sh).onclick=importPortableProject;
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.exportproject',card).onclick=()=>deliverPortableProject(id,{share:false});
    $('.shareproject',card).onclick=()=>deliverPortableProject(id,{share:true});
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}

async function switchProject(id){setFlowStep('fresco',{open:false});await saveProject();await loadProject(id);resetHistory();closeSheet();toast(tr('projectOpened',{name:state.name}))}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameProject')}</h2><p>${tr('renameHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('projectName')}</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||tr('defaultProject'))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||tr('defaultProject');const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();markBackupChanged();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;$('#projectName').value=name}closeSheet();toast(tr('projectRenamed'))};
}

async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteProject')}</h2><p>${escapeHtml(rec.data?.name||tr('unnamed'))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('deleteWarning')}</span></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirmdelete">${icon('trash')} ${tr('delete')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}

async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||tr('fresco')} ${tr('copySuffix')}`;data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob,layerBlobs:rec.layerBlobs||[]});await txDone(tx2);markBackupChanged();await loadProject(newId);closeSheet();toast(tr('copyCreated'));
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);markBackupChanged();
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast(tr('projectDeleted'));
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,projectLanguage:projectLanguage(),name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation,opacity:state.bg.opacity??1,visible:state.bg.visible!==false,name:state.bg.name||tr('backgroundLayer')},imageLayers:state.imageLayers.map(l=>({id:l.id,name:l.name||'',x:l.x,y:l.y,scale:l.scale,rotation:l.rotation||0,opacity:l.opacity??1,visible:l.visible!==false,groupId:l.groupId||null,groupNumber:l.groupNumber||null,scope:l.scope==='mission'?'mission':'global',missionNumber:l.scope==='mission'?(parseInt(l.missionNumber)||1):null,fitMode:l.fitMode==='contain'?'contain':'cover'})),texts:state.texts,customFonts:state.customFonts,active:state.active,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){markBackupChanged();clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject({markBackup=true}={}){try{const db=await openDB();const tx=db.transaction('project','readwrite');const layerBlobs=state.imageLayers.filter(l=>l.blob).map(l=>({id:l.id,blob:l.blob}));tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob,layerBlobs});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current');if(markBackup)markBackupChanged()}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();resetHistory();await saveProject();return}
    freshEditor();state.projectId=target;state.projectLanguage=SUPPORTED_LANGS.includes(rec.data.projectLanguage)?rec.data.projectLanguage:(SUPPORTED_LANGS.includes(rec.data.language)?rec.data.language:APP_LANG);
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[],customFonts:rec.data.customFonts||[]});await registerProjectFonts();normalizeAllTextStyles();
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});state.bg.visible=rec.data.bg?.visible!==false;state.bg.opacity=Number.isFinite(+rec.data.bg?.opacity)?+rec.data.bg.opacity:1;state.bg.name=rec.data.bg?.name||tr('backgroundLayer');if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    const media=new Map((rec.layerBlobs||[]).map(x=>[x.id,x.blob]));state.imageLayers=(rec.data.imageLayers||[]).map(l=>normalizeImageLayerScope({...l,image:null,blob:media.get(l.id)||null,visible:l.visible!==false,opacity:Number.isFinite(+l.opacity)?+l.opacity:1,groupId:l.groupId||null}));
    await Promise.all(state.imageLayers.map(async l=>{if(l.blob)try{l.image=await blobToImage(l.blob)}catch(e){console.warn('layer image',l.id,e)}}));normalizeLayerGroups();
    const requestedActive=rec.data.active||'background';state.active=requestedActive.startsWith('image:')&&state.imageLayers.some(l=>'image:'+l.id===requestedActive)||requestedActive.startsWith('text:')&&state.texts.some(t=>'text:'+t.id===requestedActive)||requestedActive==='background'?requestedActive:'background';
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

if(Capacitor.isNativePlatform()){
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url)}).catch?.(()=>{});
  App.addListener('appStateChange',({isActive})=>{if(isActive){autoBackupOnForeground();resumePendingPlayOverlay()}else autoBackupOnBackground('appStateChange')}).catch?.(()=>{});
  // `pause` est plus direct sur plusieurs versions Android que le seul
  // appStateChange. Les gardes backupInProgress/révision rendent les doublons sûrs.
  App.addListener('pause',()=>autoBackupOnBackground('pause')).catch?.(()=>{});
  App.addListener('resume',()=>autoBackupOnForeground()).catch?.(()=>{});
  App.getLaunchUrl().then(r=>{if(r?.url)handleBridgeUrl(r.url)}).catch(()=>{});
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)autoBackupOnBackground('visibilitychange');else autoBackupOnForeground()});
window.addEventListener('pagehide',()=>autoBackupOnBackground('pagehide'));
window.addEventListener('resize',render);
window.addEventListener('keydown',e=>{
  const k=(e.key||'').toLowerCase(),ctrl=e.ctrlKey||e.metaKey;if(!ctrl)return;
  const target=e.target,tag=(target?.tagName||'').toUpperCase();
  const editing=['INPUT','TEXTAREA','SELECT'].includes(tag)||target?.isContentEditable;
  if(editing)return; // laisse l'annulation native fonctionner dans les champs texte
  if(k==='z'&&!e.shiftKey){e.preventDefault();undoAction();return}
  if(k==='y'||(k==='z'&&e.shiftKey)){e.preventDefault();redoAction();return}
});
if('serviceWorker' in navigator&&!Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();migrateLegacyStorage().then(()=>loadProject()).then(()=>maybeShowFirstTutorial());
