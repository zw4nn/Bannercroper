import './style.css';
import JSZip from 'jszip';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import QRCode from 'qrcode';
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { IntentLauncher, ActivityAction } from '@capgo/capacitor-intent-launcher';

const APP_VERSION = '1.0.12';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;
const MissionOverlay = registerPlugin('MissionOverlay');
const BackupFolder = registerPlugin('BackupFolder');
const LocationStatus = registerPlugin('LocationStatus');
const BANNERGRESS_API='https://api.bannergress.com';
const VALHALLA_API='https://valhalla1.openstreetmap.de/route';
const VALHALLA_MAX_POINTS=10;
const BANNER_WALK_CACHE_PREFIX='rbl-banner-walk-v5:';
const BANNER_FAVORITES_KEY='rbl-bannergress-favorites-v1';
const PLAY_SESSION_KEY='rbl-play-session-v1';
const PLAY_PENDING_KEY='rbl-play-pending-v1';
const BANNER_TODO_KEY='rbl-bannergress-todo-v1';
const PLAY_HISTORY_KEY='rbl-play-history-v1';
const BACKUP_AUTO_KEY='rbl-backup-auto-v1';
const BACKUP_LAST_KEY='rbl-backup-last-v1';
const BACKUP_FILE_NAME='Redacted_BannerLab_Autosave.json';
const TUTORIAL_AUTO_KEY='rbl-tutorial-auto-v1';
const TUTORIAL_PROMPT_SESSION_KEY='rbl-tutorial-prompted-v1';
const TUTORIAL_SEEN_PREFIX='rbl-tutorial-seen-v1:';
let backupInProgress=false;
let backupRevision=1;
let lastBackedRevision=0;
let backupAutoTimer=null;
let backupAppActive=true;

const LANG_META={
  fr:{flag:'🇫🇷',name:'Français',locale:'fr-FR'},en:{flag:'🇬🇧',name:'English',locale:'en-GB'},es:{flag:'🇪🇸',name:'Español',locale:'es-ES'},
  pt:{flag:'🇵🇹',name:'Português',locale:'pt-PT'},de:{flag:'🇩🇪',name:'Deutsch',locale:'de-DE'},it:{flag:'🇮🇹',name:'Italiano',locale:'it-IT'},
  nl:{flag:'🇳🇱',name:'Nederlands',locale:'nl-NL'},pl:{flag:'🇵🇱',name:'Polski',locale:'pl-PL'},cs:{flag:'🇨🇿',name:'Čeština',locale:'cs-CZ'},
  ro:{flag:'🇷🇴',name:'Română',locale:'ro-RO'},tr:{flag:'🇹🇷',name:'Türkçe',locale:'tr-TR'},ru:{flag:'🇷🇺',name:'Русский',locale:'ru-RU'},
  uk:{flag:'🇺🇦',name:'Українська',locale:'uk-UA'},ja:{flag:'🇯🇵',name:'日本語',locale:'ja-JP'},ko:{flag:'🇰🇷',name:'한국어',locale:'ko-KR'},
  'zh-Hans':{flag:'🇨🇳',name:'简体中文',locale:'zh-CN'},'zh-Hant':{flag:'🇹🇼',name:'繁體中文',locale:'zh-TW'},yue:{flag:'🇭🇰',name:'廣東話',locale:'zh-HK'},
  ar:{flag:'🇸🇦',name:'العربية',locale:'ar-SA',rtl:true},id:{flag:'🇮🇩',name:'Bahasa Indonesia',locale:'id-ID'}
};
const SUPPORTED_LANGS=Object.keys(LANG_META);
function detectAppLanguage(){
  const raw=String(navigator.language||'fr').toLowerCase();
  if(raw.startsWith('yue')||raw.startsWith('zh-hk')||raw.startsWith('zh-mo'))return 'yue';
  if(raw.startsWith('zh-tw'))return 'zh-Hant';
  if(raw.startsWith('zh'))return 'zh-Hans';
  const short=raw.split('-')[0];
  return SUPPORTED_LANGS.includes(short)?short:'en';
}
let APP_LANG=localStorage.getItem('rbl-language')||detectAppLanguage();
if(!SUPPORTED_LANGS.includes(APP_LANG))APP_LANG='en';
function appLocale(){return LANG_META[APP_LANG]?.locale||'en-GB'}

const I18N={
  fr:{
    fresco:'Fresque',route:'Parcours',missions:'Missions',publish:'Publier',projects:'Projets',rows:'Rangées',
    image:'Images',framing:'Cadrage',layers:'Calques',text:'Texte',preview:'Aperçu',export:'Exporter',
    wholeFresco:'Fresque entière',oneMission:'Une mission',noMission:'Aucune mission sélectionnée',
    addImage:'Ajoute ton image',imageHint:'Elle sera cadrée directement sur la géométrie Prime.',
    circles:'Cercles Prime',grid:'Grille 512',numbers:'Numéros',enlarge:'Agrandir mission',resetMission:'Réinitialiser mission',
    prev:'Précédente',next:'Suivante',complete:'Mission complète',remaining:'Encore {n} portail(s)',
    openIitc:'Ouvrir IITC Companion',tutorial:'Tutoriel',installPlugin:'Installer / mettre à jour le plugin IITC',
    autoAdvance:'Passer automatiquement à la mission suivante à {n} portails',
    reuseLast:'Reprendre automatiquement le dernier portail comme premier de la mission suivante',
    noPortal:'Aucun portail pour cette mission.',
    action:'Action',hack:'Hack',mod:'Installer un mod',capture:'Capturer / améliorer',link:'Créer un lien',field:'Créer un champ',passphrase:'Passphrase',
    question:'Question',answer:'Réponse attendue',save:'Enregistrer',cancel:'Annuler',
    settings:'Réglages communs',commonDesc:'Description commune',titleFormat:'Format des titres',defaultType:'Type par défaut',
    location:'Localisation',visible:'Visible',hidden:'Cachée',sequential:'Séquentielle',anyOrder:'Ordre libre',
    portalsPerMission:'Portails / mission',editMission:'Éditer la mission',title:'Titre',description:'Description',
    missionReady:'Prête',missionIncomplete:'Incomplète',openRoute:'Modifier le parcours',
    publishPack:'Créer le pack BannerLab',openMat:'Ouvrir Mission Authoring Tool',
    ownWorkflow:'BannerLab utilise désormais son propre format de projet et son propre pack de publication.',
    language:'Langue',french:'Français',english:'English',spanish:'Español',
    companionStats:'Stats piétonnes dans IITC',companionStatsDesc:'Dans le mini panneau IITC : 📊 Stats inutiles calcule les km à pied estimés, temps, détour et autres absurdités.',
    duplicateBad:'{n} réutilisation(s) de portail à vérifier.',handoverOk:'La reprise fin → début de mission est autorisée.',
    pluginVersion:'Companion 0.6.6',
    undo:'Annuler',redo:'Rétablir'
  },
  en:{
    fresco:'Banner',route:'Route',missions:'Missions',publish:'Publish',projects:'Projects',rows:'Rows',
    image:'Images',framing:'Framing',layers:'Layers',text:'Text',preview:'Preview',export:'Export',
    wholeFresco:'Whole banner',oneMission:'One mission',noMission:'No mission selected',
    addImage:'Add your image',imageHint:'It will be framed directly on the Prime geometry.',
    circles:'Prime circles',grid:'512 grid',numbers:'Numbers',enlarge:'Enlarge mission',resetMission:'Reset mission',
    prev:'Previous',next:'Next',complete:'Mission complete',remaining:'{n} portal(s) remaining',
    openIitc:'Open IITC Companion',tutorial:'Tutorial',installPlugin:'Install / update IITC plugin',
    autoAdvance:'Automatically move to next mission at {n} portals',
    reuseLast:'Automatically reuse the last portal as the first portal of the next mission',
    noPortal:'No portal in this mission.',
    action:'Action',hack:'Hack',mod:'Install a mod',capture:'Capture / upgrade',link:'Create a link',field:'Create a field',passphrase:'Passphrase',
    question:'Question',answer:'Expected answer',save:'Save',cancel:'Cancel',
    settings:'Common settings',commonDesc:'Common description',titleFormat:'Title format',defaultType:'Default type',
    location:'Location',visible:'Visible',hidden:'Hidden',sequential:'Sequential',anyOrder:'Any order',
    portalsPerMission:'Portals / mission',editMission:'Edit mission',title:'Title',description:'Description',
    missionReady:'Ready',missionIncomplete:'Incomplete',openRoute:'Edit route',
    publishPack:'Create BannerLab pack',openMat:'Open Mission Authoring Tool',
    ownWorkflow:'BannerLab now uses its own project format and publication pack.',
    language:'Language',french:'Français',english:'English',spanish:'Español',
    companionStats:'Walking stats in IITC',companionStatsDesc:'In the IITC mini panel: 📊 Useless stats calculates estimated walking distance, time, detour and other nonsense.',
    duplicateBad:'{n} portal reuse(s) to review.',handoverOk:'Mission-end → next-start reuse is allowed.',
    pluginVersion:'Companion 0.6.6',
    undo:'Undo',redo:'Redo'
  },
  es:{
    fresco:'Mosaico',route:'Recorrido',missions:'Misiones',publish:'Publicar',projects:'Proyectos',rows:'Filas',
    image:'Imágenes',framing:'Encuadre',layers:'Capas',text:'Texto',preview:'Vista previa',export:'Exportar',
    wholeFresco:'Mosaico completo',oneMission:'Una misión',noMission:'Ninguna misión seleccionada',
    addImage:'Añade tu imagen',imageHint:'Se encuadrará directamente con la geometría Prime.',
    circles:'Círculos Prime',grid:'Cuadrícula 512',numbers:'Números',enlarge:'Ampliar misión',resetMission:'Restablecer misión',
    prev:'Anterior',next:'Siguiente',complete:'Misión completa',remaining:'Faltan {n} portal(es)',
    openIitc:'Abrir IITC Companion',tutorial:'Tutorial',installPlugin:'Instalar / actualizar plugin IITC',
    autoAdvance:'Pasar automáticamente a la siguiente misión al llegar a {n} portales',
    reuseLast:'Reutilizar automáticamente el último portal como primero de la siguiente misión',
    noPortal:'No hay portales en esta misión.',
    action:'Acción',hack:'Hackear',mod:'Instalar un mod',capture:'Capturar / mejorar',link:'Crear un enlace',field:'Crear un campo',passphrase:'Contraseña',
    question:'Pregunta',answer:'Respuesta esperada',save:'Guardar',cancel:'Cancelar',
    settings:'Ajustes comunes',commonDesc:'Descripción común',titleFormat:'Formato de títulos',defaultType:'Tipo predeterminado',
    location:'Ubicación',visible:'Visible',hidden:'Oculta',sequential:'Secuencial',anyOrder:'Cualquier orden',
    portalsPerMission:'Portales / misión',editMission:'Editar misión',title:'Título',description:'Descripción',
    missionReady:'Lista',missionIncomplete:'Incompleta',openRoute:'Editar recorrido',
    publishPack:'Crear paquete BannerLab',openMat:'Abrir Mission Authoring Tool',
    ownWorkflow:'BannerLab usa ahora su propio formato de proyecto y paquete de publicación.',
    language:'Idioma',french:'Français',english:'English',spanish:'Español',
    companionStats:'Estadísticas a pie en IITC',companionStatsDesc:'En el mini panel IITC: 📊 Stats inútiles calcula distancia a pie estimada, tiempo, desvío y otras tonterías.',
    duplicateBad:'{n} reutilización(es) de portal para revisar.',handoverOk:'Se permite reutilizar fin de misión → inicio de la siguiente.',
    pluginVersion:'Companion 0.6.6',
    undo:'Deshacer',redo:'Rehacer'
  }
};
Object.assign(I18N.fr,{"subtitle":"Fresques Ingress Prime","source":"source","bannerHelp":"<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.","missionHelp":"<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi le déplacer ici à 1 doigt.","missionSelected":"Mission {n} sélectionnée","tapMedallion":"Touche un médaillon","touchMissionFirst":"Touche d’abord la mission que tu veux recadrer.","selectMissionFirst":"Sélectionne d’abord une mission.","heavyImage":"Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.","imported":"{w} × {h} px importés","textLayerDesc":"Chaque texte reste un calque indépendant, modifiable ou supprimable.","layer":"Calque","newText":"+ Nouveau texte","size":"Taille","outline":"Contour","color":"Couleur","outlineColor":"Couleur contour","add":"Ajouter","update":"Mettre à jour","delete":"Supprimer","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotation","center":"Centrer","reset":"Réinitialiser","done":"Terminé","transformText":"Transformer le texte","frameImage":"Cadrer l’image","pinchHint":"Le geste à deux doigts reste disponible directement sur la fresque.","missionCropOnly":"Ce cadrage ne touche qu’à ce médaillon.","resetThisMission":"Réinitialiser cette mission","individualCrop":"Recadrage individuel · 512 × 512","oneFinger":"1 doigt","move":"déplacer","twoFingers":"2 doigts","zoomRotate":"zoomer et tourner","previewPrime":"Aperçu Prime","previewApplied":"Les recadrages individuels sont déjà appliqués.","previewOrder":"Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.","exportTitle":"Exporter {n} missions","exportIntro":"Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.","noBackground":"Aucune image de fond n’est chargée.","missionFormat":"Format des missions","jpgFast":"JPG rapide · qualité élevée","pngLossless":"PNG sans perte · plus lent","fastEncoding":"Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.","rowRender":"Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.","adjusted":"{n} mission(s) avec recadrage individuel.","nianticCheck":"Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.","ready":"Prêt.","createZip":"Créer le ZIP","zipAssembly":"Assemblage du ZIP…","zipCreated":"ZIP créé.","zipDownloaded":"ZIP téléchargé.","saveShareZip":"Enregistrer ou partager le ZIP","exportFinished":"Export {format} terminé","exportFailed":"L’export a échoué.","newProject":"Nouveau projet","myProjects":"Mes projets","projectsSaved":"{n} projet(s) enregistré(s) sur ce téléphone.","unnamed":"Sans nom","opened":"Ouvert","open":"Ouvrir","rename":"Renommer","copy":"Copier","noSavedProject":"Aucun projet enregistré.","renameProject":"Renommer le projet","renameHint":"Un nom humainement reconnaissable, concept révolutionnaire.","projectName":"Nom du projet","projectOpened":"Projet ouvert : {name}","projectRenamed":"Projet renommé","deleteProject":"Supprimer ce projet ?","deleteWarning":"La fresque et son image enregistrée localement seront supprimées.","copyCreated":"Copie créée","projectDeleted":"Projet supprimé","newProjectCreated":"Nouveau projet créé avec Redacted","defaultProject":"Ma fresque","defaultNewProject":"Nouvelle fresque","copySuffix":"copie","versionLabel":"Version","infoPrime":"6 colonnes · 544 px · crop 512 px.","infoPlanner":"actions portail, passphrases, reprise fin→début et pack BannerLab natif.","infoCompanion":"parcours, actions, tracés multi-missions, options et statistiques piétonnes.","disclaimer":"Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.","titleTokens":"$T = nom · $N = numéro · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.6. Dans IITC Mobile, remplace la version précédente. Si IITC refuse de l’écraser, supprime une fois l’ancien plugin puis installe ce fichier.","pluginDialog":"Installer / mettre à jour Companion 0.6.6","pluginShareFailed":"Impossible de partager le plugin IITC.","intelOpened":"IITC Mobile ouvert avec le projet BannerLab.","intelPrimeOpened":"IITC Prime ouvert avec le projet BannerLab.","intelFallback":"IITC Mobile ouvert. Le Companion utilisera son dernier état synchronisé.","intelPrimeFallback":"IITC Prime ouvert. Le Companion utilisera son dernier état synchronisé.","intelBrowser":"IITC non détecté : ouverture dans le navigateur.","tutorialIntro":"Construis toute la bannière dans IITC sans revenir dans BannerLab après chaque portail.","tut1Title":"Installe le plugin une seule fois","tut1Text":"Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.","tut2Title":"Ouvre IITC depuis BannerLab","tut2Text":"BannerLab transmet le projet, la mission active et la langue au Companion via un fragment local que le serveur Intel ne reçoit pas.","tut3Title":"Construis directement sur la carte","tut3Text":"Le Companion permet d’ajouter, modifier ou retirer des portails, changer de mission et visualiser les tracés sans revenir dans BannerLab.","tut4Title":"Synchronise quand tu as fini","tut4Text":"Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.","tutNote":"Tu peux déplacer et redimensionner le Companion et ranger ses réglages dans Options.","installUpdate":"Installer / mettre à jour","emptyTitleIssue":"Mission {n} : titre vide","emptyDescIssue":"Mission {n} : description vide","portalsIssue":"Mission {n} : {count}/{need} portails","missingGuidIssue":"Mission {n} : {count} GUID manquant(s)","passIssue":"Mission {n} : {count} passphrase(s) incomplète(s)","reviewCount":"{n} point(s) à vérifier","projectReady":"Projet BannerLab prêt","fixBeforePublish":"Corrige les éléments avant publication.","publisherDesc":"Le prochain pont remplira le Mission Authoring Tool directement depuis ce format natif. La soumission finale restera volontairement faite dans l’outil officiel.","packCreating":"Création du pack BannerLab…","packCreated":"Pack BannerLab créé","exportImpossible":"Export impossible : {error}","missionResetDone":"Mission {n} réinitialisée","textDeleted":"Texte supprimé","histImport":"Importer image","histMissionZoom":"Zoom mission","histMissionRotation":"Rotation mission","histTextRotation":"Rotation texte","histImageRotation":"Rotation image","histTextZoom":"Zoom texte","histImageZoom":"Zoom image","histCenterText":"Centrer texte","histCenterImage":"Centrer image","histResetText":"Réinitialiser texte","histResetImage":"Réinitialiser image","histResetMission":"Réinitialiser mission","histDeleteText":"Supprimer texte","histAddText":"Ajouter texte","histEditText":"Modifier texte"});
Object.assign(I18N.en,{"subtitle":"Ingress Prime banners","source":"source","bannerHelp":"<b>Banner mode:</b> 1 finger moves the selected layer. <b>2 fingers</b> zoom and rotate.","missionHelp":"<b>Mission mode:</b> tap a medallion. For comfortable editing, use <b>Enlarge mission</b>. You can also move it here with 1 finger.","missionSelected":"Mission {n} selected","tapMedallion":"Tap a medallion","touchMissionFirst":"Tap the mission you want to reframe first.","selectMissionFirst":"Select a mission first.","heavyImage":"Very large image. It may make your phone reconsider its life choices.","imported":"Imported {w} × {h} px","textLayerDesc":"Each text remains an independent layer that can be edited or deleted.","layer":"Layer","newText":"+ New text","size":"Size","outline":"Outline","color":"Color","outlineColor":"Outline color","add":"Add","update":"Update","delete":"Delete","zoom":"Zoom","localZoom":"Local zoom","rotation":"Rotation","center":"Center","reset":"Reset","done":"Done","transformText":"Transform text","frameImage":"Frame image","pinchHint":"Two-finger gestures remain available directly on the banner.","missionCropOnly":"This framing only affects this medallion.","resetThisMission":"Reset this mission","individualCrop":"Individual framing · 512 × 512","oneFinger":"1 finger","move":"move","twoFingers":"2 fingers","zoomRotate":"zoom and rotate","previewPrime":"Prime preview","previewApplied":"Individual mission adjustments are already applied.","previewOrder":"Number 1 is bottom-right, then numbering goes left and upward through the rows.","exportTitle":"Export {n} missions","exportIntro":"Choose speed or lossless PNG. Both stay at 512 × 512.","noBackground":"No background image is loaded.","missionFormat":"Mission format","jpgFast":"Fast JPG · high quality","pngLossless":"Lossless PNG · slower","fastEncoding":"Fast mode avoids PNG encoding, which is by far the slowest part on a phone.","rowRender":"The background is rendered once per row instead of being recalculated six times.","adjusted":"{n} mission(s) with individual framing.","nianticCheck":"Check Niantic rules before submission: image rights, relevant content, and no dominant single character.","ready":"Ready.","createZip":"Create ZIP","zipAssembly":"Building ZIP…","zipCreated":"ZIP created.","zipDownloaded":"ZIP downloaded.","saveShareZip":"Save or share ZIP","exportFinished":"{format} export complete","exportFailed":"Export failed.","newProject":"New project","myProjects":"My projects","projectsSaved":"{n} project(s) saved on this phone.","unnamed":"Unnamed","opened":"Open","open":"Open","rename":"Rename","copy":"Copy","noSavedProject":"No saved project.","renameProject":"Rename project","renameHint":"A human-readable name. A surprisingly advanced concept.","projectName":"Project name","projectOpened":"Project opened: {name}","projectRenamed":"Project renamed","deleteProject":"Delete this project?","deleteWarning":"The banner and its locally stored image will be deleted.","copyCreated":"Copy created","projectDeleted":"Project deleted","newProjectCreated":"New project created with Redacted","defaultProject":"My banner","defaultNewProject":"New banner","copySuffix":"copy","versionLabel":"Version","infoPrime":"6 columns · 544 px · 512 px crop.","infoPlanner":"portal actions, passphrases, end→start handover and native BannerLab pack.","infoCompanion":"routes, actions, multi-mission tracks, options and walking stats.","disclaimer":"Ingress and Ingress Prime are Niantic trademarks. Redacted BannerLab is not affiliated with or endorsed by Niantic.","titleTokens":"$T = name · $N = number · $M = total · $0N = 01, 02…","pluginShareText":"Companion plugin 0.6.6. Replace the previous version in IITC Mobile. If IITC refuses to overwrite it, remove the old plugin once and install this file.","pluginDialog":"Install / update Companion 0.6.6","pluginShareFailed":"Unable to share the IITC plugin.","intelOpened":"IITC Mobile opened with the BannerLab project.","intelPrimeOpened":"IITC Prime opened with the BannerLab project.","intelFallback":"IITC Mobile opened. The Companion will use its last synchronized state.","intelPrimeFallback":"IITC Prime opened. The Companion will use its last synchronized state.","intelBrowser":"IITC not detected: opening in browser.","tutorialIntro":"Build the whole banner in IITC without returning to BannerLab after every portal.","tut1Title":"Install the plugin once","tut1Text":"From Route, use “Install / update IITC plugin”, then add the file as a user plugin in IITC Mobile.","tut2Title":"Open IITC from BannerLab","tut2Text":"BannerLab sends the project, active mission and language to the Companion through a local fragment that the Intel server never receives.","tut3Title":"Build directly on the map","tut3Text":"The Companion lets you add, edit or remove portals, change missions and see routes without returning to BannerLab.","tut4Title":"Sync when you are done","tut4Text":"“Sync BannerLab” sends all edited missions back to the project and reopens BannerLab.","tutNote":"You can move and resize the Companion and keep its settings inside Options.","installUpdate":"Install / update","emptyTitleIssue":"Mission {n}: empty title","emptyDescIssue":"Mission {n}: empty description","portalsIssue":"Mission {n}: {count}/{need} portals","missingGuidIssue":"Mission {n}: {count} missing GUID(s)","passIssue":"Mission {n}: {count} incomplete passphrase(s)","reviewCount":"{n} item(s) to review","projectReady":"BannerLab project ready","fixBeforePublish":"Fix these items before publishing.","publisherDesc":"The next bridge will fill the Mission Authoring Tool directly from this native format. Final submission will deliberately remain in the official tool.","packCreating":"Creating BannerLab pack…","packCreated":"BannerLab pack created","exportImpossible":"Export impossible: {error}","missionResetDone":"Mission {n} reset","textDeleted":"Text deleted","histImport":"Import image","histMissionZoom":"Mission zoom","histMissionRotation":"Mission rotation","histTextRotation":"Text rotation","histImageRotation":"Image rotation","histTextZoom":"Text zoom","histImageZoom":"Image zoom","histCenterText":"Center text","histCenterImage":"Center image","histResetText":"Reset text","histResetImage":"Reset image","histResetMission":"Reset mission","histDeleteText":"Delete text","histAddText":"Add text","histEditText":"Edit text"});
Object.assign(I18N.es,{"subtitle":"Mosaicos de Ingress Prime","source":"fuente","bannerHelp":"<b>Modo mosaico:</b> 1 dedo mueve la capa seleccionada. <b>2 dedos</b> amplían y giran.","missionHelp":"<b>Modo misión:</b> toca un medallón. Para trabajar cómodamente, usa <b>Ampliar misión</b>. También puedes moverlo aquí con 1 dedo.","missionSelected":"Misión {n} seleccionada","tapMedallion":"Toca un medallón","touchMissionFirst":"Toca primero la misión que quieres reencuadrar.","selectMissionFirst":"Selecciona primero una misión.","heavyImage":"Imagen muy pesada. Puede poner de rodillas al teléfono, lo cual sería bastante humillante.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto sigue siendo una capa independiente, editable o eliminable.","layer":"Capa","newText":"+ Nuevo texto","size":"Tamaño","outline":"Contorno","color":"Color","outlineColor":"Color del contorno","add":"Añadir","update":"Actualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotación","center":"Centrar","reset":"Restablecer","done":"Hecho","transformText":"Transformar texto","frameImage":"Encuadrar imagen","pinchHint":"El gesto con dos dedos sigue disponible directamente sobre el mosaico.","missionCropOnly":"Este encuadre solo afecta a este medallón.","resetThisMission":"Restablecer esta misión","individualCrop":"Encuadre individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"ampliar y girar","previewPrime":"Vista previa Prime","previewApplied":"Los ajustes individuales de las misiones ya están aplicados.","previewOrder":"El número 1 está abajo a la derecha; después la numeración avanza hacia la izquierda y sube por las filas.","exportTitle":"Exportar {n} misiones","exportIntro":"Elige velocidad o PNG sin pérdida. Ambos siguen en 512 × 512.","noBackground":"No hay imagen de fondo cargada.","missionFormat":"Formato de las misiones","jpgFast":"JPG rápido · alta calidad","pngLossless":"PNG sin pérdida · más lento","fastEncoding":"El modo rápido evita codificar PNG, que es con diferencia la parte más lenta en el teléfono.","rowRender":"El fondo se renderiza una sola vez por fila en vez de recalcularse seis veces.","adjusted":"{n} misión(es) con encuadre individual.","nianticCheck":"Comprueba las reglas de Niantic antes de enviar: derechos de imagen, contenido pertinente y ningún carácter único dominante.","ready":"Listo.","createZip":"Crear ZIP","zipAssembly":"Montando ZIP…","zipCreated":"ZIP creado.","zipDownloaded":"ZIP descargado.","saveShareZip":"Guardar o compartir ZIP","exportFinished":"Exportación {format} terminada","exportFailed":"La exportación ha fallado.","newProject":"Nuevo proyecto","myProjects":"Mis proyectos","projectsSaved":"{n} proyecto(s) guardado(s) en este teléfono.","unnamed":"Sin nombre","opened":"Abierto","open":"Abrir","rename":"Renombrar","copy":"Copiar","noSavedProject":"No hay proyectos guardados.","renameProject":"Renombrar proyecto","renameHint":"Un nombre reconocible por humanos. Concepto sorprendentemente avanzado.","projectName":"Nombre del proyecto","projectOpened":"Proyecto abierto: {name}","projectRenamed":"Proyecto renombrado","deleteProject":"¿Eliminar este proyecto?","deleteWarning":"Se eliminarán el mosaico y su imagen guardada localmente.","copyCreated":"Copia creada","projectDeleted":"Proyecto eliminado","newProjectCreated":"Nuevo proyecto creado con Redacted","defaultProject":"Mi mosaico","defaultNewProject":"Nuevo mosaico","copySuffix":"copia","versionLabel":"Versión","infoPrime":"6 columnas · 544 px · recorte 512 px.","infoPlanner":"acciones de portal, contraseñas, continuidad fin→inicio y paquete BannerLab nativo.","infoCompanion":"recorridos, acciones, trazados multi-misión, opciones y estadísticas a pie.","disclaimer":"Ingress e Ingress Prime son marcas de Niantic. Redacted BannerLab no está afiliado ni aprobado por Niantic.","titleTokens":"$T = nombre · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.6. Sustituye la versión anterior en IITC Mobile. Si IITC se niega a sobrescribirla, elimina una vez el plugin antiguo e instala este archivo.","pluginDialog":"Instalar / actualizar Companion 0.6.6","pluginShareFailed":"No se puede compartir el plugin IITC.","intelOpened":"IITC Mobile abierto con el proyecto BannerLab.","intelPrimeOpened":"IITC Prime abierto con el proyecto BannerLab.","intelFallback":"IITC Mobile abierto. Companion usará su último estado sincronizado.","intelPrimeFallback":"IITC Prime abierto. Companion usará su último estado sincronizado.","intelBrowser":"IITC no detectado: apertura en el navegador.","tutorialIntro":"Construye todo el mosaico en IITC sin volver a BannerLab después de cada portal.","tut1Title":"Instala el plugin una sola vez","tut1Text":"En Recorrido, usa « Instalar / actualizar plugin IITC » y añade el archivo como plugin de usuario en IITC Mobile.","tut2Title":"Abre IITC desde BannerLab","tut2Text":"BannerLab transmite el proyecto, la misión activa y el idioma al Companion mediante un fragmento local que el servidor Intel nunca recibe.","tut3Title":"Construye directamente en el mapa","tut3Text":"Companion permite añadir, modificar o quitar portales, cambiar de misión y ver los trazados sin volver a BannerLab.","tut4Title":"Sincroniza al terminar","tut4Text":"« Sincronizar BannerLab » devuelve todas las misiones modificadas al proyecto y vuelve a abrir BannerLab.","tutNote":"Puedes mover y redimensionar el Companion y guardar sus ajustes dentro de Opciones.","installUpdate":"Instalar / actualizar","emptyTitleIssue":"Misión {n}: título vacío","emptyDescIssue":"Misión {n}: descripción vacía","portalsIssue":"Misión {n}: {count}/{need} portales","missingGuidIssue":"Misión {n}: {count} GUID ausente(s)","passIssue":"Misión {n}: {count} contraseña(s) incompleta(s)","reviewCount":"{n} punto(s) por revisar","projectReady":"Proyecto BannerLab listo","fixBeforePublish":"Corrige estos elementos antes de publicar.","publisherDesc":"El próximo puente rellenará Mission Authoring Tool directamente desde este formato nativo. El envío final seguirá haciéndose voluntariamente en la herramienta oficial.","packCreating":"Creando paquete BannerLab…","packCreated":"Paquete BannerLab creado","exportImpossible":"Exportación imposible: {error}","missionResetDone":"Misión {n} restablecida","textDeleted":"Texto eliminado","histImport":"Importar imagen","histMissionZoom":"Zoom de misión","histMissionRotation":"Rotación de misión","histTextRotation":"Rotación de texto","histImageRotation":"Rotación de imagen","histTextZoom":"Zoom de texto","histImageZoom":"Zoom de imagen","histCenterText":"Centrar texto","histCenterImage":"Centrar imagen","histResetText":"Restablecer texto","histResetImage":"Restablecer imagen","histResetMission":"Restablecer misión","histDeleteText":"Eliminar texto","histAddText":"Añadir texto","histEditText":"Editar texto"});
Object.assign(I18N.fr,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directement depuis le Companion.","handoverDetail":"Le dernier portail peut devenir le premier de la mission suivante sans être considéré comme un doublon fautif.","coordsMissing":"Coordonnées introuvables.","coordsInvalid":"Coordonnées invalides.","duplicateElsewhere":"Ce portail est déjà utilisé ailleurs dans la bannière.","missionCompleteAdded":"Mission {n} complète · {next}","portalAdded":"Portail ajouté · mission {n}","syncOld":"Parcours synchronisé · ancien Companion détecté : installe la version 0.6.0.","syncOk":"Parcours IITC synchronisé · Companion {v}.","portalDefault":"Portail","bannerDefault":"Fresque"});
Object.assign(I18N.en,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directly from the Companion.","handoverDetail":"The last portal can become the first of the next mission without being treated as an invalid duplicate.","coordsMissing":"Coordinates not found.","coordsInvalid":"Invalid coordinates.","duplicateElsewhere":"This portal is already used elsewhere in the banner.","missionCompleteAdded":"Mission {n} complete · {next}","portalAdded":"Portal added · mission {n}","syncOld":"Route synchronized · old Companion detected: install version 0.6.0.","syncOk":"IITC route synchronized · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner"});
Object.assign(I18N.es,{"routeActionHelp":"Hack / Mod / Captura / Link / Field / Contraseña directamente desde Companion.","handoverDetail":"El último portal puede ser el primero de la siguiente misión sin considerarse un duplicado incorrecto.","coordsMissing":"No se han encontrado coordenadas.","coordsInvalid":"Coordenadas no válidas.","duplicateElsewhere":"Este portal ya se utiliza en otra parte del mosaico.","missionCompleteAdded":"Misión {n} completa · {next}","portalAdded":"Portal añadido · misión {n}","syncOld":"Recorrido sincronizado · Companion antiguo detectado: instala la versión 0.6.0.","syncOk":"Recorrido IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Mosaico"});
Object.assign(I18N.fr,{"livePublish":"Préparer directement dans Mission Authoring","livePublishShort":"Publisher direct","livePreparing":"Préparation des {n} missions pour le Publisher…","liveReady":"Ouverture du Publisher intégré…","liveNativeOnly":"Le Publisher direct est disponible dans l’APK Android.","liveFailed":"Impossible d’ouvrir le Publisher : {error}","liveExperimental":"Expérimental : Mission Authoring s’ouvre dans une vue intégrée à RBL. La connexion Google est la première chose à valider sur ton téléphone.","backupTransfer":"Sauvegarde / transfert","exportPackBackup":"Exporter un pack BannerLab","openOfficialOnly":"Ouvrir le site officiel seulement","publisherPreparingImage":"Rendu mission {n}/{total}…"});
Object.assign(I18N.en,{"livePublish":"Prepare directly in Mission Authoring","livePublishShort":"Direct Publisher","livePreparing":"Preparing {n} missions for Publisher…","liveReady":"Opening integrated Publisher…","liveNativeOnly":"Direct Publisher is available in the Android APK.","liveFailed":"Unable to open Publisher: {error}","liveExperimental":"Experimental: Mission Authoring opens inside an RBL-controlled view. Google sign-in is the first thing to validate on your phone.","backupTransfer":"Backup / transfer","exportPackBackup":"Export BannerLab pack","openOfficialOnly":"Open official site only","publisherPreparingImage":"Rendering mission {n}/{total}…"});
Object.assign(I18N.es,{"livePublish":"Preparar directamente en Mission Authoring","livePublishShort":"Publisher directo","livePreparing":"Preparando {n} misiones para Publisher…","liveReady":"Abriendo Publisher integrado…","liveNativeOnly":"Publisher directo está disponible en la APK Android.","liveFailed":"No se puede abrir Publisher: {error}","liveExperimental":"Experimental: Mission Authoring se abre en una vista controlada por RBL. El inicio de sesión de Google es lo primero que hay que validar en tu teléfono.","backupTransfer":"Copia / transferencia","exportPackBackup":"Exportar paquete BannerLab","openOfficialOnly":"Abrir solo el sitio oficial","publisherPreparingImage":"Renderizando misión {n}/{total}…"});
Object.assign(I18N.fr,{"browserPublish":"Publier dans Firefox","browserPublishShort":"Publisher navigateur","browserSetup":"Installer / mettre à jour le Publisher navigateur","browserPreparing":"Préparation de la mission {n}/{total}…","browserOpening":"Ouverture de Firefox…","browserNeed":"Le Publisher direct utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.","browserFailed":"Impossible d’ouvrir le Publisher : {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 pour missions.ingress.com. À installer une fois dans Violentmonkey sur Firefox Android.","browserShareDialog":"Installer Publisher 0.4.0","browserShareFailed":"Impossible de partager le Publisher navigateur.","publisherUrlTooLarge":"La mission est trop lourde à transmettre au navigateur.","publisherReturn":"Retour du Publisher.","publisherNoFirefox":"Firefox n’a pas été détecté. Ouverture dans le navigateur par défaut, mais le Publisher nécessite un navigateur avec userscripts."});
Object.assign(I18N.en,{"browserPublish":"Publish in Firefox","browserPublishShort":"Browser Publisher","browserSetup":"Install / update Browser Publisher","browserPreparing":"Preparing mission {n}/{total}…","browserOpening":"Opening Firefox…","browserNeed":"Direct Publisher uses Firefox Android + Violentmonkey so Google sign-in stays in a normal browser.","browserFailed":"Unable to open Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 for missions.ingress.com. Install it once in Violentmonkey on Firefox Android.","browserShareDialog":"Install Publisher 0.4.0","browserShareFailed":"Unable to share Browser Publisher.","publisherUrlTooLarge":"This mission is too large to send to the browser.","publisherReturn":"Returned from Publisher.","publisherNoFirefox":"Firefox was not detected. Opening the default browser, but Publisher requires a browser with userscript support."});
Object.assign(I18N.es,{"browserPublish":"Publicar en Firefox","browserPublishShort":"Publisher navegador","browserSetup":"Instalar / actualizar Publisher navegador","browserPreparing":"Preparando misión {n}/{total}…","browserOpening":"Abriendo Firefox…","browserNeed":"Publisher directo usa Firefox Android + Violentmonkey para mantener el inicio de sesión de Google en un navegador normal.","browserFailed":"No se puede abrir Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 para missions.ingress.com. Instálalo una vez en Violentmonkey sobre Firefox Android.","browserShareDialog":"Instalar Publisher 0.4.0","browserShareFailed":"No se puede compartir Publisher navegador.","publisherUrlTooLarge":"La misión es demasiado pesada para enviarla al navegador.","publisherReturn":"Regreso desde Publisher.","publisherNoFirefox":"Firefox no detectado. Se abre el navegador predeterminado, pero Publisher necesita un navegador compatible con userscripts."});
Object.assign(I18N.fr,{"publisherBrowser":"Navigateur de publication","chromeMode":"Chrome","chromeModeSub":"Sans appli supplémentaire · 1 favori à lancer par mission","firefoxMode":"Firefox","firefoxModeSub":"Automatique après installation de Violentmonkey + Publisher","recommendedAuto":"Automatique","noExtraApp":"Sans appli en plus","publishSelected":"Publier la mission","chromeSetup":"Configurer Chrome","firefoxSetup":"Configurer Firefox","chromeReady":"Favori Chrome vérifié","firefoxReady":"Publisher Firefox vérifié","notConfigured":"À configurer une fois","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome ne permet pas à RBL d’ajouter le favori à ta place. On réduit donc l’installation au strict minimum.","chromeStep1":"1. Copie le code du favori RBL Publisher.","chromeStep2":"2. Ouvre Mission Authoring dans Chrome et ajoute la page aux favoris.","chromeStep3":"3. Modifie ce favori : nom « RBL Publisher » et remplace son URL par le code copié.","chromeStep4":"4. Sur la page Mission Authoring, touche la barre d’adresse, tape « RBL », puis choisis le favori pour le tester.","copyBookmarklet":"Copier le code du favori","bookmarkletCopied":"Code du favori copié","openChromeSetup":"Ouvrir Chrome pour l’installation","testChrome":"Tester le favori Chrome","chromeRunHint":"Dans Chrome : touche la barre d’adresse, tape RBL puis sélectionne « RBL Publisher ».","chromeNeedsSetup":"Configure d’abord le favori Chrome RBL Publisher.","chromeOpenFail":"Impossible d’ouvrir Chrome. Ouverture dans le navigateur par défaut.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox peut charger le Publisher automatiquement grâce à Violentmonkey. C’est le mode le plus fluide.","sharePublisher":"Partager le userscript Publisher","testFirefox":"Tester le Publisher Firefox","firefoxNeedsSetup":"Installe Violentmonkey et le Publisher dans Firefox avant le test.","browserSaved":"Navigateur de publication : {browser}","setupConfirmed":"Configuration vérifiée.","bookmarkletCopyFail":"Impossible de copier automatiquement. Le code est affiché ci-dessous.","bookmarkletLabel":"Code du favori","autoImpossibleChrome":"Chargement automatique impossible dans Chrome Android sans extension ou permission intrusive. Le favori reste nécessaire.","openChromePublish":"Ouverture dans Chrome…","openFirefoxPublish":"Ouverture dans Firefox…"});
Object.assign(I18N.en,{"publisherBrowser":"Publishing browser","chromeMode":"Chrome","chromeModeSub":"No extra app · run one bookmark per mission","firefoxMode":"Firefox","firefoxModeSub":"Automatic after installing Violentmonkey + Publisher","recommendedAuto":"Automatic","noExtraApp":"No extra app","publishSelected":"Publish mission","chromeSetup":"Set up Chrome","firefoxSetup":"Set up Firefox","chromeReady":"Chrome bookmark verified","firefoxReady":"Firefox Publisher verified","notConfigured":"One-time setup required","chromeSetupTitle":"Chrome Publisher","chromeSetupIntro":"Chrome does not let RBL add the bookmark for you. Setup is therefore reduced to the minimum possible.","chromeStep1":"1. Copy the RBL Publisher bookmark code.","chromeStep2":"2. Open Mission Authoring in Chrome and bookmark the page.","chromeStep3":"3. Edit that bookmark: name it “RBL Publisher” and replace its URL with the copied code.","chromeStep4":"4. On Mission Authoring, tap the address bar, type “RBL”, then choose the bookmark to test it.","copyBookmarklet":"Copy bookmark code","bookmarkletCopied":"Bookmark code copied","openChromeSetup":"Open Chrome for setup","testChrome":"Test Chrome bookmark","chromeRunHint":"In Chrome: tap the address bar, type RBL, then select “RBL Publisher”.","chromeNeedsSetup":"Set up the RBL Publisher Chrome bookmark first.","chromeOpenFail":"Could not open Chrome. Opening the default browser.","firefoxSetupTitle":"Firefox Publisher","firefoxSetupIntro":"Firefox can load Publisher automatically through Violentmonkey. This is the smoothest mode.","sharePublisher":"Share Publisher userscript","testFirefox":"Test Firefox Publisher","firefoxNeedsSetup":"Install Violentmonkey and Publisher in Firefox before testing.","browserSaved":"Publishing browser: {browser}","setupConfirmed":"Setup verified.","bookmarkletCopyFail":"Could not copy automatically. The code is shown below.","bookmarkletLabel":"Bookmark code","autoImpossibleChrome":"Automatic loading is not possible in Chrome Android without an extension or intrusive permission. The bookmark is still required.","openChromePublish":"Opening Chrome…","openFirefoxPublish":"Opening Firefox…"});
Object.assign(I18N.es,{"publisherBrowser":"Navegador de publicación","chromeMode":"Chrome","chromeModeSub":"Sin aplicación adicional · un favorito por misión","firefoxMode":"Firefox","firefoxModeSub":"Automático tras instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sin aplicación adicional","publishSelected":"Publicar misión","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Favorito Chrome verificado","firefoxReady":"Publisher Firefox verificado","notConfigured":"Configurar una sola vez","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome no permite que RBL añada el favorito por ti. La instalación se reduce al mínimo posible.","chromeStep1":"1. Copia el código del favorito RBL Publisher.","chromeStep2":"2. Abre Mission Authoring en Chrome y añade la página a favoritos.","chromeStep3":"3. Edita ese favorito: nombre « RBL Publisher » y sustituye la URL por el código copiado.","chromeStep4":"4. En Mission Authoring, toca la barra de direcciones, escribe « RBL » y elige el favorito para probarlo.","copyBookmarklet":"Copiar código del favorito","bookmarkletCopied":"Código del favorito copiado","openChromeSetup":"Abrir Chrome para instalar","testChrome":"Probar favorito Chrome","chromeRunHint":"En Chrome: toca la barra de direcciones, escribe RBL y selecciona « RBL Publisher ».","chromeNeedsSetup":"Configura primero el favorito Chrome RBL Publisher.","chromeOpenFail":"No se puede abrir Chrome. Se abre el navegador predeterminado.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox puede cargar Publisher automáticamente con Violentmonkey. Es el modo más fluido.","sharePublisher":"Compartir userscript Publisher","testFirefox":"Probar Publisher Firefox","firefoxNeedsSetup":"Instala Violentmonkey y Publisher en Firefox antes de probar.","browserSaved":"Navegador de publicación: {browser}","setupConfirmed":"Configuración verificada.","bookmarkletCopyFail":"No se puede copiar automáticamente. El código aparece abajo.","bookmarkletLabel":"Código del favorito","autoImpossibleChrome":"La carga automática no es posible en Chrome Android sin extensión o permiso intrusivo. El favorito sigue siendo necesario.","openChromePublish":"Abriendo Chrome…","openFirefoxPublish":"Abriendo Firefox…"});
Object.assign(I18N.fr,{"chromeModeSub":"Sans appli supplémentaire · petit favori + Autoriser si demandé","chromeWizardTitle":"Configurer Chrome","chromeWizardIntro":"Une seule configuration. RBL mémorise ta progression.","chromeFileTitle":"Enregistrer le Publisher","chromeFileText":"Enregistre le petit fichier Publisher sur ton téléphone. Dans la feuille Android, choisis Fichiers / Enregistrer et garde-le par exemple dans Téléchargements.","chromeSaveFile":"Enregistrer publisher.js","chromeFileDone":"Fichier Publisher préparé","alreadySaved":"Je l’ai déjà enregistré","chromeBookmarkTitle":"Créer le mini favori","chromeBookmarkText":"Le favori ne contient plus le Publisher entier. Il fait seulement {n} caractères et sert à charger le fichier que tu viens d’enregistrer.","chromeBookmarkName":"Nom du favori : RBL Publisher","chromeBookmarkHow":"Dans Chrome : ouvre Mission Authoring → ⋮ → Ajouter aux favoris. Modifie ensuite le favori, mets « RBL Publisher » et colle le code dans URL.","copyMiniCode":"Copier le mini code","miniCodeCopied":"Mini code copié","openChromeBookmark":"Ouvrir Mission Authoring","bookmarkCreated":"J’ai créé le favori","chromeTestTitle":"Tester et autoriser","chromeTestText":"RBL ouvre Mission Authoring. Dans la barre d’adresse, tape RBL puis touche « RBL Publisher ». La première fois, Chrome te demandera de choisir publisher.js. Les fois suivantes il pourra simplement demander Autoriser.","chromeTestButton":"Tester dans Chrome","chromeTestWaiting":"Dans Chrome : tape RBL → RBL Publisher → sélectionne publisher.js si demandé → Autoriser.","chromeSetupSuccess":"Chrome est prêt","chromeSetupSuccessText":"Le favori et le fichier Publisher fonctionnent. Pour publier : RBL ouvre Chrome, tu lances RBL Publisher et tu autorises si Chrome le demande.","publishNow":"Publier maintenant","wizardPrev":"Précédent","wizardNext":"Continuer","wizardRestart":"Recommencer la configuration","stepOf":"Étape {n}/3","chromeFileShareText":"Enregistre ce fichier publisher.js dans un dossier facile à retrouver, par exemple Téléchargements. Chrome te le demandera au premier test.","chromeFileShareDialog":"Enregistrer RBL Publisher","chromeFileShareFail":"Impossible de préparer le fichier Publisher.","chromePermissionHint":"Chrome pourra redemander l’autorisation de lire publisher.js. Tu peux simplement accepter.","chromeNotAutoFavorite":"RBL ne peut pas créer un favori Chrome automatiquement. C’est la seule étape manuelle obligatoire.","codeLength":"{n} caractères","chromeStepSaved":"Étape enregistrée","chromeResetDone":"Configuration Chrome réinitialisée","chromeSelectFileHint":"Sélectionne le fichier redacted-bannerlab-publisher.user.js enregistré à l’étape 1."});
Object.assign(I18N.en,{"chromeModeSub":"No extra app · small bookmark + Allow when requested","chromeWizardTitle":"Set up Chrome","chromeWizardIntro":"One-time setup. RBL remembers your progress.","chromeFileTitle":"Save Publisher","chromeFileText":"Save the small Publisher file on your phone. In Android's share sheet, choose Files / Save and keep it somewhere easy such as Downloads.","chromeSaveFile":"Save publisher.js","chromeFileDone":"Publisher file prepared","alreadySaved":"I already saved it","chromeBookmarkTitle":"Create the mini bookmark","chromeBookmarkText":"The bookmark no longer contains the whole Publisher. It is only {n} characters and loads the file you just saved.","chromeBookmarkName":"Bookmark name: RBL Publisher","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Add to bookmarks. Then edit the bookmark, name it “RBL Publisher” and paste the code into URL.","copyMiniCode":"Copy mini code","miniCodeCopied":"Mini code copied","openChromeBookmark":"Open Mission Authoring","bookmarkCreated":"I created the bookmark","chromeTestTitle":"Test and authorize","chromeTestText":"RBL opens Mission Authoring. In the address bar type RBL, then tap “RBL Publisher”. The first time Chrome asks you to choose publisher.js. Later it may only ask Allow.","chromeTestButton":"Test in Chrome","chromeTestWaiting":"In Chrome: type RBL → RBL Publisher → select publisher.js if requested → Allow.","chromeSetupSuccess":"Chrome is ready","chromeSetupSuccessText":"The bookmark and Publisher file work. To publish: RBL opens Chrome, you run RBL Publisher and allow access if Chrome asks.","publishNow":"Publish now","wizardPrev":"Previous","wizardNext":"Continue","wizardRestart":"Restart setup","stepOf":"Step {n}/3","chromeFileShareText":"Save this publisher.js somewhere easy to find, such as Downloads. Chrome will ask for it during the first test.","chromeFileShareDialog":"Save RBL Publisher","chromeFileShareFail":"Unable to prepare Publisher file.","chromePermissionHint":"Chrome may ask again for permission to read publisher.js. You can simply allow it.","chromeNotAutoFavorite":"RBL cannot create a Chrome bookmark automatically. This is the only mandatory manual step.","codeLength":"{n} characters","chromeStepSaved":"Step saved","chromeResetDone":"Chrome setup reset","chromeSelectFileHint":"Select the redacted-bannerlab-publisher.user.js file saved in step 1."});
Object.assign(I18N.es,{"chromeModeSub":"Sin aplicación adicional · favorito pequeño + Autorizar si se solicita","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Una sola configuración. RBL recuerda tu progreso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"Guarda el pequeño archivo Publisher en el teléfono. En la hoja de Android elige Archivos / Guardar y déjalo en un lugar fácil, por ejemplo Descargas.","chromeSaveFile":"Guardar publisher.js","chromeFileDone":"Archivo Publisher preparado","alreadySaved":"Ya lo he guardado","chromeBookmarkTitle":"Crear el mini favorito","chromeBookmarkText":"El favorito ya no contiene todo el Publisher. Solo tiene {n} caracteres y carga el archivo que acabas de guardar.","chromeBookmarkName":"Nombre del favorito: RBL Publisher","chromeBookmarkHow":"En Chrome: abre Mission Authoring → ⋮ → Añadir a favoritos. Después edita el favorito, pon « RBL Publisher » y pega el código en URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"He creado el favorito","chromeTestTitle":"Probar y autorizar","chromeTestText":"RBL abre Mission Authoring. En la barra de direcciones escribe RBL y toca « RBL Publisher ». La primera vez Chrome pedirá elegir publisher.js. Después puede pedir solo Autorizar.","chromeTestButton":"Probar en Chrome","chromeTestWaiting":"En Chrome: escribe RBL → RBL Publisher → selecciona publisher.js si se solicita → Autorizar.","chromeSetupSuccess":"Chrome está listo","chromeSetupSuccessText":"El favorito y el archivo Publisher funcionan. Para publicar: RBL abre Chrome, ejecutas RBL Publisher y autorizas si Chrome lo solicita.","publishNow":"Publicar ahora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuración","stepOf":"Paso {n}/3","chromeFileShareText":"Guarda este publisher.js en un lugar fácil de encontrar, por ejemplo Descargas. Chrome lo pedirá durante la primera prueba.","chromeFileShareDialog":"Guardar RBL Publisher","chromeFileShareFail":"No se puede preparar el archivo Publisher.","chromePermissionHint":"Chrome puede volver a pedir permiso para leer publisher.js. Basta con autorizar.","chromeNotAutoFavorite":"RBL no puede crear automáticamente un favorito de Chrome. Es la única etapa manual obligatoria.","codeLength":"{n} caracteres","chromeStepSaved":"Paso guardado","chromeResetDone":"Configuración Chrome reiniciada","chromeSelectFileHint":"Selecciona el archivo redacted-bannerlab-publisher.user.js guardado en el paso 1."});
Object.assign(I18N.fr,{"bannerDescription":"Description de la bannière","required":"Obligatoire","bannerDescriptionHint":"Cette description sert de description par défaut pour toutes les missions. Tu pourras personnaliser une mission ensuite.","bannerDescriptionRequired":"La description de la bannière est obligatoire.","describeBeforePublish":"Décris d’abord la bannière","describeBeforePublishText":"Impossible de publier tant que la bannière n’a pas de description. Elle sera appliquée par défaut à toutes les missions.","saveAndContinue":"Enregistrer et continuer","missionPublishBlocked":"Mission non publiable","missionNeedsPortals":"La mission {n} contient {count}/{need} portails. Il en faut au moins {need} pour la publier.","completeMission":"Compléter la mission","currentMissionReady":"Mission prête à publier","publishBlockedHint":"Le bouton de publication reste bloqué tant que les éléments obligatoires ne sont pas complets.","minimumSix":"Minimum : 6 portails par mission","publisherDescRequired":"Le Publisher refuse une mission sans description.","publisherPortalsRequired":"Le Publisher refuse une mission avec moins de 6 portails."});
Object.assign(I18N.en,{"bannerDescription":"Banner description","required":"Required","bannerDescriptionHint":"This is the default description for every mission. You can still customize individual missions later.","bannerDescriptionRequired":"The banner description is required.","describeBeforePublish":"Describe the banner first","describeBeforePublishText":"Publishing is blocked until the banner has a description. It will be used as the default for all missions.","saveAndContinue":"Save and continue","missionPublishBlocked":"Mission cannot be published","missionNeedsPortals":"Mission {n} has {count}/{need} portals. It needs at least {need} before publishing.","completeMission":"Complete mission","currentMissionReady":"Mission ready to publish","publishBlockedHint":"Publishing remains blocked until all mandatory items are complete.","minimumSix":"Minimum: 6 portals per mission","publisherDescRequired":"Publisher refuses missions without a description.","publisherPortalsRequired":"Publisher refuses missions with fewer than 6 portals."});
Object.assign(I18N.es,{"bannerDescription":"Descripción del mosaico","required":"Obligatorio","bannerDescriptionHint":"Esta será la descripción predeterminada de todas las misiones. Después puedes personalizar cada misión.","bannerDescriptionRequired":"La descripción del mosaico es obligatoria.","describeBeforePublish":"Describe primero el mosaico","describeBeforePublishText":"No se puede publicar hasta que el mosaico tenga una descripción. Se aplicará por defecto a todas las misiones.","saveAndContinue":"Guardar y continuar","missionPublishBlocked":"Misión no publicable","missionNeedsPortals":"La misión {n} tiene {count}/{need} portales. Necesita al menos {need} para publicarla.","completeMission":"Completar misión","currentMissionReady":"Misión lista para publicar","publishBlockedHint":"El botón de publicación permanece bloqueado hasta completar los elementos obligatorios.","minimumSix":"Mínimo: 6 portales por misión","publisherDescRequired":"Publisher rechaza una misión sin descripción.","publisherPortalsRequired":"Publisher rechaza una misión con menos de 6 portales."});
Object.assign(I18N.fr,{"playBanners":"Jouer","playHub":"Jouer une bannière","searchBannergress":"Rechercher sur Bannergress","searchPlaceholder":"Nom de bannière, ville…","search":"Rechercher","favorites":"Favoris","currentBanner":"En cours","noFavorites":"Aucune bannière favorite. Pour une fois, ton stockage local respire.","noPlaySession":"Aucune bannière en cours.","searchPrompt":"Recherche directement les bannières publiques de Bannergress.","searching":"Recherche…","searchError":"Recherche Bannergress impossible : {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favori","removeFavorite":"Retirer des favoris","playThisBanner":"Jouer cette bannière","resumeBanner":"Reprendre la bannière","stopBanner":"Arrêter l’overlay","openCurrentMission":"Ouvrir la mission actuelle","overlayPermissionTitle":"Autoriser l’overlay RBL","overlayPermissionText":"Android doit autoriser Redacted BannerLab à s’afficher par-dessus Ingress. Une seule autorisation système, ensuite notre dino fait sa vie.","overlayPermissionButton":"Autoriser l’affichage par-dessus les applis","overlayPermissionWaiting":"Reviens dans RBL après avoir autorisé l’affichage.","overlayStarted":"Overlay mission démarré.","overlayFailed":"Impossible de démarrer l’overlay : {error}","bannerLoadError":"Impossible de charger cette bannière : {error}","bannerOffline":"Cette bannière ne contient aucune mission exploitable.","bannerDisabled":"{n} mission(s) désactivée(s)","addressUnknown":"Lieu non précisé","doneMissions":"{done}/{total} terminées","deepLinkOnly":"RBL ne pilote pas Ingress : l’overlay ouvre uniquement les deeplinks officiels des missions.","bannergressCredit":"Recherche via Bannergress","publisherWholeBanner":"Préparer toute la bannière","publisherWholeHint":"Une seule session navigateur : toutes les missions et leurs images sont préparées ensemble.","publisherAllRequired":"Toutes les missions doivent être complètes avant de démarrer la session de publication.","publisherSessionCreating":"Préparation de la session Publisher {n}/{total}…","publisherSessionReady":"Session Publisher prête. Enregistre le fichier puis ouvre le navigateur.","publisherSessionFileText":"Enregistre ce fichier de session RBL. Chrome/Firefox le chargera une seule fois pour toute la bannière.","publisherSessionDialog":"Enregistrer la session Publisher","publisherSessionShareFail":"Impossible de préparer la session Publisher.","chromeSessionHint":"Chrome : lance le favori RBL Publisher une seule fois, puis sélectionne le fichier de session que tu viens d’enregistrer.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement ; charge le fichier de session une seule fois.","easterEgg":"Tu l’as cherché."});
Object.assign(I18N.en,{"playBanners":"Play","playHub":"Play a banner","searchBannergress":"Search Bannergress","searchPlaceholder":"Banner name, city…","search":"Search","favorites":"Favorites","currentBanner":"Current","noFavorites":"No favorite banners yet. Your local storage is enjoying the peace.","noPlaySession":"No banner currently running.","searchPrompt":"Search public Bannergress banners directly.","searching":"Searching…","searchError":"Bannergress search failed: {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favorite","removeFavorite":"Remove favorite","playThisBanner":"Play this banner","resumeBanner":"Resume banner","stopBanner":"Stop overlay","openCurrentMission":"Open current mission","overlayPermissionTitle":"Allow RBL overlay","overlayPermissionText":"Android must allow Redacted BannerLab to appear over Ingress. One system permission, then the dino can mind its business.","overlayPermissionButton":"Allow display over other apps","overlayPermissionWaiting":"Return to RBL after granting the permission.","overlayStarted":"Mission overlay started.","overlayFailed":"Could not start overlay: {error}","bannerLoadError":"Could not load this banner: {error}","bannerOffline":"This banner has no usable missions.","bannerDisabled":"{n} disabled mission(s)","addressUnknown":"Location not specified","doneMissions":"{done}/{total} completed","deepLinkOnly":"RBL does not control Ingress: the overlay only opens official mission deep links.","bannergressCredit":"Search via Bannergress","publisherWholeBanner":"Prepare whole banner","publisherWholeHint":"One browser session: all missions and images are prepared together.","publisherAllRequired":"Every mission must be complete before starting the publishing session.","publisherSessionCreating":"Preparing Publisher session {n}/{total}…","publisherSessionReady":"Publisher session ready. Save the file, then open the browser.","publisherSessionFileText":"Save this RBL session file. Chrome/Firefox loads it once for the entire banner.","publisherSessionDialog":"Save Publisher session","publisherSessionShareFail":"Unable to prepare Publisher session.","chromeSessionHint":"Chrome: run the RBL Publisher bookmark once, then select the session file you just saved.","firefoxSessionHint":"Firefox: Publisher loads automatically; select the session file once.","easterEgg":"You asked for this."});
Object.assign(I18N.es,{"playBanners":"Jugar","playHub":"Jugar un mosaico","searchBannergress":"Buscar en Bannergress","searchPlaceholder":"Nombre, ciudad…","search":"Buscar","favorites":"Favoritos","currentBanner":"En curso","noFavorites":"Aún no hay mosaicos favoritos. El almacenamiento local descansa.","noPlaySession":"No hay ningún mosaico en curso.","searchPrompt":"Busca directamente mosaicos públicos de Bannergress.","searching":"Buscando…","searchError":"Error al buscar en Bannergress: {error}","missionsCount":"{n} misiones","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Quitar de favoritos","playThisBanner":"Jugar este mosaico","resumeBanner":"Reanudar mosaico","stopBanner":"Detener overlay","openCurrentMission":"Abrir misión actual","overlayPermissionTitle":"Autorizar overlay RBL","overlayPermissionText":"Android debe permitir que Redacted BannerLab aparezca sobre Ingress. Un permiso del sistema y el dinosaurio queda suelto.","overlayPermissionButton":"Permitir mostrar sobre otras apps","overlayPermissionWaiting":"Vuelve a RBL después de autorizarlo.","overlayStarted":"Overlay de misión iniciado.","overlayFailed":"No se puede iniciar el overlay: {error}","bannerLoadError":"No se puede cargar el mosaico: {error}","bannerOffline":"Este mosaico no contiene misiones utilizables.","bannerDisabled":"{n} misión(es) desactivada(s)","addressUnknown":"Lugar no indicado","doneMissions":"{done}/{total} terminadas","deepLinkOnly":"RBL no controla Ingress: el overlay solo abre deeplinks oficiales de misiones.","bannergressCredit":"Búsqueda mediante Bannergress","publisherWholeBanner":"Preparar todo el mosaico","publisherWholeHint":"Una sola sesión: todas las misiones e imágenes se preparan juntas.","publisherAllRequired":"Todas las misiones deben estar completas antes de iniciar la sesión de publicación.","publisherSessionCreating":"Preparando sesión Publisher {n}/{total}…","publisherSessionReady":"Sesión Publisher lista. Guarda el archivo y abre el navegador.","publisherSessionFileText":"Guarda este archivo de sesión RBL. Chrome/Firefox lo carga una vez para todo el mosaico.","publisherSessionDialog":"Guardar sesión Publisher","publisherSessionShareFail":"No se puede preparar la sesión Publisher.","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher una sola vez y selecciona el archivo de sesión guardado.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente; carga el archivo de sesión una sola vez.","easterEgg":"Tú lo pediste."});
Object.assign(I18N.fr,{"playBanners":"Rechercher une fresque","playHub":"Rechercher une fresque","searchBannergress":"Rechercher une fresque","searchPlaceholder":"Nom ou mot-clé","bannerNameSearch":"Nom / mot-clé","citySearch":"Ville","authorSearch":"Auteur","cityPlaceholder":"Ex. Nantes","authorPlaceholder":"Ex. AgentName","nearMe":"Autour de moi","nearMeOn":"Ma position activée","nearMeHint":"La position remplace le filtre ville ; nom et auteur restent combinables.","locationGetting":"Récupération de ta position…","locationError":"Impossible de récupérer ta position : {error}","locationReady":"Position récupérée","searchCriteriaRequired":"Renseigne au moins un critère de recherche.","cityResolving":"Recherche de la ville…","cityNotFound":"Aucun lieu Bannergress trouvé pour « {city} ».","cityUsing":"Lieu retenu : {city}","searchPrompt":"Combine nom, ville et auteur, ou cherche les fresques proches de ta position.","currentBanner":"Reprendre","playThisBanner":"Lancer cette fresque","resumeBanner":"Reprendre cette fresque","bannerAuthor":"Auteur : {author}","overlayDrag":"≡  Déplacer","overlayMinimize":"Réduire","overlayClose":"Fermer","overlayMoved":"Position overlay enregistrée","searchReset":"Effacer","resultsCount":"{n} résultat(s)","searchFilters":"Filtres actifs","allPublicBanners":"Fresques publiques Bannergress"});
Object.assign(I18N.en,{"playBanners":"Find a banner","playHub":"Find a banner","searchBannergress":"Find a banner","searchPlaceholder":"Name or keyword","bannerNameSearch":"Name / keyword","citySearch":"City","authorSearch":"Author","cityPlaceholder":"e.g. Nantes","authorPlaceholder":"e.g. AgentName","nearMe":"Near me","nearMeOn":"My location enabled","nearMeHint":"Location replaces the city filter; name and author can still be combined.","locationGetting":"Getting your location…","locationError":"Could not get your location: {error}","locationReady":"Location acquired","searchCriteriaRequired":"Enter at least one search criterion.","cityResolving":"Looking up city…","cityNotFound":"No Bannergress place found for “{city}”.","cityUsing":"Using place: {city}","searchPrompt":"Combine name, city and author, or find banners near your location.","currentBanner":"Resume","playThisBanner":"Start this banner","resumeBanner":"Resume this banner","bannerAuthor":"Author: {author}","overlayDrag":"≡  Move","overlayMinimize":"Minimize","overlayClose":"Close","overlayMoved":"Overlay position saved","searchReset":"Clear","resultsCount":"{n} result(s)","searchFilters":"Active filters","allPublicBanners":"Public Bannergress banners"});
Object.assign(I18N.es,{"playBanners":"Buscar un mosaico","playHub":"Buscar un mosaico","searchBannergress":"Buscar un mosaico","searchPlaceholder":"Nombre o palabra clave","bannerNameSearch":"Nombre / palabra clave","citySearch":"Ciudad","authorSearch":"Autor","cityPlaceholder":"Ej. Nantes","authorPlaceholder":"Ej. AgentName","nearMe":"Cerca de mí","nearMeOn":"Mi ubicación activada","nearMeHint":"La ubicación sustituye la ciudad; nombre y autor se pueden combinar.","locationGetting":"Obteniendo tu ubicación…","locationError":"No se puede obtener tu ubicación: {error}","locationReady":"Ubicación obtenida","searchCriteriaRequired":"Introduce al menos un criterio de búsqueda.","cityResolving":"Buscando ciudad…","cityNotFound":"No se encontró ningún lugar Bannergress para « {city} ».","cityUsing":"Lugar usado: {city}","searchPrompt":"Combina nombre, ciudad y autor, o busca mosaicos cerca de tu ubicación.","currentBanner":"Reanudar","playThisBanner":"Iniciar este mosaico","resumeBanner":"Reanudar este mosaico","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Reducir","overlayClose":"Cerrar","overlayMoved":"Posición del overlay guardada","searchReset":"Borrar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros activos","allPublicBanners":"Mosaicos públicos Bannergress"});

Object.assign(I18N.fr,{"searchPrompt":"Recherche par nom et/ou zone géographique, avec un rayon réellement limité.","nearMeHint":"Utilise ta position actuelle à la place de la ville.","searchRadius":"Rayon de recherche","radiusHint":"Appliqué autour de la ville ou de ta position.","locationDisabled":"La localisation du téléphone est désactivée.","locationPermissionDenied":"BannerLab n’a pas l’autorisation d’utiliser ta position.","locationUnavailable":"Position indisponible. Vérifie que la localisation du téléphone est activée.","locationTimeout":"La position n’a pas pu être obtenue à temps. Vérifie que la localisation est activée.","openLocationSettings":"Activer la localisation","openAppSettings":"Ouvrir les réglages de l’app","cityNoCoordinates":"La ville « {city} » a été trouvée, mais sa position n’est pas exploitable.","cityUsingRadius":"Lieu retenu : {city} · rayon {radius} km","radiusResults":"{n} résultat(s) dans un rayon de {radius} km","distanceFromPoint":"à {distance}","locationChecking":"Vérification de la localisation…"});
Object.assign(I18N.en,{"searchPrompt":"Search by name and/or geographic area, with a real distance limit.","nearMeHint":"Uses your current position instead of a city.","searchRadius":"Search radius","radiusHint":"Applied around the city or your current position.","locationDisabled":"Location services are disabled on this phone.","locationPermissionDenied":"BannerLab is not allowed to use your location.","locationUnavailable":"Location unavailable. Check that phone location services are enabled.","locationTimeout":"Location could not be acquired in time. Check that location services are enabled.","openLocationSettings":"Enable location","openAppSettings":"Open app settings","cityNoCoordinates":"“{city}” was found, but its position cannot be used.","cityUsingRadius":"Using: {city} · {radius} km radius","radiusResults":"{n} result(s) within {radius} km","distanceFromPoint":"{distance} away","locationChecking":"Checking location services…"});
Object.assign(I18N.es,{"searchPrompt":"Busca por nombre y/o zona geográfica con un límite de distancia real.","nearMeHint":"Usa tu posición actual en lugar de una ciudad.","searchRadius":"Radio de búsqueda","radiusHint":"Se aplica alrededor de la ciudad o de tu posición.","locationDisabled":"La ubicación del teléfono está desactivada.","locationPermissionDenied":"BannerLab no tiene permiso para usar tu ubicación.","locationUnavailable":"Ubicación no disponible. Comprueba que la ubicación del teléfono esté activada.","locationTimeout":"No se pudo obtener la ubicación a tiempo. Comprueba que esté activada.","openLocationSettings":"Activar ubicación","openAppSettings":"Abrir ajustes de la app","cityNoCoordinates":"Se encontró « {city} », pero no se puede usar su posición.","cityUsingRadius":"Lugar usado: {city} · radio {radius} km","radiusResults":"{n} resultado(s) en un radio de {radius} km","distanceFromPoint":"a {distance}","locationChecking":"Comprobando ubicación…"});
Object.assign(I18N.fr,{"publisherSessionReady":"Session enregistrée dans Documents/RedactedBannerLab. Ouverture de Mission Authoring…","publisherSessionFileText":"RBL enregistre automatiquement la session dans Documents/RedactedBannerLab.","publisherSessionDialog":"Session Publisher","chromeSessionHint":"Chrome : lance le favori RBL Publisher. La première fois, choisis RBL_Current_Session.rblpub.json ; ensuite Chrome réutilise ce fichier.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement. Charge RBL_Current_Session.rblpub.json si la session courante n’est pas déjà connue.","publisherCurrentFile":"Fichier courant : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"publisherSessionReady":"Session saved in Documents/RedactedBannerLab. Opening Mission Authoring…","publisherSessionFileText":"RBL automatically saves the session in Documents/RedactedBannerLab.","publisherSessionDialog":"Publisher session","chromeSessionHint":"Chrome: run the RBL Publisher bookmark. The first time choose RBL_Current_Session.rblpub.json; Chrome will reuse that file afterwards.","firefoxSessionHint":"Firefox: Publisher opens automatically. Load RBL_Current_Session.rblpub.json if the current session is not already known.","publisherCurrentFile":"Current file: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"publisherSessionReady":"Sesión guardada en Documents/RedactedBannerLab. Abriendo Mission Authoring…","publisherSessionFileText":"RBL guarda automáticamente la sesión en Documents/RedactedBannerLab.","publisherSessionDialog":"Sesión Publisher","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. La primera vez elige RBL_Current_Session.rblpub.json; después Chrome reutilizará ese archivo.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente. Carga RBL_Current_Session.rblpub.json si la sesión actual aún no está disponible.","publisherCurrentFile":"Archivo actual: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeFileText":"RBL enregistre directement le Publisher dans Documents/RedactedBannerLab. Aucun partage Android n’est nécessaire.","chromeSaveFile":"Enregistrer le Publisher","chromeFileDone":"Publisher enregistré","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher enregistré dans Documents/RedactedBannerLab.","chromeFileWriteFail":"Impossible d’écrire le Publisher dans Documents/RedactedBannerLab.","chromeSelectFileHint":"Dans Chrome, sélectionne : Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Pour la session : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"chromeFileText":"RBL saves Publisher directly into Documents/RedactedBannerLab. No Android share sheet is needed.","chromeSaveFile":"Save Publisher","chromeFileDone":"Publisher saved","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher saved in Documents/RedactedBannerLab.","chromeFileWriteFail":"Unable to write Publisher into Documents/RedactedBannerLab.","chromeSelectFileHint":"In Chrome select: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"For the session: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"chromeFileText":"RBL guarda Publisher directamente en Documents/RedactedBannerLab. No hace falta la hoja de compartir de Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher guardado en Documents/RedactedBannerLab.","chromeFileWriteFail":"No se puede escribir Publisher en Documents/RedactedBannerLab.","chromeSelectFileHint":"En Chrome selecciona: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Para la sesión: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeSessionHint":"Chrome : lance le favori RBL Publisher. Pour chaque nouvelle bannière préparée, Chrome te demandera explicitement RBL_Current_Session.rblpub.json. Ensuite rien à refaire entre les missions.","chromeTestText":"RBL ouvre Mission Authoring. Tape RBL puis lance le favori. Chrome te demandera le Publisher, puis le JSON courant. Le JSON sera redemandé à chaque nouvelle bannière, jamais entre les missions.","chromeSetupSuccessText":"Chrome est prêt. Le Publisher reste mémorisé ; le fichier JSON de la bannière sera choisi explicitement à chaque nouvelle session pour éviter tout ancien projet fantôme.","chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.en,{"chromeSessionHint":"Chrome: run the RBL Publisher bookmark. For every newly prepared banner, Chrome will explicitly ask for RBL_Current_Session.rblpub.json. Nothing else is required between missions.","chromeTestText":"RBL opens Mission Authoring. Type RBL and run the bookmark. Chrome asks for Publisher, then the current JSON. The JSON is requested for each new banner, never between missions.","chromeSetupSuccessText":"Chrome is ready. Publisher stays remembered; the banner JSON is explicitly selected for each new session so stale projects cannot be reused silently.","chromeCurrentSessionHint":"For each new banner: choose Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.es,{"chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. Para cada nuevo mosaico preparado, Chrome pedirá explícitamente RBL_Current_Session.rblpub.json. No habrá que repetir nada entre misiones.","chromeTestText":"RBL abre Mission Authoring. Escribe RBL y ejecuta el favorito. Chrome pide Publisher y después el JSON actual. El JSON se vuelve a pedir para cada nuevo mosaico, nunca entre misiones.","chromeSetupSuccessText":"Chrome está listo. Publisher queda memorizado; el JSON del mosaico se selecciona explícitamente en cada nueva sesión para evitar proyectos antiguos.","chromeCurrentSessionHint":"Para cada nuevo mosaico: elige Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Retour au navigateur sans recharger Mission Authoring…","chromeResumeHint":"Chrome est simplement remis au premier plan. Le Publisher recharge automatiquement RBL_Current_Session.rblpub.json si l’autorisation est encore valide.","firefoxResumeHint":"Firefox est simplement remis au premier plan afin de conserver la session Mission Authoring.","browserResumeFallback":"Impossible de reprendre le navigateur existant. Ouverture de Mission Authoring en secours.","publisherAutoRefresh":"Le Publisher surveille désormais le fichier de session courant et recharge automatiquement une nouvelle bannière."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Returning to the browser without reloading Mission Authoring…","chromeResumeHint":"Chrome is only brought back to the foreground. Publisher automatically reloads RBL_Current_Session.rblpub.json while permission remains valid.","firefoxResumeHint":"Firefox is only brought back to the foreground to preserve the Mission Authoring session.","browserResumeFallback":"Could not resume the existing browser. Opening Mission Authoring as fallback.","publisherAutoRefresh":"Publisher now watches the current session file and automatically reloads a newly prepared banner."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Volviendo al navegador sin recargar Mission Authoring…","chromeResumeHint":"Chrome solo vuelve al primer plano. Publisher recarga automáticamente RBL_Current_Session.rblpub.json mientras el permiso siga válido.","firefoxResumeHint":"Firefox solo vuelve al primer plano para conservar la sesión de Mission Authoring.","browserResumeFallback":"No se puede reanudar el navegador existente. Se abre Mission Authoring como alternativa.","publisherAutoRefresh":"Publisher ahora vigila el archivo de sesión actual y recarga automáticamente una nueva pancarta."});
Object.assign(I18N.fr,{"flowLocked":"Édition de la fresque verrouillée","flowLockedText":"L’étape {step} est active. Sélectionne « 1 Fresque » pour modifier l’image, les textes ou le cadrage.","returnFresco":"Sélectionne 1 Fresque pour modifier","flowLockedToast":"Retourne sur l’étape 1 Fresque pour modifier la bannière."});
Object.assign(I18N.en,{"flowLocked":"Banner editing locked","flowLockedText":"Step {step} is active. Select “1 Banner” to edit the image, text or framing.","returnFresco":"Select 1 Banner to edit","flowLockedToast":"Return to step 1 Banner to edit the banner."});
Object.assign(I18N.es,{"flowLocked":"Edición del mosaico bloqueada","flowLockedText":"El paso {step} está activo. Selecciona « 1 Mosaico » para modificar imagen, texto o encuadre.","returnFresco":"Selecciona 1 Mosaico para editar","flowLockedToast":"Vuelve al paso 1 Mosaico para editar el mosaico."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Ouverture de l’onglet Mission Authoring RBL…","chromeResumeHint":"Chrome réutilise désormais le même onglet Mission Authoring réservé à RBL.","firefoxResumeHint":"Ouverture de Mission Authoring dans le navigateur de publication.","browserResumeFallback":"Impossible de réutiliser l’onglet RBL. Ouverture du navigateur en secours.","publisherTabReuse":"RBL utilise un identifiant d’application navigateur stable pour réutiliser le même onglet."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Opening the RBL Mission Authoring tab…","chromeResumeHint":"Chrome now reuses the same Mission Authoring tab reserved for RBL.","firefoxResumeHint":"Opening Mission Authoring in the publishing browser.","browserResumeFallback":"Could not reuse the RBL tab. Opening the browser as fallback.","publisherTabReuse":"RBL uses a stable browser application ID to reuse the same tab."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Abriendo la pestaña Mission Authoring de RBL…","chromeResumeHint":"Chrome reutiliza ahora la misma pestaña Mission Authoring reservada para RBL.","firefoxResumeHint":"Abriendo Mission Authoring en el navegador de publicación.","browserResumeFallback":"No se puede reutilizar la pestaña RBL. Abriendo el navegador como alternativa.","publisherTabReuse":"RBL usa un identificador de aplicación del navegador estable para reutilizar la misma pestaña."});
Object.assign(I18N.fr,{"todo":"À faire","history":"Historique","inProgress":"En cours","addTodo":"Ajouter à À faire","removeTodo":"Retirer de À faire","noTodo":"Aucune fresque à faire. Pour l’instant tu es raisonnable.","noHistory":"Aucune fresque jouée. Le dino s’ennuie.","bannerMap":"Carte du parcours","openMap":"Voir la carte","navigateStart":"Itinéraire vers le départ","startUnavailable":"Point de départ indisponible.","mapUnavailable":"Bannergress ne fournit pas de coordonnées exploitables pour cette fresque.","startPoint":"Départ","missionStart":"Mission {n}","shareGroup":"Partager / groupe","shareProgress":"Partager la progression","shareBanner":"Partager la fresque","shareIntro":"Le QR ouvre RBL sur la même fresque et le même numéro de mission. Aucun compte Bannergress n’est utilisé.","copyLink":"Copier le lien RBL","linkCopied":"Lien RBL copié","shareNow":"Partager","bannergressPage":"Voir sur Bannergress","joinBanner":"Rejoindre la fresque","joinAtMission":"Rejoindre à la mission {n}","sharedBannerLoaded":"Fresque partagée chargée · mission {n}","sharedBannerError":"Impossible de charger cette fresque partagée : {error}","playStats":"Stats de session","startedAt":"Début","finishedAt":"Fin","elapsed":"Durée active","estimatedDistance":"Distance estimée","missionsDone":"Missions terminées","paused":"En pause","playing":"En cours","completedBanner":"Terminée","replayBanner":"Rejouer","resumeFromHistory":"Reprendre","groupNoServer":"Mode groupe sans serveur : partage simplement le QR/lien à nouveau si le groupe change de mission.","publicOnly":"Recherche et données publiques Bannergress uniquement · aucune connexion nécessaire.","routePoints":"{n} points sur le parcours"});
Object.assign(I18N.en,{"todo":"To do","history":"History","inProgress":"In progress","addTodo":"Add to To do","removeTodo":"Remove from To do","noTodo":"No banners to do. Suspiciously reasonable.","noHistory":"No played banners yet. The dino is bored.","bannerMap":"Route map","openMap":"View map","navigateStart":"Navigate to start","startUnavailable":"Start point unavailable.","mapUnavailable":"Bannergress does not provide usable coordinates for this banner.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Share / group","shareProgress":"Share progress","shareBanner":"Share banner","shareIntro":"The QR opens RBL on the same banner and mission number. No Bannergress account is used.","copyLink":"Copy RBL link","linkCopied":"RBL link copied","shareNow":"Share","bannergressPage":"Open on Bannergress","joinBanner":"Join banner","joinAtMission":"Join at mission {n}","sharedBannerLoaded":"Shared banner loaded · mission {n}","sharedBannerError":"Could not load shared banner: {error}","playStats":"Session stats","startedAt":"Started","finishedAt":"Finished","elapsed":"Active time","estimatedDistance":"Estimated distance","missionsDone":"Missions done","paused":"Paused","playing":"In progress","completedBanner":"Completed","replayBanner":"Play again","resumeFromHistory":"Resume","groupNoServer":"Serverless group mode: share the QR/link again if the group moves to another mission.","publicOnly":"Public Bannergress search/data only · no sign-in required.","routePoints":"{n} route points"});
Object.assign(I18N.es,{"todo":"Por hacer","history":"Historial","inProgress":"En curso","addTodo":"Añadir a Por hacer","removeTodo":"Quitar de Por hacer","noTodo":"No hay mosaicos pendientes. Sospechosamente razonable.","noHistory":"No hay mosaicos jugados. El dino se aburre.","bannerMap":"Mapa del recorrido","openMap":"Ver mapa","navigateStart":"Ir al punto de inicio","startUnavailable":"Punto de inicio no disponible.","mapUnavailable":"Bannergress no proporciona coordenadas utilizables para este mosaico.","startPoint":"Inicio","missionStart":"Misión {n}","shareGroup":"Compartir / grupo","shareProgress":"Compartir progreso","shareBanner":"Compartir mosaico","shareIntro":"El QR abre RBL en el mismo mosaico y número de misión. No se usa ninguna cuenta Bannergress.","copyLink":"Copiar enlace RBL","linkCopied":"Enlace RBL copiado","shareNow":"Compartir","bannergressPage":"Abrir en Bannergress","joinBanner":"Unirse al mosaico","joinAtMission":"Unirse en la misión {n}","sharedBannerLoaded":"Mosaico compartido cargado · misión {n}","sharedBannerError":"No se puede cargar el mosaico compartido: {error}","playStats":"Estadísticas de sesión","startedAt":"Inicio","finishedAt":"Fin","elapsed":"Tiempo activo","estimatedDistance":"Distancia estimada","missionsDone":"Misiones terminadas","paused":"En pausa","playing":"En curso","completedBanner":"Terminado","replayBanner":"Jugar otra vez","resumeFromHistory":"Reanudar","groupNoServer":"Modo grupo sin servidor: comparte de nuevo el QR/enlace si el grupo cambia de misión.","publicOnly":"Solo búsqueda/datos públicos de Bannergress · no hace falta iniciar sesión.","routePoints":"{n} puntos de recorrido"});
Object.assign(I18N.fr,{"uselessStats":"Stats inutiles","loadingStats":"Calcul des trucs dont personne n’avait besoin…","statsUnavailable":"Pas assez de coordonnées pour calculer les stats inutiles.","bgDistance":"Distance Bannergress","calculatedTrack":"Tracé calculé","walkingEstimate":"Marche théorique","routeSteps":"Étapes","uniquePlaces":"Lieux distincts","revisitedPlaces":"Passages répétés","stepsPerKm":"Étapes / km","avgMissionDistance":"Moyenne / mission","longestMission":"Mission la plus longue","longestLeg":"Plus long tronçon","betweenMissions":"Transitions inter-missions","detourFactor":"Coefficient de détour","routeCoverage":"Couverture carto","missionShort":"M{n}","straightLine":"Départ → arrivée","funStatsDisclaimer":"Calculs géométriques entre les points Bannergress, pas un itinéraire routier. Donc oui, c’est scientifiquement approximatif et parfaitement satisfaisant pour des stats inutiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Stats inutiles","hideUselessStats":"Masquer les stats","statsLoaded":"Stats calculées"});
Object.assign(I18N.en,{"uselessStats":"Useless stats","loadingStats":"Calculating things nobody asked for…","statsUnavailable":"Not enough coordinates to calculate useless stats.","bgDistance":"Bannergress distance","calculatedTrack":"Calculated track","walkingEstimate":"Theoretical walking","routeSteps":"Steps","uniquePlaces":"Unique places","revisitedPlaces":"Repeated visits","stepsPerKm":"Steps / km","avgMissionDistance":"Average / mission","longestMission":"Longest mission","longestLeg":"Longest leg","betweenMissions":"Between-mission transitions","detourFactor":"Detour factor","routeCoverage":"Map coverage","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"Geometric calculations between Bannergress points, not a road route. Scientifically approximate, therefore ideal for useless stats.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Useless stats","hideUselessStats":"Hide stats","statsLoaded":"Stats calculated"});
Object.assign(I18N.es,{"uselessStats":"Estadísticas inútiles","loadingStats":"Calculando cosas que nadie necesitaba…","statsUnavailable":"No hay suficientes coordenadas para calcular estadísticas inútiles.","bgDistance":"Distancia Bannergress","calculatedTrack":"Recorrido calculado","walkingEstimate":"Caminata teórica","routeSteps":"Etapas","uniquePlaces":"Lugares distintos","revisitedPlaces":"Pasos repetidos","stepsPerKm":"Etapas / km","avgMissionDistance":"Media / misión","longestMission":"Misión más larga","longestLeg":"Tramo más largo","betweenMissions":"Transiciones entre misiones","detourFactor":"Factor de desvío","routeCoverage":"Cobertura cartográfica","missionShort":"M{n}","straightLine":"Inicio → final","funStatsDisclaimer":"Cálculos geométricos entre puntos Bannergress, no una ruta vial. Científicamente aproximado, perfecto para estadísticas inútiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Estadísticas inútiles","hideUselessStats":"Ocultar estadísticas","statsLoaded":"Estadísticas calculadas"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne RBL","walkingEstimate":"Temps piéton RBL","directGeometric":"Distance directe cumulée","routingDetour":"Détour du réseau piéton","routingSource":"Routage","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponible · estimation géométrique","routingLoading":"Calcul du vrai parcours piéton…","routingFailed":"Routage piéton indisponible, stats géométriques utilisées.","funStatsDisclaimer":"Distance piétonne calculée par Valhalla sur les chemins OpenStreetMap entre tous les points de la fresque. La distance directe reste affichée pour comparaison. Les chemins OSM peuvent évidemment être faux, parce que même les cartes ont leurs jours sans.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.en,{"calculatedTrack":"RBL walking distance","walkingEstimate":"RBL walking time","directGeometric":"Cumulative direct distance","routingDetour":"Pedestrian network detour","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla unavailable · geometric estimate","routingLoading":"Calculating actual walking route…","routingFailed":"Walking routing unavailable, geometric stats used.","funStatsDisclaimer":"Walking distance calculated by Valhalla over OpenStreetMap paths between every banner point. Direct distance remains for comparison. OSM paths can of course be wrong, because maps also enjoy chaos.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia a pie RBL","walkingEstimate":"Tiempo a pie RBL","directGeometric":"Distancia directa acumulada","routingDetour":"Desvío de la red peatonal","routingSource":"Enrutamiento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla no disponible · estimación geométrica","routingLoading":"Calculando la ruta peatonal real…","routingFailed":"Enrutamiento peatonal no disponible, se usan estadísticas geométricas.","funStatsDisclaimer":"Distancia a pie calculada por Valhalla sobre caminos OpenStreetMap entre todos los puntos del mosaico. La distancia directa se conserva para comparar. OSM también puede equivocarse, porque la perfección era demasiado pedir.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.fr,{"routingNative":"Valhalla + OSM · HTTP natif Android","routingWeb":"Valhalla + OSM · navigateur","routingErrorDetail":"Échec Valhalla : {error}"});
Object.assign(I18N.en,{"routingNative":"Valhalla + OSM · Android native HTTP","routingWeb":"Valhalla + OSM · browser","routingErrorDetail":"Valhalla failed: {error}"});
Object.assign(I18N.es,{"routingNative":"Valhalla + OSM · HTTP nativo Android","routingWeb":"Valhalla + OSM · navegador","routingErrorDetail":"Error de Valhalla: {error}"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance jouable RBL","walkingEstimate":"Temps de marche RBL","routingNative":"Valhalla + OSM · portée Ingress 40 m","routingWeb":"Valhalla + OSM · portée Ingress 40 m","routingDetour":"Écart réseau / direct","funStatsDisclaimer":"RBL cherche un chemin piéton OpenStreetMap passant à moins de 40 m de chaque portail, ce qui correspond mieux à la portée de jeu Ingress que d’obliger le trajet à atteindre la coordonnée exacte du portail. La distance directe cumulée reste affichée pour comparaison.","ingressRadius":"Portée Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.en,{"calculatedTrack":"RBL playable distance","walkingEstimate":"RBL walking time","routingNative":"Valhalla + OSM · 40 m Ingress range","routingWeb":"Valhalla + OSM · 40 m Ingress range","routingDetour":"Network / direct ratio","funStatsDisclaimer":"RBL looks for an OpenStreetMap pedestrian route passing within 40 m of every portal. This better matches actual Ingress interaction range than forcing the route to reach the portal's exact coordinate. Cumulative direct distance remains visible for comparison.","ingressRadius":"Ingress range","ingressRadiusValue":"40 m"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia jugable RBL","walkingEstimate":"Tiempo a pie RBL","routingNative":"Valhalla + OSM · alcance Ingress 40 m","routingWeb":"Valhalla + OSM · alcance Ingress 40 m","routingDetour":"Relación red / directa","funStatsDisclaimer":"RBL busca una ruta peatonal OpenStreetMap que pase a menos de 40 m de cada portal. Esto se ajusta mejor al alcance real de Ingress que obligar la ruta a llegar a la coordenada exacta del portal. La distancia directa acumulada sigue visible para comparar.","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne estimée","walkingEstimate":"Temps de marche estimé","routingNative":"Valhalla + OSM · contrôle tronçon par tronçon","routingWeb":"Valhalla + OSM · contrôle tronçon par tronçon","routingDetour":"Écart réseau / direct","correctedLegs":"Tronçons corrigés","rawValhalla":"Valhalla brut","funStatsDisclaimer":"RBL route chaque liaison portail → portail sur le réseau piéton OpenStreetMap. Chaque tronçon est contrôlé : si Valhalla propose une distance impossible ou un détour manifestement aberrant, seul ce tronçon est remplacé par sa distance directe. C’est une estimation de marche, pas une mesure GPS réelle."});
Object.assign(I18N.en,{"calculatedTrack":"Estimated walking distance","walkingEstimate":"Estimated walking time","routingNative":"Valhalla + OSM · per-leg sanity check","routingWeb":"Valhalla + OSM · per-leg sanity check","routingDetour":"Network / direct ratio","correctedLegs":"Corrected legs","rawValhalla":"Raw Valhalla","funStatsDisclaimer":"RBL routes every portal-to-portal leg on the OpenStreetMap pedestrian network. Each leg is sanity-checked: impossible shortcuts or obviously absurd detours are replaced only for that leg by direct distance. This is a walking estimate, not a GPS measurement."});
Object.assign(I18N.es,{"calculatedTrack":"Distancia peatonal estimada","walkingEstimate":"Tiempo de marcha estimado","routingNative":"Valhalla + OSM · control tramo por tramo","routingWeb":"Valhalla + OSM · control tramo por tramo","routingDetour":"Relación red / directa","correctedLegs":"Tramos corregidos","rawValhalla":"Valhalla bruto","funStatsDisclaimer":"RBL calcula cada tramo portal → portal sobre la red peatonal OpenStreetMap. Cada tramo se valida: atajos imposibles o desvíos claramente absurdos se sustituyen solo en ese tramo por la distancia directa. Es una estimación a pie, no una medición GPS real."});
Object.assign(I18N.fr,{"creditsTitle":"Crédits & remerciements","bannergressThanks":"Merci Bannergress","bannergressThanksText":"La recherche de fresques et plusieurs informations publiques affichées dans Redacted BannerLab s’appuient sur les données publiques de Bannergress. Merci à leur équipe et aux contributeurs pour l’énorme travail réalisé autour des fresques Ingress.","bannergressNoLogin":"RBL n’utilise aucun compte Bannergress : uniquement les données publiques nécessaires à la recherche et à l’affichage des fresques.","independentProject":"Redacted BannerLab est un projet indépendant et n’est ni affilié ni approuvé par Bannergress ou les services officiels Ingress.","visitBannergress":"Découvrir Bannergress","mapCredits":"Cartographie & itinéraires","mapCreditsText":"Les cartes reposent sur OpenStreetMap. Les estimations de parcours piétons utilisent le moteur de routage Valhalla.","rblCreditsFoot":"Merci à tous les outils et contributeurs qui rendent possible cet écosystème autour des missions Ingress."});
Object.assign(I18N.en,{"creditsTitle":"Credits & thanks","bannergressThanks":"Thanks Bannergress","bannergressThanksText":"Banner search and several public details displayed in Redacted BannerLab rely on public Bannergress data. Thanks to their team and contributors for the enormous amount of work around Ingress banners.","bannergressNoLogin":"RBL does not use a Bannergress account: only public data required for banner search and display.","independentProject":"Redacted BannerLab is an independent project and is not affiliated with or endorsed by Bannergress or official Ingress services.","visitBannergress":"Visit Bannergress","mapCredits":"Maps & routing","mapCreditsText":"Maps use OpenStreetMap data. Pedestrian route estimates use the Valhalla routing engine.","rblCreditsFoot":"Thanks to all the tools and contributors that make this Ingress mission ecosystem possible."});
Object.assign(I18N.es,{"creditsTitle":"Créditos y agradecimientos","bannergressThanks":"Gracias Bannergress","bannergressThanksText":"La búsqueda de mosaicos y varios datos públicos mostrados en Redacted BannerLab se apoyan en datos públicos de Bannergress. Gracias a su equipo y a sus colaboradores por el enorme trabajo realizado alrededor de los mosaicos de Ingress.","bannergressNoLogin":"RBL no utiliza ninguna cuenta Bannergress: solo los datos públicos necesarios para buscar y mostrar mosaicos.","independentProject":"Redacted BannerLab es un proyecto independiente y no está afiliado ni aprobado por Bannergress ni por los servicios oficiales de Ingress.","visitBannergress":"Visitar Bannergress","mapCredits":"Mapas y rutas","mapCreditsText":"Los mapas utilizan datos de OpenStreetMap. Las estimaciones de rutas peatonales usan el motor Valhalla.","rblCreditsFoot":"Gracias a todas las herramientas y colaboradores que hacen posible este ecosistema de misiones de Ingress."});
Object.assign(I18N.fr,{"layersTitle":"Images & calques","layersDesc":"Gère ici le fond et toutes les images superposées. Les miniatures permettent d’identifier rapidement le bon calque, puis de le sélectionner, masquer, réordonner ou grouper.","backgroundLayer":"Fond principal","addBackground":"Ajouter / remplacer le fond","addLayer":"Ajouter un calque","layerName":"Calque image","selected":"Sélectionné","visibleLayer":"Visible","hiddenLayer":"Masqué","moveUp":"Monter","moveDown":"Descendre","groupSelection":"Sélection de groupe","group":"Grouper","ungroup":"Dégrouper","groupNeedTwo":"Sélectionne au moins deux calques à grouper.","groupCreated":"Calques groupés","groupRemoved":"Groupe supprimé","deleteLayer":"Supprimer le calque","layerDeleted":"Calque supprimé","layerAdded":"Calque ajouté","backgroundReplaced":"Fond remplacé","backgroundMissing":"Aucun fond principal","backgroundFixed":"Le fond reste toujours sous les autres calques.","groupHint":"Coche plusieurs calques puis appuie sur Grouper. Un groupe se déplace, zoome et tourne ensemble.","layerOrder":"Ordre des calques","layerTransform":"Transformer le calque","groupTransform":"Transformer le groupe","renameLayer":"Renommer","duplicateLayer":"Dupliquer","layerDuplicated":"Calque dupliqué","histAddLayer":"Ajouter calque","histDeleteLayer":"Supprimer calque","histReorderLayer":"Réordonner calque","histGroupLayers":"Grouper calques","histUngroupLayers":"Dégrouper calques","histVisibilityLayer":"Visibilité calque","histRenameLayer":"Renommer calque","histDuplicateLayer":"Dupliquer calque"});
Object.assign(I18N.en,{"layersTitle":"Images & layers","layersDesc":"Manage the background and all overlaid images here. Thumbnails help identify the right layer, then select, hide, reorder or group it.","backgroundLayer":"Main background","addBackground":"Add / replace background","addLayer":"Add layer","layerName":"Image layer","selected":"Selected","visibleLayer":"Visible","hiddenLayer":"Hidden","moveUp":"Move up","moveDown":"Move down","groupSelection":"Group selection","group":"Group","ungroup":"Ungroup","groupNeedTwo":"Select at least two layers to group.","groupCreated":"Layers grouped","groupRemoved":"Group removed","deleteLayer":"Delete layer","layerDeleted":"Layer deleted","layerAdded":"Layer added","backgroundReplaced":"Background replaced","backgroundMissing":"No main background","backgroundFixed":"The background always stays below the other layers.","groupHint":"Tick several layers then tap Group. A group moves, zooms and rotates together.","layerOrder":"Layer order","layerTransform":"Transform layer","groupTransform":"Transform group","renameLayer":"Rename","duplicateLayer":"Duplicate","layerDuplicated":"Layer duplicated","histAddLayer":"Add layer","histDeleteLayer":"Delete layer","histReorderLayer":"Reorder layer","histGroupLayers":"Group layers","histUngroupLayers":"Ungroup layers","histVisibilityLayer":"Layer visibility","histRenameLayer":"Rename layer","histDuplicateLayer":"Duplicate layer"});
Object.assign(I18N.es,{"layersTitle":"Imágenes y capas","layersDesc":"Gestiona aquí el fondo y todas las imágenes superpuestas. Las miniaturas ayudan a identificar, seleccionar, ocultar, ordenar o agrupar cada capa.","backgroundLayer":"Fondo principal","addBackground":"Añadir / reemplazar fondo","addLayer":"Añadir capa","layerName":"Capa de imagen","selected":"Seleccionada","visibleLayer":"Visible","hiddenLayer":"Oculta","moveUp":"Subir","moveDown":"Bajar","groupSelection":"Selección de grupo","group":"Agrupar","ungroup":"Desagrupar","groupNeedTwo":"Selecciona al menos dos capas para agrupar.","groupCreated":"Capas agrupadas","groupRemoved":"Grupo eliminado","deleteLayer":"Eliminar capa","layerDeleted":"Capa eliminada","layerAdded":"Capa añadida","backgroundReplaced":"Fondo reemplazado","backgroundMissing":"Sin fondo principal","backgroundFixed":"El fondo siempre permanece debajo de las demás capas.","groupHint":"Marca varias capas y pulsa Agrupar. Un grupo se mueve, amplía y gira junto.","layerOrder":"Orden de capas","layerTransform":"Transformar capa","groupTransform":"Transformar grupo","renameLayer":"Renombrar","duplicateLayer":"Duplicar","layerDuplicated":"Capa duplicada","histAddLayer":"Añadir capa","histDeleteLayer":"Eliminar capa","histReorderLayer":"Reordenar capa","histGroupLayers":"Agrupar capas","histUngroupLayers":"Desagrupar capas","histVisibilityLayer":"Visibilidad capa","histRenameLayer":"Renombrar capa","histDuplicateLayer":"Duplicar capa"});
Object.assign(I18N.fr,{"layerGroupBadge":"Groupe","layerUngroup":"Dégrouper ce groupe","layerSelectHint":"Le calque sélectionné se déplace ensuite directement sur la fresque.","layerOpacity":"Opacité","layerDimensions":"{w} × {h} px","noImageContent":"Ajoute au moins une image avant d’exporter.","groupRelative":"Les réglages ci-dessous transforment tout le groupe ensemble.","groupZoom":"Zoom du groupe","groupRotation":"Rotation du groupe","clearGroupSelection":"Vider la sélection"});
Object.assign(I18N.en,{"layerGroupBadge":"Group","layerUngroup":"Ungroup this group","layerSelectHint":"The selected layer can then be moved directly on the banner.","layerOpacity":"Opacity","layerDimensions":"{w} × {h} px","noImageContent":"Add at least one image before exporting.","groupRelative":"The controls below transform the whole group together.","groupZoom":"Group zoom","groupRotation":"Group rotation","clearGroupSelection":"Clear selection"});
Object.assign(I18N.es,{"layerGroupBadge":"Grupo","layerUngroup":"Desagrupar este grupo","layerSelectHint":"La capa seleccionada se puede mover después directamente sobre el mosaico.","layerOpacity":"Opacidad","layerDimensions":"{w} × {h} px","noImageContent":"Añade al menos una imagen antes de exportar.","groupRelative":"Los controles siguientes transforman todo el grupo junto.","groupZoom":"Zoom del grupo","groupRotation":"Rotación del grupo","clearGroupSelection":"Vaciar selección"});
Object.assign(I18N.fr,{"allLayersTitle":"Calques","allLayersDesc":"Sélectionne l’élément à manipuler. Images et textes restent modifiables depuis leurs menus dédiés.","imageLayersSection":"Images","textLayersSection":"Textes","noExtraImageLayer":"Aucun calque image supplémentaire","noTextLayer":"Aucun calque texte","selectLayer":"Sélectionner","editLayer":"Modifier"});
Object.assign(I18N.en,{"allLayersTitle":"Layers","allLayersDesc":"Select the element you want to manipulate. Images and text remain editable from their dedicated menus.","imageLayersSection":"Images","textLayersSection":"Text","noExtraImageLayer":"No additional image layer","noTextLayer":"No text layer","selectLayer":"Select","editLayer":"Edit"});
Object.assign(I18N.es,{"allLayersTitle":"Capas","allLayersDesc":"Selecciona el elemento que quieres manipular. Las imágenes y los textos siguen editándose desde sus menús dedicados.","imageLayersSection":"Imágenes","textLayersSection":"Textos","noExtraImageLayer":"No hay capas de imagen adicionales","noTextLayer":"No hay capas de texto","selectLayer":"Seleccionar","editLayer":"Editar"});
Object.assign(I18N.fr,{"missionNumberQuestion":"Quel est le numéro de la mission ?"});
Object.assign(I18N.en,{"missionNumberQuestion":"What is the mission number?"});
Object.assign(I18N.es,{"missionNumberQuestion":"¿Cuál es el número de la misión?"});

Object.assign(I18N.fr,{"groupName":"Groupe {n}","groupCount":"{n} calque(s)","creatorBy":"Créé par Zw4nn","communityTitle":"Communauté & support","communityText":"Actualités, aide, bugs, suggestions et échanges autour de Redacted BannerLab.","telegramOpen":"Ouvrir Telegram","reportProblem":"Signaler un problème","reportProblemText":"Copie un diagnostic technique puis ouvre Telegram pour décrire le problème.","copyDiagnostic":"Copier le diagnostic","diagnosticCopied":"Diagnostic copié","diagnosticCopyFailed":"Impossible de copier le diagnostic","diagnosticDescription":"Description du problème :"});
Object.assign(I18N.en,{"groupName":"Group {n}","groupCount":"{n} layer(s)","creatorBy":"Created by Zw4nn","communityTitle":"Community & support","communityText":"News, help, bugs, suggestions and discussion around Redacted BannerLab.","telegramOpen":"Open Telegram","reportProblem":"Report a problem","reportProblemText":"Copy a technical diagnostic, then open Telegram to describe the problem.","copyDiagnostic":"Copy diagnostic","diagnosticCopied":"Diagnostic copied","diagnosticCopyFailed":"Unable to copy diagnostic","diagnosticDescription":"Problem description:"});
Object.assign(I18N.es,{"groupName":"Grupo {n}","groupCount":"{n} capa(s)","creatorBy":"Creado por Zw4nn","communityTitle":"Comunidad y soporte","communityText":"Noticias, ayuda, errores, sugerencias y conversaciones sobre Redacted BannerLab.","telegramOpen":"Abrir Telegram","reportProblem":"Informar de un problema","reportProblemText":"Copia un diagnóstico técnico y abre Telegram para describir el problema.","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","diagnosticCopyFailed":"No se pudo copiar el diagnóstico","diagnosticDescription":"Descripción del problema:"});
Object.assign(I18N.fr,{"portableProject":"Projet portable","portableProjectDesc":"Exporte une seule fresque avec ses images, calques, textes, polices, missions et parcours.","exportProject":"Exporter","shareProject":"Partager","importProject":"Importer un projet","projectExporting":"Préparation du projet…","projectExported":"Projet enregistré","projectShared":"Projet prêt à être partagé","projectImportSuccess":"Projet importé","projectImportInvalid":"Ce fichier n’est pas un projet Redacted BannerLab valide.","projectShareTitle":"Projet Redacted BannerLab","projectImportHint":"Le projet importé est ajouté sans modifier les autres projets.","telegramOpen":"Contacter le support","communityText":"Accède à la communauté et au support directement via le bot Redacted BannerLab.","reportProblemText":"Copie un diagnostic technique puis contacte le support via le bot."});
Object.assign(I18N.en,{"portableProject":"Portable project","portableProjectDesc":"Export one banner with its images, layers, text, fonts, missions and route.","exportProject":"Export","shareProject":"Share","importProject":"Import project","projectExporting":"Preparing project…","projectExported":"Project saved","projectShared":"Project ready to share","projectImportSuccess":"Project imported","projectImportInvalid":"This file is not a valid Redacted BannerLab project.","projectShareTitle":"Redacted BannerLab project","projectImportHint":"The imported project is added without changing your other projects.","telegramOpen":"Contact support","communityText":"Access the community and support directly through the Redacted BannerLab bot.","reportProblemText":"Copy a technical diagnostic, then contact support through the bot."});
Object.assign(I18N.es,{"portableProject":"Proyecto portátil","portableProjectDesc":"Exporta un solo mural con sus imágenes, capas, textos, fuentes, misiones y recorrido.","exportProject":"Exportar","shareProject":"Compartir","importProject":"Importar proyecto","projectExporting":"Preparando proyecto…","projectExported":"Proyecto guardado","projectShared":"Proyecto listo para compartir","projectImportSuccess":"Proyecto importado","projectImportInvalid":"Este archivo no es un proyecto Redacted BannerLab válido.","projectShareTitle":"Proyecto Redacted BannerLab","projectImportHint":"El proyecto importado se añade sin modificar los demás proyectos.","telegramOpen":"Contactar con soporte","communityText":"Accede a la comunidad y al soporte directamente a través del bot de Redacted BannerLab.","reportProblemText":"Copia un diagnóstico técnico y contacta con soporte a través del bot."});
Object.assign(I18N.fr,{"backupTitle":"Sauvegarde & restauration","backupText":"Sauvegarde tous les projets BannerLab, leurs réglages et leurs images dans un JSON portable.","backupFolder":"Dossier de sauvegarde","backupFolderChoose":"Choisir le dossier","backupFolderChange":"Changer le dossier","backupFolderNone":"Aucun dossier choisi","backupFolderReady":"Dossier configuré","backupAuto":"Sauvegarde automatique en arrière-plan","backupAutoHint":"Quand elle est active, BannerLab prépare régulièrement la sauvegarde après tes modifications et la force au passage en arrière-plan.","backupNow":"Sauvegarder maintenant","backupExport":"Exporter le JSON","backupImport":"Importer un JSON","backupWorking":"Création de la sauvegarde…","backupSaved":"Sauvegarde terminée","backupAutoSaved":"Sauvegarde automatique terminée","backupFailed":"Échec de la sauvegarde : {error}","backupNeedFolder":"Choisis d’abord un dossier de sauvegarde.","backupFolderError":"Impossible d’utiliser ce dossier.","backupImported":"Sauvegarde restaurée","backupInvalid":"Ce fichier n’est pas une sauvegarde Redacted BannerLab valide.","backupImportTitle":"Restaurer la sauvegarde","backupImportText":"{n} projet(s) trouvé(s) · sauvegarde du {date}","backupMerge":"Fusionner","backupReplace":"Remplacer tout","backupReplaceWarn":"Remplacer tout supprime les projets présents sur ce téléphone avant la restauration.","backupCancel":"Annuler","backupLast":"Dernière sauvegarde : {date}","backupNever":"Aucune sauvegarde effectuée","backupPortable":"Le JSON contient aussi les images. Il peut donc être volumineux, mais il se suffit à lui-même.","backupNativeOnly":"Le dossier automatique est disponible sur Android. L’export/import JSON reste disponible partout.","backupFolderChosen":"Dossier de sauvegarde enregistré","backupNoChanges":"Aucun changement à sauvegarder."});
Object.assign(I18N.en,{"backupTitle":"Backup & restore","backupText":"Back up all BannerLab projects, settings and images in one portable JSON file.","backupFolder":"Backup folder","backupFolderChoose":"Choose folder","backupFolderChange":"Change folder","backupFolderNone":"No folder selected","backupFolderReady":"Folder configured","backupAuto":"Automatic backup in background","backupAutoHint":"When enabled, BannerLab regularly prepares the backup after your changes and forces a final save when going to the background.","backupNow":"Back up now","backupExport":"Export JSON","backupImport":"Import JSON","backupWorking":"Creating backup…","backupSaved":"Backup complete","backupAutoSaved":"Automatic backup complete","backupFailed":"Backup failed: {error}","backupNeedFolder":"Choose a backup folder first.","backupFolderError":"Unable to use this folder.","backupImported":"Backup restored","backupInvalid":"This file is not a valid Redacted BannerLab backup.","backupImportTitle":"Restore backup","backupImportText":"{n} project(s) found · backup from {date}","backupMerge":"Merge","backupReplace":"Replace all","backupReplaceWarn":"Replace all deletes the projects currently stored on this device before restoring.","backupCancel":"Cancel","backupLast":"Last backup: {date}","backupNever":"No backup yet","backupPortable":"The JSON also contains the images. It can therefore be large, but it is fully self-contained.","backupNativeOnly":"Automatic folder backup is available on Android. JSON export/import remains available everywhere.","backupFolderChosen":"Backup folder saved","backupNoChanges":"No changes to back up."});
Object.assign(I18N.es,{"backupTitle":"Copia de seguridad y restauración","backupText":"Guarda todos los proyectos BannerLab, sus ajustes e imágenes en un JSON portátil.","backupFolder":"Carpeta de copia","backupFolderChoose":"Elegir carpeta","backupFolderChange":"Cambiar carpeta","backupFolderNone":"Ninguna carpeta seleccionada","backupFolderReady":"Carpeta configurada","backupAuto":"Copia automática en segundo plano","backupAutoHint":"Cuando está activa, BannerLab prepara regularmente la copia después de tus cambios y fuerza un guardado al pasar a segundo plano.","backupNow":"Guardar ahora","backupExport":"Exportar JSON","backupImport":"Importar JSON","backupWorking":"Creando copia…","backupSaved":"Copia terminada","backupAutoSaved":"Copia automática terminada","backupFailed":"Error de copia: {error}","backupNeedFolder":"Elige primero una carpeta de copia.","backupFolderError":"No se puede usar esta carpeta.","backupImported":"Copia restaurada","backupInvalid":"Este archivo no es una copia válida de Redacted BannerLab.","backupImportTitle":"Restaurar copia","backupImportText":"{n} proyecto(s) encontrado(s) · copia del {date}","backupMerge":"Fusionar","backupReplace":"Reemplazar todo","backupReplaceWarn":"Reemplazar todo elimina los proyectos presentes en este dispositivo antes de restaurar.","backupCancel":"Cancelar","backupLast":"Última copia: {date}","backupNever":"Aún no hay copia","backupPortable":"El JSON también contiene las imágenes. Puede ser grande, pero es completamente autónomo.","backupNativeOnly":"La copia automática en carpeta está disponible en Android. La exportación/importación JSON sigue disponible en todas partes.","backupFolderChosen":"Carpeta de copia guardada","backupNoChanges":"No hay cambios que guardar."});


Object.assign(I18N.fr,{"studioEdit":"Édition plein écran","studioTitle":"Studio d’édition","studioLayers":"Calques","studioTexts":"Textes","studioTools":"Outils","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"Tout","studioMissionMode":"Mission","studioFrescoMode":"Fresque","studioFullscreen":"Plein écran","studioRotateHint":"6 missions dans la hauteur · les rangées suivantes défilent vers la droite.","studioSelected":"Élément sélectionné","studioNoLayer":"Sélectionne un calque ou un texte sur le côté.","studioGroupSelect":"Sélection groupe","studioGroupNow":"Grouper","studioOpenFull":"Ouvrir le gestionnaire complet","studioOpacity":"Opacité","studioClose":"Quitter le studio","studioPan":"Défilement","studioAddText":"Ajouter un texte","studioNoText":"Aucun texte pour le moment.","studioEditText":"Modifier le texte","studioDuplicateText":"Dupliquer le texte"});
Object.assign(I18N.en,{"studioEdit":"Full-screen edit","studioTitle":"Editing studio","studioLayers":"Layers","studioTexts":"Text","studioTools":"Tools","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"All","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Full screen","studioRotateHint":"6 missions vertically · following rows scroll to the right.","studioSelected":"Selected item","studioNoLayer":"Select a layer or text item from the side.","studioGroupSelect":"Group selection","studioGroupNow":"Group","studioOpenFull":"Open full manager","studioOpacity":"Opacity","studioClose":"Exit studio","studioPan":"Scroll","studioAddText":"Add text","studioNoText":"No text yet.","studioEditText":"Edit text","studioDuplicateText":"Duplicate text"});
Object.assign(I18N.es,{"studioEdit":"Edición a pantalla completa","studioTitle":"Estudio de edición","studioLayers":"Capas","studioTexts":"Textos","studioTools":"Herramientas","studioFit":"6 misiones","studioFitOne":"1 misión","studioFitAll":"Todo","studioMissionMode":"Misión","studioFrescoMode":"Fresco","studioFullscreen":"Pantalla completa","studioRotateHint":"6 misiones en vertical · las filas siguientes se desplazan hacia la derecha.","studioSelected":"Elemento seleccionado","studioNoLayer":"Selecciona una capa o un texto en el lateral.","studioGroupSelect":"Selección de grupo","studioGroupNow":"Agrupar","studioOpenFull":"Abrir gestor completo","studioOpacity":"Opacidad","studioClose":"Salir del estudio","studioPan":"Desplazar","studioAddText":"Añadir texto","studioNoText":"Aún no hay textos.","studioEditText":"Editar texto","studioDuplicateText":"Duplicar texto"});
Object.assign(I18N.fr,{"font":"Police","fontWeight":"Graisse","fontItalic":"Italique","letterSpacing":"Espacement lettres","lineHeight":"Interligne","textAlign":"Alignement","alignLeft":"Gauche","alignCenter":"Centre","alignRight":"Droite","importFont":"Importer une police","fontImported":"Police importée : {name}","fontInvalid":"Cette police n’est pas prise en charge.","fontTooLarge":"Police trop volumineuse (12 Mo max).","textBackground":"Fond du texte","textBackgroundColor":"Couleur du fond","textBackgroundOpacity":"Opacité du fond","textBackgroundPadding":"Marge du fond","textBackgroundRadius":"Arrondi / radius","textTypography":"Typographie"});
Object.assign(I18N.en,{"font":"Font","fontWeight":"Weight","fontItalic":"Italic","letterSpacing":"Letter spacing","lineHeight":"Line height","textAlign":"Alignment","alignLeft":"Left","alignCenter":"Center","alignRight":"Right","importFont":"Import font","fontImported":"Font imported: {name}","fontInvalid":"This font is not supported.","fontTooLarge":"Font is too large (12 MB max).","textBackground":"Text background","textBackgroundColor":"Background color","textBackgroundOpacity":"Background opacity","textBackgroundPadding":"Background padding","textBackgroundRadius":"Corner radius","textTypography":"Typography"});
Object.assign(I18N.es,{"font":"Fuente","fontWeight":"Peso","fontItalic":"Cursiva","letterSpacing":"Espaciado de letras","lineHeight":"Interlineado","textAlign":"Alineación","alignLeft":"Izquierda","alignCenter":"Centro","alignRight":"Derecha","importFont":"Importar fuente","fontImported":"Fuente importada: {name}","fontInvalid":"Esta fuente no es compatible.","fontTooLarge":"La fuente es demasiado grande (12 MB máx.).","textBackground":"Fondo del texto","textBackgroundColor":"Color de fondo","textBackgroundOpacity":"Opacidad del fondo","textBackgroundPadding":"Margen del fondo","textBackgroundRadius":"Radio de esquinas","textTypography":"Tipografía"});
Object.assign(I18N.fr,{
  tutorialHubTitle:'Tutoriels & prise en main',tutorialHubText:'Relance une visite quand tu veux. Redacted peut expliquer seulement la partie qui t’intéresse.',
  tutorialOpen:'Voir les tutoriels',tutorialWelcomeTitle:'Bienvenue dans Redacted BannerLab',tutorialWelcomeText:'Redacted peut te faire visiter le laboratoire. Deux minutes, quelques boutons et aucun examen à la fin.',
  tutorialStart:'Commencer la visite',tutorialLater:'Plus tard',tutorialNever:'Ne plus afficher',tutorialPrevious:'Précédent',tutorialNext:'Suivant',tutorialUnderstood:'OK, j’ai compris',tutorialClose:'Fermer',tutorialDone:'Tutoriel terminé',tutorialSeen:'Déjà vu',
  tutorialQuick:'Découverte rapide',tutorialQuickDesc:'Les boutons essentiels et le parcours général de BannerLab.',tutorialBanner:'Créer une fresque',tutorialBannerDesc:'Du projet vide jusqu’à l’aperçu et l’export des missions.',
  tutorialLayers:'Images, calques & textes',tutorialLayersDesc:'Fond, images superposées, calques et atelier typographique.',tutorialIitc:'Créer le parcours avec IITC',tutorialIitcDesc:'Installer le Companion, ajouter les portails et synchroniser le tracé.',
  tutorialPublish:'Publier les missions',tutorialPublishDesc:'Préparer les missions puis utiliser le Publisher et Mission Authoring.',tutorialBackup:'Sauvegardes & projets portables',tutorialBackupDesc:'Sauvegarder BannerLab ou partager une seule fresque complète.',
  importRolesHint:'Fond principal = image de base de la fresque · Calque = image supplémentaire superposée.',
  tutProjectTitle:'Tes projets',tutProjectText:'Chaque fresque vit dans son propre projet. Tu peux ensuite l’exporter ou la partager sans embarquer tous les autres.',
  tutNameTitle:'Nom du projet',tutNameText:'Donne un nom reconnaissable à ta fresque. Oui, « test2-final-vraiment-final » fonctionne aussi, mais Redacted désapprouve.',
  tutRowsTitle:'Nombre de rangées',tutRowsText:'Une rangée contient 6 missions. Choisis ici la hauteur finale de ta fresque.',
  tutImageTitle:'Images & calques',tutImageText:'C’est ici que tu importes le fond principal et toutes les images supplémentaires. Ce même écran sert aussi à sélectionner, ordonner, masquer et grouper les calques.',
  tutBackgroundTitle:'Fond principal',tutBackgroundText:'Pour ta première vraie image, utilise Fond principal. Elle remplace l’image de base et couvre toute la fresque.',
  tutExtraLayerTitle:'Ajouter un calque',tutExtraLayerText:'Une seconde image est un calque : elle se superpose au fond et reste déplaçable, redimensionnable et masquable.',
  tutLayersTitle:'Gérer les calques image',tutLayersText:'Les miniatures te montrent immédiatement quel calque tu manipules. Tu peux le sélectionner, changer son ordre, le masquer ou cocher plusieurs images pour les grouper.',
  tutTextTitle:'Texte',tutTextText:'Ajoute du texte, choisis la police, l’espacement, le fond, le radius ou importe ta propre police.',
  tutPreviewTitle:'Aperçu',tutPreviewText:'Vérifie le rendu mission par mission avant l’export. Les recadrages individuels sont déjà appliqués.',
  tutExportTitle:'Exporter',tutExportText:'Quand tout est prêt, BannerLab génère les images 512 × 512 dans le bon ordre.',
  tutStudioTitle:'Studio plein écran',tutStudioText:'Pour les gros doigts officiellement reconnus par le laboratoire : édition plein écran, calques latéraux et navigation plus confortable.',
  tutFlowTitle:'Les 4 étapes',tutFlowText:'Fresque → Parcours → Missions → Publier. BannerLab te guide dans cet ordre sans t’obliger à tout faire d’un coup.',
  tutRouteTitle:'Parcours',tutRouteText:'Le parcours relie tes missions aux vrais portails Ingress. Le Companion IITC fait le gros du travail directement sur la carte.',
  tutCompanionTitle:'IITC Companion',tutCompanionText:'Le Companion accompagne le projet dans IITC : mission active, portails, actions et statistiques de marche.',
  tutInstallCompanionTitle:'Installer le Companion',tutInstallCompanionText:'Installe ou mets à jour le plugin une fois dans IITC Mobile. Ensuite BannerLab peut lui transmettre ton projet.',
  tutOpenIitcTitle:'Ouvrir IITC',tutOpenIitcText:'Ouvre IITC depuis BannerLab : le projet et la mission active sont transmis au Companion.',
  tutAutoRouteTitle:'Passage entre missions',tutAutoRouteText:'La mission suivante peut s’ouvrir automatiquement et reprendre le dernier portail comme premier portail. La case reste réglable ici.',
  tutPortalListTitle:'Tes portails',tutPortalListText:'Les portails ajoutés dans IITC reviennent ici avec leur GUID, coordonnées, ordre et action. Le tracé peut donc être reconstruit.',
  tutMissionsTitle:'Préparer les missions',tutMissionsText:'Avant publication, renseigne la description commune et vérifie chaque mission.',
  tutMissionDescTitle:'Description obligatoire',tutMissionDescText:'Cette description sert de base aux missions. BannerLab signale ce qui manque avant d’autoriser la publication.',
  tutPublishTitle:'Publier',tutPublishText:'Quand parcours et descriptions sont prêts, passe ici. Le Publisher prépare les missions ; la soumission finale reste volontairement dans l’outil officiel.',
  tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prépare les données et ouvre le flux de publication. Après soumission, utilise « J’ai soumis » pour vérifier l’état publié et poursuivre la synchro.',
  tutInfoTitle:'Réglages, aide & support',tutInfoText:'La roue Réglages & infos contient la langue, les sauvegardes, les tutoriels et l’accès au support via le bot Redacted BannerLab.',
  tutBackupTitle:'Sauvegarde complète',tutBackupText:'La sauvegarde JSON complète contient tous tes projets, réglages, images et polices. Sur Android, tu peux aussi choisir un dossier d’autosauvegarde.',
  tutPortableTitle:'Projet portable',tutPortableText:'Ici tu peux exporter, partager ou importer une seule fresque avec ses images, textes, polices, missions et parcours.',
  tutSupportTitle:'Besoin d’aide ?',tutSupportText:'Copie le diagnostic si nécessaire puis contacte le support. Le bot donne aussi accès au canal et au groupe de discussion.'
});
Object.assign(I18N.en,{
  tutorialHubTitle:'Tutorials & getting started',tutorialHubText:'Restart a guided tour whenever you want. Redacted can explain only the part you need.',tutorialOpen:'View tutorials',
  tutorialWelcomeTitle:'Welcome to Redacted BannerLab',tutorialWelcomeText:'Redacted can show you around the lab. Two minutes, a few buttons and no exam at the end.',tutorialStart:'Start the tour',tutorialLater:'Later',tutorialNever:'Do not show again',tutorialPrevious:'Previous',tutorialNext:'Next',tutorialUnderstood:'OK, got it',tutorialClose:'Close',tutorialDone:'Tutorial complete',tutorialSeen:'Seen',
  tutorialQuick:'Quick tour',tutorialQuickDesc:'The essential controls and the overall BannerLab workflow.',tutorialBanner:'Create a banner',tutorialBannerDesc:'From a project to previewing and exporting the missions.',tutorialLayers:'Images, layers & text',tutorialLayersDesc:'Background, overlaid images, layers and typography tools.',tutorialIitc:'Build the route with IITC',tutorialIitcDesc:'Install Companion, add portals and sync the route.',tutorialPublish:'Publish missions',tutorialPublishDesc:'Prepare missions, then use Publisher and Mission Authoring.',tutorialBackup:'Backups & portable projects',tutorialBackupDesc:'Back up BannerLab or share one complete banner.',
  importRolesHint:'Main background = base banner image · Layer = an additional overlaid image.',tutProjectTitle:'Your projects',tutProjectText:'Each banner lives in its own project. You can export or share it without taking every other project along.',tutNameTitle:'Project name',tutNameText:'Give your banner a recognizable name.',tutRowsTitle:'Number of rows',tutRowsText:'One row contains 6 missions. Choose the final banner height here.',tutImageTitle:'Images & layers',tutImageText:'Import the main background and additional images here. This same screen also selects, orders, hides and groups image layers.',tutBackgroundTitle:'Main background',tutBackgroundText:'For your first real image, use Main background. It replaces the base image and covers the banner.',tutExtraLayerTitle:'Add a layer',tutExtraLayerText:'A second image is a layer: it sits over the background and remains movable, resizable and hideable.',tutLayersTitle:'Manage image layers',tutLayersText:'Thumbnails show which image layer you are manipulating. Select it, reorder it, hide it or tick several images to group them.',tutTextTitle:'Text',tutTextText:'Add text, choose fonts, spacing, background, radius or import your own font.',tutPreviewTitle:'Preview',tutPreviewText:'Check every mission before export. Individual framing is already applied.',tutExportTitle:'Export',tutExportText:'When ready, BannerLab creates the 512 × 512 mission images in the correct order.',tutStudioTitle:'Full-screen studio',tutStudioText:'A more comfortable full-screen editor with side controls and large touch targets.',tutFlowTitle:'The 4 steps',tutFlowText:'Banner → Route → Missions → Publish. BannerLab follows this workflow.',tutRouteTitle:'Route',tutRouteText:'The route connects missions to real Ingress portals. IITC Companion does the map work.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion carries the active project, mission, portals, actions and walking stats into IITC.',tutInstallCompanionTitle:'Install Companion',tutInstallCompanionText:'Install or update the userscript once in IITC Mobile.',tutOpenIitcTitle:'Open IITC',tutOpenIitcText:'Open IITC from BannerLab so the project and active mission are passed to Companion.',tutAutoRouteTitle:'Moving between missions',tutAutoRouteText:'The next mission can open automatically and reuse the previous last portal as its first portal.',tutPortalListTitle:'Your portals',tutPortalListText:'Portals return with GUID, coordinates, order and action, so the route can be reconstructed.',tutMissionsTitle:'Prepare missions',tutMissionsText:'Before publishing, provide the common description and check each mission.',tutMissionDescTitle:'Required description',tutMissionDescText:'BannerLab reports missing information before publication is allowed.',tutPublishTitle:'Publish',tutPublishText:'When routes and descriptions are ready, continue here. Final submission stays in the official tool.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepares the mission data and publication flow. After submission, use “I submitted” to verify the published state.',tutInfoTitle:'Settings, help & support',tutInfoText:'Settings & info contains language, backups, tutorials and support through the Redacted BannerLab bot.',tutBackupTitle:'Full backup',tutBackupText:'The full JSON includes all projects, settings, images and fonts. Android can also use an automatic backup folder.',tutPortableTitle:'Portable project',tutPortableText:'Export, share or import one banner with images, text, fonts, missions and route.',tutSupportTitle:'Need help?',tutSupportText:'Copy the diagnostic if needed, then contact support. The bot also links to the channel and discussion group.'
});
Object.assign(I18N.es,{
  tutorialHubTitle:'Tutoriales y primeros pasos',tutorialHubText:'Vuelve a iniciar una visita cuando quieras. Redacted puede explicar solo la parte que necesites.',tutorialOpen:'Ver tutoriales',tutorialWelcomeTitle:'Bienvenido a Redacted BannerLab',tutorialWelcomeText:'Redacted puede enseñarte el laboratorio. Dos minutos, algunos botones y ningún examen al final.',tutorialStart:'Empezar la visita',tutorialLater:'Más tarde',tutorialNever:'No volver a mostrar',tutorialPrevious:'Anterior',tutorialNext:'Siguiente',tutorialUnderstood:'OK, entendido',tutorialClose:'Cerrar',tutorialDone:'Tutorial terminado',tutorialSeen:'Visto',tutorialQuick:'Descubrimiento rápido',tutorialQuickDesc:'Los controles esenciales y el flujo general de BannerLab.',tutorialBanner:'Crear un mosaico',tutorialBannerDesc:'Desde el proyecto hasta la vista previa y exportación.',tutorialLayers:'Imágenes, capas y textos',tutorialLayersDesc:'Fondo, imágenes superpuestas, capas y tipografía.',tutorialIitc:'Crear el recorrido con IITC',tutorialIitcDesc:'Instalar Companion, añadir portales y sincronizar.',tutorialPublish:'Publicar misiones',tutorialPublishDesc:'Preparar misiones y usar Publisher.',tutorialBackup:'Copias y proyectos portátiles',tutorialBackupDesc:'Guardar BannerLab o compartir un solo mosaico completo.',importRolesHint:'Fondo principal = imagen base · Capa = imagen adicional superpuesta.',tutProjectTitle:'Tus proyectos',tutProjectText:'Cada mosaico vive en su propio proyecto y puede exportarse por separado.',tutNameTitle:'Nombre del proyecto',tutNameText:'Pon un nombre reconocible a tu mosaico.',tutRowsTitle:'Número de filas',tutRowsText:'Una fila contiene 6 misiones. Elige aquí la altura final.',tutImageTitle:'Imágenes y capas',tutImageText:'Aquí importas el fondo principal y las imágenes adicionales. Esta misma pantalla sirve para seleccionar, ordenar, ocultar y agrupar capas.',tutBackgroundTitle:'Fondo principal',tutBackgroundText:'Para tu primera imagen real, usa Fondo principal. Sustituye la imagen base.',tutExtraLayerTitle:'Añadir capa',tutExtraLayerText:'Una segunda imagen es una capa superpuesta que se puede mover, redimensionar y ocultar.',tutLayersTitle:'Gestionar capas de imagen',tutLayersText:'Las miniaturas muestran qué capa estás manipulando. Puedes seleccionarla, cambiar el orden, ocultarla o agrupar varias imágenes.',tutTextTitle:'Texto',tutTextText:'Añade texto, cambia fuentes, espaciado, fondo, radio o importa tu propia fuente.',tutPreviewTitle:'Vista previa',tutPreviewText:'Comprueba cada misión antes de exportar.',tutExportTitle:'Exportar',tutExportText:'BannerLab genera las imágenes 512 × 512 en el orden correcto.',tutStudioTitle:'Estudio a pantalla completa',tutStudioText:'Editor más cómodo con controles laterales y objetivos táctiles grandes.',tutFlowTitle:'Las 4 etapas',tutFlowText:'Mosaico → Recorrido → Misiones → Publicar.',tutRouteTitle:'Recorrido',tutRouteText:'El recorrido enlaza las misiones con portales Ingress reales.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion lleva proyecto, misión, portales, acciones y estadísticas a IITC.',tutInstallCompanionTitle:'Instalar Companion',tutInstallCompanionText:'Instala o actualiza el plugin una vez en IITC Mobile.',tutOpenIitcTitle:'Abrir IITC',tutOpenIitcText:'Abre IITC desde BannerLab para transmitir proyecto y misión activa.',tutAutoRouteTitle:'Paso entre misiones',tutAutoRouteText:'La siguiente misión puede abrirse automáticamente y reutilizar el último portal.',tutPortalListTitle:'Tus portales',tutPortalListText:'Los portales vuelven con GUID, coordenadas, orden y acción.',tutMissionsTitle:'Preparar misiones',tutMissionsText:'Antes de publicar, completa la descripción y comprueba cada misión.',tutMissionDescTitle:'Descripción obligatoria',tutMissionDescText:'BannerLab avisa de lo que falta antes de publicar.',tutPublishTitle:'Publicar',tutPublishText:'Cuando todo esté listo, continúa aquí. El envío final se hace en la herramienta oficial.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepara los datos y el flujo de publicación y después verifica el estado publicado.',tutInfoTitle:'Ajustes, ayuda y soporte',tutInfoText:'Ajustes e información contiene idioma, copias, tutoriales y soporte mediante el bot.',tutBackupTitle:'Copia completa',tutBackupText:'El JSON completo incluye proyectos, ajustes, imágenes y fuentes.',tutPortableTitle:'Proyecto portátil',tutPortableText:'Exporta, comparte o importa un solo mosaico completo.',tutSupportTitle:'¿Necesitas ayuda?',tutSupportText:'Copia el diagnóstico si hace falta y contacta con soporte mediante el bot.'
});

Object.assign(I18N.fr,{settingsInfo:'Réglages & infos'});
Object.assign(I18N.en,{settingsInfo:'Settings & info'});
Object.assign(I18N.es,{settingsInfo:'Ajustes e información'});

Object.assign(I18N.fr,{addMissionLayer:'Sur une mission',importMissionSeries:'Importer une série',missionLayer:'Calque de mission',globalLayer:'Calque global',layerScope:'Portée du calque',wholeBanner:'Fresque entière',missionTarget:'Mission associée',fitMode:'Ajustement',fitCover:'Remplir',fitContain:'Contenir',missionBadge:'M{n}',missionLayerHint:'Ce calque reste attaché à la mission {n} et est automatiquement limité à sa case.',missionSeriesTitle:'Importer une série de missions',missionSeriesText:'Associe chaque image à une mission. BannerLab les place et les recadre automatiquement.',missionSeriesDetected:'{n} image(s) détectée(s)',missionSeriesImport:'Importer les calques',missionSeriesTooMany:'Tu as sélectionné plus d’images que de missions. Plusieurs images peuvent être associées à la même mission.',missionLayerAdded:'Image ajoutée à la mission {n}',missionSeriesAdded:'{n} calque(s) de mission ajouté(s)',missionScopeMismatch:'Pour grouper des calques de mission, ils doivent appartenir à la même mission.',missionLayerTutorialTitle:'Calques liés aux missions',missionLayerTutorialText:'Ajoute une image directement à une mission : BannerLab la place, la recadre et la limite automatiquement à cette case. « Importer une série » permet d’affecter 6, 12, 18 images ou plus en une seule fois.'});
Object.assign(I18N.en,{addMissionLayer:'On a mission',importMissionSeries:'Import a series',missionLayer:'Mission layer',globalLayer:'Global layer',layerScope:'Layer scope',wholeBanner:'Whole banner',missionTarget:'Assigned mission',fitMode:'Fit',fitCover:'Fill',fitContain:'Contain',missionBadge:'M{n}',missionLayerHint:'This layer stays attached to mission {n} and is automatically clipped to its tile.',missionSeriesTitle:'Import a mission series',missionSeriesText:'Assign each image to a mission. BannerLab places and crops them automatically.',missionSeriesDetected:'{n} image(s) detected',missionSeriesImport:'Import layers',missionSeriesTooMany:'You selected more images than missions. Multiple images can be assigned to the same mission.',missionLayerAdded:'Image added to mission {n}',missionSeriesAdded:'{n} mission layer(s) added',missionScopeMismatch:'Mission layers can only be grouped when they belong to the same mission.',missionLayerTutorialTitle:'Mission-linked layers',missionLayerTutorialText:'Add an image directly to one mission: BannerLab places, crops and clips it automatically. “Import a series” assigns 6, 12, 18 images or more in one pass.'});
Object.assign(I18N.es,{addMissionLayer:'En una misión',importMissionSeries:'Importar una serie',missionLayer:'Capa de misión',globalLayer:'Capa global',layerScope:'Alcance de la capa',wholeBanner:'Mural completo',missionTarget:'Misión asociada',fitMode:'Ajuste',fitCover:'Rellenar',fitContain:'Contener',missionBadge:'M{n}',missionLayerHint:'Esta capa queda vinculada a la misión {n} y se limita automáticamente a su casilla.',missionSeriesTitle:'Importar una serie de misiones',missionSeriesText:'Asocia cada imagen a una misión. BannerLab las coloca y recorta automáticamente.',missionSeriesDetected:'{n} imagen(es) detectada(s)',missionSeriesImport:'Importar capas',missionSeriesTooMany:'Has seleccionado más imágenes que misiones. Se pueden asociar varias imágenes a la misma misión.',missionLayerAdded:'Imagen añadida a la misión {n}',missionSeriesAdded:'{n} capa(s) de misión añadida(s)',missionScopeMismatch:'Las capas de misión solo se pueden agrupar si pertenecen a la misma misión.',missionLayerTutorialTitle:'Capas vinculadas a misiones',missionLayerTutorialText:'Añade una imagen directamente a una misión: BannerLab la coloca, recorta y limita automáticamente a esa casilla. «Importar una serie» permite asignar 6, 12, 18 imágenes o más de una vez.'});

Object.assign(I18N.fr,{addLayerChoiceTitle:'Ajouter un calque',addLayerChoiceText:'Choisis où ce calque doit vivre. Tu pourras modifier sa portée plus tard.',addLayerWhole:'Sur la fresque complète',addLayerWholeText:'Une image libre sur toute la fresque, déplaçable et redimensionnable.',addLayerOneMission:'Sur une mission',addLayerOneMissionText:'Une image automatiquement placée et limitée à la mission choisie.',addLayerManyMissions:'Sur plusieurs missions',addLayerManyMissionsText:'Importe une série d’images et associe chacune à la mission voulue.',multiSelection:'Sélection multiple',multiSelectionHint:'Coche plusieurs calques pour leur appliquer une action commune, les grouper ou les supprimer.',selectionActions:'Actions sur la sélection',editSelection:'Modifier la sélection',deleteSelection:'Supprimer la sélection',selectedLayersCount:'{n} calque(s) sélectionné(s)',bulkScopeKeep:'Ne pas changer la portée',bulkMissionKeep:'Conserver les missions actuelles',bulkFitKeep:'Ne pas changer l’ajustement',bulkVisibility:'Visibilité',bulkVisibilityKeep:'Ne pas changer',bulkShow:'Afficher',bulkHide:'Masquer',bulkOpacityEnable:'Modifier l’opacité',applyToSelection:'Appliquer aux calques sélectionnés',selectionUpdated:'Calques sélectionnés modifiés',selectionDeleted:'Calques sélectionnés supprimés',deleteSelectionConfirm:'Supprimer définitivement {n} calque(s) sélectionné(s) ?',selectionEmpty:'Sélectionne au moins un calque.',layerScopeHelp:'Fresque complète : le calque peut couvrir toute la bannière. Une mission : il est automatiquement limité à la case choisie. Plusieurs missions : importe une série et affecte chaque image à sa mission.'});
Object.assign(I18N.en,{addLayerChoiceTitle:'Add a layer',addLayerChoiceText:'Choose where this layer belongs. You can change its scope later.',addLayerWhole:'On the whole banner',addLayerWholeText:'A free image over the whole banner, movable and resizable.',addLayerOneMission:'On one mission',addLayerOneMissionText:'An image automatically positioned and clipped to the selected mission.',addLayerManyMissions:'Across several missions',addLayerManyMissionsText:'Import a series of images and assign each one to the mission you want.',multiSelection:'Multiple selection',multiSelectionHint:'Tick several layers to apply a common action, group them or delete them.',selectionActions:'Selection actions',editSelection:'Edit selection',deleteSelection:'Delete selection',selectedLayersCount:'{n} selected layer(s)',bulkScopeKeep:'Keep current scope',bulkMissionKeep:'Keep current missions',bulkFitKeep:'Keep current fit',bulkVisibility:'Visibility',bulkVisibilityKeep:'Do not change',bulkShow:'Show',bulkHide:'Hide',bulkOpacityEnable:'Change opacity',applyToSelection:'Apply to selected layers',selectionUpdated:'Selected layers updated',selectionDeleted:'Selected layers deleted',deleteSelectionConfirm:'Permanently delete {n} selected layer(s)?',selectionEmpty:'Select at least one layer.',layerScopeHelp:'Whole banner: the layer can cover the entire banner. One mission: it is automatically clipped to the chosen mission. Several missions: import a series and assign each image to its mission.'});
Object.assign(I18N.es,{addLayerChoiceTitle:'Añadir una capa',addLayerChoiceText:'Elige dónde debe vivir esta capa. Podrás cambiar su alcance más tarde.',addLayerWhole:'En todo el mosaico',addLayerWholeText:'Una imagen libre sobre todo el mosaico, desplazable y redimensionable.',addLayerOneMission:'En una misión',addLayerOneMissionText:'Una imagen colocada automáticamente y limitada a la misión elegida.',addLayerManyMissions:'En varias misiones',addLayerManyMissionsText:'Importa una serie de imágenes y asigna cada una a la misión que quieras.',multiSelection:'Selección múltiple',multiSelectionHint:'Marca varias capas para aplicarles una acción común, agruparlas o eliminarlas.',selectionActions:'Acciones sobre la selección',editSelection:'Modificar selección',deleteSelection:'Eliminar selección',selectedLayersCount:'{n} capa(s) seleccionada(s)',bulkScopeKeep:'No cambiar el alcance',bulkMissionKeep:'Conservar las misiones actuales',bulkFitKeep:'No cambiar el ajuste',bulkVisibility:'Visibilidad',bulkVisibilityKeep:'No cambiar',bulkShow:'Mostrar',bulkHide:'Ocultar',bulkOpacityEnable:'Modificar opacidad',applyToSelection:'Aplicar a las capas seleccionadas',selectionUpdated:'Capas seleccionadas modificadas',selectionDeleted:'Capas seleccionadas eliminadas',deleteSelectionConfirm:'¿Eliminar definitivamente {n} capa(s) seleccionada(s)?',selectionEmpty:'Selecciona al menos una capa.',layerScopeHelp:'Mosaico completo: la capa puede cubrir todo el mosaico. Una misión: queda limitada automáticamente a la misión elegida. Varias misiones: importa una serie y asigna cada imagen a su misión.'});
Object.assign(I18N.fr,{missionLayerTutorialText:'Appuie sur « Ajouter un calque » puis choisis : fresque complète, une mission ou plusieurs missions. Pour une mission, BannerLab place et limite automatiquement l’image à sa case. Pour plusieurs missions, importe une série et affecte chaque image à la mission voulue.'});
Object.assign(I18N.en,{missionLayerTutorialText:'Tap “Add a layer”, then choose: whole banner, one mission or several missions. For one mission, BannerLab automatically positions and clips the image to its cell. For several missions, import a series and assign each image to the mission you want.'});
Object.assign(I18N.es,{missionLayerTutorialText:'Pulsa «Añadir una capa» y elige: mosaico completo, una misión o varias misiones. Para una misión, BannerLab coloca y limita automáticamente la imagen a su casilla. Para varias misiones, importa una serie y asigna cada imagen a la misión que quieras.'});

// Extended multilingual UI. Rare legacy/technical strings fall back to English.
I18N["pt"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Percurso","missions":"Missões","publish":"Publicar","projects":"Projetos","rows":"Linhas","image":"Imagens","text":"Texto","preview":"Pré-visualização","export":"Exportar","wholeFresco":"Banner completo","oneMission":"Uma missão","search":"Pesquisar","searchBannergress":"Procurar um banner","bannerNameSearch":"Nome / palavra-chave","citySearch":"Cidade","cityPlaceholder":"ex.: Nantes","nearMe":"Perto de mim","nearMeHint":"Usa a tua posição atual em vez de uma cidade.","searchRadius":"Raio de pesquisa","radiusHint":"Aplicado à volta da cidade ou da tua posição atual.","searchReset":"Limpar","searching":"A pesquisar…","locationChecking":"A verificar os serviços de localização…","locationGetting":"A obter a tua localização…","locationReady":"Localização obtida","locationDisabled":"Os serviços de localização estão desativados neste telefone.","locationPermissionDenied":"O BannerLab não tem permissão para usar a tua localização.","locationUnavailable":"Localização indisponível. Verifica se os serviços de localização estão ativos.","locationTimeout":"Não foi possível obter a localização a tempo. Verifica os serviços de localização.","openLocationSettings":"Ativar localização","openAppSettings":"Abrir definições da aplicação","settingsInfo":"Definições e informações","language":"Idioma","newProject":"Novo projeto","myProjects":"Os meus projetos","portableProject":"Projeto portátil","portableProjectDesc":"Exporta um único banner com imagens, camadas, textos, fontes, missões e percurso.","exportProject":"Exportar","shareProject":"Partilhar","importProject":"Importar projeto","projectExporting":"A preparar o projeto…","projectExported":"Projeto guardado","projectShared":"Projeto pronto para partilhar","projectImportSuccess":"Projeto importado","backupTitle":"Cópia de segurança e restauro","backupNow":"Criar cópia agora","backupExport":"Exportar JSON","backupImport":"Importar JSON","communityTitle":"Comunidade e suporte","communityText":"Acede à comunidade e ao suporte através do bot Redacted BannerLab.","reportProblem":"Comunicar um problema","reportProblemText":"Copia o diagnóstico técnico e contacta o suporte através do bot.","telegramOpen":"Contactar suporte","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","addBackground":"Adicionar / substituir fundo","addLayer":"Adicionar camada","layersTitle":"Imagens e camadas","layersDesc":"Gere aqui o fundo e todas as imagens sobrepostas. As miniaturas ajudam a identificar, selecionar, ocultar, reordenar ou agrupar cada camada.","addLayerChoiceTitle":"Adicionar uma camada","addLayerChoiceText":"Escolhe onde esta camada deve ficar. Podes alterar depois.","addLayerWhole":"No banner completo","addLayerWholeText":"Uma imagem livre sobre todo o banner.","addLayerOneMission":"Numa missão","addLayerOneMissionText":"Uma imagem colocada e limitada automaticamente à missão escolhida.","addLayerManyMissions":"Em várias missões","addLayerManyMissionsText":"Importa uma série de imagens e associa cada uma à missão desejada.","multiSelection":"Seleção múltipla","multiSelectionHint":"Seleciona várias camadas para aplicar uma ação comum, agrupar ou eliminar.","editSelection":"Modificar seleção","deleteSelection":"Eliminar seleção","clearGroupSelection":"Limpar seleção","group":"Agrupar","selectedLayersCount":"{n} camada(s) selecionada(s)","layerScope":"Âmbito da camada","wholeBanner":"Banner completo","missionTarget":"Missão associada","fitMode":"Ajuste","fitCover":"Preencher","fitContain":"Conter","layerOpacity":"Opacidade","visible":"Visível","hidden":"Oculto","font":"Tipo de letra","fontWeight":"Peso","fontItalic":"Itálico","letterSpacing":"Espaçamento das letras","lineHeight":"Entrelinha","textAlign":"Alinhamento","alignLeft":"Esquerda","alignCenter":"Centro","alignRight":"Direita","importFont":"Importar tipo de letra","textTypography":"Tipografia","studioTitle":"Estúdio de edição","studioLayers":"Camadas","studioTexts":"Textos","studioTools":"Ferramentas","studioMissionMode":"Missão","studioFrescoMode":"Banner","studioFullscreen":"Ecrã inteiro","studioPan":"Deslocamento","tutorialHubTitle":"Tutoriais e primeiros passos","tutorialHubText":"Reinicia uma visita guiada quando quiseres. Redacted pode explicar só a parte de que precisas.","tutorialQuick":"Visita rápida","tutorialQuickDesc":"Os controlos essenciais e o fluxo geral do BannerLab.","tutorialBanner":"Criar um banner","tutorialBannerDesc":"Do projeto à pré-visualização e exportação das missões.","tutorialLayers":"Imagens, camadas e texto","tutorialLayersDesc":"Fundo, imagens sobrepostas, camadas e ferramentas tipográficas.","tutorialIitc":"Criar o percurso com IITC","tutorialIitcDesc":"Instala o Companion, adiciona portais e sincroniza o percurso.","tutorialPublish":"Publicar missões","tutorialPublishDesc":"Prepara as missões e usa o Publisher e Mission Authoring.","tutorialBackup":"Cópias e projetos portáteis","tutorialBackupDesc":"Guarda o BannerLab ou partilha um banner completo.","tutorialStart":"Começar a visita","tutorialLater":"Mais tarde","tutorialNever":"Não voltar a mostrar","tutorialClose":"Fechar","tutorialNext":"Seguinte","tutorialPrevious":"Anterior","tutorialUnderstood":"OK, percebi","tutorialWelcomeTitle":"Bem-vindo ao Redacted BannerLab","tutorialWelcomeText":"Redacted pode mostrar-te o laboratório. Dois minutos, alguns botões e nenhum exame no fim.","tutInfoTitle":"Definições, ajuda e suporte","tutInfoText":"Definições e informações contém idioma, cópias, tutoriais e suporte através do bot Redacted BannerLab.","tutSupportTitle":"Precisas de ajuda?","tutSupportText":"Copia o diagnóstico se necessário e contacta o suporte. O bot também dá acesso ao canal e ao grupo."});
I18N["de"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Route","missions":"Missionen","publish":"Veröffentlichen","projects":"Projekte","rows":"Reihen","image":"Bilder","text":"Text","preview":"Vorschau","export":"Exportieren","wholeFresco":"Gesamtes Banner","oneMission":"Eine Mission","search":"Suchen","searchBannergress":"Banner suchen","bannerNameSearch":"Name / Stichwort","citySearch":"Stadt","cityPlaceholder":"z. B. Nantes","nearMe":"In meiner Nähe","nearMeHint":"Verwendet deinen aktuellen Standort statt einer Stadt.","searchRadius":"Suchradius","radiusHint":"Gilt rund um die Stadt oder deinen aktuellen Standort.","searchReset":"Zurücksetzen","searching":"Suche…","locationChecking":"Standortdienste werden geprüft…","locationGetting":"Standort wird ermittelt…","locationReady":"Standort ermittelt","locationDisabled":"Die Standortdienste sind auf diesem Telefon deaktiviert.","locationPermissionDenied":"BannerLab darf deinen Standort nicht verwenden.","locationUnavailable":"Standort nicht verfügbar. Prüfe die Standortdienste.","locationTimeout":"Standort konnte nicht rechtzeitig ermittelt werden.","openLocationSettings":"Standort aktivieren","openAppSettings":"App-Einstellungen öffnen","settingsInfo":"Einstellungen & Infos","language":"Sprache","newProject":"Neues Projekt","myProjects":"Meine Projekte","portableProject":"Portables Projekt","portableProjectDesc":"Exportiere ein einzelnes Banner mit Bildern, Ebenen, Texten, Schriften, Missionen und Route.","exportProject":"Exportieren","shareProject":"Teilen","importProject":"Projekt importieren","projectExporting":"Projekt wird vorbereitet…","projectExported":"Projekt gespeichert","projectShared":"Projekt bereit zum Teilen","projectImportSuccess":"Projekt importiert","backupTitle":"Sichern & Wiederherstellen","backupNow":"Jetzt sichern","backupExport":"JSON exportieren","backupImport":"JSON importieren","communityTitle":"Community & Support","communityText":"Community und Support erreichst du direkt über den Redacted BannerLab Bot.","reportProblem":"Problem melden","reportProblemText":"Kopiere die technische Diagnose und kontaktiere den Support über den Bot.","telegramOpen":"Support kontaktieren","copyDiagnostic":"Diagnose kopieren","diagnosticCopied":"Diagnose kopiert","addBackground":"Hintergrund hinzufügen / ersetzen","addLayer":"Ebene hinzufügen","layersTitle":"Bilder & Ebenen","layersDesc":"Verwalte hier den Hintergrund und alle überlagerten Bilder. Miniaturen helfen beim Erkennen, Auswählen, Ausblenden, Sortieren oder Gruppieren.","addLayerChoiceTitle":"Ebene hinzufügen","addLayerChoiceText":"Wähle, wo diese Ebene liegen soll. Das kann später geändert werden.","addLayerWhole":"Auf dem gesamten Banner","addLayerWholeText":"Ein frei bewegliches Bild über dem gesamten Banner.","addLayerOneMission":"Auf einer Mission","addLayerOneMissionText":"Ein Bild, das automatisch auf die gewählte Mission gesetzt und begrenzt wird.","addLayerManyMissions":"Auf mehreren Missionen","addLayerManyMissionsText":"Importiere eine Bildserie und ordne jedes Bild einer Mission zu.","multiSelection":"Mehrfachauswahl","multiSelectionHint":"Wähle mehrere Ebenen für gemeinsame Aktionen, Gruppierung oder Löschen.","editSelection":"Auswahl bearbeiten","deleteSelection":"Auswahl löschen","clearGroupSelection":"Auswahl leeren","group":"Gruppieren","selectedLayersCount":"{n} Ebene(n) ausgewählt","layerScope":"Ebenenbereich","wholeBanner":"Gesamtes Banner","missionTarget":"Zugeordnete Mission","fitMode":"Anpassung","fitCover":"Füllen","fitContain":"Einpassen","layerOpacity":"Deckkraft","visible":"Sichtbar","hidden":"Ausgeblendet","font":"Schriftart","fontWeight":"Stärke","fontItalic":"Kursiv","letterSpacing":"Zeichenabstand","lineHeight":"Zeilenhöhe","textAlign":"Ausrichtung","alignLeft":"Links","alignCenter":"Mitte","alignRight":"Rechts","importFont":"Schrift importieren","textTypography":"Typografie","studioTitle":"Bearbeitungsstudio","studioLayers":"Ebenen","studioTexts":"Texte","studioTools":"Werkzeuge","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Vollbild","studioPan":"Scrollen","tutorialHubTitle":"Tutorials & Einstieg","tutorialHubText":"Starte jederzeit eine geführte Tour neu. Redacted erklärt auch nur den Teil, den du brauchst.","tutorialQuick":"Schnelltour","tutorialQuickDesc":"Die wichtigsten Bedienelemente und der BannerLab-Ablauf.","tutorialBanner":"Banner erstellen","tutorialBannerDesc":"Vom Projekt bis Vorschau und Export der Missionen.","tutorialLayers":"Bilder, Ebenen & Text","tutorialLayersDesc":"Hintergrund, überlagerte Bilder, Ebenen und Typografie.","tutorialIitc":"Route mit IITC erstellen","tutorialIitcDesc":"Companion installieren, Portale hinzufügen und Route synchronisieren.","tutorialPublish":"Missionen veröffentlichen","tutorialPublishDesc":"Missionen vorbereiten und Publisher/Mission Authoring verwenden.","tutorialBackup":"Backups & portable Projekte","tutorialBackupDesc":"BannerLab sichern oder ein vollständiges Banner teilen.","tutorialStart":"Tour starten","tutorialLater":"Später","tutorialNever":"Nicht mehr anzeigen","tutorialClose":"Schließen","tutorialNext":"Weiter","tutorialPrevious":"Zurück","tutorialUnderstood":"OK, verstanden","tutorialWelcomeTitle":"Willkommen bei Redacted BannerLab","tutorialWelcomeText":"Redacted kann dir das Labor zeigen. Zwei Minuten, ein paar Knöpfe und keine Prüfung am Ende.","tutInfoTitle":"Einstellungen, Hilfe & Support","tutInfoText":"Einstellungen & Infos enthält Sprache, Backups, Tutorials und Support über den Redacted BannerLab Bot.","tutSupportTitle":"Brauchst du Hilfe?","tutSupportText":"Kopiere bei Bedarf die Diagnose und kontaktiere den Support. Der Bot verlinkt auch Kanal und Gruppe."});
I18N["it"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Percorso","missions":"Missioni","publish":"Pubblica","projects":"Progetti","rows":"Righe","image":"Immagini","text":"Testo","preview":"Anteprima","export":"Esporta","wholeFresco":"Banner completo","oneMission":"Una missione","search":"Cerca","searchBannergress":"Cerca un banner","bannerNameSearch":"Nome / parola chiave","citySearch":"Città","cityPlaceholder":"es. Nantes","nearMe":"Vicino a me","nearMeHint":"Usa la tua posizione attuale invece di una città.","searchRadius":"Raggio di ricerca","radiusHint":"Applicato intorno alla città o alla tua posizione attuale.","searchReset":"Cancella","searching":"Ricerca…","locationChecking":"Controllo dei servizi di localizzazione…","locationGetting":"Recupero della posizione…","locationReady":"Posizione acquisita","locationDisabled":"I servizi di localizzazione sono disattivati su questo telefono.","locationPermissionDenied":"BannerLab non è autorizzato a usare la tua posizione.","locationUnavailable":"Posizione non disponibile. Controlla i servizi di localizzazione.","locationTimeout":"Impossibile acquisire la posizione in tempo.","openLocationSettings":"Attiva posizione","openAppSettings":"Apri impostazioni app","settingsInfo":"Impostazioni e info","language":"Lingua","newProject":"Nuovo progetto","myProjects":"I miei progetti","portableProject":"Progetto portatile","portableProjectDesc":"Esporta un solo banner con immagini, livelli, testi, font, missioni e percorso.","exportProject":"Esporta","shareProject":"Condividi","importProject":"Importa progetto","projectExporting":"Preparazione progetto…","projectExported":"Progetto salvato","projectShared":"Progetto pronto da condividere","projectImportSuccess":"Progetto importato","backupTitle":"Backup e ripristino","backupNow":"Esegui backup ora","backupExport":"Esporta JSON","backupImport":"Importa JSON","communityTitle":"Community e supporto","communityText":"Accedi alla community e al supporto tramite il bot Redacted BannerLab.","reportProblem":"Segnala un problema","reportProblemText":"Copia la diagnostica tecnica e contatta il supporto tramite il bot.","telegramOpen":"Contatta supporto","copyDiagnostic":"Copia diagnostica","diagnosticCopied":"Diagnostica copiata","addBackground":"Aggiungi / sostituisci sfondo","addLayer":"Aggiungi livello","layersTitle":"Immagini e livelli","layersDesc":"Gestisci qui lo sfondo e tutte le immagini sovrapposte. Le miniature aiutano a identificare, selezionare, nascondere, riordinare o raggruppare i livelli.","addLayerChoiceTitle":"Aggiungi un livello","addLayerChoiceText":"Scegli dove deve stare il livello. Potrai modificarlo in seguito.","addLayerWhole":"Su tutto il banner","addLayerWholeText":"Un’immagine libera su tutto il banner.","addLayerOneMission":"Su una missione","addLayerOneMissionText":"Un’immagine posizionata e ritagliata automaticamente sulla missione scelta.","addLayerManyMissions":"Su più missioni","addLayerManyMissionsText":"Importa una serie di immagini e assegna ciascuna alla missione desiderata.","multiSelection":"Selezione multipla","multiSelectionHint":"Seleziona più livelli per un’azione comune, raggrupparli o eliminarli.","editSelection":"Modifica selezione","deleteSelection":"Elimina selezione","clearGroupSelection":"Svuota selezione","group":"Raggruppa","selectedLayersCount":"{n} livello/i selezionato/i","layerScope":"Ambito livello","wholeBanner":"Banner completo","missionTarget":"Missione associata","fitMode":"Adattamento","fitCover":"Riempi","fitContain":"Contieni","layerOpacity":"Opacità","visible":"Visibile","hidden":"Nascosto","font":"Font","fontWeight":"Peso","fontItalic":"Corsivo","letterSpacing":"Spaziatura lettere","lineHeight":"Interlinea","textAlign":"Allineamento","alignLeft":"Sinistra","alignCenter":"Centro","alignRight":"Destra","importFont":"Importa font","textTypography":"Tipografia","studioTitle":"Studio di modifica","studioLayers":"Livelli","studioTexts":"Testi","studioTools":"Strumenti","studioMissionMode":"Missione","studioFrescoMode":"Banner","studioFullscreen":"Schermo intero","studioPan":"Scorrimento","tutorialHubTitle":"Tutorial e primi passi","tutorialHubText":"Riavvia una visita guidata quando vuoi. Redacted può spiegare solo la parte che ti serve.","tutorialQuick":"Tour rapido","tutorialQuickDesc":"I controlli essenziali e il flusso generale di BannerLab.","tutorialBanner":"Crea un banner","tutorialBannerDesc":"Dal progetto all’anteprima e all’esportazione delle missioni.","tutorialLayers":"Immagini, livelli e testo","tutorialLayersDesc":"Sfondo, immagini sovrapposte, livelli e strumenti tipografici.","tutorialIitc":"Crea il percorso con IITC","tutorialIitcDesc":"Installa Companion, aggiungi portali e sincronizza il percorso.","tutorialPublish":"Pubblica missioni","tutorialPublishDesc":"Prepara le missioni e usa Publisher e Mission Authoring.","tutorialBackup":"Backup e progetti portatili","tutorialBackupDesc":"Salva BannerLab o condividi un banner completo.","tutorialStart":"Avvia tour","tutorialLater":"Più tardi","tutorialNever":"Non mostrare più","tutorialClose":"Chiudi","tutorialNext":"Avanti","tutorialPrevious":"Indietro","tutorialUnderstood":"OK, capito","tutorialWelcomeTitle":"Benvenuto in Redacted BannerLab","tutorialWelcomeText":"Redacted può mostrarti il laboratorio. Due minuti, qualche pulsante e nessun esame alla fine.","tutInfoTitle":"Impostazioni, aiuto e supporto","tutInfoText":"Impostazioni e info contiene lingua, backup, tutorial e supporto tramite il bot Redacted BannerLab.","tutSupportTitle":"Serve aiuto?","tutSupportText":"Copia la diagnostica se necessario e contatta il supporto. Il bot collega anche canale e gruppo."});
I18N["ja"]=Object.assign({},I18N.en,{"fresco":"バナー","route":"ルート","missions":"ミッション","publish":"公開","projects":"プロジェクト","rows":"行","image":"画像","text":"テキスト","preview":"プレビュー","export":"エクスポート","wholeFresco":"バナー全体","oneMission":"1ミッション","search":"検索","searchBannergress":"バナーを検索","bannerNameSearch":"名前 / キーワード","citySearch":"都市","cityPlaceholder":"例：Nantes","nearMe":"現在地の近く","nearMeHint":"都市の代わりに現在地を使用します。","searchRadius":"検索範囲","radiusHint":"都市または現在地を中心に適用します。","searchReset":"クリア","searching":"検索中…","locationChecking":"位置情報サービスを確認中…","locationGetting":"現在地を取得中…","locationReady":"現在地を取得しました","locationDisabled":"この端末では位置情報サービスが無効です。","locationPermissionDenied":"BannerLab に位置情報の使用権限がありません。","locationUnavailable":"位置情報を取得できません。端末の位置情報サービスを確認してください。","locationTimeout":"時間内に位置情報を取得できませんでした。","openLocationSettings":"位置情報を有効にする","openAppSettings":"アプリ設定を開く","settingsInfo":"設定と情報","language":"言語","newProject":"新規プロジェクト","myProjects":"マイプロジェクト","portableProject":"ポータブルプロジェクト","portableProjectDesc":"画像、レイヤー、テキスト、フォント、ミッション、ルートを含むバナー1つをエクスポートします。","exportProject":"エクスポート","shareProject":"共有","importProject":"プロジェクトをインポート","projectExporting":"プロジェクトを準備中…","projectExported":"プロジェクトを保存しました","projectShared":"共有の準備ができました","projectImportSuccess":"プロジェクトをインポートしました","backupTitle":"バックアップと復元","backupNow":"今すぐバックアップ","backupExport":"JSONをエクスポート","backupImport":"JSONをインポート","communityTitle":"コミュニティとサポート","communityText":"Redacted BannerLab Bot からコミュニティとサポートにアクセスできます。","reportProblem":"問題を報告","reportProblemText":"技術診断をコピーして、Botからサポートに連絡してください。","telegramOpen":"サポートに連絡","copyDiagnostic":"診断をコピー","diagnosticCopied":"診断をコピーしました","addBackground":"背景を追加 / 置換","addLayer":"レイヤーを追加","layersTitle":"画像とレイヤー","layersDesc":"背景と重ねた画像をここで管理します。サムネイルでレイヤーを確認し、選択、非表示、並べ替え、グループ化できます。","addLayerChoiceTitle":"レイヤーを追加","addLayerChoiceText":"このレイヤーを配置する範囲を選びます。後から変更できます。","addLayerWhole":"バナー全体","addLayerWholeText":"バナー全体で自由に動かせる画像です。","addLayerOneMission":"1つのミッション","addLayerOneMissionText":"選択したミッションに自動配置され、その枠内に制限されます。","addLayerManyMissions":"複数ミッション","addLayerManyMissionsText":"複数画像を読み込み、それぞれをミッションに割り当てます。","multiSelection":"複数選択","multiSelectionHint":"複数レイヤーを選択して、一括編集・グループ化・削除できます。","editSelection":"選択を編集","deleteSelection":"選択を削除","clearGroupSelection":"選択を解除","group":"グループ化","selectedLayersCount":"{n} レイヤー選択中","layerScope":"レイヤー範囲","wholeBanner":"バナー全体","missionTarget":"割り当てミッション","fitMode":"フィット","fitCover":"塗りつぶす","fitContain":"全体を収める","layerOpacity":"不透明度","visible":"表示","hidden":"非表示","font":"フォント","fontWeight":"太さ","fontItalic":"斜体","letterSpacing":"文字間隔","lineHeight":"行間","textAlign":"配置","alignLeft":"左","alignCenter":"中央","alignRight":"右","importFont":"フォントをインポート","textTypography":"タイポグラフィ","studioTitle":"編集スタジオ","studioLayers":"レイヤー","studioTexts":"テキスト","studioTools":"ツール","studioMissionMode":"ミッション","studioFrescoMode":"バナー","studioFullscreen":"全画面","studioPan":"スクロール","tutorialHubTitle":"チュートリアルと使い方","tutorialHubText":"いつでもガイドを再開できます。必要な部分だけRedactedが説明します。","tutorialQuick":"クイックツアー","tutorialQuickDesc":"BannerLabの基本操作と全体の流れ。","tutorialBanner":"バナーを作成","tutorialBannerDesc":"プロジェクト作成からミッションのプレビューとエクスポートまで。","tutorialLayers":"画像・レイヤー・テキスト","tutorialLayersDesc":"背景、重ね画像、レイヤー、文字編集ツール。","tutorialIitc":"IITCでルートを作成","tutorialIitcDesc":"Companionをインストールし、ポータルを追加してルートを同期します。","tutorialPublish":"ミッションを公開","tutorialPublishDesc":"ミッションを準備し、PublisherとMission Authoringを使用します。","tutorialBackup":"バックアップとポータブルプロジェクト","tutorialBackupDesc":"BannerLab全体を保存するか、完成したバナー1つを共有します。","tutorialStart":"ツアー開始","tutorialLater":"後で","tutorialNever":"今後表示しない","tutorialClose":"閉じる","tutorialNext":"次へ","tutorialPrevious":"戻る","tutorialUnderstood":"OK、わかりました","tutorialWelcomeTitle":"Redacted BannerLabへようこそ","tutorialWelcomeText":"Redactedが研究所を案内します。2分、いくつかのボタン、最後に試験はありません。","tutInfoTitle":"設定・ヘルプ・サポート","tutInfoText":"設定と情報には、言語、バックアップ、チュートリアル、Redacted BannerLab Bot経由のサポートがあります。","tutSupportTitle":"助けが必要？","tutSupportText":"必要なら診断をコピーしてサポートに連絡してください。Botからチャンネルとグループにもアクセスできます。"});
I18N["ko"]=Object.assign({},I18N.en,{"fresco":"배너","route":"경로","missions":"미션","publish":"게시","projects":"프로젝트","rows":"행","image":"이미지","text":"텍스트","preview":"미리보기","export":"내보내기","wholeFresco":"전체 배너","oneMission":"미션 하나","search":"검색","searchBannergress":"배너 찾기","bannerNameSearch":"이름 / 키워드","citySearch":"도시","cityPlaceholder":"예: Nantes","nearMe":"내 주변","nearMeHint":"도시 대신 현재 위치를 사용합니다.","searchRadius":"검색 반경","radiusHint":"도시 또는 현재 위치를 중심으로 적용됩니다.","searchReset":"지우기","searching":"검색 중…","locationChecking":"위치 서비스를 확인하는 중…","locationGetting":"현재 위치를 가져오는 중…","locationReady":"위치를 가져왔습니다","locationDisabled":"이 휴대전화에서 위치 서비스가 꺼져 있습니다.","locationPermissionDenied":"BannerLab에 위치 사용 권한이 없습니다.","locationUnavailable":"위치를 사용할 수 없습니다. 위치 서비스를 확인하세요.","locationTimeout":"제시간에 위치를 가져오지 못했습니다.","openLocationSettings":"위치 켜기","openAppSettings":"앱 설정 열기","settingsInfo":"설정 및 정보","language":"언어","newProject":"새 프로젝트","myProjects":"내 프로젝트","portableProject":"휴대용 프로젝트","portableProjectDesc":"이미지, 레이어, 텍스트, 폰트, 미션, 경로가 포함된 배너 하나를 내보냅니다.","exportProject":"내보내기","shareProject":"공유","importProject":"프로젝트 가져오기","projectExporting":"프로젝트 준비 중…","projectExported":"프로젝트 저장됨","projectShared":"공유 준비 완료","projectImportSuccess":"프로젝트를 가져왔습니다","backupTitle":"백업 및 복원","backupNow":"지금 백업","backupExport":"JSON 내보내기","backupImport":"JSON 가져오기","communityTitle":"커뮤니티 및 지원","communityText":"Redacted BannerLab 봇을 통해 커뮤니티와 지원에 접근할 수 있습니다.","reportProblem":"문제 신고","reportProblemText":"기술 진단을 복사한 뒤 봇으로 지원팀에 문의하세요.","telegramOpen":"지원 문의","copyDiagnostic":"진단 복사","diagnosticCopied":"진단을 복사했습니다","addBackground":"배경 추가 / 교체","addLayer":"레이어 추가","layersTitle":"이미지 및 레이어","layersDesc":"배경과 겹쳐진 이미지를 관리합니다. 썸네일로 레이어를 확인하고 선택, 숨김, 순서 변경, 그룹화할 수 있습니다.","addLayerChoiceTitle":"레이어 추가","addLayerChoiceText":"이 레이어가 적용될 범위를 선택하세요. 나중에 변경할 수 있습니다.","addLayerWhole":"전체 배너","addLayerWholeText":"전체 배너에서 자유롭게 이동 가능한 이미지입니다.","addLayerOneMission":"미션 하나","addLayerOneMissionText":"선택한 미션에 자동으로 배치되고 그 칸 안으로 제한됩니다.","addLayerManyMissions":"여러 미션","addLayerManyMissionsText":"여러 이미지를 가져와 각 이미지에 미션을 지정합니다.","multiSelection":"다중 선택","multiSelectionHint":"여러 레이어를 선택해 함께 수정, 그룹화 또는 삭제할 수 있습니다.","editSelection":"선택 수정","deleteSelection":"선택 삭제","clearGroupSelection":"선택 비우기","group":"그룹화","selectedLayersCount":"{n}개 레이어 선택됨","layerScope":"레이어 범위","wholeBanner":"전체 배너","missionTarget":"연결된 미션","fitMode":"맞춤","fitCover":"채우기","fitContain":"맞추기","layerOpacity":"불투명도","visible":"표시","hidden":"숨김","font":"폰트","fontWeight":"굵기","fontItalic":"기울임","letterSpacing":"자간","lineHeight":"행간","textAlign":"정렬","alignLeft":"왼쪽","alignCenter":"가운데","alignRight":"오른쪽","importFont":"폰트 가져오기","textTypography":"타이포그래피","studioTitle":"편집 스튜디오","studioLayers":"레이어","studioTexts":"텍스트","studioTools":"도구","studioMissionMode":"미션","studioFrescoMode":"배너","studioFullscreen":"전체 화면","studioPan":"스크롤","tutorialHubTitle":"튜토리얼 및 시작하기","tutorialHubText":"언제든 가이드 투어를 다시 시작할 수 있습니다. 필요한 부분만 Redacted가 설명할 수도 있습니다.","tutorialQuick":"빠른 둘러보기","tutorialQuickDesc":"BannerLab의 핵심 조작과 전체 흐름.","tutorialBanner":"배너 만들기","tutorialBannerDesc":"프로젝트부터 미션 미리보기와 내보내기까지.","tutorialLayers":"이미지, 레이어 및 텍스트","tutorialLayersDesc":"배경, 겹친 이미지, 레이어, 타이포그래피 도구.","tutorialIitc":"IITC로 경로 만들기","tutorialIitcDesc":"Companion을 설치하고 포털을 추가한 뒤 경로를 동기화합니다.","tutorialPublish":"미션 게시","tutorialPublishDesc":"미션을 준비하고 Publisher와 Mission Authoring을 사용합니다.","tutorialBackup":"백업 및 휴대용 프로젝트","tutorialBackupDesc":"BannerLab 전체를 백업하거나 완성된 배너 하나를 공유합니다.","tutorialStart":"둘러보기 시작","tutorialLater":"나중에","tutorialNever":"다시 표시하지 않기","tutorialClose":"닫기","tutorialNext":"다음","tutorialPrevious":"이전","tutorialUnderstood":"확인, 알겠습니다","tutorialWelcomeTitle":"Redacted BannerLab에 오신 것을 환영합니다","tutorialWelcomeText":"Redacted가 연구실을 안내합니다. 2분, 몇 개의 버튼, 마지막 시험은 없습니다.","tutInfoTitle":"설정, 도움말 및 지원","tutInfoText":"설정 및 정보에는 언어, 백업, 튜토리얼, Redacted BannerLab 봇을 통한 지원이 있습니다.","tutSupportTitle":"도움이 필요한가요?","tutSupportText":"필요하면 진단을 복사하고 지원팀에 문의하세요. 봇에서 채널과 그룹에도 접근할 수 있습니다."});
I18N["zh-Hans"]=Object.assign({},I18N.en,{"fresco":"横幅","route":"路线","missions":"任务","publish":"发布","projects":"项目","rows":"行","image":"图片","text":"文字","preview":"预览","export":"导出","wholeFresco":"完整横幅","oneMission":"单个任务","search":"搜索","searchBannergress":"搜索横幅","bannerNameSearch":"名称 / 关键词","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"附近","nearMeHint":"使用当前位置而不是城市。","searchRadius":"搜索半径","radiusHint":"以城市或当前位置为中心。","searchReset":"清除","searching":"正在搜索…","locationChecking":"正在检查定位服务…","locationGetting":"正在获取当前位置…","locationReady":"已获取位置","locationDisabled":"此手机的定位服务已关闭。","locationPermissionDenied":"BannerLab 没有使用你位置的权限。","locationUnavailable":"无法获取位置，请检查定位服务。","locationTimeout":"未能及时获取位置。","openLocationSettings":"开启定位","openAppSettings":"打开应用设置","settingsInfo":"设置与信息","language":"语言","newProject":"新建项目","myProjects":"我的项目","portableProject":"便携项目","portableProjectDesc":"导出包含图片、图层、文字、字体、任务和路线的单个横幅。","exportProject":"导出","shareProject":"分享","importProject":"导入项目","projectExporting":"正在准备项目…","projectExported":"项目已保存","projectShared":"项目可分享","projectImportSuccess":"项目已导入","backupTitle":"备份与恢复","backupNow":"立即备份","backupExport":"导出 JSON","backupImport":"导入 JSON","communityTitle":"社区与支持","communityText":"通过 Redacted BannerLab 机器人访问社区和支持。","reportProblem":"报告问题","reportProblemText":"复制技术诊断，然后通过机器人联系支持。","telegramOpen":"联系支持","copyDiagnostic":"复制诊断","diagnosticCopied":"诊断已复制","addBackground":"添加 / 替换背景","addLayer":"添加图层","layersTitle":"图片与图层","layersDesc":"在这里管理背景和所有叠加图片。缩略图可以帮助识别、选择、隐藏、排序或分组图层。","addLayerChoiceTitle":"添加图层","addLayerChoiceText":"选择图层的作用范围，之后仍可修改。","addLayerWhole":"整个横幅","addLayerWholeText":"可在整个横幅上自由移动的图片。","addLayerOneMission":"单个任务","addLayerOneMissionText":"图片会自动放置并限制在所选任务格内。","addLayerManyMissions":"多个任务","addLayerManyMissionsText":"导入一组图片，并把每张图片分配给对应任务。","multiSelection":"多选","multiSelectionHint":"选择多个图层以统一修改、分组或删除。","editSelection":"编辑选择","deleteSelection":"删除选择","clearGroupSelection":"清空选择","group":"分组","selectedLayersCount":"已选择 {n} 个图层","layerScope":"图层范围","wholeBanner":"整个横幅","missionTarget":"关联任务","fitMode":"适配","fitCover":"填充","fitContain":"完整显示","layerOpacity":"不透明度","visible":"显示","hidden":"隐藏","font":"字体","fontWeight":"字重","fontItalic":"斜体","letterSpacing":"字间距","lineHeight":"行高","textAlign":"对齐","alignLeft":"左对齐","alignCenter":"居中","alignRight":"右对齐","importFont":"导入字体","textTypography":"排版","studioTitle":"编辑工作室","studioLayers":"图层","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任务","studioFrescoMode":"横幅","studioFullscreen":"全屏","studioPan":"滚动","tutorialHubTitle":"教程与入门","tutorialHubText":"随时重新开始引导。Redacted 也可以只解释你需要的部分。","tutorialQuick":"快速导览","tutorialQuickDesc":"BannerLab 的核心操作和整体流程。","tutorialBanner":"创建横幅","tutorialBannerDesc":"从项目创建到任务预览与导出。","tutorialLayers":"图片、图层与文字","tutorialLayersDesc":"背景、叠加图片、图层和排版工具。","tutorialIitc":"用 IITC 创建路线","tutorialIitcDesc":"安装 Companion、添加 Portal 并同步路线。","tutorialPublish":"发布任务","tutorialPublishDesc":"准备任务，然后使用 Publisher 和 Mission Authoring。","tutorialBackup":"备份与便携项目","tutorialBackupDesc":"备份整个 BannerLab，或分享一个完整横幅。","tutorialStart":"开始导览","tutorialLater":"稍后","tutorialNever":"不再显示","tutorialClose":"关闭","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"好的，明白了","tutorialWelcomeTitle":"欢迎使用 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以带你参观实验室。两分钟、几个按钮，最后没有考试。","tutInfoTitle":"设置、帮助与支持","tutInfoText":"设置与信息包含语言、备份、教程以及通过 Redacted BannerLab 机器人获得的支持。","tutSupportTitle":"需要帮助？","tutSupportText":"如有需要先复制诊断，再联系支持。机器人也提供频道和讨论组入口。"});
I18N["zh-Hant"]=Object.assign({},I18N.en,{"fresco":"橫幅","route":"路線","missions":"任務","publish":"發布","projects":"專案","rows":"列","image":"圖片","text":"文字","preview":"預覽","export":"匯出","wholeFresco":"完整橫幅","oneMission":"單一任務","search":"搜尋","searchBannergress":"搜尋橫幅","bannerNameSearch":"名稱 / 關鍵字","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"附近","nearMeHint":"使用目前位置而不是城市。","searchRadius":"搜尋半徑","radiusHint":"以城市或目前位置為中心。","searchReset":"清除","searching":"搜尋中…","locationChecking":"正在檢查定位服務…","locationGetting":"正在取得目前位置…","locationReady":"已取得位置","locationDisabled":"此手機的定位服務已關閉。","locationPermissionDenied":"BannerLab 沒有使用你位置的權限。","locationUnavailable":"無法取得位置，請檢查定位服務。","locationTimeout":"未能及時取得位置。","openLocationSettings":"開啟定位","openAppSettings":"開啟應用程式設定","settingsInfo":"設定與資訊","language":"語言","newProject":"新增專案","myProjects":"我的專案","portableProject":"可攜式專案","portableProjectDesc":"匯出包含圖片、圖層、文字、字型、任務和路線的單一橫幅。","exportProject":"匯出","shareProject":"分享","importProject":"匯入專案","projectExporting":"正在準備專案…","projectExported":"專案已儲存","projectShared":"專案可分享","projectImportSuccess":"專案已匯入","backupTitle":"備份與還原","backupNow":"立即備份","backupExport":"匯出 JSON","backupImport":"匯入 JSON","communityTitle":"社群與支援","communityText":"透過 Redacted BannerLab 機器人存取社群與支援。","reportProblem":"回報問題","reportProblemText":"複製技術診斷，然後透過機器人聯絡支援。","telegramOpen":"聯絡支援","copyDiagnostic":"複製診斷","diagnosticCopied":"診斷已複製","addBackground":"新增 / 取代背景","addLayer":"新增圖層","layersTitle":"圖片與圖層","layersDesc":"在這裡管理背景和所有疊加圖片。縮圖可協助辨識、選取、隱藏、排序或群組圖層。","addLayerChoiceTitle":"新增圖層","addLayerChoiceText":"選擇圖層的作用範圍，之後仍可修改。","addLayerWhole":"整個橫幅","addLayerWholeText":"可在整個橫幅上自由移動的圖片。","addLayerOneMission":"單一任務","addLayerOneMissionText":"圖片會自動放置並限制在所選任務格內。","addLayerManyMissions":"多個任務","addLayerManyMissionsText":"匯入一組圖片，並把每張圖片指派給對應任務。","multiSelection":"多選","multiSelectionHint":"選取多個圖層以統一修改、群組或刪除。","editSelection":"編輯選取","deleteSelection":"刪除選取","clearGroupSelection":"清空選取","group":"群組","selectedLayersCount":"已選取 {n} 個圖層","layerScope":"圖層範圍","wholeBanner":"整個橫幅","missionTarget":"關聯任務","fitMode":"適配","fitCover":"填滿","fitContain":"完整顯示","layerOpacity":"不透明度","visible":"顯示","hidden":"隱藏","font":"字型","fontWeight":"字重","fontItalic":"斜體","letterSpacing":"字距","lineHeight":"行高","textAlign":"對齊","alignLeft":"靠左","alignCenter":"置中","alignRight":"靠右","importFont":"匯入字型","textTypography":"排版","studioTitle":"編輯工作室","studioLayers":"圖層","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任務","studioFrescoMode":"橫幅","studioFullscreen":"全螢幕","studioPan":"捲動","tutorialHubTitle":"教學與入門","tutorialHubText":"隨時重新開始導覽。Redacted 也可以只解釋你需要的部分。","tutorialQuick":"快速導覽","tutorialQuickDesc":"BannerLab 的核心操作和整體流程。","tutorialBanner":"建立橫幅","tutorialBannerDesc":"從專案建立到任務預覽與匯出。","tutorialLayers":"圖片、圖層與文字","tutorialLayersDesc":"背景、疊加圖片、圖層與排版工具。","tutorialIitc":"用 IITC 建立路線","tutorialIitcDesc":"安裝 Companion、加入 Portal 並同步路線。","tutorialPublish":"發布任務","tutorialPublishDesc":"準備任務，然後使用 Publisher 和 Mission Authoring。","tutorialBackup":"備份與可攜式專案","tutorialBackupDesc":"備份整個 BannerLab，或分享一個完整橫幅。","tutorialStart":"開始導覽","tutorialLater":"稍後","tutorialNever":"不再顯示","tutorialClose":"關閉","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"好，我明白了","tutorialWelcomeTitle":"歡迎使用 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以帶你參觀實驗室。兩分鐘、幾個按鈕，最後沒有考試。","tutInfoTitle":"設定、說明與支援","tutInfoText":"設定與資訊包含語言、備份、教學，以及透過 Redacted BannerLab 機器人取得的支援。","tutSupportTitle":"需要幫忙？","tutSupportText":"需要時先複製診斷，再聯絡支援。機器人也提供頻道和討論群組入口。"});
I18N["yue"]=Object.assign({},I18N.en,{"fresco":"橫幅","route":"路線","missions":"任務","publish":"發佈","projects":"專案","rows":"行","image":"圖片","text":"文字","preview":"預覽","export":"匯出","wholeFresco":"成幅橫幅","oneMission":"一個任務","search":"搜尋","searchBannergress":"搵橫幅","bannerNameSearch":"名稱 / 關鍵字","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"我附近","nearMeHint":"用你而家嘅位置，唔使輸入城市。","searchRadius":"搜尋範圍","radiusHint":"以城市或者你而家嘅位置做中心。","searchReset":"清除","searching":"搜尋緊…","locationChecking":"檢查緊定位服務…","locationGetting":"攞緊你嘅位置…","locationReady":"攞到位置喇","locationDisabled":"呢部電話嘅定位服務未開。","locationPermissionDenied":"BannerLab 未有權限使用你嘅位置。","locationUnavailable":"攞唔到位置，請檢查定位服務。","locationTimeout":"限時內攞唔到位置。","openLocationSettings":"開啟定位","openAppSettings":"開啟 App 設定","settingsInfo":"設定同資訊","language":"語言","newProject":"新專案","myProjects":"我嘅專案","portableProject":"便攜專案","portableProjectDesc":"匯出一幅包含圖片、圖層、文字、字型、任務同路線嘅橫幅。","exportProject":"匯出","shareProject":"分享","importProject":"匯入專案","projectExporting":"準備緊專案…","projectExported":"專案已儲存","projectShared":"專案可以分享喇","projectImportSuccess":"專案已匯入","backupTitle":"備份同還原","backupNow":"而家備份","backupExport":"匯出 JSON","backupImport":"匯入 JSON","communityTitle":"社群同支援","communityText":"經 Redacted BannerLab Bot 就可以去社群同搵支援。","reportProblem":"回報問題","reportProblemText":"複製技術診斷，再經 Bot 聯絡支援。","telegramOpen":"聯絡支援","copyDiagnostic":"複製診斷","diagnosticCopied":"診斷已複製","addBackground":"新增 / 更換背景","addLayer":"新增圖層","layersTitle":"圖片同圖層","layersDesc":"喺度管理背景同所有疊加圖片。縮圖可以幫你認清、揀選、隱藏、排序或者群組圖層。","addLayerChoiceTitle":"新增圖層","addLayerChoiceText":"揀呢個圖層要放喺邊個範圍，之後都可以改。","addLayerWhole":"成幅橫幅","addLayerWholeText":"一張可以喺成幅橫幅自由郁嘅圖片。","addLayerOneMission":"一個任務","addLayerOneMissionText":"圖片會自動放去指定任務，而且唔會走出個格。","addLayerManyMissions":"多個任務","addLayerManyMissionsText":"一次過匯入多張圖片，再逐張分配去任務。","multiSelection":"多選","multiSelectionHint":"揀多個圖層，一齊修改、群組或者刪除。","editSelection":"修改選取","deleteSelection":"刪除選取","clearGroupSelection":"清除選取","group":"群組","selectedLayersCount":"已揀 {n} 個圖層","layerScope":"圖層範圍","wholeBanner":"成幅橫幅","missionTarget":"指定任務","fitMode":"適配","fitCover":"填滿","fitContain":"完整顯示","layerOpacity":"透明度","visible":"顯示","hidden":"隱藏","font":"字型","fontWeight":"粗幼","fontItalic":"斜體","letterSpacing":"字距","lineHeight":"行距","textAlign":"對齊","alignLeft":"靠左","alignCenter":"置中","alignRight":"靠右","importFont":"匯入字型","textTypography":"排版","studioTitle":"編輯工作室","studioLayers":"圖層","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任務","studioFrescoMode":"橫幅","studioFullscreen":"全螢幕","studioPan":"捲動","tutorialHubTitle":"教學同入門","tutorialHubText":"想幾時再睇導覽都得。Redacted 亦可以淨係講你需要嗰部分。","tutorialQuick":"快速導覽","tutorialQuickDesc":"BannerLab 最基本嘅操作同整體流程。","tutorialBanner":"整橫幅","tutorialBannerDesc":"由專案開始，到預覽同匯出任務。","tutorialLayers":"圖片、圖層同文字","tutorialLayersDesc":"背景、疊加圖片、圖層同文字工具。","tutorialIitc":"用 IITC 整路線","tutorialIitcDesc":"裝 Companion、加 Portal，再同步路線。","tutorialPublish":"發佈任務","tutorialPublishDesc":"準備好任務，再用 Publisher 同 Mission Authoring。","tutorialBackup":"備份同便攜專案","tutorialBackupDesc":"備份成個 BannerLab，或者分享一幅完整橫幅。","tutorialStart":"開始導覽","tutorialLater":"遲啲先","tutorialNever":"唔好再顯示","tutorialClose":"關閉","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"OK，明喇","tutorialWelcomeTitle":"歡迎嚟到 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以帶你行下個實驗室。兩分鐘、幾個掣，最後唔使考試。","tutInfoTitle":"設定、幫助同支援","tutInfoText":"設定同資訊入面有語言、備份、教學，同埋經 Redacted BannerLab Bot 嘅支援。","tutSupportTitle":"要幫手？","tutSupportText":"有需要就先複製診斷，再聯絡支援。Bot 亦可以帶你去頻道同討論群組。"});
I18N["ar"]=Object.assign({},I18N.en,{"fresco":"اللافتة","route":"المسار","missions":"المهمات","publish":"نشر","projects":"المشاريع","rows":"الصفوف","image":"الصور","text":"النص","preview":"معاينة","export":"تصدير","wholeFresco":"اللافتة كاملة","oneMission":"مهمة واحدة","search":"بحث","searchBannergress":"البحث عن لافتة","bannerNameSearch":"الاسم / كلمة مفتاحية","citySearch":"المدينة","cityPlaceholder":"مثال: Nantes","nearMe":"بالقرب مني","nearMeHint":"استخدم موقعك الحالي بدلاً من مدينة.","searchRadius":"نطاق البحث","radiusHint":"يُطبّق حول المدينة أو موقعك الحالي.","searchReset":"مسح","searching":"جارٍ البحث…","locationChecking":"جارٍ التحقق من خدمات الموقع…","locationGetting":"جارٍ الحصول على موقعك…","locationReady":"تم الحصول على الموقع","locationDisabled":"خدمات الموقع معطلة على هذا الهاتف.","locationPermissionDenied":"لا يملك BannerLab إذن استخدام موقعك.","locationUnavailable":"الموقع غير متاح. تحقق من خدمات الموقع.","locationTimeout":"تعذر الحصول على الموقع في الوقت المحدد.","openLocationSettings":"تفعيل الموقع","openAppSettings":"فتح إعدادات التطبيق","settingsInfo":"الإعدادات والمعلومات","language":"اللغة","newProject":"مشروع جديد","myProjects":"مشاريعي","portableProject":"مشروع محمول","portableProjectDesc":"صدّر لافتة واحدة مع الصور والطبقات والنصوص والخطوط والمهمات والمسار.","exportProject":"تصدير","shareProject":"مشاركة","importProject":"استيراد مشروع","projectExporting":"جارٍ تجهيز المشروع…","projectExported":"تم حفظ المشروع","projectShared":"المشروع جاهز للمشاركة","projectImportSuccess":"تم استيراد المشروع","backupTitle":"النسخ الاحتياطي والاستعادة","backupNow":"نسخ احتياطي الآن","backupExport":"تصدير JSON","backupImport":"استيراد JSON","communityTitle":"المجتمع والدعم","communityText":"ادخل إلى المجتمع والدعم مباشرة عبر بوت Redacted BannerLab.","reportProblem":"الإبلاغ عن مشكلة","reportProblemText":"انسخ التشخيص التقني ثم تواصل مع الدعم عبر البوت.","telegramOpen":"التواصل مع الدعم","copyDiagnostic":"نسخ التشخيص","diagnosticCopied":"تم نسخ التشخيص","addBackground":"إضافة / استبدال الخلفية","addLayer":"إضافة طبقة","layersTitle":"الصور والطبقات","layersDesc":"أدر الخلفية وكل الصور المتراكبة هنا. تساعد الصور المصغرة على تحديد الطبقة واختيارها وإخفائها وترتيبها أو تجميعها.","addLayerChoiceTitle":"إضافة طبقة","addLayerChoiceText":"اختر أين يجب أن تعمل هذه الطبقة. يمكنك تغيير ذلك لاحقاً.","addLayerWhole":"على اللافتة كاملة","addLayerWholeText":"صورة حرة فوق اللافتة كاملة.","addLayerOneMission":"على مهمة واحدة","addLayerOneMissionText":"صورة توضع تلقائياً وتُقص داخل المهمة المختارة.","addLayerManyMissions":"على عدة مهمات","addLayerManyMissionsText":"استورد سلسلة صور واربط كل صورة بالمهمة المطلوبة.","multiSelection":"تحديد متعدد","multiSelectionHint":"حدد عدة طبقات لتعديلها معاً أو تجميعها أو حذفها.","editSelection":"تعديل التحديد","deleteSelection":"حذف التحديد","clearGroupSelection":"مسح التحديد","group":"تجميع","selectedLayersCount":"تم تحديد {n} طبقة","layerScope":"نطاق الطبقة","wholeBanner":"اللافتة كاملة","missionTarget":"المهمة المرتبطة","fitMode":"الملاءمة","fitCover":"ملء","fitContain":"احتواء","layerOpacity":"الشفافية","visible":"ظاهر","hidden":"مخفي","font":"الخط","fontWeight":"السُمك","fontItalic":"مائل","letterSpacing":"تباعد الحروف","lineHeight":"ارتفاع السطر","textAlign":"المحاذاة","alignLeft":"يسار","alignCenter":"وسط","alignRight":"يمين","importFont":"استيراد خط","textTypography":"الطباعة","studioTitle":"استوديو التحرير","studioLayers":"الطبقات","studioTexts":"النصوص","studioTools":"الأدوات","studioMissionMode":"مهمة","studioFrescoMode":"لافتة","studioFullscreen":"ملء الشاشة","studioPan":"تمرير","tutorialHubTitle":"الدروس والبدء","tutorialHubText":"أعد تشغيل الجولة الإرشادية متى شئت. يمكن لـ Redacted شرح الجزء الذي تحتاجه فقط.","tutorialQuick":"جولة سريعة","tutorialQuickDesc":"أهم عناصر التحكم ومسار العمل العام في BannerLab.","tutorialBanner":"إنشاء لافتة","tutorialBannerDesc":"من المشروع إلى معاينة المهمات وتصديرها.","tutorialLayers":"الصور والطبقات والنص","tutorialLayersDesc":"الخلفية والصور المتراكبة والطبقات وأدوات الكتابة.","tutorialIitc":"إنشاء المسار باستخدام IITC","tutorialIitcDesc":"ثبّت Companion وأضف البوابات ثم زامن المسار.","tutorialPublish":"نشر المهمات","tutorialPublishDesc":"جهّز المهمات ثم استخدم Publisher وMission Authoring.","tutorialBackup":"النسخ الاحتياطية والمشاريع المحمولة","tutorialBackupDesc":"انسخ BannerLab احتياطياً أو شارك لافتة كاملة.","tutorialStart":"بدء الجولة","tutorialLater":"لاحقاً","tutorialNever":"عدم الإظهار مجدداً","tutorialClose":"إغلاق","tutorialNext":"التالي","tutorialPrevious":"السابق","tutorialUnderstood":"حسناً، فهمت","tutorialWelcomeTitle":"مرحباً بك في Redacted BannerLab","tutorialWelcomeText":"يمكن لـ Redacted أن يأخذك في جولة داخل المختبر. دقيقتان، بضعة أزرار، ولا اختبار في النهاية.","tutInfoTitle":"الإعدادات والمساعدة والدعم","tutInfoText":"تحتوي الإعدادات والمعلومات على اللغة والنسخ الاحتياطية والدروس والدعم عبر بوت Redacted BannerLab.","tutSupportTitle":"تحتاج مساعدة؟","tutSupportText":"انسخ التشخيص عند الحاجة ثم تواصل مع الدعم. يوفر البوت أيضاً روابط القناة والمجموعة."});
I18N["id"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Rute","missions":"Misi","publish":"Publikasikan","projects":"Proyek","rows":"Baris","image":"Gambar","text":"Teks","preview":"Pratinjau","export":"Ekspor","wholeFresco":"Seluruh banner","oneMission":"Satu misi","search":"Cari","searchBannergress":"Cari banner","bannerNameSearch":"Nama / kata kunci","citySearch":"Kota","cityPlaceholder":"mis. Nantes","nearMe":"Di dekat saya","nearMeHint":"Gunakan lokasi saat ini, bukan kota.","searchRadius":"Radius pencarian","radiusHint":"Diterapkan di sekitar kota atau lokasi saat ini.","searchReset":"Hapus","searching":"Mencari…","locationChecking":"Memeriksa layanan lokasi…","locationGetting":"Mengambil lokasi…","locationReady":"Lokasi diperoleh","locationDisabled":"Layanan lokasi dinonaktifkan di ponsel ini.","locationPermissionDenied":"BannerLab tidak diizinkan menggunakan lokasi Anda.","locationUnavailable":"Lokasi tidak tersedia. Periksa layanan lokasi.","locationTimeout":"Lokasi tidak dapat diperoleh tepat waktu.","openLocationSettings":"Aktifkan lokasi","openAppSettings":"Buka setelan aplikasi","settingsInfo":"Setelan & info","language":"Bahasa","newProject":"Proyek baru","myProjects":"Proyek saya","portableProject":"Proyek portabel","portableProjectDesc":"Ekspor satu banner dengan gambar, layer, teks, font, misi, dan rute.","exportProject":"Ekspor","shareProject":"Bagikan","importProject":"Impor proyek","projectExporting":"Menyiapkan proyek…","projectExported":"Proyek disimpan","projectShared":"Proyek siap dibagikan","projectImportSuccess":"Proyek diimpor","backupTitle":"Cadangkan & pulihkan","backupNow":"Cadangkan sekarang","backupExport":"Ekspor JSON","backupImport":"Impor JSON","communityTitle":"Komunitas & dukungan","communityText":"Akses komunitas dan dukungan melalui bot Redacted BannerLab.","reportProblem":"Laporkan masalah","reportProblemText":"Salin diagnosis teknis lalu hubungi dukungan melalui bot.","telegramOpen":"Hubungi dukungan","copyDiagnostic":"Salin diagnosis","diagnosticCopied":"Diagnosis disalin","addBackground":"Tambah / ganti latar","addLayer":"Tambah layer","layersTitle":"Gambar & layer","layersDesc":"Kelola latar dan semua gambar bertumpuk di sini. Thumbnail membantu mengenali, memilih, menyembunyikan, mengurutkan, atau mengelompokkan layer.","addLayerChoiceTitle":"Tambah layer","addLayerChoiceText":"Pilih di mana layer ini berlaku. Anda dapat mengubahnya nanti.","addLayerWhole":"Di seluruh banner","addLayerWholeText":"Gambar bebas di seluruh banner.","addLayerOneMission":"Pada satu misi","addLayerOneMissionText":"Gambar otomatis ditempatkan dan dibatasi pada misi yang dipilih.","addLayerManyMissions":"Pada beberapa misi","addLayerManyMissionsText":"Impor serangkaian gambar dan tetapkan masing-masing ke misi.","multiSelection":"Pilihan ganda","multiSelectionHint":"Pilih beberapa layer untuk tindakan bersama, kelompokkan, atau hapus.","editSelection":"Edit pilihan","deleteSelection":"Hapus pilihan","clearGroupSelection":"Kosongkan pilihan","group":"Kelompokkan","selectedLayersCount":"{n} layer dipilih","layerScope":"Cakupan layer","wholeBanner":"Seluruh banner","missionTarget":"Misi terkait","fitMode":"Penyesuaian","fitCover":"Isi","fitContain":"Muat","layerOpacity":"Opasitas","visible":"Terlihat","hidden":"Tersembunyi","font":"Font","fontWeight":"Ketebalan","fontItalic":"Miring","letterSpacing":"Jarak huruf","lineHeight":"Jarak baris","textAlign":"Perataan","alignLeft":"Kiri","alignCenter":"Tengah","alignRight":"Kanan","importFont":"Impor font","textTypography":"Tipografi","studioTitle":"Studio pengeditan","studioLayers":"Layer","studioTexts":"Teks","studioTools":"Alat","studioMissionMode":"Misi","studioFrescoMode":"Banner","studioFullscreen":"Layar penuh","studioPan":"Gulir","tutorialHubTitle":"Tutorial & mulai","tutorialHubText":"Mulai ulang tur kapan saja. Redacted dapat menjelaskan hanya bagian yang Anda perlukan.","tutorialQuick":"Tur cepat","tutorialQuickDesc":"Kontrol penting dan alur BannerLab secara umum.","tutorialBanner":"Buat banner","tutorialBannerDesc":"Dari proyek hingga pratinjau dan ekspor misi.","tutorialLayers":"Gambar, layer & teks","tutorialLayersDesc":"Latar, gambar bertumpuk, layer, dan alat tipografi.","tutorialIitc":"Buat rute dengan IITC","tutorialIitcDesc":"Pasang Companion, tambahkan portal, dan sinkronkan rute.","tutorialPublish":"Publikasikan misi","tutorialPublishDesc":"Siapkan misi lalu gunakan Publisher dan Mission Authoring.","tutorialBackup":"Cadangan & proyek portabel","tutorialBackupDesc":"Cadangkan BannerLab atau bagikan satu banner lengkap.","tutorialStart":"Mulai tur","tutorialLater":"Nanti","tutorialNever":"Jangan tampilkan lagi","tutorialClose":"Tutup","tutorialNext":"Berikutnya","tutorialPrevious":"Sebelumnya","tutorialUnderstood":"OK, paham","tutorialWelcomeTitle":"Selamat datang di Redacted BannerLab","tutorialWelcomeText":"Redacted dapat mengajak Anda berkeliling lab. Dua menit, beberapa tombol, dan tidak ada ujian di akhir.","tutInfoTitle":"Setelan, bantuan & dukungan","tutInfoText":"Setelan & info berisi bahasa, cadangan, tutorial, dan dukungan melalui bot Redacted BannerLab.","tutSupportTitle":"Butuh bantuan?","tutSupportText":"Salin diagnosis bila perlu lalu hubungi dukungan. Bot juga menyediakan tautan ke kanal dan grup."});
I18N["nl"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Route","missions":"Missies","publish":"Publiceren","projects":"Projecten","rows":"Rijen","image":"Afbeeldingen","text":"Tekst","preview":"Voorbeeld","export":"Exporteren","settingsInfo":"Instellingen & info","language":"Taal","newProject":"Nieuw project","myProjects":"Mijn projecten","search":"Zoeken","searchBannergress":"Banner zoeken","citySearch":"Stad","nearMe":"In mijn buurt","searchRadius":"Zoekstraal","addBackground":"Achtergrond toevoegen / vervangen","addLayer":"Laag toevoegen","layersTitle":"Afbeeldingen & lagen","multiSelection":"Meervoudige selectie","editSelection":"Selectie wijzigen","deleteSelection":"Selectie verwijderen","group":"Groeperen","communityTitle":"Community & support","telegramOpen":"Support contacteren","tutorialHubTitle":"Tutorials & aan de slag","tutorialStart":"Start rondleiding","tutorialLater":"Later","tutorialNever":"Niet meer tonen","tutorialNext":"Volgende","tutorialPrevious":"Vorige","tutorialUnderstood":"OK, begrepen"});
I18N["pl"]=Object.assign({},I18N.en,{"fresco":"Baner","route":"Trasa","missions":"Misje","publish":"Publikuj","projects":"Projekty","rows":"Wiersze","image":"Obrazy","text":"Tekst","preview":"Podgląd","export":"Eksportuj","settingsInfo":"Ustawienia i informacje","language":"Język","newProject":"Nowy projekt","myProjects":"Moje projekty","search":"Szukaj","searchBannergress":"Znajdź baner","citySearch":"Miasto","nearMe":"W pobliżu","searchRadius":"Promień wyszukiwania","addBackground":"Dodaj / zmień tło","addLayer":"Dodaj warstwę","layersTitle":"Obrazy i warstwy","multiSelection":"Wybór wielu","editSelection":"Edytuj zaznaczenie","deleteSelection":"Usuń zaznaczenie","group":"Grupuj","communityTitle":"Społeczność i wsparcie","telegramOpen":"Kontakt ze wsparciem","tutorialHubTitle":"Samouczki i pierwsze kroki","tutorialStart":"Rozpocznij przewodnik","tutorialLater":"Później","tutorialNever":"Nie pokazuj ponownie","tutorialNext":"Dalej","tutorialPrevious":"Wstecz","tutorialUnderstood":"OK, rozumiem"});
I18N["cs"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Trasa","missions":"Mise","publish":"Publikovat","projects":"Projekty","rows":"Řádky","image":"Obrázky","text":"Text","preview":"Náhled","export":"Exportovat","settingsInfo":"Nastavení a informace","language":"Jazyk","newProject":"Nový projekt","myProjects":"Moje projekty","search":"Hledat","searchBannergress":"Najít banner","citySearch":"Město","nearMe":"V mém okolí","searchRadius":"Poloměr hledání","addBackground":"Přidat / nahradit pozadí","addLayer":"Přidat vrstvu","layersTitle":"Obrázky a vrstvy","multiSelection":"Vícenásobný výběr","editSelection":"Upravit výběr","deleteSelection":"Smazat výběr","group":"Seskupit","communityTitle":"Komunita a podpora","telegramOpen":"Kontaktovat podporu","tutorialHubTitle":"Návody a začínáme","tutorialStart":"Spustit prohlídku","tutorialLater":"Později","tutorialNever":"Už nezobrazovat","tutorialNext":"Další","tutorialPrevious":"Předchozí","tutorialUnderstood":"OK, chápu"});
I18N["ro"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Traseu","missions":"Misiuni","publish":"Publică","projects":"Proiecte","rows":"Rânduri","image":"Imagini","text":"Text","preview":"Previzualizare","export":"Exportă","settingsInfo":"Setări și informații","language":"Limbă","newProject":"Proiect nou","myProjects":"Proiectele mele","search":"Caută","searchBannergress":"Caută un banner","citySearch":"Oraș","nearMe":"În apropiere","searchRadius":"Rază de căutare","addBackground":"Adaugă / înlocuiește fundalul","addLayer":"Adaugă strat","layersTitle":"Imagini și straturi","multiSelection":"Selecție multiplă","editSelection":"Modifică selecția","deleteSelection":"Șterge selecția","group":"Grupează","communityTitle":"Comunitate și suport","telegramOpen":"Contactează suportul","tutorialHubTitle":"Tutoriale și început","tutorialStart":"Pornește turul","tutorialLater":"Mai târziu","tutorialNever":"Nu mai afișa","tutorialNext":"Următorul","tutorialPrevious":"Anterior","tutorialUnderstood":"OK, am înțeles"});
I18N["tr"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Rota","missions":"Görevler","publish":"Yayınla","projects":"Projeler","rows":"Satırlar","image":"Görseller","text":"Metin","preview":"Önizleme","export":"Dışa aktar","settingsInfo":"Ayarlar ve bilgi","language":"Dil","newProject":"Yeni proje","myProjects":"Projelerim","search":"Ara","searchBannergress":"Banner ara","citySearch":"Şehir","nearMe":"Yakınımda","searchRadius":"Arama yarıçapı","addBackground":"Arka plan ekle / değiştir","addLayer":"Katman ekle","layersTitle":"Görseller ve katmanlar","multiSelection":"Çoklu seçim","editSelection":"Seçimi düzenle","deleteSelection":"Seçimi sil","group":"Grupla","communityTitle":"Topluluk ve destek","telegramOpen":"Destekle iletişim","tutorialHubTitle":"Eğitimler ve başlangıç","tutorialStart":"Turu başlat","tutorialLater":"Daha sonra","tutorialNever":"Bir daha gösterme","tutorialNext":"İleri","tutorialPrevious":"Geri","tutorialUnderstood":"Tamam, anladım"});
I18N["ru"]=Object.assign({},I18N.en,{"fresco":"Баннер","route":"Маршрут","missions":"Миссии","publish":"Опубликовать","projects":"Проекты","rows":"Ряды","image":"Изображения","text":"Текст","preview":"Предпросмотр","export":"Экспорт","settingsInfo":"Настройки и информация","language":"Язык","newProject":"Новый проект","myProjects":"Мои проекты","search":"Поиск","searchBannergress":"Найти баннер","citySearch":"Город","nearMe":"Рядом со мной","searchRadius":"Радиус поиска","addBackground":"Добавить / заменить фон","addLayer":"Добавить слой","layersTitle":"Изображения и слои","multiSelection":"Множественный выбор","editSelection":"Изменить выбор","deleteSelection":"Удалить выбранное","group":"Сгруппировать","communityTitle":"Сообщество и поддержка","telegramOpen":"Связаться с поддержкой","tutorialHubTitle":"Обучение и начало работы","tutorialStart":"Начать тур","tutorialLater":"Позже","tutorialNever":"Больше не показывать","tutorialNext":"Далее","tutorialPrevious":"Назад","tutorialUnderstood":"ОК, понятно"});
I18N["uk"]=Object.assign({},I18N.en,{"fresco":"Банер","route":"Маршрут","missions":"Місії","publish":"Опублікувати","projects":"Проєкти","rows":"Ряди","image":"Зображення","text":"Текст","preview":"Попередній перегляд","export":"Експорт","settingsInfo":"Налаштування та інформація","language":"Мова","newProject":"Новий проєкт","myProjects":"Мої проєкти","search":"Пошук","searchBannergress":"Знайти банер","citySearch":"Місто","nearMe":"Поруч зі мною","searchRadius":"Радіус пошуку","addBackground":"Додати / замінити фон","addLayer":"Додати шар","layersTitle":"Зображення та шари","multiSelection":"Множинний вибір","editSelection":"Змінити вибір","deleteSelection":"Видалити вибране","group":"Згрупувати","communityTitle":"Спільнота та підтримка","telegramOpen":"Зв’язатися з підтримкою","tutorialHubTitle":"Навчання та початок роботи","tutorialStart":"Почати тур","tutorialLater":"Пізніше","tutorialNever":"Більше не показувати","tutorialNext":"Далі","tutorialPrevious":"Назад","tutorialUnderstood":"Гаразд, зрозуміло"});


/* v1.0.11-r2 — traductions complètes sans fallback anglais pour DE/PT/NL */
I18N["de"]={"fresco":"Banner","route":"Route","missions":"Missionen","publish":"Veröffentlichen","projects":"Projekte","rows":"Reihen","image":"Bilder","framing":"Ausschnitt","layers":"Ebenen","text":"Text","preview":"Vorschau","export":"Exportieren","wholeFresco":"Gesamter Banner","oneMission":"Eine Mission","noMission":"Keine Mission ausgewählt","addImage":"Bild hinzufügen","imageHint":"Das Bild wird direkt an die Prime-Geometrie angepasst.","circles":"Prime-Kreise","grid":"512er-Raster","numbers":"Nummern","enlarge":"Mission vergrößern","resetMission":"Mission zurücksetzen","prev":"Zurück","next":"Weiter","complete":"Mission vollständig","remaining":"Noch {n} Portal(e)","openIitc":"IITC Companion öffnen","tutorial":"Tutorial","installPlugin":"IITC-Plugin installieren / aktualisieren","autoAdvance":"Bei {n} Portalen automatisch zur nächsten Mission wechseln","reuseLast":"Das letzte Portal automatisch als erstes Portal der nächsten Mission übernehmen","noPortal":"Diese Mission enthält noch kein Portal.","action":"Aktion","hack":"Hacken","mod":"Mod installieren","capture":"Erobern / verbessern","link":"Link erstellen","field":"Feld erstellen","passphrase":"Passphrase","question":"Frage","answer":"Erwartete Antwort","save":"Speichern","cancel":"Abbrechen","settings":"Gemeinsame Einstellungen","commonDesc":"Gemeinsame Beschreibung","titleFormat":"Titelformat","defaultType":"Standardtyp","location":"Standort","visible":"Sichtbar","hidden":"Ausgeblendet","sequential":"Nacheinander","anyOrder":"Beliebige Reihenfolge","portalsPerMission":"Portale / Mission","editMission":"Mission bearbeiten","title":"Titel","description":"Beschreibung","missionReady":"Bereit","missionIncomplete":"Unvollständig","openRoute":"Route bearbeiten","publishPack":"BannerLab-Paket erstellen","openMat":"Mission Authoring Tool öffnen","ownWorkflow":"BannerLab verwendet jetzt sein eigenes Projektformat und ein eigenes Veröffentlichungspaket.","language":"Sprache","french":"Français","english":"English","spanish":"Español","companionStats":"Fußweg-Statistiken in IITC","companionStatsDesc":"Im IITC-Minifenster berechnet 📊 Nutzlose Statistiken geschätzte Gehstrecke, Zeit, Umweg und andere Dinge, nach denen niemand gefragt hat.","duplicateBad":"{n} Portal-Wiederverwendung(en) prüfen.","handoverOk":"Die Wiederverwendung vom Missionsende zum Start der nächsten Mission ist erlaubt.","pluginVersion":"Companion 0.6.6","undo":"Rückgängig","redo":"Wiederholen","subtitle":"Ingress-Prime-Banner","source":"Quelle","bannerHelp":"<b>Banner-Modus:</b> Mit 1 Finger verschiebst du die ausgewählte Ebene. Mit <b>2 Fingern</b> zoomst und drehst du.","missionHelp":"<b>Missionsmodus:</b> Tippe auf ein Medaillon. Für bequemes Bearbeiten nutze <b>Mission vergrößern</b>. Du kannst sie hier auch mit 1 Finger verschieben.","missionSelected":"Mission {n} ausgewählt","tapMedallion":"Tippe auf ein Medaillon","touchMissionFirst":"Tippe zuerst auf die Mission, deren Ausschnitt du ändern möchtest.","selectMissionFirst":"Wähle zuerst eine Mission aus.","heavyImage":"Sehr großes Bild. Dein Telefon könnte dabei seine Lebensentscheidungen überdenken.","imported":"{w} × {h} px importiert","textLayerDesc":"Jeder Text bleibt eine eigene Ebene und kann separat bearbeitet oder gelöscht werden.","layer":"Ebene","newText":"+ Neuer Text","size":"Größe","outline":"Kontur","color":"Farbe","outlineColor":"Konturfarbe","add":"Hinzufügen","update":"Aktualisieren","delete":"Löschen","zoom":"Zoom","localZoom":"Lokaler Zoom","rotation":"Drehung","center":"Zentrieren","reset":"Zurücksetzen","done":"Fertig","transformText":"Text transformieren","frameImage":"Bild ausrichten","pinchHint":"Die Zwei-Finger-Geste funktioniert weiterhin direkt auf dem Banner.","missionCropOnly":"Dieser Ausschnitt gilt nur für dieses Medaillon.","resetThisMission":"Diese Mission zurücksetzen","individualCrop":"Individueller Ausschnitt · 512 × 512","oneFinger":"1 Finger","move":"verschieben","twoFingers":"2 Finger","zoomRotate":"zoomen und drehen","previewPrime":"Prime-Vorschau","previewApplied":"Individuelle Missionsausschnitte sind bereits berücksichtigt.","previewOrder":"Nummer 1 liegt unten rechts. Danach läuft die Nummerierung nach links und über die oberen Reihen weiter.","exportTitle":"{n} Missionen exportieren","exportIntro":"Wähle schnelle Ausgabe oder verlustfreies PNG. Beide bleiben bei 512 × 512.","noBackground":"Kein Hintergrundbild geladen.","missionFormat":"Missionsformat","jpgFast":"Schnelles JPG · hohe Qualität","pngLossless":"Verlustfreies PNG · langsamer","fastEncoding":"Der Schnellmodus vermeidet die PNG-Kodierung, die auf dem Telefon mit Abstand am längsten dauert.","rowRender":"Der Hintergrund wird pro Reihe nur einmal gerendert statt sechsmal neu berechnet.","adjusted":"{n} Mission(en) mit individuellem Ausschnitt.","nianticCheck":"Prüfe vor dem Einreichen die Niantic-Regeln: Bildrechte, passender Inhalt und keine einzelne dominante Figur.","ready":"Bereit.","createZip":"ZIP erstellen","zipAssembly":"ZIP wird erstellt…","zipCreated":"ZIP erstellt.","zipDownloaded":"ZIP heruntergeladen.","saveShareZip":"ZIP speichern oder teilen","exportFinished":"{format}-Export abgeschlossen","exportFailed":"Export fehlgeschlagen.","newProject":"Neues Projekt","myProjects":"Meine Projekte","projectsSaved":"{n} Projekt(e) auf diesem Gerät gespeichert.","unnamed":"Unbenannt","opened":"Geöffnet","open":"Öffnen","rename":"Umbenennen","copy":"Kopieren","noSavedProject":"Kein gespeichertes Projekt.","renameProject":"Projekt umbenennen","renameHint":"Ein Name, den ein Mensch später wiedererkennt. Revolutionäres Konzept.","projectName":"Projektname","projectOpened":"Projekt geöffnet: {name}","projectRenamed":"Projekt umbenannt","deleteProject":"Dieses Projekt löschen?","deleteWarning":"Der Banner und das lokal gespeicherte Bild werden gelöscht.","copyCreated":"Kopie erstellt","projectDeleted":"Projekt gelöscht","newProjectCreated":"Neues Projekt mit Redacted erstellt","defaultProject":"Mein Banner","defaultNewProject":"Neuer Banner","copySuffix":"Kopie","versionLabel":"Version","infoPrime":"6 Spalten · 544 px · 512-px-Ausschnitt.","infoPlanner":"Portalaktionen, Passphrases, Übergabe Ende→Start und natives BannerLab-Paket.","infoCompanion":"Routen, Aktionen, Missions-übergreifende Linien, Optionen und Gehstatistiken.","disclaimer":"Ingress und Ingress Prime sind Marken von Niantic. Redacted BannerLab ist weder mit Niantic verbunden noch von Niantic unterstützt.","titleTokens":"$T = Name · $N = Nummer · $M = Gesamt · $0N = 01, 02…","pluginShareText":"Companion-Plugin 0.6.6. Ersetze in IITC Mobile die vorherige Version. Falls IITC das Überschreiben verweigert, entferne das alte Plugin einmal und installiere anschließend diese Datei.","pluginDialog":"Companion 0.6.6 installieren / aktualisieren","pluginShareFailed":"Das IITC-Plugin konnte nicht geteilt werden.","intelOpened":"IITC Mobile mit dem BannerLab-Projekt geöffnet.","intelPrimeOpened":"IITC Prime mit dem BannerLab-Projekt geöffnet.","intelFallback":"IITC Mobile wurde geöffnet. Companion verwendet den zuletzt synchronisierten Stand.","intelPrimeFallback":"IITC Prime wurde geöffnet. Companion verwendet den zuletzt synchronisierten Stand.","intelBrowser":"IITC nicht erkannt: Öffnen im Browser.","tutorialIntro":"Baue den gesamten Banner in IITC, ohne nach jedem Portal zu BannerLab zurückzukehren.","tut1Title":"Plugin einmal installieren","tut1Text":"Unter Route auf „IITC-Plugin installieren / aktualisieren“ tippen und die Datei anschließend in IITC Mobile als Benutzer-Plugin hinzufügen.","tut2Title":"IITC aus BannerLab öffnen","tut2Text":"BannerLab übergibt Projekt, aktive Mission und Sprache über ein lokales Fragment an Companion. Der Intel-Server bekommt diese Daten nie zu sehen.","tut3Title":"Direkt auf der Karte bauen","tut3Text":"Mit Companion kannst du Portale hinzufügen, bearbeiten oder entfernen, Missionen wechseln und Routen sehen, ohne zu BannerLab zurückzukehren.","tut4Title":"Am Ende synchronisieren","tut4Text":"„BannerLab synchronisieren“ schreibt alle geänderten Missionen zurück ins Projekt und öffnet BannerLab erneut.","tutNote":"Companion lässt sich verschieben und in der Größe ändern. Seine Einstellungen findest du unter Optionen.","installUpdate":"Installieren / aktualisieren","emptyTitleIssue":"Mission {n}: Titel fehlt","emptyDescIssue":"Mission {n}: Beschreibung fehlt","portalsIssue":"Mission {n}: {count}/{need} Portale","missingGuidIssue":"Mission {n}: {count} GUID(s) fehlen","passIssue":"Mission {n}: {count} unvollständige Passphrase(s)","reviewCount":"{n} Punkt(e) prüfen","projectReady":"BannerLab-Projekt bereit","fixBeforePublish":"Behebe diese Punkte vor der Veröffentlichung.","publisherDesc":"Der nächste Schritt befüllt das Mission Authoring Tool direkt aus diesem nativen Format. Das endgültige Absenden bleibt bewusst im offiziellen Tool.","packCreating":"BannerLab-Paket wird erstellt…","packCreated":"BannerLab-Paket erstellt","exportImpossible":"Export nicht möglich: {error}","missionResetDone":"Mission {n} zurückgesetzt","textDeleted":"Text gelöscht","histImport":"Bild importieren","histMissionZoom":"Missionszoom","histMissionRotation":"Missionsdrehung","histTextRotation":"Textdrehung","histImageRotation":"Bilddrehung","histTextZoom":"Textzoom","histImageZoom":"Bildzoom","histCenterText":"Text zentrieren","histCenterImage":"Bild zentrieren","histResetText":"Text zurücksetzen","histResetImage":"Bild zurücksetzen","histResetMission":"Mission zurücksetzen","histDeleteText":"Text löschen","histAddText":"Text hinzufügen","histEditText":"Text bearbeiten","routeActionHelp":"Hack / Mod / Erobern / Link / Feld / Passphrase direkt in Companion.","handoverDetail":"Das letzte Portal darf das erste Portal der nächsten Mission werden, ohne als unerlaubtes Duplikat zu gelten.","coordsMissing":"Koordinaten nicht gefunden.","coordsInvalid":"Ungültige Koordinaten.","duplicateElsewhere":"Dieses Portal wird bereits an anderer Stelle im Banner verwendet.","missionCompleteAdded":"Mission {n} vollständig · {next}","portalAdded":"Portal hinzugefügt · Mission {n}","syncOld":"Route synchronisiert · alter Companion erkannt: Version 0.6.6 installieren.","syncOk":"IITC-Route synchronisiert · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Direkt in Mission Authoring vorbereiten","livePublishShort":"Direkter Publisher","livePreparing":"{n} Missionen für Publisher werden vorbereitet…","liveReady":"Integrierter Publisher wird geöffnet…","liveNativeOnly":"Der direkte Publisher ist in der Android-APK verfügbar.","liveFailed":"Publisher konnte nicht geöffnet werden: {error}","liveExperimental":"Experimentell: Mission Authoring wird in einer von RBL gesteuerten Ansicht geöffnet. Als Erstes muss geprüft werden, ob die Google-Anmeldung auf deinem Telefon funktioniert.","backupTransfer":"Sicherung / Übertragung","exportPackBackup":"BannerLab-Paket exportieren","openOfficialOnly":"Nur offizielle Website öffnen","publisherPreparingImage":"Mission {n}/{total} wird gerendert…","browserPublish":"In Firefox veröffentlichen","browserPublishShort":"Browser-Publisher","browserSetup":"Browser-Publisher installieren / aktualisieren","browserPreparing":"Mission {n}/{total} wird vorbereitet…","browserOpening":"Firefox wird geöffnet…","browserNeed":"Der direkte Publisher nutzt Firefox Android + Violentmonkey, damit die Google-Anmeldung in einem normalen Browser bleibt.","browserFailed":"Publisher konnte nicht geöffnet werden: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 für missions.ingress.com. Einmal in Violentmonkey unter Firefox Android installieren.","browserShareDialog":"Publisher 0.4.0 installieren","browserShareFailed":"Browser-Publisher konnte nicht geteilt werden.","publisherUrlTooLarge":"Diese Mission ist zu groß, um sie an den Browser zu übergeben.","publisherReturn":"Vom Publisher zurückgekehrt.","publisherNoFirefox":"Firefox wurde nicht erkannt. Der Standardbrowser wird geöffnet, aber Publisher benötigt einen Browser mit Userscript-Unterstützung.","publisherBrowser":"Browser zum Veröffentlichen","chromeMode":"Chrome","chromeModeSub":"Keine zusätzliche App · kleines Lesezeichen + bei Nachfrage erlauben","firefoxMode":"Firefox","firefoxModeSub":"Automatisch nach Installation von Violentmonkey + Publisher","recommendedAuto":"Automatisch","noExtraApp":"Keine zusätzliche App","publishSelected":"Mission veröffentlichen","chromeSetup":"Chrome einrichten","firefoxSetup":"Firefox einrichten","chromeReady":"Chrome-Lesezeichen geprüft","firefoxReady":"Firefox-Publisher geprüft","notConfigured":"Einmalige Einrichtung erforderlich","chromeSetupTitle":"Chrome Publisher","chromeSetupIntro":"Chrome erlaubt RBL nicht, das Lesezeichen automatisch anzulegen. Die Einrichtung ist deshalb auf das absolute Minimum reduziert.","chromeStep1":"1. Code für das RBL-Publisher-Lesezeichen kopieren.","chromeStep2":"2. Mission Authoring in Chrome öffnen und die Seite als Lesezeichen speichern.","chromeStep3":"3. Das Lesezeichen bearbeiten: „RBL Publisher“ nennen und die URL durch den kopierten Code ersetzen.","chromeStep4":"4. In Mission Authoring auf die Adressleiste tippen, „RBL“ eingeben und das Lesezeichen zum Testen auswählen.","copyBookmarklet":"Lesezeichen-Code kopieren","bookmarkletCopied":"Lesezeichen-Code kopiert","openChromeSetup":"Chrome zur Einrichtung öffnen","testChrome":"Chrome-Lesezeichen testen","chromeRunHint":"In Chrome: Adressleiste antippen, RBL eingeben und „RBL Publisher“ auswählen.","chromeNeedsSetup":"Richte zuerst das Chrome-Lesezeichen „RBL Publisher“ ein.","chromeOpenFail":"Chrome konnte nicht geöffnet werden. Der Standardbrowser wird verwendet.","firefoxSetupTitle":"Firefox Publisher","firefoxSetupIntro":"Firefox kann Publisher über Violentmonkey automatisch laden. Das ist der angenehmste Modus.","sharePublisher":"Publisher-Userscript teilen","testFirefox":"Firefox-Publisher testen","firefoxNeedsSetup":"Installiere Violentmonkey und Publisher in Firefox, bevor du testest.","browserSaved":"Browser zum Veröffentlichen: {browser}","setupConfirmed":"Einrichtung geprüft.","bookmarkletCopyFail":"Automatisches Kopieren nicht möglich. Der Code wird unten angezeigt.","bookmarkletLabel":"Lesezeichen-Code","autoImpossibleChrome":"Automatisches Laden ist in Chrome Android ohne Erweiterung oder weitreichende Berechtigung nicht möglich. Das Lesezeichen bleibt erforderlich.","openChromePublish":"Chrome wird geöffnet…","openFirefoxPublish":"Firefox wird geöffnet…","chromeWizardTitle":"Chrome einrichten","chromeWizardIntro":"Einmalige Einrichtung. RBL merkt sich deinen Fortschritt.","chromeFileTitle":"Publisher speichern","chromeFileText":"RBL speichert Publisher direkt unter Documents/RedactedBannerLab. Das Android-Teilen-Menü wird nicht benötigt.","chromeSaveFile":"Publisher speichern","chromeFileDone":"Publisher gespeichert","alreadySaved":"Ich habe ihn bereits gespeichert","chromeBookmarkTitle":"Mini-Lesezeichen erstellen","chromeBookmarkText":"Das Lesezeichen enthält nicht mehr den gesamten Publisher. Es ist nur {n} Zeichen lang und lädt die gerade gespeicherte Datei.","chromeBookmarkName":"Lesezeichenname: RBL Publisher","chromeBookmarkHow":"In Chrome: Mission Authoring öffnen → ⋮ → Zu Lesezeichen hinzufügen. Danach das Lesezeichen bearbeiten, „RBL Publisher“ nennen und den Code als URL einfügen.","copyMiniCode":"Mini-Code kopieren","miniCodeCopied":"Mini-Code kopiert","openChromeBookmark":"Mission Authoring öffnen","bookmarkCreated":"Ich habe das Lesezeichen erstellt","chromeTestTitle":"Testen und erlauben","chromeTestText":"RBL öffnet Mission Authoring. Gib RBL ein und starte das Lesezeichen. Chrome fragt nach Publisher und anschließend nach der aktuellen JSON-Datei. Die JSON wird bei jedem neuen Banner neu gewählt, nicht zwischen einzelnen Missionen.","chromeTestButton":"In Chrome testen","chromeTestWaiting":"In Chrome: RBL eingeben → RBL Publisher → falls gefragt publisher.js auswählen → Erlauben.","chromeSetupSuccess":"Chrome ist bereit","chromeSetupSuccessText":"Chrome ist bereit. Publisher bleibt gespeichert; die Banner-JSON wird für jede neue Sitzung bewusst neu ausgewählt, damit kein altes Projekt unbemerkt wiederverwendet wird.","publishNow":"Jetzt veröffentlichen","wizardPrev":"Zurück","wizardNext":"Weiter","wizardRestart":"Einrichtung neu starten","stepOf":"Schritt {n}/3","chromeFileShareText":"Speichere diese publisher.js an einem leicht auffindbaren Ort, etwa in Downloads. Chrome fragt beim ersten Test danach.","chromeFileShareDialog":"RBL Publisher speichern","chromeFileShareFail":"Publisher-Datei konnte nicht vorbereitet werden.","chromePermissionHint":"Chrome kann erneut um Zugriff auf publisher.js bitten. Du kannst ihn einfach erlauben.","chromeNotAutoFavorite":"RBL kann ein Chrome-Lesezeichen nicht automatisch erstellen. Das ist der einzige zwingende manuelle Schritt.","codeLength":"{n} Zeichen","chromeStepSaved":"Schritt gespeichert","chromeResetDone":"Chrome-Einrichtung zurückgesetzt","chromeSelectFileHint":"In Chrome auswählen: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","bannerDescription":"Bannerbeschreibung","required":"Erforderlich","bannerDescriptionHint":"Das ist die Standardbeschreibung für alle Missionen. Einzelne Missionen kannst du später weiterhin individuell anpassen.","bannerDescriptionRequired":"Eine Bannerbeschreibung ist erforderlich.","describeBeforePublish":"Banner zuerst beschreiben","describeBeforePublishText":"Die Veröffentlichung bleibt gesperrt, bis der Banner eine Beschreibung hat. Sie dient als Standard für alle Missionen.","saveAndContinue":"Speichern und weiter","missionPublishBlocked":"Mission kann nicht veröffentlicht werden","missionNeedsPortals":"Mission {n} hat {count}/{need} Portale. Vor der Veröffentlichung sind mindestens {need} erforderlich.","completeMission":"Mission vervollständigen","currentMissionReady":"Mission ist bereit zur Veröffentlichung","publishBlockedHint":"Die Veröffentlichung bleibt gesperrt, bis alle Pflichtangaben vollständig sind.","minimumSix":"Mindestens 6 Portale pro Mission","publisherDescRequired":"Publisher lehnt Missionen ohne Beschreibung ab.","publisherPortalsRequired":"Publisher lehnt Missionen mit weniger als 6 Portalen ab.","playBanners":"Banner finden","playHub":"Banner finden","searchBannergress":"Banner finden","searchPlaceholder":"Name oder Stichwort","search":"Suchen","favorites":"Favoriten","currentBanner":"Fortsetzen","noFavorites":"Noch keine Favoriten. Der lokale Speicher genießt die Ruhe.","noPlaySession":"Aktuell läuft kein Banner.","searchPrompt":"Suche nach Name und/oder Gebiet mit echter Entfernungsbegrenzung.","searching":"Suche läuft…","searchError":"Bannergress-Suche fehlgeschlagen: {error}","missionsCount":"{n} Missionen","distanceKm":"{n} km","favorite":"Favorit","removeFavorite":"Favorit entfernen","playThisBanner":"Diesen Banner starten","resumeBanner":"Diesen Banner fortsetzen","stopBanner":"Overlay stoppen","openCurrentMission":"Aktuelle Mission öffnen","overlayPermissionTitle":"RBL-Overlay erlauben","overlayPermissionText":"Android muss Redacted BannerLab erlauben, über Ingress angezeigt zu werden. Eine Systemberechtigung, dann kann sich der Dino um seine Angelegenheiten kümmern.","overlayPermissionButton":"Anzeige über anderen Apps erlauben","overlayPermissionWaiting":"Kehre zu RBL zurück, nachdem du die Berechtigung erteilt hast.","overlayStarted":"Missions-Overlay gestartet.","overlayFailed":"Overlay konnte nicht gestartet werden: {error}","bannerLoadError":"Dieser Banner konnte nicht geladen werden: {error}","bannerOffline":"Dieser Banner enthält keine nutzbaren Missionen.","bannerDisabled":"{n} deaktivierte Mission(en)","addressUnknown":"Standort nicht angegeben","doneMissions":"{done}/{total} abgeschlossen","deepLinkOnly":"RBL steuert Ingress nicht: Das Overlay öffnet lediglich offizielle Missions-Deep-Links.","bannergressCredit":"Suche über Bannergress","publisherWholeBanner":"Gesamten Banner vorbereiten","publisherWholeHint":"Eine Browsersitzung: Alle Missionen und Bilder werden gemeinsam vorbereitet.","publisherAllRequired":"Alle Missionen müssen vollständig sein, bevor die Veröffentlichungssitzung gestartet werden kann.","publisherSessionCreating":"Publisher-Sitzung wird vorbereitet {n}/{total}…","publisherSessionReady":"Sitzung unter Documents/RedactedBannerLab gespeichert. Mission Authoring wird geöffnet…","publisherSessionFileText":"RBL speichert die Sitzung automatisch unter Documents/RedactedBannerLab.","publisherSessionDialog":"Publisher-Sitzung","publisherSessionShareFail":"Publisher-Sitzung konnte nicht vorbereitet werden.","chromeSessionHint":"Chrome: Starte das Lesezeichen RBL Publisher. Für jeden neu vorbereiteten Banner fragt Chrome ausdrücklich nach RBL_Current_Session.rblpub.json. Zwischen Missionen ist nichts weiter nötig.","firefoxSessionHint":"Firefox: Publisher öffnet automatisch. Lade RBL_Current_Session.rblpub.json, falls die aktuelle Sitzung noch nicht bekannt ist.","easterEgg":"Du wolltest es so.","bannerNameSearch":"Name / Stichwort","citySearch":"Stadt","authorSearch":"Autor","cityPlaceholder":"z. B. Nantes","authorPlaceholder":"z. B. AgentName","nearMe":"In meiner Nähe","nearMeOn":"Mein Standort aktiviert","nearMeHint":"Verwendet deinen aktuellen Standort statt einer Stadt.","locationGetting":"Standort wird ermittelt…","locationError":"Standort konnte nicht ermittelt werden: {error}","locationReady":"Standort ermittelt","searchCriteriaRequired":"Gib mindestens ein Suchkriterium ein.","cityResolving":"Stadt wird gesucht…","cityNotFound":"Für „{city}“ wurde kein Bannergress-Ort gefunden.","cityUsing":"Verwendeter Ort: {city}","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Verschieben","overlayMinimize":"Minimieren","overlayClose":"Schließen","overlayMoved":"Overlay-Position gespeichert","searchReset":"Leeren","resultsCount":"{n} Ergebnis(se)","searchFilters":"Aktive Filter","allPublicBanners":"Öffentliche Bannergress-Banner","searchRadius":"Suchradius","radiusHint":"Gilt rund um die Stadt oder deinen aktuellen Standort.","locationDisabled":"Die Standortdienste sind auf diesem Telefon deaktiviert.","locationPermissionDenied":"BannerLab darf deinen Standort nicht verwenden.","locationUnavailable":"Standort nicht verfügbar. Prüfe, ob die Standortdienste des Telefons aktiviert sind.","locationTimeout":"Der Standort konnte nicht rechtzeitig ermittelt werden. Prüfe, ob die Standortdienste aktiviert sind.","openLocationSettings":"Standort aktivieren","openAppSettings":"App-Einstellungen öffnen","cityNoCoordinates":"„{city}“ wurde gefunden, aber die Position kann nicht verwendet werden.","cityUsingRadius":"Verwendet: {city} · Radius {radius} km","radiusResults":"{n} Ergebnis(se) innerhalb von {radius} km","distanceFromPoint":"{distance} entfernt","locationChecking":"Standortdienste werden geprüft…","publisherCurrentFile":"Aktuelle Datei: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher unter Documents/RedactedBannerLab gespeichert.","chromeFileWriteFail":"Publisher konnte nicht unter Documents/RedactedBannerLab gespeichert werden.","chromeCurrentSessionHint":"Für jeden neuen Banner: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json auswählen.","browserResume":"Sitzung vorbereitet. Der RBL-Tab mit Mission Authoring wird geöffnet…","chromeResumeHint":"Chrome verwendet jetzt denselben für RBL reservierten Mission-Authoring-Tab.","firefoxResumeHint":"Mission Authoring wird im Veröffentlichungsbrowser geöffnet.","browserResumeFallback":"Der RBL-Tab konnte nicht wiederverwendet werden. Browser wird ersatzweise neu geöffnet.","publisherAutoRefresh":"Publisher überwacht nun die aktuelle Sitzungsdatei und lädt einen neu vorbereiteten Banner automatisch neu.","flowLocked":"Banner-Bearbeitung gesperrt","flowLockedText":"Schritt {step} ist aktiv. Wähle „1 Banner“, um Bild, Text oder Ausschnitt zu bearbeiten.","returnFresco":"Zum Bearbeiten „1 Banner“ auswählen","flowLockedToast":"Kehre zu Schritt 1 Banner zurück, um den Banner zu bearbeiten.","publisherTabReuse":"RBL verwendet eine feste Browser-Anwendungs-ID, um denselben Tab wiederzuverwenden.","todo":"Zu erledigen","history":"Verlauf","inProgress":"Läuft","addTodo":"Zu „Zu erledigen“ hinzufügen","removeTodo":"Aus „Zu erledigen“ entfernen","noTodo":"Keine Banner zu erledigen. Verdächtig vernünftig.","noHistory":"Noch keine gespielten Banner. Der Dino langweilt sich.","bannerMap":"Routenkarte","openMap":"Karte anzeigen","navigateStart":"Zum Start navigieren","startUnavailable":"Startpunkt nicht verfügbar.","mapUnavailable":"Bannergress liefert für diesen Banner keine nutzbaren Koordinaten.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Teilen / Gruppe","shareProgress":"Fortschritt teilen","shareBanner":"Banner teilen","shareIntro":"Der QR-Code öffnet RBL beim selben Banner und derselben Missionsnummer. Es wird kein Bannergress-Konto verwendet.","copyLink":"RBL-Link kopieren","linkCopied":"RBL-Link kopiert","shareNow":"Teilen","bannergressPage":"Auf Bannergress öffnen","joinBanner":"Banner beitreten","joinAtMission":"Bei Mission {n} einsteigen","sharedBannerLoaded":"Geteilter Banner geladen · Mission {n}","sharedBannerError":"Geteilter Banner konnte nicht geladen werden: {error}","playStats":"Sitzungsstatistik","startedAt":"Gestartet","finishedAt":"Beendet","elapsed":"Aktive Zeit","estimatedDistance":"Geschätzte Strecke","missionsDone":"Erledigte Missionen","paused":"Pausiert","playing":"Läuft","completedBanner":"Abgeschlossen","replayBanner":"Erneut spielen","resumeFromHistory":"Fortsetzen","groupNoServer":"Serverloser Gruppenmodus: Teile QR/Link erneut, wenn die Gruppe zu einer anderen Mission wechselt.","publicOnly":"Nur öffentliche Bannergress-Suche/-Daten · keine Anmeldung erforderlich.","routePoints":"{n} Routenpunkte","uselessStats":"Nutzlose Statistiken","loadingStats":"Berechne Dinge, nach denen niemand gefragt hat…","statsUnavailable":"Nicht genug Koordinaten, um nutzlose Statistiken zu berechnen.","bgDistance":"Bannergress-Distanz","calculatedTrack":"Geschätzte Gehstrecke","walkingEstimate":"Geschätzte Gehzeit","routeSteps":"Schritte","uniquePlaces":"Einmalige Orte","revisitedPlaces":"Wiederholte Besuche","stepsPerKm":"Schritte / km","avgMissionDistance":"Durchschnitt / Mission","longestMission":"Längste Mission","longestLeg":"Längster Abschnitt","betweenMissions":"Übergänge zwischen Missionen","detourFactor":"Umwegfaktor","routeCoverage":"Kartenabdeckung","missionShort":"M{n}","straightLine":"Start → Ziel","funStatsDisclaimer":"RBL routet jeden Abschnitt von Portal zu Portal über das Fußwegenetz von OpenStreetMap. Jeder Abschnitt wird auf Plausibilität geprüft: unmögliche Abkürzungen oder offensichtlich absurde Umwege werden nur für diesen Abschnitt durch die direkte Distanz ersetzt. Das ist eine Gehschätzung, keine GPS-Messung.","minutesShort":"{n} Min.","hoursMinutes":"{h} Std. {m} Min.","xFactor":"×{n}","showUselessStats":"📊 Nutzlose Statistiken","hideUselessStats":"Statistiken ausblenden","statsLoaded":"Statistiken berechnet","directGeometric":"Kumulierte direkte Distanz","routingDetour":"Netz / Direkt-Verhältnis","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla nicht verfügbar · geometrische Schätzung","routingLoading":"Tatsächliche Gehroute wird berechnet…","routingFailed":"Fußweg-Routing nicht verfügbar, geometrische Statistik wird verwendet.","routingNative":"Valhalla + OSM · Plausibilitätsprüfung pro Abschnitt","routingWeb":"Valhalla + OSM · Plausibilitätsprüfung pro Abschnitt","routingErrorDetail":"Valhalla fehlgeschlagen: {error}","ingressRadius":"Ingress-Reichweite","ingressRadiusValue":"40 m","correctedLegs":"Korrigierte Abschnitte","rawValhalla":"Valhalla roh","creditsTitle":"Credits & Danke","bannergressThanks":"Danke, Bannergress","bannergressThanksText":"Die Bannersuche und mehrere öffentliche Details in Redacted BannerLab basieren auf öffentlichen Bannergress-Daten. Danke an das Team und alle Mitwirkenden für die enorme Arbeit rund um Ingress-Banner.","bannergressNoLogin":"RBL verwendet kein Bannergress-Konto, sondern nur öffentliche Daten, die für Suche und Anzeige erforderlich sind.","independentProject":"Redacted BannerLab ist ein unabhängiges Projekt und weder mit Bannergress noch mit offiziellen Ingress-Diensten verbunden oder von ihnen unterstützt.","visitBannergress":"Bannergress besuchen","mapCredits":"Karten & Routing","mapCreditsText":"Die Karten verwenden OpenStreetMap-Daten. Schätzungen für Fußwege nutzen die Routing-Engine Valhalla.","rblCreditsFoot":"Danke an alle Tools und Mitwirkenden, die dieses Ingress-Missionsökosystem möglich machen.","layersTitle":"Bilder & Ebenen","layersDesc":"Verwalte hier den Hintergrund und alle darüberliegenden Bilder. Die Vorschaubilder helfen dir, die richtige Ebene zu finden; anschließend kannst du sie auswählen, ausblenden, umsortieren oder gruppieren.","backgroundLayer":"Haupthintergrund","addBackground":"Hintergrund hinzufügen / ersetzen","addLayer":"Ebene hinzufügen","layerName":"Bildebene","selected":"Ausgewählt","visibleLayer":"Sichtbar","hiddenLayer":"Ausgeblendet","moveUp":"Nach oben","moveDown":"Nach unten","groupSelection":"Auswahl gruppieren","group":"Gruppieren","ungroup":"Gruppierung aufheben","groupNeedTwo":"Wähle mindestens zwei Ebenen zum Gruppieren aus.","groupCreated":"Ebenen gruppiert","groupRemoved":"Gruppierung aufgehoben","deleteLayer":"Ebene löschen","layerDeleted":"Ebene gelöscht","layerAdded":"Ebene hinzugefügt","backgroundReplaced":"Hintergrund ersetzt","backgroundMissing":"Kein Haupthintergrund","backgroundFixed":"Der Hintergrund bleibt immer unter den anderen Ebenen.","groupHint":"Markiere mehrere Ebenen und tippe auf Gruppieren. Eine Gruppe wird gemeinsam verschoben, gezoomt und gedreht.","layerOrder":"Ebenenreihenfolge","layerTransform":"Ebene transformieren","groupTransform":"Gruppe transformieren","renameLayer":"Umbenennen","duplicateLayer":"Duplizieren","layerDuplicated":"Ebene dupliziert","histAddLayer":"Ebene hinzufügen","histDeleteLayer":"Ebene löschen","histReorderLayer":"Ebene umsortieren","histGroupLayers":"Ebenen gruppieren","histUngroupLayers":"Ebenengruppierung aufheben","histVisibilityLayer":"Ebenensichtbarkeit","histRenameLayer":"Ebene umbenennen","histDuplicateLayer":"Ebene duplizieren","layerGroupBadge":"Gruppe","layerUngroup":"Diese Gruppe aufheben","layerSelectHint":"Die ausgewählte Ebene kann anschließend direkt auf dem Banner verschoben werden.","layerOpacity":"Deckkraft","layerDimensions":"{w} × {h} px","noImageContent":"Füge vor dem Export mindestens ein Bild hinzu.","groupRelative":"Die folgenden Regler transformieren die gesamte Gruppe gemeinsam.","groupZoom":"Gruppenzoom","groupRotation":"Gruppendrehung","clearGroupSelection":"Auswahl leeren","allLayersTitle":"Ebenen","allLayersDesc":"Wähle das Element aus, das du bearbeiten möchtest. Bilder und Texte bleiben zusätzlich in ihren jeweiligen Menüs editierbar.","imageLayersSection":"Bilder","textLayersSection":"Text","noExtraImageLayer":"Keine zusätzliche Bildebene","noTextLayer":"Keine Textebene","selectLayer":"Auswählen","editLayer":"Bearbeiten","missionNumberQuestion":"Wie lautet die Missionsnummer?","groupName":"Gruppe {n}","groupCount":"{n} Ebene(n)","creatorBy":"Erstellt von Zw4nn","communityTitle":"Community & Support","communityText":"Community und Support erreichst du direkt über den Redacted-BannerLab-Bot.","telegramOpen":"Support kontaktieren","reportProblem":"Problem melden","reportProblemText":"Kopiere eine technische Diagnose und kontaktiere anschließend den Support über den Bot.","copyDiagnostic":"Diagnose kopieren","diagnosticCopied":"Diagnose kopiert","diagnosticCopyFailed":"Diagnose konnte nicht kopiert werden","diagnosticDescription":"Problembeschreibung:","portableProject":"Portables Projekt","portableProjectDesc":"Exportiere einen einzelnen Banner samt Bildern, Ebenen, Text, Schriften, Missionen und Route.","exportProject":"Exportieren","shareProject":"Teilen","importProject":"Projekt importieren","projectExporting":"Projekt wird vorbereitet…","projectExported":"Projekt gespeichert","projectShared":"Projekt zum Teilen bereit","projectImportSuccess":"Projekt importiert","projectImportInvalid":"Diese Datei ist kein gültiges Redacted-BannerLab-Projekt.","projectShareTitle":"Redacted-BannerLab-Projekt","projectImportHint":"Das importierte Projekt wird hinzugefügt, ohne deine anderen Projekte zu verändern.","backupTitle":"Sichern & Wiederherstellen","backupText":"Sichere alle BannerLab-Projekte, Einstellungen und Bilder in einer portablen JSON-Datei.","backupFolder":"Sicherungsordner","backupFolderChoose":"Ordner auswählen","backupFolderChange":"Ordner ändern","backupFolderNone":"Kein Ordner ausgewählt","backupFolderReady":"Ordner eingerichtet","backupAuto":"Automatische Sicherung im Hintergrund","backupAutoHint":"Wenn aktiviert, bereitet BannerLab nach Änderungen regelmäßig eine Sicherung vor und erzwingt beim Wechsel in den Hintergrund eine letzte Speicherung.","backupNow":"Jetzt sichern","backupExport":"JSON exportieren","backupImport":"JSON importieren","backupWorking":"Sicherung wird erstellt…","backupSaved":"Sicherung abgeschlossen","backupAutoSaved":"Automatische Sicherung abgeschlossen","backupFailed":"Sicherung fehlgeschlagen: {error}","backupNeedFolder":"Wähle zuerst einen Sicherungsordner.","backupFolderError":"Dieser Ordner kann nicht verwendet werden.","backupImported":"Sicherung wiederhergestellt","backupInvalid":"Diese Datei ist keine gültige Redacted-BannerLab-Sicherung.","backupImportTitle":"Sicherung wiederherstellen","backupImportText":"{n} Projekt(e) gefunden · Sicherung vom {date}","backupMerge":"Zusammenführen","backupReplace":"Alles ersetzen","backupReplaceWarn":"Alles ersetzen löscht vor der Wiederherstellung die derzeit auf diesem Gerät gespeicherten Projekte.","backupCancel":"Abbrechen","backupLast":"Letzte Sicherung: {date}","backupNever":"Noch keine Sicherung","backupPortable":"Die JSON-Datei enthält auch die Bilder. Sie kann daher groß werden, ist dafür aber vollständig eigenständig.","backupNativeOnly":"Automatische Ordnersicherungen sind unter Android verfügbar. JSON-Export und -Import funktionieren weiterhin überall.","backupFolderChosen":"Sicherungsordner gespeichert","backupNoChanges":"Keine Änderungen zu sichern.","studioEdit":"Im Vollbild bearbeiten","studioTitle":"Bearbeitungsstudio","studioLayers":"Ebenen","studioTexts":"Text","studioTools":"Werkzeuge","studioFit":"6 Missionen","studioFitOne":"1 Mission","studioFitAll":"Alle","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Vollbild","studioRotateHint":"6 Missionen vertikal · weitere Reihen werden nach rechts gescrollt.","studioSelected":"Ausgewähltes Element","studioNoLayer":"Wähle seitlich eine Ebene oder ein Textelement aus.","studioGroupSelect":"Auswahl gruppieren","studioGroupNow":"Gruppieren","studioOpenFull":"Komplette Verwaltung öffnen","studioOpacity":"Deckkraft","studioClose":"Studio verlassen","studioPan":"Verschieben","studioAddText":"Text hinzufügen","studioNoText":"Noch kein Text.","studioEditText":"Text bearbeiten","studioDuplicateText":"Text duplizieren","font":"Schriftart","fontWeight":"Schriftstärke","fontItalic":"Kursiv","letterSpacing":"Zeichenabstand","lineHeight":"Zeilenhöhe","textAlign":"Ausrichtung","alignLeft":"Links","alignCenter":"Zentriert","alignRight":"Rechts","importFont":"Schrift importieren","fontImported":"Schrift importiert: {name}","fontInvalid":"Diese Schrift wird nicht unterstützt.","fontTooLarge":"Die Schriftdatei ist zu groß (max. 12 MB).","textBackground":"Texthintergrund","textBackgroundColor":"Hintergrundfarbe","textBackgroundOpacity":"Hintergrund-Deckkraft","textBackgroundPadding":"Innenabstand des Hintergrunds","textBackgroundRadius":"Eckenradius","textTypography":"Typografie","tutorialHubTitle":"Tutorials & Einstieg","tutorialHubText":"Starte jederzeit erneut eine geführte Tour. Redacted erklärt dir auch nur den Teil, den du gerade brauchst.","tutorialOpen":"Tutorials anzeigen","tutorialWelcomeTitle":"Willkommen bei Redacted BannerLab","tutorialWelcomeText":"Redacted kann dir das Labor zeigen. Zwei Minuten, ein paar Buttons und am Ende nicht einmal eine Prüfung.","tutorialStart":"Tour starten","tutorialLater":"Später","tutorialNever":"Nicht mehr anzeigen","tutorialPrevious":"Zurück","tutorialNext":"Weiter","tutorialUnderstood":"OK, verstanden","tutorialClose":"Schließen","tutorialDone":"Tutorial abgeschlossen","tutorialSeen":"Gesehen","tutorialQuick":"Kurztour","tutorialQuickDesc":"Die wichtigsten Bedienelemente und der gesamte BannerLab-Ablauf.","tutorialBanner":"Banner erstellen","tutorialBannerDesc":"Vom Projekt bis zur Vorschau und zum Export der Missionen.","tutorialLayers":"Bilder, Ebenen & Text","tutorialLayersDesc":"Hintergrund, überlagerte Bilder, Ebenen und Typografie-Werkzeuge.","tutorialIitc":"Route mit IITC erstellen","tutorialIitcDesc":"Companion installieren, Portale hinzufügen und Route synchronisieren.","tutorialPublish":"Missionen veröffentlichen","tutorialPublishDesc":"Missionen vorbereiten und anschließend Publisher und Mission Authoring verwenden.","tutorialBackup":"Sicherungen & portable Projekte","tutorialBackupDesc":"BannerLab sichern oder einen vollständigen Banner teilen.","importRolesHint":"Haupthintergrund = Basisbild des Banners · Ebene = zusätzlich darüberliegendes Bild.","tutProjectTitle":"Deine Projekte","tutProjectText":"Jeder Banner lebt in seinem eigenen Projekt. Du kannst ihn exportieren oder teilen, ohne alle anderen Projekte mitzuschleppen.","tutNameTitle":"Projektname","tutNameText":"Gib deinem Banner einen Namen, den du später wiedererkennst.","tutRowsTitle":"Anzahl der Reihen","tutRowsText":"Eine Reihe enthält 6 Missionen. Hier legst du die endgültige Höhe des Banners fest.","tutImageTitle":"Bilder & Ebenen","tutImageText":"Importiere hier den Haupthintergrund und zusätzliche Bilder. Auf demselben Bildschirm kannst du Bildebenen auswählen, sortieren, ausblenden und gruppieren.","tutBackgroundTitle":"Haupthintergrund","tutBackgroundText":"Für dein erstes richtiges Bild nimm Haupthintergrund. Es ersetzt das Basisbild und bedeckt den Banner.","tutExtraLayerTitle":"Ebene hinzufügen","tutExtraLayerText":"Ein zweites Bild wird als Ebene über den Hintergrund gelegt und bleibt verschiebbar, skalierbar und ausblendbar.","tutLayersTitle":"Bildebenen verwalten","tutLayersText":"An den Vorschaubildern erkennst du, welche Bildebene du gerade bearbeitest. Wähle sie aus, sortiere sie um, blende sie aus oder markiere mehrere Bilder zum Gruppieren.","tutTextTitle":"Text","tutTextText":"Füge Text hinzu, wähle Schrift, Abstände, Hintergrund und Eckenradius oder importiere eine eigene Schriftart.","tutPreviewTitle":"Vorschau","tutPreviewText":"Prüfe vor dem Export jede Mission. Individuelle Ausschnitte sind bereits berücksichtigt.","tutExportTitle":"Export","tutExportText":"Wenn alles passt, erzeugt BannerLab die 512 × 512 großen Missionsbilder in der richtigen Reihenfolge.","tutStudioTitle":"Vollbild-Studio","tutStudioText":"Ein komfortabler Vollbildeditor mit seitlichen Bedienelementen und großen Touch-Flächen.","tutFlowTitle":"Die 4 Schritte","tutFlowText":"Banner → Route → Missionen → Veröffentlichen. BannerLab folgt genau diesem Ablauf.","tutRouteTitle":"Route","tutRouteText":"Die Route verbindet die Missionen mit echten Ingress-Portalen. IITC Companion übernimmt die Kartenarbeit.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion nimmt aktives Projekt, Mission, Portale, Aktionen und Gehstatistiken mit nach IITC.","tutInstallCompanionTitle":"Companion installieren","tutInstallCompanionText":"Installiere oder aktualisiere das Userscript einmal in IITC Mobile.","tutOpenIitcTitle":"IITC öffnen","tutOpenIitcText":"Öffne IITC aus BannerLab, damit Projekt und aktive Mission an Companion übergeben werden.","tutAutoRouteTitle":"Zwischen Missionen wechseln","tutAutoRouteText":"Die nächste Mission kann automatisch geöffnet werden und das letzte Portal der vorherigen Mission als erstes übernehmen.","tutPortalListTitle":"Deine Portale","tutPortalListText":"Portale kommen mit GUID, Koordinaten, Reihenfolge und Aktion zurück, damit die Route vollständig rekonstruiert werden kann.","tutMissionsTitle":"Missionen vorbereiten","tutMissionsText":"Gib vor der Veröffentlichung die gemeinsame Beschreibung an und prüfe jede Mission.","tutMissionDescTitle":"Pflichtbeschreibung","tutMissionDescText":"BannerLab weist auf fehlende Angaben hin, bevor eine Veröffentlichung erlaubt wird.","tutPublishTitle":"Veröffentlichen","tutPublishText":"Wenn Route und Beschreibungen fertig sind, geht es hier weiter. Das endgültige Absenden bleibt im offiziellen Tool.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab bereitet Missionsdaten und Veröffentlichungsablauf vor. Nach dem Absenden prüfst du mit „Ich habe eingereicht“, ob die Mission veröffentlicht wurde.","tutInfoTitle":"Einstellungen, Hilfe & Support","tutInfoText":"Unter Einstellungen & Infos findest du Sprache, Sicherungen, Tutorials und Support über den Redacted-BannerLab-Bot.","tutBackupTitle":"Vollständige Sicherung","tutBackupText":"Die vollständige JSON enthält alle Projekte, Einstellungen, Bilder und Schriften. Unter Android kann zusätzlich ein automatischer Sicherungsordner verwendet werden.","tutPortableTitle":"Portables Projekt","tutPortableText":"Exportiere, teile oder importiere einen einzelnen Banner mit Bildern, Text, Schriften, Missionen und Route.","tutSupportTitle":"Hilfe nötig?","tutSupportText":"Kopiere bei Bedarf die Diagnose und kontaktiere den Support. Der Bot verlinkt außerdem Kanal und Diskussionsgruppe.","settingsInfo":"Einstellungen & Infos","addMissionLayer":"Auf einer Mission","importMissionSeries":"Serie importieren","missionLayer":"Missionsebene","globalLayer":"Globale Ebene","layerScope":"Ebenenbereich","wholeBanner":"Gesamter Banner","missionTarget":"Zugeordnete Mission","fitMode":"Anpassung","fitCover":"Füllen","fitContain":"Einpassen","missionBadge":"M{n}","missionLayerHint":"Diese Ebene bleibt mit Mission {n} verbunden und wird automatisch auf deren Kachel begrenzt.","missionSeriesTitle":"Missionsserie importieren","missionSeriesText":"Ordne jedes Bild einer Mission zu. BannerLab platziert und beschneidet die Bilder automatisch.","missionSeriesDetected":"{n} Bild(er) erkannt","missionSeriesImport":"Ebenen importieren","missionSeriesTooMany":"Du hast mehr Bilder als Missionen ausgewählt. Einer Mission können mehrere Bilder zugeordnet werden.","missionLayerAdded":"Bild zu Mission {n} hinzugefügt","missionSeriesAdded":"{n} Missionsebene(n) hinzugefügt","missionScopeMismatch":"Missionsebenen können nur gruppiert werden, wenn sie derselben Mission zugeordnet sind.","missionLayerTutorialTitle":"Mit Missionen verknüpfte Ebenen","missionLayerTutorialText":"Tippe auf „Ebene hinzufügen“ und wähle: gesamter Banner, eine Mission oder mehrere Missionen. Bei einer Mission platziert BannerLab das Bild automatisch in der richtigen Kachel und begrenzt es darauf. Für mehrere Missionen importierst du eine Serie und ordnest jedes Bild der gewünschten Mission zu.","addLayerChoiceTitle":"Ebene hinzufügen","addLayerChoiceText":"Wähle, wohin diese Ebene gehört. Du kannst den Bereich später jederzeit ändern.","addLayerWhole":"Auf dem gesamten Banner","addLayerWholeText":"Ein frei bewegliches und skalierbares Bild über dem gesamten Banner.","addLayerOneMission":"Auf einer Mission","addLayerOneMissionText":"Ein Bild, das automatisch auf der ausgewählten Mission platziert und auf deren Kachel begrenzt wird.","addLayerManyMissions":"Auf mehreren Missionen","addLayerManyMissionsText":"Importiere eine Bildserie und ordne jedes Bild der gewünschten Mission zu.","multiSelection":"Mehrfachauswahl","multiSelectionHint":"Markiere mehrere Ebenen, um eine gemeinsame Aktion anzuwenden, sie zu gruppieren oder zu löschen.","selectionActions":"Aktionen für Auswahl","editSelection":"Auswahl bearbeiten","deleteSelection":"Auswahl löschen","selectedLayersCount":"{n} Ebene(n) ausgewählt","bulkScopeKeep":"Aktuellen Bereich beibehalten","bulkMissionKeep":"Aktuelle Missionen beibehalten","bulkFitKeep":"Aktuelle Anpassung beibehalten","bulkVisibility":"Sichtbarkeit","bulkVisibilityKeep":"Nicht ändern","bulkShow":"Einblenden","bulkHide":"Ausblenden","bulkOpacityEnable":"Deckkraft ändern","applyToSelection":"Auf ausgewählte Ebenen anwenden","selectionUpdated":"Ausgewählte Ebenen aktualisiert","selectionDeleted":"Ausgewählte Ebenen gelöscht","deleteSelectionConfirm":"{n} ausgewählte Ebene(n) endgültig löschen?","selectionEmpty":"Wähle mindestens eine Ebene aus.","layerScopeHelp":"Gesamter Banner: Die Ebene kann den ganzen Banner bedecken. Eine Mission: Sie wird automatisch auf die gewählte Mission begrenzt. Mehrere Missionen: Importiere eine Serie und ordne jedes Bild seiner Mission zu."};
I18N["pt"]={"fresco":"Banner","route":"Percurso","missions":"Missões","publish":"Publicar","projects":"Projetos","rows":"Linhas","image":"Imagens","framing":"Enquadramento","layers":"Camadas","text":"Texto","preview":"Pré-visualização","export":"Exportar","wholeFresco":"Banner completo","oneMission":"Uma missão","noMission":"Nenhuma missão selecionada","addImage":"Adicionar imagem","imageHint":"Será enquadrada diretamente na geometria Prime.","circles":"Círculos Prime","grid":"Grelha 512","numbers":"Números","enlarge":"Ampliar missão","resetMission":"Repor missão","prev":"Anterior","next":"Seguinte","complete":"Missão concluída","remaining":"Faltam {n} portal(is)","openIitc":"Abrir IITC Companion","tutorial":"Tutorial","installPlugin":"Instalar / atualizar plugin IITC","autoAdvance":"Passar automaticamente à missão seguinte quando chegar a {n} portais","reuseLast":"Reutilizar automaticamente o último portal como primeiro da missão seguinte","noPortal":"Esta missão ainda não tem portais.","action":"Ação","hack":"Hackear","mod":"Instalar um mod","capture":"Capturar / melhorar","link":"Criar um link","field":"Criar um campo","passphrase":"Passphrase","question":"Pergunta","answer":"Resposta esperada","save":"Guardar","cancel":"Cancelar","settings":"Definições comuns","commonDesc":"Descrição comum","titleFormat":"Formato dos títulos","defaultType":"Tipo predefinido","location":"Localização","visible":"Visível","hidden":"Oculta","sequential":"Sequencial","anyOrder":"Qualquer ordem","portalsPerMission":"Portais / missão","editMission":"Editar missão","title":"Título","description":"Descrição","missionReady":"Pronta","missionIncomplete":"Incompleta","openRoute":"Editar percurso","publishPack":"Criar pacote BannerLab","openMat":"Abrir Mission Authoring Tool","ownWorkflow":"O BannerLab usa agora o seu próprio formato de projeto e o seu próprio pacote de publicação.","language":"Idioma","french":"Français","english":"English","spanish":"Español","companionStats":"Estatísticas de caminhada no IITC","companionStatsDesc":"No pequeno painel do IITC, 📊 Estatísticas inúteis calcula distância estimada a pé, tempo, desvios e outras coisas que ninguém pediu.","duplicateBad":"{n} reutilização(ões) de portal a verificar.","handoverOk":"É permitida a reutilização do fim de uma missão no início da seguinte.","pluginVersion":"Companion 0.6.6","undo":"Desfazer","redo":"Refazer","subtitle":"Banners Ingress Prime","source":"origem","bannerHelp":"<b>Modo banner:</b> 1 dedo move a camada selecionada. <b>2 dedos</b> fazem zoom e rodam.","missionHelp":"<b>Modo missão:</b> toca num medalhão. Para editar com mais conforto, usa <b>Ampliar missão</b>. Também o podes mover aqui com 1 dedo.","missionSelected":"Missão {n} selecionada","tapMedallion":"Toca num medalhão","touchMissionFirst":"Toca primeiro na missão cujo enquadramento queres ajustar.","selectMissionFirst":"Seleciona primeiro uma missão.","heavyImage":"Imagem muito pesada. Pode levar o teu telemóvel a repensar as escolhas de vida.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto continua numa camada independente, que podes editar ou eliminar separadamente.","layer":"Camada","newText":"+ Novo texto","size":"Tamanho","outline":"Contorno","color":"Cor","outlineColor":"Cor do contorno","add":"Adicionar","update":"Atualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotação","center":"Centrar","reset":"Repor","done":"Concluído","transformText":"Transformar texto","frameImage":"Enquadrar imagem","pinchHint":"Os gestos com dois dedos continuam disponíveis diretamente sobre o banner.","missionCropOnly":"Este enquadramento afeta apenas este medalhão.","resetThisMission":"Repor esta missão","individualCrop":"Enquadramento individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"fazer zoom e rodar","previewPrime":"Pré-visualização Prime","previewApplied":"Os ajustes individuais das missões já estão aplicados.","previewOrder":"O número 1 fica em baixo à direita; depois a numeração segue para a esquerda e sobe pelas restantes linhas.","exportTitle":"Exportar {n} missões","exportIntro":"Escolhe rapidez ou PNG sem perdas. Ambos mantêm 512 × 512.","noBackground":"Não há imagem de fundo carregada.","missionFormat":"Formato das missões","jpgFast":"JPG rápido · alta qualidade","pngLossless":"PNG sem perdas · mais lento","fastEncoding":"O modo rápido evita a codificação PNG, que é de longe a parte mais lenta num telemóvel.","rowRender":"O fundo é renderizado uma única vez por linha, em vez de ser recalculado seis vezes.","adjusted":"{n} missão(ões) com enquadramento individual.","nianticCheck":"Confirma as regras da Niantic antes de submeter: direitos sobre a imagem, conteúdo pertinente e nenhuma personagem única dominante.","ready":"Pronto.","createZip":"Criar ZIP","zipAssembly":"A criar ZIP…","zipCreated":"ZIP criado.","zipDownloaded":"ZIP descarregado.","saveShareZip":"Guardar ou partilhar ZIP","exportFinished":"Exportação {format} concluída","exportFailed":"A exportação falhou.","newProject":"Novo projeto","myProjects":"Os meus projetos","projectsSaved":"{n} projeto(s) guardado(s) neste dispositivo.","unnamed":"Sem nome","opened":"Aberto","open":"Abrir","rename":"Mudar nome","copy":"Copiar","noSavedProject":"Nenhum projeto guardado.","renameProject":"Mudar nome do projeto","renameHint":"Um nome que um ser humano consiga reconhecer mais tarde. Conceito surpreendentemente avançado.","projectName":"Nome do projeto","projectOpened":"Projeto aberto: {name}","projectRenamed":"Projeto renomeado","deleteProject":"Eliminar este projeto?","deleteWarning":"O banner e a imagem guardada localmente serão eliminados.","copyCreated":"Cópia criada","projectDeleted":"Projeto eliminado","newProjectCreated":"Novo projeto criado com Redacted","defaultProject":"O meu banner","defaultNewProject":"Novo banner","copySuffix":"cópia","versionLabel":"Versão","infoPrime":"6 colunas · 544 px · recorte de 512 px.","infoPlanner":"ações de portal, passphrases, passagem fim→início e pacote BannerLab nativo.","infoCompanion":"percursos, ações, traçados entre missões, opções e estatísticas de caminhada.","disclaimer":"Ingress e Ingress Prime são marcas da Niantic. O Redacted BannerLab não é afiliado nem aprovado pela Niantic.","titleTokens":"$T = nome · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.6. No IITC Mobile, substitui a versão anterior. Se o IITC não permitir substituí-la, remove uma vez o plugin antigo e instala este ficheiro.","pluginDialog":"Instalar / atualizar Companion 0.6.6","pluginShareFailed":"Não foi possível partilhar o plugin IITC.","intelOpened":"IITC Mobile aberto com o projeto BannerLab.","intelPrimeOpened":"IITC Prime aberto com o projeto BannerLab.","intelFallback":"IITC Mobile aberto. O Companion vai usar o último estado sincronizado.","intelPrimeFallback":"IITC Prime aberto. O Companion vai usar o último estado sincronizado.","intelBrowser":"IITC não detetado: a abrir no navegador.","tutorialIntro":"Constrói o banner completo no IITC sem voltar ao BannerLab depois de cada portal.","tut1Title":"Instala o plugin uma única vez","tut1Text":"Em Percurso, usa “Instalar / atualizar plugin IITC” e depois adiciona o ficheiro como plugin de utilizador no IITC Mobile.","tut2Title":"Abre o IITC a partir do BannerLab","tut2Text":"O BannerLab envia o projeto, a missão ativa e o idioma ao Companion através de um fragmento local que nunca chega ao servidor Intel.","tut3Title":"Constrói diretamente no mapa","tut3Text":"O Companion permite adicionar, editar ou remover portais, mudar de missão e ver os percursos sem voltar ao BannerLab.","tut4Title":"Sincroniza quando terminares","tut4Text":"“Sincronizar BannerLab” devolve todas as missões alteradas ao projeto e volta a abrir o BannerLab.","tutNote":"Podes mover e redimensionar o Companion e guardar as respetivas definições em Opções.","installUpdate":"Instalar / atualizar","emptyTitleIssue":"Missão {n}: título em falta","emptyDescIssue":"Missão {n}: descrição em falta","portalsIssue":"Missão {n}: {count}/{need} portais","missingGuidIssue":"Missão {n}: faltam {count} GUID(s)","passIssue":"Missão {n}: {count} passphrase(s) incompleta(s)","reviewCount":"{n} ponto(s) a verificar","projectReady":"Projeto BannerLab pronto","fixBeforePublish":"Corrige estes pontos antes de publicar.","publisherDesc":"O próximo passo preenche o Mission Authoring Tool diretamente a partir deste formato nativo. A submissão final continuará, de propósito, a ser feita na ferramenta oficial.","packCreating":"A criar pacote BannerLab…","packCreated":"Pacote BannerLab criado","exportImpossible":"Não foi possível exportar: {error}","missionResetDone":"Missão {n} reposta","textDeleted":"Texto eliminado","histImport":"Importar imagem","histMissionZoom":"Zoom da missão","histMissionRotation":"Rotação da missão","histTextRotation":"Rotação do texto","histImageRotation":"Rotação da imagem","histTextZoom":"Zoom do texto","histImageZoom":"Zoom da imagem","histCenterText":"Centrar texto","histCenterImage":"Centrar imagem","histResetText":"Repor texto","histResetImage":"Repor imagem","histResetMission":"Repor missão","histDeleteText":"Eliminar texto","histAddText":"Adicionar texto","histEditText":"Editar texto","routeActionHelp":"Hack / Mod / Capturar / Link / Campo / Passphrase diretamente no Companion.","handoverDetail":"O último portal pode tornar-se o primeiro da missão seguinte sem ser tratado como duplicado inválido.","coordsMissing":"Coordenadas não encontradas.","coordsInvalid":"Coordenadas inválidas.","duplicateElsewhere":"Este portal já é usado noutro ponto do banner.","missionCompleteAdded":"Missão {n} concluída · {next}","portalAdded":"Portal adicionado · missão {n}","syncOld":"Percurso sincronizado · Companion antigo detetado: instala a versão 0.6.6.","syncOk":"Percurso IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Preparar diretamente no Mission Authoring","livePublishShort":"Publisher direto","livePreparing":"A preparar {n} missões para o Publisher…","liveReady":"A abrir o Publisher integrado…","liveNativeOnly":"O Publisher direto está disponível na APK Android.","liveFailed":"Não foi possível abrir o Publisher: {error}","liveExperimental":"Experimental: o Mission Authoring abre numa vista controlada pelo RBL. A primeira coisa a validar no teu telemóvel é o início de sessão Google.","backupTransfer":"Cópia de segurança / transferência","exportPackBackup":"Exportar pacote BannerLab","openOfficialOnly":"Abrir apenas o site oficial","publisherPreparingImage":"A renderizar missão {n}/{total}…","browserPublish":"Publicar no Firefox","browserPublishShort":"Publisher no navegador","browserSetup":"Instalar / atualizar Publisher do navegador","browserPreparing":"A preparar missão {n}/{total}…","browserOpening":"A abrir Firefox…","browserNeed":"O Publisher direto usa Firefox Android + Violentmonkey para que o início de sessão Google continue num navegador normal.","browserFailed":"Não foi possível abrir o Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 para missions.ingress.com. Instala uma vez no Violentmonkey do Firefox Android.","browserShareDialog":"Instalar Publisher 0.4.0","browserShareFailed":"Não foi possível partilhar o Publisher do navegador.","publisherUrlTooLarge":"Esta missão é demasiado grande para ser enviada para o navegador.","publisherReturn":"Regresso do Publisher.","publisherNoFirefox":"Firefox não foi detetado. A abrir o navegador predefinido, mas o Publisher precisa de um navegador com suporte para userscripts.","publisherBrowser":"Navegador de publicação","chromeMode":"Chrome","chromeModeSub":"Sem aplicação extra · pequeno marcador + Permitir quando solicitado","firefoxMode":"Firefox","firefoxModeSub":"Automático depois de instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sem aplicação extra","publishSelected":"Publicar missão","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Marcador do Chrome verificado","firefoxReady":"Publisher do Firefox verificado","notConfigured":"É necessária uma configuração única","chromeSetupTitle":"Publisher para Chrome","chromeSetupIntro":"O Chrome não permite que o RBL crie o marcador por ti. Por isso a configuração foi reduzida ao mínimo humanamente possível.","chromeStep1":"1. Copia o código do marcador RBL Publisher.","chromeStep2":"2. Abre o Mission Authoring no Chrome e guarda a página nos marcadores.","chromeStep3":"3. Edita esse marcador: chama-lhe “RBL Publisher” e substitui o URL pelo código copiado.","chromeStep4":"4. No Mission Authoring, toca na barra de endereço, escreve “RBL” e escolhe o marcador para o testar.","copyBookmarklet":"Copiar código do marcador","bookmarkletCopied":"Código do marcador copiado","openChromeSetup":"Abrir Chrome para configurar","testChrome":"Testar marcador do Chrome","chromeRunHint":"No Chrome: toca na barra de endereço, escreve RBL e escolhe “RBL Publisher”.","chromeNeedsSetup":"Configura primeiro o marcador RBL Publisher no Chrome.","chromeOpenFail":"Não foi possível abrir o Chrome. A abrir o navegador predefinido.","firefoxSetupTitle":"Publisher para Firefox","firefoxSetupIntro":"O Firefox pode carregar o Publisher automaticamente através do Violentmonkey. É o modo mais simples.","sharePublisher":"Partilhar userscript do Publisher","testFirefox":"Testar Publisher no Firefox","firefoxNeedsSetup":"Instala o Violentmonkey e o Publisher no Firefox antes de testar.","browserSaved":"Navegador de publicação: {browser}","setupConfirmed":"Configuração verificada.","bookmarkletCopyFail":"Não foi possível copiar automaticamente. O código aparece abaixo.","bookmarkletLabel":"Código do marcador","autoImpossibleChrome":"O carregamento automático não é possível no Chrome Android sem uma extensão ou uma permissão intrusiva. O marcador continua a ser necessário.","openChromePublish":"A abrir Chrome…","openFirefoxPublish":"A abrir Firefox…","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Configuração única. O RBL guarda o teu progresso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"O RBL guarda o Publisher diretamente em Documents/RedactedBannerLab. Não é necessário abrir a folha de partilha do Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","alreadySaved":"Já o guardei","chromeBookmarkTitle":"Criar o mini marcador","chromeBookmarkText":"O marcador já não contém o Publisher completo. Tem apenas {n} caracteres e carrega o ficheiro que acabaste de guardar.","chromeBookmarkName":"Nome do marcador: RBL Publisher","chromeBookmarkHow":"No Chrome: abre Mission Authoring → ⋮ → Adicionar aos marcadores. Depois edita o marcador, chama-lhe “RBL Publisher” e cola o código no campo URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"Criei o marcador","chromeTestTitle":"Testar e autorizar","chromeTestText":"O RBL abre o Mission Authoring. Escreve RBL e executa o marcador. O Chrome pede o Publisher e depois o JSON atual. O JSON é pedido para cada banner novo, nunca entre missões do mesmo banner.","chromeTestButton":"Testar no Chrome","chromeTestWaiting":"No Chrome: escreve RBL → RBL Publisher → escolhe publisher.js se for pedido → Permitir.","chromeSetupSuccess":"Chrome pronto","chromeSetupSuccessText":"O Chrome está pronto. O Publisher fica memorizado; o JSON do banner é escolhido explicitamente para cada nova sessão, para evitar reutilizar um projeto antigo sem dar por isso.","publishNow":"Publicar agora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuração","stepOf":"Passo {n}/3","chromeFileShareText":"Guarda este publisher.js num local fácil de encontrar, como Downloads. O Chrome vai pedi-lo durante o primeiro teste.","chromeFileShareDialog":"Guardar RBL Publisher","chromeFileShareFail":"Não foi possível preparar o ficheiro do Publisher.","chromePermissionHint":"O Chrome pode voltar a pedir permissão para ler publisher.js. Basta permitir.","chromeNotAutoFavorite":"O RBL não consegue criar um marcador do Chrome automaticamente. É o único passo manual obrigatório.","codeLength":"{n} caracteres","chromeStepSaved":"Passo guardado","chromeResetDone":"Configuração do Chrome reposta","chromeSelectFileHint":"No Chrome, seleciona: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","bannerDescription":"Descrição do banner","required":"Obrigatório","bannerDescriptionHint":"Esta é a descrição predefinida para todas as missões. Ainda podes personalizar missões individuais mais tarde.","bannerDescriptionRequired":"A descrição do banner é obrigatória.","describeBeforePublish":"Descreve primeiro o banner","describeBeforePublishText":"A publicação fica bloqueada até o banner ter uma descrição. Ela será usada como predefinição para todas as missões.","saveAndContinue":"Guardar e continuar","missionPublishBlocked":"A missão não pode ser publicada","missionNeedsPortals":"A missão {n} tem {count}/{need} portais. Precisa de pelo menos {need} antes da publicação.","completeMission":"Completar missão","currentMissionReady":"Missão pronta a publicar","publishBlockedHint":"A publicação continua bloqueada até todos os elementos obrigatórios estarem completos.","minimumSix":"Mínimo: 6 portais por missão","publisherDescRequired":"O Publisher recusa missões sem descrição.","publisherPortalsRequired":"O Publisher recusa missões com menos de 6 portais.","playBanners":"Encontrar um banner","playHub":"Encontrar um banner","searchBannergress":"Encontrar um banner","searchPlaceholder":"Nome ou palavra-chave","search":"Pesquisar","favorites":"Favoritos","currentBanner":"Retomar","noFavorites":"Ainda não há banners favoritos. O armazenamento local agradece a paz.","noPlaySession":"Não há nenhum banner em curso.","searchPrompt":"Pesquisa por nome e/ou zona geográfica, com um limite real de distância.","searching":"A pesquisar…","searchError":"Falha na pesquisa Bannergress: {error}","missionsCount":"{n} missões","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Remover dos favoritos","playThisBanner":"Iniciar este banner","resumeBanner":"Retomar este banner","stopBanner":"Parar sobreposição","openCurrentMission":"Abrir missão atual","overlayPermissionTitle":"Permitir sobreposição do RBL","overlayPermissionText":"O Android tem de permitir que o Redacted BannerLab apareça sobre o Ingress. Uma autorização do sistema e depois o dinossauro pode tratar da vida dele.","overlayPermissionButton":"Permitir sobreposição sobre outras aplicações","overlayPermissionWaiting":"Volta ao RBL depois de concederes a permissão.","overlayStarted":"Sobreposição da missão iniciada.","overlayFailed":"Não foi possível iniciar a sobreposição: {error}","bannerLoadError":"Não foi possível carregar este banner: {error}","bannerOffline":"Este banner não tem missões utilizáveis.","bannerDisabled":"{n} missão(ões) desativada(s)","addressUnknown":"Localização não indicada","doneMissions":"{done}/{total} concluídas","deepLinkOnly":"O RBL não controla o Ingress: a sobreposição limita-se a abrir deep links oficiais das missões.","bannergressCredit":"Pesquisa através do Bannergress","publisherWholeBanner":"Preparar banner completo","publisherWholeHint":"Uma única sessão no navegador: todas as missões e imagens são preparadas em conjunto.","publisherAllRequired":"Todas as missões têm de estar completas antes de iniciar a sessão de publicação.","publisherSessionCreating":"A preparar sessão do Publisher {n}/{total}…","publisherSessionReady":"Sessão guardada em Documents/RedactedBannerLab. A abrir Mission Authoring…","publisherSessionFileText":"O RBL guarda automaticamente a sessão em Documents/RedactedBannerLab.","publisherSessionDialog":"Sessão do Publisher","publisherSessionShareFail":"Não foi possível preparar a sessão do Publisher.","chromeSessionHint":"Chrome: executa o marcador RBL Publisher. Para cada banner acabado de preparar, o Chrome pede explicitamente RBL_Current_Session.rblpub.json. Não é preciso fazer mais nada entre missões.","firefoxSessionHint":"Firefox: o Publisher abre automaticamente. Carrega RBL_Current_Session.rblpub.json se a sessão atual ainda não for conhecida.","easterEgg":"Tu é que pediste isto.","bannerNameSearch":"Nome / palavra-chave","citySearch":"Cidade","authorSearch":"Autor","cityPlaceholder":"ex.: Nantes","authorPlaceholder":"ex.: AgentName","nearMe":"Perto de mim","nearMeOn":"A minha localização está ativa","nearMeHint":"Usa a tua posição atual em vez de uma cidade.","locationGetting":"A obter localização…","locationError":"Não foi possível obter a localização: {error}","locationReady":"Localização obtida","searchCriteriaRequired":"Introduz pelo menos um critério de pesquisa.","cityResolving":"A procurar cidade…","cityNotFound":"Não foi encontrado nenhum local Bannergress para “{city}”.","cityUsing":"Local utilizado: {city}","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Minimizar","overlayClose":"Fechar","overlayMoved":"Posição da sobreposição guardada","searchReset":"Limpar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros ativos","allPublicBanners":"Banners públicos do Bannergress","searchRadius":"Raio de pesquisa","radiusHint":"Aplicado em torno da cidade ou da tua posição atual.","locationDisabled":"Os serviços de localização estão desativados neste telemóvel.","locationPermissionDenied":"O BannerLab não tem permissão para usar a tua localização.","locationUnavailable":"Localização indisponível. Confirma se os serviços de localização do telemóvel estão ativos.","locationTimeout":"Não foi possível obter a localização a tempo. Confirma se os serviços de localização estão ativos.","openLocationSettings":"Ativar localização","openAppSettings":"Abrir definições da aplicação","cityNoCoordinates":"“{city}” foi encontrada, mas a sua posição não pode ser utilizada.","cityUsingRadius":"A usar: {city} · raio de {radius} km","radiusResults":"{n} resultado(s) num raio de {radius} km","distanceFromPoint":"a {distance}","locationChecking":"A verificar serviços de localização…","publisherCurrentFile":"Ficheiro atual: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher guardado em Documents/RedactedBannerLab.","chromeFileWriteFail":"Não foi possível guardar o Publisher em Documents/RedactedBannerLab.","chromeCurrentSessionHint":"Para cada banner novo: escolhe Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json.","browserResume":"Sessão preparada. A abrir o separador RBL do Mission Authoring…","chromeResumeHint":"O Chrome reutiliza agora o mesmo separador do Mission Authoring reservado ao RBL.","firefoxResumeHint":"A abrir Mission Authoring no navegador de publicação.","browserResumeFallback":"Não foi possível reutilizar o separador RBL. A abrir o navegador como alternativa.","publisherAutoRefresh":"O Publisher passa a vigiar o ficheiro da sessão atual e recarrega automaticamente um novo banner preparado.","flowLocked":"Edição do banner bloqueada","flowLockedText":"O passo {step} está ativo. Seleciona “1 Banner” para editar a imagem, o texto ou o enquadramento.","returnFresco":"Seleciona 1 Banner para editar","flowLockedToast":"Volta ao passo 1 Banner para editar o banner.","publisherTabReuse":"O RBL usa um identificador fixo da aplicação do navegador para reutilizar o mesmo separador.","todo":"A fazer","history":"Histórico","inProgress":"Em curso","addTodo":"Adicionar a A fazer","removeTodo":"Remover de A fazer","noTodo":"Não há banners por fazer. Suspeitosamente sensato.","noHistory":"Ainda não jogaste nenhum banner. O dinossauro está aborrecido.","bannerMap":"Mapa do percurso","openMap":"Ver mapa","navigateStart":"Navegar até ao início","startUnavailable":"Ponto de partida indisponível.","mapUnavailable":"O Bannergress não fornece coordenadas utilizáveis para este banner.","startPoint":"Início","missionStart":"Missão {n}","shareGroup":"Partilhar / grupo","shareProgress":"Partilhar progresso","shareBanner":"Partilhar banner","shareIntro":"O QR abre o RBL no mesmo banner e no mesmo número de missão. Não é usada nenhuma conta Bannergress.","copyLink":"Copiar link RBL","linkCopied":"Link RBL copiado","shareNow":"Partilhar","bannergressPage":"Abrir no Bannergress","joinBanner":"Entrar no banner","joinAtMission":"Entrar na missão {n}","sharedBannerLoaded":"Banner partilhado carregado · missão {n}","sharedBannerError":"Não foi possível carregar o banner partilhado: {error}","playStats":"Estatísticas da sessão","startedAt":"Iniciado","finishedAt":"Terminado","elapsed":"Tempo ativo","estimatedDistance":"Distância estimada","missionsDone":"Missões concluídas","paused":"Em pausa","playing":"Em curso","completedBanner":"Concluído","replayBanner":"Jogar novamente","resumeFromHistory":"Retomar","groupNoServer":"Modo de grupo sem servidor: volta a partilhar o QR/link se o grupo passar para outra missão.","publicOnly":"Apenas pesquisa/dados públicos do Bannergress · sem início de sessão.","routePoints":"{n} pontos no percurso","uselessStats":"Estatísticas inúteis","loadingStats":"A calcular coisas que ninguém pediu…","statsUnavailable":"Não há coordenadas suficientes para calcular estatísticas inúteis.","bgDistance":"Distância Bannergress","calculatedTrack":"Distância estimada a pé","walkingEstimate":"Tempo estimado a pé","routeSteps":"Passos","uniquePlaces":"Locais únicos","revisitedPlaces":"Visitas repetidas","stepsPerKm":"Passos / km","avgMissionDistance":"Média / missão","longestMission":"Missão mais longa","longestLeg":"Troço mais longo","betweenMissions":"Transições entre missões","detourFactor":"Fator de desvio","routeCoverage":"Cobertura do mapa","missionShort":"M{n}","straightLine":"Início → fim","funStatsDisclaimer":"O RBL calcula cada troço entre portais na rede pedonal do OpenStreetMap. Cada troço é verificado: atalhos impossíveis ou desvios claramente absurdos são substituídos apenas nesse troço pela distância direta. É uma estimativa a pé, não uma medição GPS.","minutesShort":"{n} min","hoursMinutes":"{h} h {m} min","xFactor":"×{n}","showUselessStats":"📊 Estatísticas inúteis","hideUselessStats":"Ocultar estatísticas","statsLoaded":"Estatísticas calculadas","directGeometric":"Distância direta acumulada","routingDetour":"Relação rede / direto","routingSource":"Roteamento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponível · estimativa geométrica","routingLoading":"A calcular o percurso pedonal real…","routingFailed":"Roteamento pedonal indisponível; foram usadas estatísticas geométricas.","routingNative":"Valhalla + OSM · verificação por troço","routingWeb":"Valhalla + OSM · verificação por troço","routingErrorDetail":"Falha do Valhalla: {error}","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m","correctedLegs":"Troços corrigidos","rawValhalla":"Valhalla bruto","creditsTitle":"Créditos & agradecimentos","bannergressThanks":"Obrigado, Bannergress","bannergressThanksText":"A pesquisa de banners e vários detalhes públicos apresentados no Redacted BannerLab usam dados públicos do Bannergress. Obrigado à equipa e aos colaboradores pelo enorme trabalho em torno dos banners de Ingress.","bannergressNoLogin":"O RBL não usa uma conta Bannergress: apenas os dados públicos necessários para pesquisar e mostrar banners.","independentProject":"O Redacted BannerLab é um projeto independente e não é afiliado nem aprovado pelo Bannergress ou pelos serviços oficiais de Ingress.","visitBannergress":"Visitar Bannergress","mapCredits":"Mapas & roteamento","mapCreditsText":"Os mapas usam dados do OpenStreetMap. As estimativas de percurso pedonal usam o motor de roteamento Valhalla.","rblCreditsFoot":"Obrigado a todas as ferramentas e colaboradores que tornam possível este ecossistema de missões Ingress.","layersTitle":"Imagens & camadas","layersDesc":"Gere aqui o fundo e todas as imagens sobrepostas. As miniaturas ajudam a identificar a camada certa; depois podes selecioná-la, ocultá-la, reordená-la ou agrupá-la.","backgroundLayer":"Fundo principal","addBackground":"Adicionar / substituir fundo","addLayer":"Adicionar camada","layerName":"Camada de imagem","selected":"Selecionada","visibleLayer":"Visível","hiddenLayer":"Oculta","moveUp":"Subir","moveDown":"Descer","groupSelection":"Agrupar seleção","group":"Agrupar","ungroup":"Desagrupar","groupNeedTwo":"Seleciona pelo menos duas camadas para as agrupar.","groupCreated":"Camadas agrupadas","groupRemoved":"Grupo desfeito","deleteLayer":"Eliminar camada","layerDeleted":"Camada eliminada","layerAdded":"Camada adicionada","backgroundReplaced":"Fundo substituído","backgroundMissing":"Sem fundo principal","backgroundFixed":"O fundo fica sempre por baixo das restantes camadas.","groupHint":"Seleciona várias camadas e toca em Agrupar. Um grupo move-se, amplia-se e roda em conjunto.","layerOrder":"Ordem das camadas","layerTransform":"Transformar camada","groupTransform":"Transformar grupo","renameLayer":"Mudar nome","duplicateLayer":"Duplicar","layerDuplicated":"Camada duplicada","histAddLayer":"Adicionar camada","histDeleteLayer":"Eliminar camada","histReorderLayer":"Reordenar camada","histGroupLayers":"Agrupar camadas","histUngroupLayers":"Desagrupar camadas","histVisibilityLayer":"Visibilidade da camada","histRenameLayer":"Mudar nome da camada","histDuplicateLayer":"Duplicar camada","layerGroupBadge":"Grupo","layerUngroup":"Desagrupar este grupo","layerSelectHint":"Depois de selecionada, a camada pode ser movida diretamente sobre o banner.","layerOpacity":"Opacidade","layerDimensions":"{w} × {h} px","noImageContent":"Adiciona pelo menos uma imagem antes de exportar.","groupRelative":"Os controlos abaixo transformam o grupo inteiro em conjunto.","groupZoom":"Zoom do grupo","groupRotation":"Rotação do grupo","clearGroupSelection":"Limpar seleção","allLayersTitle":"Camadas","allLayersDesc":"Seleciona o elemento que queres manipular. Imagens e textos continuam editáveis nos respetivos menus.","imageLayersSection":"Imagens","textLayersSection":"Texto","noExtraImageLayer":"Nenhuma camada de imagem adicional","noTextLayer":"Nenhuma camada de texto","selectLayer":"Selecionar","editLayer":"Editar","missionNumberQuestion":"Qual é o número da missão?","groupName":"Grupo {n}","groupCount":"{n} camada(s)","creatorBy":"Criado por Zw4nn","communityTitle":"Comunidade & suporte","communityText":"Acede à comunidade e ao suporte diretamente através do bot Redacted BannerLab.","telegramOpen":"Contactar suporte","reportProblem":"Comunicar um problema","reportProblemText":"Copia um diagnóstico técnico e depois contacta o suporte através do bot.","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","diagnosticCopyFailed":"Não foi possível copiar o diagnóstico","diagnosticDescription":"Descrição do problema:","portableProject":"Projeto portátil","portableProjectDesc":"Exporta um único banner com imagens, camadas, texto, fontes, missões e percurso.","exportProject":"Exportar","shareProject":"Partilhar","importProject":"Importar projeto","projectExporting":"A preparar projeto…","projectExported":"Projeto guardado","projectShared":"Projeto pronto a partilhar","projectImportSuccess":"Projeto importado","projectImportInvalid":"Este ficheiro não é um projeto Redacted BannerLab válido.","projectShareTitle":"Projeto Redacted BannerLab","projectImportHint":"O projeto importado é adicionado sem alterar os teus outros projetos.","backupTitle":"Cópia de segurança & restauro","backupText":"Guarda todos os projetos, definições e imagens do BannerLab num único ficheiro JSON portátil.","backupFolder":"Pasta de cópias de segurança","backupFolderChoose":"Escolher pasta","backupFolderChange":"Mudar pasta","backupFolderNone":"Nenhuma pasta selecionada","backupFolderReady":"Pasta configurada","backupAuto":"Cópia de segurança automática em segundo plano","backupAutoHint":"Quando ativada, o BannerLab prepara regularmente uma cópia de segurança após as tuas alterações e força uma gravação final quando a aplicação passa para segundo plano.","backupNow":"Fazer cópia agora","backupExport":"Exportar JSON","backupImport":"Importar JSON","backupWorking":"A criar cópia de segurança…","backupSaved":"Cópia de segurança concluída","backupAutoSaved":"Cópia automática concluída","backupFailed":"Falha na cópia de segurança: {error}","backupNeedFolder":"Escolhe primeiro uma pasta de cópias de segurança.","backupFolderError":"Não foi possível usar esta pasta.","backupImported":"Cópia de segurança restaurada","backupInvalid":"Este ficheiro não é uma cópia de segurança válida do Redacted BannerLab.","backupImportTitle":"Restaurar cópia de segurança","backupImportText":"{n} projeto(s) encontrado(s) · cópia de {date}","backupMerge":"Fundir","backupReplace":"Substituir tudo","backupReplaceWarn":"Substituir tudo elimina os projetos atualmente guardados neste dispositivo antes do restauro.","backupCancel":"Cancelar","backupLast":"Última cópia: {date}","backupNever":"Ainda não há cópia de segurança","backupPortable":"O JSON também contém as imagens. Pode por isso ficar grande, mas é completamente autónomo.","backupNativeOnly":"A cópia automática para pasta está disponível no Android. A exportação/importação JSON continua disponível em todas as plataformas.","backupFolderChosen":"Pasta de cópias guardada","backupNoChanges":"Não há alterações para guardar.","studioEdit":"Editar em ecrã inteiro","studioTitle":"Estúdio de edição","studioLayers":"Camadas","studioTexts":"Texto","studioTools":"Ferramentas","studioFit":"6 missões","studioFitOne":"1 missão","studioFitAll":"Tudo","studioMissionMode":"Missão","studioFrescoMode":"Banner","studioFullscreen":"Ecrã inteiro","studioRotateHint":"6 missões na vertical · as linhas seguintes deslocam-se para a direita.","studioSelected":"Elemento selecionado","studioNoLayer":"Seleciona uma camada ou um texto na lateral.","studioGroupSelect":"Agrupar seleção","studioGroupNow":"Agrupar","studioOpenFull":"Abrir gestor completo","studioOpacity":"Opacidade","studioClose":"Sair do estúdio","studioPan":"Deslocar","studioAddText":"Adicionar texto","studioNoText":"Ainda não há texto.","studioEditText":"Editar texto","studioDuplicateText":"Duplicar texto","font":"Fonte","fontWeight":"Espessura","fontItalic":"Itálico","letterSpacing":"Espaçamento entre letras","lineHeight":"Altura da linha","textAlign":"Alinhamento","alignLeft":"Esquerda","alignCenter":"Centro","alignRight":"Direita","importFont":"Importar fonte","fontImported":"Fonte importada: {name}","fontInvalid":"Esta fonte não é suportada.","fontTooLarge":"A fonte é demasiado grande (máx. 12 MB).","textBackground":"Fundo do texto","textBackgroundColor":"Cor do fundo","textBackgroundOpacity":"Opacidade do fundo","textBackgroundPadding":"Margem interna do fundo","textBackgroundRadius":"Raio dos cantos","textTypography":"Tipografia","tutorialHubTitle":"Tutoriais & primeiros passos","tutorialHubText":"Volta a iniciar uma visita guiada quando quiseres. O Redacted pode explicar apenas a parte de que precisas.","tutorialOpen":"Ver tutoriais","tutorialWelcomeTitle":"Bem-vindo ao Redacted BannerLab","tutorialWelcomeText":"O Redacted pode mostrar-te o laboratório. Dois minutos, alguns botões e nem sequer há exame no fim.","tutorialStart":"Iniciar visita","tutorialLater":"Mais tarde","tutorialNever":"Não voltar a mostrar","tutorialPrevious":"Anterior","tutorialNext":"Seguinte","tutorialUnderstood":"OK, percebi","tutorialClose":"Fechar","tutorialDone":"Tutorial concluído","tutorialSeen":"Visto","tutorialQuick":"Visita rápida","tutorialQuickDesc":"Os controlos essenciais e o fluxo geral do BannerLab.","tutorialBanner":"Criar um banner","tutorialBannerDesc":"Do projeto à pré-visualização e exportação das missões.","tutorialLayers":"Imagens, camadas & texto","tutorialLayersDesc":"Fundo, imagens sobrepostas, camadas e ferramentas de tipografia.","tutorialIitc":"Criar o percurso com IITC","tutorialIitcDesc":"Instala o Companion, adiciona portais e sincroniza o percurso.","tutorialPublish":"Publicar missões","tutorialPublishDesc":"Prepara as missões e depois usa o Publisher e o Mission Authoring.","tutorialBackup":"Cópias de segurança & projetos portáteis","tutorialBackupDesc":"Faz uma cópia do BannerLab ou partilha um banner completo.","importRolesHint":"Fundo principal = imagem base do banner · Camada = imagem adicional sobreposta.","tutProjectTitle":"Os teus projetos","tutProjectText":"Cada banner vive no seu próprio projeto. Podes exportá-lo ou partilhá-lo sem levar todos os outros projetos atrás.","tutNameTitle":"Nome do projeto","tutNameText":"Dá ao banner um nome que reconheças mais tarde.","tutRowsTitle":"Número de linhas","tutRowsText":"Cada linha contém 6 missões. Escolhe aqui a altura final do banner.","tutImageTitle":"Imagens & camadas","tutImageText":"Importa aqui o fundo principal e imagens adicionais. Neste mesmo ecrã também podes selecionar, ordenar, ocultar e agrupar camadas de imagem.","tutBackgroundTitle":"Fundo principal","tutBackgroundText":"Para a primeira imagem real, usa Fundo principal. Substitui a imagem base e cobre o banner.","tutExtraLayerTitle":"Adicionar camada","tutExtraLayerText":"Uma segunda imagem torna-se uma camada: fica por cima do fundo e continua móvel, redimensionável e ocultável.","tutLayersTitle":"Gerir camadas de imagem","tutLayersText":"As miniaturas mostram qual camada estás a manipular. Seleciona-a, muda a ordem, oculta-a ou marca várias imagens para as agrupar.","tutTextTitle":"Texto","tutTextText":"Adiciona texto, escolhe fontes, espaçamento, fundo e raio dos cantos ou importa a tua própria fonte.","tutPreviewTitle":"Pré-visualização","tutPreviewText":"Verifica cada missão antes de exportar. Os enquadramentos individuais já estão aplicados.","tutExportTitle":"Exportar","tutExportText":"Quando estiver tudo pronto, o BannerLab cria as imagens 512 × 512 das missões pela ordem correta.","tutStudioTitle":"Estúdio em ecrã inteiro","tutStudioText":"Um editor mais confortável em ecrã inteiro, com controlos laterais e grandes zonas táteis.","tutFlowTitle":"Os 4 passos","tutFlowText":"Banner → Percurso → Missões → Publicar. O BannerLab segue este fluxo.","tutRouteTitle":"Percurso","tutRouteText":"O percurso liga as missões a portais reais do Ingress. O IITC Companion trata do trabalho no mapa.","tutCompanionTitle":"IITC Companion","tutCompanionText":"O Companion leva para o IITC o projeto ativo, a missão, os portais, as ações e as estatísticas de caminhada.","tutInstallCompanionTitle":"Instalar Companion","tutInstallCompanionText":"Instala ou atualiza uma vez o userscript no IITC Mobile.","tutOpenIitcTitle":"Abrir IITC","tutOpenIitcText":"Abre o IITC a partir do BannerLab para enviar o projeto e a missão ativa ao Companion.","tutAutoRouteTitle":"Passar entre missões","tutAutoRouteText":"A missão seguinte pode abrir automaticamente e reutilizar o último portal da missão anterior como primeiro.","tutPortalListTitle":"Os teus portais","tutPortalListText":"Os portais regressam com GUID, coordenadas, ordem e ação, para que o percurso possa ser reconstruído.","tutMissionsTitle":"Preparar missões","tutMissionsText":"Antes de publicar, indica a descrição comum e verifica cada missão.","tutMissionDescTitle":"Descrição obrigatória","tutMissionDescText":"O BannerLab assinala informação em falta antes de permitir a publicação.","tutPublishTitle":"Publicar","tutPublishText":"Quando percurso e descrições estiverem prontos, continua aqui. A submissão final continua na ferramenta oficial.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"O BannerLab prepara os dados das missões e o fluxo de publicação. Depois da submissão, usa “Já submeti” para confirmar o estado publicado.","tutInfoTitle":"Definições, ajuda & suporte","tutInfoText":"Definições & info contém idioma, cópias de segurança, tutoriais e suporte através do bot Redacted BannerLab.","tutBackupTitle":"Cópia de segurança completa","tutBackupText":"O JSON completo inclui todos os projetos, definições, imagens e fontes. No Android também podes usar uma pasta de cópia automática.","tutPortableTitle":"Projeto portátil","tutPortableText":"Exporta, partilha ou importa um único banner com imagens, texto, fontes, missões e percurso.","tutSupportTitle":"Precisas de ajuda?","tutSupportText":"Copia o diagnóstico se for necessário e contacta o suporte. O bot também dá acesso ao canal e ao grupo de discussão.","settingsInfo":"Definições & info","addMissionLayer":"Numa missão","importMissionSeries":"Importar série","missionLayer":"Camada de missão","globalLayer":"Camada global","layerScope":"Âmbito da camada","wholeBanner":"Banner completo","missionTarget":"Missão associada","fitMode":"Ajuste","fitCover":"Preencher","fitContain":"Conter","missionBadge":"M{n}","missionLayerHint":"Esta camada fica associada à missão {n} e é automaticamente limitada à respetiva célula.","missionSeriesTitle":"Importar série de missões","missionSeriesText":"Associa cada imagem a uma missão. O BannerLab posiciona e recorta tudo automaticamente.","missionSeriesDetected":"{n} imagem(ns) detetada(s)","missionSeriesImport":"Importar camadas","missionSeriesTooMany":"Selecionaste mais imagens do que missões. Podes associar várias imagens à mesma missão.","missionLayerAdded":"Imagem adicionada à missão {n}","missionSeriesAdded":"{n} camada(s) de missão adicionada(s)","missionScopeMismatch":"As camadas de missão só podem ser agrupadas quando pertencem à mesma missão.","missionLayerTutorialTitle":"Camadas associadas a missões","missionLayerTutorialText":"Toca em “Adicionar camada” e escolhe: banner completo, uma missão ou várias missões. Para uma missão, o BannerLab posiciona e limita automaticamente a imagem à respetiva célula. Para várias missões, importa uma série e associa cada imagem à missão pretendida.","addLayerChoiceTitle":"Adicionar camada","addLayerChoiceText":"Escolhe onde esta camada deve ficar. Podes alterar o âmbito mais tarde.","addLayerWhole":"No banner completo","addLayerWholeText":"Uma imagem livre sobre todo o banner, móvel e redimensionável.","addLayerOneMission":"Numa missão","addLayerOneMissionText":"Uma imagem posicionada automaticamente e limitada à missão selecionada.","addLayerManyMissions":"Em várias missões","addLayerManyMissionsText":"Importa uma série de imagens e associa cada uma à missão que quiseres.","multiSelection":"Seleção múltipla","multiSelectionHint":"Marca várias camadas para aplicar uma ação comum, agrupá-las ou eliminá-las.","selectionActions":"Ações da seleção","editSelection":"Editar seleção","deleteSelection":"Eliminar seleção","selectedLayersCount":"{n} camada(s) selecionada(s)","bulkScopeKeep":"Manter âmbito atual","bulkMissionKeep":"Manter missões atuais","bulkFitKeep":"Manter ajuste atual","bulkVisibility":"Visibilidade","bulkVisibilityKeep":"Não alterar","bulkShow":"Mostrar","bulkHide":"Ocultar","bulkOpacityEnable":"Alterar opacidade","applyToSelection":"Aplicar às camadas selecionadas","selectionUpdated":"Camadas selecionadas atualizadas","selectionDeleted":"Camadas selecionadas eliminadas","deleteSelectionConfirm":"Eliminar definitivamente {n} camada(s) selecionada(s)?","selectionEmpty":"Seleciona pelo menos uma camada.","layerScopeHelp":"Banner completo: a camada pode cobrir todo o banner. Uma missão: fica automaticamente limitada à missão escolhida. Várias missões: importa uma série e associa cada imagem à respetiva missão."};
I18N["nl"]={"fresco":"Banner","route":"Route","missions":"Missies","publish":"Publiceren","projects":"Projecten","rows":"Rijen","image":"Afbeeldingen","framing":"Uitsnede","layers":"Lagen","text":"Tekst","preview":"Voorbeeld","export":"Exporteren","wholeFresco":"Hele banner","oneMission":"Eén missie","noMission":"Geen missie geselecteerd","addImage":"Voeg je afbeelding toe","imageHint":"De afbeelding wordt direct op de Prime-geometrie uitgesneden.","circles":"Prime-cirkels","grid":"512-raster","numbers":"Nummers","enlarge":"Missie vergroten","resetMission":"Missie resetten","prev":"Vorige","next":"Volgende","complete":"Missie voltooid","remaining":"Nog {n} portal(s)","openIitc":"IITC Companion openen","tutorial":"Handleiding","installPlugin":"IITC-plugin installeren / bijwerken","autoAdvance":"Na {n} portals automatisch naar de volgende missie gaan","reuseLast":"Laatste portal automatisch als eerste portal van de volgende missie gebruiken","noPortal":"Deze missie heeft nog geen portals.","action":"Actie","hack":"Hack","mod":"Mod installeren","capture":"Veroveren / upgraden","link":"Link maken","field":"Field maken","passphrase":"Passphrase","question":"Vraag","answer":"Verwacht antwoord","save":"Opslaan","cancel":"Annuleren","settings":"Algemene instellingen","commonDesc":"Algemene beschrijving","titleFormat":"Titelopmaak","defaultType":"Standaardtype","location":"Locatie","visible":"Zichtbaar","hidden":"Verborgen","sequential":"Op volgorde","anyOrder":"Willekeurige volgorde","portalsPerMission":"Portals / missie","editMission":"Missie bewerken","title":"Titel","description":"Beschrijving","missionReady":"Klaar","missionIncomplete":"Onvolledig","openRoute":"Route bewerken","publishPack":"BannerLab-pakket maken","openMat":"Mission Authoring Tool openen","ownWorkflow":"BannerLab gebruikt nu zijn eigen projectformaat en publicatiepakket.","language":"Taal","french":"Français","english":"English","spanish":"Español","companionStats":"Wandelstatistieken in IITC","companionStatsDesc":"In het IITC-minipaneel berekent 📊 Nutteloze statistieken de geschatte wandelafstand, tijd, omwegen en andere onzin.","duplicateBad":"{n} hergebruikte portal(s) controleren.","handoverOk":"Hergebruik van missie-einde → start van de volgende missie is toegestaan.","pluginVersion":"Companion 0.6.6","undo":"Ongedaan maken","redo":"Opnieuw","subtitle":"Ingress Prime-banners","source":"bron","bannerHelp":"<b>Bannermodus:</b> met 1 vinger verplaats je de geselecteerde laag. Met <b>2 vingers</b> zoom en draai je.","missionHelp":"<b>Missiemodus:</b> tik op een medaillon. Gebruik <b>Missie vergroten</b> voor comfortabeler bewerken. Je kunt de missie hier ook met 1 vinger verplaatsen.","missionSelected":"Missie {n} geselecteerd","tapMedallion":"Tik op een medaillon","touchMissionFirst":"Tik eerst op de missie waarvan je de uitsnede wilt aanpassen.","selectMissionFirst":"Selecteer eerst een missie.","heavyImage":"Erg grote afbeelding. Je telefoon kan hierdoor zijn levenskeuzes gaan heroverwegen.","imported":"Geïmporteerd: {w} × {h} px","textLayerDesc":"Elke tekst blijft een aparte laag die je afzonderlijk kunt bewerken of verwijderen.","layer":"Laag","newText":"+ Nieuwe tekst","size":"Grootte","outline":"Omlijning","color":"Kleur","outlineColor":"Kleur omlijning","add":"Toevoegen","update":"Bijwerken","delete":"Verwijderen","zoom":"Zoom","localZoom":"Lokale zoom","rotation":"Rotatie","center":"Centreren","reset":"Resetten","done":"Klaar","transformText":"Tekst transformeren","frameImage":"Afbeelding kaderen","pinchHint":"Gebaren met twee vingers blijven rechtstreeks op de banner beschikbaar.","missionCropOnly":"Deze uitsnede geldt alleen voor dit medaillon.","resetThisMission":"Deze missie resetten","individualCrop":"Individuele uitsnede · 512 × 512","oneFinger":"1 vinger","move":"verplaatsen","twoFingers":"2 vingers","zoomRotate":"zoomen en draaien","previewPrime":"Prime-voorbeeld","previewApplied":"Individuele missie-aanpassingen zijn al toegepast.","previewOrder":"Nummer 1 staat rechtsonder; daarna loopt de nummering naar links en vervolgens rij voor rij omhoog.","exportTitle":"{n} missies exporteren","exportIntro":"Kies snelheid of verliesvrije PNG. Beide blijven 512 × 512.","noBackground":"Er is geen achtergrondafbeelding geladen.","missionFormat":"Missieformaat","jpgFast":"Snelle JPG · hoge kwaliteit","pngLossless":"Verliesvrije PNG · langzamer","fastEncoding":"De snelle modus vermijdt PNG-codering, veruit het langzaamste deel op een telefoon.","rowRender":"De achtergrond wordt één keer per rij gerenderd in plaats van zes keer opnieuw berekend.","adjusted":"{n} missie(s) met individuele uitsnede.","nianticCheck":"Controleer vóór het indienen de Niantic-regels: afbeeldingsrechten, relevante inhoud en geen dominant enkel teken.","ready":"Klaar.","createZip":"ZIP maken","zipAssembly":"ZIP wordt opgebouwd…","zipCreated":"ZIP gemaakt.","zipDownloaded":"ZIP gedownload.","saveShareZip":"ZIP opslaan of delen","exportFinished":"{format}-export voltooid","exportFailed":"Export mislukt.","newProject":"Nieuw project","myProjects":"Mijn projecten","projectsSaved":"{n} project(en) opgeslagen op deze telefoon.","unnamed":"Naamloos","opened":"Geopend","open":"Openen","rename":"Hernoemen","copy":"Kopiëren","noSavedProject":"Geen opgeslagen project.","renameProject":"Project hernoemen","renameHint":"Een naam die mensen kunnen lezen. Verrassend geavanceerd concept.","projectName":"Projectnaam","projectOpened":"Project geopend: {name}","projectRenamed":"Project hernoemd","deleteProject":"Dit project verwijderen?","deleteWarning":"De banner en de lokaal opgeslagen afbeelding worden verwijderd.","copyCreated":"Kopie gemaakt","projectDeleted":"Project verwijderd","newProjectCreated":"Nieuw project gemaakt met Redacted","defaultProject":"Mijn banner","defaultNewProject":"Nieuwe banner","copySuffix":"kopie","versionLabel":"Versie","infoPrime":"6 kolommen · 544 px · uitsnede van 512 px.","infoPlanner":"portalacties, passphrases, overdracht einde→start en het native BannerLab-pakket.","infoCompanion":"routes, acties, meerdere missies, opties en wandelstatistieken.","disclaimer":"Ingress en Ingress Prime zijn handelsmerken van Niantic. Redacted BannerLab is niet verbonden met of goedgekeurd door Niantic.","titleTokens":"$T = naam · $N = nummer · $M = totaal · $0N = 01, 02…","pluginShareText":"Companion-plugin 0.6.6. Vervang de vorige versie in IITC Mobile. Als IITC hem niet wil overschrijven, verwijder de oude plugin één keer en installeer dit bestand.","pluginDialog":"Companion 0.6.6 installeren / bijwerken","pluginShareFailed":"IITC-plugin kon niet worden gedeeld.","intelOpened":"IITC Mobile geopend met het BannerLab-project.","intelPrimeOpened":"IITC Prime geopend met het BannerLab-project.","intelFallback":"IITC Mobile geopend. Companion gebruikt de laatst gesynchroniseerde status.","intelPrimeFallback":"IITC Prime geopend. Companion gebruikt de laatst gesynchroniseerde status.","intelBrowser":"IITC niet gevonden: openen in browser.","tutorialIntro":"Bouw de volledige banner in IITC zonder na elke portal terug te keren naar BannerLab.","tut1Title":"Installeer de plugin één keer","tut1Text":"Gebruik onder Route “IITC-plugin installeren / bijwerken” en voeg het bestand daarna als gebruikersplugin toe in IITC Mobile.","tut2Title":"Open IITC vanuit BannerLab","tut2Text":"BannerLab geeft project, actieve missie en taal via een lokaal fragment door aan Companion. De Intel-server krijgt die gegevens nooit te zien.","tut3Title":"Bouw rechtstreeks op de kaart","tut3Text":"Met Companion kun je portals toevoegen, bewerken of verwijderen, van missie wisselen en routes bekijken zonder terug te gaan naar BannerLab.","tut4Title":"Synchroniseer als je klaar bent","tut4Text":"“BannerLab synchroniseren” stuurt alle bewerkte missies terug naar het project en opent BannerLab opnieuw.","tutNote":"Je kunt Companion verplaatsen en van grootte veranderen; de instellingen blijven onder Opties bewaard.","installUpdate":"Installeren / bijwerken","emptyTitleIssue":"Missie {n}: titel ontbreekt","emptyDescIssue":"Missie {n}: beschrijving ontbreekt","portalsIssue":"Missie {n}: {count}/{need} portals","missingGuidIssue":"Missie {n}: {count} ontbrekende GUID(s)","passIssue":"Missie {n}: {count} onvolledige passphrase(s)","reviewCount":"{n} punt(en) controleren","projectReady":"BannerLab-project klaar","fixBeforePublish":"Los deze punten op vóór publicatie.","publisherDesc":"De volgende brug vult het Mission Authoring Tool rechtstreeks vanuit dit native formaat. Het definitieve indienen blijft bewust in de officiële tool.","packCreating":"BannerLab-pakket wordt gemaakt…","packCreated":"BannerLab-pakket gemaakt","exportImpossible":"Export niet mogelijk: {error}","missionResetDone":"Missie {n} gereset","textDeleted":"Tekst verwijderd","histImport":"Afbeelding importeren","histMissionZoom":"Missiezoom","histMissionRotation":"Missierotatie","histTextRotation":"Tekstrotatie","histImageRotation":"Afbeeldingsrotatie","histTextZoom":"Tekstzoom","histImageZoom":"Afbeeldingszoom","histCenterText":"Tekst centreren","histCenterImage":"Afbeelding centreren","histResetText":"Tekst resetten","histResetImage":"Afbeelding resetten","histResetMission":"Missie resetten","histDeleteText":"Tekst verwijderen","histAddText":"Tekst toevoegen","histEditText":"Tekst bewerken","routeActionHelp":"Hack / Mod / Veroveren / Link / Field / Passphrase rechtstreeks vanuit Companion.","handoverDetail":"De laatste portal kan de eerste van de volgende missie worden zonder als ongeldig duplicaat te gelden.","coordsMissing":"Coördinaten niet gevonden.","coordsInvalid":"Ongeldige coördinaten.","duplicateElsewhere":"Deze portal wordt elders in de banner al gebruikt.","missionCompleteAdded":"Missie {n} voltooid · {next}","portalAdded":"Portal toegevoegd · missie {n}","syncOld":"Route gesynchroniseerd · oude Companion gevonden: installeer versie 0.6.6.","syncOk":"IITC-route gesynchroniseerd · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Rechtstreeks voorbereiden in Mission Authoring","livePublishShort":"Directe Publisher","livePreparing":"{n} missies voorbereiden voor Publisher…","liveReady":"Geïntegreerde Publisher openen…","liveNativeOnly":"Directe Publisher is beschikbaar in de Android-APK.","liveFailed":"Publisher kon niet worden geopend: {error}","liveExperimental":"Experimenteel: Mission Authoring opent in een door RBL beheerde weergave. Google-aanmelding is het eerste dat je op je telefoon moet controleren.","backupTransfer":"Back-up / overdracht","exportPackBackup":"BannerLab-pakket exporteren","openOfficialOnly":"Alleen officiële site openen","publisherPreparingImage":"Missie {n}/{total} renderen…","browserPublish":"Publiceren in Firefox","browserPublishShort":"Browser-Publisher","browserSetup":"Browser-Publisher installeren / bijwerken","browserPreparing":"Missie {n}/{total} voorbereiden…","browserOpening":"Firefox openen…","browserNeed":"Directe Publisher gebruikt Firefox Android + Violentmonkey zodat Google-aanmelding in een gewone browser blijft.","browserFailed":"Publisher kon niet worden geopend: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 voor missions.ingress.com. Installeer hem één keer in Violentmonkey op Firefox Android.","browserShareDialog":"Publisher 0.4.0 installeren","browserShareFailed":"Browser-Publisher kon niet worden gedeeld.","publisherUrlTooLarge":"Deze missie is te groot om naar de browser te sturen.","publisherReturn":"Teruggekeerd uit Publisher.","publisherNoFirefox":"Firefox is niet gevonden. De standaardbrowser wordt geopend, maar Publisher vereist een browser met userscript-ondersteuning.","publisherBrowser":"Publicatiebrowser","chromeMode":"Chrome","chromeModeSub":"Geen extra app · klein bladwijzer-script + Toestaan wanneer gevraagd","firefoxMode":"Firefox","firefoxModeSub":"Automatisch na installatie van Violentmonkey + Publisher","recommendedAuto":"Automatisch","noExtraApp":"Geen extra app","publishSelected":"Missie publiceren","chromeSetup":"Chrome instellen","firefoxSetup":"Firefox instellen","chromeReady":"Chrome-bladwijzer gecontroleerd","firefoxReady":"Firefox-Publisher gecontroleerd","notConfigured":"Eenmalige instelling vereist","chromeSetupTitle":"Chrome-Publisher","chromeSetupIntro":"Chrome laat RBL de bladwijzer niet voor je aanmaken. De instelling is daarom tot het minimum beperkt.","chromeStep1":"1. Kopieer de code van de RBL Publisher-bladwijzer.","chromeStep2":"2. Open Mission Authoring in Chrome en maak een bladwijzer van de pagina.","chromeStep3":"3. Bewerk die bladwijzer: noem hem “RBL Publisher” en vervang de URL door de gekopieerde code.","chromeStep4":"4. Tik in Mission Authoring op de adresbalk, typ “RBL” en kies de bladwijzer om te testen.","copyBookmarklet":"Bladwijzercode kopiëren","bookmarkletCopied":"Bladwijzercode gekopieerd","openChromeSetup":"Chrome openen voor instelling","testChrome":"Chrome-bladwijzer testen","chromeRunHint":"In Chrome: tik op de adresbalk, typ RBL en selecteer “RBL Publisher”.","chromeNeedsSetup":"Stel eerst de RBL Publisher-bladwijzer in Chrome in.","chromeOpenFail":"Chrome kon niet worden geopend. De standaardbrowser wordt geopend.","firefoxSetupTitle":"Firefox-Publisher","firefoxSetupIntro":"Firefox kan Publisher automatisch laden via Violentmonkey. Dit is de soepelste modus.","sharePublisher":"Publisher-userscript delen","testFirefox":"Firefox-Publisher testen","firefoxNeedsSetup":"Installeer Violentmonkey en Publisher in Firefox voordat je test.","browserSaved":"Publicatiebrowser: {browser}","setupConfirmed":"Instelling gecontroleerd.","bookmarkletCopyFail":"Automatisch kopiëren lukte niet. De code staat hieronder.","bookmarkletLabel":"Bladwijzercode","autoImpossibleChrome":"Automatisch laden is in Chrome Android niet mogelijk zonder extensie of ingrijpende toestemming. De bladwijzer blijft nodig.","openChromePublish":"Chrome openen…","openFirefoxPublish":"Firefox openen…","chromeWizardTitle":"Chrome instellen","chromeWizardIntro":"Eenmalige instelling. RBL onthoudt je voortgang.","chromeFileTitle":"Publisher opslaan","chromeFileText":"RBL slaat Publisher rechtstreeks op in Documenten/RedactedBannerLab. Het Android-deelvenster is niet nodig.","chromeSaveFile":"Publisher opslaan","chromeFileDone":"Publisher opgeslagen","alreadySaved":"Ik heb hem al opgeslagen","chromeBookmarkTitle":"Mini-bladwijzer maken","chromeBookmarkText":"De bladwijzer bevat niet meer de volledige Publisher. Hij is slechts {n} tekens lang en laadt het bestand dat je net hebt opgeslagen.","chromeBookmarkName":"Naam bladwijzer: RBL Publisher","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Toevoegen aan bladwijzers. Bewerk daarna de bladwijzer, noem hem “RBL Publisher” en plak de code in URL.","copyMiniCode":"Minicode kopiëren","miniCodeCopied":"Minicode gekopieerd","openChromeBookmark":"Mission Authoring openen","bookmarkCreated":"Ik heb de bladwijzer gemaakt","chromeTestTitle":"Testen en toestaan","chromeTestText":"RBL opent Mission Authoring. Typ RBL en voer de bladwijzer uit. Chrome vraagt om Publisher en daarna om de huidige JSON. De JSON wordt bij elke nieuwe banner gevraagd, nooit tussen missies.","chromeTestButton":"Testen in Chrome","chromeTestWaiting":"In Chrome: typ RBL → RBL Publisher → selecteer publisher.js indien gevraagd → Toestaan.","chromeSetupSuccess":"Chrome is klaar","chromeSetupSuccessText":"Chrome is klaar. Publisher blijft onthouden; de banner-JSON wordt voor elke nieuwe sessie expliciet gekozen zodat oude projecten niet stilletjes opnieuw gebruikt worden.","publishNow":"Nu publiceren","wizardPrev":"Vorige","wizardNext":"Doorgaan","wizardRestart":"Instelling opnieuw starten","stepOf":"Stap {n}/3","chromeFileShareText":"Sla deze publisher.js op een makkelijk te vinden plek op, bijvoorbeeld Downloads. Chrome vraagt er tijdens de eerste test om.","chromeFileShareDialog":"RBL Publisher opslaan","chromeFileShareFail":"Publisher-bestand kon niet worden voorbereid.","chromePermissionHint":"Chrome kan opnieuw toestemming vragen om publisher.js te lezen. Gewoon toestaan.","chromeNotAutoFavorite":"RBL kan geen Chrome-bladwijzer automatisch aanmaken. Dit is de enige verplichte handmatige stap.","codeLength":"{n} tekens","chromeStepSaved":"Stap opgeslagen","chromeResetDone":"Chrome-instelling gereset","chromeSelectFileHint":"Selecteer in Chrome: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","bannerDescription":"Bannerbeschrijving","required":"Verplicht","bannerDescriptionHint":"Dit is de standaardbeschrijving voor elke missie. Je kunt individuele missies later nog aanpassen.","bannerDescriptionRequired":"De bannerbeschrijving is verplicht.","describeBeforePublish":"Beschrijf eerst de banner","describeBeforePublishText":"Publiceren is geblokkeerd totdat de banner een beschrijving heeft. Die wordt als standaard voor alle missies gebruikt.","saveAndContinue":"Opslaan en doorgaan","missionPublishBlocked":"Missie kan niet worden gepubliceerd","missionNeedsPortals":"Missie {n} heeft {count}/{need} portals. Er zijn minimaal {need} nodig vóór publicatie.","completeMission":"Missie voltooien","currentMissionReady":"Missie klaar om te publiceren","publishBlockedHint":"Publiceren blijft geblokkeerd tot alle verplichte onderdelen compleet zijn.","minimumSix":"Minimum: 6 portals per missie","publisherDescRequired":"Publisher weigert missies zonder beschrijving.","publisherPortalsRequired":"Publisher weigert missies met minder dan 6 portals.","playBanners":"Banner zoeken","playHub":"Banner zoeken","searchBannergress":"Banner zoeken","searchPlaceholder":"Naam of trefwoord","search":"Zoeken","favorites":"Favorieten","currentBanner":"Hervatten","noFavorites":"Nog geen favorieten. Je lokale opslag geniet van de rust.","noPlaySession":"Er is momenteel geen banner actief.","searchPrompt":"Zoek op naam en/of geografisch gebied, met een echte afstandslimiet.","searching":"Zoeken…","searchError":"Bannergress-zoekopdracht mislukt: {error}","missionsCount":"{n} missies","distanceKm":"{n} km","favorite":"Favoriet","removeFavorite":"Uit favorieten verwijderen","playThisBanner":"Deze banner starten","resumeBanner":"Deze banner hervatten","stopBanner":"Overlay stoppen","openCurrentMission":"Huidige missie openen","overlayPermissionTitle":"RBL-overlay toestaan","overlayPermissionText":"Android moet Redacted BannerLab toestaan boven Ingress te verschijnen. Eén systeemtoestemming, daarna kan de dinosaurus weer gewoon zijn werk doen.","overlayPermissionButton":"Weergave boven andere apps toestaan","overlayPermissionWaiting":"Keer terug naar RBL nadat je toestemming hebt gegeven.","overlayStarted":"Missie-overlay gestart.","overlayFailed":"Overlay kon niet worden gestart: {error}","bannerLoadError":"Deze banner kon niet worden geladen: {error}","bannerOffline":"Deze banner bevat geen bruikbare missies.","bannerDisabled":"{n} uitgeschakelde missie(s)","addressUnknown":"Locatie niet opgegeven","doneMissions":"{done}/{total} voltooid","deepLinkOnly":"RBL bestuurt Ingress niet: de overlay opent alleen officiële missie-deeplinks.","bannergressCredit":"Zoeken via Bannergress","publisherWholeBanner":"Hele banner voorbereiden","publisherWholeHint":"Eén browsersessie: alle missies en afbeeldingen worden samen voorbereid.","publisherAllRequired":"Elke missie moet compleet zijn voordat de publicatiesessie start.","publisherSessionCreating":"Publisher-sessie {n}/{total} voorbereiden…","publisherSessionReady":"Sessie opgeslagen in Documents/RedactedBannerLab. Mission Authoring openen…","publisherSessionFileText":"RBL slaat de sessie automatisch op in Documents/RedactedBannerLab.","publisherSessionDialog":"Publisher-sessie","publisherSessionShareFail":"Publisher-sessie kon niet worden voorbereid.","chromeSessionHint":"Chrome: voer de RBL Publisher-bladwijzer uit. Voor elke nieuw voorbereide banner vraagt Chrome expliciet om RBL_Current_Session.rblpub.json. Tussen missies is niets extra nodig.","firefoxSessionHint":"Firefox: Publisher opent automatisch. Laad RBL_Current_Session.rblpub.json als de huidige sessie nog niet bekend is.","easterEgg":"Je hebt hierom gevraagd.","bannerNameSearch":"Naam / trefwoord","citySearch":"Plaats","authorSearch":"Auteur","cityPlaceholder":"bijv. Nantes","authorPlaceholder":"bijv. AgentName","nearMe":"Bij mij in de buurt","nearMeOn":"Huidige locatie ingeschakeld","nearMeHint":"Gebruikt je huidige locatie in plaats van een plaats.","locationGetting":"Locatie ophalen…","locationError":"Locatie kon niet worden opgehaald: {error}","locationReady":"Locatie gevonden","searchCriteriaRequired":"Vul minstens één zoekcriterium in.","cityResolving":"Plaats opzoeken…","cityNotFound":"Geen Bannergress-plaats gevonden voor “{city}”.","cityUsing":"Gebruikte plaats: {city}","bannerAuthor":"Auteur: {author}","overlayDrag":"≡ Verplaatsen","overlayMinimize":"Minimaliseren","overlayClose":"Sluiten","overlayMoved":"Overlaypositie opgeslagen","searchReset":"Wissen","resultsCount":"{n} resultaat/resultaten","searchFilters":"Actieve filters","allPublicBanners":"Openbare Bannergress-banners","searchRadius":"Zoekradius","radiusHint":"Wordt toegepast rond de plaats of je huidige locatie.","locationDisabled":"Locatieservices zijn op deze telefoon uitgeschakeld.","locationPermissionDenied":"BannerLab heeft geen toestemming om je locatie te gebruiken.","locationUnavailable":"Locatie niet beschikbaar. Controleer of locatieservices op de telefoon zijn ingeschakeld.","locationTimeout":"Locatie kon niet op tijd worden bepaald. Controleer of locatieservices zijn ingeschakeld.","openLocationSettings":"Locatie inschakelen","openAppSettings":"App-instellingen openen","cityNoCoordinates":"“{city}” is gevonden, maar de positie kan niet worden gebruikt.","cityUsingRadius":"Gebruikt: {city} · radius {radius} km","radiusResults":"{n} resultaat/resultaten binnen {radius} km","distanceFromPoint":"{distance} verderop","locationChecking":"Locatieservices controleren…","publisherCurrentFile":"Huidig bestand: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher opgeslagen in Documents/RedactedBannerLab.","chromeFileWriteFail":"Publisher kon niet naar Documents/RedactedBannerLab worden geschreven.","chromeCurrentSessionHint":"Voor elke nieuwe banner: kies Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json.","browserResume":"Sessie voorbereid. RBL Mission Authoring-tab openen…","chromeResumeHint":"Chrome hergebruikt nu hetzelfde Mission Authoring-tabblad dat voor RBL is gereserveerd.","firefoxResumeHint":"Mission Authoring openen in de publicatiebrowser.","browserResumeFallback":"RBL-tab kon niet worden hergebruikt. Browser openen als fallback.","publisherAutoRefresh":"Publisher bewaakt nu het huidige sessiebestand en laadt een nieuw voorbereide banner automatisch opnieuw.","flowLocked":"Bannerbewerking vergrendeld","flowLockedText":"Stap {step} is actief. Kies “1 Banner” om afbeelding, tekst of uitsnede te bewerken.","returnFresco":"Kies 1 Banner om te bewerken","flowLockedToast":"Ga terug naar stap 1 Banner om de banner te bewerken.","publisherTabReuse":"RBL gebruikt een stabiele browser-app-ID om hetzelfde tabblad te hergebruiken.","todo":"Te doen","history":"Geschiedenis","inProgress":"Bezig","addTodo":"Toevoegen aan Te doen","removeTodo":"Verwijderen uit Te doen","noTodo":"Geen banners te doen. Verdacht redelijk.","noHistory":"Nog geen banners gespeeld. De dinosaurus verveelt zich.","bannerMap":"Routekaart","openMap":"Kaart bekijken","navigateStart":"Naar start navigeren","startUnavailable":"Startpunt niet beschikbaar.","mapUnavailable":"Bannergress levert geen bruikbare coördinaten voor deze banner.","startPoint":"Start","missionStart":"Missie {n}","shareGroup":"Delen / groep","shareProgress":"Voortgang delen","shareBanner":"Banner delen","shareIntro":"De QR-code opent RBL op dezelfde banner en hetzelfde missienummer. Er wordt geen Bannergress-account gebruikt.","copyLink":"RBL-link kopiëren","linkCopied":"RBL-link gekopieerd","shareNow":"Delen","bannergressPage":"Openen op Bannergress","joinBanner":"Deelnemen aan banner","joinAtMission":"Instappen bij missie {n}","sharedBannerLoaded":"Gedeelde banner geladen · missie {n}","sharedBannerError":"Gedeelde banner kon niet worden geladen: {error}","playStats":"Sessiestatistieken","startedAt":"Gestart","finishedAt":"Voltooid","elapsed":"Actieve tijd","estimatedDistance":"Geschatte afstand","missionsDone":"Missies voltooid","paused":"Gepauzeerd","playing":"Bezig","completedBanner":"Voltooid","replayBanner":"Opnieuw spelen","resumeFromHistory":"Hervatten","groupNoServer":"Serverloze groepsmodus: deel de QR/link opnieuw als de groep naar een andere missie gaat.","publicOnly":"Alleen openbare Bannergress-zoekopdracht/-gegevens · geen login nodig.","routePoints":"{n} routepunten","uselessStats":"Nutteloze statistieken","loadingStats":"Dingen berekenen waar niemand om vroeg…","statsUnavailable":"Niet genoeg coördinaten om nutteloze statistieken te berekenen.","bgDistance":"Bannergress-afstand","calculatedTrack":"Geschatte wandelafstand","walkingEstimate":"Geschatte wandeltijd","routeSteps":"Etappes","uniquePlaces":"Unieke locaties","revisitedPlaces":"Herhaalde bezoeken","stepsPerKm":"Etappes / km","avgMissionDistance":"Gemiddeld / missie","longestMission":"Langste missie","longestLeg":"Langste etappe","betweenMissions":"Overgangen tussen missies","detourFactor":"Omwegfactor","routeCoverage":"Kaartdekking","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"RBL routeert elke portal-naar-portal-etappe over het voetgangersnetwerk van OpenStreetMap. Elke etappe wordt gecontroleerd: onmogelijke shortcuts of duidelijk absurde omwegen worden alleen voor die etappe vervangen door de directe afstand. Dit is een wandelinschatting, geen GPS-meting.","minutesShort":"{n} min","hoursMinutes":"{h} u {m}","xFactor":"×{n}","showUselessStats":"📊 Nutteloze statistieken","hideUselessStats":"Statistieken verbergen","statsLoaded":"Statistieken berekend","directGeometric":"Opgetelde directe afstand","routingDetour":"Netwerk / direct","routingSource":"Routering","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla niet beschikbaar · geometrische schatting","routingLoading":"Werkelijke wandelroute berekenen…","routingFailed":"Wandelroutering niet beschikbaar, geometrische statistieken gebruikt.","routingNative":"Valhalla + OSM · controle per etappe","routingWeb":"Valhalla + OSM · controle per etappe","routingErrorDetail":"Valhalla mislukt: {error}","ingressRadius":"Ingress-bereik","ingressRadiusValue":"40 m","correctedLegs":"Gecorrigeerde etappes","rawValhalla":"Ruwe Valhalla","creditsTitle":"Credits & dank","bannergressThanks":"Bedankt, Bannergress","bannergressThanksText":"Bannerzoeken en diverse openbare details in Redacted BannerLab gebruiken openbare Bannergress-gegevens. Dank aan hun team en bijdragers voor het enorme werk rond Ingress-banners.","bannergressNoLogin":"RBL gebruikt geen Bannergress-account: alleen openbare gegevens die nodig zijn voor zoeken en tonen.","independentProject":"Redacted BannerLab is een onafhankelijk project en is niet verbonden met of goedgekeurd door Bannergress of officiële Ingress-diensten.","visitBannergress":"Bannergress bezoeken","mapCredits":"Kaarten & routering","mapCreditsText":"Kaarten gebruiken OpenStreetMap-gegevens. Schattingen van wandelroutes gebruiken de Valhalla-routeringsengine.","rblCreditsFoot":"Dank aan alle tools en bijdragers die dit Ingress-missie-ecosysteem mogelijk maken.","layersTitle":"Afbeeldingen & lagen","layersDesc":"Beheer hier de achtergrond en alle afbeeldingen erboven. Miniaturen helpen de juiste laag te herkennen; daarna kun je selecteren, verbergen, herschikken of groeperen.","backgroundLayer":"Hoofdachtergrond","addBackground":"Achtergrond toevoegen / vervangen","addLayer":"Laag toevoegen","layerName":"Afbeeldingslaag","selected":"Geselecteerd","visibleLayer":"Zichtbaar","hiddenLayer":"Verborgen","moveUp":"Omhoog","moveDown":"Omlaag","groupSelection":"Selectie groeperen","group":"Groeperen","ungroup":"Groep opheffen","groupNeedTwo":"Selecteer minstens twee lagen om te groeperen.","groupCreated":"Lagen gegroepeerd","groupRemoved":"Groep opgeheven","deleteLayer":"Laag verwijderen","layerDeleted":"Laag verwijderd","layerAdded":"Laag toegevoegd","backgroundReplaced":"Achtergrond vervangen","backgroundMissing":"Geen hoofdachtergrond","backgroundFixed":"De achtergrond blijft altijd onder de andere lagen.","groupHint":"Vink meerdere lagen aan en tik op Groeperen. Een groep verplaatst, zoomt en draait samen.","layerOrder":"Laagvolgorde","layerTransform":"Laag transformeren","groupTransform":"Groep transformeren","renameLayer":"Hernoemen","duplicateLayer":"Dupliceren","layerDuplicated":"Laag gedupliceerd","histAddLayer":"Laag toevoegen","histDeleteLayer":"Laag verwijderen","histReorderLayer":"Laag herschikken","histGroupLayers":"Lagen groeperen","histUngroupLayers":"Groep opheffen","histVisibilityLayer":"Laagzichtbaarheid","histRenameLayer":"Laag hernoemen","histDuplicateLayer":"Laag dupliceren","layerGroupBadge":"Groep","layerUngroup":"Deze groep opheffen","layerSelectHint":"De geselecteerde laag kan daarna rechtstreeks op de banner worden verplaatst.","layerOpacity":"Dekking","layerDimensions":"{w} × {h} px","noImageContent":"Voeg minstens één afbeelding toe vóór export.","groupRelative":"De bediening hieronder transformeert de hele groep tegelijk.","groupZoom":"Groepszoom","groupRotation":"Groepsrotatie","clearGroupSelection":"Selectie wissen","allLayersTitle":"Lagen","allLayersDesc":"Selecteer het element dat je wilt bewerken. Afbeeldingen en tekst blijven ook vanuit hun eigen menu's bewerkbaar.","imageLayersSection":"Afbeeldingen","textLayersSection":"Tekst","noExtraImageLayer":"Geen extra afbeeldingslaag","noTextLayer":"Geen tekstlaag","selectLayer":"Selecteren","editLayer":"Bewerken","missionNumberQuestion":"Wat is het nummer van de missie?","groupName":"Groep {n}","groupCount":"{n} laag/lagen","creatorBy":"Gemaakt door Zw4nn","communityTitle":"Community & support","communityText":"Ga rechtstreeks naar de community en support via de Redacted BannerLab-bot.","telegramOpen":"Contact opnemen met support","reportProblem":"Probleem melden","reportProblemText":"Kopieer een technische diagnose en neem daarna via de bot contact op met support.","copyDiagnostic":"Diagnose kopiëren","diagnosticCopied":"Diagnose gekopieerd","diagnosticCopyFailed":"Diagnose kon niet worden gekopieerd","diagnosticDescription":"Beschrijving van het probleem:","portableProject":"Draagbaar project","portableProjectDesc":"Exporteer één banner met afbeeldingen, lagen, tekst, lettertypen, missies en route.","exportProject":"Exporteren","shareProject":"Delen","importProject":"Project importeren","projectExporting":"Project voorbereiden…","projectExported":"Project opgeslagen","projectShared":"Project klaar om te delen","projectImportSuccess":"Project geïmporteerd","projectImportInvalid":"Dit bestand is geen geldig Redacted BannerLab-project.","projectShareTitle":"Redacted BannerLab-project","projectImportHint":"Het geïmporteerde project wordt toegevoegd zonder je andere projecten te wijzigen.","backupTitle":"Back-up & herstellen","backupText":"Bewaar alle BannerLab-projecten, instellingen en afbeeldingen in één draagbaar JSON-bestand.","backupFolder":"Back-upmap","backupFolderChoose":"Map kiezen","backupFolderChange":"Map wijzigen","backupFolderNone":"Geen map geselecteerd","backupFolderReady":"Map ingesteld","backupAuto":"Automatische back-up op de achtergrond","backupAutoHint":"Wanneer ingeschakeld, bereidt BannerLab na wijzigingen regelmatig een back-up voor en forceert bij naar de achtergrond gaan een laatste opslag.","backupNow":"Nu back-up maken","backupExport":"JSON exporteren","backupImport":"JSON importeren","backupWorking":"Back-up maken…","backupSaved":"Back-up voltooid","backupAutoSaved":"Automatische back-up voltooid","backupFailed":"Back-up mislukt: {error}","backupNeedFolder":"Kies eerst een back-upmap.","backupFolderError":"Deze map kan niet worden gebruikt.","backupImported":"Back-up hersteld","backupInvalid":"Dit bestand is geen geldige Redacted BannerLab-back-up.","backupImportTitle":"Back-up herstellen","backupImportText":"{n} project(en) gevonden · back-up van {date}","backupMerge":"Samenvoegen","backupReplace":"Alles vervangen","backupReplaceWarn":"Alles vervangen verwijdert eerst de projecten die momenteel op dit apparaat zijn opgeslagen.","backupCancel":"Annuleren","backupLast":"Laatste back-up: {date}","backupNever":"Nog geen back-up","backupPortable":"De JSON bevat ook de afbeeldingen. Het bestand kan dus groot zijn, maar is volledig zelfstandig.","backupNativeOnly":"Automatische mapback-up is beschikbaar op Android. JSON-export/import blijft overal beschikbaar.","backupFolderChosen":"Back-upmap opgeslagen","backupNoChanges":"Geen wijzigingen om te back-uppen.","studioEdit":"Bewerken op volledig scherm","studioTitle":"Bewerkingsstudio","studioLayers":"Lagen","studioTexts":"Tekst","studioTools":"Gereedschap","studioFit":"6 missies","studioFitOne":"1 missie","studioFitAll":"Alles","studioMissionMode":"Missie","studioFrescoMode":"Banner","studioFullscreen":"Volledig scherm","studioRotateHint":"6 missies verticaal · volgende rijen scrollen naar rechts.","studioSelected":"Geselecteerd item","studioNoLayer":"Selecteer een laag of tekst in het zijpaneel.","studioGroupSelect":"Groepsselectie","studioGroupNow":"Groeperen","studioOpenFull":"Volledige beheerder openen","studioOpacity":"Dekking","studioClose":"Studio verlaten","studioPan":"Scrollen","studioAddText":"Tekst toevoegen","studioNoText":"Nog geen tekst.","studioEditText":"Tekst bewerken","studioDuplicateText":"Tekst dupliceren","font":"Lettertype","fontWeight":"Gewicht","fontItalic":"Cursief","letterSpacing":"Letterafstand","lineHeight":"Regelhoogte","textAlign":"Uitlijning","alignLeft":"Links","alignCenter":"Midden","alignRight":"Rechts","importFont":"Lettertype importeren","fontImported":"Lettertype geïmporteerd: {name}","fontInvalid":"Dit lettertype wordt niet ondersteund.","fontTooLarge":"Lettertypebestand is te groot (max. 12 MB).","textBackground":"Tekstachtergrond","textBackgroundColor":"Achtergrondkleur","textBackgroundOpacity":"Achtergronddekking","textBackgroundPadding":"Binnenruimte achtergrond","textBackgroundRadius":"Hoekradius","textTypography":"Typografie","tutorialHubTitle":"Handleidingen & aan de slag","tutorialHubText":"Start wanneer je wilt opnieuw een rondleiding. Redacted kan ook alleen uitleggen wat je op dat moment nodig hebt.","tutorialOpen":"Handleidingen bekijken","tutorialWelcomeTitle":"Welkom bij Redacted BannerLab","tutorialWelcomeText":"Redacted kan je het lab laten zien. Twee minuten, een paar knoppen en geen examen aan het eind.","tutorialStart":"Rondleiding starten","tutorialLater":"Later","tutorialNever":"Niet meer tonen","tutorialPrevious":"Vorige","tutorialNext":"Volgende","tutorialUnderstood":"OK, begrepen","tutorialClose":"Sluiten","tutorialDone":"Handleiding voltooid","tutorialSeen":"Gezien","tutorialQuick":"Snelle rondleiding","tutorialQuickDesc":"De belangrijkste bediening en de algemene BannerLab-workflow.","tutorialBanner":"Banner maken","tutorialBannerDesc":"Van project tot voorbeeld en export van de missies.","tutorialLayers":"Afbeeldingen, lagen & tekst","tutorialLayersDesc":"Achtergrond, overliggende afbeeldingen, lagen en typografie.","tutorialIitc":"Route bouwen met IITC","tutorialIitcDesc":"Installeer Companion, voeg portals toe en synchroniseer de route.","tutorialPublish":"Missies publiceren","tutorialPublishDesc":"Bereid missies voor en gebruik daarna Publisher en Mission Authoring.","tutorialBackup":"Back-ups & draagbare projecten","tutorialBackupDesc":"Maak een back-up van BannerLab of deel één volledige banner.","importRolesHint":"Hoofdachtergrond = basisafbeelding van de banner · Laag = extra afbeelding erboven.","tutProjectTitle":"Je projecten","tutProjectText":"Elke banner zit in zijn eigen project. Je kunt hem exporteren of delen zonder alle andere projecten mee te slepen.","tutNameTitle":"Projectnaam","tutNameText":"Geef je banner een herkenbare naam.","tutRowsTitle":"Aantal rijen","tutRowsText":"Eén rij bevat 6 missies. Kies hier de uiteindelijke hoogte van de banner.","tutImageTitle":"Afbeeldingen & lagen","tutImageText":"Importeer hier de hoofdachtergrond en extra afbeeldingen. In hetzelfde scherm selecteer, orden, verberg en groepeer je afbeeldingslagen.","tutBackgroundTitle":"Hoofdachtergrond","tutBackgroundText":"Gebruik Hoofdachtergrond voor je eerste echte afbeelding. Die vervangt de basisafbeelding en vult de banner.","tutExtraLayerTitle":"Laag toevoegen","tutExtraLayerText":"Een tweede afbeelding is een laag: die ligt boven de achtergrond en blijft verplaatsbaar, schaalbaar en verbergbaar.","tutLayersTitle":"Afbeeldingslagen beheren","tutLayersText":"Miniaturen laten zien welke afbeeldingslaag je bewerkt. Selecteer hem, verander de volgorde, verberg hem of vink meerdere afbeeldingen aan om te groeperen.","tutTextTitle":"Tekst","tutTextText":"Voeg tekst toe, kies lettertypen, afstanden, achtergrond en radius, of importeer je eigen lettertype.","tutPreviewTitle":"Voorbeeld","tutPreviewText":"Controleer elke missie vóór export. Individuele uitsneden zijn al toegepast.","tutExportTitle":"Export","tutExportText":"Als alles klaar is, maakt BannerLab de 512 × 512-missieafbeeldingen in de juiste volgorde.","tutStudioTitle":"Studio op volledig scherm","tutStudioText":"Een comfortabelere editor op volledig scherm met bediening aan de zijkant en grote aanraakvlakken.","tutFlowTitle":"De 4 stappen","tutFlowText":"Banner → Route → Missies → Publiceren. BannerLab volgt deze workflow.","tutRouteTitle":"Route","tutRouteText":"De route koppelt missies aan echte Ingress-portals. IITC Companion doet het kaartwerk.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion neemt het actieve project, de missie, portals, acties en wandelstatistieken mee naar IITC.","tutInstallCompanionTitle":"Companion installeren","tutInstallCompanionText":"Installeer of update het userscript één keer in IITC Mobile.","tutOpenIitcTitle":"IITC openen","tutOpenIitcText":"Open IITC vanuit BannerLab zodat project en actieve missie aan Companion worden doorgegeven.","tutAutoRouteTitle":"Tussen missies schakelen","tutAutoRouteText":"De volgende missie kan automatisch openen en de laatste portal van de vorige als eerste hergebruiken.","tutPortalListTitle":"Je portals","tutPortalListText":"Portals komen terug met GUID, coördinaten, volgorde en actie, zodat de route opnieuw kan worden opgebouwd.","tutMissionsTitle":"Missies voorbereiden","tutMissionsText":"Vul vóór publicatie de algemene beschrijving in en controleer elke missie.","tutMissionDescTitle":"Verplichte beschrijving","tutMissionDescText":"BannerLab meldt ontbrekende informatie voordat publiceren wordt toegestaan.","tutPublishTitle":"Publiceren","tutPublishText":"Als routes en beschrijvingen klaar zijn, ga je hier verder. Het definitieve indienen blijft in de officiële tool.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab bereidt missiegegevens en de publicatiestroom voor. Gebruik na het indienen “Ik heb ingediend” om de gepubliceerde status te controleren.","tutInfoTitle":"Instellingen, hulp & support","tutInfoText":"Instellingen & info bevat taal, back-ups, handleidingen en support via de Redacted BannerLab-bot.","tutBackupTitle":"Volledige back-up","tutBackupText":"De volledige JSON bevat alle projecten, instellingen, afbeeldingen en lettertypen. Android kan ook een automatische back-upmap gebruiken.","tutPortableTitle":"Draagbaar project","tutPortableText":"Exporteer, deel of importeer één banner met afbeeldingen, tekst, lettertypen, missies en route.","tutSupportTitle":"Hulp nodig?","tutSupportText":"Kopieer zo nodig de diagnose en neem contact op met support. De bot linkt ook naar het kanaal en de discussiegroep.","settingsInfo":"Instellingen & info","addMissionLayer":"Op een missie","importMissionSeries":"Serie importeren","missionLayer":"Missielaag","globalLayer":"Globale laag","layerScope":"Bereik van laag","wholeBanner":"Hele banner","missionTarget":"Toegewezen missie","fitMode":"Passend maken","fitCover":"Vullen","fitContain":"Passen","missionBadge":"M{n}","missionLayerHint":"Deze laag blijft gekoppeld aan missie {n} en wordt automatisch tot die tegel begrensd.","missionSeriesTitle":"Missieserie importeren","missionSeriesText":"Wijs elke afbeelding aan een missie toe. BannerLab plaatst en snijdt ze automatisch bij.","missionSeriesDetected":"{n} afbeelding(en) gevonden","missionSeriesImport":"Lagen importeren","missionSeriesTooMany":"Je hebt meer afbeeldingen dan missies geselecteerd. Meerdere afbeeldingen mogen aan dezelfde missie worden toegewezen.","missionLayerAdded":"Afbeelding toegevoegd aan missie {n}","missionSeriesAdded":"{n} missielaag/lagen toegevoegd","missionScopeMismatch":"Missielagen kunnen alleen worden gegroepeerd als ze bij dezelfde missie horen.","missionLayerTutorialTitle":"Aan missies gekoppelde lagen","missionLayerTutorialText":"Tik op “Laag toevoegen” en kies: hele banner, één missie of meerdere missies. Bij één missie plaatst en begrenst BannerLab de afbeelding automatisch in de juiste cel. Bij meerdere missies importeer je een serie en wijs je elke afbeelding aan de gewenste missie toe.","addLayerChoiceTitle":"Laag toevoegen","addLayerChoiceText":"Kies waar deze laag bij hoort. Je kunt dit later aanpassen.","addLayerWhole":"Op de hele banner","addLayerWholeText":"Een vrije afbeelding boven de hele banner, verplaatsbaar en schaalbaar.","addLayerOneMission":"Op één missie","addLayerOneMissionText":"Een afbeelding die automatisch op de gekozen missie wordt geplaatst en begrensd.","addLayerManyMissions":"Over meerdere missies","addLayerManyMissionsText":"Importeer een serie afbeeldingen en wijs elke afbeelding aan de gewenste missie toe.","multiSelection":"Meervoudige selectie","multiSelectionHint":"Vink meerdere lagen aan om een gezamenlijke actie toe te passen, ze te groeperen of te verwijderen.","selectionActions":"Acties voor selectie","editSelection":"Selectie bewerken","deleteSelection":"Selectie verwijderen","selectedLayersCount":"{n} laag/lagen geselecteerd","bulkScopeKeep":"Huidig bereik behouden","bulkMissionKeep":"Huidige missies behouden","bulkFitKeep":"Huidige passing behouden","bulkVisibility":"Zichtbaarheid","bulkVisibilityKeep":"Niet wijzigen","bulkShow":"Tonen","bulkHide":"Verbergen","bulkOpacityEnable":"Dekking wijzigen","applyToSelection":"Toepassen op geselecteerde lagen","selectionUpdated":"Geselecteerde lagen bijgewerkt","selectionDeleted":"Geselecteerde lagen verwijderd","deleteSelectionConfirm":"{n} geselecteerde laag/lagen definitief verwijderen?","selectionEmpty":"Selecteer minstens één laag.","layerScopeHelp":"Hele banner: de laag kan de volledige banner bedekken. Eén missie: de laag wordt automatisch tot de gekozen missie begrensd. Meerdere missies: importeer een serie en wijs elke afbeelding aan zijn missie toe."};
// Italiano completo: tutte le stringhe UI principali, incluse le funzioni Studio e Publisher.
Object.assign(I18N.it,{"fresco":"Banner","framing":"Inquadratura","layers":"Livelli","noMission":"Nessuna missione selezionata","addImage":"Aggiungi la tua immagine","imageHint":"Verrà inquadrata direttamente sulla geometria Prime.","circles":"Cerchi Prime","grid":"Griglia 512","numbers":"Numeri","enlarge":"Ingrandisci missione","resetMission":"Reimposta missione","prev":"Precedente","next":"Successiva","complete":"Missione completa","remaining":"Mancano {n} portale/i","openIitc":"Apri IITC Companion","tutorial":"Tutorial","installPlugin":"Installa / aggiorna il plugin IITC","autoAdvance":"Passa automaticamente alla missione successiva a {n} portali","reuseLast":"Riutilizza automaticamente l’ultimo portale come primo della missione successiva","noPortal":"Nessun portale in questa missione.","action":"Azione","hack":"Hack","mod":"Installa un mod","capture":"Cattura / potenzia","link":"Crea un link","field":"Crea un campo","passphrase":"Passphrase","question":"Domanda","answer":"Risposta prevista","save":"Salva","cancel":"Annulla","settings":"Impostazioni comuni","commonDesc":"Descrizione comune","titleFormat":"Formato dei titoli","defaultType":"Tipo predefinito","location":"Posizione","sequential":"Sequenziale","anyOrder":"Ordine libero","portalsPerMission":"Portali / missione","editMission":"Modifica missione","title":"Titolo","description":"Descrizione","missionReady":"Pronta","missionIncomplete":"Incompleta","openRoute":"Modifica percorso","publishPack":"Crea pacchetto BannerLab","openMat":"Apri Mission Authoring Tool","ownWorkflow":"BannerLab usa ora il proprio formato di progetto e il proprio pacchetto di pubblicazione.","french":"Français","english":"English","spanish":"Español","companionStats":"Statistiche a piedi in IITC","companionStatsDesc":"Nel mini pannello IITC: 📊 Statistiche inutili calcola distanza a piedi stimata, tempo, deviazione e altre assurdità.","duplicateBad":"{n} riutilizzo/i di portale da verificare.","handoverOk":"È consentito riutilizzare la fine di una missione come inizio della successiva.","pluginVersion":"Companion 0.6.6","undo":"Annulla","redo":"Ripristina","subtitle":"Banner Ingress Prime","source":"sorgente","bannerHelp":"<b>Modalità banner:</b> 1 dito sposta il livello selezionato. <b>2 dita</b> eseguono zoom e rotazione.","missionHelp":"<b>Modalità missione:</b> tocca un medaglione. Per lavorare più comodamente, usa <b>Ingrandisci missione</b>. Puoi anche spostarlo qui con 1 dito.","missionSelected":"Missione {n} selezionata","tapMedallion":"Tocca un medaglione","touchMissionFirst":"Tocca prima la missione che vuoi reinquadrare.","selectMissionFirst":"Seleziona prima una missione.","heavyImage":"Immagine molto pesante. Potrebbe mettere in ginocchio il telefono, con notevole disappunto per entrambi.","imported":"Importati {w} × {h} px","textLayerDesc":"Ogni testo resta un livello indipendente, modificabile o eliminabile.","layer":"Livello","newText":"+ Nuovo testo","size":"Dimensione","outline":"Contorno","color":"Colore","outlineColor":"Colore contorno","add":"Aggiungi","update":"Aggiorna","delete":"Elimina","zoom":"Zoom","localZoom":"Zoom locale","rotation":"Rotazione","center":"Centra","reset":"Reimposta","done":"Fatto","transformText":"Trasforma testo","frameImage":"Inquadra immagine","pinchHint":"I gesti a due dita restano disponibili direttamente sul banner.","missionCropOnly":"Questa inquadratura riguarda solo questo medaglione.","resetThisMission":"Reimposta questa missione","individualCrop":"Inquadratura individuale · 512 × 512","oneFinger":"1 dito","move":"sposta","twoFingers":"2 dita","zoomRotate":"zoom e rotazione","previewPrime":"Anteprima Prime","previewApplied":"Le regolazioni individuali delle missioni sono già applicate.","previewOrder":"Il numero 1 è in basso a destra, poi la numerazione procede verso sinistra e sale nelle righe superiori.","exportTitle":"Esporta {n} missioni","exportIntro":"Scegli velocità oppure PNG senza perdita. Entrambi restano a 512 × 512.","noBackground":"Nessuna immagine di sfondo caricata.","missionFormat":"Formato missioni","jpgFast":"JPG rapido · alta qualità","pngLossless":"PNG senza perdita · più lento","fastEncoding":"La modalità rapida evita la codifica PNG, che è di gran lunga la parte più lenta su telefono.","rowRender":"Lo sfondo viene renderizzato una sola volta per riga invece di essere ricalcolato sei volte.","adjusted":"{n} missione/i con inquadratura individuale.","nianticCheck":"Controlla le regole Niantic prima dell’invio: diritti sull’immagine, contenuto pertinente e nessun singolo personaggio dominante.","ready":"Pronto.","createZip":"Crea ZIP","zipAssembly":"Creazione ZIP…","zipCreated":"ZIP creato.","zipDownloaded":"ZIP scaricato.","saveShareZip":"Salva o condividi ZIP","exportFinished":"Esportazione {format} completata","exportFailed":"Esportazione non riuscita.","projectsSaved":"{n} progetto/i salvato/i su questo telefono.","unnamed":"Senza nome","opened":"Aperto","open":"Apri","rename":"Rinomina","copy":"Copia","noSavedProject":"Nessun progetto salvato.","renameProject":"Rinomina progetto","renameHint":"Un nome leggibile da un essere umano. Concetto sorprendentemente avanzato.","projectName":"Nome progetto","projectOpened":"Progetto aperto: {name}","projectRenamed":"Progetto rinominato","deleteProject":"Eliminare questo progetto?","deleteWarning":"Il banner e la sua immagine salvata localmente verranno eliminati.","copyCreated":"Copia creata","projectDeleted":"Progetto eliminato","newProjectCreated":"Nuovo progetto creato con Redacted","defaultProject":"Il mio banner","defaultNewProject":"Nuovo banner","copySuffix":"copia","versionLabel":"Versione","infoPrime":"6 colonne · 544 px · ritaglio 512 px.","infoPlanner":"azioni portale, passphrase, passaggio fine→inizio e pacchetto BannerLab nativo.","infoCompanion":"percorsi, azioni, tracciati multi-missione, opzioni e statistiche a piedi.","disclaimer":"Ingress e Ingress Prime sono marchi di Niantic. Redacted BannerLab non è affiliato né approvato da Niantic.","titleTokens":"$T = nome · $N = numero · $M = totale · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.6. Sostituisci la versione precedente in IITC Mobile. Se IITC rifiuta di sovrascriverla, rimuovi una volta il vecchio plugin e installa questo file.","pluginDialog":"Installa / aggiorna Companion 0.6.6","pluginShareFailed":"Impossibile condividere il plugin IITC.","intelOpened":"IITC Mobile aperto con il progetto BannerLab.","intelPrimeOpened":"IITC Prime aperto con il progetto BannerLab.","intelFallback":"IITC Mobile aperto. Companion userà l’ultimo stato sincronizzato.","intelPrimeFallback":"IITC Prime aperto. Companion userà l’ultimo stato sincronizzato.","intelBrowser":"IITC non rilevato: apertura nel browser.","tutorialIntro":"Costruisci l’intero banner in IITC senza tornare a BannerLab dopo ogni portale.","tut1Title":"Installa il plugin una sola volta","tut1Text":"Da Percorso, usa “Installa / aggiorna il plugin IITC”, poi aggiungi il file come plugin utente in IITC Mobile.","tut2Title":"Apri IITC da BannerLab","tut2Text":"BannerLab invia progetto, missione attiva e lingua a Companion tramite un frammento locale che il server Intel non riceve mai.","tut3Title":"Costruisci direttamente sulla mappa","tut3Text":"Companion permette di aggiungere, modificare o rimuovere portali, cambiare missione e visualizzare i percorsi senza tornare a BannerLab.","tut4Title":"Sincronizza quando hai finito","tut4Text":"“Sincronizza BannerLab” rimanda al progetto tutte le missioni modificate e riapre BannerLab.","tutNote":"Puoi spostare e ridimensionare Companion e conservare le sue impostazioni in Opzioni.","installUpdate":"Installa / aggiorna","emptyTitleIssue":"Missione {n}: titolo vuoto","emptyDescIssue":"Missione {n}: descrizione vuota","portalsIssue":"Missione {n}: {count}/{need} portali","missingGuidIssue":"Missione {n}: {count} GUID mancante/i","passIssue":"Missione {n}: {count} passphrase incompleta/e","reviewCount":"{n} elemento/i da verificare","projectReady":"Progetto BannerLab pronto","fixBeforePublish":"Correggi questi elementi prima di pubblicare.","publisherDesc":"Il prossimo ponte compilerà il Mission Authoring Tool direttamente da questo formato nativo. L’invio finale resterà volutamente nell’strumento ufficiale.","packCreating":"Creazione pacchetto BannerLab…","packCreated":"Pacchetto BannerLab creato","exportImpossible":"Esportazione impossibile: {error}","missionResetDone":"Missione {n} reimpostata","textDeleted":"Testo eliminato","histImport":"Importa immagine","histMissionZoom":"Zoom missione","histMissionRotation":"Rotazione missione","histTextRotation":"Rotazione testo","histImageRotation":"Rotazione immagine","histTextZoom":"Zoom testo","histImageZoom":"Zoom immagine","histCenterText":"Centra testo","histCenterImage":"Centra immagine","histResetText":"Reimposta testo","histResetImage":"Reimposta immagine","histResetMission":"Reimposta missione","histDeleteText":"Elimina testo","histAddText":"Aggiungi testo","histEditText":"Modifica testo","routeActionHelp":"Hack / Mod / Cattura / Link / Campo / Passphrase direttamente da Companion.","handoverDetail":"L’ultimo portale può diventare il primo della missione successiva senza essere considerato un duplicato non valido.","coordsMissing":"Coordinate non trovate.","coordsInvalid":"Coordinate non valide.","duplicateElsewhere":"Questo portale è già usato altrove nel banner.","missionCompleteAdded":"Missione {n} completa · {next}","portalAdded":"Portale aggiunto · missione {n}","syncOld":"Percorso sincronizzato · rilevato Companion obsoleto: installa la versione 0.6.0.","syncOk":"Percorso IITC sincronizzato · Companion {v}.","portalDefault":"Portale","bannerDefault":"Banner","livePublish":"Prepara direttamente in Mission Authoring","livePublishShort":"Publisher diretto","livePreparing":"Preparazione di {n} missioni per Publisher…","liveReady":"Apertura del Publisher integrato…","liveNativeOnly":"Publisher diretto è disponibile nell’APK Android.","liveFailed":"Impossibile aprire Publisher: {error}","liveExperimental":"Sperimentale: Mission Authoring si apre in una vista controllata da RBL. L’accesso Google è la prima cosa da verificare sul telefono.","backupTransfer":"Backup / trasferimento","exportPackBackup":"Esporta pacchetto BannerLab","openOfficialOnly":"Apri solo il sito ufficiale","publisherPreparingImage":"Rendering missione {n}/{total}…","browserPublish":"Pubblica in Firefox","browserPublishShort":"Publisher nel browser","browserSetup":"Installa / aggiorna Browser Publisher","browserPreparing":"Preparazione missione {n}/{total}…","browserOpening":"Apertura di Firefox…","browserNeed":"Publisher diretto usa Firefox Android + Violentmonkey, così l’accesso Google resta in un browser normale.","browserFailed":"Impossibile aprire Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 per missions.ingress.com. Installalo una volta in Violentmonkey su Firefox Android.","browserShareDialog":"Installa Publisher 0.4.0","browserShareFailed":"Impossibile condividere Browser Publisher.","publisherUrlTooLarge":"Questa missione è troppo grande per essere inviata al browser.","publisherReturn":"Ritorno da Publisher.","publisherNoFirefox":"Firefox non è stato rilevato. Apertura del browser predefinito, ma Publisher richiede un browser con supporto userscript.","publisherBrowser":"Browser di pubblicazione","chromeMode":"Chrome","chromeModeSub":"Nessuna app aggiuntiva · piccolo segnalibro + Consenti quando richiesto","firefoxMode":"Firefox","firefoxModeSub":"Automatico dopo l’installazione di Violentmonkey + Publisher","recommendedAuto":"Automatico","noExtraApp":"Nessuna app aggiuntiva","publishSelected":"Pubblica missione","chromeSetup":"Configura Chrome","firefoxSetup":"Configura Firefox","chromeReady":"Segnalibro Chrome verificato","firefoxReady":"Firefox Publisher verificato","notConfigured":"Configurazione iniziale richiesta","chromeSetupTitle":"Chrome Publisher","chromeSetupIntro":"Chrome non permette a RBL di aggiungere il segnalibro al posto tuo. La configurazione è quindi ridotta al minimo possibile.","chromeStep1":"1. Copia il codice del segnalibro RBL Publisher.","chromeStep2":"2. Apri Mission Authoring in Chrome e aggiungi la pagina ai segnalibri.","chromeStep3":"3. Modifica il segnalibro: chiamalo “RBL Publisher” e sostituisci il suo URL con il codice copiato.","chromeStep4":"4. In Mission Authoring, tocca la barra degli indirizzi, digita “RBL”, poi scegli il segnalibro per provarlo.","copyBookmarklet":"Copia codice segnalibro","bookmarkletCopied":"Codice segnalibro copiato","openChromeSetup":"Apri Chrome per la configurazione","testChrome":"Prova segnalibro Chrome","chromeRunHint":"In Chrome: tocca la barra degli indirizzi, digita RBL, poi seleziona “RBL Publisher”.","chromeNeedsSetup":"Configura prima il segnalibro Chrome RBL Publisher.","chromeOpenFail":"Impossibile aprire Chrome. Apertura del browser predefinito.","firefoxSetupTitle":"Firefox Publisher","firefoxSetupIntro":"Firefox può caricare Publisher automaticamente tramite Violentmonkey. È la modalità più fluida.","sharePublisher":"Condividi userscript Publisher","testFirefox":"Prova Firefox Publisher","firefoxNeedsSetup":"Installa Violentmonkey e Publisher in Firefox prima di provarlo.","browserSaved":"Browser di pubblicazione: {browser}","setupConfirmed":"Configurazione verificata.","bookmarkletCopyFail":"Impossibile copiare automaticamente. Il codice è mostrato qui sotto.","bookmarkletLabel":"Codice segnalibro","autoImpossibleChrome":"Il caricamento automatico non è possibile in Chrome Android senza un’estensione o un’autorizzazione invasiva. Il segnalibro resta necessario.","openChromePublish":"Apertura di Chrome…","openFirefoxPublish":"Apertura di Firefox…","chromeWizardTitle":"Configura Chrome","chromeWizardIntro":"Configurazione una tantum. RBL ricorda i tuoi progressi.","chromeFileTitle":"Salva Publisher","chromeFileText":"RBL salva Publisher direttamente in Documents/RedactedBannerLab. Non serve il pannello di condivisione Android.","chromeSaveFile":"Salva Publisher","chromeFileDone":"Publisher salvato","alreadySaved":"L’ho già salvato","chromeBookmarkTitle":"Crea il mini segnalibro","chromeBookmarkText":"Il segnalibro non contiene più l’intero Publisher. È lungo solo {n} caratteri e carica il file appena salvato.","chromeBookmarkName":"Nome segnalibro: RBL Publisher","chromeBookmarkHow":"In Chrome: apri Mission Authoring → ⋮ → Aggiungi ai segnalibri. Poi modifica il segnalibro, chiamalo “RBL Publisher” e incolla il codice nel campo URL.","copyMiniCode":"Copia mini codice","miniCodeCopied":"Mini codice copiato","openChromeBookmark":"Apri Mission Authoring","bookmarkCreated":"Ho creato il segnalibro","chromeTestTitle":"Prova e autorizza","chromeTestText":"RBL apre Mission Authoring. Digita RBL ed esegui il segnalibro. Chrome chiede Publisher, poi il JSON corrente. Il JSON viene richiesto per ogni nuovo banner, mai tra una missione e l’altra.","chromeTestButton":"Prova in Chrome","chromeTestWaiting":"In Chrome: digita RBL → RBL Publisher → seleziona publisher.js se richiesto → Consenti.","chromeSetupSuccess":"Chrome è pronto","chromeSetupSuccessText":"Chrome è pronto. Publisher resta memorizzato; il JSON del banner viene selezionato esplicitamente per ogni nuova sessione, così i vecchi progetti non possono essere riutilizzati di nascosto.","publishNow":"Pubblica ora","wizardPrev":"Precedente","wizardNext":"Continua","wizardRestart":"Ricomincia configurazione","stepOf":"Passaggio {n}/3","chromeFileShareText":"Salva questo publisher.js in un posto facile da trovare, per esempio Download. Chrome lo chiederà durante il primo test.","chromeFileShareDialog":"Salva RBL Publisher","chromeFileShareFail":"Impossibile preparare il file Publisher.","chromePermissionHint":"Chrome potrebbe chiedere di nuovo il permesso di leggere publisher.js. Puoi semplicemente consentirlo.","chromeNotAutoFavorite":"RBL non può creare automaticamente un segnalibro Chrome. Questo è l’unico passaggio manuale obbligatorio.","codeLength":"{n} caratteri","chromeStepSaved":"Passaggio salvato","chromeResetDone":"Configurazione Chrome reimpostata","chromeSelectFileHint":"In Chrome seleziona: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","bannerDescription":"Descrizione banner","required":"Obbligatorio","bannerDescriptionHint":"Questa è la descrizione predefinita per ogni missione. Potrai comunque personalizzare le singole missioni in seguito.","bannerDescriptionRequired":"La descrizione del banner è obbligatoria.","describeBeforePublish":"Descrivi prima il banner","describeBeforePublishText":"La pubblicazione è bloccata finché il banner non ha una descrizione. Verrà usata come valore predefinito per tutte le missioni.","saveAndContinue":"Salva e continua","missionPublishBlocked":"La missione non può essere pubblicata","missionNeedsPortals":"La missione {n} ha {count}/{need} portali. Ne servono almeno {need} prima della pubblicazione.","completeMission":"Completa missione","currentMissionReady":"Missione pronta per la pubblicazione","publishBlockedHint":"La pubblicazione resta bloccata finché tutti gli elementi obbligatori non sono completi.","minimumSix":"Minimo: 6 portali per missione","publisherDescRequired":"Publisher rifiuta le missioni senza descrizione.","publisherPortalsRequired":"Publisher rifiuta le missioni con meno di 6 portali.","playBanners":"Trova un banner","playHub":"Trova un banner","searchPlaceholder":"Nome o parola chiave","favorites":"Preferiti","currentBanner":"Riprendi","noFavorites":"Nessun banner preferito. La memoria locale si sta godendo una pace sospetta.","noPlaySession":"Nessun banner attualmente in corso.","searchPrompt":"Cerca per nome e/o area geografica, con un vero limite di distanza.","searchError":"Ricerca Bannergress non riuscita: {error}","missionsCount":"{n} missioni","distanceKm":"{n} km","favorite":"Preferito","removeFavorite":"Rimuovi dai preferiti","playThisBanner":"Avvia questo banner","resumeBanner":"Riprendi questo banner","stopBanner":"Ferma overlay","openCurrentMission":"Apri missione corrente","overlayPermissionTitle":"Consenti overlay RBL","overlayPermissionText":"Android deve consentire a Redacted BannerLab di apparire sopra Ingress. Un solo permesso di sistema, poi il dinosauro può tornare a farsi gli affari suoi.","overlayPermissionButton":"Consenti visualizzazione sopra altre app","overlayPermissionWaiting":"Torna a RBL dopo aver concesso il permesso.","overlayStarted":"Overlay missione avviato.","overlayFailed":"Impossibile avviare l’overlay: {error}","bannerLoadError":"Impossibile caricare questo banner: {error}","bannerOffline":"Questo banner non contiene missioni utilizzabili.","bannerDisabled":"{n} missione/i disabilitata/e","addressUnknown":"Posizione non specificata","doneMissions":"{done}/{total} completate","deepLinkOnly":"RBL non controlla Ingress: l’overlay apre solo i deep link ufficiali delle missioni.","bannergressCredit":"Ricerca tramite Bannergress","publisherWholeBanner":"Prepara l’intero banner","publisherWholeHint":"Una sola sessione browser: tutte le missioni e le immagini vengono preparate insieme.","publisherAllRequired":"Ogni missione deve essere completa prima di avviare la sessione di pubblicazione.","publisherSessionCreating":"Preparazione sessione Publisher {n}/{total}…","publisherSessionReady":"Sessione salvata in Documents/RedactedBannerLab. Apertura di Mission Authoring…","publisherSessionFileText":"RBL salva automaticamente la sessione in Documents/RedactedBannerLab.","publisherSessionDialog":"Sessione Publisher","publisherSessionShareFail":"Impossibile preparare la sessione Publisher.","chromeSessionHint":"Chrome: esegui il segnalibro RBL Publisher. Per ogni nuovo banner preparato, Chrome chiederà esplicitamente RBL_Current_Session.rblpub.json. Non serve altro tra una missione e l’altra.","firefoxSessionHint":"Firefox: Publisher si apre automaticamente. Carica RBL_Current_Session.rblpub.json se la sessione corrente non è già nota.","easterEgg":"L’hai chiesto tu.","authorSearch":"Autore","authorPlaceholder":"es. AgentName","nearMeOn":"La mia posizione è attiva","locationError":"Impossibile ottenere la posizione: {error}","searchCriteriaRequired":"Inserisci almeno un criterio di ricerca.","cityResolving":"Ricerca città…","cityNotFound":"Nessun luogo Bannergress trovato per “{city}”.","cityUsing":"Luogo utilizzato: {city}","bannerAuthor":"Autore: {author}","overlayDrag":"≡  Sposta","overlayMinimize":"Riduci","overlayClose":"Chiudi","overlayMoved":"Posizione overlay salvata","resultsCount":"{n} risultato/i","searchFilters":"Filtri attivi","allPublicBanners":"Banner pubblici Bannergress","cityNoCoordinates":"“{city}” è stata trovata, ma la sua posizione non può essere utilizzata.","cityUsingRadius":"Utilizzo: {city} · raggio {radius} km","radiusResults":"{n} risultato/i entro {radius} km","distanceFromPoint":"A {distance} di distanza","publisherCurrentFile":"File corrente: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher salvato in Documents/RedactedBannerLab.","chromeFileWriteFail":"Impossibile scrivere Publisher in Documents/RedactedBannerLab.","chromeCurrentSessionHint":"Per ogni nuovo banner: scegli Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json.","browserResume":"Sessione preparata. Apertura della scheda RBL Mission Authoring…","chromeResumeHint":"Chrome riutilizza ora la stessa scheda Mission Authoring riservata a RBL.","firefoxResumeHint":"Apertura di Mission Authoring nel browser di pubblicazione.","browserResumeFallback":"Impossibile riutilizzare la scheda RBL. Apertura del browser come ripiego.","publisherAutoRefresh":"Publisher ora controlla il file della sessione corrente e ricarica automaticamente un nuovo banner preparato.","flowLocked":"Modifica banner bloccata","flowLockedText":"È attivo il passaggio {step}. Seleziona “1 Banner” per modificare immagine, testo o inquadratura.","returnFresco":"Seleziona 1 Banner per modificare","flowLockedToast":"Torna al passaggio 1 Banner per modificare il banner.","publisherTabReuse":"RBL usa un ID applicazione browser stabile per riutilizzare la stessa scheda.","todo":"Da fare","history":"Cronologia","inProgress":"In corso","addTodo":"Aggiungi a Da fare","removeTodo":"Rimuovi da Da fare","noTodo":"Nessun banner da fare. Quasi sospettosamente ragionevole.","noHistory":"Nessun banner giocato finora. Il dinosauro si annoia.","bannerMap":"Mappa del percorso","openMap":"Visualizza mappa","navigateStart":"Naviga verso la partenza","startUnavailable":"Punto di partenza non disponibile.","mapUnavailable":"Bannergress non fornisce coordinate utilizzabili per questo banner.","startPoint":"Partenza","missionStart":"Missione {n}","shareGroup":"Condividi / gruppo","shareProgress":"Condividi avanzamento","shareBanner":"Condividi banner","shareIntro":"Il QR apre RBL sullo stesso banner e sullo stesso numero di missione. Non viene usato alcun account Bannergress.","copyLink":"Copia link RBL","linkCopied":"Link RBL copiato","shareNow":"Condividi","bannergressPage":"Apri su Bannergress","joinBanner":"Unisciti al banner","joinAtMission":"Unisciti alla missione {n}","sharedBannerLoaded":"Banner condiviso caricato · missione {n}","sharedBannerError":"Impossibile caricare il banner condiviso: {error}","playStats":"Statistiche sessione","startedAt":"Iniziato","finishedAt":"Terminato","elapsed":"Tempo attivo","estimatedDistance":"Distanza stimata","missionsDone":"Missioni completate","paused":"In pausa","playing":"In corso","completedBanner":"Completato","replayBanner":"Gioca di nuovo","resumeFromHistory":"Riprendi","groupNoServer":"Modalità gruppo senza server: condividi di nuovo il QR/link se il gruppo passa a un’altra missione.","publicOnly":"Solo ricerca/dati pubblici Bannergress · nessun accesso richiesto.","routePoints":"{n} punti del percorso","uselessStats":"Statistiche inutili","loadingStats":"Calcolo di cose che nessuno ha chiesto…","statsUnavailable":"Coordinate insufficienti per calcolare le statistiche inutili.","bgDistance":"Distanza Bannergress","calculatedTrack":"Distanza a piedi stimata","walkingEstimate":"Tempo a piedi stimato","routeSteps":"Passi","uniquePlaces":"Luoghi unici","revisitedPlaces":"Visite ripetute","stepsPerKm":"Passi / km","avgMissionDistance":"Media / missione","longestMission":"Missione più lunga","longestLeg":"Tratto più lungo","betweenMissions":"Transizioni tra missioni","detourFactor":"Fattore di deviazione","routeCoverage":"Copertura mappa","missionShort":"M{n}","straightLine":"Partenza → arrivo","funStatsDisclaimer":"RBL calcola ogni tratto da portale a portale sulla rete pedonale OpenStreetMap. Ogni tratto viene controllato: scorciatoie impossibili o deviazioni chiaramente assurde vengono sostituite, solo per quel tratto, dalla distanza diretta. È una stima a piedi, non una misurazione GPS.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Statistiche inutili","hideUselessStats":"Nascondi statistiche","statsLoaded":"Statistiche calcolate","directGeometric":"Distanza diretta cumulativa","routingDetour":"Rapporto rete / diretto","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla non disponibile · stima geometrica","routingLoading":"Calcolo del percorso pedonale reale…","routingFailed":"Routing pedonale non disponibile, usate statistiche geometriche.","routingNative":"Valhalla + OSM · controllo per tratto","routingWeb":"Valhalla + OSM · controllo per tratto","routingErrorDetail":"Errore Valhalla: {error}","ingressRadius":"Raggio Ingress","ingressRadiusValue":"40 m","correctedLegs":"Tratti corretti","rawValhalla":"Valhalla grezzo","creditsTitle":"Crediti e ringraziamenti","bannergressThanks":"Grazie Bannergress","bannergressThanksText":"La ricerca dei banner e diversi dettagli pubblici mostrati in Redacted BannerLab si basano sui dati pubblici di Bannergress. Grazie al loro team e ai collaboratori per l’enorme lavoro svolto intorno ai banner Ingress.","bannergressNoLogin":"RBL non usa un account Bannergress: utilizza solo i dati pubblici necessari alla ricerca e alla visualizzazione dei banner.","independentProject":"Redacted BannerLab è un progetto indipendente e non è affiliato né approvato da Bannergress o dai servizi ufficiali Ingress.","visitBannergress":"Visita Bannergress","mapCredits":"Mappe e routing","mapCreditsText":"Le mappe usano dati OpenStreetMap. Le stime dei percorsi pedonali usano il motore di routing Valhalla.","rblCreditsFoot":"Grazie a tutti gli strumenti e ai collaboratori che rendono possibile questo ecosistema di missioni Ingress.","backgroundLayer":"Sfondo principale","layerName":"Livello immagine","selected":"Selezionato","visibleLayer":"Visibile","hiddenLayer":"Nascosto","moveUp":"Sposta su","moveDown":"Sposta giù","groupSelection":"Seleziona per gruppo","ungroup":"Separa gruppo","groupNeedTwo":"Seleziona almeno due livelli da raggruppare.","groupCreated":"Livelli raggruppati","groupRemoved":"Gruppo rimosso","deleteLayer":"Elimina livello","layerDeleted":"Livello eliminato","layerAdded":"Livello aggiunto","backgroundReplaced":"Sfondo sostituito","backgroundMissing":"Nessuno sfondo principale","backgroundFixed":"Lo sfondo resta sempre sotto gli altri livelli.","groupHint":"Seleziona più livelli, poi tocca Raggruppa. Un gruppo si sposta, si ingrandisce e ruota insieme.","layerOrder":"Ordine livelli","layerTransform":"Trasforma livello","groupTransform":"Trasforma gruppo","renameLayer":"Rinomina","duplicateLayer":"Duplica","layerDuplicated":"Livello duplicato","histAddLayer":"Aggiungi livello","histDeleteLayer":"Elimina livello","histReorderLayer":"Riordina livello","histGroupLayers":"Raggruppa livelli","histUngroupLayers":"Separa livelli","histVisibilityLayer":"Visibilità livello","histRenameLayer":"Rinomina livello","histDuplicateLayer":"Duplica livello","layerGroupBadge":"Gruppo","layerUngroup":"Separa questo gruppo","layerSelectHint":"Il livello selezionato può poi essere spostato direttamente sul banner.","layerDimensions":"{w} × {h} px","noImageContent":"Aggiungi almeno un’immagine prima di esportare.","groupRelative":"I controlli qui sotto trasformano l’intero gruppo insieme.","groupZoom":"Zoom gruppo","groupRotation":"Rotazione gruppo","allLayersTitle":"Livelli","allLayersDesc":"Seleziona l’elemento che vuoi manipolare. Immagini e testo restano modificabili dai rispettivi menu.","imageLayersSection":"Immagini","textLayersSection":"Testo","noExtraImageLayer":"Nessun livello immagine aggiuntivo","noTextLayer":"Nessun livello di testo","selectLayer":"Seleziona","editLayer":"Modifica","missionNumberQuestion":"Qual è il numero della missione?","groupName":"Gruppo {n}","groupCount":"{n} livello/i","creatorBy":"Creato da Zw4nn","diagnosticCopyFailed":"Impossibile copiare la diagnostica","diagnosticDescription":"Descrizione del problema:","projectImportInvalid":"Questo file non è un progetto Redacted BannerLab valido.","projectShareTitle":"Progetto Redacted BannerLab","projectImportHint":"Il progetto importato viene aggiunto senza modificare gli altri progetti.","backupText":"Salva tutti i progetti, le impostazioni e le immagini di BannerLab in un unico file JSON portatile.","backupFolder":"Cartella di backup","backupFolderChoose":"Scegli cartella","backupFolderChange":"Cambia cartella","backupFolderNone":"Nessuna cartella selezionata","backupFolderReady":"Cartella configurata","backupAuto":"Backup automatico in background","backupAutoHint":"Quando è attivo, BannerLab prepara regolarmente il backup dopo le modifiche e forza un salvataggio finale quando passa in background.","backupWorking":"Creazione backup…","backupSaved":"Backup completato","backupAutoSaved":"Backup automatico completato","backupFailed":"Backup non riuscito: {error}","backupNeedFolder":"Scegli prima una cartella di backup.","backupFolderError":"Impossibile usare questa cartella.","backupImported":"Backup ripristinato","backupInvalid":"Questo file non è un backup Redacted BannerLab valido.","backupImportTitle":"Ripristina backup","backupImportText":"{n} progetto/i trovato/i · backup del {date}","backupMerge":"Unisci","backupReplace":"Sostituisci tutto","backupReplaceWarn":"Sostituisci tutto elimina i progetti attualmente salvati su questo dispositivo prima del ripristino.","backupCancel":"Annulla","backupLast":"Ultimo backup: {date}","backupNever":"Nessun backup ancora","backupPortable":"Il JSON contiene anche le immagini. Può quindi essere grande, ma è completamente autosufficiente.","backupNativeOnly":"Il backup automatico in una cartella è disponibile su Android. L’esportazione/importazione JSON resta disponibile ovunque.","backupFolderChosen":"Cartella di backup salvata","backupNoChanges":"Nessuna modifica da salvare nel backup.","studioEdit":"Modifica a schermo intero","studioFit":"6 missioni","studioFitOne":"1 missione","studioFitAll":"Tutte","studioFrescoMode":"Banner","studioRotateHint":"6 missioni in verticale · le righe successive scorrono verso destra.","studioSelected":"Elemento selezionato","studioNoLayer":"Seleziona un livello o un elemento di testo dal pannello laterale.","studioGroupSelect":"Selezione gruppo","studioGroupNow":"Raggruppa","studioOpenFull":"Apri gestione completa","studioOpacity":"Opacità","studioClose":"Esci dallo studio","studioAddText":"Aggiungi testo","studioNoText":"Nessun testo per ora.","studioEditText":"Modifica testo","studioDuplicateText":"Duplica testo","font":"Font","fontImported":"Font importato: {name}","fontInvalid":"Questo font non è supportato.","fontTooLarge":"Il font è troppo grande (massimo 12 MB).","textBackground":"Sfondo del testo","textBackgroundColor":"Colore sfondo","textBackgroundOpacity":"Opacità sfondo","textBackgroundPadding":"Spaziatura interna sfondo","textBackgroundRadius":"Raggio angoli","tutorialOpen":"Visualizza tutorial","tutorialDone":"Tutorial completato","tutorialSeen":"Visto","importRolesHint":"Sfondo principale = immagine di base del banner · Livello = immagine aggiuntiva sovrapposta.","tutProjectTitle":"I tuoi progetti","tutProjectText":"Ogni banner vive nel proprio progetto. Puoi esportarlo o condividerlo senza trascinarti dietro tutti gli altri progetti.","tutNameTitle":"Nome progetto","tutNameText":"Dai al tuo banner un nome riconoscibile.","tutRowsTitle":"Numero di righe","tutRowsText":"Una riga contiene 6 missioni. Scegli qui l’altezza finale del banner.","tutImageTitle":"Immagini e livelli","tutImageText":"Importa qui lo sfondo principale e le immagini aggiuntive. Questa stessa schermata permette anche di selezionare, ordinare, nascondere e raggruppare i livelli immagine.","tutBackgroundTitle":"Sfondo principale","tutBackgroundText":"Per la prima vera immagine usa Sfondo principale. Sostituisce l’immagine di base e copre il banner.","tutExtraLayerTitle":"Aggiungi un livello","tutExtraLayerText":"Una seconda immagine è un livello: si trova sopra lo sfondo e resta spostabile, ridimensionabile e nascondibile.","tutLayersTitle":"Gestisci i livelli immagine","tutLayersText":"Le miniature mostrano quale livello immagine stai manipolando. Selezionalo, riordinalo, nascondilo oppure seleziona più immagini per raggrupparle.","tutTextTitle":"Testo","tutTextText":"Aggiungi testo, scegli font, spaziatura, sfondo, raggio oppure importa un tuo font.","tutPreviewTitle":"Anteprima","tutPreviewText":"Controlla ogni missione prima dell’esportazione. L’inquadratura individuale è già applicata.","tutExportTitle":"Esportazione","tutExportText":"Quando è tutto pronto, BannerLab crea le immagini missione da 512 × 512 nell’ordine corretto.","tutStudioTitle":"Studio a schermo intero","tutStudioText":"Un editor a schermo intero più comodo, con controlli laterali e ampie aree touch.","tutFlowTitle":"I 4 passaggi","tutFlowText":"Banner → Percorso → Missioni → Pubblica. BannerLab segue questo flusso.","tutRouteTitle":"Percorso","tutRouteText":"Il percorso collega le missioni ai veri portali Ingress. IITC Companion si occupa del lavoro sulla mappa.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion porta in IITC il progetto attivo, la missione, i portali, le azioni e le statistiche a piedi.","tutInstallCompanionTitle":"Installa Companion","tutInstallCompanionText":"Installa o aggiorna lo userscript una sola volta in IITC Mobile.","tutOpenIitcTitle":"Apri IITC","tutOpenIitcText":"Apri IITC da BannerLab affinché progetto e missione attiva vengano passati a Companion.","tutAutoRouteTitle":"Passare da una missione all’altra","tutAutoRouteText":"La missione successiva può aprirsi automaticamente e riutilizzare l’ultimo portale della precedente come primo portale.","tutPortalListTitle":"I tuoi portali","tutPortalListText":"I portali tornano con GUID, coordinate, ordine e azione, così il percorso può essere ricostruito.","tutMissionsTitle":"Prepara le missioni","tutMissionsText":"Prima di pubblicare, inserisci la descrizione comune e controlla ogni missione.","tutMissionDescTitle":"Descrizione obbligatoria","tutMissionDescText":"BannerLab segnala le informazioni mancanti prima di consentire la pubblicazione.","tutPublishTitle":"Pubblica","tutPublishText":"Quando percorsi e descrizioni sono pronti, continua qui. L’invio finale resta nello strumento ufficiale.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab prepara i dati delle missioni e il flusso di pubblicazione. Dopo l’invio, usa “Ho inviato” per verificare lo stato pubblicato.","tutBackupTitle":"Backup completo","tutBackupText":"Il JSON completo include tutti i progetti, le impostazioni, le immagini e i font. Android può anche usare una cartella di backup automatico.","tutPortableTitle":"Progetto portatile","tutPortableText":"Esporta, condividi o importa un banner con immagini, testo, font, missioni e percorso.","addMissionLayer":"Su una missione","importMissionSeries":"Importa una serie","missionLayer":"Livello missione","globalLayer":"Livello globale","missionBadge":"M{n}","missionLayerHint":"Questo livello resta collegato alla missione {n} e viene ritagliato automaticamente alla sua casella.","missionSeriesTitle":"Importa una serie di missioni","missionSeriesText":"Assegna ogni immagine a una missione. BannerLab le posiziona e le ritaglia automaticamente.","missionSeriesDetected":"{n} immagine/i rilevata/e","missionSeriesImport":"Importa livelli","missionSeriesTooMany":"Hai selezionato più immagini che missioni. È possibile assegnare più immagini alla stessa missione.","missionLayerAdded":"Immagine aggiunta alla missione {n}","missionSeriesAdded":"{n} livello/i missione aggiunto/i","missionScopeMismatch":"I livelli missione possono essere raggruppati solo se appartengono alla stessa missione.","missionLayerTutorialTitle":"Livelli collegati alle missioni","missionLayerTutorialText":"Tocca “Aggiungi un livello”, poi scegli: intero banner, una missione o più missioni. Per una missione, BannerLab posiziona e ritaglia automaticamente l’immagine nella sua casella. Per più missioni, importa una serie e assegna ogni immagine alla missione desiderata.","selectionActions":"Azioni selezione","bulkScopeKeep":"Mantieni ambito attuale","bulkMissionKeep":"Mantieni missioni attuali","bulkFitKeep":"Mantieni adattamento attuale","bulkVisibility":"Visibilità","bulkVisibilityKeep":"Non modificare","bulkShow":"Mostra","bulkHide":"Nascondi","bulkOpacityEnable":"Modifica opacità","applyToSelection":"Applica ai livelli selezionati","selectionUpdated":"Livelli selezionati aggiornati","selectionDeleted":"Livelli selezionati eliminati","deleteSelectionConfirm":"Eliminare definitivamente {n} livello/i selezionato/i?","selectionEmpty":"Seleziona almeno un livello.","layerScopeHelp":"Intero banner: il livello può coprire tutto il banner. Una missione: viene ritagliato automaticamente sulla missione scelta. Più missioni: importa una serie e assegna ogni immagine alla propria missione."});
// IITC Companion 0.6.6: téléchargement/enregistrement natif du plugin.
Object.assign(I18N["fr"],{pluginInstallChoiceTitle:"Installer Companion 0.6.6",pluginInstallChoiceText:"Choisis l’installation directe dans IITC Mobile ou enregistre une copie vérifiée du fichier .user.js dans Téléchargements.",pluginOpenIitc:"Ouvrir directement avec IITC",pluginOpenIitcText:"BannerLab transmet le fichier .user.js à IITC Mobile, qui ouvre directement son écran d’installation du plugin.",pluginSaveFile:"Enregistrer le fichier",pluginSaveFileText:"Enregistre une copie vérifiée de redacted-bannerlab-iitc.user.js directement dans Téléchargements.",pluginOpenedIitc:"Plugin envoyé à IITC Mobile. Confirme son installation dans IITC.",pluginOpenFailed:"IITC Mobile n’a pas pu être ouvert. Tu peux enregistrer le fichier à la place."});
Object.assign(I18N["en"],{pluginInstallChoiceTitle:"Install Companion 0.6.6",pluginInstallChoiceText:"Choose direct installation in IITC Mobile or save a verified .user.js copy to Downloads.",pluginOpenIitc:"Open directly with IITC",pluginOpenIitcText:"BannerLab sends the .user.js file to IITC Mobile, which opens its plugin installation screen directly.",pluginSaveFile:"Save the file",pluginSaveFileText:"Saves a verified copy of redacted-bannerlab-iitc.user.js directly to Downloads.",pluginOpenedIitc:"Plugin sent to IITC Mobile. Confirm its installation in IITC.",pluginOpenFailed:"IITC Mobile could not be opened. You can save the file instead."});
Object.assign(I18N["de"],{pluginInstallChoiceTitle:"Companion 0.6.6 installieren",pluginInstallChoiceText:"Wähle die direkte Installation in IITC Mobile oder speichere eine geprüfte .user.js-Kopie im Download-Ordner.",pluginOpenIitc:"Direkt mit IITC öffnen",pluginOpenIitcText:"BannerLab übergibt die .user.js-Datei an IITC Mobile, das direkt den Installationsbildschirm für das Plugin öffnet.",pluginSaveFile:"Datei speichern",pluginSaveFileText:"Speichert eine geprüfte Kopie von redacted-bannerlab-iitc.user.js direkt im Download-Ordner.",pluginOpenedIitc:"Plugin an IITC Mobile übergeben. Bestätige die Installation in IITC.",pluginOpenFailed:"IITC Mobile konnte nicht geöffnet werden. Du kannst stattdessen die Datei speichern."});
Object.assign(I18N["nl"],{pluginInstallChoiceTitle:"Companion 0.6.6 installeren",pluginInstallChoiceText:"Kies directe installatie in IITC Mobile of sla een gecontroleerde .user.js-kopie op in Downloads.",pluginOpenIitc:"Direct openen met IITC",pluginOpenIitcText:"BannerLab stuurt het .user.js-bestand naar IITC Mobile, dat meteen het installatiescherm van de plugin opent.",pluginSaveFile:"Bestand opslaan",pluginSaveFileText:"Slaat een gecontroleerde kopie van redacted-bannerlab-iitc.user.js rechtstreeks op in Downloads.",pluginOpenedIitc:"Plugin naar IITC Mobile gestuurd. Bevestig de installatie in IITC.",pluginOpenFailed:"IITC Mobile kon niet worden geopend. Je kunt het bestand in plaats daarvan opslaan."});
Object.assign(I18N["pt"],{pluginInstallChoiceTitle:"Instalar Companion 0.6.6",pluginInstallChoiceText:"Escolhe a instalação direta no IITC Mobile ou guarda uma cópia verificada do .user.js em Transferências.",pluginOpenIitc:"Abrir diretamente com IITC",pluginOpenIitcText:"O BannerLab envia o ficheiro .user.js para o IITC Mobile, que abre diretamente o ecrã de instalação do plugin.",pluginSaveFile:"Guardar o ficheiro",pluginSaveFileText:"Guarda uma cópia verificada de redacted-bannerlab-iitc.user.js diretamente em Transferências.",pluginOpenedIitc:"Plugin enviado para o IITC Mobile. Confirma a instalação no IITC.",pluginOpenFailed:"Não foi possível abrir o IITC Mobile. Podes guardar o ficheiro em alternativa."});
Object.assign(I18N["es"],{pluginInstallChoiceTitle:"Instalar Companion 0.6.6",pluginInstallChoiceText:"Elige la instalación directa en IITC Mobile o guarda una copia verificada del .user.js en Descargas.",pluginOpenIitc:"Abrir directamente con IITC",pluginOpenIitcText:"BannerLab envía el archivo .user.js a IITC Mobile, que abre directamente la pantalla de instalación del plugin.",pluginSaveFile:"Guardar el archivo",pluginSaveFileText:"Guarda una copia verificada de redacted-bannerlab-iitc.user.js directamente en Descargas.",pluginOpenedIitc:"Plugin enviado a IITC Mobile. Confirma la instalación en IITC.",pluginOpenFailed:"No se ha podido abrir IITC Mobile. Puedes guardar el archivo en su lugar."});
Object.assign(I18N["it"],{pluginInstallChoiceTitle:"Installa Companion 0.6.6",pluginInstallChoiceText:"Scegli l’installazione diretta in IITC Mobile oppure salva una copia verificata del .user.js in Download.",pluginOpenIitc:"Apri direttamente con IITC",pluginOpenIitcText:"BannerLab invia il file .user.js a IITC Mobile, che apre direttamente la schermata di installazione del plugin.",pluginSaveFile:"Salva il file",pluginSaveFileText:"Salva una copia verificata di redacted-bannerlab-iitc.user.js direttamente in Download.",pluginOpenedIitc:"Plugin inviato a IITC Mobile. Conferma l’installazione in IITC.",pluginOpenFailed:"Impossibile aprire IITC Mobile. Puoi salvare il file al suo posto."});
Object.assign(I18N["fr"],{pluginSaved:"Plugin IITC enregistré. Ouvre IITC Mobile et installe ce fichier comme plugin utilisateur.",pluginSaveFailed:"Impossible d’enregistrer le plugin IITC."});
Object.assign(I18N["en"],{pluginSaved:"IITC plugin saved. Open IITC Mobile and install this file as a user plugin.",pluginSaveFailed:"Unable to save the IITC plugin."});
Object.assign(I18N["es"],{pluginSaved:"Plugin IITC guardado. Abre IITC Mobile e instala este archivo como plugin de usuario.",pluginSaveFailed:"No se ha podido guardar el plugin IITC."});
Object.assign(I18N["pt"],{pluginSaved:"Plugin IITC guardado. Abre o IITC Mobile e instala este ficheiro como plugin de utilizador.",pluginSaveFailed:"Não foi possível guardar o plugin IITC."});
Object.assign(I18N["de"],{pluginSaved:"IITC-Plugin gespeichert. Öffne IITC Mobile und installiere diese Datei als Benutzer-Plugin.",pluginSaveFailed:"Das IITC-Plugin konnte nicht gespeichert werden."});
Object.assign(I18N["it"],{pluginSaved:"Plugin IITC salvato. Apri IITC Mobile e installa questo file come plugin utente.",pluginSaveFailed:"Impossibile salvare il plugin IITC."});
Object.assign(I18N["nl"],{pluginSaved:"IITC-plugin opgeslagen. Open IITC Mobile en installeer dit bestand als gebruikersplugin.",pluginSaveFailed:"Het IITC-plugin kon niet worden opgeslagen."});
Object.assign(I18N["pl"],{pluginSaved:"Wtyczka IITC została zapisana. Otwórz IITC Mobile i zainstaluj ten plik jako wtyczkę użytkownika.",pluginSaveFailed:"Nie udało się zapisać wtyczki IITC."});
Object.assign(I18N["cs"],{pluginSaved:"Plugin IITC byl uložen. Otevři IITC Mobile a nainstaluj tento soubor jako uživatelský plugin.",pluginSaveFailed:"Plugin IITC se nepodařilo uložit."});
Object.assign(I18N["ro"],{pluginSaved:"Pluginul IITC a fost salvat. Deschide IITC Mobile și instalează acest fișier ca plugin de utilizator.",pluginSaveFailed:"Pluginul IITC nu a putut fi salvat."});
Object.assign(I18N["tr"],{pluginSaved:"IITC eklentisi kaydedildi. IITC Mobile’ı aç ve bu dosyayı kullanıcı eklentisi olarak yükle.",pluginSaveFailed:"IITC eklentisi kaydedilemedi."});
Object.assign(I18N["ru"],{pluginSaved:"Плагин IITC сохранён. Открой IITC Mobile и установи этот файл как пользовательский плагин.",pluginSaveFailed:"Не удалось сохранить плагин IITC."});
Object.assign(I18N["uk"],{pluginSaved:"Плагін IITC збережено. Відкрий IITC Mobile та встанови цей файл як користувацький плагін.",pluginSaveFailed:"Не вдалося зберегти плагін IITC."});
Object.assign(I18N["ja"],{pluginSaved:"IITCプラグインを保存しました。IITC Mobileを開き、このファイルをユーザープラグインとしてインストールしてください。",pluginSaveFailed:"IITCプラグインを保存できませんでした。"});
Object.assign(I18N["ko"],{pluginSaved:"IITC 플러그인을 저장했습니다. IITC Mobile을 열고 이 파일을 사용자 플러그인으로 설치하세요.",pluginSaveFailed:"IITC 플러그인을 저장하지 못했습니다."});
Object.assign(I18N["zh-Hans"],{pluginSaved:"IITC 插件已保存。打开 IITC Mobile，并将此文件安装为用户插件。",pluginSaveFailed:"无法保存 IITC 插件。"});
Object.assign(I18N["zh-Hant"],{pluginSaved:"IITC 外掛已儲存。開啟 IITC Mobile，並將此檔案安裝為使用者外掛。",pluginSaveFailed:"無法儲存 IITC 外掛。"});
Object.assign(I18N["yue"],{pluginSaved:"IITC 外掛已經儲存。打開 IITC Mobile，將呢個檔案安裝做使用者外掛。",pluginSaveFailed:"儲存唔到 IITC 外掛。"});
Object.assign(I18N["ar"],{pluginSaved:"تم حفظ إضافة IITC. افتح IITC Mobile وثبّت هذا الملف كإضافة مستخدم.",pluginSaveFailed:"تعذّر حفظ إضافة IITC."});
Object.assign(I18N["id"],{pluginSaved:"Plugin IITC disimpan. Buka IITC Mobile lalu pasang file ini sebagai plugin pengguna.",pluginSaveFailed:"Plugin IITC tidak dapat disimpan."});

// Chaînes utilisées hors des écrans principaux : éviter les textes codés en dur lors des exports et diagnostics.
Object.assign(I18N.fr,{close:'Fermer'});
Object.assign(I18N.en,{close:'Close'});
Object.assign(I18N.es,{close:'Cerrar'});
Object.assign(I18N.pt,{close:'Fechar'});
Object.assign(I18N.de,{close:'Schließen'});
Object.assign(I18N.nl,{close:'Sluiten'});
Object.assign(I18N.it,{close:'Chiudi'});
Object.assign(I18N.fr,{missionLabel:'Mission {n}',syncUnreadable:'Synchronisation IITC illisible.',canvasExportFailed:'Export du canvas impossible.',projectSaveFailed:'Impossible d’enregistrer le projet.',platformLabel:'Plateforme',orderRowsLine:'{rows} rangée(s) · {missions} missions',orderTitle:'Ordre de création :',orderItem:'{file} : rangée {row} depuis le haut, colonne {col} depuis la gauche{adjusted}',orderAdjusted:' · recadrage individuel'});
Object.assign(I18N.en,{missionLabel:'Mission {n}',syncUnreadable:'IITC synchronization data could not be read.',canvasExportFailed:'Canvas export failed.',projectSaveFailed:'Unable to save the project.',platformLabel:'Platform',orderRowsLine:'{rows} row(s) · {missions} missions',orderTitle:'Creation order:',orderItem:'{file}: row {row} from the top, column {col} from the left{adjusted}',orderAdjusted:' · individual framing'});
Object.assign(I18N.es,{missionLabel:'Misión {n}',syncUnreadable:'No se pueden leer los datos de sincronización de IITC.',canvasExportFailed:'No se ha podido exportar el lienzo.',projectSaveFailed:'No se ha podido guardar el proyecto.',platformLabel:'Plataforma',orderRowsLine:'{rows} fila(s) · {missions} misiones',orderTitle:'Orden de creación:',orderItem:'{file}: fila {row} desde arriba, columna {col} desde la izquierda{adjusted}',orderAdjusted:' · encuadre individual'});
Object.assign(I18N.pt,{missionLabel:'Missão {n}',syncUnreadable:'Não foi possível ler os dados de sincronização do IITC.',canvasExportFailed:'Não foi possível exportar a tela.',projectSaveFailed:'Não foi possível guardar o projeto.',platformLabel:'Plataforma',orderRowsLine:'{rows} linha(s) · {missions} missões',orderTitle:'Ordem de criação:',orderItem:'{file}: linha {row} a partir do topo, coluna {col} a partir da esquerda{adjusted}',orderAdjusted:' · enquadramento individual'});
Object.assign(I18N.de,{missionLabel:'Mission {n}',syncUnreadable:'Die IITC-Synchronisationsdaten konnten nicht gelesen werden.',canvasExportFailed:'Canvas-Export fehlgeschlagen.',projectSaveFailed:'Projekt konnte nicht gespeichert werden.',platformLabel:'Plattform',orderRowsLine:'{rows} Reihe(n) · {missions} Missionen',orderTitle:'Erstellungsreihenfolge:',orderItem:'{file}: Reihe {row} von oben, Spalte {col} von links{adjusted}',orderAdjusted:' · individueller Ausschnitt'});
Object.assign(I18N.nl,{missionLabel:'Missie {n}',syncUnreadable:'De IITC-synchronisatiegegevens konden niet worden gelezen.',canvasExportFailed:'Canvas exporteren is mislukt.',projectSaveFailed:'Het project kon niet worden opgeslagen.',platformLabel:'Platform',orderRowsLine:'{rows} rij(en) · {missions} missies',orderTitle:'Aanmaakvolgorde:',orderItem:'{file}: rij {row} vanaf boven, kolom {col} vanaf links{adjusted}',orderAdjusted:' · individuele uitsnede'});
Object.assign(I18N.it,{missionLabel:'Missione {n}',syncUnreadable:'Impossibile leggere i dati di sincronizzazione IITC.',canvasExportFailed:'Esportazione canvas non riuscita.',projectSaveFailed:'Impossibile salvare il progetto.',platformLabel:'Piattaforma',orderRowsLine:'{rows} riga/he · {missions} missioni',orderTitle:'Ordine di creazione:',orderItem:'{file}: riga {row} dall’alto, colonna {col} da sinistra{adjusted}',orderAdjusted:' · inquadratura individuale'});
function tr(key,vars={}){
  let s=(I18N[APP_LANG]&&I18N[APP_LANG][key])||I18N.en[key]||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))s=s.replaceAll('{'+k+'}',String(v));
  return s;
}
function setAppLanguage(lang){
  if(!SUPPORTED_LANGS.includes(lang))return;
  localStorage.setItem('rbl-language',lang);
  location.reload();
}
function applyLanguageDirection(){document.documentElement.lang=APP_LANG;document.documentElement.dir=LANG_META[APP_LANG]?.rtl?'rtl':'ltr'}
applyLanguageDirection();

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  projectLanguage: APP_LANG,
  name: tr('defaultProject'),
  rows: 3,
  showGrid: true,
  showCircles: true,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0, visible:true, name:'' },
  imageLayers: [],
  texts: [],
  customFonts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    reuseLastPortal: true,
    currentMission: 0,
    missions: []
  }
};

let activeFlow = 'fresco';
let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;
let historyUndo = [];
let historyRedo = [];
let historyBusy = false;
const HISTORY_LIMIT = 80;

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function snapshotState(){
  const data=serializeState();
  delete data.updatedAt;delete data.customFonts;
  return {
    data:deepClone(data),
    blob:state.bg.blob,
    image:state.bg.image,
    layerMedia:state.imageLayers.map(l=>({id:l.id,blob:l.blob,image:l.image})),
    active:state.active
  };
}
function snapshotsEqual(a,b){
  if(!a||!b||a.blob!==b.blob||a.image!==b.image||a.active!==b.active||JSON.stringify(a.data)!==JSON.stringify(b.data))return false;
  const am=a.layerMedia||[],bm=b.layerMedia||[];
  return am.length===bm.length&&am.every((x,i)=>x.id===bm[i]?.id&&x.blob===bm[i]?.blob&&x.image===bm[i]?.image);
}
function beginHistory(){return historyBusy?null:snapshotState()}
function commitHistory(before,label='Modification'){
  if(historyBusy||!before)return;
  const after=snapshotState();
  if(snapshotsEqual(before,after))return;
  historyUndo.push({snapshot:before,label});
  if(historyUndo.length>HISTORY_LIMIT)historyUndo.shift();
  historyRedo.length=0;
  updateHistoryUi();
}
function resetHistory(){historyUndo=[];historyRedo=[];updateHistoryUi()}
async function restoreSnapshot(snap){
  if(!snap)return;
  historyBusy=true;
  try{
    const d=snap.data||{};
    state.name=d.name||tr('defaultProject');
    state.rows=clamp(parseInt(d.rows)||3,1,25);
    state.showGrid=d.showGrid!==false;state.showCircles=d.showCircles!==false;state.showNumbers=d.showNumbers!==false;
    state.editMode=d.editMode==='mission'?'mission':'fresco';
    state.selectedMissionKey=d.selectedMissionKey||null;
    state.missionOverrides=deepClone(d.missionOverrides||{});
    state.texts=deepClone(d.texts||[]);normalizeAllTextStyles();
    state.imageLayers=deepClone(d.imageLayers||[]).map(l=>({...l,image:null,blob:null,visible:l.visible!==false}));
    const media=new Map((snap.layerMedia||[]).map(x=>[x.id,x]));
    for(const layer of state.imageLayers){
      const m=media.get(layer.id);if(m){layer.blob=m.blob||null;layer.image=m.image||null}
      if(!layer.image&&layer.blob)layer.image=await blobToImage(layer.blob);
    }
    state.active=snap.active||'background';
    state.planner=normalizePlanner(d.planner||{});ensurePlannerMissions();
    state.bg={image:snap.image||null,blob:snap.blob||null,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,visible:true,name:''};
    Object.assign(state.bg,d.bg||{});state.bg.visible=d.bg?.visible!==false;
    if(!state.bg.image&&state.bg.blob)state.bg.image=await blobToImage(state.bg.blob);
    refreshProjectUi();render();
    if(missionEditorBack)renderMissionEditor();
    scheduleSave();
  }finally{historyBusy=false;updateHistoryUi()}
}
async function undoAction(){
  const item=historyUndo.pop();if(!item)return;
  historyRedo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('undo')} · ${item.label}`);
}
async function redoAction(){
  const item=historyRedo.pop();if(!item)return;
  historyUndo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('redo')} · ${item.label}`);
}
function updateHistoryUi(){
  const undoDisabled=!historyUndo.length,redoDisabled=!historyRedo.length;
  $$('.undoActionBtn').forEach(b=>{b.disabled=undoDisabled;b.classList.toggle('disabled',undoDisabled);b.title=undoDisabled?tr('undo'):`${tr('undo')} · ${historyUndo.at(-1).label}`});
  $$('.redoActionBtn').forEach(b=>{b.disabled=redoDisabled;b.classList.toggle('disabled',redoDisabled);b.title=redoDisabled?tr('redo'):`${tr('redo')} · ${historyRedo.at(-1).label}`});
}
function historyControl(el,label){
  if(!el)return;
  let before=null;
  const begin=()=>{if(before===null)before=beginHistory()};
  const commit=()=>{if(before!==null){commitHistory(before,label);before=null}};
  el.addEventListener('pointerdown',begin);
  el.addEventListener('focus',begin);
  el.addEventListener('change',commit);
  el.addEventListener('blur',commit);
}

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    settingsGear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21H9.6v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4V9.6h.1A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6A1.7 1.7 0 0 0 10 2.5V2.4h4v.1a1.7 1.7 0 0 0 1 1.7 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.1v4h-.1a1.7 1.7 0 0 0-1.7 1Z"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2-4.5-4.4 6.2-.9L12 3Z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand">
        <button class="brandmark brandegg" id="brandEgg" aria-label="Redacted"><img src="/redacted-logo-512.png" alt="Redacted"></button>
        <div><h1>Redacted BannerLab</h1><small>${tr('subtitle')} · v${APP_VERSION}</small></div>
      </div>
      <div class="grow"></div><button class="playhubbtn" id="playHubBtn" aria-label="${tr('playBanners')}">${icon('search')}<span>${tr('playBanners')}</span></button><button class="iconbtn" id="infoBtn" aria-label="${tr('settingsInfo')}" title="${tr('settingsInfo')}">${icon('settingsGear')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div class="projectidentity"><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> ${tr('missions').toLowerCase()} · ${tr('source')} ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>${tr("projects")}</span></button>
        <div class="rowpick"><span>${tr("rows")}</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>${tr("fresco")}</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>${tr("route")}</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>${tr("missions")}</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>${tr("publish")}</span></button>
      </div>
      <div class="card workspace" id="workspaceCard">
        <div class="flowlockveil" id="flowLockVeil" hidden>
          <div class="flowlockbox">
            <strong>🔒 ${tr('flowLocked')}</strong>
            <span id="flowLockText">${tr('flowLockedText',{step:tr('route')})}</span>
            <small>${tr('returnFresco')}</small>
          </div>
        </div>
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">${tr("wholeFresco")}</button>
          <button class="modebtn" data-editmode="mission">${tr("oneMission")}</button>
          <div class="missionstatus" id="missionStatus">${tr("noMission")}</div>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>${tr("addImage")}</strong>${tr("imageHint")}</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">${tr("circles")}</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">${tr("grid")}</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">${tr("numbers")}</button>
          <button class="chip studioedit" id="openStudioEditorBtn">${icon('expand')} ${tr("studioEdit")}</button>
          <button class="chip historychip undoActionBtn" id="undoBtn" disabled>↶ ${tr("undo")}</button>
          <button class="chip historychip redoActionBtn" id="redoBtn" disabled>↷ ${tr("redo")}</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} ${tr("enlarge")}</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>${tr("resetMission")}</button>
        </div>
        <div class="hint" id="gestureHint">${tr('bannerHelp')}</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>${tr("image")}</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>${tr("text")}</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>${tr("preview")}</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>${tr("export")}</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function flowIsEditable(){return activeFlow==='fresco'}
function activeFlowLabel(){
  return activeFlow==='route'?tr('route'):activeFlow==='missions'?tr('missions'):activeFlow==='publish'?tr('publish'):tr('fresco');
}
function applyFlowLock(){
  const locked=!flowIsEditable();
  const workspace=$('#workspaceCard');
  const veil=$('#flowLockVeil');
  workspace?.classList.toggle('flowlocked',locked);
  if(veil)veil.hidden=!locked;
  const txt=$('#flowLockText');
  if(txt)txt.textContent=tr('flowLockedText',{step:activeFlowLabel()});

  const rows=$('#rowsSelect');
  if(rows)rows.disabled=locked;

  // Editing tools only. Preview/export remain usable.
  $$('.tool[data-tool="image"],.tool[data-tool="text"]').forEach(b=>{
    b.classList.toggle('flowdisabled',locked);
    b.setAttribute('aria-disabled',locked?'true':'false');
  });

  $$('.flowstep').forEach(b=>b.classList.toggle('on',b.dataset.flow===activeFlow));
}
function requireFrescoFlow(){
  if(flowIsEditable())return true;
  toast(tr('flowLockedToast'));
  return false;
}
function setFlowStep(flow,{open=true}={}){
  if(!['fresco','route','missions','publish'].includes(flow))flow='fresco';
  activeFlow=flow;
  applyFlowLock();

  if(!open)return;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawImageObject(c,b){
  if(!b?.image||b.visible===false)return;
  c.save();c.translate(b.x||0,b.y||0);c.rotate(b.rotation||0);c.scale(b.scale||1,b.scale||1);
  c.globalAlpha=clamp(Number.isFinite(+b.opacity)?+b.opacity:1,0,1);
  c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
}
function drawImageLayerObject(c,layer){normalizeImageLayerScope(layer);if(layer.scope!=='mission'){drawImageObject(c,layer);return}const r=missionLayerRect(layer);if(!r||!layer?.image||layer.visible===false)return;c.save();c.beginPath();c.rect(r.x,r.y,TILE,TILE);c.clip();drawImageObject(c,layer);c.restore()}
function drawBaseBackground(c){
  drawImageObject(c,state.bg);
  for(const layer of state.imageLayers)drawImageLayerObject(c,layer);
}
function hasImageContent(){return !!state.bg.image||state.imageLayers.some(l=>!!l.image)}
function activeImageLayer(){
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||null;
  return null;
}
function imageLayerLabel(layer,index){return layer?.name?.trim()||`${tr('layerName')} ${index+1}`}
function groupLayersFor(layer){return layer?.groupId?state.imageLayers.filter(x=>x.groupId===layer.groupId):layer?[layer]:[]}

const BUILTIN_TEXT_FONTS=[
  {value:'system-ui, sans-serif',label:'System'},
  {value:'Arial, sans-serif',label:'Arial'},
  {value:'Georgia, serif',label:'Georgia'},
  {value:'serif',label:'Serif'},
  {value:'monospace',label:'Monospace'},
  {value:'cursive',label:'Cursive'}
];
const registeredProjectFontFamilies=new Set();
function textDefaults(t={}){
  return Object.assign({fontFamily:'system-ui, sans-serif',fontWeight:800,fontItalic:false,letterSpacing:0,lineHeight:1.08,textAlign:'center',backgroundEnabled:false,backgroundColor:'#07100c',backgroundOpacity:.72,backgroundPadding:24,backgroundRadius:24},t||{});
}
function normalizeTextStyle(t){
  if(!t)return t;const d=textDefaults();
  for(const [k,v] of Object.entries(d))if(t[k]===undefined||t[k]===null)t[k]=v;
  t.fontWeight=clamp(parseInt(t.fontWeight)||800,100,900);t.letterSpacing=clamp(Number(t.letterSpacing)||0,-40,160);t.lineHeight=clamp(Number(t.lineHeight)||1.08,.7,2.4);{const op=Number(t.backgroundOpacity);t.backgroundOpacity=clamp(Number.isFinite(op)?op:.72,0,1);}t.backgroundPadding=clamp(Number(t.backgroundPadding)||0,0,180);t.backgroundRadius=clamp(Number(t.backgroundRadius)||0,0,240);if(!['left','center','right'].includes(t.textAlign))t.textAlign='center';return t;
}
function normalizeAllTextStyles(){state.texts.forEach(normalizeTextStyle)}
function textFontCss(t){normalizeTextStyle(t);return `${t.fontItalic?'italic ':'normal '}${t.fontWeight||800} ${t.fontSize||180}px ${t.fontFamily||'system-ui, sans-serif'}`}
function fontOptionsHtml(selected){
  const builtin=BUILTIN_TEXT_FONTS.map(f=>`<option value="${escapeAttr(f.value)}" ${selected===f.value?'selected':''}>${escapeHtml(f.label)}</option>`).join('');
  const custom=(state.customFonts||[]).map(f=>`<option value="${escapeAttr(f.family)}" ${selected===f.family?'selected':''}>★ ${escapeHtml(f.name||f.family)}</option>`).join('');
  return builtin+custom;
}
function bytesToBase64(bytes){let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary)}
async function registerProjectFont(rec){
  if(!rec?.family||!rec?.dataUrl)return false;if(registeredProjectFontFamilies.has(rec.family))return true;if(typeof FontFace==='undefined'||!document.fonts)return false;
  try{const face=new FontFace(rec.family,`url(${rec.dataUrl})`);await face.load();document.fonts.add(face);registeredProjectFontFamilies.add(rec.family);return true}catch(e){console.warn('custom font',rec.name,e);return false}
}
async function registerProjectFonts(){for(const rec of (state.customFonts||[]))await registerProjectFont(rec)}
async function importProjectFont(applyToText=null,onDone=null){
  const input=document.createElement('input');input.type='file';input.accept='.ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{
    const file=input.files?.[0];if(!file)return;if(file.size>12*1024*1024){toast(tr('fontTooLarge'));return}
    const ext=(file.name.split('.').pop()||'').toLowerCase();if(!['ttf','otf','woff','woff2'].includes(ext)){toast(tr('fontInvalid'));return}
    const id='font_'+uid(),family='RBLFont_'+id.replace(/[^a-z0-9_]/gi,''),mime=file.type||({ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2'}[ext]||'application/octet-stream');
    const dataUrl=`data:${mime};base64,${bytesToBase64(new Uint8Array(await file.arrayBuffer()))}`;const rec={id,name:file.name,family,mime,dataUrl};state.customFonts.push(rec);const ok=await registerProjectFont(rec);if(!ok){state.customFonts=state.customFonts.filter(x=>x.id!==id);toast(tr('fontInvalid'));return}
    if(applyToText){applyToText.fontFamily=family;normalizeTextStyle(applyToText)}scheduleSave();render();toast(tr('fontImported',{name:file.name}));if(onDone)onDone(rec);
  }catch(e){console.warn('font import',e);toast(tr('fontInvalid'))}finally{input.remove()}};input.click();
}
function measureSpacedLine(c,line,t){const chars=Array.from(String(line||''));return c.measureText(String(line||'')).width+Math.max(0,chars.length-1)*(t.letterSpacing||0)}
function textBlockMetrics(c,t){
  normalizeTextStyle(t);c.font=textFontCss(t);const lines=(t.text||tr('text')).split('\n'),lineH=(t.fontSize||180)*(t.lineHeight||1.08),widths=lines.map(line=>measureSpacedLine(c,line,t)),maxW=Math.max(40,...widths),h=Math.max(lineH,lines.length*lineH),pad=t.backgroundEnabled?(t.backgroundPadding||0):0;return {lines,lineH,widths,maxW,h,pad,bgW:maxW+pad*2,bgH:h+pad*2};
}
function roundedRectPath(c,x,y,w,h,r){r=Math.max(0,Math.min(r,Math.min(w,h)/2));c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath()}
function drawSpacedLine(c,line,x,y,t,maxW){
  const chars=Array.from(String(line||'')),spacing=t.letterSpacing||0,width=measureSpacedLine(c,line,t);let start=x-width/2;if(t.textAlign==='left')start=x-maxW/2;else if(t.textAlign==='right')start=x+maxW/2-width;
  if(Math.abs(spacing)<.001){c.textAlign=t.textAlign;const tx=t.textAlign==='left'?x-maxW/2:t.textAlign==='right'?x+maxW/2:x;if(t.strokeWidth>0)c.strokeText(line,tx,y);c.fillText(line,tx,y);return}
  c.textAlign='left';for(const ch of chars){if(t.strokeWidth>0)c.strokeText(ch,start,y);c.fillText(ch,start,y);start+=c.measureText(ch).width+spacing}
}

function drawOverlayWorld(c){
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  normalizeTextStyle(t);c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);c.font=textFontCss(t);c.textBaseline='middle';c.lineJoin='round';
  const m=textBlockMetrics(c,t);
  if(t.backgroundEnabled){c.save();c.globalAlpha=t.backgroundOpacity??.72;c.fillStyle=t.backgroundColor||'#07100c';roundedRectPath(c,-m.bgW/2,-m.bgH/2,m.bgW,m.bgH,t.backgroundRadius||0);c.fill();c.restore()}
  c.lineWidth=t.strokeWidth||0;c.strokeStyle=t.strokeColor||'#07100c';c.fillStyle=t.color||'#ffffff';
  m.lines.forEach((line,i)=>{const y=(i-(m.lines.length-1)/2)*m.lineH;drawSpacedLine(c,line,0,y,t,m.maxW)});c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseBackground(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseBackground(c);
    c.restore();
  }
  drawOverlayWorld(c);
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=hasImageContent()?'none':'grid';
  updateMissionUi();
  updateHistoryUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission')return;
  if(state.active.startsWith('text:')){
    const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
    c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
    normalizeTextStyle(t);c.font=textFontCss(t);const m=textBlockMetrics(c,t),w=(t.backgroundEnabled?m.bgW:m.maxW)+36,h=(t.backgroundEnabled?m.bgH:m.h)+28;
    c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
    return;
  }
  const layer=activeImageLayer();if(!layer?.image||layer.visible===false)return;
  const group=groupLayersFor(layer);
  for(const item of group){
    if(!item.image||item.visible===false)continue;
    c.save();c.scale(s,s);c.translate(item.x,item.y);c.rotate(item.rotation||0);c.scale(item.scale||1,item.scale||1);
    const inv=Math.max(.0001,s*(item.scale||1));
    c.strokeStyle=item===layer?'#ffcc66':'rgba(255,204,102,.55)';c.lineWidth=4/inv;c.setLineDash([14/(item.scale||1),10/(item.scale||1)]);
    c.strokeRect(-item.image.naturalWidth/2,-item.image.naturalHeight/2,item.image.naturalWidth,item.image.naturalHeight);c.restore();
  }
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}
function rowColForMissionAtRows(n,rows){n=Math.max(1,parseInt(n)||1);return {row:rows-1-Math.floor((n-1)/6),col:5-((n-1)%6)}}
function missionLayerNumber(layer){return layer?.scope==='mission'?Math.max(1,parseInt(layer.missionNumber)||1):null}
function missionLayerRect(layer,rows=state.rows){const n=missionLayerNumber(layer);if(!n||n>rows*COLS)return null;const rc=rowColForMissionAtRows(n,rows);if(rc.row<0||rc.row>=rows)return null;return {n,row:rc.row,col:rc.col,x:rc.col*STEP+PAD,y:rc.row*STEP+PAD,cx:rc.col*STEP+PAD+TILE/2,cy:rc.row*STEP+PAD+TILE/2}}
function missionLayerFitScale(layer,mode=layer?.fitMode||'cover'){if(!layer?.image)return 1;return mode==='contain'?Math.min(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight):Math.max(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight)}
function normalizeImageLayerScope(layer){if(!layer)return layer;layer.scope=layer.scope==='mission'?'mission':'global';if(layer.scope==='mission'){layer.missionNumber=Math.max(1,parseInt(layer.missionNumber)||1);layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}else{layer.missionNumber=null;layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}return layer}
function reanchorMissionLayers(oldRows,newRows){for(const l of state.imageLayers){normalizeImageLayerScope(l);if(l.scope!=='mission')continue;const n=missionLayerNumber(l),oldRc=n&&n<=oldRows*COLS?rowColForMissionAtRows(n,oldRows):null,newRc=n&&n<=newRows*COLS?rowColForMissionAtRows(n,newRows):null;if(!newRc)continue;const oldCx=oldRc?oldRc.col*STEP+PAD+TILE/2:l.x||0,oldCy=oldRc?oldRc.row*STEP+PAD+TILE/2:l.y||0,newCx=newRc.col*STEP+PAD+TILE/2,newCy=newRc.row*STEP+PAD+TILE/2;l.x=(l.x||oldCx)+(newCx-oldCx);l.y=(l.y||oldCy)+(newCy-oldCy)}}
function missionLayerBadgeHtml(layer){const n=missionLayerNumber(layer);return n?`<span class="missionLayerBadge">${escapeHtml(tr('missionBadge',{n}))}</span>`:''}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  const isImage=a==='background'||a.startsWith('image:');
  $$('.tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='layers'));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  else state.selectedMissionKey=null;
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=tr('missionSelected',{n:missionNumber(rc.row,rc.col)});
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent=tr('tapMedallion');reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML=tr('missionHelp');
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML=tr('bannerHelp');
  }
}

let pendingImageMode='background';
async function loadImageFile(file){
  if(!file)return;
  const before=beginHistory();
  if(file.size>45*1024*1024)toast(tr('heavyImage'));
  const img=await blobToImage(file);
  if(pendingImageMode==='background'){
    state.bg.blob=file;state.bg.image=img;state.bg.visible=true;state.bg.name=tr('backgroundLayer');
    fitBackground();setEditMode('fresco');setActive('background');commitHistory(before,tr('histImport'));toast(tr('backgroundReplaced'));
  }else{
    const layer={id:uid(),name:file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'global',missionNumber:null,fitMode:'cover'};
    fitImageLayer(layer);state.imageLayers.push(layer);setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));toast(tr('layerAdded'));
  }
  scheduleSave();render();if(studioEditorRoot)refreshStudioEditor();toast(`${tr('imported',{w:img.naturalWidth,h:img.naturalHeight})} · ${pendingImageMode==='background'?tr('backgroundReplaced'):tr('layerAdded')}`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight);b.visible=true;b.opacity=1}
function fitImageLayer(layer){if(!layer?.image)return;normalizeImageLayerScope(layer);if(layer.scope==='mission'){const r=missionLayerRect(layer);if(r){layer.x=r.cx;layer.y=r.cy;layer.scale=missionLayerFitScale(layer)}}else{layer.x=WORLD_W/2;layer.y=worldH()/2;layer.scale=Math.min(WORLD_W*.72/layer.image.naturalWidth,worldH()*.72/layer.image.naturalHeight)}layer.rotation=0;layer.opacity=1;layer.visible=true}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;state.bg.name=tr('backgroundLayer');state.bg.visible=true;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasClientToWorld(clientX,clientY){
  if(studioEditorRoot){
    const stage=$('.studioCanvasStage',studioEditorRoot),rect=stage?.getBoundingClientRect(),scale=Math.max(.0001,studioViewScale);
    if(rect)return {x:(clientY-rect.top)/scale,y:(rect.right-clientX)/scale};
  }
  const rect=canvas.getBoundingClientRect(),scale=rect.width/WORLD_W;return {x:(clientX-rect.left)/scale,y:(clientY-rect.top)/scale};
}
function clientDeltaToWorld(dx,dy){
  const scale=Math.max(.0001,getCssScale());return studioEditorRoot?{dx:dy/scale,dy:-dx/scale}:{dx:dx/scale,dy:dy/scale};
}
function canvasPointToMission(clientX,clientY){
  const pt=canvasClientToWorld(clientX,clientY),x=pt.x,y=pt.y;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

function frescoTransformTargets(){
  const obj=selectedObj();if(!obj)return[];
  if(state.active.startsWith('image:')&&obj.groupId)return groupLayersFor(obj);
  return [obj];
}
function captureTransformTargets(targets){return targets.map(obj=>({obj,x:obj.x||0,y:obj.y||0,scale:obj.scale??1,rotation:obj.rotation||0}))}
function transformCenter(items){if(!items.length)return{x:0,y:0};return{x:items.reduce((a,t)=>a+t.x,0)/items.length,y:items.reduce((a,t)=>a+t.y,0)/items.length}}
function makeFrescoTwoGesture(points,historyBefore){const items=captureTransformTargets(frescoTransformTargets());return{mode:'two',dist:distance(points[0],points[1]),angle:angle(points[0],points[1]),mid:mid(points[0],points[1]),items,center:transformCenter(items),historyBefore}}

canvas.addEventListener('pointerdown',e=>{
  if(!requireFrescoFlow())return;
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    const changed=state.selectedMissionKey!==hit.key;
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();
    // Le premier toucher choisit la mission sans la déplacer. Les gestes suivants
    // sur cette même mission servent ensuite à la transformer.
    if(changed){gesture=null;return}
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(state.editMode==='mission'){
    if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:beginHistory()};
    else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()}}
    return;
  }
  if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,items:captureTransformTargets(frescoTransformTargets()),historyBefore:beginHistory()};
  else if(pointers.size===2)gesture=makeFrescoTwoGesture([...pointers.values()],gesture?.historyBefore||beginHistory());
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(state.editMode==='mission'){
    if(pointers.size===1&&gesture?.mode==='one'){
      const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }else if(pointers.size===2){
      const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()};return}
      const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),.2,5);obj.rotation=gesture.objRot+(a-gesture.angle);const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }
    return;
  }
  if(pointers.size===1&&gesture?.mode==='one'){
    const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);for(const t of gesture.items||[]){t.obj.x=t.x+dxy.dx;t.obj.y=t.y+dxy.dy}render();
  }else if(pointers.size===2){
    const pts=[...pointers.values()];if(gesture?.mode!=='two'){gesture=makeFrescoTwoGesture(pts,gesture?.historyBefore||beginHistory());return}
    const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]),factor=d/Math.max(1,gesture.dist),rd=a-gesture.angle,cs=Math.cos(rd),sn=Math.sin(rd);
    const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y),nc={x:gesture.center.x+dxy.dx,y:gesture.center.y+dxy.dy};
    for(const t of gesture.items||[]){const ox=(t.x-gesture.center.x)*factor,oy=(t.y-gesture.center.y)*factor;t.obj.x=nc.x+ox*cs-oy*sn;t.obj.y=nc.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*factor,.02,30);t.obj.rotation=t.rotation+rd}render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){
    const before=gesture?.historyBefore,label=state.editMode==='mission'?tr('histResetMission'):(state.active.startsWith('text:')?tr('histEditText'):(state.active.startsWith('image:')&&selectedObj()?.groupId?tr('groupTransform'):tr('frameImage')));
    gesture=null;commitHistory(before,label);scheduleSave();
  }else if(pointers.size===1){
    const p=[...pointers.values()][0],obj=selectedObj(),before=gesture?.historyBefore;
    if(state.editMode==='mission'&&obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:before};
    else gesture={mode:'one',startX:p.x,startY:p.y,items:captureTransformTargets(frescoTransformTargets()),historyBefore:before};
  }
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return studioEditorRoot?Math.max(.0001,studioViewScale):canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||tr('defaultProject');ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>{if(!requireFrescoFlow()){e.target.value=String(state.rows);return}changeRows(+e.target.value)});
$('#openStudioEditorBtn').addEventListener('click',openStudioEditor);
function changeRows(rows){
  const before=beginHistory();
  const oldRows=state.rows,oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.imageLayers.filter(l=>l.scope!=='mission').forEach(l=>l.y+=(newH/2-oldCenter));reanchorMissionLayers(oldRows,state.rows);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();commitHistory(before,tr('rows'));scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;setEditMode(btn.dataset.editmode)}));
$('#resetMissionBtn').addEventListener('click',()=>{if(requireFrescoFlow())resetSelectedMission()});
$('#openMissionEditorBtn').addEventListener('click',()=>{if(requireFrescoFlow())openMissionEditor()});

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(['image','text'].includes(t)&&!requireFrescoFlow())return;
  if(t==='image')openImageLayersSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#playHubBtn').addEventListener('click',()=>openPlayHub('search'));
let eggTaps=0,eggTimer=null;
$('#brandEgg').addEventListener('click',()=>{
  eggTaps++;clearTimeout(eggTimer);eggTimer=setTimeout(()=>{eggTaps=0},2200);
  if(eggTaps>=7){eggTaps=0;clearTimeout(eggTimer);runDinoEasterEgg()}
});
$('#infoBtn').addEventListener('click',openInfoSheet);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$('#undoBtn').addEventListener('click',()=>{if(requireFrescoFlow())undoAction()});
$('#redoBtn').addEventListener('click',()=>{if(requireFrescoFlow())redoAction()});
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  setFlowStep(btn.dataset.flow);
}));

applyFlowLock();

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}


function runDinoEasterEgg(){
  if($('.rblDinoEgg'))return;
  const wrap=document.createElement('div');wrap.className='rblDinoEgg';
  wrap.innerHTML=`<img src="/redacted-dino-cutout.png" alt=""><span>${escapeHtml(tr('easterEgg'))}</span>`;
  document.body.appendChild(wrap);
  const img=$('img',wrap);
  const done=()=>wrap.remove();
  img.addEventListener('animationend',done,{once:true});
  setTimeout(done,4300);
}

function loadBannerFavorites(){
  try{const x=JSON.parse(localStorage.getItem(BANNER_FAVORITES_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}
}
function saveBannerFavorites(items){localStorage.setItem(BANNER_FAVORITES_KEY,JSON.stringify(items.slice(0,120)));markBackupChanged()}
function isBannerFavorite(id){return loadBannerFavorites().some(x=>String(x.id)===String(id))}
function favoriteBanner(detail){
  const list=loadBannerFavorites().filter(x=>String(x.id)!==String(detail.id));
  list.unshift(compactBanner(detail));saveBannerFavorites(list);return true;
}
function unfavoriteBanner(id){saveBannerFavorites(loadBannerFavorites().filter(x=>String(x.id)!==String(id)))}
function compactBanner(detail){
  return {
    id:String(detail?.id||''),title:String(detail?.title||tr('unnamed')),
    formattedAddress:String(detail?.formattedAddress||''),lengthMeters:Number(detail?.lengthMeters||0)||0,
    numberOfMissions:Number(detail?.numberOfMissions||detail?.missions?.length||0)||0,
    numberOfDisabledMissions:Number(detail?.numberOfDisabledMissions||0)||0,
    picture:String(detail?.picture||''),author:String(detail?.author||'')
  };
}
function loadBannerTodo(){try{const x=JSON.parse(localStorage.getItem(BANNER_TODO_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function saveBannerTodo(items){localStorage.setItem(BANNER_TODO_KEY,JSON.stringify((items||[]).slice(0,160)));markBackupChanged()}
function isBannerTodo(id){return loadBannerTodo().some(x=>String(x.id)===String(id))}
function addBannerTodo(detail){const list=loadBannerTodo().filter(x=>String(x.id)!==String(detail.id));list.unshift(compactBanner(detail));saveBannerTodo(list)}
function removeBannerTodo(id){saveBannerTodo(loadBannerTodo().filter(x=>String(x.id)!==String(id)))}
function loadPlayHistory(){try{const x=JSON.parse(localStorage.getItem(PLAY_HISTORY_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function savePlayHistory(items){localStorage.setItem(PLAY_HISTORY_KEY,JSON.stringify((items||[]).slice(0,100)));markBackupChanged()}
function upsertPlayHistory(session,extra={}){
  if(!session?.bannerId)return;
  const list=loadPlayHistory();const key=String(session.bannerId);
  const old=list.find(x=>String(x.bannerId)===key)||{};
  const rec={...old,...compactBanner({id:session.bannerId,title:session.title,formattedAddress:session.address,picture:session.picture,author:session.author,lengthMeters:session.lengthMeters,numberOfMissions:session.missions?.length}),
    bannerId:key,currentIndex:Number(extra.currentIndex??session.currentIndex??old.currentIndex??0)||0,
    doneCount:Number(extra.doneCount??old.doneCount??0)||0,total:Number(session.missions?.length||old.total||0)||0,
    startedAt:Number(extra.startedAt??session.startedAt??old.startedAt??Date.now())||Date.now(),
    finishedAt:Number(extra.finishedAt??old.finishedAt??0)||0,pausedTotal:Number(extra.pausedTotal??old.pausedTotal??0)||0,
    paused:!!(extra.paused??old.paused),updatedAt:Date.now()};
  const out=[rec,...list.filter(x=>String(x.bannerId)!==key)].sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));savePlayHistory(out);return rec;
}
function activeDurationMs(x){
  const start=Number(x?.startedAt||0);if(!start)return 0;
  const end=Number(x?.finishedAt||Date.now());let paused=Number(x?.pausedTotal||0)||0;
  if(x?.paused&&x?.pausedAt)paused+=Math.max(0,Date.now()-Number(x.pausedAt));
  return Math.max(0,end-start-paused);
}
function formatPlayDuration(ms){
  const min=Math.floor(Math.max(0,ms)/60000),h=Math.floor(min/60),m=min%60;
  return h?`${h} h ${String(m).padStart(2,'0')}`:`${m} min`;
}
function formatPlayDate(ts){if(!ts)return '—';const locale=appLocale();return new Date(ts).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'})}
function estimatedPlayedMeters(entry){const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1));return (Number(entry?.lengthMeters||0)||0)*Math.min(1,(Number(entry?.doneCount||0)||0)/total)}
function bannergressImage(picture=''){
  if(!picture)return '';
  return /^https?:/i.test(picture)?picture:`${BANNERGRESS_API}${picture.startsWith('/')?'':'/'}${picture}`;
}
function formatBannerDistance(meters){
  const m=Number(meters)||0;if(!m)return '—';return `${(m/1000).toFixed(m>=10000?0:1).replace('.',',')} km`;
}

function formatBannerMeters(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  if(m<1000)return `${Math.round(m)} m`;
  return `${(m/1000).toFixed(m<10000?2:1).replace('.',',')} km`;
}
function formatWalkSeconds(seconds){
  const total=Math.max(0,Math.round(Number(seconds)||0));
  if(!total)return '—';
  const minutes=Math.max(1,Math.round(total/60));
  if(minutes<60)return tr('minutesShort',{n:minutes});
  const h=Math.floor(minutes/60),m=minutes%60;
  return tr('hoursMinutes',{h,m:String(m).padStart(2,'0')});
}
function formatWalkEstimate(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  return formatWalkSeconds((m/4800)*3600);
}
function bannerRouteRows(detail){
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  return missions.map((m,index)=>{
    const route=Array.isArray(m?.route)?m.route.filter(p=>Number.isFinite(Number(p?.latitude))&&Number.isFinite(Number(p?.longitude))):[];
    let meters=0,longestLeg=0;
    for(let i=1;i<route.length;i++){
      const d=haversine(route[i-1],route[i]);
      meters+=d;
      longestLeg=Math.max(longestLeg,d);
    }
    return {index,route,meters,longestLeg,title:m?.title||tr('missionStart',{n:index+1})};
  });
}
function bannerFunStats(detail){
  const missionRows=bannerRouteRows(detail);
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  const withRoute=missionRows.filter(x=>x.route.length);
  const routeMeters=missionRows.reduce((s,x)=>s+x.meters,0);
  let transitionMeters=0,longestTransition=0;
  for(let i=1;i<withRoute.length;i++){
    const prev=withRoute[i-1].route.at(-1),next=withRoute[i].route[0];
    const d=haversine(prev,next);
    transitionMeters+=d;
    longestTransition=Math.max(longestTransition,d);
  }
  const geometricMeters=routeMeters+transitionMeters;
  const bgMeters=Number(detail?.lengthMeters||0)||0;

  const allPoints=missionRows.flatMap(x=>x.route);
  const uniqueKeys=new Set(allPoints.map(p=>`${Number(p.latitude).toFixed(5)},${Number(p.longitude).toFixed(5)}`));
  const uniquePlaces=uniqueKeys.size;
  const repeated=Math.max(0,allPoints.length-uniquePlaces);

  let longestMission=null,longestLeg=0;
  for(const row of missionRows){
    if(!longestMission||row.meters>longestMission.meters)longestMission=row;
    longestLeg=Math.max(longestLeg,row.longestLeg);
  }

  const start=allPoints[0]||null,end=allPoints.at(-1)||null;
  const straight=start&&end?haversine(start,end):0;
  const missionCount=Math.max(1,missions.length);
  const mappedMissionCount=withRoute.length;
  const coverage=missions.length?Math.round(mappedMissionCount/missions.length*100):0;

  return {
    bgMeters,routeMeters,transitionMeters,geometricMeters,
    points:allPoints.length,uniquePlaces,repeated,
    avgMission:routeMeters/missionCount,
    longestMission,longestLeg,longestTransition,
    straight,coverage,mappedMissionCount,totalMissions:missions.length,
    missionRows
  };
}
function bannerWalkSignature(detail){
  const rows=bannerRouteRows(detail);
  return JSON.stringify(rows.flatMap(r=>r.route.map(p=>[
    r.index,
    Number(p.latitude).toFixed(6),
    Number(p.longitude).toFixed(6)
  ])));
}
function bannerWalkCacheKey(detail){
  const id=String(detail?.id??detail?.bannerId??'unknown').replace(/[^a-zA-Z0-9_.:-]/g,'_');
  return `${BANNER_WALK_CACHE_PREFIX}${id}`;
}
function loadBannerWalkCache(detail){
  try{
    const x=JSON.parse(localStorage.getItem(bannerWalkCacheKey(detail))||'null');
    if(x?.sig===bannerWalkSignature(detail)&&x?.walking)return x.walking;
  }catch{}
  return null;
}
function saveBannerWalkCache(detail,walking){
  try{
    localStorage.setItem(bannerWalkCacheKey(detail),JSON.stringify({
      sig:bannerWalkSignature(detail),
      walking,
      at:Date.now()
    }));
  }catch{}
}
async function fetchValhallaWalkingChunk(chunk){
  const lang=appLocale();
  const body={
    locations:chunk.map(x=>({
      lat:Number(x.point.latitude),
      lon:Number(x.point.longitude),
      type:'break'
    })),
    costing:'pedestrian',
    units:'kilometers',
    directions_options:{units:'kilometers',language:lang}
  };

  let data,status=0,transport='web';

  if(Capacitor.isNativePlatform()){
    transport='native';
    const response=await CapacitorHttp.post({
      url:VALHALLA_API,
      headers:{
        'Content-Type':'application/json',
        'Accept':'application/json',
        'X-Client-Id':'redacted-bannerlab'
      },
      data:body,
      connectTimeout:18000,
      readTimeout:18000,
      responseType:'json'
    });
    status=Number(response?.status)||0;
    data=response?.data;
    if(typeof data==='string'){
      try{data=JSON.parse(data)}catch{}
    }
  }else{
    // Browser/web fallback. GET with encoded json stays a simple request
    // and avoids the JSON POST preflight that can be blocked by CORS.
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),18000);
    try{
      const url=`${VALHALLA_API}?json=${encodeURIComponent(JSON.stringify(body))}`;
      const response=await fetch(url,{
        method:'GET',
        headers:{'Accept':'application/json'},
        signal:ctrl.signal
      });
      status=response.status;
      if(response.ok)data=await response.json();
      else{
        let msg='';
        try{msg=await response.text()}catch{}
        throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg.slice(0,120)}`:''}`);
      }
    }finally{
      clearTimeout(timer);
    }
  }

  if(status<200||status>=300){
    const msg=data?.error||data?.error_code||data?.status_message||'';
    throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg}`:''}`);
  }

  const legs=data?.trip?.legs||[];
  if(legs.length!==Math.max(0,chunk.length-1)){
    const msg=data?.error||data?.status_message||'incomplete route';
    throw new Error(`Valhalla ${msg} · ${legs.length}/${Math.max(0,chunk.length-1)} legs`);
  }

  return legs.map(leg=>({
    meters:(Number(leg?.summary?.length)||0)*1000,
    seconds:Number(leg?.summary?.time)||0,
    transport
  }));
}
async function calculateBannerWalkingStats(detail,{force=false}={}){
  const direct=bannerFunStats(detail);
  const flat=[];
  direct.missionRows.forEach(row=>{
    row.route.forEach((point,pointIndex)=>flat.push({
      point,
      missionIndex:row.index,
      pointIndex,
      title:point?.title||row.title||`M${row.index+1}`
    }));
  });
  if(flat.length<2)throw new Error(tr('statsUnavailable'));

  if(!force){
    const cached=loadBannerWalkCache(detail);
    if(cached)return {...cached,cached:true};
  }

  const missionMeters=Array.from({length:direct.totalMissions},()=>0);
  const missionSeconds=Array.from({length:direct.totalMissions},()=>0);
  let totalMeters=0,totalSeconds=0,transitionMeters=0,transitionSeconds=0;
  let rawValhallaMeters=0,rawValhallaSeconds=0;
  let correctedLegs=0,tooShortLegs=0,absurdDetourLegs=0;
  let longestLegMeters=0,longestLegNames=null;
  let transport=Capacitor.isNativePlatform()?'native':'web';

  let cursor=0;
  while(cursor<flat.length-1){
    const end=Math.min(flat.length,cursor+VALHALLA_MAX_POINTS);
    const chunk=flat.slice(cursor,end);
    const legs=await fetchValhallaWalkingChunk(chunk);
    if(legs[0]?.transport)transport=legs[0].transport;

    legs.forEach((leg,i)=>{
      const a=chunk[i],b=chunk[i+1];
      const directMeters=haversine(a.point,b.point);
      const rawMeters=Math.max(0,Number(leg.meters)||0);
      const rawSeconds=Math.max(0,Number(leg.seconds)||0);

      rawValhallaMeters+=rawMeters;
      rawValhallaSeconds+=rawSeconds;

      let acceptedMeters=rawMeters;
      let acceptedSeconds=rawSeconds;

      // Same portal / nearly identical coordinate: no meaningful walking.
      if(directMeters<3){
        acceptedMeters=0;
        acceptedSeconds=0;
        if(rawMeters>15)correctedLegs++;
      }else{
        // A pedestrian-network route cannot realistically be much shorter
        // than straight-line centre-to-centre distance. This catches bad
        // snapping/correlation shortcuts.
        const impossibleShortcut=rawMeters < directMeters*0.88;

        // Catch isolated OSM/Valhalla detours without throwing away the whole
        // banner. The additive allowance is important for rivers, stations,
        // parks and other genuine obstacles.
        const maxPlausible=Math.max(directMeters*4,directMeters+350);
        const absurdDetour=rawMeters > maxPlausible;

        if(impossibleShortcut || absurdDetour || !rawMeters){
          acceptedMeters=directMeters;
          acceptedSeconds=(directMeters/4800)*3600;
          correctedLegs++;
          if(impossibleShortcut)tooShortLegs++;
          if(absurdDetour)absurdDetourLegs++;
        }
      }

      totalMeters+=acceptedMeters;
      totalSeconds+=acceptedSeconds;

      if(a.missionIndex===b.missionIndex){
        missionMeters[a.missionIndex]=(missionMeters[a.missionIndex]||0)+acceptedMeters;
        missionSeconds[a.missionIndex]=(missionSeconds[a.missionIndex]||0)+acceptedSeconds;
      }else{
        transitionMeters+=acceptedMeters;
        transitionSeconds+=acceptedSeconds;
      }

      if(acceptedMeters>longestLegMeters){
        longestLegMeters=acceptedMeters;
        longestLegNames=[a.title||'Portal',b.title||'Portal'];
      }
    });

    if(end>=flat.length)break;
    cursor=end-1;
    await new Promise(r=>setTimeout(r,160));
  }

  let longestMission=null;
  missionMeters.forEach((meters,index)=>{
    if(meters>0&&(!longestMission||meters>longestMission.meters)){
      longestMission={index,meters,seconds:missionSeconds[index]||0};
    }
  });

  const walking={
    totalMeters,totalSeconds,
    transitionMeters,transitionSeconds,
    missionMeters,missionSeconds,
    longestLegMeters,longestLegNames,longestMission,
    rawValhallaMeters,rawValhallaSeconds,
    correctedLegs,tooShortLegs,absurdDetourLegs,
    source:'valhalla-sanitized',
    transport
  };
  saveBannerWalkCache(detail,walking);
  return walking;
}
function bannerFunStatsHtml(detail,{compact=false,walking=null,routingError=false,loading=false}={}){
  const s=bannerFunStats(detail);
  if(!s.points&&!s.bgMeters)return `<div class="bannerStatsUnavailable">${tr('statsUnavailable')}</div>`;

  const effectiveMeters=walking?.totalMeters||s.geometricMeters||s.bgMeters;
  const effectiveSeconds=walking?.totalSeconds||0;
  const directKmBase=s.geometricMeters;
  const networkDetour=walking&&directKmBase>0?walking.totalMeters/directKmBase:null;

  const longestMission=walking?.longestMission?.meters>0
    ? `${tr('missionShort',{n:walking.longestMission.index+1})} · ${formatBannerMeters(walking.longestMission.meters)}`
    : s.longestMission&&s.longestMission.meters>0
      ? `${tr('missionShort',{n:s.longestMission.index+1})} · ${formatBannerMeters(s.longestMission.meters)}`
      : '—';

  const avgMission=walking?.missionMeters?.length
    ? walking.missionMeters.reduce((a,b)=>a+(Number(b)||0),0)/Math.max(1,s.totalMissions)
    : s.avgMission;

  const longestLeg=walking?.longestLegMeters||s.longestLeg;
  const between=walking?.transitionMeters??s.transitionMeters;
  const stepsPerKm=effectiveMeters>0?s.points/(effectiveMeters/1000):0;

  const items=[
    [tr('bgDistance'),formatBannerDistance(s.bgMeters),'🛣'],
    [tr('calculatedTrack'),loading?'…':formatBannerMeters(walking?.totalMeters||s.geometricMeters),'🚶'],
    [tr('walkingEstimate'),loading?'…':(walking?formatWalkSeconds(effectiveSeconds):formatWalkEstimate(effectiveMeters)),'⏱'],
    [tr('directGeometric'),formatBannerMeters(s.geometricMeters),'〰'],
    [tr('routeSteps'),String(s.points),'◉'],
    [tr('uniquePlaces'),String(s.uniquePlaces),'⌖'],
    [tr('revisitedPlaces'),String(s.repeated),'↻'],
    [tr('stepsPerKm'),stepsPerKm?String(stepsPerKm.toFixed(1)).replace('.',','):'—','⋮'],
    [tr('avgMissionDistance'),formatBannerMeters(avgMission),'÷'],
    [tr('longestMission'),longestMission,'🏆'],
    [tr('longestLeg'),formatBannerMeters(longestLeg),'↔'],
    [tr('betweenMissions'),formatBannerMeters(between),'⇢'],
    [tr('routingDetour'),networkDetour?tr('xFactor',{n:networkDetour.toFixed(2).replace('.',',')}):'—','🌀'],
    [tr('straightLine'),formatBannerMeters(s.straight),'⌁'],
    [tr('routeCoverage'),`${s.coverage} %`,'◫'],
    [tr('correctedLegs'),walking?`${walking.correctedLegs||0}`:'—','⚙'],
    [tr('rawValhalla'),walking?formatBannerMeters(walking.rawValhallaMeters):'—','V'],
    [tr('routingSource'),walking
      ?(walking.transport==='native'?tr('routingNative'):tr('routingWeb'))
      :(routingError?tr('routingFallback'):tr('routingLoading')),'OSM']
  ];

  const shown=compact
    ? [items[0],items[1],items[2],items[7],items[9],items[15]]
    : items;

  return `<div class="bannerFunStats ${compact?'compact':''} ${walking?'walkRouted':''}">
    <div class="bannerFunStatsTitle"><span>📊</span><b>${tr('uselessStats')}</b>${walking?.cached?'<em>cache</em>':''}</div>
    <div class="bannerFunStatsGrid">${shown.map(([label,value,ico])=>`<div><i>${ico}</i><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>
    ${routingError?`<div class="bannerRoutingWarn">${tr('routingFailed')}${typeof routingError==='string'?`<small>${escapeHtml(tr('routingErrorDetail',{error:routingError}))}</small>`:''}</div>`:''}
    ${compact?'':`<small>${tr('funStatsDisclaimer')}</small>`}
  </div>`;
}
async function renderBannerWalkingStats(panel,detail,{compact=false}={}){
  if(!panel)return;
  panel.innerHTML=bannerFunStatsHtml(detail,{compact,loading:true});
  try{
    const walking=await calculateBannerWalkingStats(detail);
    panel.innerHTML=bannerFunStatsHtml(detail,{compact,walking});
    return walking;
  }catch(e){
    console.warn('[Banner walking stats]',e);
    panel.innerHTML=bannerFunStatsHtml(detail,{
      compact,
      routingError:String(e?.message||e||'unknown error')
    });
    return null;
  }
}
async function toggleSearchBannerStats(button,summary){
  const wrap=button.closest('.bannergressCardWrap');
  const panel=wrap?.querySelector('.bannerSearchStats');
  if(!panel)return;
  const opening=panel.hidden;
  if(!opening){
    panel.hidden=true;
    button.textContent=tr('showUselessStats');
    return;
  }
  panel.hidden=false;
  button.disabled=true;
  button.textContent=tr('routingLoading');
  panel.innerHTML=`<div class="loadingInline">${tr('routingLoading')}</div>`;
  try{
    const detail=await fetchBannerDetail(summary);
    await renderBannerWalkingStats(panel,detail,{compact:true});
    button.textContent=tr('hideUselessStats');
  }catch(e){
    panel.innerHTML=`<div class="bannerStatsUnavailable">${escapeHtml(tr('bannerLoadError',{error:e?.message||e}))}</div>`;
    button.textContent=tr('showUselessStats');
  }finally{
    button.disabled=false;
  }
}
function bindBannerList(container,list,onOpen){
  $$('.bannergressCard',container).forEach(btn=>{
    btn.onclick=()=>{
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerId));
      if(b)(onOpen||openBannerDetail)(b);
    };
  });
  $$('.bannerStatsBtn',container).forEach(btn=>{
    btn.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerStatsId));
      if(b)toggleSearchBannerStats(btn,b);
    };
  });
}
function unwrapBannerSearch(raw){
  if(Array.isArray(raw))return raw;
  for(const candidate of [raw?.items,raw?.banners,raw?.results,raw?.data]){
    if(Array.isArray(candidate))return candidate;
    if(candidate&&typeof candidate==='object'){
      for(const key of ['banners','items','results'])if(Array.isArray(candidate[key]))return candidate[key];
    }
  }
  return [];
}
function normalizeGeoPoint(p){
  if(!p)return null;
  const lat=Number(p.latitude??p.lat??p.location?.latitude??p.location?.lat);
  const lng=Number(p.longitude??p.lng??p.lon??p.location?.longitude??p.location?.lng??p.location?.lon);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  return {latitude:lat,longitude:lng,title:String(p.title??p.name??p.portalTitle??'')};
}
function normalizeMissionList(raw){
  let list=raw?.items?.missions??raw?.missions??raw?.banner?.items?.missions??raw?.banner?.missions??[];
  if(!Array.isArray(list)&&list&&typeof list==='object')list=Object.values(list);
  if(!Array.isArray(list))return [];
  const normalized=list.map((m,i)=>{
    let steps=m?.steps??m?.waypoints??m?.points??[];
    if(!Array.isArray(steps)&&steps&&typeof steps==='object')steps=Object.values(steps);
    const route=(Array.isArray(steps)?steps:[]).map(s=>normalizeGeoPoint(s?.poi??s?.portal??s?.point??s)).filter(Boolean);
    const direct=normalizeGeoPoint(m?.startPoint??m?.startPoi??m?.poi);
    if(!route.length&&direct)route.push(direct);
    return {
      id:String(m?.id??m?.missionId??m?.guid??'').trim(),
      title:String(m?.title??m?.name??m?.missionTitle??tr('missionLabel',{n:i+1})),
      order:Number(m?.order??m?.sequence??m?.position??m?.index??i),route
    };
  }).filter(m=>m.id);
  if(normalized.every(x=>Number.isFinite(x.order)))normalized.sort((a,b)=>a.order-b.order);
  return normalized.map(({id,title,route})=>({id,title,route}));
}
function normalizeBannerDetail(raw,fallback={}){
  const b=raw?.banner??raw?.item??raw?.data?.banner??raw?.data??raw??{};
  const source={...fallback,...b};
  const missions=normalizeMissionList(raw);
  return {
    id:String(source.id??fallback.id??''),
    title:String(source.title??fallback.title??tr('unnamed')),
    formattedAddress:String(source.formattedAddress??source.address??fallback.formattedAddress??''),
    lengthMeters:Number(source.lengthMeters??fallback.lengthMeters??0)||0,
    numberOfMissions:Number(source.numberOfMissions??missions.length??fallback.numberOfMissions??0)||missions.length,
    numberOfDisabledMissions:Number(source.numberOfDisabledMissions??fallback.numberOfDisabledMissions??0)||0,
    picture:String(source.picture??fallback.picture??''),
    author:String(source.author??source.authorName??source.creator?.name??source.agent?.name??fallback.author??''),
    startPoint:normalizeGeoPoint(source.startPoint??source.startPoi??source.startLocation??source.location??((source.startPointLatitude??source.startLatitude)!=null?{latitude:source.startPointLatitude??source.startLatitude,longitude:source.startPointLongitude??source.startLongitude}:null)??fallback.startPoint),
    searchDistanceMeters:Number.isFinite(Number(source.searchDistanceMeters??fallback.searchDistanceMeters))?Number(source.searchDistanceMeters??fallback.searchDistanceMeters):null,
    missions
  };
}
async function fetchBannerDetail(summary){
  if(summary?.missions?.length&&summary.missions.some(m=>m?.route?.length))return summary;
  const r=await fetch(`${BANNERGRESS_API}/bnrs/${encodeURIComponent(summary.id??summary.bannerId)}`,{headers:{Accept:'application/json'}});
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return normalizeBannerDetail(await r.json(),summary);
}
function ingressMissionUrl(id){
  const intel=`https://intel.ingress.com/mission/${id}`;
  const p=new URLSearchParams({link:intel,apn:'com.nianticproject.ingress',isi:'576505181',ibi:'com.google.ingress',ifl:'https://apps.apple.com/app/ingress/id576505181',ofl:intel});
  return `https://link.ingress.com/?${p.toString()}`;
}
async function openIngressMission(id){
  if(!id)return;
  const url=ingressMissionUrl(id);
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:url,packageName:'com.nianticproject.ingress'});
    else await AppLauncher.openUrl({url});
  }catch{
    try{await AppLauncher.openUrl({url})}catch(e){console.warn('Ingress deeplink',e)}
  }
}
function savePlaySession(session){localStorage.setItem(PLAY_SESSION_KEY,JSON.stringify(session));markBackupChanged()}
function loadPlaySession(){try{return JSON.parse(localStorage.getItem(PLAY_SESSION_KEY)||'null')}catch{return null}}
async function overlayState(){
  if(!Capacitor.isNativePlatform())return {active:false,currentIndex:loadPlaySession()?.currentIndex||0,total:loadPlaySession()?.missions?.length||0,doneJson:'[]'};
  try{return await MissionOverlay.getState()}catch(e){console.warn('overlay state',e);return {active:false}}
}
function bannerStartPoint(detail){
  for(const m of detail?.missions||[])if(m?.route?.length)return m.route[0];
  return normalizeGeoPoint(detail?.startPoint);
}
function bannerRoutePoints(detail){
  const out=[];(detail?.missions||[]).forEach((m,mi)=>(m.route||[]).forEach((p,pi)=>out.push({...p,missionIndex:mi,pointIndex:pi})));
  return out;
}
function rblGroupLink(detail,index=0){
  const id=String(detail?.id??detail?.bannerId??'');
  return `redactedbannerlab://play?banner=${encodeURIComponent(id)}&mission=${Math.max(0,Number(index)||0)}`;
}
function bannergressBannerUrl(detail){return `https://bannergress.com/banner/${encodeURIComponent(String(detail?.id??detail?.bannerId??''))}`}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);return true}catch{}
  try{
    const ta=document.createElement('textarea');ta.value=String(text);ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';ta.style.pointerEvents='none';document.body.appendChild(ta);ta.select();ta.setSelectionRange(0,ta.value.length);const ok=document.execCommand('copy');ta.remove();return !!ok;
  }catch{return false}
}
async function openGroupShareSheet(detail,index=0){
  const link=rblGroupLink(detail,index);
  let qr='';try{qr=await QRCode.toDataURL(link,{width:420,margin:1,color:{dark:'#06140b',light:'#ffffff'}})}catch(e){console.warn('QR',e)}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('shareGroup')}</h2><p>${tr('shareIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="groupShareCard">${qr?`<img class="groupQr" src="${qr}" alt="QR">`:''}<b>${escapeHtml(detail?.title||tr('unnamed'))}</b><span>${tr('missionStart',{n:Number(index)+1})}</span></div>
    <div class="shareLinkBox"><code>${escapeHtml(link)}</code></div>
    <div class="actions"><button class="secondary copygroup">${tr('copyLink')}</button><button class="primary sharegroup">${tr('shareNow')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('groupNoServer')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.copygroup',sh).onclick=async()=>{if(await copyText(link))toast(tr('linkCopied'))};
  $('.sharegroup',sh).onclick=async()=>{
    const text=`${detail?.title||'RBL'} · ${tr('missionStart',{n:Number(index)+1})}\n${link}`;
    try{await Share.share({title:detail?.title||'Redacted BannerLab',text,dialogTitle:tr('shareGroup')})}catch(e){console.warn('share group',e)}
  };
}
async function navigateToBannerStart(detail){
  const p=bannerStartPoint(detail);if(!p){toast(tr('startUnavailable'));return}
  const dest=`${p.latitude},${p.longitude}`;
  const web=`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=walking`;
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:web,packageName:'com.google.android.apps.maps'});
    else await AppLauncher.openUrl({url:web});
  }catch{try{await AppLauncher.openUrl({url:web})}catch(e){console.warn('maps',e)}}
}
function missionMapIcon(n,isStart=false){return L.divIcon({className:'rblLeafletIcon',html:`<span class="${isStart?'start':''}">${isStart?'▶':n}</span>`,iconSize:[30,30],iconAnchor:[15,15]})}
async function openBannerMap(detail){
  const points=bannerRoutePoints(detail);const start=bannerStartPoint(detail);
  if(!points.length&&!start){toast(tr('mapUnavailable'));return}
  const mapId=`rblMap_${Date.now().toString(36)}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('bannerMap')}</h2><p>${escapeHtml(detail.title||'')} · ${tr('routePoints',{n:points.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="bannerMapCanvas" id="${mapId}"></div>
    <div class="actions"><button class="primary navstart">📍 ${tr('navigateStart')}</button><button class="secondary sharemap">${tr('shareGroup')}</button></div>`);
  let map=null;
  const close=()=>{try{map?.remove()}catch{}closeSheet()};
  $('.close',sh).onclick=close;$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharemap',sh).onclick=()=>openGroupShareSheet(detail,0);
  await new Promise(r=>setTimeout(r,80));
  const el=document.getElementById(mapId);if(!el)return;
  map=L.map(el,{zoomControl:true,attributionControl:true});
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
  const bounds=[];
  (detail.missions||[]).forEach((m,mi)=>{
    const route=m.route||[];if(!route.length)return;
    const latlngs=route.map(p=>[p.latitude,p.longitude]);bounds.push(...latlngs);
    if(latlngs.length>1)L.polyline(latlngs,{color:'#31ed83',weight:4,opacity:.8}).addTo(map);
    L.marker(latlngs[0],{icon:missionMapIcon(mi+1,mi===0)}).addTo(map).bindPopup(`${mi===0?tr('startPoint')+' · ':''}${escapeHtml(m.title||tr('missionStart',{n:mi+1}))}`);
  });
  if(!bounds.length&&start)bounds.push([start.latitude,start.longitude]);
  if(bounds.length===1)map.setView(bounds[0],16);else map.fitBounds(bounds,{padding:[24,24]});
  setTimeout(()=>map.invalidateSize(),100);
}
async function joinSharedBanner(id,index=0){
  try{
    const detail=await fetchBannerDetail({id:String(id)});const i=clamp(Number(index)||0,0,Math.max(0,detail.missions.length-1));
    toast(tr('sharedBannerLoaded',{n:i+1}));openBannerDetail(detail,{startIndex:i,fromShare:true});
  }catch(e){toast(tr('sharedBannerError',{error:e?.message||e}))}
}
async function startPlaySession(detail,index=0){
  if(!detail?.missions?.length){toast(tr('bannerOffline'));return}
  const bannerId=String(detail.id??detail.bannerId??'');
  const previous=loadPlaySession();const same=String(previous?.bannerId||'')===bannerId;
  const session={format:'redacted-bannerlab-play-session',version:2,bannerId,title:detail.title,address:detail.formattedAddress??detail.address??'',picture:detail.picture||'',author:detail.author||'',lengthMeters:Number(detail.lengthMeters||0)||0,currentIndex:clamp(index,0,detail.missions.length-1),startedAt:same&&previous?.startedAt?previous.startedAt:Date.now(),missions:detail.missions};
  savePlaySession(session);upsertPlayHistory(session,{currentIndex:session.currentIndex,doneCount:same?Number(loadPlayHistory().find(x=>String(x.bannerId)===String(detail.id))?.doneCount||0):0,startedAt:session.startedAt});
  if(!Capacitor.isNativePlatform()){
    await openIngressMission(session.missions[session.currentIndex].id);return;
  }
  try{
    const p=await MissionOverlay.hasPermission();
    if(!p?.granted){
      localStorage.setItem(PLAY_PENDING_KEY,JSON.stringify(session));
      openOverlayPermissionSheet();return;
    }
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions[session.currentIndex].id),180);
  }catch(e){console.error(e);toast(tr('overlayFailed',{error:e?.message||e}))}
}
function openOverlayPermissionSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('overlayPermissionTitle')}</h2><p>${tr('overlayPermissionText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>Redacted Overlay</b><span>${tr('deepLinkOnly')}</span></div></div>
    <div class="actions"><button class="primary allowoverlay">${tr('overlayPermissionButton')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('overlayPermissionWaiting')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.allowoverlay',sh).onclick=async()=>{try{await MissionOverlay.requestPermission();toast(tr('overlayPermissionWaiting'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
}
async function resumePendingPlayOverlay(){
  if(!Capacitor.isNativePlatform())return;
  const raw=localStorage.getItem(PLAY_PENDING_KEY);if(!raw)return;
  try{
    const p=await MissionOverlay.hasPermission();if(!p?.granted)return;
    const session=JSON.parse(raw);
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    closeSheet();toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions?.[session.currentIndex||0]?.id),180);
  }catch(e){console.warn('pending overlay',e)}
}
async function stopPlayOverlay(){
  const session=loadPlaySession();let native={};try{native=await overlayState()}catch{}
  if(session){let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}upsertPlayHistory(session,{currentIndex:Number(native?.currentIndex??session.currentIndex??0),doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});}
  try{if(Capacitor.isNativePlatform())await MissionOverlay.stop()}catch(e){console.warn(e)}
  localStorage.removeItem(PLAY_SESSION_KEY);localStorage.removeItem(PLAY_PENDING_KEY);toast(tr('stopBanner'));
}
function bannerCardHtml(b){
  const img=bannergressImage(b.picture||'');
  const fav=isBannerFavorite(b.id);
  const id=escapeAttr(String(b.id));
  return `<div class="bannergressCardWrap">
    <button class="bannergressCard" data-banner-id="${id}">
      <span class="bannerPic">${img?`<img src="${escapeAttr(img)}" alt="">`:'<span>🐊</span>'}</span>
      <span class="bannerCardCopy"><b>${escapeHtml(b.title||tr('unnamed'))}</b><small>${escapeHtml(b.formattedAddress||tr('addressUnknown'))}</small>${b.author?`<small class="bannerAuthorLine">${escapeHtml(tr('bannerAuthor',{author:b.author}))}</small>`:''}<em>${tr('missionsCount',{n:b.numberOfMissions||0})} · ${formatBannerDistance(b.lengthMeters)}${Number.isFinite(Number(b.searchDistanceMeters))?` · 📍 ${formatBannerDistance(b.searchDistanceMeters)}`:''}</em></span>
      <span class="bannerFavState">${fav?'★':'›'}</span>
    </button>
    <button class="bannerStatsBtn" data-banner-stats-id="${id}">${tr('showUselessStats')}</button>
    <div class="bannerSearchStats" hidden></div>
  </div>`;
}
async function openBannerDetail(summary,opts={}){
  let detail=summary;
  try{detail=await fetchBannerDetail(summary)}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}));return}
  const fav=isBannerFavorite(detail.id),todo=isBannerTodo(detail.id),img=bannergressImage(detail.picture);
  const startIndex=clamp(Number(opts.startIndex)||0,0,Math.max(0,detail.missions.length-1));const hasMap=!!bannerStartPoint(detail);
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(detail.title)}</h2><p>${escapeHtml(detail.formattedAddress||tr('addressUnknown'))}${detail.author?` · ${escapeHtml(tr('bannerAuthor',{author:detail.author}))}`:''}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${opts.fromShare?`<div class="groupJoinNotice">🐊 <b>${tr('joinAtMission',{n:startIndex+1})}</b><span>${tr('groupNoServer')}</span></div>`:''}
    <div class="bannerDetailHero">${img?`<img src="${escapeAttr(img)}" alt="">`:''}<div><b>${tr('missionsCount',{n:detail.missions.length||detail.numberOfMissions})}</b><span>${formatBannerDistance(detail.lengthMeters)}</span>${detail.numberOfDisabledMissions?`<small>${tr('bannerDisabled',{n:detail.numberOfDisabledMissions})}</small>`:''}</div></div>
    <div class="bannerDetailStats">${bannerFunStatsHtml(detail,{loading:true})}</div>
    <div class="actions"><button class="primary playbanner" ${detail.missions.length?'':'disabled'}>▶ ${opts.fromShare?tr('joinAtMission',{n:startIndex+1}):tr('playThisBanner')}</button></div>
    <div class="bannerUtilityGrid"><button class="secondary mapbanner" ${hasMap?'':'disabled'}>🗺 ${tr('openMap')}</button><button class="secondary navstart" ${hasMap?'':'disabled'}>📍 ${tr('navigateStart')}</button><button class="secondary sharebanner">▦ ${tr('shareGroup')}</button></div>
    <div class="bannerUtilityGrid two"><button class="secondary favbanner">${fav?'★ '+tr('removeFavorite'):'☆ '+tr('favorite')}</button><button class="secondary todobanner">${todo?'✓ '+tr('removeTodo'):'+ '+tr('addTodo')}</button></div>
    <div class="missionPreviewList">${detail.missions.slice(0,18).map((m,i)=>`<div class="${i===startIndex?'current':''}"><b>${String(i+1).padStart(2,'0')}</b><span>${escapeHtml(m.title)}</span></div>`).join('')}${detail.missions.length>18?`<small>+ ${detail.missions.length-18}</small>`:''}</div>
    <div class="rule"><span class="dot"></span><span>${tr('publicOnly')} · ${tr('deepLinkOnly')}</span></div>`);
  $('.close',sh).onclick=()=>openPlayHub(opts.returnTab||'search');
  $('.playbanner',sh).onclick=()=>startPlaySession(detail,startIndex);
  $('.mapbanner',sh).onclick=()=>openBannerMap(detail);$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharebanner',sh).onclick=()=>openGroupShareSheet(detail,startIndex);
  $('.favbanner',sh).onclick=()=>{if(isBannerFavorite(detail.id))unfavoriteBanner(detail.id);else favoriteBanner(detail);closeSheet();openBannerDetail(detail,{...opts})};
  $('.todobanner',sh).onclick=()=>{if(isBannerTodo(detail.id))removeBannerTodo(detail.id);else addBannerTodo(detail);closeSheet();openBannerDetail(detail,{...opts})};
  renderBannerWalkingStats($('.bannerDetailStats',sh),detail);
}


const BANNER_SEARCH_PREFS_KEY='rbl-bannergress-search-v3';
const BANNER_SEARCH_OLD_PREFS_KEY='rbl-bannergress-search-v2';
function loadBannerSearchPrefs(){
  try{
    const current=JSON.parse(localStorage.getItem(BANNER_SEARCH_PREFS_KEY)||'null');
    if(current&&typeof current==='object')return current;
    const old=JSON.parse(localStorage.getItem(BANNER_SEARCH_OLD_PREFS_KEY)||'{}')||{};
    return {query:old.query||'',city:old.city||'',nearMe:!!old.nearMe,radiusKm:5};
  }catch{return{radiusKm:5}}
}
function saveBannerSearchPrefs(p){localStorage.setItem(BANNER_SEARCH_PREFS_KEY,JSON.stringify(p||{}));markBackupChanged()}
function normalizeTextMatch(v=''){
  return String(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim().replace(/[’'`´]/g,' ').replace(/[-_/.,;:()]+/g,' ').replace(/\s+/g,' ');
}
function canonicalCityKey(v=''){
  return normalizeTextMatch(v).replace(/\bste\b/g,'sainte').replace(/\bst\b/g,'saint').replace(/\s+/g,' ').trim();
}
function citySearchVariants(city=''){
  const raw=String(city||'').trim();if(!raw)return[];
  const expanded=raw.replace(/\bSte\.?(?=\s|-|$)/gi,'Sainte').replace(/\bSt\.?(?=\s|-|$)/gi,'Saint').replace(/[’'`´]/g,' ');
  const spaced=expanded.replace(/-/g,' ').replace(/\s+/g,' ').trim();
  const hyphen=spaced.split(' ').filter(Boolean).join('-');
  const abbreviated=spaced.replace(/^Sainte\b/i,'Ste').replace(/^Saint\b/i,'St');
  const variants=[raw,expanded,spaced,hyphen,abbreviated,abbreviated.replace(/\s+/g,'-')];
  return [...new Set(variants.map(x=>x.trim()).filter(Boolean))];
}
function placeMatchValues(p){return [p?.shortName,p?.name,p?.formattedAddress,p?.title,p?.displayName].filter(Boolean)}
function placeDisplayLabel(p,fallback=''){return String(p?.formattedAddress??p?.displayName??p?.name??p?.shortName??fallback)}
function placeCenter(p){
  if(!p)return null;
  for(const candidate of [p.center,p.location,p.point,p]){
    const direct=normalizeGeoPoint(candidate);if(direct)return direct;
  }
  const minLat=Number(p.boundaryMinLatitude??p.minLatitude??p.bounds?.minLatitude??p.bounds?.south);
  const maxLat=Number(p.boundaryMaxLatitude??p.maxLatitude??p.bounds?.maxLatitude??p.bounds?.north);
  const minLng=Number(p.boundaryMinLongitude??p.minLongitude??p.bounds?.minLongitude??p.bounds?.west);
  const maxLng=Number(p.boundaryMaxLongitude??p.maxLongitude??p.bounds?.maxLongitude??p.bounds?.east);
  if([minLat,maxLat,minLng,maxLng].every(Number.isFinite))return {latitude:(minLat+maxLat)/2,longitude:(minLng+maxLng)/2};
  const lat=Number(p.centerLatitude??p.latitude??p.lat),lng=Number(p.centerLongitude??p.longitude??p.lng??p.lon);
  return Number.isFinite(lat)&&Number.isFinite(lng)?{latitude:lat,longitude:lng}:null;
}
async function resolveBannergressPlace(city){
  const q=String(city||'').trim();if(!q)return null;
  const variants=citySearchVariants(q),found=new Map();
  for(const variant of variants){
    const u=`${BANNERGRESS_API}/places?used=true&collapsePlaces=true&query=${encodeURIComponent(variant)}&limit=40&offset=0`;
    const r=await fetch(u,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const raw=await r.json();
    const list=Array.isArray(raw)?raw:(Array.isArray(raw?.items)?raw.items:(Array.isArray(raw?.results)?raw.results:(Array.isArray(raw?.data)?raw.data:[])));
    for(const p of list){const key=String(p?.id??p?.placeId??placeMatchValues(p)[0]??Math.random());if(!found.has(key))found.set(key,p)}
    if(found.size&&variant!==q)break;
  }
  const list=[...found.values()];if(!list.length)return null;
  const target=canonicalCityKey(q);
  const score=p=>{
    const vals=placeMatchValues(p).map(canonicalCityKey);
    if(vals.some(x=>x===target))return 0;
    if(vals.some(x=>x.startsWith(target)||target.startsWith(x)))return 1;
    if(vals.some(x=>x.includes(target)||target.includes(x)))return 2;
    return 3;
  };
  return list.sort((a,b)=>score(a)-score(b))[0]||null;
}
function locationError(code,message=''){
  const e=new Error(message||String(code));e.locationCode=code;return e;
}
async function nativeLocationStatus(){
  if(!Capacitor.isNativePlatform())return null;
  try{return await LocationStatus.getStatus()}catch(e){console.warn('LocationStatus',e);return null}
}
async function openNativeLocationSettings(kind='location'){
  if(!Capacitor.isNativePlatform())return false;
  try{if(kind==='app')await LocationStatus.openAppSettings();else await LocationStatus.openLocationSettings();return true}catch(e){console.warn('location settings',e);return false}
}
async function getCurrentBannerPosition(){
  if(!navigator.geolocation)throw locationError('UNSUPPORTED','géolocalisation indisponible');
  const native=await nativeLocationStatus();
  if(native&&native.enabled===false)throw locationError('LOCATION_DISABLED',tr('locationDisabled'));
  if(navigator.permissions?.query){
    try{const perm=await navigator.permissions.query({name:'geolocation'});if(perm.state==='denied')throw locationError('PERMISSION_DENIED',tr('locationPermissionDenied'))}catch(e){if(e?.locationCode)throw e}
  }
  return new Promise((resolve,reject)=>{
    navigator.geolocation.getCurrentPosition(
      p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy}),
      e=>{
        if(e?.code===1)reject(locationError('PERMISSION_DENIED',tr('locationPermissionDenied')));
        else if(e?.code===2)reject(locationError('UNAVAILABLE',tr('locationUnavailable')));
        else if(e?.code===3)reject(locationError('TIMEOUT',tr('locationTimeout')));
        else reject(locationError('UNKNOWN',e?.message||`code ${e?.code||'?'}`));
      },
      {enableHighAccuracy:true,maximumAge:120000,timeout:8000}
    );
  });
}
function searchRadiusBounds(position,radiusKm){
  if(!position)return null;
  const km=Math.max(1,Number(radiusKm)||5),lat=Number(position.latitude),lng=Number(position.longitude);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  const latDelta=km/111.32,cos=Math.max(.08,Math.cos(lat*Math.PI/180)),lngDelta=km/(111.32*cos);
  return {minLatitude:lat-latDelta,maxLatitude:lat+latDelta,minLongitude:lng-lngDelta,maxLongitude:lng+lngDelta};
}
function buildBannergressSearchUrl({query='',position=null,radiusKm=5,placeId=''}){
  const u=new URL(`${BANNERGRESS_API}/bnrs`);
  u.searchParams.set('online','true');u.searchParams.set('limit','80');u.searchParams.set('offset','0');
  if(query.trim())u.searchParams.set('query',query.trim());
  if(placeId)u.searchParams.set('placeId',placeId);
  if(position){
    u.searchParams.set('orderBy','proximityStartPoint');u.searchParams.set('orderDirection','ASC');
    u.searchParams.set('proximityLatitude',String(position.latitude));u.searchParams.set('proximityLongitude',String(position.longitude));
    const bounds=searchRadiusBounds(position,radiusKm);
    if(bounds)for(const [key,value] of Object.entries(bounds))u.searchParams.set(key,String(value));
  }else if(query.trim()){
    u.searchParams.set('orderBy','relevance');u.searchParams.set('orderDirection','DESC');
  }else{
    u.searchParams.set('orderBy','created');u.searchParams.set('orderDirection','DESC');
  }
  return u.toString();
}
async function hydrateSearchStartPoints(list){
  const out=[...list],missing=[];
  out.forEach((b,i)=>{if(!bannerStartPoint(b))missing.push(i)});
  const concurrency=5;
  for(let start=0;start<missing.length;start+=concurrency){
    await Promise.all(missing.slice(start,start+concurrency).map(async i=>{
      try{const detail=await fetchBannerDetail(out[i]);out[i]={...out[i],startPoint:bannerStartPoint(detail)||detail.startPoint||null}}catch(e){console.warn('banner location',out[i]?.id,e)}
    }));
  }
  return out;
}
async function filterBannersByRadius(list,center,radiusKm){
  if(!center)return list;
  const hydrated=await hydrateSearchStartPoints(list),maxMeters=Math.max(1,Number(radiusKm)||5)*1000;
  return hydrated.map(b=>{
    const point=bannerStartPoint(b),distance=point?haversine(center,point):Infinity;
    return {...b,searchDistanceMeters:distance};
  }).filter(b=>Number.isFinite(b.searchDistanceMeters)&&b.searchDistanceMeters<=maxMeters+25).sort((a,b)=>a.searchDistanceMeters-b.searchDistanceMeters);
}
function locationErrorText(e){
  switch(e?.locationCode){
    case 'LOCATION_DISABLED':return tr('locationDisabled');
    case 'PERMISSION_DENIED':return tr('locationPermissionDenied');
    case 'UNAVAILABLE':return tr('locationUnavailable');
    case 'TIMEOUT':return tr('locationTimeout');
    default:return tr('locationError',{error:e?.message||e});
  }
}
function historyCardHtml(h){
  const total=Math.max(1,Number(h.total||h.numberOfMissions||1)),done=Math.min(total,Number(h.doneCount||0));const complete=done>=total;
  return `<button class="playHistoryCard" data-history-id="${escapeAttr(String(h.bannerId))}"><span class="historyState">${complete?'✓':'▶'}</span><span><b>${escapeHtml(h.title||tr('unnamed'))}</b><small>${formatPlayDate(h.startedAt)} · ${done}/${total}</small><em>${formatPlayDuration(activeDurationMs(h))} · ~${formatBannerDistance(estimatedPlayedMeters(h))}</em></span><strong>${complete?tr('completedBanner'):tr('resumeFromHistory')}</strong></button>`;
}
async function openHistoryBanner(h){
  try{const d=await fetchBannerDetail({id:h.bannerId,title:h.title,formattedAddress:h.formattedAddress,lengthMeters:h.lengthMeters,picture:h.picture,author:h.author,numberOfMissions:h.total});openBannerDetail(d,{startIndex:h.doneCount>=h.total?0:clamp(h.currentIndex,0,d.missions.length-1),returnTab:'history'})}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}))}
}
function playStatsHtml(entry){
  const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1)),done=Math.min(total,Number(entry?.doneCount||0));
  return `<div class="playStats"><b>${tr('playStats')}</b><div><span>${tr('startedAt')}</span><strong>${formatPlayDate(entry?.startedAt)}</strong></div><div><span>${tr('elapsed')}</span><strong>${formatPlayDuration(activeDurationMs(entry))}</strong></div><div><span>${tr('estimatedDistance')}</span><strong>~${formatBannerDistance(estimatedPlayedMeters(entry))}</strong></div><div><span>${tr('missionsDone')}</span><strong>${done}/${total}</strong></div>${entry?.finishedAt?`<div><span>${tr('finishedAt')}</span><strong>${formatPlayDate(entry.finishedAt)}</strong></div>`:''}</div>`;
}
async function renderPlayTab(sh,tab){
  const body=$('.playHubBody',sh);if(!body)return;
  if(tab==='todo'){
    const list=loadBannerTodo();body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">＋<b>${tr('noTodo')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b,{returnTab:'todo'}));return;
  }
  if(tab==='history'){
    const list=loadPlayHistory();body.innerHTML=list.length?`<div class="playHistoryList">${list.map(historyCardHtml).join('')}</div>`:`<div class="emptyPlayState">◷<b>${tr('noHistory')}</b></div>`;
    $$('.playHistoryCard',body).forEach(btn=>{btn.onclick=()=>{const h=list.find(x=>String(x.bannerId)===btn.dataset.historyId);if(h)openHistoryBanner(h)}});return;
  }
  if(tab==='favorites'){
    const list=loadBannerFavorites();
    body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">☆<b>${tr('noFavorites')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b));return;
  }
  if(tab==='current'){
    const session=loadPlaySession();const native=await overlayState();
    if(!session){body.innerHTML=`<div class="emptyPlayState">🦖<b>${tr('noPlaySession')}</b></div>`;return}
    let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}
    const index=clamp(Number(native?.currentIndex??session.currentIndex??0),0,Math.max(0,session.missions.length-1));
    const hist=upsertPlayHistory(session,{currentIndex:index,doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});
    body.innerHTML=`<div class="currentPlayCard"><div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>${escapeHtml(session.title)}</b><span>${tr('doneMissions',{done:done.length,total:session.missions.length})}</span></div></div>
      <div class="currentMissionLine"><strong>${index+1}/${session.missions.length}</strong><span>${escapeHtml(session.missions[index]?.title||tr('missionLabel',{n:index+1}))}</span></div>
      ${playStatsHtml(hist)}
      <div class="actions"><button class="primary resumeplay">▶ ${tr('resumeBanner')}</button><button class="secondary opencurrent">${tr('openCurrentMission')}</button></div>
      <div class="bannerUtilityGrid"><button class="secondary currentmap">🗺 ${tr('openMap')}</button><button class="secondary currentnav">📍 ${tr('navigateStart')}</button><button class="secondary currentshare">▦ ${tr('shareProgress')}</button></div>
      <button class="danger stopplay">${tr('stopBanner')}</button></div>`;
    $('.resumeplay',body).onclick=()=>startPlaySession(session,index);
    $('.opencurrent',body).onclick=()=>openIngressMission(session.missions[index]?.id);
    $('.currentmap',body).onclick=()=>openBannerMap({...session,id:session.bannerId,formattedAddress:session.address});
    $('.currentnav',body).onclick=()=>navigateToBannerStart({...session,id:session.bannerId});
    $('.currentshare',body).onclick=()=>openGroupShareSheet({...session,id:session.bannerId},index);
    $('.stopplay',body).onclick=async()=>{await stopPlayOverlay();openPlayHub('current')};return;
  }

  const prefs=loadBannerSearchPrefs();
  let nearMe=!!prefs.nearMe;
  let position=null;
  const initialRadius=clamp(Number(prefs.radiusKm)||5,1,50);
  body.innerHTML=`<div class="bannerSearchBox bannerSearchAdvanced">
      <div class="bannerSearchHeading"><div><b>${tr('searchBannergress')}</b><span>${tr('searchPrompt')}</span></div><span>BG</span></div>
      <div class="field bannerSearchField"><label>${tr('bannerNameSearch')}</label><input class="bannerNameInput" placeholder="${escapeAttr(tr('searchPlaceholder'))}" value="${escapeAttr(prefs.query||'')}"></div>
      <div class="field bannerSearchField"><label>${tr('citySearch')}</label><input class="bannerCityInput" placeholder="${escapeAttr(tr('cityPlaceholder'))}" value="${escapeAttr(prefs.city||'')}" ${nearMe?'disabled':''}></div>
      <button class="nearMeButton ${nearMe?'on':''}" type="button">📍 <span>${nearMe?tr('nearMeOn'):tr('nearMe')}</span></button>
      <small class="nearMeHelp">${tr('nearMeHint')}</small>
      <div class="bannerRadiusBox">
        <div class="bannerRadiusHead"><label>${tr('searchRadius')}</label><strong class="bannerRadiusValue">${initialRadius} km</strong></div>
        <input class="bannerRadiusRange" type="range" min="1" max="50" step="1" value="${initialRadius}">
        <small>${tr('radiusHint')}</small>
      </div>
      <button class="secondary bannerLocationSettings" type="button" hidden>⚙ ${tr('openLocationSettings')}</button>
      <div class="bannerSearchActions"><button class="secondary bannerSearchReset">${tr('searchReset')}</button><button class="primary bannerSearchBtn">${icon('search')} ${tr('search')}</button></div>
      <div class="bannerSearchStatus"></div>
    </div><div class="bannerSearchResults"></div>`;

  const qInput=$('.bannerNameInput',body),cityInput=$('.bannerCityInput',body),radiusInput=$('.bannerRadiusRange',body),radiusValue=$('.bannerRadiusValue',body);
  const nearBtn=$('.nearMeButton',body),status=$('.bannerSearchStatus',body),results=$('.bannerSearchResults',body),settingsBtn=$('.bannerLocationSettings',body);
  let locationSettingsKind='location';
  const setStatus=(txt,cls='')=>{status.textContent=txt||'';status.className='bannerSearchStatus '+cls};
  const radiusKm=()=>clamp(Number(radiusInput.value)||5,1,50);
  const savePrefs=()=>saveBannerSearchPrefs({query:qInput.value,city:cityInput.value,nearMe,radiusKm:radiusKm()});
  const updateRadius=()=>{radiusValue.textContent=`${radiusKm()} km`;const active=nearMe||!!cityInput.value.trim();radiusInput.disabled=!active;$('.bannerRadiusBox',body)?.classList.toggle('disabled',!active);savePrefs()};
  const hideLocationAction=()=>{settingsBtn.hidden=true};
  const showLocationError=e=>{
    setStatus(locationErrorText(e),'error');
    if(Capacitor.isNativePlatform()&&['LOCATION_DISABLED','UNAVAILABLE','TIMEOUT','PERMISSION_DENIED'].includes(e?.locationCode)){
      locationSettingsKind=e?.locationCode==='PERMISSION_DENIED'?'app':'location';
      settingsBtn.textContent=`⚙ ${tr(locationSettingsKind==='app'?'openAppSettings':'openLocationSettings')}`;settingsBtn.hidden=false;
    }
  };
  settingsBtn.onclick=()=>openNativeLocationSettings(locationSettingsKind);

  const acquirePosition=async()=>{
    hideLocationAction();setStatus(tr('locationChecking'),'loading');
    const pos=await getCurrentBannerPosition();position=pos;setStatus(`${tr('locationReady')}${Number.isFinite(pos.accuracy)?` · ±${Math.round(pos.accuracy)} m`:''}`,'ok');return pos;
  };
  const toggleNear=async()=>{
    nearMe=!nearMe;position=null;cityInput.disabled=nearMe;nearBtn.classList.toggle('on',nearMe);
    $('span',nearBtn).textContent=nearMe?tr('nearMeOn'):tr('nearMe');hideLocationAction();updateRadius();savePrefs();
    if(nearMe){try{await acquirePosition()}catch(e){showLocationError(e)}}else setStatus('');
  };
  nearBtn.onclick=toggleNear;
  radiusInput.oninput=updateRadius;
  cityInput.addEventListener('input',updateRadius);
  updateRadius();

  const run=async()=>{
    const query=qInput.value.trim(),city=cityInput.value.trim();savePrefs();hideLocationAction();
    if(!query&&!city&&!nearMe){setStatus(tr('searchCriteriaRequired'),'error');results.innerHTML='';return}
    results.innerHTML=`<div class="loadingPlay">${tr('searching')}</div>`;setStatus('');
    try{
      let place=null,searchCenter=null;
      if(nearMe){if(!position)await acquirePosition();searchCenter=position}
      if(city&&!nearMe){
        setStatus(tr('cityResolving'),'loading');place=await resolveBannergressPlace(city);
        if(!place){results.innerHTML='';setStatus(tr('cityNotFound',{city}),'error');return}
        searchCenter=placeCenter(place);
        if(!searchCenter){results.innerHTML='';setStatus(tr('cityNoCoordinates',{city:placeDisplayLabel(place,city)}),'error');return}
        setStatus(tr('cityUsingRadius',{city:placeDisplayLabel(place,city),radius:radiusKm()}),'ok');
      }
      const url=buildBannergressSearchUrl({query,position:searchCenter,radiusKm:radiusKm()});
      const r=await fetch(url,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
      let list=unwrapBannerSearch(await r.json()).map(b=>normalizeBannerDetail(b,b));
      if(searchCenter)list=await filterBannersByRadius(list,searchCenter,radiusKm());
      const filterBits=[];if(query)filterBits.push(`“${query}”`);if(city&&!nearMe)filterBits.push(placeDisplayLabel(place,city));if(nearMe)filterBits.push('📍');if(searchCenter)filterBits.push(`≤ ${radiusKm()} km`);
      const countText=searchCenter?tr('radiusResults',{n:list.length,radius:radiusKm()}):tr('resultsCount',{n:list.length});
      setStatus(`${countText}${filterBits.length?' · '+filterBits.join(' · '):''}`,list.length?'ok':'');
      results.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">⌕<b>0</b></div>`;
      bindBannerList(results,list,b=>openBannerDetail(b));
    }catch(e){console.error(e);if(e?.locationCode)showLocationError(e);else setStatus(tr('searchError',{error:e?.message||e}),'error');results.innerHTML=''}
  };
  $('.bannerSearchBtn',body).onclick=run;
  $('.bannerSearchReset',body).onclick=()=>{qInput.value='';cityInput.value='';radiusInput.value='5';nearMe=false;position=null;cityInput.disabled=false;nearBtn.classList.remove('on');$('span',nearBtn).textContent=tr('nearMe');hideLocationAction();updateRadius();savePrefs();setStatus('');results.innerHTML=''};
  [qInput,cityInput].forEach(inp=>inp.addEventListener('keydown',e=>{if(e.key==='Enter')run()}));
  setTimeout(()=>qInput.focus(),80);
}
function openPlayHub(tab='search'){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('playHub')}</h2><p>${tr('publicOnly')} · ${tr('deepLinkOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playTabs"><button data-playtab="search" class="${tab==='search'?'on':''}">${icon('search')} ${tr('search')}</button><button data-playtab="todo" class="${tab==='todo'?'on':''}">＋ ${tr('todo')}</button><button data-playtab="favorites" class="${tab==='favorites'?'on':''}">${icon('star')} ${tr('favorites')}</button><button data-playtab="current" class="${tab==='current'?'on':''}">🐊 ${tr('inProgress')}</button><button data-playtab="history" class="${tab==='history'?'on':''}">◷ ${tr('history')}</button></div>
    <div class="playHubBody"></div>`);
  $('.close',sh).onclick=closeSheet;
  $$('[data-playtab]',sh).forEach(btn=>btn.onclick=()=>openPlayHub(btn.dataset.playtab));
  renderPlayTab(sh,tab);
}



let studioEditorRoot=null,studioCanvasHome=null,studioZoom=1,studioOrientationLocked=false,studioPanMode=false,studioFitMode='six',studioViewScale=1;
function studioActiveLayer(){return activeImageLayer()}
function studioActiveText(){return state.active.startsWith('text:')?state.texts.find(t=>t.id===state.active.slice(5))||null:null}
function studioLayerClass(l){const g=groupInfoForLayer(l);return g?` groupColor${g.color}`:''}
function studioLayerRowsHtml(){
  normalizeLayerGroups();
  const rows=[...state.imageLayers].map((l,i)=>({l,i})).reverse().map(({l,i})=>{
    const active=state.active==='image:'+l.id,g=groupInfoForLayer(l),top=i===state.imageLayers.length-1,bottom=i===0;
    return `<div class="studioLayerRow${active?' active':''}${l.visible===false?' hidden':''}${studioLayerClass(l)}" data-studio-layer="${escapeAttr(l.id)}">
      <label class="studioGroupCheck" title="${tr('multiSelection')}"><input type="checkbox" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="studioLayerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:g?'▱':'▧',alt:imageLayerLabel(l,i),studio:true})}<span><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:`${l.image?.naturalWidth||0} × ${l.image?.naturalHeight||0}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}`}</small></span></button>
      <button class="studioEye" type="button">${l.visible===false?'◌':'◉'}</button>
      <div class="studioLayerOrder"><button type="button" class="studioDown" ${bottom?'disabled':''}>↓</button><button type="button" class="studioUp" ${top?'disabled':''}>↑</button></div>
    </div>`;
  }).join('');
  return `${rows}<div class="studioLayerRow background${state.active==='background'?' active':''}${state.bg.visible===false?' hidden':''}"><span class="studioGroupLock">⌄</span><button class="studioLayerSelect studioBackground" type="button">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer'),studio:true})}<span><b>${tr('backgroundLayer')}</b><small>${state.bg.image?`${state.bg.image.naturalWidth} × ${state.bg.image.naturalHeight}`:tr('backgroundMissing')}</small></span></button><button class="studioEye studioBackgroundEye" type="button">${state.bg.visible===false?'◌':'◉'}</button><span class="studioLock">🔒</span></div>`;
}
function studioTextRowsHtml(){
  if(!state.texts.length)return `<div class="studioNoLayer">${tr('studioNoText')}</div>`;
  return state.texts.map((t,i)=>`<div class="studioTextRow${state.active==='text:'+t.id?' active':''}" data-studio-text="${escapeAttr(t.id)}"><button class="studioTextSelect" type="button"><span class="studioLayerGlyph">T</span><span><b>${escapeHtml((t.text||tr('text')).slice(0,42))}</b><small>${tr('size')} ${Math.round(t.fontSize||180)} · ${tr('rotation')} ${Math.round((t.rotation||0)*180/Math.PI)}°</small></span></button><button class="studioTextDelete" type="button">${icon('trash')}</button></div>`).join('');
}
function studioAddTextNow(){
  const before=beginHistory();const t=textDefaults({id:uid(),text:'I LOVE REDACTED',x:WORLD_W/2,y:worldH()/2,fontSize:180,color:'#ffffff',strokeColor:'#07100c',strokeWidth:14,scale:1,rotation:0});state.texts.push(t);setActive('text:'+t.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();
}
function studioDuplicateText(id){const src=state.texts.find(t=>t.id===id);if(!src)return;const before=beginHistory(),copy={...src,id:uid(),x:(src.x||0)+24,y:(src.y||0)+24,text:src.text||tr('text')};state.texts.push(copy);setActive('text:'+copy.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();}
function studioDeleteText(id){const t=state.texts.find(x=>x.id===id);if(!t)return;const before=beginHistory();state.texts=state.texts.filter(x=>x.id!==id);state.active='background';commitHistory(before,tr('histDeleteText'));scheduleSave();render();refreshStudioEditor();toast(tr('textDeleted'));}
function studioToolsHtml(){
  const txt=studioActiveText();
  if(txt){
    normalizeTextStyle(txt);return `<div class="studioSelectedCard"><b>${escapeHtml((txt.text||tr('text')).slice(0,48))}</b><small>${tr('studioSelected')} · ${tr('text')}</small></div>
      <div class="studioTextQuick">
        <label><span>${tr('text')}</span><input class="studioTextValue" maxlength="120" value="${escapeAttr(txt.text||'')}"></label>
        <div class="studioTypographyTitle">${tr('textTypography')}</div>
        <div class="studioFontLine"><label><span>${tr('font')}</span><select class="studioTextFont">${fontOptionsHtml(txt.fontFamily)}</select></label><button class="secondary studioImportFont" type="button">＋ ${tr('importFont')}</button></div>
        <div class="grid2"><label><span>${tr('size')}</span><input class="studioTextSize" type="number" min="40" max="700" value="${txt.fontSize||180}"></label><label><span>${tr('fontWeight')}</span><select class="studioTextWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${txt.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></label></div>
        <div class="grid2"><label><span>${tr('letterSpacing')}</span><input class="studioTextSpacing" type="number" min="-40" max="160" step="1" value="${txt.letterSpacing||0}"></label><label><span>${tr('lineHeight')}</span><input class="studioTextLineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${txt.lineHeight||1.08}"></label></div>
        <div class="grid2"><label><span>${tr('textAlign')}</span><select class="studioTextAlign"><option value="left" ${txt.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${txt.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${txt.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></label><label class="studioCheckLabel"><span>${tr('fontItalic')}</span><input class="studioTextItalic" type="checkbox" ${txt.fontItalic?'checked':''}></label></div>
        <div class="grid2"><label><span>${tr('outline')}</span><input class="studioTextStroke" type="number" min="0" max="60" value="${txt.strokeWidth??14}"></label><label><span>${tr('color')}</span><input class="studioTextColor" type="color" value="${txt.color||'#ffffff'}"></label></div>
        <label><span>${tr('outlineColor')}</span><input class="studioTextStrokeColor" type="color" value="${txt.strokeColor||'#07100c'}"></label>
        <label class="studioSwitch"><input class="studioTextBgEnabled" type="checkbox" ${txt.backgroundEnabled?'checked':''}><span>${tr('textBackground')}</span></label>
        <div class="studioTextBgFields" ${txt.backgroundEnabled?'':'hidden'}><div class="grid2"><label><span>${tr('textBackgroundColor')}</span><input class="studioTextBgColor" type="color" value="${txt.backgroundColor||'#07100c'}"></label><label><span>${tr('textBackgroundOpacity')}</span><input class="studioTextBgOpacity" type="number" min="0" max="100" value="${Math.round((txt.backgroundOpacity??.72)*100)}"></label></div><div class="grid2"><label><span>${tr('textBackgroundPadding')}</span><input class="studioTextBgPadding" type="number" min="0" max="180" value="${txt.backgroundPadding??24}"></label><label><span>${tr('textBackgroundRadius')}</span><input class="studioTextBgRadius" type="number" min="0" max="240" value="${txt.backgroundRadius??24}"></label></div></div>
      </div>
      <div class="studioToolGrid"><button type="button" class="studioTransform">${icon('move')}<span>${tr('transformText')}</span></button><button type="button" class="studioDuplicateText">${icon('copy')}<span>${tr('studioDuplicateText')}</span></button><button type="button" class="studioDeleteText danger">${icon('trash')}<span>${tr('delete')}</span></button></div>`;
  }
  const l=studioActiveLayer();
  if(!l)return `<div class="studioNoLayer">${tr('studioNoLayer')}</div>`;
  const isBg=l===state.bg,idx=isBg?-1:imageLayerIndex(l.id),g=!isBg?groupInfoForLayer(l):null;
  return `<div class="studioSelectedCard${g?` groupColor${g.color}`:''}"><b>${escapeHtml(isBg?tr('backgroundLayer'):imageLayerLabel(l,idx))}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:tr('studioSelected')}</small></div>
    <label class="studioOpacity"><span>${tr('studioOpacity')}</span><strong>${Math.round((l.opacity??1)*100)}%</strong><input type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></label>
    <div class="studioToolGrid">
      <button type="button" class="studioTransform">${icon('move')}<span>${g?tr('groupTransform'):tr('layerTransform')}</span></button>
      <button type="button" class="studioVisibility">${l.visible===false?'◌':'◉'}<span>${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}</span></button>
      ${isBg?'':`<button type="button" class="studioMoveDown" ${idx===0?'disabled':''}>↓<span>${tr('moveDown')}</span></button><button type="button" class="studioMoveUp" ${idx===state.imageLayers.length-1?'disabled':''}>↑<span>${tr('moveUp')}</span></button><button type="button" class="studioDuplicate">${icon('copy')}<span>${tr('duplicateLayer')}</span></button><button type="button" class="studioRename">${icon('edit')}<span>${tr('renameLayer')}</span></button>${g?`<button type="button" class="studioUngroup">⇱<span>${tr('ungroup')}</span></button>`:''}<button type="button" class="studioDelete danger">${icon('trash')}<span>${tr('deleteLayer')}</span></button>`}
    </div>`;
}
function studioMoveLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;const before=beginHistory();[state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];commitHistory(before,tr('histReorderLayer'));scheduleSave();render();refreshStudioEditor();
}
function studioToggleLayer(id){
  if(id==='background'){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  else{const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  scheduleSave();render();refreshStudioEditor();
}
function studioDeleteLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDeleted'));
}
function studioDuplicateLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDuplicated'));
}
function studioUngroupLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupRemoved'));
}
function studioGroupSelected(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));if(ids.length<2){toast(tr('groupNeedTwo'));return}const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupCreated'));
}
function studioSelectedMissionRc(){return parseMissionKey(state.selectedMissionKey)||rowColForMission(1)}
function studioMissionVisualPosition(rc,scale=studioViewScale){return {left:(worldH()-(rc.row+1)*STEP)*scale,top:rc.col*STEP*scale,size:STEP*scale}}
function studioScrollToSelectedMission(behavior='smooth'){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),rc=studioSelectedMissionRc();if(!sc||!rc)return;const p=studioMissionVisualPosition(rc);sc.scrollTo({left:Math.max(0,p.left-(sc.clientWidth-p.size)/2),top:Math.max(0,p.top-(sc.clientHeight-p.size)/2),behavior});
}
function applyStudioCanvasSize({recenter=false}={}){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),stage=$('.studioCanvasStage',studioEditorRoot);if(!sc||!stage)return;
  const availH=Math.max(220,sc.clientHeight-20),availW=Math.max(220,sc.clientWidth-20);let fit;
  if(studioFitMode==='one')fit=Math.min(availH,availW)/STEP;
  else if(studioFitMode==='all')fit=Math.min(availH/WORLD_W,availW/worldH());
  else fit=availH/WORLD_W;
  studioViewScale=Math.max(.04,fit*studioZoom);
  const cssW=WORLD_W*studioViewScale,cssH=worldH()*studioViewScale,mount=$('.studioCanvasMount',studioEditorRoot);
  stage.style.width=`${Math.round(cssH)}px`;stage.style.height=`${Math.round(cssW)}px`;
  if(mount){mount.style.width=`${Math.max(Math.round(cssH),Math.max(1,sc.clientWidth-20))}px`;mount.style.height=`${Math.max(Math.round(cssW),Math.max(1,sc.clientHeight-20))}px`;}
  canvas.style.width=`${Math.round(cssW)}px`;canvas.style.height=`${Math.round(cssH)}px`;canvas.style.position='absolute';canvas.style.left=`${Math.round(cssH)}px`;canvas.style.top='0';canvas.style.transformOrigin='0 0';canvas.style.transform='rotate(90deg)';
  if(recenter){requestAnimationFrame(()=>{if(studioFitMode==='one')studioScrollToSelectedMission('smooth');else {const scroll=$('.studioScroll',studioEditorRoot),mx=Math.max(0,((mount?.scrollWidth||0)-scroll.clientWidth)/2),my=Math.max(0,((mount?.scrollHeight||0)-scroll.clientHeight)/2);scroll?.scrollTo({left:mx,top:my,behavior:'smooth'})}})}
}
function bindStudioPanels(){
  if(!studioEditorRoot)return;const root=studioEditorRoot;
  $$('.studioLayerRow[data-studio-layer]',root).forEach(row=>{const id=row.dataset.studioLayer;$('.studioLayerSelect',row).onclick=()=>{setEditMode('fresco');setActive('image:'+id);refreshStudioEditor()};$('.studioEye',row).onclick=()=>studioToggleLayer(id);$('.studioDown',row).onclick=()=>studioMoveLayer(id,-1);$('.studioUp',row).onclick=()=>studioMoveLayer(id,1);$('input',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);row.classList.toggle('multiSelected',e.target.checked);const cnt=$('.studioGroupCount',root);if(cnt)cnt.textContent=String(layerGroupSelection.size);const gb=$('.studioGroupNow',root);if(gb)gb.disabled=layerGroupSelection.size<2;const act=$('.studioSelectionActions',root);if(act)act.disabled=layerGroupSelection.size<1};});
  const bg=$('.studioBackground',root),bgEye=$('.studioBackgroundEye',root);if(bg)bg.onclick=()=>{setActive('background');refreshStudioEditor()};if(bgEye)bgEye.onclick=()=>studioToggleLayer('background');
  $$('.studioTextRow[data-studio-text]',root).forEach(row=>{const id=row.dataset.studioText;$('.studioTextSelect',row).onclick=()=>{setEditMode('fresco');setActive('text:'+id);refreshStudioEditor()};$('.studioTextDelete',row).onclick=()=>studioDeleteText(id)});
  const addText=$('.studioAddText',root);if(addText)addText.onclick=studioAddTextNow;
  const groupBtn=$('.studioGroupNow',root);if(groupBtn)groupBtn.onclick=studioGroupSelected;const selectionActions=$('.studioSelectionActions',root);if(selectionActions)selectionActions.onclick=()=>openSelectedLayersActionsSheet({returnToStudio:true});const clear=$('.studioClearGroup',root);if(clear)clear.onclick=()=>{layerGroupSelection.clear();$$('.studioGroupCheck input',root).forEach(cb=>cb.checked=false);$$('.studioLayerRow.multiSelected',root).forEach(row=>row.classList.remove('multiSelected'));const cnt=$('.studioGroupCount',root);if(cnt)cnt.textContent='0';if(groupBtn)groupBtn.disabled=true;if(selectionActions)selectionActions.disabled=true};
  const openFull=$('.studioOpenManager',root);if(openFull)openFull.onclick=()=>{closeStudioEditor();openImageLayersSheet()};
  const txt=studioActiveText();if(txt){
    normalizeTextStyle(txt);const value=$('.studioTextValue',root),size=$('.studioTextSize',root),stroke=$('.studioTextStroke',root),color=$('.studioTextColor',root),strokeColor=$('.studioTextStrokeColor',root),font=$('.studioTextFont',root),weight=$('.studioTextWeight',root),italic=$('.studioTextItalic',root),spacing=$('.studioTextSpacing',root),lineHeight=$('.studioTextLineHeight',root),align=$('.studioTextAlign',root),bgEnabled=$('.studioTextBgEnabled',root),bgColor=$('.studioTextBgColor',root),bgOpacity=$('.studioTextBgOpacity',root),bgPadding=$('.studioTextBgPadding',root),bgRadius=$('.studioTextBgRadius',root);
    const update=()=>{txt.text=value?.value||tr('text');txt.fontSize=clamp(+size?.value||180,40,700);txt.strokeWidth=clamp(+stroke?.value||0,0,60);if(color)txt.color=color.value;if(strokeColor)txt.strokeColor=strokeColor.value;if(font)txt.fontFamily=font.value;if(weight)txt.fontWeight=clamp(+weight.value||800,100,900);if(italic)txt.fontItalic=italic.checked;if(spacing)txt.letterSpacing=clamp(+spacing.value||0,-40,160);if(lineHeight)txt.lineHeight=clamp(+lineHeight.value||1.08,.7,2.4);if(align)txt.textAlign=align.value;if(bgEnabled)txt.backgroundEnabled=bgEnabled.checked;if(bgColor)txt.backgroundColor=bgColor.value;if(bgOpacity)txt.backgroundOpacity=clamp((+bgOpacity.value||0)/100,0,1);if(bgPadding)txt.backgroundPadding=clamp(+bgPadding.value||0,0,180);if(bgRadius)txt.backgroundRadius=clamp(+bgRadius.value||0,0,240);normalizeTextStyle(txt);const fields=$('.studioTextBgFields',root);if(fields)fields.hidden=!txt.backgroundEnabled;render();scheduleSave()};
    [value,size,stroke,color,strokeColor,font,weight,italic,spacing,lineHeight,align,bgEnabled,bgColor,bgOpacity,bgPadding,bgRadius].filter(Boolean).forEach(el=>el.addEventListener(el.type==='checkbox'||el.tagName==='SELECT'?'change':'input',update));
    const imp=$('.studioImportFont',root);if(imp)imp.onclick=()=>importProjectFont(txt,()=>refreshStudioEditor());
    const transform=$('.studioTransform',root),dup=$('.studioDuplicateText',root),del=$('.studioDeleteText',root);if(transform)transform.onclick=()=>openTransformSheet();if(dup)dup.onclick=()=>studioDuplicateText(txt.id);if(del)del.onclick=()=>studioDeleteText(txt.id);return;
  }
  const l=studioActiveLayer();if(!l)return;const isBg=l===state.bg,id=isBg?'background':l.id;const rng=$('.studioOpacity input',root);if(rng){rng.oninput=e=>{l.opacity=+e.target.value/100;$('.studioOpacity strong',root).textContent=`${e.target.value}%`;render();scheduleSave()};}
  const transform=$('.studioTransform',root);if(transform)transform.onclick=()=>openTransformSheet();const vis=$('.studioVisibility',root);if(vis)vis.onclick=()=>studioToggleLayer(id);
  if(!isBg){const down=$('.studioMoveDown',root),up=$('.studioMoveUp',root),dup=$('.studioDuplicate',root),ren=$('.studioRename',root),del=$('.studioDelete',root),ung=$('.studioUngroup',root);if(down)down.onclick=()=>studioMoveLayer(id,-1);if(up)up.onclick=()=>studioMoveLayer(id,1);if(dup)dup.onclick=()=>studioDuplicateLayer(id);if(del)del.onclick=()=>studioDeleteLayer(id);if(ung)ung.onclick=()=>studioUngroupLayer(id);if(ren)ren.onclick=()=>{closeStudioEditor({keepOrientation:true});renameImageLayer(id)};}
}
function refreshStudioEditor(){
  if(!studioEditorRoot)return;normalizeLayerGroups();const left=$('.studioLayerList',studioEditorRoot),texts=$('.studioTextList',studioEditorRoot),right=$('.studioToolsBody',studioEditorRoot);if(left)left.innerHTML=studioLayerRowsHtml();if(texts)texts.innerHTML=studioTextRowsHtml();if(right)right.innerHTML=studioToolsHtml();const cnt=$('.studioGroupCount',studioEditorRoot);if(cnt)cnt.textContent=String(layerGroupSelection.size);const gb=$('.studioGroupNow',studioEditorRoot);if(gb)gb.disabled=layerGroupSelection.size<2;bindStudioPanels();refreshStudioMissionControls();applyStudioCanvasSize();
}
function refreshStudioMissionControls(){
  if(!studioEditorRoot)return;const mission=$('.studioMissionMode',studioEditorRoot),fresco=$('.studioFrescoMode',studioEditorRoot),rc=parseMissionKey(state.selectedMissionKey);
  mission?.classList.toggle('on',state.editMode==='mission');fresco?.classList.toggle('on',state.editMode==='fresco');
  if(mission){const label=$('.studioMissionLabel',mission);if(label)label.textContent=state.editMode==='mission'&&rc?`M${missionNumber(rc.row,rc.col)}`:tr('studioMissionMode');mission.title=state.editMode==='mission'&&rc?tr('missionSelected',{n:missionNumber(rc.row,rc.col)}):tr('tapMedallion');}
}
async function requestStudioFullscreen(){if(!studioEditorRoot)return;try{if(document.documentElement.requestFullscreen&&!document.fullscreenElement)await document.documentElement.requestFullscreen()}catch{}setTimeout(()=>applyStudioCanvasSize(),160)}
function studioToggleDrawer(selector){if(!studioEditorRoot)return;const target=$(selector,studioEditorRoot);$$('.studioDrawer',studioEditorRoot).forEach(d=>{if(d!==target)d.classList.remove('open')});target?.classList.toggle('open')}
function openStudioEditor(){
  if(!requireFrescoFlow())return;setEditMode('fresco');if(studioEditorRoot)return;closeSheet();studioZoom=1;studioFitMode='six';studioPanMode=false;
  studioCanvasHome={parent:canvas.parentNode,next:canvas.nextSibling};const root=document.createElement('div');root.className='studioEditorBack';root.innerHTML=`<div class="studioTop"><button class="studioClose" type="button">${icon('close')}</button><div class="studioTitle"><b>${tr('studioTitle')}</b><small>${state.rows*6} ${tr('missions').toLowerCase()} · ${tr('studioRotateHint')}</small></div><div class="studioZoom"><button type="button" class="studioMissionMode" title="${tr('tapMedallion')}">🎯 <span class="studioMissionLabel">${tr('studioMissionMode')}</span></button><button type="button" class="studioFrescoMode on" title="${tr('studioFrescoMode')}">◎ <span>${tr('studioFrescoMode')}</span></button><button type="button" class="studioZoomOut" title="−">−</button><button type="button" class="studioZoomIn" title="＋">＋</button><button type="button" class="studioPan" title="${tr('studioPan')}">✋</button><button type="button" class="studioFullscreen" title="${tr('studioFullscreen')}" aria-label="${tr('studioFullscreen')}">⛶</button></div></div><div class="studioBody"><div class="studioScroll"><div class="studioCanvasMount"><div class="studioCanvasStage"></div></div></div><button class="studioEdge studioEdgeLeft" type="button">${icon('layers')}<span>${tr('studioLayers')}</span></button><button class="studioEdge studioEdgeText" type="button">${icon('text')}<span>${tr('studioTexts')}</span></button><button class="studioEdge studioEdgeRight" type="button">${icon('move')}<span>${tr('studioTools')}</span></button><aside class="studioDrawer studioDrawerLeft"><div class="studioDrawerHead"><b>${tr('studioLayers')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioLayerActions"><button class="studioAddLayer primary" type="button">＋ ${tr('addLayerChoiceTitle')}</button><button class="studioOpenManager secondary" type="button">⋯ ${tr('layersTitle')}</button></div><div class="studioLayerList"></div><div class="studioGroupMini" ${layerGroupSelection.size>=2?'':'hidden'}><span>${tr('multiSelection')} <b class="studioGroupCount">${layerGroupSelection.size}</b></span><div><button class="studioClearGroup" type="button">×</button><button class="studioSelectionActions" type="button" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('editSelection')}</button><button class="studioGroupNow" type="button" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('studioGroupNow')}</button></div></div></aside><aside class="studioDrawer studioDrawerText"><div class="studioDrawerHead"><b>${tr('studioTexts')}</b><button class="studioDrawerClose" type="button">×</button></div><button class="studioAddText primary" type="button">＋ ${tr('studioAddText')}</button><div class="studioTextList"></div></aside><aside class="studioDrawer studioDrawerRight"><div class="studioDrawerHead"><b>${tr('studioTools')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioToolsBody"></div></aside></div>`;document.body.appendChild(root);studioEditorRoot=root;$('.studioCanvasStage',root).appendChild(canvas);canvas.classList.add('studioCanvas');
  $('.studioClose',root).onclick=()=>closeStudioEditor();$('.studioEdgeLeft',root).onclick=()=>studioToggleDrawer('.studioDrawerLeft');$('.studioEdgeText',root).onclick=()=>studioToggleDrawer('.studioDrawerText');$('.studioEdgeRight',root).onclick=()=>studioToggleDrawer('.studioDrawerRight');$$('.studioDrawerClose',root).forEach(b=>b.onclick=()=>b.closest('.studioDrawer').classList.remove('open'));
  $('.studioMissionMode',root).onclick=()=>{studioPanMode=false;root.classList.remove('panMode');canvas.style.pointerEvents='';$('.studioPan',root).classList.remove('on');setEditMode('mission');refreshStudioMissionControls();};
  $('.studioFrescoMode',root).onclick=()=>{setEditMode('fresco');studioFitMode='all';studioZoom=1;applyStudioCanvasSize({recenter:true});refreshStudioMissionControls();};
  $('.studioZoomOut',root).onclick=()=>{studioZoom=clamp(studioZoom-.2,.35,4);applyStudioCanvasSize()};$('.studioZoomIn',root).onclick=()=>{studioZoom=clamp(studioZoom+.2,.35,4);applyStudioCanvasSize()};$('.studioFullscreen',root).onclick=requestStudioFullscreen;$('.studioPan',root).onclick=()=>{studioPanMode=!studioPanMode;root.classList.toggle('panMode',studioPanMode);canvas.style.pointerEvents=studioPanMode?'none':'';$('.studioPan',root).classList.toggle('on',studioPanMode)};$('.studioAddLayer',root).onclick=()=>openAddLayerChoiceSheet({returnToStudio:true});
  refreshStudioEditor();render();setTimeout(()=>{applyStudioCanvasSize({recenter:true});requestStudioFullscreen()},50);window.addEventListener('resize',applyStudioCanvasSize);
}
function closeStudioEditor({keepOrientation=false}={}){
  if(!studioEditorRoot)return;window.removeEventListener('resize',applyStudioCanvasSize);canvas.classList.remove('studioCanvas');canvas.style.width='';canvas.style.height='';canvas.style.pointerEvents='';canvas.style.position='';canvas.style.left='';canvas.style.top='';canvas.style.transform='';canvas.style.transformOrigin='';studioPanMode=false;if(studioCanvasHome?.parent){if(studioCanvasHome.next)studioCanvasHome.parent.insertBefore(canvas,studioCanvasHome.next);else studioCanvasHome.parent.appendChild(canvas)}const root=studioEditorRoot;studioEditorRoot=null;root.remove();if(!keepOrientation){try{screen.orientation?.unlock?.()}catch{}studioOrientationLocked=false;try{if(document.fullscreenElement)document.exitFullscreen()}catch{}}render();
}


let layerGroupSelection=new Set();
function normalizeLayerGroups(){
  const counts=new Map();
  for(const l of state.imageLayers)if(l.groupId)counts.set(l.groupId,(counts.get(l.groupId)||0)+1);
  for(const l of state.imageLayers){
    if(l.groupId&&(counts.get(l.groupId)||0)<2){l.groupId=null;l.groupNumber=null;}
  }
  const validGroups=[...new Set(state.imageLayers.filter(l=>l.groupId).map(l=>l.groupId))];
  const assigned=new Map(),used=new Set();
  for(const gid of validGroups){
    const existing=state.imageLayers.find(l=>l.groupId===gid&&Number.isInteger(+l.groupNumber)&&+l.groupNumber>0&&!used.has(+l.groupNumber));
    if(existing){assigned.set(gid,+existing.groupNumber);used.add(+existing.groupNumber);}
  }
  let next=1;
  for(const gid of validGroups){
    if(!assigned.has(gid)){while(used.has(next))next++;assigned.set(gid,next);used.add(next);}
    const n=assigned.get(gid);for(const l of state.imageLayers)if(l.groupId===gid)l.groupNumber=n;
  }
}
function groupInfoForLayer(l){
  if(!l?.groupId)return null;normalizeLayerGroups();
  const n=Math.max(1,parseInt(l.groupNumber)||1),count=state.imageLayers.filter(x=>x.groupId===l.groupId).length;
  return {number:n,count,color:((n-1)%6)+1,label:tr('groupName',{n})};
}
function missionOptionsHtml(selected=1){const total=state.rows*COLS;return Array.from({length:total},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===+selected?'selected':''}>${tr('missionLabel',{n})}</option>`).join('')}
async function createMissionImageLayer(file,{missionNumber=1,fitMode='cover',name=null}={}){if(!file)return null;if(file.size>45*1024*1024)toast(tr('heavyImage'));const img=await blobToImage(file);const layer={id:uid(),name:name||file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:0,y:0,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'mission',missionNumber:clamp(parseInt(missionNumber)||1,1,state.rows*COLS),fitMode:fitMode==='contain'?'contain':'cover'};fitImageLayer(layer);state.imageLayers.push(layer);return layer}
function openAddLayerChoiceSheet({returnToStudio=!!studioEditorRoot}={}){
  const sh=openSheet(`<div class="sheethead"><div><h2>＋ ${tr('addLayerChoiceTitle')}</h2><p>${tr('addLayerChoiceText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule"><span class="dot"></span><span>${tr('layerScopeHelp')}</span></div><div class="layerScopeChoice"><button class="primary addWholeLayer" type="button"><b>▣ ${tr('addLayerWhole')}</b><small>${tr('addLayerWholeText')}</small></button><button class="secondary addOneMissionLayer" type="button"><b>🎯 ${tr('addLayerOneMission')}</b><small>${tr('addLayerOneMissionText')}</small></button><button class="secondary addManyMissionLayers" type="button"><b>▦ ${tr('addLayerManyMissions')}</b><small>${tr('addLayerManyMissionsText')}</small></button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};
  $('.close',sh).onclick=back;
  $('.addWholeLayer',sh).onclick=()=>{closeSheet();chooseImageFile('layer')};
  $('.addOneMissionLayer',sh).onclick=()=>{closeSheet();chooseMissionLayerFile()};
  $('.addManyMissionLayers',sh).onclick=()=>{closeSheet();chooseMissionSeriesFiles()};
}
function chooseMissionLayerFile(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const file=input.files?.[0];input.remove();if(file)openMissionLayerImportSheet(file,{returnToStudio})};input.click()}
function openMissionLayerImportSheet(file,{returnToStudio=false}={}){const url=URL.createObjectURL(file),defaultMission=1;const sh=openSheet(`<div class="sheethead"><div><h2>🎯 ${tr('addMissionLayer')}</h2><p>${tr('missionLayerHint',{n:defaultMission})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="missionLayerImportPreview"><img src="${escapeAttr(url)}" alt=""><div><b>${escapeHtml(file.name)}</b><small>${Math.round(file.size/1024)} KB</small></div></div><div class="field"><label>${tr('missionTarget')}</label><select class="missionLayerTarget">${missionOptionsHtml(defaultMission)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="missionLayerFit"><option value="cover">${tr('fitCover')}</option><option value="contain">${tr('fitContain')}</option></select></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('add')}</button></div>`);const cleanup=()=>URL.revokeObjectURL(url),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.missionLayerTarget',sh).onchange=e=>{$('.sheethead p',sh).textContent=tr('missionLayerHint',{n:e.target.value})};$('.import',sh).onclick=async()=>{const before=beginHistory(),n=+$('.missionLayerTarget',sh).value,fit=$('.missionLayerFit',sh).value,layer=await createMissionImageLayer(file,{missionNumber:n,fitMode:fit});if(!layer){cleanup();return}setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionLayerAdded',{n}));done()}}
function chooseMissionSeriesFiles(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.multiple=true;input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const files=[...(input.files||[])];input.remove();if(files.length)openMissionSeriesSheet(files,{returnToStudio})};input.click()}
function openMissionSeriesSheet(files,{returnToStudio=false}={}){const items=files.slice().sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})).map((file,i)=>({file,missionNumber:(i%(state.rows*COLS))+1,url:URL.createObjectURL(file)}));let fitMode='cover';const cleanup=()=>items.forEach(x=>URL.revokeObjectURL(x.url)),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};const renderSheet=()=>{const rows=items.map((x,i)=>`<div class="missionSeriesRow" data-series-index="${i}"><img src="${escapeAttr(x.url)}" alt=""><div class="missionSeriesInfo"><b>${escapeHtml(x.file.name)}</b><select class="seriesMission">${missionOptionsHtml(x.missionNumber)}</select></div><div class="missionSeriesOrder"><button type="button" class="seriesUp" ${i===0?'disabled':''}>↑</button><button type="button" class="seriesDown" ${i===items.length-1?'disabled':''}>↓</button></div></div>`).join('');const sh=openSheet(`<div class="sheethead"><div><h2>▦ ${tr('missionSeriesTitle')}</h2><p>${tr('missionSeriesText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule"><span class="dot"></span><span>${tr('missionSeriesDetected',{n:items.length})}${items.length>state.rows*COLS?` · ${tr('missionSeriesTooMany')}`:''}</span></div><div class="field"><label>${tr('fitMode')}</label><select class="seriesFit"><option value="cover" ${fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="missionSeriesList">${rows}</div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('missionSeriesImport')}</button></div>`);$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.seriesFit',sh).onchange=e=>{fitMode=e.target.value};$$('.missionSeriesRow',sh).forEach(row=>{const i=+row.dataset.seriesIndex;$('.seriesMission',row).onchange=e=>items[i].missionNumber=+e.target.value;$('.seriesUp',row).onclick=()=>{if(i<=0)return;[items[i-1],items[i]]=[items[i],items[i-1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()};$('.seriesDown',row).onclick=()=>{if(i>=items.length-1)return;[items[i+1],items[i]]=[items[i],items[i+1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()}});$('.import',sh).onclick=async()=>{const before=beginHistory(),created=[];for(const x of items){const l=await createMissionImageLayer(x.file,{missionNumber:x.missionNumber,fitMode});if(l)created.push(l)}if(created.length){setEditMode('fresco');setActive('image:'+created[created.length-1].id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionSeriesAdded',{n:created.length}))}done()}};renderSheet()}
function imageLayerIndex(id){return state.imageLayers.findIndex(l=>l.id===id)}
function chooseImageFile(mode='background'){
  pendingImageMode=mode==='background'?'background':'layer';
  const input=$('#fileInput');if(!input)return;input.value='';input.click();
}
function activateImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  setEditMode('fresco');setActive('image:'+id);render();scheduleSave();
}
function moveImageLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;
  const before=beginHistory();
  [state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];
  commitHistory(before,tr('histReorderLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleImageLayerVisibility(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;
  commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleBackgroundVisibility(){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet()}
function deleteImageLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();
  state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();
  commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDeleted'));
}
function duplicateImageLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();
  const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};
  const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;
  commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDuplicated'));
}
function renameImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameLayer')}</h2><p>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layer')}</label><input id="layerRename" maxlength="60" value="${escapeAttr(imageLayerLabel(l,imageLayerIndex(id)))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=()=>openImageLayersSheet();$('.cancel',sh).onclick=()=>openImageLayersSheet();
  $('.save',sh).onclick=()=>{const before=beginHistory();l.name=$('#layerRename',sh).value.trim()||tr('layerName');commitHistory(before,tr('histRenameLayer'));scheduleSave();openImageLayersSheet()};
}
function selectedImageLayerIds(){return [...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id))}
function syncLayerSelectionUi(sh=currentSheet){
  if(!sh)return;const ids=selectedImageLayerIds(),n=ids.length;
  const bulk=$('.layerBulkPanel',sh);if(bulk)bulk.hidden=n<2;
  const count=$('.layerSelectionCount',sh);if(count)count.textContent=String(n);
  const clear=$('.clearGroup',sh);if(clear)clear.disabled=n<2;
  const group=$('.doGroup',sh);if(group)group.disabled=n<2;
  const edit=$('.editSelection',sh);if(edit)edit.disabled=n<2;
  const del=$('.deleteSelection',sh);if(del)del.disabled=n<2;
  const summary=$('.selectedLayersSummary',sh);if(summary)summary.textContent=tr('selectedLayersCount',{n});
  $$('.imageLayerRow[data-layer]',sh).forEach(row=>{const id=row.dataset.layer,checked=layerGroupSelection.has(id);row.classList.toggle('multiSelected',checked);const cb=$('.layerGroupCheck',row);if(cb)cb.checked=checked});
  if(studioEditorRoot){const mini=$('.studioGroupMini',studioEditorRoot);if(mini)mini.hidden=n<2;const sc=$('.studioGroupCount',studioEditorRoot);if(sc)sc.textContent=String(n);const se=$('.studioSelectionActions',studioEditorRoot);if(se)se.disabled=n<2;const sg=$('.studioGroupNow',studioEditorRoot);if(sg)sg.disabled=n<2;}
}
function openSelectedLayersActionsSheet({returnToStudio=!!studioEditorRoot}={}){
  const ids=selectedImageLayerIds();if(!ids.length){toast(tr('selectionEmpty'));return}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('editSelection')}</h2><p>${tr('selectedLayersCount',{n:ids.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layerScope')}</label><select class="bulkScope"><option value="keep">${tr('bulkScopeKeep')}</option><option value="global">${tr('wholeBanner')}</option><option value="mission">${tr('missionLayer')}</option></select></div><div class="field bulkMissionField" hidden><label>${tr('missionTarget')}</label><select class="bulkMission">${missionOptionsHtml(1)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="bulkFit"><option value="keep">${tr('bulkFitKeep')}</option><option value="cover">${tr('fitCover')}</option><option value="contain">${tr('fitContain')}</option></select></div><div class="field"><label>${tr('bulkVisibility')}</label><select class="bulkVisibility"><option value="keep">${tr('bulkVisibilityKeep')}</option><option value="show">${tr('bulkShow')}</option><option value="hide">${tr('bulkHide')}</option></select></div><label class="switchline"><input type="checkbox" class="bulkOpacityEnable"> ${tr('bulkOpacityEnable')}</label><div class="field bulkOpacityField" hidden><label>${tr('layerOpacity')} <span class="bulkOpacityVal">100%</span></label><input class="bulkOpacity" type="range" min="0" max="100" value="100"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary apply">${tr('applyToSelection')}</button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};
  $('.close',sh).onclick=back;$('.cancel',sh).onclick=back;
  const scope=$('.bulkScope',sh),missionField=$('.bulkMissionField',sh),opEnable=$('.bulkOpacityEnable',sh),opField=$('.bulkOpacityField',sh),op=$('.bulkOpacity',sh);
  scope.onchange=()=>missionField.hidden=scope.value!=='mission';opEnable.onchange=()=>opField.hidden=!opEnable.checked;op.oninput=()=>$('.bulkOpacityVal',sh).textContent=`${op.value}%`;
  $('.apply',sh).onclick=()=>{const before=beginHistory(),scopeValue=scope.value,mission=+$('.bulkMission',sh).value,fit=$('.bulkFit',sh).value,vis=$('.bulkVisibility',sh).value,opacity=+op.value/100,touchedGroups=new Set(ids.map(id=>state.imageLayers.find(x=>x.id===id)?.groupId).filter(Boolean));if(scopeValue!=='keep'&&touchedGroups.size){for(const x of state.imageLayers)if(touchedGroups.has(x.groupId)){x.groupId=null;x.groupNumber=null}}for(const id of ids){const l=state.imageLayers.find(x=>x.id===id);if(!l)continue;normalizeImageLayerScope(l);if(scopeValue!=='keep'){const previousFit=l.fitMode;l.scope=scopeValue==='mission'?'mission':'global';if(l.scope==='mission'){l.missionNumber=clamp(mission,1,state.rows*COLS);l.fitMode=fit==='keep'?(previousFit==='contain'?'contain':'cover'):(fit==='contain'?'contain':'cover');fitImageLayer(l)}else{l.missionNumber=null;fitImageLayer(l)}}else if(fit!=='keep'&&l.scope==='mission'){l.fitMode=fit==='contain'?'contain':'cover';fitImageLayer(l)}if(vis==='show')l.visible=true;else if(vis==='hide')l.visible=false;if(opEnable.checked)l.opacity=clamp(opacity,0,1)}normalizeLayerGroups();commitHistory(before,tr('histImageZoom'));scheduleSave();render();toast(tr('selectionUpdated'));back()};
}
function confirmDeleteSelectedLayers({returnToStudio=!!studioEditorRoot}={}){
  const ids=selectedImageLayerIds();if(!ids.length){toast(tr('selectionEmpty'));return}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteSelection')}</h2><p>${tr('deleteSelectionConfirm',{n:ids.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirm">${icon('trash')} ${tr('delete')}</button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};$('.close',sh).onclick=back;$('.cancel',sh).onclick=back;$('.confirm',sh).onclick=()=>{const before=beginHistory(),set=new Set(ids),touchedGroups=new Set(state.imageLayers.filter(l=>set.has(l.id)&&l.groupId).map(l=>l.groupId));state.imageLayers=state.imageLayers.filter(l=>!set.has(l.id));if(touchedGroups.size){for(const l of state.imageLayers)if(touchedGroups.has(l.groupId)){l.groupId=null;l.groupNumber=null}}for(const id of ids)layerGroupSelection.delete(id);if(state.active.startsWith('image:')&&set.has(state.active.slice(6)))state.active='background';normalizeLayerGroups();commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();toast(tr('selectionDeleted'));back()};
}
function groupSelectedImageLayers(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));
  if(ids.length<2){toast(tr('groupNeedTwo'));return}
  const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}
  const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();
  state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupCreated'));
}
function ungroupImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();
  for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupRemoved'));
}
function setLayerOpacity(id,value){const l=state.imageLayers.find(x=>x.id===id);if(!l)return;l.opacity=clamp(value,0,1);render();scheduleSave()}
const layerPreviewUrls=new WeakMap();
function layerPreviewUrl(blob,image){
  if(blob instanceof Blob){
    let url=layerPreviewUrls.get(blob);
    if(!url){url=URL.createObjectURL(blob);layerPreviewUrls.set(blob,url)}
    return url;
  }
  const src=image?.src||'';
  return src&&!src.startsWith('blob:')?src:'';
}
function imageLayerThumbHtml(blob,image,{fallback='▧',alt='',studio=false}={}){
  const src=layerPreviewUrl(blob,image);
  if(!src)return `<span class="${studio?'studioLayerGlyph':'layerGlyph'}">${fallback}</span>`;
  return `<span class="${studio?'studioLayerThumb':'layerThumb'}"><img src="${escapeAttr(src)}" alt="" aria-label="${escapeAttr(alt)}"></span>`;
}
function openImageLayersSheet(){
  setEditMode('fresco');normalizeLayerGroups();
  for(const id of [...layerGroupSelection])if(!state.imageLayers.some(l=>l.id===id))layerGroupSelection.delete(id);
  const ordered=[...state.imageLayers].map((l,i)=>({l,i})).reverse();
  const layerRows=ordered.map(({l,i})=>{
    const active=state.active==='image:'+l.id,top=i===state.imageLayers.length-1,bottom=i===0,grouped=!!l.groupId,ginfo=groupInfoForLayer(l);
    const w=l.image?.naturalWidth||0,h=l.image?.naturalHeight||0;
    return `<div class="imageLayerRow ${active?'active':''} ${l.visible===false?'hidden':''} ${grouped?`groupedLayer groupColor${ginfo.color}`:''}" data-layer="${escapeAttr(l.id)}">
      ${grouped?`<span class="groupEdge" aria-hidden="true"></span>`:''}
      <label class="layerCheck" title="${tr('multiSelection')}"><input type="checkbox" class="layerGroupCheck" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="layerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:grouped?'▱':'▧',alt:imageLayerLabel(l,i)})}<span class="layerCopy"><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${w&&h?tr('layerDimensions',{w,h}):''}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}${grouped?` · <span class="groupInline">${tr('groupCount',{n:ginfo.count})}</span>`:''}</small>${grouped?`<span class="groupBadge">${escapeHtml(ginfo.label)}</span>`:''}</span>${active?`<em>${tr('selected')}</em>`:''}</button>
      <button class="layerEye" title="${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}">${l.visible===false?'◌':'◉'}</button>
      <div class="layerQuick"><button class="layerDown" ${bottom?'disabled':''} title="${tr('moveDown')}">↓</button><button class="layerUp" ${top?'disabled':''} title="${tr('moveUp')}">↑</button><button class="layerMore" title="${tr('layerTransform')}">⋯</button></div>
    </div>`;
  }).join('')||`<div class="layerEmpty">${tr('layersDesc')}</div>`;
  const activeLayer=activeImageLayer(),activeIsExtra=state.active.startsWith('image:'),groupedActive=activeIsExtra&&!!activeLayer?.groupId;
  const sh=openSheet(`<div class="sheethead"><div><h2>${icon('layers')} ${tr('layersTitle')}</h2><p>${tr('layersDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="layerAddGrid"><button class="primary addBackground">${icon('image')} ${tr('addBackground')}</button><button class="secondary addImageLayer">${icon('plus')} ${tr('addLayerChoiceTitle')}</button></div><div class="layerImportHint">${tr('layerScopeHelp')}</div>
    <div class="imageLayerStack">
      ${layerRows}
      <div class="imageLayerRow backgroundRow ${state.active==='background'?'active':''} ${state.bg.visible===false?'hidden':''}">
        <span class="layerCheck lock">⌄</span><button class="layerSelect selectBackground">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer')})}<span class="layerCopy"><b>${tr('backgroundLayer')}</b><small>${state.bg.image?tr('layerDimensions',{w:state.bg.image.naturalWidth,h:state.bg.image.naturalHeight}):tr('backgroundMissing')}</small></span>${state.active==='background'?`<em>${tr('selected')}</em>`:''}</button><button class="layerEye backgroundEye">${state.bg.visible===false?'◌':'◉'}</button><span class="layerBottomLock">🔒</span>
      </div>
    </div>
    <div class="layerBulkPanel" ${layerGroupSelection.size>=2?'':'hidden'}><div class="layerGroupBar"><div><b>${tr('multiSelection')}</b><small>${tr('multiSelectionHint')}</small><small class="selectedLayersSummary">${tr('selectedLayersCount',{n:layerGroupSelection.size})}</small></div><span class="layerSelectionCount">${layerGroupSelection.size}</span></div>
    <div class="actions layerGroupActions"><button class="secondary clearGroup" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('clearGroupSelection')}</button><button class="secondary editSelection" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('editSelection')}</button><button class="primary doGroup" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('group')}</button><button class="danger deleteSelection" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('deleteSelection')}</button></div></div>${groupedActive?`<div class="actions"><button class="secondary doUngroup">${tr('layerUngroup')}</button></div>`:''}
    <p class="small layerFooterHint">${tr('backgroundFixed')} ${tr('layerSelectHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('.addBackground',sh).onclick=()=>{closeSheet();chooseImageFile('background')};$('.addImageLayer',sh).onclick=()=>openAddLayerChoiceSheet();
  $('.selectBackground',sh).onclick=()=>{setActive('background');openImageLayersSheet()};$('.backgroundEye',sh).onclick=toggleBackgroundVisibility;
  $$('.imageLayerRow[data-layer]',sh).forEach(row=>{
    const id=row.dataset.layer;$('.layerSelect',row).onclick=()=>{activateImageLayer(id);openImageLayersSheet()};
    $('.layerEye',row).onclick=()=>toggleImageLayerVisibility(id);$('.layerDown',row).onclick=()=>moveImageLayer(id,-1);$('.layerUp',row).onclick=()=>moveImageLayer(id,1);
    $('.layerGroupCheck',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);syncLayerSelectionUi(sh)};
    $('.layerMore',row).onclick=()=>openLayerActionsSheet(id);
  });
  $('.clearGroup',sh).onclick=()=>{layerGroupSelection.clear();syncLayerSelectionUi(sh)};$('.editSelection',sh).onclick=()=>openSelectedLayersActionsSheet();$('.deleteSelection',sh).onclick=()=>confirmDeleteSelectedLayers();$('.doGroup',sh).onclick=groupSelectedImageLayers;if($('.doUngroup',sh))$('.doUngroup',sh).onclick=()=>ungroupImageLayer(activeLayer.id);syncLayerSelectionUi(sh);
}
function openLayerActionsSheet(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;activateImageLayer(id);normalizeImageLayerScope(l);
  const grouped=!!l.groupId,ginfo=groupInfoForLayer(l),missionControls=l.scope==='mission'?`<div class="field"><label>${tr('missionTarget')}</label><select class="layerMissionTarget">${missionOptionsHtml(l.missionNumber)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="layerMissionFit"><option value="cover" ${l.fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${l.fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="rule"><span class="dot"></span><span>${tr('missionLayerHint',{n:l.missionNumber})}</span></div>`:'';
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))} ${missionLayerBadgeHtml(l)}</h2><p>${grouped?`${tr('groupTransform')} · ${escapeHtml(ginfo.label)} · ${tr('groupCount',{n:ginfo.count})}`:tr('layerTransform')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layerScope')}</label><select class="layerScopeSelect"><option value="global" ${l.scope==='global'?'selected':''}>${tr('wholeBanner')}</option><option value="mission" ${l.scope==='mission'?'selected':''}>${tr('missionLayer')}</option></select></div>${missionControls}<div class="field"><label>${tr('layerOpacity')} <span class="opacityVal">${Math.round((l.opacity??1)*100)}%</span></label><input class="layerOpacityRange" type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></div><div class="layerActionGrid"><button class="secondary transformLayer">${icon('move')} ${grouped?tr('groupTransform'):tr('layerTransform')}</button><button class="secondary renameLayerBtn">${icon('edit')} ${tr('renameLayer')}</button><button class="secondary duplicateLayerBtn">${icon('copy')} ${tr('duplicateLayer')}</button>${grouped?`<button class="secondary ungroupLayerBtn">${tr('ungroup')}</button>`:''}<button class="danger deleteLayerBtn">${icon('trash')} ${tr('deleteLayer')}</button></div>`);
  $('.close',sh).onclick=openImageLayersSheet;const rng=$('.layerOpacityRange',sh);rng.oninput=e=>{setLayerOpacity(id,+e.target.value/100);$('.opacityVal',sh).textContent=`${e.target.value}%`};historyControl(rng,tr('histVisibilityLayer'));
  $('.layerScopeSelect',sh).onchange=e=>{const before=beginHistory();l.scope=e.target.value==='mission'?'mission':'global';l.groupId=null;l.groupNumber=null;if(l.scope==='mission'){l.missionNumber=clamp(parseInt(l.missionNumber)||1,1,state.rows*COLS);l.fitMode=l.fitMode==='contain'?'contain':'cover'}else l.missionNumber=null;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionTarget',sh))$('.layerMissionTarget',sh).onchange=e=>{const before=beginHistory();l.missionNumber=+e.target.value;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionFit',sh))$('.layerMissionFit',sh).onchange=e=>{const before=beginHistory();l.fitMode=e.target.value==='contain'?'contain':'cover';fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  $('.transformLayer',sh).onclick=openTransformSheet;$('.renameLayerBtn',sh).onclick=()=>renameImageLayer(id);$('.duplicateLayerBtn',sh).onclick=()=>duplicateImageLayer(id);$('.deleteLayerBtn',sh).onclick=()=>deleteImageLayer(id);if($('.ungroupLayerBtn',sh))$('.ungroupLayerBtn',sh).onclick=()=>ungroupImageLayer(id);
}
function imageFitScale(o){
  if(!o?.image)return 1;
  if(o===state.bg)return Math.max(WORLD_W/o.image.naturalWidth,worldH()/o.image.naturalHeight);
  normalizeImageLayerScope(o);if(o.scope==='mission')return missionLayerFitScale(o);
  return Math.min(WORLD_W*.72/o.image.naturalWidth,worldH()*.72/o.image.naturalHeight);
}
function shiftImageItems(items,dx,dy){for(const x of items){x.x=(x.x||0)+dx;x.y=(x.y||0)+dy}}
function groupTransformBaseline(items){
  const snap=captureTransformTargets(items),center=transformCenter(snap);return {snap,center};
}
function applyRelativeGroupTransform(base,scaleFactor,rotationDelta){
  const cs=Math.cos(rotationDelta),sn=Math.sin(rotationDelta);
  for(const t of base.snap){const ox=(t.x-base.center.x)*scaleFactor,oy=(t.y-base.center.y)*scaleFactor;t.obj.x=base.center.x+ox*cs-oy*sn;t.obj.y=base.center.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*scaleFactor,.02,30);t.obj.rotation=t.rotation+rotationDelta}
}

function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast(tr('touchMissionFirst'));return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${n}</h2><p>${tr('missionCropOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>${tr('localZoom')} <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>${tr('rotation')} <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} ${tr('resetThisMission')}</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),tr('histMissionZoom'));
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),tr('histMissionRotation'));
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:'),isImage=!isText;
  const items=isImage?frescoTransformTargets():[o],isGroup=isImage&&items.length>1,groupBase=isGroup?groupTransformBaseline(items):null;
  const fit=isImage&&!isGroup?imageFitScale(o):1,zoomValue=isGroup?100:Math.round((isText?o.scale:o.scale/Math.max(.0001,fit))*100),rotValue=isGroup?0:Math.round((o.rotation||0)*180/Math.PI);
  const title=isText?tr('transformText'):(isGroup?tr('groupTransform'):tr('layerTransform'));
  const sh=openSheet(`<div class="sheethead"><div><h2>${title}</h2><p>${isGroup?tr('groupRelative'):tr('pinchHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${isGroup?tr('groupZoom'):tr('zoom')} <span id="zoomVal">${zoomValue}%</span></label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>${isGroup?tr('groupRotation'):tr('rotation')} <span id="rotVal">${rotValue}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${rotValue}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">${tr('center')}</button>${!isGroup?`<button class="secondary" id="resetBtn">${icon('reset')} ${tr('reset')}</button>`:''}${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  if(isGroup){
    const apply=()=>{applyRelativeGroupTransform(groupBase,+$('#zoom',sh).value/100,+$('#rotation',sh).value*Math.PI/180);$('#zoomVal',sh).textContent=`${$('#zoom',sh).value}%`;$('#rotVal',sh).textContent=`${$('#rotation',sh).value}°`;render();scheduleSave()};
    $('#zoom',sh).oninput=apply;$('#rotation',sh).oninput=apply;historyControl($('#zoom',sh),tr('histImageZoom'));historyControl($('#rotation',sh),tr('histImageRotation'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory(),now=transformCenter(captureTransformTargets(items));shiftImageItems(items,WORLD_W/2-now.x,worldH()/2-now.y);render();commitHistory(before,tr('histCenterImage'));scheduleSave()};
  }else{
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),isText?tr('histTextRotation'):tr('histImageRotation'));
    $('#zoom',sh).oninput=e=>{o.scale=(isText?1:fit)*(+e.target.value/100);$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),isText?tr('histTextZoom'):tr('histImageZoom'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory();if(!isText&&o.scope==='mission'){const mr=missionLayerRect(o);if(mr){o.x=mr.cx;o.y=mr.cy}}else{o.x=WORLD_W/2;o.y=worldH()/2}render();commitHistory(before,isText?tr('histCenterText'):tr('histCenterImage'));scheduleSave()};
    $('#resetBtn',sh).onclick=()=>{const before=beginHistory();if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else if(o===state.bg)fitBackground();else fitImageLayer(o);closeSheet();render();commitHistory(before,isText?tr('histResetText'):tr('histResetImage'));scheduleSave()};
  }
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast(tr('selectMissionFirst'));return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="${tr('close')}">${icon('close')}</button>
      <div><strong id="missionEditorTitle">${tr('missions')} ${n}</strong><span>${tr('individualCrop')}</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="${tr('previewPrime')}">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>${tr('oneFinger')}</b> ${tr('move')} · <b>${tr('twoFingers')}</b> ${tr('zoomRotate')}</div>
    <section class="missioneditorcontrols">
      <div class="missionhistory"><button class="secondary undoActionBtn missionundo" disabled>↶ ${tr('undo')}</button><button class="secondary redoActionBtn missionredo" disabled>↷ ${tr('redo')}</button></div>
      <div class="missionnav">
        <button class="secondary missionprev">‹ ${tr('prev')}</button>
        <button class="secondary missionnext">${tr('next')} ›</button>
      </div>
      <div class="field"><label>${tr('zoom')} <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>${tr('rotation')} <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} ${tr('reset')}</button><button class="primary missiondone">${tr('done')}</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const before=beginHistory(),o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();commitHistory(before,tr('histResetMission'));scheduleSave();};
  $('.missionundo',back).onclick=undoAction;$('.missionredo',back).onclick=redoAction;
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorZoom',back),tr('histMissionZoom'));
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorRot',back),tr('histMissionRotation'));
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=tr('missionLabel',{n});
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0,historyBefore:beginHistory()};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){const before=missionEditorGesture?.historyBefore;missionEditorGesture=null;commitHistory(before,tr('histResetMission'));scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0],before=missionEditorGesture?.historyBefore;missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0,historyBefore:before};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  const before=beginHistory();
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();commitHistory(before,tr('histResetMission'));scheduleSave();toast(tr('missionResetDone',{n:missionNumber(rc.row,rc.col)}));
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  const before=beginHistory();
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();commitHistory(before,tr('histDeleteText'));scheduleSave();toast(tr('textDeleted'));
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('text')}</h2><p>${tr('textLayerDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('layer')}</label><select id="textLayer"><option value="new">${tr('newText')}</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);if(t)normalizeTextStyle(t);const box=$('#textEditor',sh),td=textDefaults(t||{});
    box.innerHTML=`<div class="field"><label>${tr('text')}</label><input id="txt" value="${escapeAttr(t?.text||'I LOVE REDACTED')}" maxlength="120"></div>
      <div class="textTypographyCard"><b>${tr('textTypography')}</b><div class="field"><label>${tr('font')}</label><div class="fontPickerLine"><select id="fontFamily">${fontOptionsHtml(td.fontFamily)}</select><button type="button" class="secondary" id="importFont">＋ ${tr('importFont')}</button></div></div>
      <div class="grid2"><div class="field"><label>${tr('size')}</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>${tr('fontWeight')}</label><select id="fontWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${td.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></div></div>
      <div class="grid2"><div class="field"><label>${tr('letterSpacing')}</label><input id="letterSpacing" type="number" min="-40" max="160" value="${td.letterSpacing||0}"></div><div class="field"><label>${tr('lineHeight')}</label><input id="lineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${td.lineHeight||1.08}"></div></div>
      <div class="grid2"><div class="field"><label>${tr('textAlign')}</label><select id="textAlign"><option value="left" ${td.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${td.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${td.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></div><label class="switchline textItalicLine"><input id="fontItalic" type="checkbox" ${td.fontItalic?'checked':''}> ${tr('fontItalic')}</label></div></div>
      <div class="grid2"><div class="field"><label>${tr('outline')}</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div><div class="field"><label>${tr('color')}</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div></div>
      <div class="field"><label>${tr('outlineColor')}</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div>
      <label class="switchline"><input id="textBgEnabled" type="checkbox" ${td.backgroundEnabled?'checked':''}> ${tr('textBackground')}</label>
      <div id="textBgFields" ${td.backgroundEnabled?'':'hidden'}><div class="grid2"><div class="field"><label>${tr('textBackgroundColor')}</label><input id="textBgColor" type="color" value="${td.backgroundColor}"></div><div class="field"><label>${tr('textBackgroundOpacity')}</label><input id="textBgOpacity" type="number" min="0" max="100" value="${Math.round(td.backgroundOpacity*100)}"></div></div><div class="grid2"><div class="field"><label>${tr('textBackgroundPadding')}</label><input id="textBgPadding" type="number" min="0" max="180" value="${td.backgroundPadding}"></div><div class="field"><label>${tr('textBackgroundRadius')}</label><input id="textBgRadius" type="number" min="0" max="240" value="${td.backgroundRadius}"></div></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?tr('update'):tr('add')}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`;
    $('#textBgEnabled',box).onchange=e=>$('#textBgFields',box).hidden=!e.target.checked;$('#importFont',box).onclick=()=>importProjectFont(t,rec=>{if(t){t.fontFamily=rec.family;drawTextEditor(t.id)}else{const select=$('#fontFamily',box);if(select){select.insertAdjacentHTML('beforeend',`<option value="${escapeAttr(rec.family)}">★ ${escapeHtml(rec.name)}</option>`);select.value=rec.family}}});
    $('#saveText',box).onclick=()=>{
      const before=beginHistory(),wasNew=!t;
      const style={text:$('#txt',box).value||tr('text'),fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,fontFamily:$('#fontFamily',box).value,fontWeight:+$('#fontWeight',box).value||800,fontItalic:$('#fontItalic',box).checked,letterSpacing:+$('#letterSpacing',box).value||0,lineHeight:+$('#lineHeight',box).value||1.08,textAlign:$('#textAlign',box).value,backgroundEnabled:$('#textBgEnabled',box).checked,backgroundColor:$('#textBgColor',box).value,backgroundOpacity:clamp((+$('#textBgOpacity',box).value||0)/100,0,1),backgroundPadding:clamp(+$('#textBgPadding',box).value||0,0,180),backgroundRadius:clamp(+$('#textBgRadius',box).value||0,0,240)};
      if(!t){t=textDefaults({id:uid(),x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,...style});state.texts.push(t)}else Object.assign(t,style);normalizeTextStyle(t);
      setActive('text:'+t.id);commitHistory(before,wasNew?tr('histAddText'):tr('histEditText'));scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('previewPrime')}</h2><p>${tr('previewApplied')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">${tr('previewOrder')}</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseBackground(cc);cc.restore();
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);drawOverlayWorld(cc);cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('exportTitle',{n:count})}</h2><p>${tr('exportIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!hasImageContent()?`<div class="rule warning"><span class="dot"></span><span>${tr('noImageContent')}</span></div>`:''}
    <div class="field"><label>${tr('missionFormat')}</label><select id="exportFormat"><option value="jpeg" selected>${tr('jpgFast')}</option><option value="png">${tr('pngLossless')}</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>${tr('fastEncoding')}</span></div><div class="rule"><span class="dot"></span><span>${tr('rowRender')}</span></div><div class="rule"><span class="dot"></span><span>${tr('adjusted',{n:adjusted})}</span></div><div class="rule warning"><span class="dot"></span><span>${tr('nianticCheck')}</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">${tr('ready')}</div>
    <div class="actions"><button class="primary" id="doExport" ${!hasImageContent()?'disabled':''}>${tr('createZip')}</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseBackground(cc);drawOverlayWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent=tr('zipAssembly');bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`${tr('zipAssembly')} ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent=tr('zipCreated');
      await Share.share({title:'Export Redacted BannerLab',text:`${total} ${tr('missions').toLowerCase()} · ${state.name}`,url:uri.uri,dialogTitle:tr('saveShareZip')});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent=tr('zipDownloaded');
    }
    toast(tr('exportFinished',{format:jpeg?'JPG':'PNG'}));
  }catch(err){console.error(err);txt.textContent=tr('exportImpossible',{error:err?.message||err});toast(tr('exportFailed'))}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}
${state.name}
${tr('orderRowsLine',{rows:state.rows,missions:state.rows*6})}

${tr('orderTitle')}
`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false),file=`${String(n).padStart(3,'0')}.${ext}`,adjusted=o&&!isIdentityOverride(o)?tr('orderAdjusted'):'';s+=tr('orderItem',{file,row:row+1,col:col+1,adjusted})+'\n'}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error(tr('canvasExportFailed'))),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const MIN_PORTALS_PER_MISSION=6;

const OBJECTIVE_LABELS={
  HACK_PORTAL:'hack',
  INSTALL_MOD:'mod',
  CAPTURE_PORTAL:'capture',
  CREATE_LINK:'link',
  CREATE_FIELD:'field',
  PASSPHRASE:'passphrase'
};
function objectiveLabel(type){return tr(OBJECTIVE_LABELS[type]||'hack')}
function missionSequential(m){return typeof m?.sequential==='boolean'?m.sequential:state.planner.sequential!==false}
function missionHidden(m){return missionSequential(m)&&(typeof m?.hiddenLocation==='boolean'?m.hiddenLocation:!!state.planner.hiddenLocation)}

function projectLanguage(){return SUPPORTED_LANGS.includes(state.projectLanguage)?state.projectLanguage:APP_LANG}
function trProject(key,vars={}){
  let txt=(I18N[projectLanguage()]&&I18N[projectLanguage()][key])||I18N.en[key]||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))txt=txt.replaceAll('{'+k+'}',String(v));
  return txt;
}
function defaultMissionPassphrase(mi){return {question:trProject('missionNumberQuestion'),answer:String(Math.max(0,Number(mi)||0)+1)}}
function fillPassphraseDefaults(portal,mi){
  if(!portal?.objective||portal.objective.type!=='PASSPHRASE')return portal;
  portal.objective.passphrase_params=portal.objective.passphrase_params||{question:'',_single_passphrase:''};
  const d=defaultMissionPassphrase(mi);
  if(!String(portal.objective.passphrase_params.question||'').trim())portal.objective.passphrase_params.question=d.question;
  if(!String(portal.objective.passphrase_params._single_passphrase||'').trim())portal.objective.passphrase_params._single_passphrase=d.answer;
  return portal;
}


function normalizePlanner(p={}){
  const planner={
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24),
    autoAdvance: p.autoAdvance!==false,
    reuseLastPortal: p.reuseLastPortal!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    sequential: typeof m.sequential==='boolean'?m.sequential:null,
    hiddenLocation: typeof m.hiddenLocation==='boolean'?m.hiddenLocation:null,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||tr('portalDefault')),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||tr('bannerDefault');
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function guidOccurrences(guid){
  const out=[];
  state.planner.missions.forEach((m,mi)=>(m.portals||[]).forEach((p,pi)=>{if(guid&&p.guid===guid)out.push({mi,pi})}));
  return out;
}
function isAllowedHandoverOccurrences(occ){
  if(occ.length!==2)return false;
  const [a,b]=occ;
  if(b.mi!==a.mi+1||b.pi!==0)return false;
  const prev=state.planner.missions[a.mi]?.portals||[];
  return a.pi===prev.length-1;
}
function duplicateGuidCount(){
  let bad=0;
  for(const m of state.planner.missions){
    const seen=new Set(),dupes=new Set();
    for(const p of (m.portals||[]))if(p.guid){if(seen.has(p.guid))dupes.add(p.guid);else seen.add(p.guid)}
    bad+=dupes.size;
  }
  return bad;
}
function canReuseAsHandover(portal,mi){
  if(!portal?.guid||mi<=0)return false;
  const cur=plannerMission(mi),prev=plannerMission(mi-1);
  return cur.portals.length===0&&prev?.portals?.at(-1)?.guid===portal.guid;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):tr('route');
  const badGuid=!p.guid,pass=p.objective?.type==='PASSPHRASE';
  const extra=pass&&p.objective?.passphrase_params?.question?` · ${escapeHtml(p.objective.passphrase_params.question)}`:'';
  return `<div class="portalrow portalrow-v2" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||tr('portalDefault'))}</strong><span>${dist}${badGuid?' · GUID ?':''}</span>
      <button class="portalactionbtn">${escapeHtml(objectiveLabel(p.objective?.type))}${extra}</button>
    </div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="↑">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="↓">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="×">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('route')} · ${tr('missions')} ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} ${tr('portalsPerMission').split(' / ')[0].toLowerCase()} · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ ${tr('prev')}</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>${tr('next')} ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?tr('complete'):tr('remaining',{n:Math.max(0,need-count)})}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion">
      <div class="iitccompanion-head"><img src="/redacted-logo-512.png" alt="Redacted"><div><b>IITC Companion</b><span>${tr('companionStats')}</span></div><span class="beta">${tr('pluginVersion')}</span></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('companionStats')}</b><small>${tr('companionStatsDesc')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('action')}</b><small>${tr('routeActionHelp')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('handoverOk')}</b><small>${tr('handoverDetail')}</small></div></div>
      <div class="actions companionactions"><button class="primary openintel">${icon('globe')} ${tr('openIitc')}</button><button class="secondary tutorialiitc">${icon('info')} ${tr('tutorial')}</button></div>
      <div class="actions companionsecondary"><button class="secondary sharebridge">${tr('installPlugin')}</button></div>
    </div>
    <div class="routeoptions">
      <label class="switchline"><input type="checkbox" id="autoAdvance" ${state.planner.autoAdvance?'checked':''}> ${tr('autoAdvance',{n:need})}</label>
      <label class="switchline"><input type="checkbox" id="reuseLastPortal" ${state.planner.reuseLastPortal?'checked':''}> ${tr('reuseLast')}</label>
    </div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${tr('duplicateBad',{n:dup})}</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):`<div class="emptyroute">${tr('noPortal')}</div>`}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('#autoAdvance',sh).onchange=e=>{state.planner.autoAdvance=e.target.checked;scheduleSave()};
  $('#reuseLastPortal',sh).onchange=e=>{state.planner.reuseLastPortal=e.target.checked;scheduleSave()};
  $('.openintel',sh).onclick=openIntel;
  $('.tutorialiitc',sh).onclick=()=>startTutorial('iitc',{manual:true});
  $('.sharebridge',sh).onclick=shareIitcBridge;
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalactionbtn',row).onclick=()=>openPortalObjectiveSheet(idx,pi);
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();openRoutePlanner();
}
function removePortal(mi,pi){const m=plannerMission(mi);if(!m)return;m.portals.splice(pi,1);scheduleSave();openRoutePlanner()}

function openPortalObjectiveSheet(mi,pi){
  const m=plannerMission(mi),p=m?.portals?.[pi];if(!p)return;
  const options=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('action')}</h2><p>${escapeHtml(p.title)}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('action')}</label><select id="objectiveType">${options}</select></div>
    <div class="passphraseFields" ${p.objective?.type==='PASSPHRASE'?'':'hidden'}>
      <div class="field"><label>${tr('question')}</label><input id="passQuestion" value="${escapeAttr(p.objective?.passphrase_params?.question||'')}"></div>
      <div class="field"><label>${tr('answer')}</label><input id="passAnswer" value="${escapeAttr(p.objective?.passphrase_params?._single_passphrase||'')}"></div>
    </div>
    <div class="actions"><button class="secondary close2">${tr('cancel')}</button><button class="primary saveobj">${tr('save')}</button></div>`);
  const update=()=>{
    const isPass=$('#objectiveType',sh).value==='PASSPHRASE';
    $('.passphraseFields',sh).hidden=!isPass;
    if(isPass){const d=defaultMissionPassphrase(mi);const q=$('#passQuestion',sh),a=$('#passAnswer',sh);if(q&&!q.value.trim())q.value=d.question;if(a&&!a.value.trim())a.value=d.answer}
  };
  $('#objectiveType',sh).onchange=update;update();
  $('.close',sh).onclick=closeSheet;$('.close2',sh).onclick=closeSheet;
  $('.saveobj',sh).onclick=()=>{
    p.objective.type=$('#objectiveType',sh).value;
    p.objective.passphrase_params.question=$('#passQuestion',sh)?.value?.trim()||'';
    p.objective.passphrase_params._single_passphrase=$('#passAnswer',sh)?.value?.trim()||'';
    fillPassphraseDefaults(p,mi);
    scheduleSave();openRoutePlanner();
  };
}

function addPortalToMission(portal,mi=state.planner.currentMission,opts={}){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  const p=normalizePortal(portal);fillPassphraseDefaults(p,mi);
  if(p.guid&&(m.portals||[]).some(x=>x.guid===p.guid)){toast(tr('duplicateElsewhere'));return false}
  m.portals.push(p);scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){
    const last=m.portals.at(-1);
    state.planner.currentMission=mi+1;
    const next=plannerMission(mi+1);
    if(state.planner.reuseLastPortal&&next.portals.length===0&&last)next.portals.push(structuredClone(last));
    scheduleSave();
    toast(tr('missionCompleteAdded',{n:mi+1,next:mi+2}));
  }else toast(tr('portalAdded',{n:mi+1}));
  return true;
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||tr('portalDefault'),Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL',p.objective?.passphrase_params?.question||'',p.objective?.passphrase_params?._single_passphrase||'']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||tr('portalDefault'),location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL',passphrase_params:{question:a?.[6]||'',_single_passphrase:a?.[7]||''}}})}
function bridgePlannerPayload(){
  ensurePlannerMissions();return {v:3,pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,carry:state.planner.reuseLastPortal!==false,lang:projectLanguage(),m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact))};
}
async function openIntel(){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  u.hash='rbl='+encodeURIComponent(bridgeEncode(bridgePlannerPayload()));

  if(!Capacitor.isNativePlatform()){
    window.open(u.toString(),'_blank','noopener');
    return;
  }

  // Android : une URL https seule part dans Chrome. On cible donc explicitement
  // IITC Mobile avec ACTION_VIEW + l'URL contenant le payload BannerLab.
  const candidates=[
    'org.exarhteam.iitc_mobile',
    'org.exarhteam.iitcprime'
  ];

  for(const packageName of candidates){
    try{
      await IntentLauncher.startActivityAsync({
        action: ActivityAction.VIEW,
        data: u.toString(),
        packageName
      });
      toast(packageName.includes('iitcprime')
        ? tr('intelPrimeOpened')
        : tr('intelOpened'));
      return;
    }catch(e){
      console.warn(`IITC non ouvert via ${packageName}`,e);
    }
  }

  // Ultime secours : on ouvre IITC Mobile sans payload si Android refuse
  // l'intent ciblé, puis seulement le navigateur si IITC n'est pas installé.
  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitc_mobile'});
    toast(tr('intelFallback'));
    return;
  }catch(e){
    console.warn('IITC Mobile absent',e);
  }

  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitcprime'});
    toast(tr('intelPrimeFallback'));
    return;
  }catch(e){
    console.warn('IITC Prime absent',e);
  }

  await AppLauncher.openUrl({url:u.toString()});
  toast(tr('intelBrowser'));
}
async function bridgeUserscriptText(){
  const r=await fetch('/redacted-bannerlab-iitc.user.js',{cache:'no-store'});
  if(!r.ok)throw new Error('Plugin IITC introuvable');
  const text=await r.text();
  if(!text||text.length<1024)throw new Error(`Plugin IITC invalide (${text?.length||0} octet)`);
  return text;
}
async function bundledIitcInfo(){
  if(!Capacitor.isNativePlatform())return null;
  const info=await BackupFolder.getBundledIitcInfo();
  if(!info?.available||Number(info?.bytes||0)<1024)throw new Error(`Plugin IITC embarqué invalide (${Number(info?.bytes||0)} octet)`);
  return info;
}
async function saveIitcBridgeFile(name='redacted-bannerlab-iitc.user.js'){
  const info=await bundledIitcInfo();
  const result=await BackupFolder.saveBundledIitcAs({fileName:name});
  if(result?.cancelled)return false;
  if(!result?.saved||Number(result?.bytes||0)!==Number(info?.bytes||0))throw new Error(`IITC plugin save failed (${Number(result?.bytes||0)}/${Number(info?.bytes||0)} bytes)`);
  toast(tr('pluginSaved'));
  return true;
}
async function openIitcBridgeDirect(name='redacted-bannerlab-iitc.user.js'){
  try{
    const info=await bundledIitcInfo();
    const result=await BackupFolder.openBundledIitcWithIitc({
      fileName:name,
      packageName:'org.exarhteam.iitc_mobile'
    });
    if(!result?.opened||Number(result?.bytes||0)!==Number(info?.bytes||0))throw new Error(`IITC direct open failed (${Number(result?.bytes||0)}/${Number(info?.bytes||0)} bytes)`);
    toast(tr('pluginOpenedIitc'));
    return true;
  }catch(e){
    console.warn('[IITC direct plugin open]',e);
    toast(`${tr('pluginOpenFailed')} · ${e?.message||e}`);
    return false;
  }
}
async function shareIitcBridge(){
  const name='redacted-bannerlab-iitc.user.js';
  try{
    if(!Capacitor.isNativePlatform()){
      const text=await bridgeUserscriptText();
      downloadBlob(new Blob([text],{type:'text/javascript;charset=utf-8'}),name);
      toast(tr('pluginSaved'));
      return;
    }

    const info=await bundledIitcInfo();
    const kb=(Number(info.bytes)/1024).toFixed(1);
    const sh=openSheet(`<div class="sheethead"><div><h2>${tr('pluginInstallChoiceTitle')}</h2><p>${tr('pluginInstallChoiceText')}</p><div class="rule ok"><span class="dot"></span><span>Companion 0.6.6 · ${kb} Ko · APK ✓</span></div></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="tutorialsteps">
        <div class="tutorialstep"><b>1</b><div><strong>${tr('pluginOpenIitc')}</strong><span>${tr('pluginOpenIitcText')}</span></div></div>
        <div class="tutorialstep"><b>2</b><div><strong>${tr('pluginSaveFile')}</strong><span>${tr('pluginSaveFileText')}</span></div></div>
      </div>
      <div class="actions"><button class="primary openiitcplugin">${tr('pluginOpenIitc')}</button><button class="secondary saveiitcplugin">${tr('pluginSaveFile')}</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('.openiitcplugin',sh).onclick=async()=>{
      const ok=await openIitcBridgeDirect(name);
      if(ok)closeSheet();
    };
    $('.saveiitcplugin',sh).onclick=async()=>{
      try{
        const saved=await saveIitcBridgeFile(name);
        if(saved)closeSheet();
      }catch(e){console.error('[IITC plugin save]',e);toast(`${tr('pluginSaveFailed')} · ${e?.message||e}`)}
    };
  }catch(e){console.error('[IITC plugin install]',e);toast(`${tr('pluginSaveFailed')} · ${e?.message||e}`)}
}

function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>${tr('tutorialIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>${tr('tut1Title')}</strong><span>${tr('tut1Text')}</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>${tr('tut2Title')}</strong><span>${tr('tut2Text')}</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>${tr('tut3Title')}</strong><span>${tr('tut3Text')}</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>${tr('tut4Title')}</strong><span>${tr('tut4Text')}</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>${tr('tutNote')}</span></div>
    <div class="actions"><button class="secondary installplugin">${tr('installUpdate')}</button><button class="primary launchiitc">${tr('openIitc')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}

function handleBridgeUrl(raw){
  try{
    const u=new URL(raw);if(u.protocol!=='redactedbannerlab:')return false;
    if(u.hostname==='play'||u.hostname==='banner'){
      const id=u.searchParams.get('banner')||u.searchParams.get('id')||'';const mission=Math.max(0,parseInt(u.searchParams.get('mission')||'0')||0);
      if(!id)return false;setTimeout(()=>joinSharedBanner(id,mission),120);return true;
    }
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||tr('portalDefault'),imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='publisher-chrome-ready'){
      setPublisherReady('chrome',true);
      setChromeSetupStep(4);
      setPublisherBrowser('chrome');
      toast(tr('setupConfirmed'));
      closeSheet();
      setTimeout(()=>openChromeSetupSheet(4),120);
      return true;
    }
    if(u.hostname==='publisher-firefox-ready'){
      setPublisherReady('firefox',true);
      setPublisherBrowser('firefox');
      toast(tr('setupConfirmed'));
      return true;
    }
    if(u.hostname==='publisher-next'){
      const index=clamp(parseInt(u.searchParams.get('mission'))||0,0,state.planner.missions.length-1);
      state.planner.currentMission=index;
      scheduleSave();saveProject();
      setTimeout(()=>openBrowserPublisher(index),180);
      return true;
    }
    if(u.hostname==='publisher-return'){
      toast(tr('publisherReturn'));
      return true;
    }
    if(u.hostname==='sync'){
      const data=bridgeDecode(u.searchParams.get('data')||'');if(!data||!Number.isFinite(Number(data.v))||Number(data.v)<2||!Array.isArray(data.m))return false;
      ensurePlannerMissions();
      state.planner.portalsPerMission=clamp(parseInt(data.ppm)||state.planner.portalsPerMission,MIN_PORTALS_PER_MISSION,24);
      state.planner.autoAdvance=data.auto!==false;if(typeof data.carry==='boolean')state.planner.reuseLastPortal=data.carry;
      data.m.slice(0,state.planner.missions.length).forEach((portals,i)=>{if(Array.isArray(portals))state.planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean)});
      state.planner.currentMission=clamp(parseInt(data.c)||0,0,state.planner.missions.length-1);
      scheduleSave();saveProject();
      if(!data.pv)toast(tr('syncOld'));
      else toast(tr('syncOk',{v:data.pv}));
      openRoutePlanner();return true;
    }
    return false;
  }catch(e){console.warn('bridge',e);toast(tr('syncUnreadable'));return false}
}
function openMissionSettings(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(m=>m.portals.length>=need).length;
  const hasDescription=!!state.planner.description.trim();

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')}</h2><p>${complete}/${state.planner.missions.length} ${tr('missionReady').toLowerCase()}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>

    <div class="requiredFieldCard ${hasDescription?'ok':'missing'}">
      <div class="requiredFieldHead">
        <div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div>
        <strong>${hasDescription?'✓':'!'}</strong>
      </div>
      <textarea id="bannerDesc" rows="4" placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
      <small>${tr('bannerDescriptionHint')}</small>
    </div>

    <details class="missiondefaults">
      <summary>${tr('settings')}</summary>
      <div class="missiondefaults-body">
        <div class="field"><label>${tr('titleFormat')}</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><small>${tr('titleTokens')}</small></div>
        <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>${tr('sequential')}</option><option value="0" ${!state.planner.sequential?'selected':''}>${tr('anyOrder')}</option></select></div>
        <div class="field"><label>${tr('location')}</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>${tr('visible')}</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>${tr('hidden')}</option></select></div></div>
        <div class="field"><label>${tr('portalsPerMission')}</label><input id="ppm" type="number" min="${MIN_PORTALS_PER_MISSION}" max="24" value="${need}"><small>${tr('minimumSix')}</small></div>
      </div>
    </details>

    <div class="missionlist-v2">${state.planner.missions.map((x,i)=>{
      const ok=x.portals.length>=need;
      return `<button class="missioncard-v2 ${ok?'ok':''}" data-mi="${i}">
        <span class="missioncard-num">${String(i+1).padStart(2,'0')}</span>
        <span class="missioncard-copy"><b>${escapeHtml(x.title||generatedMissionTitle(i))}</b><small>${x.portals.length}/${need} · ${formatDistance(missionDistance(x))}</small></span>
        <span class="missioncard-state">${ok?'✓':'!'}</span>
      </button>`;
    }).join('')}</div>`);

  $('.close',sh).onclick=closeSheet;

  $('#bannerDesc',sh).oninput=e=>{
    const value=e.target.value;
    state.planner.description=value;
    state.planner.missions.forEach(x=>{
      if(!x.descriptionCustom)x.description=value;
    });
    scheduleSave();

    const card=$('.requiredFieldCard',sh);
    const valid=!!value.trim();
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{
    state.planner.portalsPerMission=clamp(parseInt(e.target.value)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24);
    scheduleSave();
    openMissionSettings();
  };
  $$('.missioncard-v2',sh).forEach(btn=>btn.onclick=()=>openMissionDetail(+btn.dataset.mi));
}

function openMissionDetail(idx){
  ensurePlannerMissions();state.planner.currentMission=idx;const m=plannerMission(idx);
  const seq=missionSequential(m),hidden=missionHidden(m);
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${idx+1}</h2><p>${m.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(m))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionsetcard missiondetail-v2">
      <div class="field"><label>${tr('title')}</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>${tr('description')}</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="missionSeq"><option value="1" ${seq?'selected':''}>${tr('sequential')}</option><option value="0" ${!seq?'selected':''}>${tr('anyOrder')}</option></select></div>
      <div class="field"><label>${tr('location')}</label><select id="missionHidden" ${!seq?'disabled':''}><option value="0" ${!hidden?'selected':''}>${tr('visible')}</option><option value="1" ${hidden?'selected':''}>${tr('hidden')}</option></select></div></div>
      <div class="missiondetail-actions"><button class="secondary backmissions">‹ ${tr('missions')}</button><button class="primary openRoute">${icon('route')} ${tr('openRoute')}</button></div>
    </div>`);
  $('.close',sh).onclick=closeSheet;
  $('.backmissions',sh).onclick=openMissionSettings;
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('#missionSeq',sh).onchange=e=>{m.sequential=e.target.value==='1';if(!m.sequential)m.hiddenLocation=false;scheduleSave();openMissionDetail(idx)};
  $('#missionHidden',sh).onchange=e=>{m.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('.openRoute',sh).onclick=openRoutePlanner;
}
function missionPublishIssues(index=state.planner.currentMission){
  ensurePlannerMissions();
  const issues=[];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const m=state.planner.missions[clamp(index,0,state.planner.missions.length-1)];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));
  if(!m)return issues;

  if(!String(m.title||'').trim())issues.push(tr('emptyTitleIssue',{n:index+1}));
  if(!String(m.description||'').trim())issues.push(tr('emptyDescIssue',{n:index+1}));
  if((m.portals||[]).length<need){
    issues.push(tr('missionNeedsPortals',{n:index+1,count:(m.portals||[]).length,need}));
  }

  const missing=(m.portals||[]).filter(p=>!p.guid).length;
  if(missing)issues.push(tr('missingGuidIssue',{n:index+1,count:missing}));

  const badPass=(m.portals||[]).filter(p=>
    p.objective?.type==='PASSPHRASE' &&
    (!p.objective?.passphrase_params?.question?.trim() ||
     !p.objective?.passphrase_params?._single_passphrase?.trim())
  ).length;
  if(badPass)issues.push(tr('passIssue',{n:index+1,count:badPass}));

  return issues;
}

function validatePlanner(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const issues=[];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));

  state.planner.missions.forEach((m,i)=>{
    const n=i+1;
    if(!m.title.trim())issues.push(tr('emptyTitleIssue',{n}));
    if(!m.description.trim())issues.push(tr('emptyDescIssue',{n}));
    if(m.portals.length<need)issues.push(tr('portalsIssue',{n,count:m.portals.length,need}));

    const missing=m.portals.filter(p=>!p.guid).length;
    if(missing)issues.push(tr('missingGuidIssue',{n,count:missing}));

    const badPass=m.portals.filter(p=>
      p.objective?.type==='PASSPHRASE' &&
      (!p.objective?.passphrase_params?.question?.trim() ||
       !p.objective?.passphrase_params?._single_passphrase?.trim())
    ).length;
    if(badPass)issues.push(tr('passIssue',{n,count:badPass}));
  });
  return issues;
}

function openBannerDescriptionRequired(onSaved){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('describeBeforePublish')}</h2><p>${tr('describeBeforePublishText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="requiredFieldCard missing">
      <div class="requiredFieldHead"><div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div><strong>!</strong></div>
      <textarea id="requiredBannerDesc" rows="5" autofocus placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
    </div>
    <div class="actions"><button class="primary saveDesc" disabled>${tr('saveAndContinue')}</button></div>`);

  $('.close',sh).onclick=closeSheet;
  const input=$('#requiredBannerDesc',sh);
  const save=$('.saveDesc',sh);

  const update=()=>{
    const valid=!!input.value.trim();
    save.disabled=!valid;
    const card=$('.requiredFieldCard',sh);
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  input.oninput=update;
  update();
  setTimeout(()=>input.focus(),80);

  save.onclick=()=>{
    const value=input.value.trim();
    if(!value)return;
    state.planner.description=value;
    state.planner.missions.forEach(m=>{
      if(!m.descriptionCustom)m.description=value;
    });
    scheduleSave();
    saveProject();
    closeSheet();
    if(typeof onSaved==='function')setTimeout(onSaved,80);
  };
}

function missionPublisherData(m,i,imageDataUrl=''){
  return {
    number:i+1,
    title:m.title||generatedMissionTitle(i),
    description:m.description||'',
    sequential:missionSequential(m),
    hiddenLocation:missionHidden(m),
    imageDataUrl,
    portals:(m.portals||[]).map(p=>({
      guid:p.guid||'',title:p.title||tr('portalDefault'),
      latitude:Number(p.location?.latitude)||0,longitude:Number(p.location?.longitude)||0,
      imageUrl:p.imageUrl||'',description:p.description||'',
      objective:{
        type:p.objective?.type||'HACK_PORTAL',
        question:p.objective?.passphrase_params?.question||'',
        answer:p.objective?.passphrase_params?._single_passphrase||''
      }
    }))
  };
}
async function buildPublisherSession(){
  ensurePlannerMissions();
  if(!state.bg.image)throw new Error(tr('noBackground'));
  const issues=validatePlanner();
  if(issues.length){const e=new Error(issues.join('\n'));e.rblBlockingIssues=issues;throw e}
  const total=state.planner.missions.length;
  const missions=[];
  for(let index=0;index<total;index++){
    toast(tr('publisherSessionCreating',{n:index+1,total}));
    const {row,col}=rowColForMission(index+1),c=document.createElement('canvas');
    c.width=c.height=512;drawTile(c,row,col,512);
    const imageDataUrl=c.toDataURL('image/jpeg',.90);
    missions.push(missionPublisherData(state.planner.missions[index],index,imageDataUrl));
    if(index%2===1)await tick();
  }
  return {
    format:'redacted-bannerlab-publisher-session',version:2,appVersion:APP_VERSION,
    sessionId:`${state.projectId||'project'}-${Date.now()}`,
    projectId:state.projectId||'',name:state.name,language:projectLanguage(),
    portalsPerMission:Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission),
    currentIndex:0,missions
  };
}

async function savePublisherSessionFile(){
  const session=await buildPublisherSession();
  const currentName='RBL_Current_Session.rblpub.json';
  const projectName=`RBL_${safeName(state.name)}.rblpub.json`;
  const text=JSON.stringify(session);

  if(Capacitor.isNativePlatform()){
    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    // Stable filename: Chrome can remember this exact file handle and RBL
    // simply overwrites its contents when another project is prepared.
    await Filesystem.writeFile({
      path:`${folder}/${currentName}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    // Human-readable project copy, useful for manual loading/recovery.
    if(projectName!==currentName){
      await Filesystem.writeFile({
        path:`${folder}/${projectName}`,
        data:text,
        directory:Directory.Documents,
        encoding:Encoding.UTF8
      }).catch(e=>console.warn('[Publisher project copy]',e));
    }
  }else{
    downloadBlob(new Blob([text],{type:'application/json'}),projectName);
  }

  toast(tr('publisherSessionReady'));
  return {session,currentName,projectName};
}

const PUBLISH_BROWSER_KEY='rblPublisherBrowser';
const CHROME_READY_KEY='rblPublisherChromeReady';
const FIREFOX_READY_KEY='rblPublisherFirefoxReady';
const CHROME_STEP_KEY='rblPublisherChromeStep';
const CHROME_CODE_KEY='rblPublisherChromeCodeCopied';
const PUBLISHER_SETUP_VERSION='0.10.7';
const CHROME_SETUP_VERSION_KEY='rblPublisherChromeSetupVersion';
const FIREFOX_SETUP_VERSION_KEY='rblPublisherFirefoxSetupVersion';

function publisherBrowser(){
  return localStorage.getItem(PUBLISH_BROWSER_KEY)||'chrome';
}
function setPublisherBrowser(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  localStorage.setItem(PUBLISH_BROWSER_KEY,browser);
  toast(tr('browserSaved',{browser:browser==='firefox'?tr('firefoxMode'):tr('chromeMode')}));
}
function publisherReady(browser){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  return localStorage.getItem(readyKey)==='1'
    && localStorage.getItem(versionKey)===PUBLISHER_SETUP_VERSION;
}
function setPublisherReady(browser,value=true){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  localStorage.setItem(readyKey,value?'1':'0');
  if(value)localStorage.setItem(versionKey,PUBLISHER_SETUP_VERSION);
  else localStorage.removeItem(versionKey);
  if(browser==='chrome'&&value)localStorage.setItem(CHROME_STEP_KEY,'4');
}
function chromeSetupStep(){
  if(publisherReady('chrome'))return 4;
  if(localStorage.getItem(CHROME_SETUP_VERSION_KEY)!==PUBLISHER_SETUP_VERSION){
    localStorage.setItem(CHROME_STEP_KEY,'1');
    localStorage.removeItem(CHROME_CODE_KEY);
  }
  return clamp(parseInt(localStorage.getItem(CHROME_STEP_KEY))||1,1,3);
}
function setChromeSetupStep(step){
  step=clamp(parseInt(step)||1,1,4);
  localStorage.setItem(CHROME_STEP_KEY,String(step));
}
function resetChromeSetup(){
  setPublisherReady('chrome',false);
  localStorage.setItem(CHROME_STEP_KEY,'1');
  localStorage.removeItem(CHROME_CODE_KEY);
  toast(tr('chromeResetDone'));
}

async function prepareAndOpenPublisher(browser=publisherBrowser()){
  if(!Capacitor.isNativePlatform()){toast(tr('liveNativeOnly'));return}
  try{
    if(!publisherReady(browser)){
      if(browser==='firefox')openFirefoxSetupSheet();else openChromeSetupSheet();
      toast(browser==='firefox'?tr('firefoxNeedsSetup'):tr('chromeNeedsSetup'));
      return;
    }

    await saveProject();

    // Keep the stable JS file current without changing the bookmark.
    if(browser==='chrome'){
      await saveChromePublisherDirect().catch(e=>console.warn('[Publisher JS refresh]',e));
    }

    await savePublisherSessionFile();

    const packageName=browser==='firefox'?'org.mozilla.firefox':'com.android.chrome';
    const url='https://missions.ingress.com/';

    toast(tr('browserResume'));
    toast(browser==='chrome'?tr('chromeResumeHint'):tr('firefoxResumeHint'));

    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:url,
        packageName,
        // Browser.EXTRA_APPLICATION_ID:
        // Android/Chrome will associate this external-app id with a browser
        // tab and attempt to reuse that same tab on later launches.
        extra:{
          'com.android.browser.application_id':'com.bannerforge.mobile'
        },
        // Intent.FLAG_ACTIVITY_NEW_TASK
        flags:268435456
      });
    }catch(e){
      console.warn('[Publisher app-tab launch]',e);
      toast(tr('browserResumeFallback'));
      try{
        await IntentLauncher.openApplication({packageName});
      }catch(e2){
        await AppLauncher.openUrl({url});
      }
    }
  }catch(e){
    console.error('[Publisher session]',e);
    if(e?.rblBlockingIssues){openPublishSheet();return}
    toast(tr('browserFailed',{error:e?.message||e}));
  }
}
async function openChromePublisher(){return prepareAndOpenPublisher('chrome')}
async function openFirefoxPublisher(){return prepareAndOpenPublisher('firefox')}
async function openBrowserPublisher(){return prepareAndOpenPublisher(publisherBrowser())}

async function saveChromePublisherDirect(){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(!Capacitor.isNativePlatform()){
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
      return true;
    }

    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    await Filesystem.writeFile({
      path:`${folder}/${name}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    toast(tr('chromeFileSaved'));
    return true;
  }catch(e){
    console.error('[Chrome Publisher direct write]',e);
    toast(tr('chromeFileWriteFail'));
    return false;
  }
}

async function shareBrowserPublisher(forChrome=false){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({
        path:`RedactedBannerLab/${name}`,
        data:text,
        directory:Directory.Cache,
        encoding:Encoding.UTF8
      });
      const uri=await Filesystem.getUri({
        path:`RedactedBannerLab/${name}`,
        directory:Directory.Cache
      });
      await Share.share({
        title:'Redacted BannerLab Publisher 0.4.0',
        text:forChrome?tr('chromeFileShareText'):tr('browserShareText'),
        url:uri.uri,
        dialogTitle:forChrome?tr('chromeFileShareDialog'):tr('browserShareDialog')
      });
    }else{
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
    }
    return true;
  }catch(e){
    console.error('[Browser Publisher share]',e);
    toast(forChrome?tr('chromeFileShareFail'):tr('browserShareFailed'));
    return false;
  }
}

async function chromeBookmarkletText(){
  const r=await fetch('/redacted-bannerlab-chrome-bookmarklet.txt');
  if(!r.ok)throw new Error('bookmarklet '+r.status);
  return r.text();
}

async function copyChromeBookmarklet(){
  const code=await chromeBookmarkletText();
  try{
    await navigator.clipboard.writeText(code);
    localStorage.setItem(CHROME_CODE_KEY,'1');
    toast(tr('miniCodeCopied'));
    return true;
  }catch(e){
    console.warn('[Chrome bookmarklet clipboard]',e);
    return false;
  }
}

async function openChromeSetupPage(test=false){
  const url=test
    ?'https://missions.ingress.com/#rblsetup=chrome&rblpick=1'
    :'https://missions.ingress.com/';
  try{
    await IntentLauncher.startActivityAsync({
      action:ActivityAction.VIEW,
      data:url,
      packageName:'com.android.chrome'
    });
    if(test)toast(tr('chromeTestWaiting'));
  }catch(e){
    toast(tr('chromeOpenFail'));
    await AppLauncher.openUrl({url});
  }
}

async function openChromeSetupSheet(step=chromeSetupStep()){
  step=publisherReady('chrome')?4:clamp(parseInt(step)||1,1,3);
  setChromeSetupStep(step);
  const code=await chromeBookmarkletText().catch(()=> '');
  const codeCopied=localStorage.getItem(CHROME_CODE_KEY)==='1';

  let body='';
  if(step===1){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">📄</div>
      <h3>${tr('chromeFileTitle')}</h3>
      <p>${tr('chromeFileText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromeFilePath')}</span></div>
      <button class="primary savepub">${tr('chromeSaveFile')}</button>
      <button class="secondary alreadysaved">${tr('alreadySaved')}</button>
    </div>`;
  }else if(step===2){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">⭐</div>
      <h3>${tr('chromeBookmarkTitle')}</h3>
      <p>${tr('chromeBookmarkText',{n:code.length})}</p>
      <div class="chromeCodeMeta"><b>${tr('chromeBookmarkName')}</b><span>${tr('codeLength',{n:code.length})}</span></div>
      <textarea class="bookmarkcode" readonly>${escapeHtml(code)}</textarea>
      <button class="primary copybookmark">${codeCopied?'✓ ':''}${tr('copyMiniCode')}</button>
      <button class="secondary openchrome">${tr('openChromeBookmark')}</button>
      <div class="rule warning"><span class="dot"></span><span>${tr('chromeNotAutoFavorite')}</span></div>
      <p class="chromeWizardHelp">${tr('chromeBookmarkHow')}</p>
      <button class="secondary bookmarkdone">${tr('bookmarkCreated')}</button>
    </div>`;
  }else if(step===3){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">✅</div>
      <h3>${tr('chromeTestTitle')}</h3>
      <p>${tr('chromeTestText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromePermissionHint')}<br>${tr('chromeSelectFileHint')}<br>${tr('chromeCurrentSessionHint')}</span></div>
      <button class="primary testchrome">${tr('chromeTestButton')}</button>
      <p class="chromeWizardHelp">${tr('chromeTestWaiting')}</p>
    </div>`;
  }else{
    body=`<div class="chromeWizardCard success">
      <div class="chromeWizardIcon">✓</div>
      <h3>${tr('chromeSetupSuccess')}</h3>
      <p>${tr('chromeSetupSuccessText')}</p>
      <button class="primary publishnow">${tr('publishNow')}</button>
    </div>`;
  }

  const dots=[1,2,3].map(n=>`<span class="${step===n?'active':step>n?'done':''}">${step>n?'✓':n}</span>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('chromeWizardTitle')}</h2><p>${step<=3?tr('stepOf',{n:step}):tr('chromeSetupSuccess')} · ${tr('chromeWizardIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="chromeWizardProgress">${dots}</div>
    ${body}
    <div class="chromeWizardNav">
      ${step>1&&step<=3?`<button class="secondary wizardprev">← ${tr('wizardPrev')}</button>`:''}
      ${step<3?`<button class="secondary wizardnext">${tr('wizardNext')} →</button>`:''}
    </div>
    <button class="chromeRestart">${tr('wizardRestart')}</button>`);

  $('.close',sh).onclick=closeSheet;
  $('.wizardprev',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step-1)});
  $('.wizardnext',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step+1)});

  $('.savepub',sh)?.addEventListener('click',async()=>{
    const ok=await saveChromePublisherDirect();
    if(ok){
      setChromeSetupStep(2);
      closeSheet();
      openChromeSetupSheet(2);
    }
  });
  $('.alreadysaved',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(2);closeSheet();openChromeSetupSheet(2);
  });

  $('.copybookmark',sh)?.addEventListener('click',async()=>{
    if(await copyChromeBookmarklet()){
      closeSheet();openChromeSetupSheet(2);
    }else toast(tr('bookmarkletCopyFail'));
  });
  $('.openchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(false));
  $('.bookmarkdone',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(3);closeSheet();openChromeSetupSheet(3);
  });

  $('.testchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(true));
  $('.publishnow',sh)?.addEventListener('click',()=>{
    closeSheet();openChromePublisher(state.planner.currentMission);
  });

  $('.chromeRestart',sh).onclick=()=>{
    resetChromeSetup();
    closeSheet();
    openChromeSetupSheet(1);
  };
}

function openFirefoxSetupSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('firefoxSetupTitle')}</h2><p>${tr('firefoxSetupIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="actions"><button class="primary sharepublisher">${tr('sharePublisher')}</button></div>
    <div class="actions"><button class="secondary testfirefox">${tr('testFirefox')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.sharepublisher',sh).onclick=()=>shareBrowserPublisher(false);
  $('.testfirefox',sh).onclick=async()=>{
    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:'https://missions.ingress.com/#rblsetup=firefox',
        packageName:'org.mozilla.firefox'
      });
    }catch(e){
      toast(tr('publisherNoFirefox'));
    }
  };
}

function openPublishSheet(){
  ensurePlannerMissions();
  if(!state.planner.description.trim()){openBannerDescriptionRequired(openPublishSheet);return}

  const issues=validatePlanner();
  const current=state.planner.currentMission;
  const currentIssues=missionPublishIssues(current);
  const m=state.planner.missions[current];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(x=>x.portals.length>=need && String(x.description||'').trim()).length;
  const total=state.planner.missions.length;
  const mode=publisherBrowser();
  const chromeReady=publisherReady('chrome'),firefoxReady=publisherReady('firefox');
  const blocked=issues.length>0;

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('publish')}</h2><p>${complete}/${total} · ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishMissionGate ${blocked?'blocked':'ready'}">
      <div class="publishMissionGateHead"><span class="missioncard-num">${String(current+1).padStart(2,'0')}</span><div><b>${escapeHtml(m?.title||generatedMissionTitle(current))}</b><small>${m?.portals?.length||0}/${need} · ${tr('bannerDescription')} ✓</small></div><strong>${blocked?'!':'✓'}</strong></div>
      ${blocked?`<div class="publishBlockingList">${issues.slice(0,12).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}</div><div class="actions"><button class="primary completemission">${icon('route')} ${tr('completeMission')}</button></div>`:`<div class="publishReadyText">${tr('publisherWholeHint')}<small>${tr('publisherCurrentFile')}</small></div>`}
    </div>
    ${blocked?`<div class="publishscore warn"><b>${tr('reviewCount',{n:issues.length})}</b><span>${tr('publisherAllRequired')}</span></div>`:''}
    <div class="field"><label>${tr('publisherBrowser')}</label><div class="publisherchoices">
      <button class="publisherchoice chrome ${mode==='chrome'?'selected':''}" data-mode="chrome"><span class="browsericon">🌐</span><span><b>${tr('chromeMode')}</b><small>${tr('chromeModeSub')}</small><em>${chromeReady?'✓ '+tr('chromeReady'):tr('noExtraApp')}</em></span></button>
      <button class="publisherchoice firefox ${mode==='firefox'?'selected':''}" data-mode="firefox"><span class="browsericon">🦊</span><span><b>${tr('firefoxMode')}</b><small>${tr('firefoxModeSub')}</small><em>${firefoxReady?'✓ '+tr('firefoxReady'):tr('recommendedAuto')}</em></span></button>
    </div></div>
    <div class="actions"><button class="primary livepublisher" ${blocked?'disabled':''}>🚀 ${tr('publisherWholeBanner')}</button></div>
    <div class="actions"><button class="secondary setupselected">${mode==='firefox'?tr('firefoxSetup'):tr('chromeSetup')}</button></div>
    <details class="missionCommon"><summary>${tr('backupTransfer')}</summary><div class="missionCommonBody"><div class="actions"><button class="secondary exportpack">${icon('download')} ${tr('exportPackBackup')}</button></div><div class="actions"><button class="secondary openmat">${icon('globe')} ${tr('openOfficialOnly')}</button></div></div></details>`);
  $('.close',sh).onclick=closeSheet;
  $('.completemission',sh)?.addEventListener('click',()=>{closeSheet();state.planner.currentMission=current;scheduleSave();openRoutePlanner()});
  $$('.publisherchoice',sh).forEach(btn=>btn.onclick=()=>{setPublisherBrowser(btn.dataset.mode);closeSheet();openPublishSheet()});
  $('.livepublisher',sh).onclick=()=>openBrowserPublisher();
  $('.setupselected',sh).onclick=()=>publisherBrowser()==='firefox'?openFirefoxSetupSheet():openChromeSetupSheet();
  $('.exportpack',sh).onclick=exportBannerLabPack;$('.openmat',sh).onclick=openMissionAuthoring;
}

async function exportBannerLabPack(){
  ensurePlannerMissions();
  const zip=new JSZip(),imgFolder=zip.folder('missions');
  const manifest={
    format:'redacted-bannerlab',version:1,appVersion:APP_VERSION,name:state.name,
    language:projectLanguage(),portalsPerMission:state.planner.portalsPerMission,
    missions:state.planner.missions.map((m,i)=>({
      number:i+1,title:m.title,description:m.description,sequential:missionSequential(m),hiddenLocation:missionHidden(m),
      image:`missions/${String(i+1).padStart(3,'0')}.jpg`,
      portals:(m.portals||[]).map(p=>({
        guid:p.guid,title:p.title,latitude:p.location.latitude,longitude:p.location.longitude,imageUrl:p.imageUrl||'',
        objective:{type:p.objective?.type||'HACK_PORTAL',question:p.objective?.passphrase_params?.question||'',answer:p.objective?.passphrase_params?._single_passphrase||''}
      }))
    }))
  };
  try{
    toast(tr('packCreating'));
    for(let n=1;n<=manifest.missions.length;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      imgFolder.file(`${String(n).padStart(3,'0')}.jpg`,await canvasBlob(c,'image/jpeg',.94));
      if(n%4===0)await tick();
    }
    zip.file('missions.json',JSON.stringify(manifest,null,2));
    const name=`${safeName(state.name)}_BannerLab.zip`;
    if(Capacitor.isNativePlatform()){
      const b64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true});
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:b64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:`${manifest.missions.length} ${tr('missions').toLowerCase()} · ${state.name}`,url:uri.uri,dialogTitle:name});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
      downloadBlob(blob,name);
    }
    toast(tr('packCreated'));
  }catch(e){console.error(e);toast(tr('exportImpossible',{error:e?.message||e}))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function backupAutoEnabled(){return localStorage.getItem(BACKUP_AUTO_KEY)==='1'}
function setBackupAutoEnabled(value){localStorage.setItem(BACKUP_AUTO_KEY,value?'1':'0');if(value)queueForegroundAutoBackup(250);else{clearTimeout(backupAutoTimer);backupAutoTimer=null}}
function markBackupChanged(){backupRevision++;queueForegroundAutoBackup()}
function queueForegroundAutoBackup(delay=1800){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||!backupAppActive)return;
  // Throttle volontairement au lieu de repousser le timer à chaque mouvement :
  // une longue session d'édition produit ainsi régulièrement un snapshot complet
  // pendant que le WebView est encore actif.
  if(backupAutoTimer)return;
  backupAutoTimer=setTimeout(async()=>{
    backupAutoTimer=null;
    if(!backupAutoEnabled())return;
    await autoBackupIfNeeded('foreground');
    // Si des modifications sont arrivées pendant la création du JSON, on repasse.
    if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(2200);
  },Math.max(0,delay));
}
function backupDateText(value){
  if(!value)return tr('backupNever');
  try{return tr('backupLast',{date:new Date(value).toLocaleString(appLocale(),{dateStyle:'short',timeStyle:'short'})})}catch{return tr('backupNever')}
}
async function blobToBackupMedia(blob){
  if(!blob)return null;
  const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return {mime:blob.type||'application/octet-stream',name:blob.name||'',base64:btoa(binary)};
}
function backupMediaToBlob(media){
  if(!media?.base64)return null;
  const bin=atob(media.base64),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  try{return media.name?new File([bytes],media.name,{type:media.mime||'application/octet-stream'}):new Blob([bytes],{type:media.mime||'application/octet-stream'})}catch{return new Blob([bytes],{type:media.mime||'application/octet-stream'})}
}
function portableLocalSettings(){
  const keys=[BANNER_FAVORITES_KEY,BANNER_TODO_KEY,PLAY_HISTORY_KEY,BANNER_SEARCH_PREFS_KEY,PLAY_SESSION_KEY,'rbl-language'];
  const out={};for(const k of keys){const v=localStorage.getItem(k);if(v!==null)out[k]=v}return out;
}
async function buildFullBackup(){
  await saveProject({markBackup:false});
  const rows=await getAllProjects(),projects=[];
  for(const rec of rows){
    const background=await blobToBackupMedia(rec.blob);
    const layerBlobs=[];
    for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
    projects.push({id:rec.id,data:rec.data||{},background,layerBlobs});
    await tick();
  }
  return {format:'redacted-bannerlab-backup',schemaVersion:1,appVersion:APP_VERSION,createdAt:new Date().toISOString(),currentProjectId:localStorage.getItem('redactedBannerLabCurrentProjectId')||state.projectId||'',language:APP_LANG,settings:portableLocalSettings(),projects};
}
async function fullBackupJson(){return JSON.stringify(await buildFullBackup())}
function safeProjectFilename(name='Redacted_BannerLab'){
  const clean=String(name||'Redacted_BannerLab').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,72);
  return clean||'Redacted_BannerLab';
}
async function projectRecordById(id){
  if(id===state.projectId)await saveProject({markBackup:false});
  const db=await openDB(),tx=db.transaction('project','readonly');
  return await request(tx.objectStore('project').get(id));
}
async function buildPortableProject(id=state.projectId){
  const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
  const background=await blobToBackupMedia(rec.blob),layerBlobs=[];
  for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
  return {
    format:'redacted-bannerlab-project',schemaVersion:1,appVersion:APP_VERSION,exportedAt:new Date().toISOString(),
    originalProjectId:String(rec.id||''),
    project:{data:rec.data,background,layerBlobs},
    capabilities:{images:true,customFonts:true,planner:true,routeFromPortalCoordinates:true}
  };
}
async function portableProjectJson(id=state.projectId){return JSON.stringify(await buildPortableProject(id),null,2)}
function validatePortableProject(x){return !!(x&&x.format==='redacted-bannerlab-project'&&Number(x.schemaVersion)>=1&&x.project?.data)}
async function deliverPortableProject(id,{share=false}={}){
  try{
    toast(tr('projectExporting'));
    const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
    const text=await portableProjectJson(id),name=`Redacted_BannerLab_${safeProjectFilename(rec.data.name)}.rbl.json`;
    if(Capacitor.isNativePlatform()){
      if(share){
        // Partager garde la feuille de partage Android.
        await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
        await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
        const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
        await Share.share({title:tr('projectShareTitle'),text:rec.data.name||tr('projectShareTitle'),url:uri.uri,dialogTitle:tr('shareProject')});
      }else{
        // Exporter ouvre le sélecteur Android ACTION_CREATE_DOCUMENT :
        // l'utilisateur choisit réellement le dossier et peut modifier le nom.
        const result=await BackupFolder.saveTextFileAs({fileName:name,text,mimeType:'application/json'});
        if(result?.cancelled)return;
        if(!result?.saved)throw new Error(tr('projectSaveFailed'));
      }
    }else{
      downloadBlob(new Blob([text],{type:'application/json'}),name);
    }
    toast(share?tr('projectShared'):tr('projectExported'));
  }catch(e){console.error('portable project',e);toast(tr('backupFailed',{error:e?.message||e}))}
}
async function restorePortableProject(payload){
  if(!validatePortableProject(payload)){toast(tr('projectImportInvalid'));return false}
  try{
    const src=payload.project,data=JSON.parse(JSON.stringify(src.data||{})),blob=backupMediaToBlob(src.background),layerBlobs=[];
    for(const x of (src.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    data.updatedAt=new Date().toISOString();
    const id=newProjectId(),db=await openDB(),tx=db.transaction('project','readwrite');
    tx.objectStore('project').put({id,data,blob,layerBlobs});await txDone(tx);
    markBackupChanged();await loadProject(id);resetHistory();closeSheet();toast(tr('projectImportSuccess'));return true;
  }catch(e){console.error('project import',e);toast(tr('projectImportInvalid'));return false}
}
function importPortableProject(){
  const input=document.createElement('input');input.type='file';input.accept='.json,.rbl.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());await restorePortableProject(payload)}catch(e){console.warn(e);toast(tr('projectImportInvalid'))}finally{input.remove()}};
  input.click();
}

async function backupFolderInfo(){
  if(!Capacitor.isNativePlatform())return {configured:false,label:''};
  try{return await BackupFolder.getFolder()}catch(e){console.warn('backup folder',e);return {configured:false,label:''}}
}
async function chooseBackupFolder(){
  if(!Capacitor.isNativePlatform()){toast(tr('backupNativeOnly'));return null}
  try{const r=await BackupFolder.chooseFolder();if(r?.configured){toast(tr('backupFolderChosen'));return r}}catch(e){console.warn(e);toast(tr('backupFolderError'))}return null;
}
function refreshBackupLastStatus(when=localStorage.getItem(BACKUP_LAST_KEY)){
  $$('.backupLastStatus').forEach(el=>{el.textContent=backupDateText(when)});
}
async function writeBackupToFolder({automatic=false,force=false}={}){
  if(backupInProgress)return false;
  if(automatic&&!force&&lastBackedRevision===backupRevision)return false;
  const folder=await backupFolderInfo();if(!folder?.configured){if(!automatic)toast(tr('backupNeedFolder'));return false}
  const targetRevision=backupRevision;
  backupInProgress=true;
  try{
    if(!automatic)toast(tr('backupWorking'));
    const text=await fullBackupJson();
    await BackupFolder.writeTextFile({fileName:BACKUP_FILE_NAME,text});
    const when=new Date().toISOString();localStorage.setItem(BACKUP_LAST_KEY,when);lastBackedRevision=Math.max(lastBackedRevision,targetRevision);refreshBackupLastStatus(when);
    // Pas de toast pour les sauvegardes automatiques de premier plan : elles peuvent
    // arriver régulièrement et ne doivent pas interrompre l'édition.
    if(!automatic)toast(tr('backupSaved'));
    return true;
  }catch(e){console.error('backup',e);if(!automatic)toast(tr('backupFailed',{error:e?.message||e}));return false}
  finally{backupInProgress=false;if(backupAppActive&&backupAutoEnabled()&&lastBackedRevision!==backupRevision)queueForegroundAutoBackup(1200)}
}
async function exportFullBackupJson(){
  if(backupInProgress)return;backupInProgress=true;
  try{
    toast(tr('backupWorking'));const text=await fullBackupJson();const name=`Redacted_BannerLab_Backup_${new Date().toISOString().slice(0,19).replaceAll(':','-')}.json`;
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:tr('backupTitle'),url:uri.uri,dialogTitle:name});
    }else downloadBlob(new Blob([text],{type:'application/json'}),name);
    toast(tr('backupSaved'));
  }catch(e){console.error(e);toast(tr('backupFailed',{error:e?.message||e}))}finally{backupInProgress=false}
}
function validateBackupPayload(x){return !!(x&&x.format==='redacted-bannerlab-backup'&&Number(x.schemaVersion)>=1&&Array.isArray(x.projects))}
async function restoreFullBackup(payload,{replace=false}={}){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return false}
  const prepared=[];
  for(const rec of payload.projects){
    if(!rec?.id||!rec?.data)continue;
    const blob=backupMediaToBlob(rec.background),layerBlobs=[];
    for(const x of (rec.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    prepared.push({id:String(rec.id),data:rec.data,blob,layerBlobs});await tick();
  }
  if(!prepared.length){toast(tr('backupInvalid'));return false}
  const db=await openDB();const tx=db.transaction('project','readwrite'),store=tx.objectStore('project');if(replace)store.clear();for(const rec of prepared)store.put(rec);await txDone(tx);
  if(payload.settings&&typeof payload.settings==='object')for(const [k,v] of Object.entries(payload.settings))if(typeof v==='string'&&k!==BACKUP_AUTO_KEY&&k!==BACKUP_LAST_KEY)localStorage.setItem(k,v);
  if(SUPPORTED_LANGS.includes(payload.language))localStorage.setItem('rbl-language',payload.language);
  const target=prepared.some(x=>x.id===payload.currentProjectId)?payload.currentProjectId:prepared[0].id;localStorage.setItem('redactedBannerLabCurrentProjectId',target);
  localStorage.setItem('redactedBannerLabMigrationDone','1');markBackupChanged();toast(tr('backupImported'));setTimeout(()=>location.reload(),450);return true;
}
function confirmBackupImport(payload){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return}
  const date=(()=>{try{return new Date(payload.createdAt).toLocaleString(appLocale())}catch{return payload.createdAt||'—'}})();
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('backupImportTitle')}</h2><p>${tr('backupImportText',{n:payload.projects.length,date})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('backupReplaceWarn')}</span></div><div class="actions"><button class="secondary mergeBackup">${tr('backupMerge')}</button><button class="danger replaceBackup">${tr('backupReplace')}</button></div>`);
  $('.close',sh).onclick=()=>openInfoSheet();$('.mergeBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:false});$('.replaceBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:true});
}
function importFullBackupJson(){
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());confirmBackupImport(payload)}catch(e){console.warn(e);toast(tr('backupInvalid'))}finally{input.remove()}};input.click();
}
async function autoBackupIfNeeded(reason='background'){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||backupInProgress||lastBackedRevision===backupRevision)return false;
  try{
    // Sauvegarde d'abord le projet courant dans IndexedDB, puis construit le JSON.
    await saveProject({markBackup:false});
    return await writeBackupToFolder({automatic:true});
  }catch(e){console.warn('auto backup '+reason,e);return false}
}
function autoBackupOnBackground(reason='background'){
  backupAppActive=false;
  clearTimeout(backupAutoTimer);backupAutoTimer=null;
  // On lance immédiatement le flush. En parallèle, les snapshots réguliers faits
  // au premier plan évitent de dépendre de ce court créneau avant suspension Android.
  void autoBackupIfNeeded(reason);
}
function autoBackupOnForeground(){backupAppActive=true;if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(500)}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('settingsInfo')}</h2><p>Redacted BannerLab · ${tr('versionLabel')} ${APP_VERSION}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('language')}</label><select id="appLanguage">${SUPPORTED_LANGS.map(code=>`<option value="${code}" ${APP_LANG===code?'selected':''}>${LANG_META[code].flag} ${LANG_META[code].name}</option>`).join('')}</select></div>
    <div class="rulelist">
      <div class="rule"><span class="dot"></span><span><b>Prime</b> · ${tr('infoPrime')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>Mission Planner</b> · ${tr('infoPlanner')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>IITC Companion 0.6.6</b> · ${tr('infoCompanion')}</span></div>
      <div class="rule warning"><span class="dot"></span><span>${tr('disclaimer')}</span></div>
    </div>

    <div class="tutorialHubSection">
      <div class="tutorialHubCard"><div class="tutorialHubHead"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><strong>🎓 ${tr('tutorialHubTitle')}</strong><p>${tr('tutorialHubText')}</p></div></div><button class="primary tutorialHubOpen">${tr('tutorialOpen')}</button></div>
    </div>

    <div class="backupSection">
      <div class="backupCard">
        <div class="backupHead"><span>💾</span><div><strong>${tr('backupTitle')}</strong><p>${tr('backupText')}</p></div></div>
        <div class="backupFolderLine"><div><b>${tr('backupFolder')}</b><small class="backupFolderStatus">${tr('backupFolderNone')}</small></div><button class="secondary chooseBackupFolder">${tr('backupFolderChoose')}</button></div>
        <label class="switchline backupAutoLine"><input type="checkbox" class="backupAutoToggle" ${backupAutoEnabled()?'checked':''} ${Capacitor.isNativePlatform()?'':'disabled'}> ${tr('backupAuto')}</label>
        <small class="backupHint">${tr('backupAutoHint')}</small>
        <div class="backupActions"><button class="primary backupNow" ${Capacitor.isNativePlatform()?'':'disabled'}>💾 ${tr('backupNow')}</button><button class="secondary backupExport">${icon('download')} ${tr('backupExport')}</button><button class="secondary backupImport">${icon('upload')} ${tr('backupImport')}</button></div>
        <small class="backupPortable">${tr('backupPortable')}</small><small class="backupLastStatus">${backupDateText(localStorage.getItem(BACKUP_LAST_KEY))}</small>
      </div>
    </div>

    <div class="creatorCommunity">
      <div class="creatorLine"><span class="creatorMark">R</span><div><strong>${tr('creatorBy')}</strong><small>Redacted BannerLab</small></div></div>
      <div class="communityCard">
        <div class="communityIcon">✈</div><div class="communityCopy"><strong>${tr('communityTitle')}</strong><p>${tr('communityText')}</p></div>
      </div>
      <div class="reportCard">
        <div><strong>🐛 ${tr('reportProblem')}</strong><p>${tr('reportProblemText')}</p></div>
        <div class="reportActions"><button class="secondary copyDiagnostic">${tr('copyDiagnostic')}</button><button class="primary reportTelegram">${tr('telegramOpen')}</button></div>
      </div>
    </div>


    <div class="creditSection">
      <div class="creditHeading">♥ ${tr('creditsTitle')}</div>
      <div class="creditCard bannergressCredit">
        <strong>${tr('bannergressThanks')}</strong>
        <p>${tr('bannergressThanksText')}</p>
        <p>${tr('bannergressNoLogin')}</p>
        <small>${tr('independentProject')}</small>
        <button class="secondary infoBannergress">↗ ${tr('visitBannergress')}</button>
      </div>
      <div class="creditCard">
        <strong>${tr('mapCredits')}</strong>
        <p>${tr('mapCreditsText')}</p>
      </div>
      <div class="creditFoot">${tr('rblCreditsFoot')}</div>
    </div>

    <div class="actions"><button class="secondary" id="manageProjects">${icon('folder')} ${tr('projects')}</button><button class="primary" id="newProject">${icon('plus')} ${tr('newProject')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#appLanguage',sh).onchange=e=>setAppLanguage(e.target.value);
  $('#manageProjects',sh).onclick=openProjectsSheet;
  $('#newProject',sh).onclick=()=>createNewProject();
  $('.tutorialHubOpen',sh).onclick=openTutorialHubSheet;
  const refreshBackupFolder=async()=>{
    const info=await backupFolderInfo(),status=$('.backupFolderStatus',sh),btn=$('.chooseBackupFolder',sh),now=$('.backupNow',sh);
    if(status)status.textContent=info?.configured?(info.label||tr('backupFolderReady')):tr('backupFolderNone');
    if(btn){btn.textContent=info?.configured?tr('backupFolderChange'):tr('backupFolderChoose');btn.disabled=!Capacitor.isNativePlatform()}
    if(now)now.disabled=!Capacitor.isNativePlatform()||!info?.configured;
  };
  refreshBackupFolder();
  $('.chooseBackupFolder',sh).onclick=async()=>{const r=await chooseBackupFolder();if(r){markBackupChanged();await refreshBackupFolder()}};
  $('.backupAutoToggle',sh).onchange=async e=>{if(e.target.checked){const info=await backupFolderInfo();if(!info?.configured){const r=await chooseBackupFolder();if(!r){e.target.checked=false;return}await refreshBackupFolder()}}setBackupAutoEnabled(e.target.checked)};
  $('.backupNow',sh).onclick=async()=>{await writeBackupToFolder({force:true});$('.backupLastStatus',sh).textContent=backupDateText(localStorage.getItem(BACKUP_LAST_KEY))};
  $('.backupExport',sh).onclick=exportFullBackupJson;
  $('.backupImport',sh).onclick=importFullBackupJson;
  $('.infoBannergress',sh).onclick=()=>{
    const url='https://bannergress.com/';
    if(Capacitor.isNativePlatform())AppLauncher.openUrl({url}).catch(()=>{});
    else window.open(url,'_blank','noopener');
  };
  const openTelegram=()=>{
    const botLang=APP_LANG==='zh-Hans'?'zh-CN':APP_LANG==='zh-Hant'?'zh-TW':APP_LANG;
    const start=`support_${botLang}`;
    const webUrl=`https://t.me/redactedbannerlabbot?start=${encodeURIComponent(start)}`;
    const tgUrl=`tg://resolve?domain=redactedbannerlabbot&start=${encodeURIComponent(start)}`;
    if(Capacitor.isNativePlatform()){
      AppLauncher.openUrl({url:tgUrl}).catch(()=>AppLauncher.openUrl({url:webUrl}).catch(()=>{}));
    }else window.open(webUrl,'_blank','noopener');
  };
  $('.reportTelegram',sh).onclick=openTelegram;
  $('.copyDiagnostic',sh).onclick=async()=>{
    const android=(navigator.userAgent.match(/Android\s+([0-9.]+)/i)||[])[1];
    const platform=Capacitor.getPlatform?Capacitor.getPlatform():(Capacitor.isNativePlatform()?'android':'web');
    const diagnostic=`Redacted BannerLab v${APP_VERSION}\n${tr('platformLabel')} : ${platform}${android?` · Android ${android}`:''}\n${tr('language')} : ${APP_LANG.toUpperCase()}\nIITC Companion : 0.6.6\n\n${tr('diagnosticDescription')}\n`;
    if(await copyText(diagnostic))toast(tr('diagnosticCopied'));else toast(tr('diagnosticCopyFailed'));
  };
}

/* =========================================================
   v1.0.7 — tutoriels guidés contextuels
========================================================= */
let tutorialSession=null;
let tutorialOverlay=null;
let tutorialResizeHandler=null;

function tutorialCatalog(){
  return {
    quick:{icon:'🚀',title:tr('tutorialQuick'),desc:tr('tutorialQuickDesc'),steps:[
      {prepare:'home',target:'#projectsBtn',title:tr('tutProjectTitle'),text:tr('tutProjectText')},
      {prepare:'home',target:'.tool[data-tool="image"]',title:tr('tutImageTitle'),text:tr('tutImageText')},
      {prepare:'home',target:'#rowsSelect',title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'home',target:'#openStudioEditorBtn',title:tr('tutStudioTitle'),text:tr('tutStudioText')},
      {prepare:'home',target:'[data-flow="route"]',title:tr('tutFlowTitle'),text:tr('tutFlowText')},
      {prepare:'home',target:'#infoBtn',title:tr('tutInfoTitle'),text:tr('tutInfoText')},
      {prepare:'info',target:'.reportCard',title:tr('tutSupportTitle'),text:tr('tutSupportText')}
    ]},
    banner:{icon:'🖼',title:tr('tutorialBanner'),desc:tr('tutorialBannerDesc'),steps:[
      {prepare:'home',target:'#projectName',title:tr('tutNameTitle'),text:tr('tutNameText')},
      {prepare:'home',target:'#rowsSelect',title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'image',target:'.addBackground',title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addImageLayer',title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'home',target:'.tool[data-tool="text"]',title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'home',target:'.tool[data-tool="preview"]',title:tr('tutPreviewTitle'),text:tr('tutPreviewText')},
      {prepare:'home',target:'.tool[data-tool="export"]',title:tr('tutExportTitle'),text:tr('tutExportText')}
    ]},
    layers:{icon:'🎨',title:tr('tutorialLayers'),desc:tr('tutorialLayersDesc'),steps:[
      {prepare:'image',target:'.addBackground',title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addImageLayer',title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.imageLayerStack',title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'image',target:'.layerGroupBar',title:tr('groupSelection'),text:tr('groupHint')},
      {prepare:'text',target:'#txt',title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'text',target:'.textTypographyCard',title:tr('textTypography'),text:tr('tutTextText')},
      {prepare:'home',target:'#openStudioEditorBtn',title:tr('tutStudioTitle'),text:tr('tutStudioText')}
    ]},
    iitc:{icon:'🗺',title:tr('tutorialIitc'),desc:tr('tutorialIitcDesc'),steps:[
      {prepare:'home',target:'[data-flow="route"]',title:tr('tutRouteTitle'),text:tr('tutRouteText')},
      {prepare:'route',target:'.iitccompanion-head',title:tr('tutCompanionTitle'),text:tr('tutCompanionText')},
      {prepare:'route',target:'.sharebridge',title:tr('tutInstallCompanionTitle'),text:tr('tutInstallCompanionText')},
      {prepare:'route',target:'.openintel',title:tr('tutOpenIitcTitle'),text:tr('tutOpenIitcText')},
      {prepare:'route',target:'.routeoptions',title:tr('tutAutoRouteTitle'),text:tr('tutAutoRouteText')},
      {prepare:'route',target:'.portallist',title:tr('tutPortalListTitle'),text:tr('tutPortalListText')}
    ]},
    publish:{icon:'📤',title:tr('tutorialPublish'),desc:tr('tutorialPublishDesc'),steps:[
      {prepare:'home',target:'[data-flow="missions"]',title:tr('tutMissionsTitle'),text:tr('tutMissionsText')},
      {prepare:'missions',target:'.requiredFieldCard',title:tr('tutMissionDescTitle'),text:tr('tutMissionDescText')},
      {prepare:'missions',target:'.missionlist-v2',title:tr('tutMissionsTitle'),text:tr('tutMissionsText')},
      {prepare:'home',target:'[data-flow="publish"]',title:tr('tutPublishTitle'),text:tr('tutPublishText')},
      {prepare:'home',target:'[data-flow="publish"]',title:tr('tutPublisherExplainTitle'),text:tr('tutPublisherExplainText')}
    ]},
    backup:{icon:'💾',title:tr('tutorialBackup'),desc:tr('tutorialBackupDesc'),steps:[
      {prepare:'home',target:'#infoBtn',title:tr('tutInfoTitle'),text:tr('tutInfoText')},
      {prepare:'info',target:'.backupCard',title:tr('tutBackupTitle'),text:tr('tutBackupText')},
      {prepare:'projects',target:'.portableProjectIntro',title:tr('tutPortableTitle'),text:tr('tutPortableText')},
      {prepare:'info',target:'.reportCard',title:tr('tutSupportTitle'),text:tr('tutSupportText')}
    ]}
  };
}

function openTutorialHubSheet(){
  const catalog=tutorialCatalog();
  const cards=Object.entries(catalog).map(([id,t])=>{
    const seen=localStorage.getItem(TUTORIAL_SEEN_PREFIX+id)==='1';
    return `<button class="tutorialChoice" data-tutorial-id="${escapeAttr(id)}"><span class="tutorialChoiceIcon">${t.icon}</span><span><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.desc)}</small></span>${seen?`<em>✓ ${tr('tutorialSeen')}</em>`:'<i>›</i>'}</button>`;
  }).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>🎓 ${tr('tutorialHubTitle')}</h2><p>${tr('tutorialHubText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="tutorialChoiceList">${cards}</div>`);
  $('.close',sh).onclick=openInfoSheet;
  $$('.tutorialChoice',sh).forEach(btn=>btn.onclick=()=>startTutorial(btn.dataset.tutorialId,{manual:true}));
}

function showFirstTutorialPrompt(){
  sessionStorage.setItem(TUTORIAL_PROMPT_SESSION_KEY,'1');
  const sh=openSheet(`<div class="tutorialWelcome"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><h2>${tr('tutorialWelcomeTitle')}</h2><p>${tr('tutorialWelcomeText')}</p></div></div><div class="tutorialWelcomeActions"><button class="primary tutorialStart">${tr('tutorialStart')}</button><button class="secondary tutorialLater">${tr('tutorialLater')}</button><button class="ghost tutorialNever">${tr('tutorialNever')}</button></div>`);
  $('.tutorialStart',sh).onclick=()=>startTutorial('quick',{manual:false});
  $('.tutorialLater',sh).onclick=closeSheet;
  $('.tutorialNever',sh).onclick=()=>{localStorage.setItem(TUTORIAL_AUTO_KEY,'never');closeSheet()};
}

function maybeShowFirstTutorial(){
  if(localStorage.getItem(TUTORIAL_AUTO_KEY))return;
  if(sessionStorage.getItem(TUTORIAL_PROMPT_SESSION_KEY)==='1')return;
  setTimeout(showFirstTutorialPrompt,450);
}

async function prepareTutorialStep(step){
  const action=step?.prepare||'home';
  if(action==='home'){closeSheet();setFlowStep('fresco',{open:false})}
  else if(action==='image'){setFlowStep('fresco',{open:false});openImageLayersSheet()}
  else if(action==='text'){setFlowStep('fresco',{open:false});openTextSheet()}
  else if(action==='route'){setFlowStep('route')}
  else if(action==='missions'){setFlowStep('missions')}
  else if(action==='info'){openInfoSheet()}
  else if(action==='projects'){openProjectsSheet()}
  await new Promise(r=>setTimeout(r,90));
}

function startTutorial(id,{manual=false}={}){
  const t=tutorialCatalog()[id];if(!t)return;
  closeTutorial({restore:false});
  closeSheet();
  tutorialSession={id,index:0,manual,title:t.title,steps:t.steps};
  void renderTutorialStep();
}

async function renderTutorialStep(){
  if(!tutorialSession)return;
  const step=tutorialSession.steps[tutorialSession.index];if(!step)return;
  await prepareTutorialStep(step);
  if(!tutorialSession)return;
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  tutorialOverlay?.remove();
  const overlay=document.createElement('div');overlay.className='guidedTutorialOverlay';
  overlay.innerHTML=`<div class="guidedTutorialSpotlight"></div><section class="guidedTutorialBubble"><button class="guidedTutorialClose" aria-label="${escapeAttr(tr('tutorialClose'))}">×</button><div class="guidedTutorialRedacted"><img src="/redacted-dino-cutout.png" alt=""><div><small>${escapeHtml(tutorialSession.title)}</small><strong>${escapeHtml(step.title)}</strong></div></div><p>${escapeHtml(step.text)}</p><div class="guidedTutorialProgress"><span>${tutorialSession.index+1} / ${tutorialSession.steps.length}</span><div><i style="width:${Math.round((tutorialSession.index+1)/tutorialSession.steps.length*100)}%"></i></div></div><div class="guidedTutorialActions"><button class="secondary guidedTutorialPrev" ${tutorialSession.index===0?'disabled':''}>‹ ${tr('tutorialPrevious')}</button><button class="primary guidedTutorialNext">${tutorialSession.index===tutorialSession.steps.length-1?tr('tutorialUnderstood'):tr('tutorialNext')+' ›'}</button></div></section>`;
  document.body.appendChild(overlay);tutorialOverlay=overlay;
  $('.guidedTutorialClose',overlay).onclick=()=>closeTutorial();
  $('.guidedTutorialPrev',overlay).onclick=()=>{if(tutorialSession&&tutorialSession.index>0){tutorialSession.index--;void renderTutorialStep()}};
  $('.guidedTutorialNext',overlay).onclick=()=>{if(!tutorialSession)return;if(tutorialSession.index>=tutorialSession.steps.length-1){finishTutorial();return}tutorialSession.index++;void renderTutorialStep()};
  placeTutorialOverlay(step.target);
  tutorialResizeHandler=()=>placeTutorialOverlay(step.target);
  window.addEventListener('resize',tutorialResizeHandler,{passive:true});
}

function placeTutorialOverlay(selector){
  if(!tutorialOverlay)return;
  const spot=$('.guidedTutorialSpotlight',tutorialOverlay),bubble=$('.guidedTutorialBubble',tutorialOverlay);
  let target=null;try{target=selector?$(selector):null}catch{}
  if(target){try{target.scrollIntoView({behavior:'auto',block:'center',inline:'center'})}catch{target.scrollIntoView()}}
  setTimeout(()=>{
    if(!tutorialOverlay)return;
    const vw=window.innerWidth,vh=window.innerHeight,margin=10;
    if(!target||!document.body.contains(target)){
      spot.hidden=true;bubble.classList.add('centered');bubble.style.left='12px';bubble.style.right='12px';bubble.style.top='50%';bubble.style.bottom='auto';return;
    }
    spot.hidden=false;bubble.classList.remove('centered');bubble.style.right='auto';bubble.style.bottom='auto';
    const r=target.getBoundingClientRect(),pad=7;
    spot.style.left=`${Math.max(margin,r.left-pad)}px`;spot.style.top=`${Math.max(margin,r.top-pad)}px`;spot.style.width=`${Math.min(vw-margin, r.right+pad)-Math.max(margin,r.left-pad)}px`;spot.style.height=`${Math.min(vh-margin,r.bottom+pad)-Math.max(margin,r.top-pad)}px`;
    const br=bubble.getBoundingClientRect(),bw=Math.min(br.width,vw-24),bh=br.height;
    let left=Math.max(12,Math.min(vw-bw-12,r.left+(r.width-bw)/2));
    let top=r.bottom+16;
    if(top+bh>vh-12)top=r.top-bh-16;
    if(top<12){top=Math.max(12,(vh-bh)/2);left=r.right+bw+20<vw?r.right+12:Math.max(12,r.left-bw-12)}
    bubble.style.left=`${Math.round(left)}px`;bubble.style.top=`${Math.round(Math.max(12,Math.min(vh-bh-12,top)))}px`;
  },110);
}

function closeTutorial({restore=true}={}){
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  tutorialOverlay?.remove();tutorialOverlay=null;
  if(restore&&tutorialSession){closeSheet();setFlowStep('fresco',{open:false})}
  tutorialSession=null;
}

function finishTutorial(){
  if(!tutorialSession)return;
  const id=tutorialSession.id,manual=tutorialSession.manual;
  localStorage.setItem(TUTORIAL_SEEN_PREFIX+id,'1');
  if(!manual)localStorage.setItem(TUTORIAL_AUTO_KEY,'done');
  closeTutorial();toast(tr('tutorialDone'));
}


function freshEditor(name=tr('defaultProject')){
  state.projectLanguage=APP_LANG;state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0,opacity:1,visible:true,name:tr('backgroundLayer')};state.imageLayers=[];state.texts=[];state.customFonts=[];state.active='background';layerGroupSelection.clear();state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,reuseLastPortal:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  $('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name=tr('defaultNewProject')){
  setFlowStep('fresco',{open:false});
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();await saveProject();closeSheet();toast(tr('newProjectCreated'));
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const locale=appLocale();
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||tr('unnamed'))}</strong><span>${(d.rows||3)*6} ${tr('missions').toLowerCase()}${updated?' · '+escapeHtml(updated):''}</span></div>${current?`<span class="currentbadge">${tr('opened')}</span>`:''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>${tr('open')}</button><button class="secondary exportproject">${icon('download')} ${tr('exportProject')}</button><button class="secondary shareproject">${icon('upload')} ${tr('shareProject')}</button><button class="secondary renameproject">${icon('edit')} ${tr('rename')}</button><button class="secondary duplicateproject">${icon('copy')} ${tr('copy')}</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||`<div class="small">${tr('noSavedProject')}</div>`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('myProjects')}</h2><p>${tr('projectsSaved',{n:projects.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="portableProjectIntro"><b>📦 ${tr('portableProject')}</b><span>${tr('portableProjectDesc')}</span></div><div class="projectlist">${cards}</div><div class="actions projectMainActions"><button class="secondary" id="importProject">${icon('upload')} ${tr('importProject')}</button><button class="primary" id="createProject">${icon('plus')} ${tr('newProject')}</button></div><p class="small">${tr('projectImportHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();$('#importProject',sh).onclick=importPortableProject;
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.exportproject',card).onclick=()=>deliverPortableProject(id,{share:false});
    $('.shareproject',card).onclick=()=>deliverPortableProject(id,{share:true});
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}

async function switchProject(id){setFlowStep('fresco',{open:false});await saveProject();await loadProject(id);resetHistory();closeSheet();toast(tr('projectOpened',{name:state.name}))}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameProject')}</h2><p>${tr('renameHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('projectName')}</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||tr('defaultProject'))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||tr('defaultProject');const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();markBackupChanged();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;$('#projectName').value=name}closeSheet();toast(tr('projectRenamed'))};
}

async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteProject')}</h2><p>${escapeHtml(rec.data?.name||tr('unnamed'))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('deleteWarning')}</span></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirmdelete">${icon('trash')} ${tr('delete')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}

async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||tr('fresco')} ${tr('copySuffix')}`;data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob,layerBlobs:rec.layerBlobs||[]});await txDone(tx2);markBackupChanged();await loadProject(newId);closeSheet();toast(tr('copyCreated'));
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);markBackupChanged();
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast(tr('projectDeleted'));
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,projectLanguage:projectLanguage(),name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation,opacity:state.bg.opacity??1,visible:state.bg.visible!==false,name:state.bg.name||tr('backgroundLayer')},imageLayers:state.imageLayers.map(l=>({id:l.id,name:l.name||'',x:l.x,y:l.y,scale:l.scale,rotation:l.rotation||0,opacity:l.opacity??1,visible:l.visible!==false,groupId:l.groupId||null,groupNumber:l.groupNumber||null,scope:l.scope==='mission'?'mission':'global',missionNumber:l.scope==='mission'?(parseInt(l.missionNumber)||1):null,fitMode:l.fitMode==='contain'?'contain':'cover'})),texts:state.texts,customFonts:state.customFonts,active:state.active,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){markBackupChanged();clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject({markBackup=true}={}){try{const db=await openDB();const tx=db.transaction('project','readwrite');const layerBlobs=state.imageLayers.filter(l=>l.blob).map(l=>({id:l.id,blob:l.blob}));tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob,layerBlobs});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current');if(markBackup)markBackupChanged()}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();resetHistory();await saveProject();return}
    freshEditor();state.projectId=target;state.projectLanguage=SUPPORTED_LANGS.includes(rec.data.projectLanguage)?rec.data.projectLanguage:(SUPPORTED_LANGS.includes(rec.data.language)?rec.data.language:APP_LANG);
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[],customFonts:rec.data.customFonts||[]});await registerProjectFonts();normalizeAllTextStyles();
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});state.bg.visible=rec.data.bg?.visible!==false;state.bg.opacity=Number.isFinite(+rec.data.bg?.opacity)?+rec.data.bg.opacity:1;state.bg.name=rec.data.bg?.name||tr('backgroundLayer');if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    const media=new Map((rec.layerBlobs||[]).map(x=>[x.id,x.blob]));state.imageLayers=(rec.data.imageLayers||[]).map(l=>normalizeImageLayerScope({...l,image:null,blob:media.get(l.id)||null,visible:l.visible!==false,opacity:Number.isFinite(+l.opacity)?+l.opacity:1,groupId:l.groupId||null}));
    await Promise.all(state.imageLayers.map(async l=>{if(l.blob)try{l.image=await blobToImage(l.blob)}catch(e){console.warn('layer image',l.id,e)}}));normalizeLayerGroups();
    const requestedActive=rec.data.active||'background';state.active=requestedActive.startsWith('image:')&&state.imageLayers.some(l=>'image:'+l.id===requestedActive)||requestedActive.startsWith('text:')&&state.texts.some(t=>'text:'+t.id===requestedActive)||requestedActive==='background'?requestedActive:'background';
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

if(Capacitor.isNativePlatform()){
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url)}).catch?.(()=>{});
  App.addListener('appStateChange',({isActive})=>{if(isActive){autoBackupOnForeground();resumePendingPlayOverlay()}else autoBackupOnBackground('appStateChange')}).catch?.(()=>{});
  // `pause` est plus direct sur plusieurs versions Android que le seul
  // appStateChange. Les gardes backupInProgress/révision rendent les doublons sûrs.
  App.addListener('pause',()=>autoBackupOnBackground('pause')).catch?.(()=>{});
  App.addListener('resume',()=>autoBackupOnForeground()).catch?.(()=>{});
  App.getLaunchUrl().then(r=>{if(r?.url)handleBridgeUrl(r.url)}).catch(()=>{});
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)autoBackupOnBackground('visibilitychange');else autoBackupOnForeground()});
window.addEventListener('pagehide',()=>autoBackupOnBackground('pagehide'));
window.addEventListener('resize',render);
window.addEventListener('keydown',e=>{
  const k=(e.key||'').toLowerCase(),ctrl=e.ctrlKey||e.metaKey;if(!ctrl)return;
  const target=e.target,tag=(target?.tagName||'').toUpperCase();
  const editing=['INPUT','TEXTAREA','SELECT'].includes(tag)||target?.isContentEditable;
  if(editing)return; // laisse l'annulation native fonctionner dans les champs texte
  if(k==='z'&&!e.shiftKey){e.preventDefault();undoAction();return}
  if(k==='y'||(k==='z'&&e.shiftKey)){e.preventDefault();redoAction();return}
});
if('serviceWorker' in navigator&&!Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();migrateLegacyStorage().then(()=>loadProject()).then(()=>maybeShowFirstTutorial());
