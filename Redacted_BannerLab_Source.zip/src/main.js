import './style.css';
import JSZip from 'jszip';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import QRCode from 'qrcode';
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { IntentLauncher, ActivityAction } from '@capgo/capacitor-intent-launcher';

const APP_VERSION = '0.10.5';
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;
const MissionOverlay = registerPlugin('MissionOverlay');
const BANNERGRESS_API='https://api.bannergress.com';
const VALHALLA_API='https://valhalla1.openstreetmap.de/route';
const VALHALLA_MAX_POINTS=10;
const BANNER_WALK_CACHE_PREFIX='rbl-banner-walk-v5:';
const BANNER_FAVORITES_KEY='rbl-bannergress-favorites-v1';
const PLAY_SESSION_KEY='rbl-play-session-v1';
const PLAY_PENDING_KEY='rbl-play-pending-v1';
const BANNER_TODO_KEY='rbl-bannergress-todo-v1';
const PLAY_HISTORY_KEY='rbl-play-history-v1';

const SUPPORTED_LANGS=['fr','en','es'];
let APP_LANG=localStorage.getItem('rbl-language')||((navigator.language||'fr').toLowerCase().startsWith('es')?'es':(navigator.language||'fr').toLowerCase().startsWith('en')?'en':'fr');
if(!SUPPORTED_LANGS.includes(APP_LANG))APP_LANG='fr';
const I18N={
  fr:{
    fresco:'Fresque',route:'Parcours',missions:'Missions',publish:'Publier',projects:'Projets',rows:'Rangées',
    image:'Image',framing:'Cadrage',text:'Texte',preview:'Aperçu',export:'Exporter',
    wholeFresco:'Fresque entière',oneMission:'Une mission',noMission:'Aucune mission sélectionnée',
    addImage:'Ajoute ton image',imageHint:'Elle sera cadrée directement sur la géométrie Prime.',
    circles:'Cercles Prime',grid:'Grille 512',numbers:'Numéros',enlarge:'Agrandir mission',resetMission:'Réinitialiser mission',
    prev:'Précédente',next:'Suivante',complete:'Mission complète',remaining:'Encore {n} portail(s)',
    openIitc:'Ouvrir IITC Companion',tutorial:'Tutoriel',installPlugin:'Installer / mettre à jour le plugin IITC',
    addPortal:'Ajouter un portail manuellement',autoAdvance:'Passer automatiquement à la mission suivante à {n} portails',
    reuseLast:'Reprendre automatiquement le dernier portail comme premier de la mission suivante',
    carryPrev:'Reprendre le dernier portail précédent',noPortal:'Aucun portail pour cette mission.',
    action:'Action',hack:'Hack',mod:'Installer un mod',capture:'Capturer / améliorer',link:'Créer un lien',field:'Créer un champ',passphrase:'Passphrase',
    question:'Question',answer:'Réponse attendue',save:'Enregistrer',cancel:'Annuler',
    settings:'Réglages communs',commonDesc:'Description commune',titleFormat:'Format des titres',defaultType:'Type par défaut',
    location:'Localisation',visible:'Visible',hidden:'Cachée',sequential:'Séquentielle',anyOrder:'Ordre libre',
    portalsPerMission:'Portails / mission',editMission:'Éditer la mission',title:'Titre',description:'Description',
    missionReady:'Prête',missionIncomplete:'Incomplète',openRoute:'Modifier le parcours',
    publishPack:'Créer le pack BannerLab',openMat:'Ouvrir Mission Authoring Tool',
    ownWorkflow:'BannerLab utilise désormais son propre format de projet et son propre pack de publication.',
    language:'Langue',french:'Français',english:'English',spanish:'Español',
    companionStats:'Stats piétonnes dans IITC',companionStatsDesc:'Dans le mini panneau IITC : 📊 Stats inutiles calcule les km à pied estimés, temps, détour et autres absurdités.',
    duplicateBad:'{n} réutilisation(s) de portail à vérifier.',handoverOk:'La reprise fin → début de mission est autorisée.',
    pluginVersion:'Companion 0.6.2',
    undo:'Annuler',redo:'Rétablir'
  },
  en:{
    fresco:'Banner',route:'Route',missions:'Missions',publish:'Publish',projects:'Projects',rows:'Rows',
    image:'Image',framing:'Framing',text:'Text',preview:'Preview',export:'Export',
    wholeFresco:'Whole banner',oneMission:'One mission',noMission:'No mission selected',
    addImage:'Add your image',imageHint:'It will be framed directly on the Prime geometry.',
    circles:'Prime circles',grid:'512 grid',numbers:'Numbers',enlarge:'Enlarge mission',resetMission:'Reset mission',
    prev:'Previous',next:'Next',complete:'Mission complete',remaining:'{n} portal(s) remaining',
    openIitc:'Open IITC Companion',tutorial:'Tutorial',installPlugin:'Install / update IITC plugin',
    addPortal:'Add a portal manually',autoAdvance:'Automatically move to next mission at {n} portals',
    reuseLast:'Automatically reuse the last portal as the first portal of the next mission',
    carryPrev:'Reuse previous mission last portal',noPortal:'No portal in this mission.',
    action:'Action',hack:'Hack',mod:'Install a mod',capture:'Capture / upgrade',link:'Create a link',field:'Create a field',passphrase:'Passphrase',
    question:'Question',answer:'Expected answer',save:'Save',cancel:'Cancel',
    settings:'Common settings',commonDesc:'Common description',titleFormat:'Title format',defaultType:'Default type',
    location:'Location',visible:'Visible',hidden:'Hidden',sequential:'Sequential',anyOrder:'Any order',
    portalsPerMission:'Portals / mission',editMission:'Edit mission',title:'Title',description:'Description',
    missionReady:'Ready',missionIncomplete:'Incomplete',openRoute:'Edit route',
    publishPack:'Create BannerLab pack',openMat:'Open Mission Authoring Tool',
    ownWorkflow:'BannerLab now uses its own project format and publication pack.',
    language:'Language',french:'Français',english:'English',spanish:'Español',
    companionStats:'Walking stats in IITC',companionStatsDesc:'In the IITC mini panel: 📊 Useless stats calculates estimated walking distance, time, detour and other nonsense.',
    duplicateBad:'{n} portal reuse(s) to review.',handoverOk:'Mission-end → next-start reuse is allowed.',
    pluginVersion:'Companion 0.6.2',
    undo:'Undo',redo:'Redo'
  },
  es:{
    fresco:'Mosaico',route:'Recorrido',missions:'Misiones',publish:'Publicar',projects:'Proyectos',rows:'Filas',
    image:'Imagen',framing:'Encuadre',text:'Texto',preview:'Vista previa',export:'Exportar',
    wholeFresco:'Mosaico completo',oneMission:'Una misión',noMission:'Ninguna misión seleccionada',
    addImage:'Añade tu imagen',imageHint:'Se encuadrará directamente con la geometría Prime.',
    circles:'Círculos Prime',grid:'Cuadrícula 512',numbers:'Números',enlarge:'Ampliar misión',resetMission:'Restablecer misión',
    prev:'Anterior',next:'Siguiente',complete:'Misión completa',remaining:'Faltan {n} portal(es)',
    openIitc:'Abrir IITC Companion',tutorial:'Tutorial',installPlugin:'Instalar / actualizar plugin IITC',
    addPortal:'Añadir portal manualmente',autoAdvance:'Pasar automáticamente a la siguiente misión al llegar a {n} portales',
    reuseLast:'Reutilizar automáticamente el último portal como primero de la siguiente misión',
    carryPrev:'Reutilizar el último portal anterior',noPortal:'No hay portales en esta misión.',
    action:'Acción',hack:'Hackear',mod:'Instalar un mod',capture:'Capturar / mejorar',link:'Crear un enlace',field:'Crear un campo',passphrase:'Contraseña',
    question:'Pregunta',answer:'Respuesta esperada',save:'Guardar',cancel:'Cancelar',
    settings:'Ajustes comunes',commonDesc:'Descripción común',titleFormat:'Formato de títulos',defaultType:'Tipo predeterminado',
    location:'Ubicación',visible:'Visible',hidden:'Oculta',sequential:'Secuencial',anyOrder:'Cualquier orden',
    portalsPerMission:'Portales / misión',editMission:'Editar misión',title:'Título',description:'Descripción',
    missionReady:'Lista',missionIncomplete:'Incompleta',openRoute:'Editar recorrido',
    publishPack:'Crear paquete BannerLab',openMat:'Abrir Mission Authoring Tool',
    ownWorkflow:'BannerLab usa ahora su propio formato de proyecto y paquete de publicación.',
    language:'Idioma',french:'Français',english:'English',spanish:'Español',
    companionStats:'Estadísticas a pie en IITC',companionStatsDesc:'En el mini panel IITC: 📊 Stats inútiles calcula distancia a pie estimada, tiempo, desvío y otras tonterías.',
    duplicateBad:'{n} reutilización(es) de portal para revisar.',handoverOk:'Se permite reutilizar fin de misión → inicio de la siguiente.',
    pluginVersion:'Companion 0.6.2',
    undo:'Deshacer',redo:'Rehacer'
  }
};
Object.assign(I18N.fr,{"subtitle":"Fresques Ingress Prime","source":"source","bannerHelp":"<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.","missionHelp":"<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi le déplacer ici à 1 doigt.","missionSelected":"Mission {n} sélectionnée","tapMedallion":"Touche un médaillon","touchMissionFirst":"Touche d’abord la mission que tu veux recadrer.","selectMissionFirst":"Sélectionne d’abord une mission.","heavyImage":"Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.","imported":"{w} × {h} px importés","textLayerDesc":"Chaque texte reste un calque indépendant, modifiable ou supprimable.","layer":"Calque","newText":"+ Nouveau texte","size":"Taille","outline":"Contour","color":"Couleur","outlineColor":"Couleur contour","add":"Ajouter","update":"Mettre à jour","delete":"Supprimer","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotation","center":"Centrer","reset":"Réinitialiser","done":"Terminé","transformText":"Transformer le texte","frameImage":"Cadrer l’image","pinchHint":"Le geste à deux doigts reste disponible directement sur la fresque.","missionCropOnly":"Ce cadrage ne touche qu’à ce médaillon.","resetThisMission":"Réinitialiser cette mission","individualCrop":"Recadrage individuel · 512 × 512","oneFinger":"1 doigt","move":"déplacer","twoFingers":"2 doigts","zoomRotate":"zoomer et tourner","previewPrime":"Aperçu Prime","previewApplied":"Les recadrages individuels sont déjà appliqués.","previewOrder":"Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.","exportTitle":"Exporter {n} missions","exportIntro":"Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.","noBackground":"Aucune image de fond n’est chargée.","missionFormat":"Format des missions","jpgFast":"JPG rapide · qualité élevée","pngLossless":"PNG sans perte · plus lent","fastEncoding":"Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.","rowRender":"Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.","adjusted":"{n} mission(s) avec recadrage individuel.","nianticCheck":"Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.","ready":"Prêt.","createZip":"Créer le ZIP","zipAssembly":"Assemblage du ZIP…","zipCreated":"ZIP créé.","zipDownloaded":"ZIP téléchargé.","saveShareZip":"Enregistrer ou partager le ZIP","exportFinished":"Export {format} terminé","exportFailed":"L’export a échoué.","newProject":"Nouveau projet","myProjects":"Mes projets","projectsSaved":"{n} projet(s) enregistré(s) sur ce téléphone.","unnamed":"Sans nom","opened":"Ouvert","open":"Ouvrir","rename":"Renommer","copy":"Copier","noSavedProject":"Aucun projet enregistré.","renameProject":"Renommer le projet","renameHint":"Un nom humainement reconnaissable, concept révolutionnaire.","projectName":"Nom du projet","projectOpened":"Projet ouvert : {name}","projectRenamed":"Projet renommé","deleteProject":"Supprimer ce projet ?","deleteWarning":"La fresque et son image enregistrée localement seront supprimées.","copyCreated":"Copie créée","projectDeleted":"Projet supprimé","newProjectCreated":"Nouveau projet créé avec Redacted","defaultProject":"Ma fresque","defaultNewProject":"Nouvelle fresque","copySuffix":"copie","versionLabel":"Version","infoPrime":"6 colonnes · 544 px · crop 512 px.","infoPlanner":"actions portail, passphrases, reprise fin→début et pack BannerLab natif.","infoCompanion":"parcours, actions, tracés multi-missions, options et statistiques piétonnes.","disclaimer":"Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.","titleTokens":"$T = nom · $N = numéro · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.2. Dans IITC Mobile, remplace la version précédente. Si IITC refuse de l’écraser, supprime une fois l’ancien plugin puis installe ce fichier.","pluginDialog":"Installer / mettre à jour Companion 0.6.2","pluginShareFailed":"Impossible de partager le plugin IITC.","intelOpened":"IITC Mobile ouvert avec le projet BannerLab.","intelPrimeOpened":"IITC Prime ouvert avec le projet BannerLab.","intelFallback":"IITC Mobile ouvert. Le Companion utilisera son dernier état synchronisé.","intelPrimeFallback":"IITC Prime ouvert. Le Companion utilisera son dernier état synchronisé.","intelBrowser":"IITC non détecté : ouverture dans le navigateur.","tutorialIntro":"Construis toute la bannière dans IITC sans revenir dans BannerLab après chaque portail.","tut1Title":"Installe le plugin une seule fois","tut1Text":"Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.","tut2Title":"Ouvre IITC depuis BannerLab","tut2Text":"BannerLab transmet le projet, la mission active et la langue au Companion via un fragment local que le serveur Intel ne reçoit pas.","tut3Title":"Construis directement sur la carte","tut3Text":"Le Companion permet d’ajouter, modifier ou retirer des portails, changer de mission et visualiser les tracés sans revenir dans BannerLab.","tut4Title":"Synchronise quand tu as fini","tut4Text":"Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.","tutNote":"Tu peux déplacer et redimensionner le Companion et ranger ses réglages dans Options.","installUpdate":"Installer / mettre à jour","emptyTitleIssue":"Mission {n} : titre vide","emptyDescIssue":"Mission {n} : description vide","portalsIssue":"Mission {n} : {count}/{need} portails","missingGuidIssue":"Mission {n} : {count} GUID manquant(s)","passIssue":"Mission {n} : {count} passphrase(s) incomplète(s)","reviewCount":"{n} point(s) à vérifier","projectReady":"Projet BannerLab prêt","fixBeforePublish":"Corrige les éléments avant publication.","publisherDesc":"Le prochain pont remplira le Mission Authoring Tool directement depuis ce format natif. La soumission finale restera volontairement faite dans l’outil officiel.","packCreating":"Création du pack BannerLab…","packCreated":"Pack BannerLab créé","exportImpossible":"Export impossible : {error}","missionResetDone":"Mission {n} réinitialisée","textDeleted":"Texte supprimé","histImport":"Importer image","histMissionZoom":"Zoom mission","histMissionRotation":"Rotation mission","histTextRotation":"Rotation texte","histImageRotation":"Rotation image","histTextZoom":"Zoom texte","histImageZoom":"Zoom image","histCenterText":"Centrer texte","histCenterImage":"Centrer image","histResetText":"Réinitialiser texte","histResetImage":"Réinitialiser image","histResetMission":"Réinitialiser mission","histDeleteText":"Supprimer texte","histAddText":"Ajouter texte","histEditText":"Modifier texte"});
Object.assign(I18N.en,{"subtitle":"Ingress Prime banners","source":"source","bannerHelp":"<b>Banner mode:</b> 1 finger moves the selected layer. <b>2 fingers</b> zoom and rotate.","missionHelp":"<b>Mission mode:</b> tap a medallion. For comfortable editing, use <b>Enlarge mission</b>. You can also move it here with 1 finger.","missionSelected":"Mission {n} selected","tapMedallion":"Tap a medallion","touchMissionFirst":"Tap the mission you want to reframe first.","selectMissionFirst":"Select a mission first.","heavyImage":"Very large image. It may make your phone reconsider its life choices.","imported":"Imported {w} × {h} px","textLayerDesc":"Each text remains an independent layer that can be edited or deleted.","layer":"Layer","newText":"+ New text","size":"Size","outline":"Outline","color":"Color","outlineColor":"Outline color","add":"Add","update":"Update","delete":"Delete","zoom":"Zoom","localZoom":"Local zoom","rotation":"Rotation","center":"Center","reset":"Reset","done":"Done","transformText":"Transform text","frameImage":"Frame image","pinchHint":"Two-finger gestures remain available directly on the banner.","missionCropOnly":"This framing only affects this medallion.","resetThisMission":"Reset this mission","individualCrop":"Individual framing · 512 × 512","oneFinger":"1 finger","move":"move","twoFingers":"2 fingers","zoomRotate":"zoom and rotate","previewPrime":"Prime preview","previewApplied":"Individual mission adjustments are already applied.","previewOrder":"Number 1 is bottom-right, then numbering goes left and upward through the rows.","exportTitle":"Export {n} missions","exportIntro":"Choose speed or lossless PNG. Both stay at 512 × 512.","noBackground":"No background image is loaded.","missionFormat":"Mission format","jpgFast":"Fast JPG · high quality","pngLossless":"Lossless PNG · slower","fastEncoding":"Fast mode avoids PNG encoding, which is by far the slowest part on a phone.","rowRender":"The background is rendered once per row instead of being recalculated six times.","adjusted":"{n} mission(s) with individual framing.","nianticCheck":"Check Niantic rules before submission: image rights, relevant content, and no dominant single character.","ready":"Ready.","createZip":"Create ZIP","zipAssembly":"Building ZIP…","zipCreated":"ZIP created.","zipDownloaded":"ZIP downloaded.","saveShareZip":"Save or share ZIP","exportFinished":"{format} export complete","exportFailed":"Export failed.","newProject":"New project","myProjects":"My projects","projectsSaved":"{n} project(s) saved on this phone.","unnamed":"Unnamed","opened":"Open","open":"Open","rename":"Rename","copy":"Copy","noSavedProject":"No saved project.","renameProject":"Rename project","renameHint":"A human-readable name. A surprisingly advanced concept.","projectName":"Project name","projectOpened":"Project opened: {name}","projectRenamed":"Project renamed","deleteProject":"Delete this project?","deleteWarning":"The banner and its locally stored image will be deleted.","copyCreated":"Copy created","projectDeleted":"Project deleted","newProjectCreated":"New project created with Redacted","defaultProject":"My banner","defaultNewProject":"New banner","copySuffix":"copy","versionLabel":"Version","infoPrime":"6 columns · 544 px · 512 px crop.","infoPlanner":"portal actions, passphrases, end→start handover and native BannerLab pack.","infoCompanion":"routes, actions, multi-mission tracks, options and walking stats.","disclaimer":"Ingress and Ingress Prime are Niantic trademarks. Redacted BannerLab is not affiliated with or endorsed by Niantic.","titleTokens":"$T = name · $N = number · $M = total · $0N = 01, 02…","pluginShareText":"Companion plugin 0.6.0. Replace the previous version in IITC Mobile. If IITC refuses to overwrite it, remove the old plugin once and install this file.","pluginDialog":"Install / update Companion 0.6.2","pluginShareFailed":"Unable to share the IITC plugin.","intelOpened":"IITC Mobile opened with the BannerLab project.","intelPrimeOpened":"IITC Prime opened with the BannerLab project.","intelFallback":"IITC Mobile opened. The Companion will use its last synchronized state.","intelPrimeFallback":"IITC Prime opened. The Companion will use its last synchronized state.","intelBrowser":"IITC not detected: opening in browser.","tutorialIntro":"Build the whole banner in IITC without returning to BannerLab after every portal.","tut1Title":"Install the plugin once","tut1Text":"From Route, use “Install / update IITC plugin”, then add the file as a user plugin in IITC Mobile.","tut2Title":"Open IITC from BannerLab","tut2Text":"BannerLab sends the project, active mission and language to the Companion through a local fragment that the Intel server never receives.","tut3Title":"Build directly on the map","tut3Text":"The Companion lets you add, edit or remove portals, change missions and see routes without returning to BannerLab.","tut4Title":"Sync when you are done","tut4Text":"“Sync BannerLab” sends all edited missions back to the project and reopens BannerLab.","tutNote":"You can move and resize the Companion and keep its settings inside Options.","installUpdate":"Install / update","emptyTitleIssue":"Mission {n}: empty title","emptyDescIssue":"Mission {n}: empty description","portalsIssue":"Mission {n}: {count}/{need} portals","missingGuidIssue":"Mission {n}: {count} missing GUID(s)","passIssue":"Mission {n}: {count} incomplete passphrase(s)","reviewCount":"{n} item(s) to review","projectReady":"BannerLab project ready","fixBeforePublish":"Fix these items before publishing.","publisherDesc":"The next bridge will fill the Mission Authoring Tool directly from this native format. Final submission will deliberately remain in the official tool.","packCreating":"Creating BannerLab pack…","packCreated":"BannerLab pack created","exportImpossible":"Export impossible: {error}","missionResetDone":"Mission {n} reset","textDeleted":"Text deleted","histImport":"Import image","histMissionZoom":"Mission zoom","histMissionRotation":"Mission rotation","histTextRotation":"Text rotation","histImageRotation":"Image rotation","histTextZoom":"Text zoom","histImageZoom":"Image zoom","histCenterText":"Center text","histCenterImage":"Center image","histResetText":"Reset text","histResetImage":"Reset image","histResetMission":"Reset mission","histDeleteText":"Delete text","histAddText":"Add text","histEditText":"Edit text"});
Object.assign(I18N.es,{"subtitle":"Mosaicos de Ingress Prime","source":"fuente","bannerHelp":"<b>Modo mosaico:</b> 1 dedo mueve la capa seleccionada. <b>2 dedos</b> amplían y giran.","missionHelp":"<b>Modo misión:</b> toca un medallón. Para trabajar cómodamente, usa <b>Ampliar misión</b>. También puedes moverlo aquí con 1 dedo.","missionSelected":"Misión {n} seleccionada","tapMedallion":"Toca un medallón","touchMissionFirst":"Toca primero la misión que quieres reencuadrar.","selectMissionFirst":"Selecciona primero una misión.","heavyImage":"Imagen muy pesada. Puede poner de rodillas al teléfono, lo cual sería bastante humillante.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto sigue siendo una capa independiente, editable o eliminable.","layer":"Capa","newText":"+ Nuevo texto","size":"Tamaño","outline":"Contorno","color":"Color","outlineColor":"Color del contorno","add":"Añadir","update":"Actualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotación","center":"Centrar","reset":"Restablecer","done":"Hecho","transformText":"Transformar texto","frameImage":"Encuadrar imagen","pinchHint":"El gesto con dos dedos sigue disponible directamente sobre el mosaico.","missionCropOnly":"Este encuadre solo afecta a este medallón.","resetThisMission":"Restablecer esta misión","individualCrop":"Encuadre individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"ampliar y girar","previewPrime":"Vista previa Prime","previewApplied":"Los ajustes individuales de las misiones ya están aplicados.","previewOrder":"El número 1 está abajo a la derecha; después la numeración avanza hacia la izquierda y sube por las filas.","exportTitle":"Exportar {n} misiones","exportIntro":"Elige velocidad o PNG sin pérdida. Ambos siguen en 512 × 512.","noBackground":"No hay imagen de fondo cargada.","missionFormat":"Formato de las misiones","jpgFast":"JPG rápido · alta calidad","pngLossless":"PNG sin pérdida · más lento","fastEncoding":"El modo rápido evita codificar PNG, que es con diferencia la parte más lenta en el teléfono.","rowRender":"El fondo se renderiza una sola vez por fila en vez de recalcularse seis veces.","adjusted":"{n} misión(es) con encuadre individual.","nianticCheck":"Comprueba las reglas de Niantic antes de enviar: derechos de imagen, contenido pertinente y ningún carácter único dominante.","ready":"Listo.","createZip":"Crear ZIP","zipAssembly":"Montando ZIP…","zipCreated":"ZIP creado.","zipDownloaded":"ZIP descargado.","saveShareZip":"Guardar o compartir ZIP","exportFinished":"Exportación {format} terminada","exportFailed":"La exportación ha fallado.","newProject":"Nuevo proyecto","myProjects":"Mis proyectos","projectsSaved":"{n} proyecto(s) guardado(s) en este teléfono.","unnamed":"Sin nombre","opened":"Abierto","open":"Abrir","rename":"Renombrar","copy":"Copiar","noSavedProject":"No hay proyectos guardados.","renameProject":"Renombrar proyecto","renameHint":"Un nombre reconocible por humanos. Concepto sorprendentemente avanzado.","projectName":"Nombre del proyecto","projectOpened":"Proyecto abierto: {name}","projectRenamed":"Proyecto renombrado","deleteProject":"¿Eliminar este proyecto?","deleteWarning":"Se eliminarán el mosaico y su imagen guardada localmente.","copyCreated":"Copia creada","projectDeleted":"Proyecto eliminado","newProjectCreated":"Nuevo proyecto creado con Redacted","defaultProject":"Mi mosaico","defaultNewProject":"Nuevo mosaico","copySuffix":"copia","versionLabel":"Versión","infoPrime":"6 columnas · 544 px · recorte 512 px.","infoPlanner":"acciones de portal, contraseñas, continuidad fin→inicio y paquete BannerLab nativo.","infoCompanion":"recorridos, acciones, trazados multi-misión, opciones y estadísticas a pie.","disclaimer":"Ingress e Ingress Prime son marcas de Niantic. Redacted BannerLab no está afiliado ni aprobado por Niantic.","titleTokens":"$T = nombre · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin Companion 0.6.2. Sustituye la versión anterior en IITC Mobile. Si IITC se niega a sobrescribirla, elimina una vez el plugin antiguo e instala este archivo.","pluginDialog":"Instalar / actualizar Companion 0.6.2","pluginShareFailed":"No se puede compartir el plugin IITC.","intelOpened":"IITC Mobile abierto con el proyecto BannerLab.","intelPrimeOpened":"IITC Prime abierto con el proyecto BannerLab.","intelFallback":"IITC Mobile abierto. Companion usará su último estado sincronizado.","intelPrimeFallback":"IITC Prime abierto. Companion usará su último estado sincronizado.","intelBrowser":"IITC no detectado: apertura en el navegador.","tutorialIntro":"Construye todo el mosaico en IITC sin volver a BannerLab después de cada portal.","tut1Title":"Instala el plugin una sola vez","tut1Text":"En Recorrido, usa « Instalar / actualizar plugin IITC » y añade el archivo como plugin de usuario en IITC Mobile.","tut2Title":"Abre IITC desde BannerLab","tut2Text":"BannerLab transmite el proyecto, la misión activa y el idioma al Companion mediante un fragmento local que el servidor Intel nunca recibe.","tut3Title":"Construye directamente en el mapa","tut3Text":"Companion permite añadir, modificar o quitar portales, cambiar de misión y ver los trazados sin volver a BannerLab.","tut4Title":"Sincroniza al terminar","tut4Text":"« Sincronizar BannerLab » devuelve todas las misiones modificadas al proyecto y vuelve a abrir BannerLab.","tutNote":"Puedes mover y redimensionar el Companion y guardar sus ajustes dentro de Opciones.","installUpdate":"Instalar / actualizar","emptyTitleIssue":"Misión {n}: título vacío","emptyDescIssue":"Misión {n}: descripción vacía","portalsIssue":"Misión {n}: {count}/{need} portales","missingGuidIssue":"Misión {n}: {count} GUID ausente(s)","passIssue":"Misión {n}: {count} contraseña(s) incompleta(s)","reviewCount":"{n} punto(s) por revisar","projectReady":"Proyecto BannerLab listo","fixBeforePublish":"Corrige estos elementos antes de publicar.","publisherDesc":"El próximo puente rellenará Mission Authoring Tool directamente desde este formato nativo. El envío final seguirá haciéndose voluntariamente en la herramienta oficial.","packCreating":"Creando paquete BannerLab…","packCreated":"Paquete BannerLab creado","exportImpossible":"Exportación imposible: {error}","missionResetDone":"Misión {n} restablecida","textDeleted":"Texto eliminado","histImport":"Importar imagen","histMissionZoom":"Zoom de misión","histMissionRotation":"Rotación de misión","histTextRotation":"Rotación de texto","histImageRotation":"Rotación de imagen","histTextZoom":"Zoom de texto","histImageZoom":"Zoom de imagen","histCenterText":"Centrar texto","histCenterImage":"Centrar imagen","histResetText":"Restablecer texto","histResetImage":"Restablecer imagen","histResetMission":"Restablecer misión","histDeleteText":"Eliminar texto","histAddText":"Añadir texto","histEditText":"Editar texto"});
Object.assign(I18N.fr,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directement depuis le Companion.","handoverDetail":"Le dernier portail peut devenir le premier de la mission suivante sans être considéré comme un doublon fautif.","coordsMissing":"Coordonnées introuvables.","coordsInvalid":"Coordonnées invalides.","duplicateElsewhere":"Ce portail est déjà utilisé ailleurs dans la bannière.","missionCompleteAdded":"Mission {n} complète · {next}","portalAdded":"Portail ajouté · mission {n}","syncOld":"Parcours synchronisé · ancien Companion détecté : installe la version 0.6.0.","syncOk":"Parcours IITC synchronisé · Companion {v}.","portalDefault":"Portail","bannerDefault":"Fresque"});
Object.assign(I18N.en,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directly from the Companion.","handoverDetail":"The last portal can become the first of the next mission without being treated as an invalid duplicate.","coordsMissing":"Coordinates not found.","coordsInvalid":"Invalid coordinates.","duplicateElsewhere":"This portal is already used elsewhere in the banner.","missionCompleteAdded":"Mission {n} complete · {next}","portalAdded":"Portal added · mission {n}","syncOld":"Route synchronized · old Companion detected: install version 0.6.0.","syncOk":"IITC route synchronized · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner"});
Object.assign(I18N.es,{"routeActionHelp":"Hack / Mod / Captura / Link / Field / Contraseña directamente desde Companion.","handoverDetail":"El último portal puede ser el primero de la siguiente misión sin considerarse un duplicado incorrecto.","coordsMissing":"No se han encontrado coordenadas.","coordsInvalid":"Coordenadas no válidas.","duplicateElsewhere":"Este portal ya se utiliza en otra parte del mosaico.","missionCompleteAdded":"Misión {n} completa · {next}","portalAdded":"Portal añadido · misión {n}","syncOld":"Recorrido sincronizado · Companion antiguo detectado: instala la versión 0.6.0.","syncOk":"Recorrido IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Mosaico"});
Object.assign(I18N.fr,{"livePublish":"Préparer directement dans Mission Authoring","livePublishShort":"Publisher direct","livePreparing":"Préparation des {n} missions pour le Publisher…","liveReady":"Ouverture du Publisher intégré…","liveNativeOnly":"Le Publisher direct est disponible dans l’APK Android.","liveFailed":"Impossible d’ouvrir le Publisher : {error}","liveExperimental":"Expérimental : Mission Authoring s’ouvre dans une vue intégrée à RBL. La connexion Google est la première chose à valider sur ton téléphone.","backupTransfer":"Sauvegarde / transfert","exportPackBackup":"Exporter un pack BannerLab","openOfficialOnly":"Ouvrir le site officiel seulement","publisherPreparingImage":"Rendu mission {n}/{total}…"});
Object.assign(I18N.en,{"livePublish":"Prepare directly in Mission Authoring","livePublishShort":"Direct Publisher","livePreparing":"Preparing {n} missions for Publisher…","liveReady":"Opening integrated Publisher…","liveNativeOnly":"Direct Publisher is available in the Android APK.","liveFailed":"Unable to open Publisher: {error}","liveExperimental":"Experimental: Mission Authoring opens inside an RBL-controlled view. Google sign-in is the first thing to validate on your phone.","backupTransfer":"Backup / transfer","exportPackBackup":"Export BannerLab pack","openOfficialOnly":"Open official site only","publisherPreparingImage":"Rendering mission {n}/{total}…"});
Object.assign(I18N.es,{"livePublish":"Preparar directamente en Mission Authoring","livePublishShort":"Publisher directo","livePreparing":"Preparando {n} misiones para Publisher…","liveReady":"Abriendo Publisher integrado…","liveNativeOnly":"Publisher directo está disponible en la APK Android.","liveFailed":"No se puede abrir Publisher: {error}","liveExperimental":"Experimental: Mission Authoring se abre en una vista controlada por RBL. El inicio de sesión de Google es lo primero que hay que validar en tu teléfono.","backupTransfer":"Copia / transferencia","exportPackBackup":"Exportar paquete BannerLab","openOfficialOnly":"Abrir solo el sitio oficial","publisherPreparingImage":"Renderizando misión {n}/{total}…"});
Object.assign(I18N.fr,{"browserPublish":"Publier dans Firefox","browserPublishShort":"Publisher navigateur","browserSetup":"Installer / mettre à jour le Publisher navigateur","browserPreparing":"Préparation de la mission {n}/{total}…","browserOpening":"Ouverture de Firefox…","browserNeed":"Le Publisher direct utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.","browserFailed":"Impossible d’ouvrir le Publisher : {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 pour missions.ingress.com. À installer une fois dans Violentmonkey sur Firefox Android.","browserShareDialog":"Installer Publisher 0.4.0","browserShareFailed":"Impossible de partager le Publisher navigateur.","publisherUrlTooLarge":"La mission est trop lourde à transmettre au navigateur.","publisherReturn":"Retour du Publisher.","publisherNoFirefox":"Firefox n’a pas été détecté. Ouverture dans le navigateur par défaut, mais le Publisher nécessite un navigateur avec userscripts."});
Object.assign(I18N.en,{"browserPublish":"Publish in Firefox","browserPublishShort":"Browser Publisher","browserSetup":"Install / update Browser Publisher","browserPreparing":"Preparing mission {n}/{total}…","browserOpening":"Opening Firefox…","browserNeed":"Direct Publisher uses Firefox Android + Violentmonkey so Google sign-in stays in a normal browser.","browserFailed":"Unable to open Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 for missions.ingress.com. Install it once in Violentmonkey on Firefox Android.","browserShareDialog":"Install Publisher 0.4.0","browserShareFailed":"Unable to share Browser Publisher.","publisherUrlTooLarge":"This mission is too large to send to the browser.","publisherReturn":"Returned from Publisher.","publisherNoFirefox":"Firefox was not detected. Opening the default browser, but Publisher requires a browser with userscript support."});
Object.assign(I18N.es,{"browserPublish":"Publicar en Firefox","browserPublishShort":"Publisher navegador","browserSetup":"Instalar / actualizar Publisher navegador","browserPreparing":"Preparando misión {n}/{total}…","browserOpening":"Abriendo Firefox…","browserNeed":"Publisher directo usa Firefox Android + Violentmonkey para mantener el inicio de sesión de Google en un navegador normal.","browserFailed":"No se puede abrir Publisher: {error}","browserShareText":"Redacted BannerLab Publisher 0.4.0 para missions.ingress.com. Instálalo una vez en Violentmonkey sobre Firefox Android.","browserShareDialog":"Instalar Publisher 0.4.0","browserShareFailed":"No se puede compartir Publisher navegador.","publisherUrlTooLarge":"La misión es demasiado pesada para enviarla al navegador.","publisherReturn":"Regreso desde Publisher.","publisherNoFirefox":"Firefox no detectado. Se abre el navegador predeterminado, pero Publisher necesita un navegador compatible con userscripts."});
Object.assign(I18N.fr,{"publisherBrowser":"Navigateur de publication","chromeMode":"Chrome","chromeModeSub":"Sans appli supplémentaire · 1 favori à lancer par mission","firefoxMode":"Firefox","firefoxModeSub":"Automatique après installation de Violentmonkey + Publisher","recommendedAuto":"Automatique","noExtraApp":"Sans appli en plus","publishSelected":"Publier la mission","chromeSetup":"Configurer Chrome","firefoxSetup":"Configurer Firefox","chromeReady":"Favori Chrome vérifié","firefoxReady":"Publisher Firefox vérifié","notConfigured":"À configurer une fois","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome ne permet pas à RBL d’ajouter le favori à ta place. On réduit donc l’installation au strict minimum.","chromeStep1":"1. Copie le code du favori RBL Publisher.","chromeStep2":"2. Ouvre Mission Authoring dans Chrome et ajoute la page aux favoris.","chromeStep3":"3. Modifie ce favori : nom « RBL Publisher » et remplace son URL par le code copié.","chromeStep4":"4. Sur la page Mission Authoring, touche la barre d’adresse, tape « RBL », puis choisis le favori pour le tester.","copyBookmarklet":"Copier le code du favori","bookmarkletCopied":"Code du favori copié","openChromeSetup":"Ouvrir Chrome pour l’installation","testChrome":"Tester le favori Chrome","chromeRunHint":"Dans Chrome : touche la barre d’adresse, tape RBL puis sélectionne « RBL Publisher ».","chromeNeedsSetup":"Configure d’abord le favori Chrome RBL Publisher.","chromeOpenFail":"Impossible d’ouvrir Chrome. Ouverture dans le navigateur par défaut.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox peut charger le Publisher automatiquement grâce à Violentmonkey. C’est le mode le plus fluide.","sharePublisher":"Partager le userscript Publisher","testFirefox":"Tester le Publisher Firefox","firefoxNeedsSetup":"Installe Violentmonkey et le Publisher dans Firefox avant le test.","browserSaved":"Navigateur de publication : {browser}","setupConfirmed":"Configuration vérifiée.","bookmarkletCopyFail":"Impossible de copier automatiquement. Le code est affiché ci-dessous.","bookmarkletLabel":"Code du favori","autoImpossibleChrome":"Chargement automatique impossible dans Chrome Android sans extension ou permission intrusive. Le favori reste nécessaire.","openChromePublish":"Ouverture dans Chrome…","openFirefoxPublish":"Ouverture dans Firefox…"});
Object.assign(I18N.en,{"publisherBrowser":"Publishing browser","chromeMode":"Chrome","chromeModeSub":"No extra app · run one bookmark per mission","firefoxMode":"Firefox","firefoxModeSub":"Automatic after installing Violentmonkey + Publisher","recommendedAuto":"Automatic","noExtraApp":"No extra app","publishSelected":"Publish mission","chromeSetup":"Set up Chrome","firefoxSetup":"Set up Firefox","chromeReady":"Chrome bookmark verified","firefoxReady":"Firefox Publisher verified","notConfigured":"One-time setup required","chromeSetupTitle":"Chrome Publisher","chromeSetupIntro":"Chrome does not let RBL add the bookmark for you. Setup is therefore reduced to the minimum possible.","chromeStep1":"1. Copy the RBL Publisher bookmark code.","chromeStep2":"2. Open Mission Authoring in Chrome and bookmark the page.","chromeStep3":"3. Edit that bookmark: name it “RBL Publisher” and replace its URL with the copied code.","chromeStep4":"4. On Mission Authoring, tap the address bar, type “RBL”, then choose the bookmark to test it.","copyBookmarklet":"Copy bookmark code","bookmarkletCopied":"Bookmark code copied","openChromeSetup":"Open Chrome for setup","testChrome":"Test Chrome bookmark","chromeRunHint":"In Chrome: tap the address bar, type RBL, then select “RBL Publisher”.","chromeNeedsSetup":"Set up the RBL Publisher Chrome bookmark first.","chromeOpenFail":"Could not open Chrome. Opening the default browser.","firefoxSetupTitle":"Firefox Publisher","firefoxSetupIntro":"Firefox can load Publisher automatically through Violentmonkey. This is the smoothest mode.","sharePublisher":"Share Publisher userscript","testFirefox":"Test Firefox Publisher","firefoxNeedsSetup":"Install Violentmonkey and Publisher in Firefox before testing.","browserSaved":"Publishing browser: {browser}","setupConfirmed":"Setup verified.","bookmarkletCopyFail":"Could not copy automatically. The code is shown below.","bookmarkletLabel":"Bookmark code","autoImpossibleChrome":"Automatic loading is not possible in Chrome Android without an extension or intrusive permission. The bookmark is still required.","openChromePublish":"Opening Chrome…","openFirefoxPublish":"Opening Firefox…"});
Object.assign(I18N.es,{"publisherBrowser":"Navegador de publicación","chromeMode":"Chrome","chromeModeSub":"Sin aplicación adicional · un favorito por misión","firefoxMode":"Firefox","firefoxModeSub":"Automático tras instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sin aplicación adicional","publishSelected":"Publicar misión","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Favorito Chrome verificado","firefoxReady":"Publisher Firefox verificado","notConfigured":"Configurar una sola vez","chromeSetupTitle":"Publisher Chrome","chromeSetupIntro":"Chrome no permite que RBL añada el favorito por ti. La instalación se reduce al mínimo posible.","chromeStep1":"1. Copia el código del favorito RBL Publisher.","chromeStep2":"2. Abre Mission Authoring en Chrome y añade la página a favoritos.","chromeStep3":"3. Edita ese favorito: nombre « RBL Publisher » y sustituye la URL por el código copiado.","chromeStep4":"4. En Mission Authoring, toca la barra de direcciones, escribe « RBL » y elige el favorito para probarlo.","copyBookmarklet":"Copiar código del favorito","bookmarkletCopied":"Código del favorito copiado","openChromeSetup":"Abrir Chrome para instalar","testChrome":"Probar favorito Chrome","chromeRunHint":"En Chrome: toca la barra de direcciones, escribe RBL y selecciona « RBL Publisher ».","chromeNeedsSetup":"Configura primero el favorito Chrome RBL Publisher.","chromeOpenFail":"No se puede abrir Chrome. Se abre el navegador predeterminado.","firefoxSetupTitle":"Publisher Firefox","firefoxSetupIntro":"Firefox puede cargar Publisher automáticamente con Violentmonkey. Es el modo más fluido.","sharePublisher":"Compartir userscript Publisher","testFirefox":"Probar Publisher Firefox","firefoxNeedsSetup":"Instala Violentmonkey y Publisher en Firefox antes de probar.","browserSaved":"Navegador de publicación: {browser}","setupConfirmed":"Configuración verificada.","bookmarkletCopyFail":"No se puede copiar automáticamente. El código aparece abajo.","bookmarkletLabel":"Código del favorito","autoImpossibleChrome":"La carga automática no es posible en Chrome Android sin extensión o permiso intrusivo. El favorito sigue siendo necesario.","openChromePublish":"Abriendo Chrome…","openFirefoxPublish":"Abriendo Firefox…"});
Object.assign(I18N.fr,{"chromeModeSub":"Sans appli supplémentaire · petit favori + Autoriser si demandé","chromeWizardTitle":"Configurer Chrome","chromeWizardIntro":"Une seule configuration. RBL mémorise ta progression.","chromeFileTitle":"Enregistrer le Publisher","chromeFileText":"Enregistre le petit fichier Publisher sur ton téléphone. Dans la feuille Android, choisis Fichiers / Enregistrer et garde-le par exemple dans Téléchargements.","chromeSaveFile":"Enregistrer publisher.js","chromeFileDone":"Fichier Publisher préparé","alreadySaved":"Je l’ai déjà enregistré","chromeBookmarkTitle":"Créer le mini favori","chromeBookmarkText":"Le favori ne contient plus le Publisher entier. Il fait seulement {n} caractères et sert à charger le fichier que tu viens d’enregistrer.","chromeBookmarkName":"Nom du favori : RBL Publisher","chromeBookmarkHow":"Dans Chrome : ouvre Mission Authoring → ⋮ → Ajouter aux favoris. Modifie ensuite le favori, mets « RBL Publisher » et colle le code dans URL.","copyMiniCode":"Copier le mini code","miniCodeCopied":"Mini code copié","openChromeBookmark":"Ouvrir Mission Authoring","bookmarkCreated":"J’ai créé le favori","chromeTestTitle":"Tester et autoriser","chromeTestText":"RBL ouvre Mission Authoring. Dans la barre d’adresse, tape RBL puis touche « RBL Publisher ». La première fois, Chrome te demandera de choisir publisher.js. Les fois suivantes il pourra simplement demander Autoriser.","chromeTestButton":"Tester dans Chrome","chromeTestWaiting":"Dans Chrome : tape RBL → RBL Publisher → sélectionne publisher.js si demandé → Autoriser.","chromeSetupSuccess":"Chrome est prêt","chromeSetupSuccessText":"Le favori et le fichier Publisher fonctionnent. Pour publier : RBL ouvre Chrome, tu lances RBL Publisher et tu autorises si Chrome le demande.","publishNow":"Publier maintenant","wizardPrev":"Précédent","wizardNext":"Continuer","wizardRestart":"Recommencer la configuration","stepOf":"Étape {n}/3","chromeFileShareText":"Enregistre ce fichier publisher.js dans un dossier facile à retrouver, par exemple Téléchargements. Chrome te le demandera au premier test.","chromeFileShareDialog":"Enregistrer RBL Publisher","chromeFileShareFail":"Impossible de préparer le fichier Publisher.","chromePermissionHint":"Chrome pourra redemander l’autorisation de lire publisher.js. Tu peux simplement accepter.","chromeNotAutoFavorite":"RBL ne peut pas créer un favori Chrome automatiquement. C’est la seule étape manuelle obligatoire.","codeLength":"{n} caractères","chromeStepSaved":"Étape enregistrée","chromeResetDone":"Configuration Chrome réinitialisée","chromeSelectFileHint":"Sélectionne le fichier redacted-bannerlab-publisher.user.js enregistré à l’étape 1."});
Object.assign(I18N.en,{"chromeModeSub":"No extra app · small bookmark + Allow when requested","chromeWizardTitle":"Set up Chrome","chromeWizardIntro":"One-time setup. RBL remembers your progress.","chromeFileTitle":"Save Publisher","chromeFileText":"Save the small Publisher file on your phone. In Android's share sheet, choose Files / Save and keep it somewhere easy such as Downloads.","chromeSaveFile":"Save publisher.js","chromeFileDone":"Publisher file prepared","alreadySaved":"I already saved it","chromeBookmarkTitle":"Create the mini bookmark","chromeBookmarkText":"The bookmark no longer contains the whole Publisher. It is only {n} characters and loads the file you just saved.","chromeBookmarkName":"Bookmark name: RBL Publisher","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Add to bookmarks. Then edit the bookmark, name it “RBL Publisher” and paste the code into URL.","copyMiniCode":"Copy mini code","miniCodeCopied":"Mini code copied","openChromeBookmark":"Open Mission Authoring","bookmarkCreated":"I created the bookmark","chromeTestTitle":"Test and authorize","chromeTestText":"RBL opens Mission Authoring. In the address bar type RBL, then tap “RBL Publisher”. The first time Chrome asks you to choose publisher.js. Later it may only ask Allow.","chromeTestButton":"Test in Chrome","chromeTestWaiting":"In Chrome: type RBL → RBL Publisher → select publisher.js if requested → Allow.","chromeSetupSuccess":"Chrome is ready","chromeSetupSuccessText":"The bookmark and Publisher file work. To publish: RBL opens Chrome, you run RBL Publisher and allow access if Chrome asks.","publishNow":"Publish now","wizardPrev":"Previous","wizardNext":"Continue","wizardRestart":"Restart setup","stepOf":"Step {n}/3","chromeFileShareText":"Save this publisher.js somewhere easy to find, such as Downloads. Chrome will ask for it during the first test.","chromeFileShareDialog":"Save RBL Publisher","chromeFileShareFail":"Unable to prepare Publisher file.","chromePermissionHint":"Chrome may ask again for permission to read publisher.js. You can simply allow it.","chromeNotAutoFavorite":"RBL cannot create a Chrome bookmark automatically. This is the only mandatory manual step.","codeLength":"{n} characters","chromeStepSaved":"Step saved","chromeResetDone":"Chrome setup reset","chromeSelectFileHint":"Select the redacted-bannerlab-publisher.user.js file saved in step 1."});
Object.assign(I18N.es,{"chromeModeSub":"Sin aplicación adicional · favorito pequeño + Autorizar si se solicita","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Una sola configuración. RBL recuerda tu progreso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"Guarda el pequeño archivo Publisher en el teléfono. En la hoja de Android elige Archivos / Guardar y déjalo en un lugar fácil, por ejemplo Descargas.","chromeSaveFile":"Guardar publisher.js","chromeFileDone":"Archivo Publisher preparado","alreadySaved":"Ya lo he guardado","chromeBookmarkTitle":"Crear el mini favorito","chromeBookmarkText":"El favorito ya no contiene todo el Publisher. Solo tiene {n} caracteres y carga el archivo que acabas de guardar.","chromeBookmarkName":"Nombre del favorito: RBL Publisher","chromeBookmarkHow":"En Chrome: abre Mission Authoring → ⋮ → Añadir a favoritos. Después edita el favorito, pon « RBL Publisher » y pega el código en URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"He creado el favorito","chromeTestTitle":"Probar y autorizar","chromeTestText":"RBL abre Mission Authoring. En la barra de direcciones escribe RBL y toca « RBL Publisher ». La primera vez Chrome pedirá elegir publisher.js. Después puede pedir solo Autorizar.","chromeTestButton":"Probar en Chrome","chromeTestWaiting":"En Chrome: escribe RBL → RBL Publisher → selecciona publisher.js si se solicita → Autorizar.","chromeSetupSuccess":"Chrome está listo","chromeSetupSuccessText":"El favorito y el archivo Publisher funcionan. Para publicar: RBL abre Chrome, ejecutas RBL Publisher y autorizas si Chrome lo solicita.","publishNow":"Publicar ahora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuración","stepOf":"Paso {n}/3","chromeFileShareText":"Guarda este publisher.js en un lugar fácil de encontrar, por ejemplo Descargas. Chrome lo pedirá durante la primera prueba.","chromeFileShareDialog":"Guardar RBL Publisher","chromeFileShareFail":"No se puede preparar el archivo Publisher.","chromePermissionHint":"Chrome puede volver a pedir permiso para leer publisher.js. Basta con autorizar.","chromeNotAutoFavorite":"RBL no puede crear automáticamente un favorito de Chrome. Es la única etapa manual obligatoria.","codeLength":"{n} caracteres","chromeStepSaved":"Paso guardado","chromeResetDone":"Configuración Chrome reiniciada","chromeSelectFileHint":"Selecciona el archivo redacted-bannerlab-publisher.user.js guardado en el paso 1."});
Object.assign(I18N.fr,{"bannerDescription":"Description de la bannière","required":"Obligatoire","bannerDescriptionHint":"Cette description sert de description par défaut pour toutes les missions. Tu pourras personnaliser une mission ensuite.","bannerDescriptionRequired":"La description de la bannière est obligatoire.","describeBeforePublish":"Décris d’abord la bannière","describeBeforePublishText":"Impossible de publier tant que la bannière n’a pas de description. Elle sera appliquée par défaut à toutes les missions.","saveAndContinue":"Enregistrer et continuer","missionPublishBlocked":"Mission non publiable","missionNeedsPortals":"La mission {n} contient {count}/{need} portails. Il en faut au moins {need} pour la publier.","completeMission":"Compléter la mission","currentMissionReady":"Mission prête à publier","publishBlockedHint":"Le bouton de publication reste bloqué tant que les éléments obligatoires ne sont pas complets.","minimumSix":"Minimum : 6 portails par mission","publisherDescRequired":"Le Publisher refuse une mission sans description.","publisherPortalsRequired":"Le Publisher refuse une mission avec moins de 6 portails."});
Object.assign(I18N.en,{"bannerDescription":"Banner description","required":"Required","bannerDescriptionHint":"This is the default description for every mission. You can still customize individual missions later.","bannerDescriptionRequired":"The banner description is required.","describeBeforePublish":"Describe the banner first","describeBeforePublishText":"Publishing is blocked until the banner has a description. It will be used as the default for all missions.","saveAndContinue":"Save and continue","missionPublishBlocked":"Mission cannot be published","missionNeedsPortals":"Mission {n} has {count}/{need} portals. It needs at least {need} before publishing.","completeMission":"Complete mission","currentMissionReady":"Mission ready to publish","publishBlockedHint":"Publishing remains blocked until all mandatory items are complete.","minimumSix":"Minimum: 6 portals per mission","publisherDescRequired":"Publisher refuses missions without a description.","publisherPortalsRequired":"Publisher refuses missions with fewer than 6 portals."});
Object.assign(I18N.es,{"bannerDescription":"Descripción del mosaico","required":"Obligatorio","bannerDescriptionHint":"Esta será la descripción predeterminada de todas las misiones. Después puedes personalizar cada misión.","bannerDescriptionRequired":"La descripción del mosaico es obligatoria.","describeBeforePublish":"Describe primero el mosaico","describeBeforePublishText":"No se puede publicar hasta que el mosaico tenga una descripción. Se aplicará por defecto a todas las misiones.","saveAndContinue":"Guardar y continuar","missionPublishBlocked":"Misión no publicable","missionNeedsPortals":"La misión {n} tiene {count}/{need} portales. Necesita al menos {need} para publicarla.","completeMission":"Completar misión","currentMissionReady":"Misión lista para publicar","publishBlockedHint":"El botón de publicación permanece bloqueado hasta completar los elementos obligatorios.","minimumSix":"Mínimo: 6 portales por misión","publisherDescRequired":"Publisher rechaza una misión sin descripción.","publisherPortalsRequired":"Publisher rechaza una misión con menos de 6 portales."});
Object.assign(I18N.fr,{"playBanners":"Jouer","playHub":"Jouer une bannière","searchBannergress":"Rechercher sur Bannergress","searchPlaceholder":"Nom de bannière, ville…","search":"Rechercher","favorites":"Favoris","currentBanner":"En cours","noFavorites":"Aucune bannière favorite. Pour une fois, ton stockage local respire.","noPlaySession":"Aucune bannière en cours.","searchPrompt":"Recherche directement les bannières publiques de Bannergress.","searching":"Recherche…","searchError":"Recherche Bannergress impossible : {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favori","removeFavorite":"Retirer des favoris","playThisBanner":"Jouer cette bannière","resumeBanner":"Reprendre la bannière","stopBanner":"Arrêter l’overlay","openCurrentMission":"Ouvrir la mission actuelle","overlayPermissionTitle":"Autoriser l’overlay RBL","overlayPermissionText":"Android doit autoriser Redacted BannerLab à s’afficher par-dessus Ingress. Une seule autorisation système, ensuite notre dino fait sa vie.","overlayPermissionButton":"Autoriser l’affichage par-dessus les applis","overlayPermissionWaiting":"Reviens dans RBL après avoir autorisé l’affichage.","overlayStarted":"Overlay mission démarré.","overlayFailed":"Impossible de démarrer l’overlay : {error}","bannerLoadError":"Impossible de charger cette bannière : {error}","bannerOffline":"Cette bannière ne contient aucune mission exploitable.","bannerDisabled":"{n} mission(s) désactivée(s)","addressUnknown":"Lieu non précisé","doneMissions":"{done}/{total} terminées","deepLinkOnly":"RBL ne pilote pas Ingress : l’overlay ouvre uniquement les deeplinks officiels des missions.","bannergressCredit":"Recherche via Bannergress","publisherWholeBanner":"Préparer toute la bannière","publisherWholeHint":"Une seule session navigateur : toutes les missions et leurs images sont préparées ensemble.","publisherAllRequired":"Toutes les missions doivent être complètes avant de démarrer la session de publication.","publisherSessionCreating":"Préparation de la session Publisher {n}/{total}…","publisherSessionReady":"Session Publisher prête. Enregistre le fichier puis ouvre le navigateur.","publisherSessionFileText":"Enregistre ce fichier de session RBL. Chrome/Firefox le chargera une seule fois pour toute la bannière.","publisherSessionDialog":"Enregistrer la session Publisher","publisherSessionShareFail":"Impossible de préparer la session Publisher.","chromeSessionHint":"Chrome : lance le favori RBL Publisher une seule fois, puis sélectionne le fichier de session que tu viens d’enregistrer.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement ; charge le fichier de session une seule fois.","easterEgg":"Tu l’as cherché."});
Object.assign(I18N.en,{"playBanners":"Play","playHub":"Play a banner","searchBannergress":"Search Bannergress","searchPlaceholder":"Banner name, city…","search":"Search","favorites":"Favorites","currentBanner":"Current","noFavorites":"No favorite banners yet. Your local storage is enjoying the peace.","noPlaySession":"No banner currently running.","searchPrompt":"Search public Bannergress banners directly.","searching":"Searching…","searchError":"Bannergress search failed: {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favorite","removeFavorite":"Remove favorite","playThisBanner":"Play this banner","resumeBanner":"Resume banner","stopBanner":"Stop overlay","openCurrentMission":"Open current mission","overlayPermissionTitle":"Allow RBL overlay","overlayPermissionText":"Android must allow Redacted BannerLab to appear over Ingress. One system permission, then the dino can mind its business.","overlayPermissionButton":"Allow display over other apps","overlayPermissionWaiting":"Return to RBL after granting the permission.","overlayStarted":"Mission overlay started.","overlayFailed":"Could not start overlay: {error}","bannerLoadError":"Could not load this banner: {error}","bannerOffline":"This banner has no usable missions.","bannerDisabled":"{n} disabled mission(s)","addressUnknown":"Location not specified","doneMissions":"{done}/{total} completed","deepLinkOnly":"RBL does not control Ingress: the overlay only opens official mission deep links.","bannergressCredit":"Search via Bannergress","publisherWholeBanner":"Prepare whole banner","publisherWholeHint":"One browser session: all missions and images are prepared together.","publisherAllRequired":"Every mission must be complete before starting the publishing session.","publisherSessionCreating":"Preparing Publisher session {n}/{total}…","publisherSessionReady":"Publisher session ready. Save the file, then open the browser.","publisherSessionFileText":"Save this RBL session file. Chrome/Firefox loads it once for the entire banner.","publisherSessionDialog":"Save Publisher session","publisherSessionShareFail":"Unable to prepare Publisher session.","chromeSessionHint":"Chrome: run the RBL Publisher bookmark once, then select the session file you just saved.","firefoxSessionHint":"Firefox: Publisher loads automatically; select the session file once.","easterEgg":"You asked for this."});
Object.assign(I18N.es,{"playBanners":"Jugar","playHub":"Jugar un mosaico","searchBannergress":"Buscar en Bannergress","searchPlaceholder":"Nombre, ciudad…","search":"Buscar","favorites":"Favoritos","currentBanner":"En curso","noFavorites":"Aún no hay mosaicos favoritos. El almacenamiento local descansa.","noPlaySession":"No hay ningún mosaico en curso.","searchPrompt":"Busca directamente mosaicos públicos de Bannergress.","searching":"Buscando…","searchError":"Error al buscar en Bannergress: {error}","missionsCount":"{n} misiones","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Quitar de favoritos","playThisBanner":"Jugar este mosaico","resumeBanner":"Reanudar mosaico","stopBanner":"Detener overlay","openCurrentMission":"Abrir misión actual","overlayPermissionTitle":"Autorizar overlay RBL","overlayPermissionText":"Android debe permitir que Redacted BannerLab aparezca sobre Ingress. Un permiso del sistema y el dinosaurio queda suelto.","overlayPermissionButton":"Permitir mostrar sobre otras apps","overlayPermissionWaiting":"Vuelve a RBL después de autorizarlo.","overlayStarted":"Overlay de misión iniciado.","overlayFailed":"No se puede iniciar el overlay: {error}","bannerLoadError":"No se puede cargar el mosaico: {error}","bannerOffline":"Este mosaico no contiene misiones utilizables.","bannerDisabled":"{n} misión(es) desactivada(s)","addressUnknown":"Lugar no indicado","doneMissions":"{done}/{total} terminadas","deepLinkOnly":"RBL no controla Ingress: el overlay solo abre deeplinks oficiales de misiones.","bannergressCredit":"Búsqueda mediante Bannergress","publisherWholeBanner":"Preparar todo el mosaico","publisherWholeHint":"Una sola sesión: todas las misiones e imágenes se preparan juntas.","publisherAllRequired":"Todas las misiones deben estar completas antes de iniciar la sesión de publicación.","publisherSessionCreating":"Preparando sesión Publisher {n}/{total}…","publisherSessionReady":"Sesión Publisher lista. Guarda el archivo y abre el navegador.","publisherSessionFileText":"Guarda este archivo de sesión RBL. Chrome/Firefox lo carga una vez para todo el mosaico.","publisherSessionDialog":"Guardar sesión Publisher","publisherSessionShareFail":"No se puede preparar la sesión Publisher.","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher una sola vez y selecciona el archivo de sesión guardado.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente; carga el archivo de sesión una sola vez.","easterEgg":"Tú lo pediste."});
Object.assign(I18N.fr,{"playBanners":"Rechercher une fresque","playHub":"Rechercher une fresque","searchBannergress":"Rechercher une fresque","searchPlaceholder":"Nom ou mot-clé","bannerNameSearch":"Nom / mot-clé","citySearch":"Ville","authorSearch":"Auteur","cityPlaceholder":"Ex. Nantes","authorPlaceholder":"Ex. AgentName","nearMe":"Autour de moi","nearMeOn":"Ma position activée","nearMeHint":"La position remplace le filtre ville ; nom et auteur restent combinables.","locationGetting":"Récupération de ta position…","locationError":"Impossible de récupérer ta position : {error}","locationReady":"Position récupérée","searchCriteriaRequired":"Renseigne au moins un critère de recherche.","cityResolving":"Recherche de la ville…","cityNotFound":"Aucun lieu Bannergress trouvé pour « {city} ».","cityUsing":"Lieu retenu : {city}","searchPrompt":"Combine nom, ville et auteur, ou cherche les fresques proches de ta position.","currentBanner":"Reprendre","playThisBanner":"Lancer cette fresque","resumeBanner":"Reprendre cette fresque","bannerAuthor":"Auteur : {author}","overlayDrag":"≡  Déplacer","overlayMinimize":"Réduire","overlayClose":"Fermer","overlayMoved":"Position overlay enregistrée","searchReset":"Effacer","resultsCount":"{n} résultat(s)","searchFilters":"Filtres actifs","allPublicBanners":"Fresques publiques Bannergress"});
Object.assign(I18N.en,{"playBanners":"Find a banner","playHub":"Find a banner","searchBannergress":"Find a banner","searchPlaceholder":"Name or keyword","bannerNameSearch":"Name / keyword","citySearch":"City","authorSearch":"Author","cityPlaceholder":"e.g. Nantes","authorPlaceholder":"e.g. AgentName","nearMe":"Near me","nearMeOn":"My location enabled","nearMeHint":"Location replaces the city filter; name and author can still be combined.","locationGetting":"Getting your location…","locationError":"Could not get your location: {error}","locationReady":"Location acquired","searchCriteriaRequired":"Enter at least one search criterion.","cityResolving":"Looking up city…","cityNotFound":"No Bannergress place found for “{city}”.","cityUsing":"Using place: {city}","searchPrompt":"Combine name, city and author, or find banners near your location.","currentBanner":"Resume","playThisBanner":"Start this banner","resumeBanner":"Resume this banner","bannerAuthor":"Author: {author}","overlayDrag":"≡  Move","overlayMinimize":"Minimize","overlayClose":"Close","overlayMoved":"Overlay position saved","searchReset":"Clear","resultsCount":"{n} result(s)","searchFilters":"Active filters","allPublicBanners":"Public Bannergress banners"});
Object.assign(I18N.es,{"playBanners":"Buscar un mosaico","playHub":"Buscar un mosaico","searchBannergress":"Buscar un mosaico","searchPlaceholder":"Nombre o palabra clave","bannerNameSearch":"Nombre / palabra clave","citySearch":"Ciudad","authorSearch":"Autor","cityPlaceholder":"Ej. Nantes","authorPlaceholder":"Ej. AgentName","nearMe":"Cerca de mí","nearMeOn":"Mi ubicación activada","nearMeHint":"La ubicación sustituye la ciudad; nombre y autor se pueden combinar.","locationGetting":"Obteniendo tu ubicación…","locationError":"No se puede obtener tu ubicación: {error}","locationReady":"Ubicación obtenida","searchCriteriaRequired":"Introduce al menos un criterio de búsqueda.","cityResolving":"Buscando ciudad…","cityNotFound":"No se encontró ningún lugar Bannergress para « {city} ».","cityUsing":"Lugar usado: {city}","searchPrompt":"Combina nombre, ciudad y autor, o busca mosaicos cerca de tu ubicación.","currentBanner":"Reanudar","playThisBanner":"Iniciar este mosaico","resumeBanner":"Reanudar este mosaico","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Reducir","overlayClose":"Cerrar","overlayMoved":"Posición del overlay guardada","searchReset":"Borrar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros activos","allPublicBanners":"Mosaicos públicos Bannergress"});
Object.assign(I18N.fr,{"publisherSessionReady":"Session enregistrée dans Documents/RedactedBannerLab. Ouverture de Mission Authoring…","publisherSessionFileText":"RBL enregistre automatiquement la session dans Documents/RedactedBannerLab.","publisherSessionDialog":"Session Publisher","chromeSessionHint":"Chrome : lance le favori RBL Publisher. La première fois, choisis RBL_Current_Session.rblpub.json ; ensuite Chrome réutilise ce fichier.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement. Charge RBL_Current_Session.rblpub.json si la session courante n’est pas déjà connue.","publisherCurrentFile":"Fichier courant : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"publisherSessionReady":"Session saved in Documents/RedactedBannerLab. Opening Mission Authoring…","publisherSessionFileText":"RBL automatically saves the session in Documents/RedactedBannerLab.","publisherSessionDialog":"Publisher session","chromeSessionHint":"Chrome: run the RBL Publisher bookmark. The first time choose RBL_Current_Session.rblpub.json; Chrome will reuse that file afterwards.","firefoxSessionHint":"Firefox: Publisher opens automatically. Load RBL_Current_Session.rblpub.json if the current session is not already known.","publisherCurrentFile":"Current file: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"publisherSessionReady":"Sesión guardada en Documents/RedactedBannerLab. Abriendo Mission Authoring…","publisherSessionFileText":"RBL guarda automáticamente la sesión en Documents/RedactedBannerLab.","publisherSessionDialog":"Sesión Publisher","chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. La primera vez elige RBL_Current_Session.rblpub.json; después Chrome reutilizará ese archivo.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente. Carga RBL_Current_Session.rblpub.json si la sesión actual aún no está disponible.","publisherCurrentFile":"Archivo actual: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeFileText":"RBL enregistre directement le Publisher dans Documents/RedactedBannerLab. Aucun partage Android n’est nécessaire.","chromeSaveFile":"Enregistrer le Publisher","chromeFileDone":"Publisher enregistré","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher enregistré dans Documents/RedactedBannerLab.","chromeFileWriteFail":"Impossible d’écrire le Publisher dans Documents/RedactedBannerLab.","chromeSelectFileHint":"Dans Chrome, sélectionne : Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Pour la session : Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.en,{"chromeFileText":"RBL saves Publisher directly into Documents/RedactedBannerLab. No Android share sheet is needed.","chromeSaveFile":"Save Publisher","chromeFileDone":"Publisher saved","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher saved in Documents/RedactedBannerLab.","chromeFileWriteFail":"Unable to write Publisher into Documents/RedactedBannerLab.","chromeSelectFileHint":"In Chrome select: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"For the session: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.es,{"chromeFileText":"RBL guarda Publisher directamente en Documents/RedactedBannerLab. No hace falta la hoja de compartir de Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","chromeFilePath":"Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeFileSaved":"Publisher guardado en Documents/RedactedBannerLab.","chromeFileWriteFail":"No se puede escribir Publisher en Documents/RedactedBannerLab.","chromeSelectFileHint":"En Chrome selecciona: Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js","chromeCurrentSessionHint":"Para la sesión: Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json"});
Object.assign(I18N.fr,{"chromeSessionHint":"Chrome : lance le favori RBL Publisher. Pour chaque nouvelle bannière préparée, Chrome te demandera explicitement RBL_Current_Session.rblpub.json. Ensuite rien à refaire entre les missions.","chromeTestText":"RBL ouvre Mission Authoring. Tape RBL puis lance le favori. Chrome te demandera le Publisher, puis le JSON courant. Le JSON sera redemandé à chaque nouvelle bannière, jamais entre les missions.","chromeSetupSuccessText":"Chrome est prêt. Le Publisher reste mémorisé ; le fichier JSON de la bannière sera choisi explicitement à chaque nouvelle session pour éviter tout ancien projet fantôme.","chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.en,{"chromeSessionHint":"Chrome: run the RBL Publisher bookmark. For every newly prepared banner, Chrome will explicitly ask for RBL_Current_Session.rblpub.json. Nothing else is required between missions.","chromeTestText":"RBL opens Mission Authoring. Type RBL and run the bookmark. Chrome asks for Publisher, then the current JSON. The JSON is requested for each new banner, never between missions.","chromeSetupSuccessText":"Chrome is ready. Publisher stays remembered; the banner JSON is explicitly selected for each new session so stale projects cannot be reused silently.","chromeCurrentSessionHint":"For each new banner: choose Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.es,{"chromeSessionHint":"Chrome: ejecuta el favorito RBL Publisher. Para cada nuevo mosaico preparado, Chrome pedirá explícitamente RBL_Current_Session.rblpub.json. No habrá que repetir nada entre misiones.","chromeTestText":"RBL abre Mission Authoring. Escribe RBL y ejecuta el favorito. Chrome pide Publisher y después el JSON actual. El JSON se vuelve a pedir para cada nuevo mosaico, nunca entre misiones.","chromeSetupSuccessText":"Chrome está listo. Publisher queda memorizado; el JSON del mosaico se selecciona explícitamente en cada nueva sesión para evitar proyectos antiguos.","chromeCurrentSessionHint":"Para cada nuevo mosaico: elige Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Retour au navigateur sans recharger Mission Authoring…","chromeResumeHint":"Chrome est simplement remis au premier plan. Le Publisher recharge automatiquement RBL_Current_Session.rblpub.json si l’autorisation est encore valide.","firefoxResumeHint":"Firefox est simplement remis au premier plan afin de conserver la session Mission Authoring.","browserResumeFallback":"Impossible de reprendre le navigateur existant. Ouverture de Mission Authoring en secours.","publisherAutoRefresh":"Le Publisher surveille désormais le fichier de session courant et recharge automatiquement une nouvelle bannière."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Returning to the browser without reloading Mission Authoring…","chromeResumeHint":"Chrome is only brought back to the foreground. Publisher automatically reloads RBL_Current_Session.rblpub.json while permission remains valid.","firefoxResumeHint":"Firefox is only brought back to the foreground to preserve the Mission Authoring session.","browserResumeFallback":"Could not resume the existing browser. Opening Mission Authoring as fallback.","publisherAutoRefresh":"Publisher now watches the current session file and automatically reloads a newly prepared banner."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Volviendo al navegador sin recargar Mission Authoring…","chromeResumeHint":"Chrome solo vuelve al primer plano. Publisher recarga automáticamente RBL_Current_Session.rblpub.json mientras el permiso siga válido.","firefoxResumeHint":"Firefox solo vuelve al primer plano para conservar la sesión de Mission Authoring.","browserResumeFallback":"No se puede reanudar el navegador existente. Se abre Mission Authoring como alternativa.","publisherAutoRefresh":"Publisher ahora vigila el archivo de sesión actual y recarga automáticamente una nueva pancarta."});
Object.assign(I18N.fr,{"flowLocked":"Édition de la fresque verrouillée","flowLockedText":"L’étape {step} est active. Sélectionne « 1 Fresque » pour modifier l’image, les textes ou le cadrage.","returnFresco":"Sélectionne 1 Fresque pour modifier","flowLockedToast":"Retourne sur l’étape 1 Fresque pour modifier la bannière."});
Object.assign(I18N.en,{"flowLocked":"Banner editing locked","flowLockedText":"Step {step} is active. Select “1 Banner” to edit the image, text or framing.","returnFresco":"Select 1 Banner to edit","flowLockedToast":"Return to step 1 Banner to edit the banner."});
Object.assign(I18N.es,{"flowLocked":"Edición del mosaico bloqueada","flowLockedText":"El paso {step} está activo. Selecciona « 1 Mosaico » para modificar imagen, texto o encuadre.","returnFresco":"Selecciona 1 Mosaico para editar","flowLockedToast":"Vuelve al paso 1 Mosaico para editar el mosaico."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Ouverture de l’onglet Mission Authoring RBL…","chromeResumeHint":"Chrome réutilise désormais le même onglet Mission Authoring réservé à RBL.","firefoxResumeHint":"Ouverture de Mission Authoring dans le navigateur de publication.","browserResumeFallback":"Impossible de réutiliser l’onglet RBL. Ouverture du navigateur en secours.","publisherTabReuse":"RBL utilise un identifiant d’application navigateur stable pour réutiliser le même onglet."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Opening the RBL Mission Authoring tab…","chromeResumeHint":"Chrome now reuses the same Mission Authoring tab reserved for RBL.","firefoxResumeHint":"Opening Mission Authoring in the publishing browser.","browserResumeFallback":"Could not reuse the RBL tab. Opening the browser as fallback.","publisherTabReuse":"RBL uses a stable browser application ID to reuse the same tab."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Abriendo la pestaña Mission Authoring de RBL…","chromeResumeHint":"Chrome reutiliza ahora la misma pestaña Mission Authoring reservada para RBL.","firefoxResumeHint":"Abriendo Mission Authoring en el navegador de publicación.","browserResumeFallback":"No se puede reutilizar la pestaña RBL. Abriendo el navegador como alternativa.","publisherTabReuse":"RBL usa un identificador de aplicación del navegador estable para reutilizar la misma pestaña."});
Object.assign(I18N.fr,{"todo":"À faire","history":"Historique","inProgress":"En cours","addTodo":"Ajouter à À faire","removeTodo":"Retirer de À faire","noTodo":"Aucune fresque à faire. Pour l’instant tu es raisonnable.","noHistory":"Aucune fresque jouée. Le dino s’ennuie.","bannerMap":"Carte du parcours","openMap":"Voir la carte","navigateStart":"Itinéraire vers le départ","startUnavailable":"Point de départ indisponible.","mapUnavailable":"Bannergress ne fournit pas de coordonnées exploitables pour cette fresque.","startPoint":"Départ","missionStart":"Mission {n}","shareGroup":"Partager / groupe","shareProgress":"Partager la progression","shareBanner":"Partager la fresque","shareIntro":"Le QR ouvre RBL sur la même fresque et le même numéro de mission. Aucun compte Bannergress n’est utilisé.","copyLink":"Copier le lien RBL","linkCopied":"Lien RBL copié","shareNow":"Partager","bannergressPage":"Voir sur Bannergress","joinBanner":"Rejoindre la fresque","joinAtMission":"Rejoindre à la mission {n}","sharedBannerLoaded":"Fresque partagée chargée · mission {n}","sharedBannerError":"Impossible de charger cette fresque partagée : {error}","playStats":"Stats de session","startedAt":"Début","finishedAt":"Fin","elapsed":"Durée active","estimatedDistance":"Distance estimée","missionsDone":"Missions terminées","paused":"En pause","playing":"En cours","completedBanner":"Terminée","replayBanner":"Rejouer","resumeFromHistory":"Reprendre","groupNoServer":"Mode groupe sans serveur : partage simplement le QR/lien à nouveau si le groupe change de mission.","publicOnly":"Recherche et données publiques Bannergress uniquement · aucune connexion nécessaire.","routePoints":"{n} points sur le parcours"});
Object.assign(I18N.en,{"todo":"To do","history":"History","inProgress":"In progress","addTodo":"Add to To do","removeTodo":"Remove from To do","noTodo":"No banners to do. Suspiciously reasonable.","noHistory":"No played banners yet. The dino is bored.","bannerMap":"Route map","openMap":"View map","navigateStart":"Navigate to start","startUnavailable":"Start point unavailable.","mapUnavailable":"Bannergress does not provide usable coordinates for this banner.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Share / group","shareProgress":"Share progress","shareBanner":"Share banner","shareIntro":"The QR opens RBL on the same banner and mission number. No Bannergress account is used.","copyLink":"Copy RBL link","linkCopied":"RBL link copied","shareNow":"Share","bannergressPage":"Open on Bannergress","joinBanner":"Join banner","joinAtMission":"Join at mission {n}","sharedBannerLoaded":"Shared banner loaded · mission {n}","sharedBannerError":"Could not load shared banner: {error}","playStats":"Session stats","startedAt":"Started","finishedAt":"Finished","elapsed":"Active time","estimatedDistance":"Estimated distance","missionsDone":"Missions done","paused":"Paused","playing":"In progress","completedBanner":"Completed","replayBanner":"Play again","resumeFromHistory":"Resume","groupNoServer":"Serverless group mode: share the QR/link again if the group moves to another mission.","publicOnly":"Public Bannergress search/data only · no sign-in required.","routePoints":"{n} route points"});
Object.assign(I18N.es,{"todo":"Por hacer","history":"Historial","inProgress":"En curso","addTodo":"Añadir a Por hacer","removeTodo":"Quitar de Por hacer","noTodo":"No hay mosaicos pendientes. Sospechosamente razonable.","noHistory":"No hay mosaicos jugados. El dino se aburre.","bannerMap":"Mapa del recorrido","openMap":"Ver mapa","navigateStart":"Ir al punto de inicio","startUnavailable":"Punto de inicio no disponible.","mapUnavailable":"Bannergress no proporciona coordenadas utilizables para este mosaico.","startPoint":"Inicio","missionStart":"Misión {n}","shareGroup":"Compartir / grupo","shareProgress":"Compartir progreso","shareBanner":"Compartir mosaico","shareIntro":"El QR abre RBL en el mismo mosaico y número de misión. No se usa ninguna cuenta Bannergress.","copyLink":"Copiar enlace RBL","linkCopied":"Enlace RBL copiado","shareNow":"Compartir","bannergressPage":"Abrir en Bannergress","joinBanner":"Unirse al mosaico","joinAtMission":"Unirse en la misión {n}","sharedBannerLoaded":"Mosaico compartido cargado · misión {n}","sharedBannerError":"No se puede cargar el mosaico compartido: {error}","playStats":"Estadísticas de sesión","startedAt":"Inicio","finishedAt":"Fin","elapsed":"Tiempo activo","estimatedDistance":"Distancia estimada","missionsDone":"Misiones terminadas","paused":"En pausa","playing":"En curso","completedBanner":"Terminado","replayBanner":"Jugar otra vez","resumeFromHistory":"Reanudar","groupNoServer":"Modo grupo sin servidor: comparte de nuevo el QR/enlace si el grupo cambia de misión.","publicOnly":"Solo búsqueda/datos públicos de Bannergress · no hace falta iniciar sesión.","routePoints":"{n} puntos de recorrido"});
Object.assign(I18N.fr,{"uselessStats":"Stats inutiles","loadingStats":"Calcul des trucs dont personne n’avait besoin…","statsUnavailable":"Pas assez de coordonnées pour calculer les stats inutiles.","bgDistance":"Distance Bannergress","calculatedTrack":"Tracé calculé","walkingEstimate":"Marche théorique","routeSteps":"Étapes","uniquePlaces":"Lieux distincts","revisitedPlaces":"Passages répétés","stepsPerKm":"Étapes / km","avgMissionDistance":"Moyenne / mission","longestMission":"Mission la plus longue","longestLeg":"Plus long tronçon","betweenMissions":"Transitions inter-missions","detourFactor":"Coefficient de détour","routeCoverage":"Couverture carto","missionShort":"M{n}","straightLine":"Départ → arrivée","funStatsDisclaimer":"Calculs géométriques entre les points Bannergress, pas un itinéraire routier. Donc oui, c’est scientifiquement approximatif et parfaitement satisfaisant pour des stats inutiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Stats inutiles","hideUselessStats":"Masquer les stats","statsLoaded":"Stats calculées"});
Object.assign(I18N.en,{"uselessStats":"Useless stats","loadingStats":"Calculating things nobody asked for…","statsUnavailable":"Not enough coordinates to calculate useless stats.","bgDistance":"Bannergress distance","calculatedTrack":"Calculated track","walkingEstimate":"Theoretical walking","routeSteps":"Steps","uniquePlaces":"Unique places","revisitedPlaces":"Repeated visits","stepsPerKm":"Steps / km","avgMissionDistance":"Average / mission","longestMission":"Longest mission","longestLeg":"Longest leg","betweenMissions":"Between-mission transitions","detourFactor":"Detour factor","routeCoverage":"Map coverage","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"Geometric calculations between Bannergress points, not a road route. Scientifically approximate, therefore ideal for useless stats.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Useless stats","hideUselessStats":"Hide stats","statsLoaded":"Stats calculated"});
Object.assign(I18N.es,{"uselessStats":"Estadísticas inútiles","loadingStats":"Calculando cosas que nadie necesitaba…","statsUnavailable":"No hay suficientes coordenadas para calcular estadísticas inútiles.","bgDistance":"Distancia Bannergress","calculatedTrack":"Recorrido calculado","walkingEstimate":"Caminata teórica","routeSteps":"Etapas","uniquePlaces":"Lugares distintos","revisitedPlaces":"Pasos repetidos","stepsPerKm":"Etapas / km","avgMissionDistance":"Media / misión","longestMission":"Misión más larga","longestLeg":"Tramo más largo","betweenMissions":"Transiciones entre misiones","detourFactor":"Factor de desvío","routeCoverage":"Cobertura cartográfica","missionShort":"M{n}","straightLine":"Inicio → final","funStatsDisclaimer":"Cálculos geométricos entre puntos Bannergress, no una ruta vial. Científicamente aproximado, perfecto para estadísticas inútiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Estadísticas inútiles","hideUselessStats":"Ocultar estadísticas","statsLoaded":"Estadísticas calculadas"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne RBL","walkingEstimate":"Temps piéton RBL","directGeometric":"Distance directe cumulée","routingDetour":"Détour du réseau piéton","routingSource":"Routage","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponible · estimation géométrique","routingLoading":"Calcul du vrai parcours piéton…","routingFailed":"Routage piéton indisponible, stats géométriques utilisées.","funStatsDisclaimer":"Distance piétonne calculée par Valhalla sur les chemins OpenStreetMap entre tous les points de la fresque. La distance directe reste affichée pour comparaison. Les chemins OSM peuvent évidemment être faux, parce que même les cartes ont leurs jours sans.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.en,{"calculatedTrack":"RBL walking distance","walkingEstimate":"RBL walking time","directGeometric":"Cumulative direct distance","routingDetour":"Pedestrian network detour","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla unavailable · geometric estimate","routingLoading":"Calculating actual walking route…","routingFailed":"Walking routing unavailable, geometric stats used.","funStatsDisclaimer":"Walking distance calculated by Valhalla over OpenStreetMap paths between every banner point. Direct distance remains for comparison. OSM paths can of course be wrong, because maps also enjoy chaos.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia a pie RBL","walkingEstimate":"Tiempo a pie RBL","directGeometric":"Distancia directa acumulada","routingDetour":"Desvío de la red peatonal","routingSource":"Enrutamiento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla no disponible · estimación geométrica","routingLoading":"Calculando la ruta peatonal real…","routingFailed":"Enrutamiento peatonal no disponible, se usan estadísticas geométricas.","funStatsDisclaimer":"Distancia a pie calculada por Valhalla sobre caminos OpenStreetMap entre todos los puntos del mosaico. La distancia directa se conserva para comparar. OSM también puede equivocarse, porque la perfección era demasiado pedir.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.fr,{"routingNative":"Valhalla + OSM · HTTP natif Android","routingWeb":"Valhalla + OSM · navigateur","routingErrorDetail":"Échec Valhalla : {error}"});
Object.assign(I18N.en,{"routingNative":"Valhalla + OSM · Android native HTTP","routingWeb":"Valhalla + OSM · browser","routingErrorDetail":"Valhalla failed: {error}"});
Object.assign(I18N.es,{"routingNative":"Valhalla + OSM · HTTP nativo Android","routingWeb":"Valhalla + OSM · navegador","routingErrorDetail":"Error de Valhalla: {error}"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance jouable RBL","walkingEstimate":"Temps de marche RBL","routingNative":"Valhalla + OSM · portée Ingress 40 m","routingWeb":"Valhalla + OSM · portée Ingress 40 m","routingDetour":"Écart réseau / direct","funStatsDisclaimer":"RBL cherche un chemin piéton OpenStreetMap passant à moins de 40 m de chaque portail, ce qui correspond mieux à la portée de jeu Ingress que d’obliger le trajet à atteindre la coordonnée exacte du portail. La distance directe cumulée reste affichée pour comparaison.","ingressRadius":"Portée Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.en,{"calculatedTrack":"RBL playable distance","walkingEstimate":"RBL walking time","routingNative":"Valhalla + OSM · 40 m Ingress range","routingWeb":"Valhalla + OSM · 40 m Ingress range","routingDetour":"Network / direct ratio","funStatsDisclaimer":"RBL looks for an OpenStreetMap pedestrian route passing within 40 m of every portal. This better matches actual Ingress interaction range than forcing the route to reach the portal's exact coordinate. Cumulative direct distance remains visible for comparison.","ingressRadius":"Ingress range","ingressRadiusValue":"40 m"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia jugable RBL","walkingEstimate":"Tiempo a pie RBL","routingNative":"Valhalla + OSM · alcance Ingress 40 m","routingWeb":"Valhalla + OSM · alcance Ingress 40 m","routingDetour":"Relación red / directa","funStatsDisclaimer":"RBL busca una ruta peatonal OpenStreetMap que pase a menos de 40 m de cada portal. Esto se ajusta mejor al alcance real de Ingress que obligar la ruta a llegar a la coordenada exacta del portal. La distancia directa acumulada sigue visible para comparar.","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne estimée","walkingEstimate":"Temps de marche estimé","routingNative":"Valhalla + OSM · contrôle tronçon par tronçon","routingWeb":"Valhalla + OSM · contrôle tronçon par tronçon","routingDetour":"Écart réseau / direct","correctedLegs":"Tronçons corrigés","rawValhalla":"Valhalla brut","funStatsDisclaimer":"RBL route chaque liaison portail → portail sur le réseau piéton OpenStreetMap. Chaque tronçon est contrôlé : si Valhalla propose une distance impossible ou un détour manifestement aberrant, seul ce tronçon est remplacé par sa distance directe. C’est une estimation de marche, pas une mesure GPS réelle."});
Object.assign(I18N.en,{"calculatedTrack":"Estimated walking distance","walkingEstimate":"Estimated walking time","routingNative":"Valhalla + OSM · per-leg sanity check","routingWeb":"Valhalla + OSM · per-leg sanity check","routingDetour":"Network / direct ratio","correctedLegs":"Corrected legs","rawValhalla":"Raw Valhalla","funStatsDisclaimer":"RBL routes every portal-to-portal leg on the OpenStreetMap pedestrian network. Each leg is sanity-checked: impossible shortcuts or obviously absurd detours are replaced only for that leg by direct distance. This is a walking estimate, not a GPS measurement."});
Object.assign(I18N.es,{"calculatedTrack":"Distancia peatonal estimada","walkingEstimate":"Tiempo de marcha estimado","routingNative":"Valhalla + OSM · control tramo por tramo","routingWeb":"Valhalla + OSM · control tramo por tramo","routingDetour":"Relación red / directa","correctedLegs":"Tramos corregidos","rawValhalla":"Valhalla bruto","funStatsDisclaimer":"RBL calcula cada tramo portal → portal sobre la red peatonal OpenStreetMap. Cada tramo se valida: atajos imposibles o desvíos claramente absurdos se sustituyen solo en ese tramo por la distancia directa. Es una estimación a pie, no una medición GPS real."});
function tr(key,vars={}){
  let s=(I18N[APP_LANG]&&I18N[APP_LANG][key])||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))s=s.replaceAll('{'+k+'}',String(v));
  return s;
}
function setAppLanguage(lang){
  if(!SUPPORTED_LANGS.includes(lang))return;
  localStorage.setItem('rbl-language',lang);
  location.reload();
}

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  name: 'Ma fresque',
  rows: 3,
  showGrid: true,
  showCircles: true,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0 },
  texts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    reuseLastPortal: true,
    currentMission: 0,
    missions: []
  }
};

let activeFlow = 'fresco';
let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;
let historyUndo = [];
let historyRedo = [];
let historyBusy = false;
const HISTORY_LIMIT = 80;

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function snapshotState(){
  const data=serializeState();
  delete data.updatedAt;
  return {data:deepClone(data),blob:state.bg.blob,image:state.bg.image,active:state.active};
}
function snapshotsEqual(a,b){
  return !!a&&!!b&&a.blob===b.blob&&a.image===b.image&&a.active===b.active&&JSON.stringify(a.data)===JSON.stringify(b.data);
}
function beginHistory(){return historyBusy?null:snapshotState()}
function commitHistory(before,label='Modification'){
  if(historyBusy||!before)return;
  const after=snapshotState();
  if(snapshotsEqual(before,after))return;
  historyUndo.push({snapshot:before,label});
  if(historyUndo.length>HISTORY_LIMIT)historyUndo.shift();
  historyRedo.length=0;
  updateHistoryUi();
}
function resetHistory(){historyUndo=[];historyRedo=[];updateHistoryUi()}
async function restoreSnapshot(snap){
  if(!snap)return;
  historyBusy=true;
  try{
    const d=snap.data||{};
    state.name=d.name||'Ma fresque';
    state.rows=clamp(parseInt(d.rows)||3,1,25);
    state.showGrid=d.showGrid!==false;state.showCircles=d.showCircles!==false;state.showNumbers=d.showNumbers!==false;
    state.editMode=d.editMode==='mission'?'mission':'fresco';
    state.selectedMissionKey=d.selectedMissionKey||null;
    state.missionOverrides=deepClone(d.missionOverrides||{});
    state.texts=deepClone(d.texts||[]);
    state.active=snap.active||'background';
    state.planner=normalizePlanner(d.planner||{});ensurePlannerMissions();
    state.bg={image:snap.image||null,blob:snap.blob||null,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0};
    Object.assign(state.bg,d.bg||{});
    if(!state.bg.image&&state.bg.blob)state.bg.image=await blobToImage(state.bg.blob);
    refreshProjectUi();render();
    if(missionEditorBack)renderMissionEditor();
    scheduleSave();
  }finally{historyBusy=false;updateHistoryUi()}
}
async function undoAction(){
  const item=historyUndo.pop();if(!item)return;
  historyRedo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('undo')} · ${item.label}`);
}
async function redoAction(){
  const item=historyRedo.pop();if(!item)return;
  historyUndo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('redo')} · ${item.label}`);
}
function updateHistoryUi(){
  const undoDisabled=!historyUndo.length,redoDisabled=!historyRedo.length;
  $$('.undoActionBtn').forEach(b=>{b.disabled=undoDisabled;b.classList.toggle('disabled',undoDisabled);b.title=undoDisabled?tr('undo'):`${tr('undo')} · ${historyUndo.at(-1).label}`});
  $$('.redoActionBtn').forEach(b=>{b.disabled=redoDisabled;b.classList.toggle('disabled',redoDisabled);b.title=redoDisabled?tr('redo'):`${tr('redo')} · ${historyRedo.at(-1).label}`});
}
function historyControl(el,label){
  if(!el)return;
  let before=null;
  const begin=()=>{if(before===null)before=beginHistory()};
  const commit=()=>{if(before!==null){commitHistory(before,label);before=null}};
  el.addEventListener('pointerdown',begin);
  el.addEventListener('focus',begin);
  el.addEventListener('change',commit);
  el.addEventListener('blur',commit);
}

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2-4.5-4.4 6.2-.9L12 3Z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

function appHTML(){
  return `<main class="app">
    <header class="topbar">
      <div class="brand">
        <button class="brandmark brandegg" id="brandEgg" aria-label="Redacted"><img src="/redacted-logo-512.png" alt="Redacted"></button>
        <div><h1>Redacted BannerLab</h1><small>${tr('subtitle')} · v${APP_VERSION}</small></div>
      </div>
      <div class="grow"></div><button class="playhubbtn" id="playHubBtn" aria-label="${tr('playBanners')}">${icon('search')}<span>${tr('playBanners')}</span></button><button class="iconbtn" id="infoBtn" aria-label="Infos">${icon('info')}</button>
    </header>
    <section class="page">
      <div class="card projectbar">
        <div class="projectidentity"><input id="projectName" value="${escapeAttr(state.name)}" maxlength="60"><div class="meta"><span id="missionCount">${state.rows*6}</span> ${tr('missions').toLowerCase()} · ${tr('source')} ${WORLD_W} × <span id="worldH">${state.rows*STEP}</span> px</div></div>
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>${tr("projects")}</span></button>
        <div class="rowpick"><span>${tr("rows")}</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>${tr("fresco")}</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>${tr("route")}</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>${tr("missions")}</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>${tr("publish")}</span></button>
      </div>
      <div class="card workspace" id="workspaceCard">
        <div class="flowlockveil" id="flowLockVeil" hidden>
          <div class="flowlockbox">
            <strong>🔒 ${tr('flowLocked')}</strong>
            <span id="flowLockText">${tr('flowLockedText',{step:tr('route')})}</span>
            <small>${tr('returnFresco')}</small>
          </div>
        </div>
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">${tr("wholeFresco")}</button>
          <button class="modebtn" data-editmode="mission">${tr("oneMission")}</button>
          <div class="missionstatus" id="missionStatus">${tr("noMission")}</div>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>${tr("addImage")}</strong>${tr("imageHint")}</div></div></div>
        <div class="badges">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">${tr("circles")}</button>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">${tr("grid")}</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">${tr("numbers")}</button>
          <button class="chip historychip undoActionBtn" id="undoBtn" disabled>↶ ${tr("undo")}</button>
          <button class="chip historychip redoActionBtn" id="redoBtn" disabled>↷ ${tr("redo")}</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} ${tr("enlarge")}</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>${tr("resetMission")}</button>
        </div>
        <div class="hint" id="gestureHint">${tr('bannerHelp')}</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>${tr("image")}</span></button>
      <button class="tool active" data-tool="move">${icon('move')}<span>${tr("framing")}</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>${tr("text")}</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>${tr("preview")}</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>${tr("export")}</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function flowIsEditable(){return activeFlow==='fresco'}
function activeFlowLabel(){
  return activeFlow==='route'?tr('route'):activeFlow==='missions'?tr('missions'):activeFlow==='publish'?tr('publish'):tr('fresco');
}
function applyFlowLock(){
  const locked=!flowIsEditable();
  const workspace=$('#workspaceCard');
  const veil=$('#flowLockVeil');
  workspace?.classList.toggle('flowlocked',locked);
  if(veil)veil.hidden=!locked;
  const txt=$('#flowLockText');
  if(txt)txt.textContent=tr('flowLockedText',{step:activeFlowLabel()});

  const rows=$('#rowsSelect');
  if(rows)rows.disabled=locked;

  // Editing tools only. Preview/export remain usable.
  $$('.tool[data-tool="image"],.tool[data-tool="move"],.tool[data-tool="text"]').forEach(b=>{
    b.classList.toggle('flowdisabled',locked);
    b.setAttribute('aria-disabled',locked?'true':'false');
  });

  $$('.flowstep').forEach(b=>b.classList.toggle('on',b.dataset.flow===activeFlow));
}
function requireFrescoFlow(){
  if(flowIsEditable())return true;
  toast(tr('flowLockedToast'));
  return false;
}
function setFlowStep(flow,{open=true}={}){
  if(!['fresco','route','missions','publish'].includes(flow))flow='fresco';
  activeFlow=flow;
  applyFlowLock();

  if(!open)return;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawBaseBackground(c){
  if(!state.bg.image)return;
  const b=state.bg;
  c.save();c.translate(b.x,b.y);c.rotate(b.rotation);c.scale(b.scale,b.scale);
  c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
}

function drawOverlayWorld(c){
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  const lines=(t.text||tr('text')).split('\n');
  c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  const lineH=t.fontSize*1.08;
  lines.forEach((line,i)=>{const y=(i-(lines.length-1)/2)*lineH;if(t.strokeWidth>0){c.lineWidth=t.strokeWidth;c.strokeStyle=t.strokeColor;c.strokeText(line,0,y)}c.fillStyle=t.color;c.fillText(line,0,y)});
  c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseBackground(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseBackground(c);
    c.restore();
  }
  drawOverlayWorld(c);
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=state.bg.image?'none':'grid';
  updateMissionUi();
  updateHistoryUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle='rgba(0,0,0,.44)';c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission'||!state.active.startsWith('text:'))return;
  const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
  c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
  c.font=`800 ${t.fontSize}px system-ui, sans-serif`;
  const lines=t.text.split('\n');const w=Math.max(...lines.map(x=>c.measureText(x).width),40)+36;const h=lines.length*t.fontSize*1.08+28;
  c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  $$('.tool').forEach(b=>b.classList.toggle('active',(b.dataset.tool==='move'&&a==='background')||(b.dataset.tool==='text'&&a.startsWith('text:'))));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=tr('missionSelected',{n:missionNumber(rc.row,rc.col)});
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent=tr('tapMedallion');reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML=tr('missionHelp');
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML=tr('bannerHelp');
  }
}

async function loadImageFile(file){
  if(!file)return;
  const before=beginHistory();
  if(file.size>45*1024*1024)toast(tr('heavyImage'));
  const img=await blobToImage(file);state.bg.blob=file;state.bg.image=img;
  fitBackground();setEditMode('fresco');setActive('background');commitHistory(before,tr('histImport'));scheduleSave();render();toast(tr('imported',{w:img.naturalWidth,h:img.naturalHeight}));
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight)}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasPointToMission(clientX,clientY){
  const rect=canvas.getBoundingClientRect();const scale=rect.width/WORLD_W;
  const x=(clientX-rect.left)/scale,y=(clientY-rect.top)/scale;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

canvas.addEventListener('pointerdown',e=>{
  if(!requireFrescoFlow())return;
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(pointers.size===1){gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,isMission:state.editMode==='mission',historyBefore:beginHistory()}}
  else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:state.editMode==='mission',historyBefore:gesture?.historyBefore||beginHistory()}}
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(pointers.size===1&&gesture?.mode==='one'){
    const dx=(e.clientX-gesture.startX)/getCssScale(),dy=(e.clientY-gesture.startY)/getCssScale();
    if(state.editMode==='mission'){obj.dx=gesture.objX+dx;obj.dy=gesture.objY+dy}else{obj.x=gesture.objX+dx;obj.y=gesture.objY+dy}
    render();
  } else if(pointers.size===2){
    const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.x??obj.dx??0,objY:obj.y??obj.dy??0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),historyBefore:gesture?.historyBefore||beginHistory()};return}
    const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);
    obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),state.editMode==='mission'?.2:.02,state.editMode==='mission'?5:30);obj.rotation=gesture.objRot+(a-gesture.angle);
    const x=gesture.objX+(m.x-gesture.mid.x)/getCssScale(),y=gesture.objY+(m.y-gesture.mid.y)/getCssScale();
    if(state.editMode==='mission'){obj.dx=x;obj.dy=y}else{obj.x=x;obj.y=y}
    render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){
    const before=gesture?.historyBefore,label=state.editMode==='mission'?tr('histResetMission'):(state.active.startsWith('text:')?tr('histEditText'):tr('frameImage'));
    gesture=null;commitHistory(before,label);scheduleSave();
  }else if(pointers.size===1){
    const p=[...pointers.values()][0],obj=selectedObj(),before=gesture?.historyBefore;
    if(obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:state.editMode==='mission'?(obj.dx||0):obj.x,objY:state.editMode==='mission'?(obj.dy||0):obj.y,historyBefore:before};
  }
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName').addEventListener('input',e=>{state.name=e.target.value||'Ma fresque';ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>{if(!requireFrescoFlow()){e.target.value=String(state.rows);return}changeRows(+e.target.value)});
function changeRows(rows){
  const before=beginHistory();
  const oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=newH;resizeCanvas();commitHistory(before,tr('rows'));scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;setEditMode(btn.dataset.editmode)}));
$('#resetMissionBtn').addEventListener('click',()=>{if(requireFrescoFlow())resetSelectedMission()});
$('#openMissionEditorBtn').addEventListener('click',()=>{if(requireFrescoFlow())openMissionEditor()});

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(['image','move','text'].includes(t)&&!requireFrescoFlow())return;
  if(t==='image')$('#fileInput').click();
  if(t==='move')openTransformSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#playHubBtn').addEventListener('click',()=>openPlayHub('search'));
let eggTaps=0,eggTimer=null;
$('#brandEgg').addEventListener('click',()=>{
  eggTaps++;clearTimeout(eggTimer);eggTimer=setTimeout(()=>{eggTaps=0},2200);
  if(eggTaps>=7){eggTaps=0;clearTimeout(eggTimer);runDinoEasterEgg()}
});
$('#infoBtn').addEventListener('click',openInfoSheet);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$('#undoBtn').addEventListener('click',()=>{if(requireFrescoFlow())undoAction()});
$('#redoBtn').addEventListener('click',()=>{if(requireFrescoFlow())redoAction()});
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  setFlowStep(btn.dataset.flow);
}));

applyFlowLock();

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}


function runDinoEasterEgg(){
  if($('.rblDinoEgg'))return;
  const wrap=document.createElement('div');wrap.className='rblDinoEgg';
  wrap.innerHTML=`<img src="/redacted-dino-cutout.png" alt=""><span>${escapeHtml(tr('easterEgg'))}</span>`;
  document.body.appendChild(wrap);
  const img=$('img',wrap);
  const done=()=>wrap.remove();
  img.addEventListener('animationend',done,{once:true});
  setTimeout(done,4300);
}

function loadBannerFavorites(){
  try{const x=JSON.parse(localStorage.getItem(BANNER_FAVORITES_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}
}
function saveBannerFavorites(items){localStorage.setItem(BANNER_FAVORITES_KEY,JSON.stringify(items.slice(0,120)))}
function isBannerFavorite(id){return loadBannerFavorites().some(x=>String(x.id)===String(id))}
function favoriteBanner(detail){
  const list=loadBannerFavorites().filter(x=>String(x.id)!==String(detail.id));
  list.unshift(compactBanner(detail));saveBannerFavorites(list);return true;
}
function unfavoriteBanner(id){saveBannerFavorites(loadBannerFavorites().filter(x=>String(x.id)!==String(id)))}
function compactBanner(detail){
  return {
    id:String(detail?.id||''),title:String(detail?.title||tr('unnamed')),
    formattedAddress:String(detail?.formattedAddress||''),lengthMeters:Number(detail?.lengthMeters||0)||0,
    numberOfMissions:Number(detail?.numberOfMissions||detail?.missions?.length||0)||0,
    numberOfDisabledMissions:Number(detail?.numberOfDisabledMissions||0)||0,
    picture:String(detail?.picture||''),author:String(detail?.author||'')
  };
}
function loadBannerTodo(){try{const x=JSON.parse(localStorage.getItem(BANNER_TODO_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function saveBannerTodo(items){localStorage.setItem(BANNER_TODO_KEY,JSON.stringify((items||[]).slice(0,160)))}
function isBannerTodo(id){return loadBannerTodo().some(x=>String(x.id)===String(id))}
function addBannerTodo(detail){const list=loadBannerTodo().filter(x=>String(x.id)!==String(detail.id));list.unshift(compactBanner(detail));saveBannerTodo(list)}
function removeBannerTodo(id){saveBannerTodo(loadBannerTodo().filter(x=>String(x.id)!==String(id)))}
function loadPlayHistory(){try{const x=JSON.parse(localStorage.getItem(PLAY_HISTORY_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function savePlayHistory(items){localStorage.setItem(PLAY_HISTORY_KEY,JSON.stringify((items||[]).slice(0,100)))}
function upsertPlayHistory(session,extra={}){
  if(!session?.bannerId)return;
  const list=loadPlayHistory();const key=String(session.bannerId);
  const old=list.find(x=>String(x.bannerId)===key)||{};
  const rec={...old,...compactBanner({id:session.bannerId,title:session.title,formattedAddress:session.address,picture:session.picture,author:session.author,lengthMeters:session.lengthMeters,numberOfMissions:session.missions?.length}),
    bannerId:key,currentIndex:Number(extra.currentIndex??session.currentIndex??old.currentIndex??0)||0,
    doneCount:Number(extra.doneCount??old.doneCount??0)||0,total:Number(session.missions?.length||old.total||0)||0,
    startedAt:Number(extra.startedAt??session.startedAt??old.startedAt??Date.now())||Date.now(),
    finishedAt:Number(extra.finishedAt??old.finishedAt??0)||0,pausedTotal:Number(extra.pausedTotal??old.pausedTotal??0)||0,
    paused:!!(extra.paused??old.paused),updatedAt:Date.now()};
  const out=[rec,...list.filter(x=>String(x.bannerId)!==key)].sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));savePlayHistory(out);return rec;
}
function activeDurationMs(x){
  const start=Number(x?.startedAt||0);if(!start)return 0;
  const end=Number(x?.finishedAt||Date.now());let paused=Number(x?.pausedTotal||0)||0;
  if(x?.paused&&x?.pausedAt)paused+=Math.max(0,Date.now()-Number(x.pausedAt));
  return Math.max(0,end-start-paused);
}
function formatPlayDuration(ms){
  const min=Math.floor(Math.max(0,ms)/60000),h=Math.floor(min/60),m=min%60;
  return h?`${h} h ${String(m).padStart(2,'0')}`:`${m} min`;
}
function formatPlayDate(ts){if(!ts)return '—';const locale=APP_LANG==='fr'?'fr-FR':APP_LANG==='es'?'es-ES':'en-GB';return new Date(ts).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'})}
function estimatedPlayedMeters(entry){const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1));return (Number(entry?.lengthMeters||0)||0)*Math.min(1,(Number(entry?.doneCount||0)||0)/total)}
function bannergressImage(picture=''){
  if(!picture)return '';
  return /^https?:/i.test(picture)?picture:`${BANNERGRESS_API}${picture.startsWith('/')?'':'/'}${picture}`;
}
function formatBannerDistance(meters){
  const m=Number(meters)||0;if(!m)return '—';return `${(m/1000).toFixed(m>=10000?0:1).replace('.',',')} km`;
}

function formatBannerMeters(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  if(m<1000)return `${Math.round(m)} m`;
  return `${(m/1000).toFixed(m<10000?2:1).replace('.',',')} km`;
}
function formatWalkSeconds(seconds){
  const total=Math.max(0,Math.round(Number(seconds)||0));
  if(!total)return '—';
  const minutes=Math.max(1,Math.round(total/60));
  if(minutes<60)return tr('minutesShort',{n:minutes});
  const h=Math.floor(minutes/60),m=minutes%60;
  return tr('hoursMinutes',{h,m:String(m).padStart(2,'0')});
}
function formatWalkEstimate(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  return formatWalkSeconds((m/4800)*3600);
}
function bannerRouteRows(detail){
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  return missions.map((m,index)=>{
    const route=Array.isArray(m?.route)?m.route.filter(p=>Number.isFinite(Number(p?.latitude))&&Number.isFinite(Number(p?.longitude))):[];
    let meters=0,longestLeg=0;
    for(let i=1;i<route.length;i++){
      const d=haversine(route[i-1],route[i]);
      meters+=d;
      longestLeg=Math.max(longestLeg,d);
    }
    return {index,route,meters,longestLeg,title:m?.title||tr('missionStart',{n:index+1})};
  });
}
function bannerFunStats(detail){
  const missionRows=bannerRouteRows(detail);
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  const withRoute=missionRows.filter(x=>x.route.length);
  const routeMeters=missionRows.reduce((s,x)=>s+x.meters,0);
  let transitionMeters=0,longestTransition=0;
  for(let i=1;i<withRoute.length;i++){
    const prev=withRoute[i-1].route.at(-1),next=withRoute[i].route[0];
    const d=haversine(prev,next);
    transitionMeters+=d;
    longestTransition=Math.max(longestTransition,d);
  }
  const geometricMeters=routeMeters+transitionMeters;
  const bgMeters=Number(detail?.lengthMeters||0)||0;

  const allPoints=missionRows.flatMap(x=>x.route);
  const uniqueKeys=new Set(allPoints.map(p=>`${Number(p.latitude).toFixed(5)},${Number(p.longitude).toFixed(5)}`));
  const uniquePlaces=uniqueKeys.size;
  const repeated=Math.max(0,allPoints.length-uniquePlaces);

  let longestMission=null,longestLeg=0;
  for(const row of missionRows){
    if(!longestMission||row.meters>longestMission.meters)longestMission=row;
    longestLeg=Math.max(longestLeg,row.longestLeg);
  }

  const start=allPoints[0]||null,end=allPoints.at(-1)||null;
  const straight=start&&end?haversine(start,end):0;
  const missionCount=Math.max(1,missions.length);
  const mappedMissionCount=withRoute.length;
  const coverage=missions.length?Math.round(mappedMissionCount/missions.length*100):0;

  return {
    bgMeters,routeMeters,transitionMeters,geometricMeters,
    points:allPoints.length,uniquePlaces,repeated,
    avgMission:routeMeters/missionCount,
    longestMission,longestLeg,longestTransition,
    straight,coverage,mappedMissionCount,totalMissions:missions.length,
    missionRows
  };
}
function bannerWalkSignature(detail){
  const rows=bannerRouteRows(detail);
  return JSON.stringify(rows.flatMap(r=>r.route.map(p=>[
    r.index,
    Number(p.latitude).toFixed(6),
    Number(p.longitude).toFixed(6)
  ])));
}
function bannerWalkCacheKey(detail){
  const id=String(detail?.id??detail?.bannerId??'unknown').replace(/[^a-zA-Z0-9_.:-]/g,'_');
  return `${BANNER_WALK_CACHE_PREFIX}${id}`;
}
function loadBannerWalkCache(detail){
  try{
    const x=JSON.parse(localStorage.getItem(bannerWalkCacheKey(detail))||'null');
    if(x?.sig===bannerWalkSignature(detail)&&x?.walking)return x.walking;
  }catch{}
  return null;
}
function saveBannerWalkCache(detail,walking){
  try{
    localStorage.setItem(bannerWalkCacheKey(detail),JSON.stringify({
      sig:bannerWalkSignature(detail),
      walking,
      at:Date.now()
    }));
  }catch{}
}
async function fetchValhallaWalkingChunk(chunk){
  const lang=APP_LANG==='en'?'en-US':APP_LANG==='es'?'es-ES':'fr-FR';
  const body={
    locations:chunk.map(x=>({
      lat:Number(x.point.latitude),
      lon:Number(x.point.longitude),
      type:'break'
    })),
    costing:'pedestrian',
    units:'kilometers',
    directions_options:{units:'kilometers',language:lang}
  };

  let data,status=0,transport='web';

  if(Capacitor.isNativePlatform()){
    transport='native';
    const response=await CapacitorHttp.post({
      url:VALHALLA_API,
      headers:{
        'Content-Type':'application/json',
        'Accept':'application/json',
        'X-Client-Id':'redacted-bannerlab'
      },
      data:body,
      connectTimeout:18000,
      readTimeout:18000,
      responseType:'json'
    });
    status=Number(response?.status)||0;
    data=response?.data;
    if(typeof data==='string'){
      try{data=JSON.parse(data)}catch{}
    }
  }else{
    // Browser/web fallback. GET with encoded json stays a simple request
    // and avoids the JSON POST preflight that can be blocked by CORS.
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),18000);
    try{
      const url=`${VALHALLA_API}?json=${encodeURIComponent(JSON.stringify(body))}`;
      const response=await fetch(url,{
        method:'GET',
        headers:{'Accept':'application/json'},
        signal:ctrl.signal
      });
      status=response.status;
      if(response.ok)data=await response.json();
      else{
        let msg='';
        try{msg=await response.text()}catch{}
        throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg.slice(0,120)}`:''}`);
      }
    }finally{
      clearTimeout(timer);
    }
  }

  if(status<200||status>=300){
    const msg=data?.error||data?.error_code||data?.status_message||'';
    throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg}`:''}`);
  }

  const legs=data?.trip?.legs||[];
  if(legs.length!==Math.max(0,chunk.length-1)){
    const msg=data?.error||data?.status_message||'incomplete route';
    throw new Error(`Valhalla ${msg} · ${legs.length}/${Math.max(0,chunk.length-1)} legs`);
  }

  return legs.map(leg=>({
    meters:(Number(leg?.summary?.length)||0)*1000,
    seconds:Number(leg?.summary?.time)||0,
    transport
  }));
}
async function calculateBannerWalkingStats(detail,{force=false}={}){
  const direct=bannerFunStats(detail);
  const flat=[];
  direct.missionRows.forEach(row=>{
    row.route.forEach((point,pointIndex)=>flat.push({
      point,
      missionIndex:row.index,
      pointIndex,
      title:point?.title||row.title||`M${row.index+1}`
    }));
  });
  if(flat.length<2)throw new Error('Not enough mapped points');

  if(!force){
    const cached=loadBannerWalkCache(detail);
    if(cached)return {...cached,cached:true};
  }

  const missionMeters=Array.from({length:direct.totalMissions},()=>0);
  const missionSeconds=Array.from({length:direct.totalMissions},()=>0);
  let totalMeters=0,totalSeconds=0,transitionMeters=0,transitionSeconds=0;
  let rawValhallaMeters=0,rawValhallaSeconds=0;
  let correctedLegs=0,tooShortLegs=0,absurdDetourLegs=0;
  let longestLegMeters=0,longestLegNames=null;
  let transport=Capacitor.isNativePlatform()?'native':'web';

  let cursor=0;
  while(cursor<flat.length-1){
    const end=Math.min(flat.length,cursor+VALHALLA_MAX_POINTS);
    const chunk=flat.slice(cursor,end);
    const legs=await fetchValhallaWalkingChunk(chunk);
    if(legs[0]?.transport)transport=legs[0].transport;

    legs.forEach((leg,i)=>{
      const a=chunk[i],b=chunk[i+1];
      const directMeters=haversine(a.point,b.point);
      const rawMeters=Math.max(0,Number(leg.meters)||0);
      const rawSeconds=Math.max(0,Number(leg.seconds)||0);

      rawValhallaMeters+=rawMeters;
      rawValhallaSeconds+=rawSeconds;

      let acceptedMeters=rawMeters;
      let acceptedSeconds=rawSeconds;

      // Same portal / nearly identical coordinate: no meaningful walking.
      if(directMeters<3){
        acceptedMeters=0;
        acceptedSeconds=0;
        if(rawMeters>15)correctedLegs++;
      }else{
        // A pedestrian-network route cannot realistically be much shorter
        // than straight-line centre-to-centre distance. This catches bad
        // snapping/correlation shortcuts.
        const impossibleShortcut=rawMeters < directMeters*0.88;

        // Catch isolated OSM/Valhalla detours without throwing away the whole
        // banner. The additive allowance is important for rivers, stations,
        // parks and other genuine obstacles.
        const maxPlausible=Math.max(directMeters*4,directMeters+350);
        const absurdDetour=rawMeters > maxPlausible;

        if(impossibleShortcut || absurdDetour || !rawMeters){
          acceptedMeters=directMeters;
          acceptedSeconds=(directMeters/4800)*3600;
          correctedLegs++;
          if(impossibleShortcut)tooShortLegs++;
          if(absurdDetour)absurdDetourLegs++;
        }
      }

      totalMeters+=acceptedMeters;
      totalSeconds+=acceptedSeconds;

      if(a.missionIndex===b.missionIndex){
        missionMeters[a.missionIndex]=(missionMeters[a.missionIndex]||0)+acceptedMeters;
        missionSeconds[a.missionIndex]=(missionSeconds[a.missionIndex]||0)+acceptedSeconds;
      }else{
        transitionMeters+=acceptedMeters;
        transitionSeconds+=acceptedSeconds;
      }

      if(acceptedMeters>longestLegMeters){
        longestLegMeters=acceptedMeters;
        longestLegNames=[a.title||'Portal',b.title||'Portal'];
      }
    });

    if(end>=flat.length)break;
    cursor=end-1;
    await new Promise(r=>setTimeout(r,160));
  }

  let longestMission=null;
  missionMeters.forEach((meters,index)=>{
    if(meters>0&&(!longestMission||meters>longestMission.meters)){
      longestMission={index,meters,seconds:missionSeconds[index]||0};
    }
  });

  const walking={
    totalMeters,totalSeconds,
    transitionMeters,transitionSeconds,
    missionMeters,missionSeconds,
    longestLegMeters,longestLegNames,longestMission,
    rawValhallaMeters,rawValhallaSeconds,
    correctedLegs,tooShortLegs,absurdDetourLegs,
    source:'valhalla-sanitized',
    transport
  };
  saveBannerWalkCache(detail,walking);
  return walking;
}
function bannerFunStatsHtml(detail,{compact=false,walking=null,routingError=false,loading=false}={}){
  const s=bannerFunStats(detail);
  if(!s.points&&!s.bgMeters)return `<div class="bannerStatsUnavailable">${tr('statsUnavailable')}</div>`;

  const effectiveMeters=walking?.totalMeters||s.geometricMeters||s.bgMeters;
  const effectiveSeconds=walking?.totalSeconds||0;
  const directKmBase=s.geometricMeters;
  const networkDetour=walking&&directKmBase>0?walking.totalMeters/directKmBase:null;

  const longestMission=walking?.longestMission?.meters>0
    ? `${tr('missionShort',{n:walking.longestMission.index+1})} · ${formatBannerMeters(walking.longestMission.meters)}`
    : s.longestMission&&s.longestMission.meters>0
      ? `${tr('missionShort',{n:s.longestMission.index+1})} · ${formatBannerMeters(s.longestMission.meters)}`
      : '—';

  const avgMission=walking?.missionMeters?.length
    ? walking.missionMeters.reduce((a,b)=>a+(Number(b)||0),0)/Math.max(1,s.totalMissions)
    : s.avgMission;

  const longestLeg=walking?.longestLegMeters||s.longestLeg;
  const between=walking?.transitionMeters??s.transitionMeters;
  const stepsPerKm=effectiveMeters>0?s.points/(effectiveMeters/1000):0;

  const items=[
    [tr('bgDistance'),formatBannerDistance(s.bgMeters),'🛣'],
    [tr('calculatedTrack'),loading?'…':formatBannerMeters(walking?.totalMeters||s.geometricMeters),'🚶'],
    [tr('walkingEstimate'),loading?'…':(walking?formatWalkSeconds(effectiveSeconds):formatWalkEstimate(effectiveMeters)),'⏱'],
    [tr('directGeometric'),formatBannerMeters(s.geometricMeters),'〰'],
    [tr('routeSteps'),String(s.points),'◉'],
    [tr('uniquePlaces'),String(s.uniquePlaces),'⌖'],
    [tr('revisitedPlaces'),String(s.repeated),'↻'],
    [tr('stepsPerKm'),stepsPerKm?String(stepsPerKm.toFixed(1)).replace('.',','):'—','⋮'],
    [tr('avgMissionDistance'),formatBannerMeters(avgMission),'÷'],
    [tr('longestMission'),longestMission,'🏆'],
    [tr('longestLeg'),formatBannerMeters(longestLeg),'↔'],
    [tr('betweenMissions'),formatBannerMeters(between),'⇢'],
    [tr('routingDetour'),networkDetour?tr('xFactor',{n:networkDetour.toFixed(2).replace('.',',')}):'—','🌀'],
    [tr('straightLine'),formatBannerMeters(s.straight),'⌁'],
    [tr('routeCoverage'),`${s.coverage} %`,'◫'],
    [tr('correctedLegs'),walking?`${walking.correctedLegs||0}`:'—','⚙'],
    [tr('rawValhalla'),walking?formatBannerMeters(walking.rawValhallaMeters):'—','V'],
    [tr('routingSource'),walking
      ?(walking.transport==='native'?tr('routingNative'):tr('routingWeb'))
      :(routingError?tr('routingFallback'):tr('routingLoading')),'OSM']
  ];

  const shown=compact
    ? [items[0],items[1],items[2],items[7],items[9],items[15]]
    : items;

  return `<div class="bannerFunStats ${compact?'compact':''} ${walking?'walkRouted':''}">
    <div class="bannerFunStatsTitle"><span>📊</span><b>${tr('uselessStats')}</b>${walking?.cached?'<em>cache</em>':''}</div>
    <div class="bannerFunStatsGrid">${shown.map(([label,value,ico])=>`<div><i>${ico}</i><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>
    ${routingError?`<div class="bannerRoutingWarn">${tr('routingFailed')}${typeof routingError==='string'?`<small>${escapeHtml(tr('routingErrorDetail',{error:routingError}))}</small>`:''}</div>`:''}
    ${compact?'':`<small>${tr('funStatsDisclaimer')}</small>`}
  </div>`;
}
async function renderBannerWalkingStats(panel,detail,{compact=false}={}){
  if(!panel)return;
  panel.innerHTML=bannerFunStatsHtml(detail,{compact,loading:true});
  try{
    const walking=await calculateBannerWalkingStats(detail);
    panel.innerHTML=bannerFunStatsHtml(detail,{compact,walking});
    return walking;
  }catch(e){
    console.warn('[Banner walking stats]',e);
    panel.innerHTML=bannerFunStatsHtml(detail,{
      compact,
      routingError:String(e?.message||e||'unknown error')
    });
    return null;
  }
}
async function toggleSearchBannerStats(button,summary){
  const wrap=button.closest('.bannergressCardWrap');
  const panel=wrap?.querySelector('.bannerSearchStats');
  if(!panel)return;
  const opening=panel.hidden;
  if(!opening){
    panel.hidden=true;
    button.textContent=tr('showUselessStats');
    return;
  }
  panel.hidden=false;
  button.disabled=true;
  button.textContent=tr('routingLoading');
  panel.innerHTML=`<div class="loadingInline">${tr('routingLoading')}</div>`;
  try{
    const detail=await fetchBannerDetail(summary);
    await renderBannerWalkingStats(panel,detail,{compact:true});
    button.textContent=tr('hideUselessStats');
  }catch(e){
    panel.innerHTML=`<div class="bannerStatsUnavailable">${escapeHtml(tr('bannerLoadError',{error:e?.message||e}))}</div>`;
    button.textContent=tr('showUselessStats');
  }finally{
    button.disabled=false;
  }
}
function bindBannerList(container,list,onOpen){
  $$('.bannergressCard',container).forEach(btn=>{
    btn.onclick=()=>{
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerId));
      if(b)(onOpen||openBannerDetail)(b);
    };
  });
  $$('.bannerStatsBtn',container).forEach(btn=>{
    btn.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerStatsId));
      if(b)toggleSearchBannerStats(btn,b);
    };
  });
}
function unwrapBannerSearch(raw){
  if(Array.isArray(raw))return raw;
  for(const candidate of [raw?.items,raw?.banners,raw?.results,raw?.data]){
    if(Array.isArray(candidate))return candidate;
    if(candidate&&typeof candidate==='object'){
      for(const key of ['banners','items','results'])if(Array.isArray(candidate[key]))return candidate[key];
    }
  }
  return [];
}
function normalizeGeoPoint(p){
  if(!p)return null;
  const lat=Number(p.latitude??p.lat??p.location?.latitude??p.location?.lat);
  const lng=Number(p.longitude??p.lng??p.lon??p.location?.longitude??p.location?.lng??p.location?.lon);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  return {latitude:lat,longitude:lng,title:String(p.title??p.name??p.portalTitle??'')};
}
function normalizeMissionList(raw){
  let list=raw?.items?.missions??raw?.missions??raw?.banner?.items?.missions??raw?.banner?.missions??[];
  if(!Array.isArray(list)&&list&&typeof list==='object')list=Object.values(list);
  if(!Array.isArray(list))return [];
  const normalized=list.map((m,i)=>{
    let steps=m?.steps??m?.waypoints??m?.points??[];
    if(!Array.isArray(steps)&&steps&&typeof steps==='object')steps=Object.values(steps);
    const route=(Array.isArray(steps)?steps:[]).map(s=>normalizeGeoPoint(s?.poi??s?.portal??s?.point??s)).filter(Boolean);
    const direct=normalizeGeoPoint(m?.startPoint??m?.startPoi??m?.poi);
    if(!route.length&&direct)route.push(direct);
    return {
      id:String(m?.id??m?.missionId??m?.guid??'').trim(),
      title:String(m?.title??m?.name??m?.missionTitle??`Mission ${i+1}`),
      order:Number(m?.order??m?.sequence??m?.position??m?.index??i),route
    };
  }).filter(m=>m.id);
  if(normalized.every(x=>Number.isFinite(x.order)))normalized.sort((a,b)=>a.order-b.order);
  return normalized.map(({id,title,route})=>({id,title,route}));
}
function normalizeBannerDetail(raw,fallback={}){
  const b=raw?.banner??raw?.item??raw?.data?.banner??raw?.data??raw??{};
  const source={...fallback,...b};
  const missions=normalizeMissionList(raw);
  return {
    id:String(source.id??fallback.id??''),
    title:String(source.title??fallback.title??tr('unnamed')),
    formattedAddress:String(source.formattedAddress??source.address??fallback.formattedAddress??''),
    lengthMeters:Number(source.lengthMeters??fallback.lengthMeters??0)||0,
    numberOfMissions:Number(source.numberOfMissions??missions.length??fallback.numberOfMissions??0)||missions.length,
    numberOfDisabledMissions:Number(source.numberOfDisabledMissions??fallback.numberOfDisabledMissions??0)||0,
    picture:String(source.picture??fallback.picture??''),
    author:String(source.author??source.authorName??source.creator?.name??source.agent?.name??fallback.author??''),
    startPoint:normalizeGeoPoint(source.startPoint??source.startPoi??source.startLocation??fallback.startPoint),
    missions
  };
}
async function fetchBannerDetail(summary){
  if(summary?.missions?.length&&summary.missions.some(m=>m?.route?.length))return summary;
  const r=await fetch(`${BANNERGRESS_API}/bnrs/${encodeURIComponent(summary.id??summary.bannerId)}`,{headers:{Accept:'application/json'}});
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return normalizeBannerDetail(await r.json(),summary);
}
function ingressMissionUrl(id){
  const intel=`https://intel.ingress.com/mission/${id}`;
  const p=new URLSearchParams({link:intel,apn:'com.nianticproject.ingress',isi:'576505181',ibi:'com.google.ingress',ifl:'https://apps.apple.com/app/ingress/id576505181',ofl:intel});
  return `https://link.ingress.com/?${p.toString()}`;
}
async function openIngressMission(id){
  if(!id)return;
  const url=ingressMissionUrl(id);
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:url,packageName:'com.nianticproject.ingress'});
    else await AppLauncher.openUrl({url});
  }catch{
    try{await AppLauncher.openUrl({url})}catch(e){console.warn('Ingress deeplink',e)}
  }
}
function savePlaySession(session){localStorage.setItem(PLAY_SESSION_KEY,JSON.stringify(session))}
function loadPlaySession(){try{return JSON.parse(localStorage.getItem(PLAY_SESSION_KEY)||'null')}catch{return null}}
async function overlayState(){
  if(!Capacitor.isNativePlatform())return {active:false,currentIndex:loadPlaySession()?.currentIndex||0,total:loadPlaySession()?.missions?.length||0,doneJson:'[]'};
  try{return await MissionOverlay.getState()}catch(e){console.warn('overlay state',e);return {active:false}}
}
function bannerStartPoint(detail){
  for(const m of detail?.missions||[])if(m?.route?.length)return m.route[0];
  return normalizeGeoPoint(detail?.startPoint);
}
function bannerRoutePoints(detail){
  const out=[];(detail?.missions||[]).forEach((m,mi)=>(m.route||[]).forEach((p,pi)=>out.push({...p,missionIndex:mi,pointIndex:pi})));
  return out;
}
function rblGroupLink(detail,index=0){
  const id=String(detail?.id??detail?.bannerId??'');
  return `redactedbannerlab://play?banner=${encodeURIComponent(id)}&mission=${Math.max(0,Number(index)||0)}`;
}
function bannergressBannerUrl(detail){return `https://bannergress.com/banner/${encodeURIComponent(String(detail?.id??detail?.bannerId??''))}`}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);return true}catch{return false}
}
async function openGroupShareSheet(detail,index=0){
  const link=rblGroupLink(detail,index),web=bannergressBannerUrl(detail);
  let qr='';try{qr=await QRCode.toDataURL(link,{width:420,margin:1,color:{dark:'#06140b',light:'#ffffff'}})}catch(e){console.warn('QR',e)}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('shareGroup')}</h2><p>${tr('shareIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="groupShareCard">${qr?`<img class="groupQr" src="${qr}" alt="QR">`:''}<b>${escapeHtml(detail?.title||tr('unnamed'))}</b><span>${tr('missionStart',{n:Number(index)+1})}</span></div>
    <div class="shareLinkBox"><code>${escapeHtml(link)}</code></div>
    <div class="actions"><button class="secondary copygroup">${tr('copyLink')}</button><button class="primary sharegroup">${tr('shareNow')}</button></div>
    <div class="actions"><button class="secondary openbg">${tr('bannergressPage')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('groupNoServer')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.copygroup',sh).onclick=async()=>{if(await copyText(link))toast(tr('linkCopied'))};
  $('.sharegroup',sh).onclick=async()=>{
    const text=`${detail?.title||'RBL'} · ${tr('missionStart',{n:Number(index)+1})}\n${link}\n${web}`;
    try{await Share.share({title:detail?.title||'Redacted BannerLab',text,dialogTitle:tr('shareGroup')})}catch(e){console.warn('share group',e)}
  };
  $('.openbg',sh).onclick=()=>AppLauncher.openUrl({url:web});
}
async function navigateToBannerStart(detail){
  const p=bannerStartPoint(detail);if(!p){toast(tr('startUnavailable'));return}
  const dest=`${p.latitude},${p.longitude}`;
  const web=`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=walking`;
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:web,packageName:'com.google.android.apps.maps'});
    else await AppLauncher.openUrl({url:web});
  }catch{try{await AppLauncher.openUrl({url:web})}catch(e){console.warn('maps',e)}}
}
function missionMapIcon(n,isStart=false){return L.divIcon({className:'rblLeafletIcon',html:`<span class="${isStart?'start':''}">${isStart?'▶':n}</span>`,iconSize:[30,30],iconAnchor:[15,15]})}
async function openBannerMap(detail){
  const points=bannerRoutePoints(detail);const start=bannerStartPoint(detail);
  if(!points.length&&!start){toast(tr('mapUnavailable'));return}
  const mapId=`rblMap_${Date.now().toString(36)}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('bannerMap')}</h2><p>${escapeHtml(detail.title||'')} · ${tr('routePoints',{n:points.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="bannerMapCanvas" id="${mapId}"></div>
    <div class="actions"><button class="primary navstart">📍 ${tr('navigateStart')}</button><button class="secondary sharemap">${tr('shareGroup')}</button></div>`);
  let map=null;
  const close=()=>{try{map?.remove()}catch{}closeSheet()};
  $('.close',sh).onclick=close;$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharemap',sh).onclick=()=>openGroupShareSheet(detail,0);
  await new Promise(r=>setTimeout(r,80));
  const el=document.getElementById(mapId);if(!el)return;
  map=L.map(el,{zoomControl:true,attributionControl:true});
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
  const bounds=[];
  (detail.missions||[]).forEach((m,mi)=>{
    const route=m.route||[];if(!route.length)return;
    const latlngs=route.map(p=>[p.latitude,p.longitude]);bounds.push(...latlngs);
    if(latlngs.length>1)L.polyline(latlngs,{color:'#31ed83',weight:4,opacity:.8}).addTo(map);
    L.marker(latlngs[0],{icon:missionMapIcon(mi+1,mi===0)}).addTo(map).bindPopup(`${mi===0?tr('startPoint')+' · ':''}${escapeHtml(m.title||tr('missionStart',{n:mi+1}))}`);
  });
  if(!bounds.length&&start)bounds.push([start.latitude,start.longitude]);
  if(bounds.length===1)map.setView(bounds[0],16);else map.fitBounds(bounds,{padding:[24,24]});
  setTimeout(()=>map.invalidateSize(),100);
}
async function joinSharedBanner(id,index=0){
  try{
    const detail=await fetchBannerDetail({id:String(id)});const i=clamp(Number(index)||0,0,Math.max(0,detail.missions.length-1));
    toast(tr('sharedBannerLoaded',{n:i+1}));openBannerDetail(detail,{startIndex:i,fromShare:true});
  }catch(e){toast(tr('sharedBannerError',{error:e?.message||e}))}
}
async function startPlaySession(detail,index=0){
  if(!detail?.missions?.length){toast(tr('bannerOffline'));return}
  const bannerId=String(detail.id??detail.bannerId??'');
  const previous=loadPlaySession();const same=String(previous?.bannerId||'')===bannerId;
  const session={format:'redacted-bannerlab-play-session',version:2,bannerId,title:detail.title,address:detail.formattedAddress??detail.address??'',picture:detail.picture||'',author:detail.author||'',lengthMeters:Number(detail.lengthMeters||0)||0,currentIndex:clamp(index,0,detail.missions.length-1),startedAt:same&&previous?.startedAt?previous.startedAt:Date.now(),missions:detail.missions};
  savePlaySession(session);upsertPlayHistory(session,{currentIndex:session.currentIndex,doneCount:same?Number(loadPlayHistory().find(x=>String(x.bannerId)===String(detail.id))?.doneCount||0):0,startedAt:session.startedAt});
  if(!Capacitor.isNativePlatform()){
    await openIngressMission(session.missions[session.currentIndex].id);return;
  }
  try{
    const p=await MissionOverlay.hasPermission();
    if(!p?.granted){
      localStorage.setItem(PLAY_PENDING_KEY,JSON.stringify(session));
      openOverlayPermissionSheet();return;
    }
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions[session.currentIndex].id),180);
  }catch(e){console.error(e);toast(tr('overlayFailed',{error:e?.message||e}))}
}
function openOverlayPermissionSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('overlayPermissionTitle')}</h2><p>${tr('overlayPermissionText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>Redacted Overlay</b><span>${tr('deepLinkOnly')}</span></div></div>
    <div class="actions"><button class="primary allowoverlay">${tr('overlayPermissionButton')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('overlayPermissionWaiting')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.allowoverlay',sh).onclick=async()=>{try{await MissionOverlay.requestPermission();toast(tr('overlayPermissionWaiting'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
}
async function resumePendingPlayOverlay(){
  if(!Capacitor.isNativePlatform())return;
  const raw=localStorage.getItem(PLAY_PENDING_KEY);if(!raw)return;
  try{
    const p=await MissionOverlay.hasPermission();if(!p?.granted)return;
    const session=JSON.parse(raw);
    await MissionOverlay.start({sessionJson:JSON.stringify(session)});
    localStorage.removeItem(PLAY_PENDING_KEY);
    closeSheet();toast(tr('overlayStarted'));
    setTimeout(()=>openIngressMission(session.missions?.[session.currentIndex||0]?.id),180);
  }catch(e){console.warn('pending overlay',e)}
}
async function stopPlayOverlay(){
  const session=loadPlaySession();let native={};try{native=await overlayState()}catch{}
  if(session){let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}upsertPlayHistory(session,{currentIndex:Number(native?.currentIndex??session.currentIndex??0),doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});}
  try{if(Capacitor.isNativePlatform())await MissionOverlay.stop()}catch(e){console.warn(e)}
  localStorage.removeItem(PLAY_SESSION_KEY);localStorage.removeItem(PLAY_PENDING_KEY);toast(tr('stopBanner'));
}
function bannerCardHtml(b){
  const img=bannergressImage(b.picture||'');
  const fav=isBannerFavorite(b.id);
  const id=escapeAttr(String(b.id));
  return `<div class="bannergressCardWrap">
    <button class="bannergressCard" data-banner-id="${id}">
      <span class="bannerPic">${img?`<img src="${escapeAttr(img)}" alt="">`:'<span>🐊</span>'}</span>
      <span class="bannerCardCopy"><b>${escapeHtml(b.title||tr('unnamed'))}</b><small>${escapeHtml(b.formattedAddress||tr('addressUnknown'))}</small>${b.author?`<small class="bannerAuthorLine">${escapeHtml(tr('bannerAuthor',{author:b.author}))}</small>`:''}<em>${tr('missionsCount',{n:b.numberOfMissions||0})} · ${formatBannerDistance(b.lengthMeters)}</em></span>
      <span class="bannerFavState">${fav?'★':'›'}</span>
    </button>
    <button class="bannerStatsBtn" data-banner-stats-id="${id}">${tr('showUselessStats')}</button>
    <div class="bannerSearchStats" hidden></div>
  </div>`;
}
async function openBannerDetail(summary,opts={}){
  let detail=summary;
  try{detail=await fetchBannerDetail(summary)}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}));return}
  const fav=isBannerFavorite(detail.id),todo=isBannerTodo(detail.id),img=bannergressImage(detail.picture);
  const startIndex=clamp(Number(opts.startIndex)||0,0,Math.max(0,detail.missions.length-1));const hasMap=!!bannerStartPoint(detail);
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(detail.title)}</h2><p>${escapeHtml(detail.formattedAddress||tr('addressUnknown'))}${detail.author?` · ${escapeHtml(tr('bannerAuthor',{author:detail.author}))}`:''}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${opts.fromShare?`<div class="groupJoinNotice">🐊 <b>${tr('joinAtMission',{n:startIndex+1})}</b><span>${tr('groupNoServer')}</span></div>`:''}
    <div class="bannerDetailHero">${img?`<img src="${escapeAttr(img)}" alt="">`:''}<div><b>${tr('missionsCount',{n:detail.missions.length||detail.numberOfMissions})}</b><span>${formatBannerDistance(detail.lengthMeters)}</span>${detail.numberOfDisabledMissions?`<small>${tr('bannerDisabled',{n:detail.numberOfDisabledMissions})}</small>`:''}</div></div>
    <div class="bannerDetailStats">${bannerFunStatsHtml(detail,{loading:true})}</div>
    <div class="actions"><button class="primary playbanner" ${detail.missions.length?'':'disabled'}>▶ ${opts.fromShare?tr('joinAtMission',{n:startIndex+1}):tr('playThisBanner')}</button></div>
    <div class="bannerUtilityGrid"><button class="secondary mapbanner" ${hasMap?'':'disabled'}>🗺 ${tr('openMap')}</button><button class="secondary navstart" ${hasMap?'':'disabled'}>📍 ${tr('navigateStart')}</button><button class="secondary sharebanner">▦ ${tr('shareGroup')}</button></div>
    <div class="bannerUtilityGrid two"><button class="secondary favbanner">${fav?'★ '+tr('removeFavorite'):'☆ '+tr('favorite')}</button><button class="secondary todobanner">${todo?'✓ '+tr('removeTodo'):'+ '+tr('addTodo')}</button></div>
    <div class="missionPreviewList">${detail.missions.slice(0,18).map((m,i)=>`<div class="${i===startIndex?'current':''}"><b>${String(i+1).padStart(2,'0')}</b><span>${escapeHtml(m.title)}</span></div>`).join('')}${detail.missions.length>18?`<small>+ ${detail.missions.length-18}</small>`:''}</div>
    <div class="rule"><span class="dot"></span><span>${tr('publicOnly')} · ${tr('deepLinkOnly')}</span></div>`);
  $('.close',sh).onclick=()=>openPlayHub(opts.returnTab||'search');
  $('.playbanner',sh).onclick=()=>startPlaySession(detail,startIndex);
  $('.mapbanner',sh).onclick=()=>openBannerMap(detail);$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharebanner',sh).onclick=()=>openGroupShareSheet(detail,startIndex);
  $('.favbanner',sh).onclick=()=>{if(isBannerFavorite(detail.id))unfavoriteBanner(detail.id);else favoriteBanner(detail);closeSheet();openBannerDetail(detail,{...opts})};
  $('.todobanner',sh).onclick=()=>{if(isBannerTodo(detail.id))removeBannerTodo(detail.id);else addBannerTodo(detail);closeSheet();openBannerDetail(detail,{...opts})};
  renderBannerWalkingStats($('.bannerDetailStats',sh),detail);
}


const BANNER_SEARCH_PREFS_KEY='rbl-bannergress-search-v2';
function loadBannerSearchPrefs(){try{return JSON.parse(localStorage.getItem(BANNER_SEARCH_PREFS_KEY)||'{}')||{}}catch{return{}}}
function saveBannerSearchPrefs(p){localStorage.setItem(BANNER_SEARCH_PREFS_KEY,JSON.stringify(p||{}))}
function normalizeTextMatch(v=''){return String(v).trim().toLocaleLowerCase()}
async function resolveBannergressPlace(city){
  const q=String(city||'').trim();if(!q)return null;
  const u=`${BANNERGRESS_API}/places?used=true&collapsePlaces=true&query=${encodeURIComponent(q)}&limit=40&offset=0`;
  const r=await fetch(u,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
  const list=await r.json();if(!Array.isArray(list)||!list.length)return null;
  const target=normalizeTextMatch(q);
  const score=p=>{
    const vals=[p?.shortName,p?.name,p?.formattedAddress,p?.title].filter(Boolean).map(normalizeTextMatch);
    if(vals.some(x=>x===target))return 0;
    if(vals.some(x=>x.startsWith(target)))return 1;
    if(vals.some(x=>x.includes(target)))return 2;
    return 3;
  };
  return [...list].sort((a,b)=>score(a)-score(b))[0]||null;
}
function getCurrentBannerPosition(){
  return new Promise((resolve,reject)=>{
    if(!navigator.geolocation){reject(new Error('géolocalisation indisponible'));return}
    navigator.geolocation.getCurrentPosition(
      p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy}),
      e=>reject(new Error(e?.message||`code ${e?.code||'?'}`)),
      {enableHighAccuracy:true,maximumAge:60000,timeout:10000}
    );
  });
}
function buildBannergressSearchUrl({query='',author='',placeId='',position=null}){
  const u=new URL(`${BANNERGRESS_API}/bnrs`);
  u.searchParams.set('online','true');u.searchParams.set('limit','80');u.searchParams.set('offset','0');
  if(query.trim())u.searchParams.set('query',query.trim());
  if(author.trim())u.searchParams.set('author',author.trim());
  if(placeId)u.searchParams.set('placeId',placeId);
  if(position){
    u.searchParams.set('orderBy','proximityStartPoint');u.searchParams.set('orderDirection','ASC');
    u.searchParams.set('proximityLatitude',String(position.latitude));u.searchParams.set('proximityLongitude',String(position.longitude));
  }else if(query.trim()){
    u.searchParams.set('orderBy','relevance');u.searchParams.set('orderDirection','DESC');
  }else{
    u.searchParams.set('orderBy','created');u.searchParams.set('orderDirection','DESC');
  }
  return u.toString();
}
function historyCardHtml(h){
  const total=Math.max(1,Number(h.total||h.numberOfMissions||1)),done=Math.min(total,Number(h.doneCount||0));const complete=done>=total;
  return `<button class="playHistoryCard" data-history-id="${escapeAttr(String(h.bannerId))}"><span class="historyState">${complete?'✓':'▶'}</span><span><b>${escapeHtml(h.title||tr('unnamed'))}</b><small>${formatPlayDate(h.startedAt)} · ${done}/${total}</small><em>${formatPlayDuration(activeDurationMs(h))} · ~${formatBannerDistance(estimatedPlayedMeters(h))}</em></span><strong>${complete?tr('completedBanner'):tr('resumeFromHistory')}</strong></button>`;
}
async function openHistoryBanner(h){
  try{const d=await fetchBannerDetail({id:h.bannerId,title:h.title,formattedAddress:h.formattedAddress,lengthMeters:h.lengthMeters,picture:h.picture,author:h.author,numberOfMissions:h.total});openBannerDetail(d,{startIndex:h.doneCount>=h.total?0:clamp(h.currentIndex,0,d.missions.length-1),returnTab:'history'})}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}))}
}
function playStatsHtml(entry){
  const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1)),done=Math.min(total,Number(entry?.doneCount||0));
  return `<div class="playStats"><b>${tr('playStats')}</b><div><span>${tr('startedAt')}</span><strong>${formatPlayDate(entry?.startedAt)}</strong></div><div><span>${tr('elapsed')}</span><strong>${formatPlayDuration(activeDurationMs(entry))}</strong></div><div><span>${tr('estimatedDistance')}</span><strong>~${formatBannerDistance(estimatedPlayedMeters(entry))}</strong></div><div><span>${tr('missionsDone')}</span><strong>${done}/${total}</strong></div>${entry?.finishedAt?`<div><span>${tr('finishedAt')}</span><strong>${formatPlayDate(entry.finishedAt)}</strong></div>`:''}</div>`;
}
async function renderPlayTab(sh,tab){
  const body=$('.playHubBody',sh);if(!body)return;
  if(tab==='todo'){
    const list=loadBannerTodo();body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">＋<b>${tr('noTodo')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b,{returnTab:'todo'}));return;
  }
  if(tab==='history'){
    const list=loadPlayHistory();body.innerHTML=list.length?`<div class="playHistoryList">${list.map(historyCardHtml).join('')}</div>`:`<div class="emptyPlayState">◷<b>${tr('noHistory')}</b></div>`;
    $$('.playHistoryCard',body).forEach(btn=>{btn.onclick=()=>{const h=list.find(x=>String(x.bannerId)===btn.dataset.historyId);if(h)openHistoryBanner(h)}});return;
  }
  if(tab==='favorites'){
    const list=loadBannerFavorites();
    body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">☆<b>${tr('noFavorites')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b));return;
  }
  if(tab==='current'){
    const session=loadPlaySession();const native=await overlayState();
    if(!session){body.innerHTML=`<div class="emptyPlayState">🐊<b>${tr('noPlaySession')}</b></div>`;return}
    let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}
    const index=clamp(Number(native?.currentIndex??session.currentIndex??0),0,Math.max(0,session.missions.length-1));
    const hist=upsertPlayHistory(session,{currentIndex:index,doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});
    body.innerHTML=`<div class="currentPlayCard"><div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt=""><div><b>${escapeHtml(session.title)}</b><span>${tr('doneMissions',{done:done.length,total:session.missions.length})}</span></div></div>
      <div class="currentMissionLine"><strong>${index+1}/${session.missions.length}</strong><span>${escapeHtml(session.missions[index]?.title||'Mission')}</span></div>
      ${playStatsHtml(hist)}
      <div class="actions"><button class="primary resumeplay">▶ ${tr('resumeBanner')}</button><button class="secondary opencurrent">${tr('openCurrentMission')}</button></div>
      <div class="bannerUtilityGrid"><button class="secondary currentmap">🗺 ${tr('openMap')}</button><button class="secondary currentnav">📍 ${tr('navigateStart')}</button><button class="secondary currentshare">▦ ${tr('shareProgress')}</button></div>
      <button class="danger stopplay">${tr('stopBanner')}</button></div>`;
    $('.resumeplay',body).onclick=()=>startPlaySession(session,index);
    $('.opencurrent',body).onclick=()=>openIngressMission(session.missions[index]?.id);
    $('.currentmap',body).onclick=()=>openBannerMap({...session,id:session.bannerId,formattedAddress:session.address});
    $('.currentnav',body).onclick=()=>navigateToBannerStart({...session,id:session.bannerId});
    $('.currentshare',body).onclick=()=>openGroupShareSheet({...session,id:session.bannerId},index);
    $('.stopplay',body).onclick=async()=>{await stopPlayOverlay();openPlayHub('current')};return;
  }

  const prefs=loadBannerSearchPrefs();
  let nearMe=!!prefs.nearMe;
  let position=null;
  body.innerHTML=`<div class="bannerSearchBox bannerSearchAdvanced">
      <div class="bannerSearchHeading"><div><b>${tr('searchBannergress')}</b><span>${tr('searchPrompt')}</span></div><span>BG</span></div>
      <div class="field bannerSearchField"><label>${tr('bannerNameSearch')}</label><input class="bannerNameInput" placeholder="${escapeAttr(tr('searchPlaceholder'))}" value="${escapeAttr(prefs.query||'')}"></div>
      <div class="bannerSearchGrid">
        <div class="field bannerSearchField"><label>${tr('citySearch')}</label><input class="bannerCityInput" placeholder="${escapeAttr(tr('cityPlaceholder'))}" value="${escapeAttr(prefs.city||'')}" ${nearMe?'disabled':''}></div>
        <div class="field bannerSearchField"><label>${tr('authorSearch')}</label><input class="bannerAuthorInput" placeholder="${escapeAttr(tr('authorPlaceholder'))}" value="${escapeAttr(prefs.author||'')}"></div>
      </div>
      <button class="nearMeButton ${nearMe?'on':''}" type="button">📍 <span>${nearMe?tr('nearMeOn'):tr('nearMe')}</span></button>
      <small class="nearMeHelp">${tr('nearMeHint')}</small>
      <div class="bannerSearchActions"><button class="secondary bannerSearchReset">${tr('searchReset')}</button><button class="primary bannerSearchBtn">${icon('search')} ${tr('search')}</button></div>
      <div class="bannerSearchStatus"></div>
    </div><div class="bannerSearchResults"></div>`;

  const qInput=$('.bannerNameInput',body),cityInput=$('.bannerCityInput',body),authorInput=$('.bannerAuthorInput',body);
  const nearBtn=$('.nearMeButton',body),status=$('.bannerSearchStatus',body),results=$('.bannerSearchResults',body);
  const setStatus=(txt,cls='')=>{status.textContent=txt||'';status.className='bannerSearchStatus '+cls};
  const savePrefs=()=>saveBannerSearchPrefs({query:qInput.value,city:cityInput.value,author:authorInput.value,nearMe});

  const toggleNear=async()=>{
    nearMe=!nearMe;position=null;cityInput.disabled=nearMe;nearBtn.classList.toggle('on',nearMe);
    $('span',nearBtn).textContent=nearMe?tr('nearMeOn'):tr('nearMe');savePrefs();
    if(nearMe){
      setStatus(tr('locationGetting'),'loading');
      try{position=await getCurrentBannerPosition();setStatus(tr('locationReady'),'ok')}
      catch(e){nearMe=false;cityInput.disabled=false;nearBtn.classList.remove('on');$('span',nearBtn).textContent=tr('nearMe');savePrefs();setStatus(tr('locationError',{error:e?.message||e}),'error')}
    }else setStatus('');
  };
  nearBtn.onclick=toggleNear;

  const run=async()=>{
    const query=qInput.value.trim(),city=cityInput.value.trim(),author=authorInput.value.trim();savePrefs();
    if(!query&&!city&&!author&&!nearMe){setStatus(tr('searchCriteriaRequired'),'error');results.innerHTML='';return}
    results.innerHTML=`<div class="loadingPlay">${tr('searching')}</div>`;setStatus('');
    try{
      let place=null;
      if(nearMe&&!position){setStatus(tr('locationGetting'),'loading');position=await getCurrentBannerPosition();setStatus(tr('locationReady'),'ok')}
      if(city&&!nearMe){
        setStatus(tr('cityResolving'),'loading');place=await resolveBannergressPlace(city);
        if(!place){results.innerHTML='';setStatus(tr('cityNotFound',{city}),'error');return}
        setStatus(tr('cityUsing',{city:place.shortName||place.name||city}),'ok');
      }
      const url=buildBannergressSearchUrl({query,author,placeId:place?.id||'',position:nearMe?position:null});
      const r=await fetch(url,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
      const list=unwrapBannerSearch(await r.json()).map(b=>normalizeBannerDetail(b,b));
      const filterBits=[];if(query)filterBits.push(`“${query}”`);if(city&&!nearMe)filterBits.push(place?.shortName||city);if(author)filterBits.push(`@${author}`);if(nearMe)filterBits.push('📍');
      setStatus(`${tr('resultsCount',{n:list.length})}${filterBits.length?' · '+filterBits.join(' · '):''}`,list.length?'ok':'');
      results.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">⌕<b>0</b></div>`;
      bindBannerList(results,list,b=>openBannerDetail(b));
    }catch(e){console.error(e);setStatus(tr('searchError',{error:e?.message||e}),'error');results.innerHTML=''}
  };
  $('.bannerSearchBtn',body).onclick=run;
  $('.bannerSearchReset',body).onclick=()=>{qInput.value='';cityInput.value='';authorInput.value='';nearMe=false;position=null;cityInput.disabled=false;nearBtn.classList.remove('on');$('span',nearBtn).textContent=tr('nearMe');savePrefs();setStatus('');results.innerHTML=''};
  [qInput,cityInput,authorInput].forEach(inp=>inp.addEventListener('keydown',e=>{if(e.key==='Enter')run()}));
  setTimeout(()=>qInput.focus(),80);
}
function openPlayHub(tab='search'){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('playHub')}</h2><p>${tr('publicOnly')} · ${tr('deepLinkOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playTabs"><button data-playtab="search" class="${tab==='search'?'on':''}">${icon('search')} ${tr('search')}</button><button data-playtab="todo" class="${tab==='todo'?'on':''}">＋ ${tr('todo')}</button><button data-playtab="favorites" class="${tab==='favorites'?'on':''}">${icon('star')} ${tr('favorites')}</button><button data-playtab="current" class="${tab==='current'?'on':''}">🐊 ${tr('inProgress')}</button><button data-playtab="history" class="${tab==='history'?'on':''}">◷ ${tr('history')}</button></div>
    <div class="playHubBody"></div>`);
  $('.close',sh).onclick=closeSheet;
  $$('[data-playtab]',sh).forEach(btn=>btn.onclick=()=>openPlayHub(btn.dataset.playtab));
  renderPlayTab(sh,tab);
}


function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast(tr('touchMissionFirst'));return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${n}</h2><p>${tr('missionCropOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>${tr('localZoom')} <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>${tr('rotation')} <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} ${tr('resetThisMission')}</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),tr('histMissionZoom'));
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),tr('histMissionRotation'));
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:');
  const baseScale=state.bg.image?Math.max(WORLD_W/state.bg.image.naturalWidth,worldH()/state.bg.image.naturalHeight):1;
  const zoomValue=Math.round((isText?o.scale:o.scale/baseScale)*100);
  const sh=openSheet(`<div class="sheethead"><div><h2>${isText?tr('transformText'):tr('frameImage')}</h2><p>${tr('pinchHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('zoom')}</label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>${tr('rotation')} <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">${tr('center')}</button><button class="secondary" id="resetBtn">${icon('reset')} ${tr('reset')}</button>${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),isText?tr('histTextRotation'):tr('histImageRotation'));
  $('#zoom',sh).oninput=e=>{if(isText)o.scale=+e.target.value/100;else if(state.bg.image)o.scale=baseScale*(+e.target.value/100);render();scheduleSave()};historyControl($('#zoom',sh),isText?tr('histTextZoom'):tr('histImageZoom'));
  $('#centerBtn',sh).onclick=()=>{const before=beginHistory();o.x=WORLD_W/2;o.y=worldH()/2;render();commitHistory(before,isText?tr('histCenterText'):tr('histCenterImage'));scheduleSave()};
  $('#resetBtn',sh).onclick=()=>{const before=beginHistory();if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else fitBackground();closeSheet();render();commitHistory(before,isText?tr('histResetText'):tr('histResetImage'));scheduleSave()};
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast(tr('selectMissionFirst'));return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="${tr('close')}">${icon('close')}</button>
      <div><strong id="missionEditorTitle">${tr('missions')} ${n}</strong><span>${tr('individualCrop')}</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="${tr('previewPrime')}">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>${tr('oneFinger')}</b> ${tr('move')} · <b>${tr('twoFingers')}</b> ${tr('zoomRotate')}</div>
    <section class="missioneditorcontrols">
      <div class="missionhistory"><button class="secondary undoActionBtn missionundo" disabled>↶ ${tr('undo')}</button><button class="secondary redoActionBtn missionredo" disabled>↷ ${tr('redo')}</button></div>
      <div class="missionnav">
        <button class="secondary missionprev">‹ ${tr('prev')}</button>
        <button class="secondary missionnext">${tr('next')} ›</button>
      </div>
      <div class="field"><label>${tr('zoom')} <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>${tr('rotation')} <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} ${tr('reset')}</button><button class="primary missiondone">${tr('done')}</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const before=beginHistory(),o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();commitHistory(before,tr('histResetMission'));scheduleSave();};
  $('.missionundo',back).onclick=undoAction;$('.missionredo',back).onclick=redoAction;
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorZoom',back),tr('histMissionZoom'));
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorRot',back),tr('histMissionRotation'));
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=`Mission ${n}`;
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0,historyBefore:beginHistory()};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){const before=missionEditorGesture?.historyBefore;missionEditorGesture=null;commitHistory(before,tr('histResetMission'));scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0],before=missionEditorGesture?.historyBefore;missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0,historyBefore:before};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  const before=beginHistory();
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();commitHistory(before,tr('histResetMission'));scheduleSave();toast(tr('missionResetDone',{n:missionNumber(rc.row,rc.col)}));
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  const before=beginHistory();
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();commitHistory(before,tr('histDeleteText'));scheduleSave();toast(tr('textDeleted'));
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('text')}</h2><p>${tr('textLayerDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('layer')}</label><select id="textLayer"><option value="new">${tr('newText')}</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);const box=$('#textEditor',sh);
    box.innerHTML=`<div class="field"><label>${tr('text')}</label><input id="txt" value="${escapeAttr(t?.text||'GREEN RILLETTES 7')}" maxlength="120"></div>
      <div class="grid2"><div class="field"><label>${tr('size')}</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>${tr('outline')}</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div></div>
      <div class="grid2"><div class="field"><label>${tr('color')}</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div><div class="field"><label>${tr('outlineColor')}</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?tr('update'):tr('add')}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`;
    $('#saveText',box).onclick=()=>{
      const before=beginHistory(),wasNew=!t;
      if(!t){t={id:uid(),text:$('#txt',box).value||tr('text'),x:WORLD_W/2,y:worldH()/2,fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,scale:1,rotation:0};state.texts.push(t)}
      else Object.assign(t,{text:$('#txt',box).value||tr('text'),fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0});
      setActive('text:'+t.id);commitHistory(before,wasNew?tr('histAddText'):tr('histEditText'));scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('previewPrime')}</h2><p>${tr('previewApplied')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">${tr('previewOrder')}</p>`);$('.close',sh).onclick=closeSheet;
  const grid=$('#previewGrid',sh);
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';const c=document.createElement('canvas');c.width=c.height=180;box.appendChild(c);const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);grid.appendChild(box);drawTile(c,r,col,180);
  }
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseBackground(cc);cc.restore();
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);drawOverlayWorld(cc);cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('exportTitle',{n:count})}</h2><p>${tr('exportIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!state.bg.image?`<div class="rule warning"><span class="dot"></span><span>${tr('noBackground')}</span></div>`:''}
    <div class="field"><label>${tr('missionFormat')}</label><select id="exportFormat"><option value="jpeg" selected>${tr('jpgFast')}</option><option value="png">${tr('pngLossless')}</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>${tr('fastEncoding')}</span></div><div class="rule"><span class="dot"></span><span>${tr('rowRender')}</span></div><div class="rule"><span class="dot"></span><span>${tr('adjusted',{n:adjusted})}</span></div><div class="rule warning"><span class="dot"></span><span>${tr('nianticCheck')}</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">${tr('ready')}</div>
    <div class="actions"><button class="primary" id="doExport" ${!state.bg.image?'disabled':''}>${tr('createZip')}</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseBackground(cc);drawOverlayWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent=tr('zipAssembly');bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`${tr('zipAssembly')} ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent=tr('zipCreated');
      await Share.share({title:'Export Redacted BannerLab',text:`${total} missions · ${state.name}`,url:uri.uri,dialogTitle:tr('saveShareZip')});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent=tr('zipDownloaded');
    }
    toast(tr('exportFinished',{format:jpeg?'JPG':'PNG'}));
  }catch(err){console.error(err);txt.textContent='Erreur : '+(err?.message||err);toast(tr('exportFailed'))}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}\n${state.name}\n${state.rows} rangée(s) · ${state.rows*6} missions\n\nOrdre de création :\n`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false);s+=`${String(n).padStart(3,'0')}.${ext} : rangée ${row+1} depuis le haut, colonne ${col+1} depuis la gauche${o&&!isIdentityOverride(o)?' · recadrage individuel':''}\n`}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('Canvas export impossible')),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const MIN_PORTALS_PER_MISSION=6;

const OBJECTIVE_LABELS={
  HACK_PORTAL:'hack',
  INSTALL_MOD:'mod',
  CAPTURE_PORTAL:'capture',
  CREATE_LINK:'link',
  CREATE_FIELD:'field',
  PASSPHRASE:'passphrase'
};
function objectiveLabel(type){return tr(OBJECTIVE_LABELS[type]||'hack')}
function missionSequential(m){return typeof m?.sequential==='boolean'?m.sequential:state.planner.sequential!==false}
function missionHidden(m){return missionSequential(m)&&(typeof m?.hiddenLocation==='boolean'?m.hiddenLocation:!!state.planner.hiddenLocation)}


function normalizePlanner(p={}){
  const planner={
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24),
    autoAdvance: p.autoAdvance!==false,
    reuseLastPortal: p.reuseLastPortal!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    sequential: typeof m.sequential==='boolean'?m.sequential:null,
    hiddenLocation: typeof m.hiddenLocation==='boolean'?m.hiddenLocation:null,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||tr('portalDefault')),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||tr('bannerDefault');
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function guidOccurrences(guid){
  const out=[];
  state.planner.missions.forEach((m,mi)=>(m.portals||[]).forEach((p,pi)=>{if(guid&&p.guid===guid)out.push({mi,pi})}));
  return out;
}
function isAllowedHandoverOccurrences(occ){
  if(occ.length!==2)return false;
  const [a,b]=occ;
  if(b.mi!==a.mi+1||b.pi!==0)return false;
  const prev=state.planner.missions[a.mi]?.portals||[];
  return a.pi===prev.length-1;
}
function duplicateGuidCount(){
  let bad=0;
  for(const m of state.planner.missions){
    const seen=new Set(),dupes=new Set();
    for(const p of (m.portals||[]))if(p.guid){if(seen.has(p.guid))dupes.add(p.guid);else seen.add(p.guid)}
    bad+=dupes.size;
  }
  return bad;
}
function canReuseAsHandover(portal,mi){
  if(!portal?.guid||mi<=0)return false;
  const cur=plannerMission(mi),prev=plannerMission(mi-1);
  return cur.portals.length===0&&prev?.portals?.at(-1)?.guid===portal.guid;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):tr('route');
  const badGuid=!p.guid,pass=p.objective?.type==='PASSPHRASE';
  const extra=pass&&p.objective?.passphrase_params?.question?` · ${escapeHtml(p.objective.passphrase_params.question)}`:'';
  return `<div class="portalrow portalrow-v2" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||tr('portalDefault'))}</strong><span>${dist}${badGuid?' · GUID ?':''}</span>
      <button class="portalactionbtn">${escapeHtml(objectiveLabel(p.objective?.type))}${extra}</button>
    </div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="↑">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="↓">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="×">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('route')} · ${tr('missions')} ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} ${tr('portalsPerMission').split(' / ')[0].toLowerCase()} · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ ${tr('prev')}</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>${tr('next')} ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?tr('complete'):tr('remaining',{n:Math.max(0,need-count)})}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion">
      <div class="iitccompanion-head"><img src="/redacted-logo-512.png" alt="Redacted"><div><b>IITC Companion</b><span>${tr('companionStats')}</span></div><span class="beta">${tr('pluginVersion')}</span></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('companionStats')}</b><small>${tr('companionStatsDesc')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('action')}</b><small>${tr('routeActionHelp')}</small></div></div>
      <div class="iitcfeatureline"><span>●</span><div><b>${tr('handoverOk')}</b><small>${tr('handoverDetail')}</small></div></div>
      <div class="actions companionactions"><button class="primary openintel">${icon('globe')} ${tr('openIitc')}</button><button class="secondary tutorialiitc">${icon('info')} ${tr('tutorial')}</button></div>
      <div class="actions companionsecondary"><button class="secondary sharebridge">${tr('installPlugin')}</button></div>
    </div>
    <div class="actions routeactions"><button class="secondary addportal">${icon('plus')} ${tr('addPortal')}</button></div>
    <div class="routeoptions">
      <label class="switchline"><input type="checkbox" id="autoAdvance" ${state.planner.autoAdvance?'checked':''}> ${tr('autoAdvance',{n:need})}</label>
      <label class="switchline"><input type="checkbox" id="reuseLastPortal" ${state.planner.reuseLastPortal?'checked':''}> ${tr('reuseLast')}</label>
    </div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${tr('duplicateBad',{n:dup})}</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):`<div class="emptyroute">${tr('noPortal')}</div>`}</div>
    <div class="actions"><button class="secondary carryprev" ${idx===0||!plannerMission(idx-1)?.portals?.length||m.portals.length?'disabled':''}>${tr('carryPrev')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('#autoAdvance',sh).onchange=e=>{state.planner.autoAdvance=e.target.checked;scheduleSave()};
  $('#reuseLastPortal',sh).onchange=e=>{state.planner.reuseLastPortal=e.target.checked;scheduleSave()};
  $('.openintel',sh).onclick=openIntel;
  $('.tutorialiitc',sh).onclick=openIitcTutorial;
  $('.addportal',sh).onclick=()=>openAddPortalSheet(idx);
  $('.carryprev',sh).onclick=()=>{const prev=plannerMission(idx-1)?.portals?.at(-1);if(prev){addPortalToMission(structuredClone(prev),idx,{handover:true});openRoutePlanner()}};
  $('.sharebridge',sh).onclick=shareIitcBridge;
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalactionbtn',row).onclick=()=>openPortalObjectiveSheet(idx,pi);
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();openRoutePlanner();
}
function removePortal(mi,pi){const m=plannerMission(mi);if(!m)return;m.portals.splice(pi,1);scheduleSave();openRoutePlanner()}

function openPortalObjectiveSheet(mi,pi){
  const m=plannerMission(mi),p=m?.portals?.[pi];if(!p)return;
  const options=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('action')}</h2><p>${escapeHtml(p.title)}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('action')}</label><select id="objectiveType">${options}</select></div>
    <div class="passphraseFields" ${p.objective?.type==='PASSPHRASE'?'':'hidden'}>
      <div class="field"><label>${tr('question')}</label><input id="passQuestion" value="${escapeAttr(p.objective?.passphrase_params?.question||'')}"></div>
      <div class="field"><label>${tr('answer')}</label><input id="passAnswer" value="${escapeAttr(p.objective?.passphrase_params?._single_passphrase||'')}"></div>
    </div>
    <div class="actions"><button class="secondary close2">${tr('cancel')}</button><button class="primary saveobj">${tr('save')}</button></div>`);
  const update=()=>$('.passphraseFields',sh).hidden=$('#objectiveType',sh).value!=='PASSPHRASE';
  $('#objectiveType',sh).onchange=update;
  $('.close',sh).onclick=closeSheet;$('.close2',sh).onclick=closeSheet;
  $('.saveobj',sh).onclick=()=>{
    p.objective.type=$('#objectiveType',sh).value;
    p.objective.passphrase_params.question=$('#passQuestion',sh)?.value?.trim()||'';
    p.objective.passphrase_params._single_passphrase=$('#passAnswer',sh)?.value?.trim()||'';
    scheduleSave();openRoutePlanner();
  };
}

function openAddPortalSheet(mi=state.planner.currentMission,prefill={}){
  const opts=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}">${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('addPortal')}</h2><p>${tr('missions')} ${mi+1}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>Lien Intel</label><input id="intelUrl" placeholder="https://intel.ingress.com/intel?...&pll=47.1,-1.6" value="${escapeAttr(prefill.url||'')}"></div>
    <div class="field"><label>Portail</label><input id="portalTitle" value="${escapeAttr(prefill.title||'')}"></div>
    <div class="field"><label>GUID</label><input id="portalGuid" value="${escapeAttr(prefill.guid||'')}"></div>
    <div class="grid2"><div class="field"><label>Latitude</label><input id="portalLat" inputmode="decimal" value="${escapeAttr(prefill.lat??'')}"></div><div class="field"><label>Longitude</label><input id="portalLng" inputmode="decimal" value="${escapeAttr(prefill.lng??'')}"></div></div>
    <div class="field"><label>${tr('action')}</label><select id="portalObjective">${opts}</select></div>
    <div class="passphraseFields" hidden><div class="field"><label>${tr('question')}</label><input id="portalQuestion"></div><div class="field"><label>${tr('answer')}</label><input id="portalAnswer"></div></div>
    <div class="actions"><button class="secondary parseintel">Lire le lien Intel</button><button class="primary saveportal">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#portalObjective',sh).onchange=()=>$('.passphraseFields',sh).hidden=$('#portalObjective',sh).value!=='PASSPHRASE';
  $('.parseintel',sh).onclick=()=>{const p=parseIntelUrl($('#intelUrl',sh).value);if(!p){toast(tr('coordsMissing'));return}$('#portalLat',sh).value=p.lat;$('#portalLng',sh).value=p.lng;};
  $('.saveportal',sh).onclick=()=>{
    const lat=parseFloat(String($('#portalLat',sh).value).replace(',','.')),lng=parseFloat(String($('#portalLng',sh).value).replace(',','.'));
    if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180){toast(tr('coordsInvalid'));return}
    const p=normalizePortal({guid:$('#portalGuid',sh).value.trim(),title:$('#portalTitle',sh).value.trim()||'Portail',location:{latitude:lat,longitude:lng},
      objective:{type:$('#portalObjective',sh).value,passphrase_params:{question:$('#portalQuestion',sh).value.trim(),_single_passphrase:$('#portalAnswer',sh).value.trim()}}});
    addPortalToMission(p,mi);openRoutePlanner();
  };
}
function parseIntelUrl(raw){
  try{const u=new URL(raw.trim());const pll=u.searchParams.get('pll');if(!pll)return null;const [lat,lng]=pll.split(',').map(Number);if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;return {lat,lng}}catch{return null}
}
function addPortalToMission(portal,mi=state.planner.currentMission,opts={}){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  const p=normalizePortal(portal);
  if(p.guid&&(m.portals||[]).some(x=>x.guid===p.guid)){toast(tr('duplicateElsewhere'));return false}
  m.portals.push(p);scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){
    const last=m.portals.at(-1);
    state.planner.currentMission=mi+1;
    const next=plannerMission(mi+1);
    if(state.planner.reuseLastPortal&&next.portals.length===0&&last)next.portals.push(structuredClone(last));
    scheduleSave();
    toast(tr('missionCompleteAdded',{n:mi+1,next:mi+2}));
  }else toast(tr('portalAdded',{n:mi+1}));
  return true;
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||tr('portalDefault'),Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL',p.objective?.passphrase_params?.question||'',p.objective?.passphrase_params?._single_passphrase||'']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||'Portail',location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL',passphrase_params:{question:a?.[6]||'',_single_passphrase:a?.[7]||''}}})}
function bridgePlannerPayload(){
  ensurePlannerMissions();return {v:3,pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,carry:state.planner.reuseLastPortal!==false,lang:APP_LANG,m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact))};
}
async function openIntel(){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  u.hash='rbl='+encodeURIComponent(bridgeEncode(bridgePlannerPayload()));

  if(!Capacitor.isNativePlatform()){
    window.open(u.toString(),'_blank','noopener');
    return;
  }

  // Android : une URL https seule part dans Chrome. On cible donc explicitement
  // IITC Mobile avec ACTION_VIEW + l'URL contenant le payload BannerLab.
  const candidates=[
    'org.exarhteam.iitc_mobile',
    'org.exarhteam.iitcprime'
  ];

  for(const packageName of candidates){
    try{
      await IntentLauncher.startActivityAsync({
        action: ActivityAction.VIEW,
        data: u.toString(),
        packageName
      });
      toast(packageName.includes('iitcprime')
        ? tr('intelPrimeOpened')
        : tr('intelOpened'));
      return;
    }catch(e){
      console.warn(`IITC non ouvert via ${packageName}`,e);
    }
  }

  // Ultime secours : on ouvre IITC Mobile sans payload si Android refuse
  // l'intent ciblé, puis seulement le navigateur si IITC n'est pas installé.
  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitc_mobile'});
    toast(tr('intelFallback'));
    return;
  }catch(e){
    console.warn('IITC Mobile absent',e);
  }

  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitcprime'});
    toast(tr('intelPrimeFallback'));
    return;
  }catch(e){
    console.warn('IITC Prime absent',e);
  }

  await AppLauncher.openUrl({url:u.toString()});
  toast(tr('intelBrowser'));
}
async function bridgeUserscriptText(){
  const r=await fetch('/redacted-bannerlab-iitc.user.js',{cache:'no-store'});if(!r.ok)throw new Error('Plugin IITC introuvable');return await r.text();
}
async function shareIitcBridge(){
  const name='redacted-bannerlab-iitc.user.js';
  try{
    const text=await bridgeUserscriptText();
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab · IITC Companion 0.6.2',text:tr('pluginShareText'),url:uri.uri,dialogTitle:tr('pluginDialog')});
    }else downloadBlob(new Blob([text],{type:'text/javascript'}),name);
  }catch(e){console.error(e);toast(tr('pluginShareFailed'))}
}

function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>${tr('tutorialIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>${tr('tut1Title')}</strong><span>${tr('tut1Text')}</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>${tr('tut2Title')}</strong><span>${tr('tut2Text')}</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>${tr('tut3Title')}</strong><span>${tr('tut3Text')}</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>${tr('tut4Title')}</strong><span>${tr('tut4Text')}</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>${tr('tutNote')}</span></div>
    <div class="actions"><button class="secondary installplugin">${tr('installUpdate')}</button><button class="primary launchiitc">${tr('openIitc')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}

function handleBridgeUrl(raw){
  try{
    const u=new URL(raw);if(u.protocol!=='redactedbannerlab:')return false;
    if(u.hostname==='play'||u.hostname==='banner'){
      const id=u.searchParams.get('banner')||u.searchParams.get('id')||'';const mission=Math.max(0,parseInt(u.searchParams.get('mission')||'0')||0);
      if(!id)return false;setTimeout(()=>joinSharedBanner(id,mission),120);return true;
    }
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||'Portail',imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='publisher-chrome-ready'){
      setPublisherReady('chrome',true);
      setChromeSetupStep(4);
      setPublisherBrowser('chrome');
      toast(tr('setupConfirmed'));
      closeSheet();
      setTimeout(()=>openChromeSetupSheet(4),120);
      return true;
    }
    if(u.hostname==='publisher-firefox-ready'){
      setPublisherReady('firefox',true);
      setPublisherBrowser('firefox');
      toast(tr('setupConfirmed'));
      return true;
    }
    if(u.hostname==='publisher-next'){
      const index=clamp(parseInt(u.searchParams.get('mission'))||0,0,state.planner.missions.length-1);
      state.planner.currentMission=index;
      scheduleSave();saveProject();
      setTimeout(()=>openBrowserPublisher(index),180);
      return true;
    }
    if(u.hostname==='publisher-return'){
      toast(tr('publisherReturn'));
      return true;
    }
    if(u.hostname==='sync'){
      const data=bridgeDecode(u.searchParams.get('data')||'');if(!data||!Number.isFinite(Number(data.v))||Number(data.v)<2||!Array.isArray(data.m))return false;
      ensurePlannerMissions();
      state.planner.portalsPerMission=clamp(parseInt(data.ppm)||state.planner.portalsPerMission,MIN_PORTALS_PER_MISSION,24);
      state.planner.autoAdvance=data.auto!==false;if(typeof data.carry==='boolean')state.planner.reuseLastPortal=data.carry;
      data.m.slice(0,state.planner.missions.length).forEach((portals,i)=>{if(Array.isArray(portals))state.planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean)});
      state.planner.currentMission=clamp(parseInt(data.c)||0,0,state.planner.missions.length-1);
      scheduleSave();saveProject();
      if(!data.pv)toast(tr('syncOld'));
      else toast(tr('syncOk',{v:data.pv}));
      openRoutePlanner();return true;
    }
    return false;
  }catch(e){console.warn('bridge',e);toast('Synchronisation IITC illisible.');return false}
}
function openMissionSettings(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(m=>m.portals.length>=need).length;
  const hasDescription=!!state.planner.description.trim();

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')}</h2><p>${complete}/${state.planner.missions.length} ${tr('missionReady').toLowerCase()}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>

    <div class="requiredFieldCard ${hasDescription?'ok':'missing'}">
      <div class="requiredFieldHead">
        <div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div>
        <strong>${hasDescription?'✓':'!'}</strong>
      </div>
      <textarea id="bannerDesc" rows="4" placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
      <small>${tr('bannerDescriptionHint')}</small>
    </div>

    <details class="missiondefaults">
      <summary>${tr('settings')}</summary>
      <div class="missiondefaults-body">
        <div class="field"><label>${tr('titleFormat')}</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><small>${tr('titleTokens')}</small></div>
        <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>${tr('sequential')}</option><option value="0" ${!state.planner.sequential?'selected':''}>${tr('anyOrder')}</option></select></div>
        <div class="field"><label>${tr('location')}</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>${tr('visible')}</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>${tr('hidden')}</option></select></div></div>
        <div class="field"><label>${tr('portalsPerMission')}</label><input id="ppm" type="number" min="${MIN_PORTALS_PER_MISSION}" max="24" value="${need}"><small>${tr('minimumSix')}</small></div>
      </div>
    </details>

    <div class="missionlist-v2">${state.planner.missions.map((x,i)=>{
      const ok=x.portals.length>=need;
      return `<button class="missioncard-v2 ${ok?'ok':''}" data-mi="${i}">
        <span class="missioncard-num">${String(i+1).padStart(2,'0')}</span>
        <span class="missioncard-copy"><b>${escapeHtml(x.title||generatedMissionTitle(i))}</b><small>${x.portals.length}/${need} · ${formatDistance(missionDistance(x))}</small></span>
        <span class="missioncard-state">${ok?'✓':'!'}</span>
      </button>`;
    }).join('')}</div>`);

  $('.close',sh).onclick=closeSheet;

  $('#bannerDesc',sh).oninput=e=>{
    const value=e.target.value;
    state.planner.description=value;
    state.planner.missions.forEach(x=>{
      if(!x.descriptionCustom)x.description=value;
    });
    scheduleSave();

    const card=$('.requiredFieldCard',sh);
    const valid=!!value.trim();
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{
    state.planner.portalsPerMission=clamp(parseInt(e.target.value)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24);
    scheduleSave();
    openMissionSettings();
  };
  $$('.missioncard-v2',sh).forEach(btn=>btn.onclick=()=>openMissionDetail(+btn.dataset.mi));
}

function openMissionDetail(idx){
  ensurePlannerMissions();state.planner.currentMission=idx;const m=plannerMission(idx);
  const seq=missionSequential(m),hidden=missionHidden(m);
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${idx+1}</h2><p>${m.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(m))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionsetcard missiondetail-v2">
      <div class="field"><label>${tr('title')}</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>${tr('description')}</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="missionSeq"><option value="1" ${seq?'selected':''}>${tr('sequential')}</option><option value="0" ${!seq?'selected':''}>${tr('anyOrder')}</option></select></div>
      <div class="field"><label>${tr('location')}</label><select id="missionHidden" ${!seq?'disabled':''}><option value="0" ${!hidden?'selected':''}>${tr('visible')}</option><option value="1" ${hidden?'selected':''}>${tr('hidden')}</option></select></div></div>
      <div class="missiondetail-actions"><button class="secondary backmissions">‹ ${tr('missions')}</button><button class="primary openRoute">${icon('route')} ${tr('openRoute')}</button></div>
    </div>`);
  $('.close',sh).onclick=closeSheet;
  $('.backmissions',sh).onclick=openMissionSettings;
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('#missionSeq',sh).onchange=e=>{m.sequential=e.target.value==='1';if(!m.sequential)m.hiddenLocation=false;scheduleSave();openMissionDetail(idx)};
  $('#missionHidden',sh).onchange=e=>{m.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('.openRoute',sh).onclick=openRoutePlanner;
}
function missionPublishIssues(index=state.planner.currentMission){
  ensurePlannerMissions();
  const issues=[];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const m=state.planner.missions[clamp(index,0,state.planner.missions.length-1)];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));
  if(!m)return issues;

  if(!String(m.title||'').trim())issues.push(tr('emptyTitleIssue',{n:index+1}));
  if(!String(m.description||'').trim())issues.push(tr('emptyDescIssue',{n:index+1}));
  if((m.portals||[]).length<need){
    issues.push(tr('missionNeedsPortals',{n:index+1,count:(m.portals||[]).length,need}));
  }

  const missing=(m.portals||[]).filter(p=>!p.guid).length;
  if(missing)issues.push(tr('missingGuidIssue',{n:index+1,count:missing}));

  const badPass=(m.portals||[]).filter(p=>
    p.objective?.type==='PASSPHRASE' &&
    (!p.objective?.passphrase_params?.question?.trim() ||
     !p.objective?.passphrase_params?._single_passphrase?.trim())
  ).length;
  if(badPass)issues.push(tr('passIssue',{n:index+1,count:badPass}));

  return issues;
}

function validatePlanner(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const issues=[];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));

  state.planner.missions.forEach((m,i)=>{
    const n=i+1;
    if(!m.title.trim())issues.push(tr('emptyTitleIssue',{n}));
    if(!m.description.trim())issues.push(tr('emptyDescIssue',{n}));
    if(m.portals.length<need)issues.push(tr('portalsIssue',{n,count:m.portals.length,need}));

    const missing=m.portals.filter(p=>!p.guid).length;
    if(missing)issues.push(tr('missingGuidIssue',{n,count:missing}));

    const badPass=m.portals.filter(p=>
      p.objective?.type==='PASSPHRASE' &&
      (!p.objective?.passphrase_params?.question?.trim() ||
       !p.objective?.passphrase_params?._single_passphrase?.trim())
    ).length;
    if(badPass)issues.push(tr('passIssue',{n,count:badPass}));
  });
  return issues;
}

function openBannerDescriptionRequired(onSaved){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('describeBeforePublish')}</h2><p>${tr('describeBeforePublishText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="requiredFieldCard missing">
      <div class="requiredFieldHead"><div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div><strong>!</strong></div>
      <textarea id="requiredBannerDesc" rows="5" autofocus placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
    </div>
    <div class="actions"><button class="primary saveDesc" disabled>${tr('saveAndContinue')}</button></div>`);

  $('.close',sh).onclick=closeSheet;
  const input=$('#requiredBannerDesc',sh);
  const save=$('.saveDesc',sh);

  const update=()=>{
    const valid=!!input.value.trim();
    save.disabled=!valid;
    const card=$('.requiredFieldCard',sh);
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  input.oninput=update;
  update();
  setTimeout(()=>input.focus(),80);

  save.onclick=()=>{
    const value=input.value.trim();
    if(!value)return;
    state.planner.description=value;
    state.planner.missions.forEach(m=>{
      if(!m.descriptionCustom)m.description=value;
    });
    scheduleSave();
    saveProject();
    closeSheet();
    if(typeof onSaved==='function')setTimeout(onSaved,80);
  };
}

function missionPublisherData(m,i,imageDataUrl=''){
  return {
    number:i+1,
    title:m.title||generatedMissionTitle(i),
    description:m.description||'',
    sequential:missionSequential(m),
    hiddenLocation:missionHidden(m),
    imageDataUrl,
    portals:(m.portals||[]).map(p=>({
      guid:p.guid||'',title:p.title||tr('portalDefault'),
      latitude:Number(p.location?.latitude)||0,longitude:Number(p.location?.longitude)||0,
      imageUrl:p.imageUrl||'',description:p.description||'',
      objective:{
        type:p.objective?.type||'HACK_PORTAL',
        question:p.objective?.passphrase_params?.question||'',
        answer:p.objective?.passphrase_params?._single_passphrase||''
      }
    }))
  };
}
async function buildPublisherSession(){
  ensurePlannerMissions();
  if(!state.bg.image)throw new Error(tr('noBackground'));
  const issues=validatePlanner();
  if(issues.length){const e=new Error(issues.join('\n'));e.rblBlockingIssues=issues;throw e}
  const total=state.planner.missions.length;
  const missions=[];
  for(let index=0;index<total;index++){
    toast(tr('publisherSessionCreating',{n:index+1,total}));
    const {row,col}=rowColForMission(index+1),c=document.createElement('canvas');
    c.width=c.height=512;drawTile(c,row,col,512);
    const imageDataUrl=c.toDataURL('image/jpeg',.90);
    missions.push(missionPublisherData(state.planner.missions[index],index,imageDataUrl));
    if(index%2===1)await tick();
  }
  return {
    format:'redacted-bannerlab-publisher-session',version:2,appVersion:APP_VERSION,
    sessionId:`${state.projectId||'project'}-${Date.now()}`,
    projectId:state.projectId||'',name:state.name,language:APP_LANG,
    portalsPerMission:Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission),
    currentIndex:0,missions
  };
}

async function savePublisherSessionFile(){
  const session=await buildPublisherSession();
  const currentName='RBL_Current_Session.rblpub.json';
  const projectName=`RBL_${safeName(state.name)}.rblpub.json`;
  const text=JSON.stringify(session);

  if(Capacitor.isNativePlatform()){
    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    // Stable filename: Chrome can remember this exact file handle and RBL
    // simply overwrites its contents when another project is prepared.
    await Filesystem.writeFile({
      path:`${folder}/${currentName}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    // Human-readable project copy, useful for manual loading/recovery.
    if(projectName!==currentName){
      await Filesystem.writeFile({
        path:`${folder}/${projectName}`,
        data:text,
        directory:Directory.Documents,
        encoding:Encoding.UTF8
      }).catch(e=>console.warn('[Publisher project copy]',e));
    }
  }else{
    downloadBlob(new Blob([text],{type:'application/json'}),projectName);
  }

  toast(tr('publisherSessionReady'));
  return {session,currentName,projectName};
}

const PUBLISH_BROWSER_KEY='rblPublisherBrowser';
const CHROME_READY_KEY='rblPublisherChromeReady';
const FIREFOX_READY_KEY='rblPublisherFirefoxReady';
const CHROME_STEP_KEY='rblPublisherChromeStep';
const CHROME_CODE_KEY='rblPublisherChromeCodeCopied';
const PUBLISHER_SETUP_VERSION='0.9.5';
const CHROME_SETUP_VERSION_KEY='rblPublisherChromeSetupVersion';
const FIREFOX_SETUP_VERSION_KEY='rblPublisherFirefoxSetupVersion';

function publisherBrowser(){
  return localStorage.getItem(PUBLISH_BROWSER_KEY)||'chrome';
}
function setPublisherBrowser(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  localStorage.setItem(PUBLISH_BROWSER_KEY,browser);
  toast(tr('browserSaved',{browser:browser==='firefox'?tr('firefoxMode'):tr('chromeMode')}));
}
function publisherReady(browser){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  return localStorage.getItem(readyKey)==='1'
    && localStorage.getItem(versionKey)===PUBLISHER_SETUP_VERSION;
}
function setPublisherReady(browser,value=true){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  localStorage.setItem(readyKey,value?'1':'0');
  if(value)localStorage.setItem(versionKey,PUBLISHER_SETUP_VERSION);
  else localStorage.removeItem(versionKey);
  if(browser==='chrome'&&value)localStorage.setItem(CHROME_STEP_KEY,'4');
}
function chromeSetupStep(){
  if(publisherReady('chrome'))return 4;
  if(localStorage.getItem(CHROME_SETUP_VERSION_KEY)!==PUBLISHER_SETUP_VERSION){
    localStorage.setItem(CHROME_STEP_KEY,'1');
    localStorage.removeItem(CHROME_CODE_KEY);
  }
  return clamp(parseInt(localStorage.getItem(CHROME_STEP_KEY))||1,1,3);
}
function setChromeSetupStep(step){
  step=clamp(parseInt(step)||1,1,4);
  localStorage.setItem(CHROME_STEP_KEY,String(step));
}
function resetChromeSetup(){
  setPublisherReady('chrome',false);
  localStorage.setItem(CHROME_STEP_KEY,'1');
  localStorage.removeItem(CHROME_CODE_KEY);
  toast(tr('chromeResetDone'));
}

async function prepareAndOpenPublisher(browser=publisherBrowser()){
  if(!Capacitor.isNativePlatform()){toast(tr('liveNativeOnly'));return}
  try{
    if(!publisherReady(browser)){
      if(browser==='firefox')openFirefoxSetupSheet();else openChromeSetupSheet();
      toast(browser==='firefox'?tr('firefoxNeedsSetup'):tr('chromeNeedsSetup'));
      return;
    }

    await saveProject();

    // Keep the stable JS file current without changing the bookmark.
    if(browser==='chrome'){
      await saveChromePublisherDirect().catch(e=>console.warn('[Publisher JS refresh]',e));
    }

    await savePublisherSessionFile();

    const packageName=browser==='firefox'?'org.mozilla.firefox':'com.android.chrome';
    const url='https://missions.ingress.com/';

    toast(tr('browserResume'));
    toast(browser==='chrome'?tr('chromeResumeHint'):tr('firefoxResumeHint'));

    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:url,
        packageName,
        // Browser.EXTRA_APPLICATION_ID:
        // Android/Chrome will associate this external-app id with a browser
        // tab and attempt to reuse that same tab on later launches.
        extra:{
          'com.android.browser.application_id':'com.bannerforge.mobile'
        },
        // Intent.FLAG_ACTIVITY_NEW_TASK
        flags:268435456
      });
    }catch(e){
      console.warn('[Publisher app-tab launch]',e);
      toast(tr('browserResumeFallback'));
      try{
        await IntentLauncher.openApplication({packageName});
      }catch(e2){
        await AppLauncher.openUrl({url});
      }
    }
  }catch(e){
    console.error('[Publisher session]',e);
    if(e?.rblBlockingIssues){openPublishSheet();return}
    toast(tr('browserFailed',{error:e?.message||e}));
  }
}
async function openChromePublisher(){return prepareAndOpenPublisher('chrome')}
async function openFirefoxPublisher(){return prepareAndOpenPublisher('firefox')}
async function openBrowserPublisher(){return prepareAndOpenPublisher(publisherBrowser())}

async function saveChromePublisherDirect(){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(!Capacitor.isNativePlatform()){
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
      return true;
    }

    const folder='RedactedBannerLab';
    await Filesystem.mkdir({
      path:folder,
      directory:Directory.Documents,
      recursive:true
    }).catch(()=>{});

    await Filesystem.writeFile({
      path:`${folder}/${name}`,
      data:text,
      directory:Directory.Documents,
      encoding:Encoding.UTF8
    });

    toast(tr('chromeFileSaved'));
    return true;
  }catch(e){
    console.error('[Chrome Publisher direct write]',e);
    toast(tr('chromeFileWriteFail'));
    return false;
  }
}

async function shareBrowserPublisher(forChrome=false){
  const name='redacted-bannerlab-publisher.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({
        path:`RedactedBannerLab/${name}`,
        data:text,
        directory:Directory.Cache,
        encoding:Encoding.UTF8
      });
      const uri=await Filesystem.getUri({
        path:`RedactedBannerLab/${name}`,
        directory:Directory.Cache
      });
      await Share.share({
        title:'Redacted BannerLab Publisher 0.4.0',
        text:forChrome?tr('chromeFileShareText'):tr('browserShareText'),
        url:uri.uri,
        dialogTitle:forChrome?tr('chromeFileShareDialog'):tr('browserShareDialog')
      });
    }else{
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
    }
    return true;
  }catch(e){
    console.error('[Browser Publisher share]',e);
    toast(forChrome?tr('chromeFileShareFail'):tr('browserShareFailed'));
    return false;
  }
}

async function chromeBookmarkletText(){
  const r=await fetch('/redacted-bannerlab-chrome-bookmarklet.txt');
  if(!r.ok)throw new Error('bookmarklet '+r.status);
  return r.text();
}

async function copyChromeBookmarklet(){
  const code=await chromeBookmarkletText();
  try{
    await navigator.clipboard.writeText(code);
    localStorage.setItem(CHROME_CODE_KEY,'1');
    toast(tr('miniCodeCopied'));
    return true;
  }catch(e){
    console.warn('[Chrome bookmarklet clipboard]',e);
    return false;
  }
}

async function openChromeSetupPage(test=false){
  const url=test
    ?'https://missions.ingress.com/#rblsetup=chrome&rblpick=1'
    :'https://missions.ingress.com/';
  try{
    await IntentLauncher.startActivityAsync({
      action:ActivityAction.VIEW,
      data:url,
      packageName:'com.android.chrome'
    });
    if(test)toast(tr('chromeTestWaiting'));
  }catch(e){
    toast(tr('chromeOpenFail'));
    await AppLauncher.openUrl({url});
  }
}

async function openChromeSetupSheet(step=chromeSetupStep()){
  step=publisherReady('chrome')?4:clamp(parseInt(step)||1,1,3);
  setChromeSetupStep(step);
  const code=await chromeBookmarkletText().catch(()=> '');
  const codeCopied=localStorage.getItem(CHROME_CODE_KEY)==='1';

  let body='';
  if(step===1){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">📄</div>
      <h3>${tr('chromeFileTitle')}</h3>
      <p>${tr('chromeFileText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromeFilePath')}</span></div>
      <button class="primary savepub">${tr('chromeSaveFile')}</button>
      <button class="secondary alreadysaved">${tr('alreadySaved')}</button>
    </div>`;
  }else if(step===2){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">⭐</div>
      <h3>${tr('chromeBookmarkTitle')}</h3>
      <p>${tr('chromeBookmarkText',{n:code.length})}</p>
      <div class="chromeCodeMeta"><b>${tr('chromeBookmarkName')}</b><span>${tr('codeLength',{n:code.length})}</span></div>
      <textarea class="bookmarkcode" readonly>${escapeHtml(code)}</textarea>
      <button class="primary copybookmark">${codeCopied?'✓ ':''}${tr('copyMiniCode')}</button>
      <button class="secondary openchrome">${tr('openChromeBookmark')}</button>
      <div class="rule warning"><span class="dot"></span><span>${tr('chromeNotAutoFavorite')}</span></div>
      <p class="chromeWizardHelp">${tr('chromeBookmarkHow')}</p>
      <button class="secondary bookmarkdone">${tr('bookmarkCreated')}</button>
    </div>`;
  }else if(step===3){
    body=`<div class="chromeWizardCard">
      <div class="chromeWizardIcon">✅</div>
      <h3>${tr('chromeTestTitle')}</h3>
      <p>${tr('chromeTestText')}</p>
      <div class="rule"><span class="dot"></span><span>${tr('chromePermissionHint')}<br>${tr('chromeSelectFileHint')}<br>${tr('chromeCurrentSessionHint')}</span></div>
      <button class="primary testchrome">${tr('chromeTestButton')}</button>
      <p class="chromeWizardHelp">${tr('chromeTestWaiting')}</p>
    </div>`;
  }else{
    body=`<div class="chromeWizardCard success">
      <div class="chromeWizardIcon">✓</div>
      <h3>${tr('chromeSetupSuccess')}</h3>
      <p>${tr('chromeSetupSuccessText')}</p>
      <button class="primary publishnow">${tr('publishNow')}</button>
    </div>`;
  }

  const dots=[1,2,3].map(n=>`<span class="${step===n?'active':step>n?'done':''}">${step>n?'✓':n}</span>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('chromeWizardTitle')}</h2><p>${step<=3?tr('stepOf',{n:step}):tr('chromeSetupSuccess')} · ${tr('chromeWizardIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="chromeWizardProgress">${dots}</div>
    ${body}
    <div class="chromeWizardNav">
      ${step>1&&step<=3?`<button class="secondary wizardprev">← ${tr('wizardPrev')}</button>`:''}
      ${step<3?`<button class="secondary wizardnext">${tr('wizardNext')} →</button>`:''}
    </div>
    <button class="chromeRestart">${tr('wizardRestart')}</button>`);

  $('.close',sh).onclick=closeSheet;
  $('.wizardprev',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step-1)});
  $('.wizardnext',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step+1)});

  $('.savepub',sh)?.addEventListener('click',async()=>{
    const ok=await saveChromePublisherDirect();
    if(ok){
      setChromeSetupStep(2);
      closeSheet();
      openChromeSetupSheet(2);
    }
  });
  $('.alreadysaved',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(2);closeSheet();openChromeSetupSheet(2);
  });

  $('.copybookmark',sh)?.addEventListener('click',async()=>{
    if(await copyChromeBookmarklet()){
      closeSheet();openChromeSetupSheet(2);
    }else toast(tr('bookmarkletCopyFail'));
  });
  $('.openchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(false));
  $('.bookmarkdone',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(3);closeSheet();openChromeSetupSheet(3);
  });

  $('.testchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(true));
  $('.publishnow',sh)?.addEventListener('click',()=>{
    closeSheet();openChromePublisher(state.planner.currentMission);
  });

  $('.chromeRestart',sh).onclick=()=>{
    resetChromeSetup();
    closeSheet();
    openChromeSetupSheet(1);
  };
}

function openFirefoxSetupSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('firefoxSetupTitle')}</h2><p>${tr('firefoxSetupIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="actions"><button class="primary sharepublisher">${tr('sharePublisher')}</button></div>
    <div class="actions"><button class="secondary testfirefox">${tr('testFirefox')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.sharepublisher',sh).onclick=()=>shareBrowserPublisher(false);
  $('.testfirefox',sh).onclick=async()=>{
    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:'https://missions.ingress.com/#rblsetup=firefox',
        packageName:'org.mozilla.firefox'
      });
    }catch(e){
      toast(tr('publisherNoFirefox'));
    }
  };
}

function openPublishSheet(){
  ensurePlannerMissions();
  if(!state.planner.description.trim()){openBannerDescriptionRequired(openPublishSheet);return}

  const issues=validatePlanner();
  const current=state.planner.currentMission;
  const currentIssues=missionPublishIssues(current);
  const m=state.planner.missions[current];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(x=>x.portals.length>=need && String(x.description||'').trim()).length;
  const total=state.planner.missions.length;
  const mode=publisherBrowser();
  const chromeReady=publisherReady('chrome'),firefoxReady=publisherReady('firefox');
  const blocked=issues.length>0;

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('publish')}</h2><p>${complete}/${total} · ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishMissionGate ${blocked?'blocked':'ready'}">
      <div class="publishMissionGateHead"><span class="missioncard-num">${String(current+1).padStart(2,'0')}</span><div><b>${escapeHtml(m?.title||generatedMissionTitle(current))}</b><small>${m?.portals?.length||0}/${need} · ${tr('bannerDescription')} ✓</small></div><strong>${blocked?'!':'✓'}</strong></div>
      ${blocked?`<div class="publishBlockingList">${issues.slice(0,12).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}</div><div class="actions"><button class="primary completemission">${icon('route')} ${tr('completeMission')}</button></div>`:`<div class="publishReadyText">${tr('publisherWholeHint')}<small>${tr('publisherCurrentFile')}</small></div>`}
    </div>
    ${blocked?`<div class="publishscore warn"><b>${tr('reviewCount',{n:issues.length})}</b><span>${tr('publisherAllRequired')}</span></div>`:''}
    <div class="field"><label>${tr('publisherBrowser')}</label><div class="publisherchoices">
      <button class="publisherchoice chrome ${mode==='chrome'?'selected':''}" data-mode="chrome"><span class="browsericon">🌐</span><span><b>${tr('chromeMode')}</b><small>${tr('chromeModeSub')}</small><em>${chromeReady?'✓ '+tr('chromeReady'):tr('noExtraApp')}</em></span></button>
      <button class="publisherchoice firefox ${mode==='firefox'?'selected':''}" data-mode="firefox"><span class="browsericon">🦊</span><span><b>${tr('firefoxMode')}</b><small>${tr('firefoxModeSub')}</small><em>${firefoxReady?'✓ '+tr('firefoxReady'):tr('recommendedAuto')}</em></span></button>
    </div></div>
    <div class="actions"><button class="primary livepublisher" ${blocked?'disabled':''}>🚀 ${tr('publisherWholeBanner')}</button></div>
    <div class="actions"><button class="secondary setupselected">${mode==='firefox'?tr('firefoxSetup'):tr('chromeSetup')}</button></div>
    <details class="missionCommon"><summary>${tr('backupTransfer')}</summary><div class="missionCommonBody"><div class="actions"><button class="secondary exportpack">${icon('download')} ${tr('exportPackBackup')}</button></div><div class="actions"><button class="secondary openmat">${icon('globe')} ${tr('openOfficialOnly')}</button></div></div></details>`);
  $('.close',sh).onclick=closeSheet;
  $('.completemission',sh)?.addEventListener('click',()=>{closeSheet();state.planner.currentMission=current;scheduleSave();openRoutePlanner()});
  $$('.publisherchoice',sh).forEach(btn=>btn.onclick=()=>{setPublisherBrowser(btn.dataset.mode);closeSheet();openPublishSheet()});
  $('.livepublisher',sh).onclick=()=>openBrowserPublisher();
  $('.setupselected',sh).onclick=()=>publisherBrowser()==='firefox'?openFirefoxSetupSheet():openChromeSetupSheet();
  $('.exportpack',sh).onclick=exportBannerLabPack;$('.openmat',sh).onclick=openMissionAuthoring;
}

async function exportBannerLabPack(){
  ensurePlannerMissions();
  const zip=new JSZip(),imgFolder=zip.folder('missions');
  const manifest={
    format:'redacted-bannerlab',version:1,appVersion:APP_VERSION,name:state.name,
    language:APP_LANG,portalsPerMission:state.planner.portalsPerMission,
    missions:state.planner.missions.map((m,i)=>({
      number:i+1,title:m.title,description:m.description,sequential:missionSequential(m),hiddenLocation:missionHidden(m),
      image:`missions/${String(i+1).padStart(3,'0')}.jpg`,
      portals:(m.portals||[]).map(p=>({
        guid:p.guid,title:p.title,latitude:p.location.latitude,longitude:p.location.longitude,imageUrl:p.imageUrl||'',
        objective:{type:p.objective?.type||'HACK_PORTAL',question:p.objective?.passphrase_params?.question||'',answer:p.objective?.passphrase_params?._single_passphrase||''}
      }))
    }))
  };
  try{
    toast(tr('packCreating'));
    for(let n=1;n<=manifest.missions.length;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      imgFolder.file(`${String(n).padStart(3,'0')}.jpg`,await canvasBlob(c,'image/jpeg',.94));
      if(n%4===0)await tick();
    }
    zip.file('missions.json',JSON.stringify(manifest,null,2));
    const name=`${safeName(state.name)}_BannerLab.zip`;
    if(Capacitor.isNativePlatform()){
      const b64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true});
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:b64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:`${manifest.missions.length} missions · ${state.name}`,url:uri.uri,dialogTitle:name});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
      downloadBlob(blob,name);
    }
    toast(tr('packCreated'));
  }catch(e){console.error(e);toast(tr('exportImpossible',{error:e?.message||e}))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function openInfoSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>Redacted BannerLab</h2><p>${tr('versionLabel')} ${APP_VERSION}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('language')}</label><select id="appLanguage"><option value="fr" ${APP_LANG==='fr'?'selected':''}>🇫🇷 ${tr('french')}</option><option value="en" ${APP_LANG==='en'?'selected':''}>🇬🇧 ${tr('english')}</option><option value="es" ${APP_LANG==='es'?'selected':''}>🇪🇸 ${tr('spanish')}</option></select></div>
    <div class="rulelist">
      <div class="rule"><span class="dot"></span><span><b>Prime</b> · ${tr('infoPrime')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>Mission Planner</b> · ${tr('infoPlanner')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>IITC Companion 0.6.2</b> · ${tr('infoCompanion')}</span></div>
      <div class="rule warning"><span class="dot"></span><span>${tr('disclaimer')}</span></div>
    </div>
    <div class="actions"><button class="secondary" id="manageProjects">${icon('folder')} ${tr('projects')}</button><button class="primary" id="newProject">${icon('plus')} ${tr('newProject')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('#appLanguage',sh).onchange=e=>setAppLanguage(e.target.value);
  $('#manageProjects',sh).onclick=openProjectsSheet;
  $('#newProject',sh).onclick=()=>createNewProject();
}

function freshEditor(name=tr('defaultProject')){
  state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0};state.texts=[];state.active='background';state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,reuseLastPortal:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  $('#projectName').value=state.name;$('#rowsSelect').value=String(state.rows);$('#missionCount').textContent=state.rows*6;$('#worldH').textContent=worldH();syncChips();$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name=tr('defaultNewProject')){
  setFlowStep('fresco',{open:false});
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();await saveProject();closeSheet();toast(tr('newProjectCreated'));
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const locale=APP_LANG==='es'?'es-ES':APP_LANG==='en'?'en-GB':'fr-FR';
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||tr('unnamed'))}</strong><span>${(d.rows||3)*6} ${tr('missions').toLowerCase()}${updated?' · '+escapeHtml(updated):''}</span></div>${current?`<span class="currentbadge">${tr('opened')}</span>`:''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>${tr('open')}</button><button class="secondary renameproject">${icon('edit')} ${tr('rename')}</button><button class="secondary duplicateproject">${icon('copy')} ${tr('copy')}</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||`<div class="small">${tr('noSavedProject')}</div>`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('myProjects')}</h2><p>${tr('projectsSaved',{n:projects.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="projectlist">${cards}</div><div class="actions"><button class="primary" id="createProject">${icon('plus')} ${tr('newProject')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}

async function switchProject(id){setFlowStep('fresco',{open:false});await saveProject();await loadProject(id);resetHistory();closeSheet();toast(tr('projectOpened',{name:state.name}))}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameProject')}</h2><p>${tr('renameHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('projectName')}</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||tr('defaultProject'))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||tr('defaultProject');const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;$('#projectName').value=name}closeSheet();toast(tr('projectRenamed'))};
}

async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteProject')}</h2><p>${escapeHtml(rec.data?.name||tr('unnamed'))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('deleteWarning')}</span></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirmdelete">${icon('trash')} ${tr('delete')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}

async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||tr('fresco')} ${tr('copySuffix')}`;data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob});await txDone(tx2);await loadProject(newId);closeSheet();toast(tr('copyCreated'));
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast(tr('projectDeleted'));
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation},texts:state.texts,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject(){try{const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current')}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();resetHistory();await saveProject();return}
    freshEditor();state.projectId=target;
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[]});
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

if(Capacitor.isNativePlatform()){
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url)}).catch?.(()=>{});
  App.addListener('appStateChange',({isActive})=>{if(isActive)resumePendingPlayOverlay()}).catch?.(()=>{});
  App.getLaunchUrl().then(r=>{if(r?.url)handleBridgeUrl(r.url)}).catch(()=>{});
}
window.addEventListener('resize',render);
window.addEventListener('keydown',e=>{
  const k=(e.key||'').toLowerCase(),ctrl=e.ctrlKey||e.metaKey;if(!ctrl)return;
  const target=e.target,tag=(target?.tagName||'').toUpperCase();
  const editing=['INPUT','TEXTAREA','SELECT'].includes(tag)||target?.isContentEditable;
  if(editing)return; // laisse l'annulation native fonctionner dans les champs texte
  if(k==='z'&&!e.shiftKey){e.preventDefault();undoAction();return}
  if(k==='y'||(k==='z'&&e.shiftKey)){e.preventDefault();redoAction();return}
});
if('serviceWorker' in navigator&&!Capacitor.isNativePlatform())window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
resizeCanvas();migrateLegacyStorage().then(()=>loadProject());
