# Redacted BannerLab 1.0.15.15 TEST · build 11516

## Interface

- Arcade : les vignettes IGOR, MILO, RITA et REDACTED affichent désormais **l’illustration complète**, cercle compris, sans zoom ni recadrage.
- Accueil principal : le bouton **Rechercher une fresque** devient un véritable CTA vert plein, plus grand et beaucoup plus visible dans l’en-tête.
- Aucun nouvel asset graphique n’a été généré.
