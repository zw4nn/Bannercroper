# Redacted BannerLab 1.0.15.17 TEST · build 11518

## Accueil
- Suppression de la grosse carte du projet actif.
- Barre compacte **Projets / Rangées** à la place.
- **Rechercher une fresque** reste mis en avant, mais dans un format plus petit et moins agressif visuellement.

## Parcours / IGOR
- Carte IGOR simplifiée.
- Suppression des options doublonnées dans RBL pour le passage automatique et la reprise du dernier portail.
- Ces réglages restent disponibles directement dans **Options** d’IGOR.
- IGOR passe en **0.6.13** et conserve désormais correctement le réglage local `carry` lors du chargement d’un projet RBL.
