# Redacted BannerLab 1.0.15.19 TEST · build 11520

## Packaging IGOR

- IGOR embarqué passe à **0.6.14**.
- Le fichier d’installation IITC est désormais **`igor.user.js`** au lieu de `redacted-bannerlab-iitc.user.js`.
- Tous les appels web, installateurs Android et contrôles de build utilisent le nouveau nom.
- Migration prévue : lors d’une installation/mise à jour via RBL, l’ancien fichier `redacted-bannerlab-iitc.user.js` est reconnu et supprimé afin d’éviter un doublon de plugin dans IITC.
- L’identifiant interne userscript reste `redacted-bannerlab-iitc` pour conserver la compatibilité logique de l’extension.
