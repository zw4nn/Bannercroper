# Redacted BannerLab 1.0.15.18 TEST · build 11519

## Arcade — rythme du chrono et lisibilité Machina

- Portal Panic : anomalies **Machina rouges beaucoup plus contrastées**, y compris quand la faction choisie est RES.
- Le bonus de temps Arcade est fortement réduit et harmonisé sur tous les mini-jeux : **+2 secondes uniquement à chaque palier de combo ×5** (×5, ×10, ×15…).
- Suppression des bonus de temps supplémentaires qui rendaient les parties trop faciles à prolonger : fin de série MILO, boss Portal Blaster et bonus Machina ne donnent plus de secondes gratuites hors palier de combo.
- Les textes des 7 langues prioritaires ont été ajustés pour annoncer clairement la règle +2 s tous les 5 combos.
