# Redacted BannerLab 1.0.15.2 TEST · build 11503

## Arcade du Lab — itération mini-jeux

- Passage de l’Arcade du Lab à **6 mini-jeux**.
- Ajout d’un **vrai briefing visuel** au lancement de chaque mini-jeu, avec les personnages qui parlent.
- Ajout d’un **panneau tutoriel** repliable pour chaque mini-jeu.
- Correctif d’affichage en haut de l’écran : l’overlay Arcade est désormais **décalé sous la barre de notification** / zone safe-area.
- Refonte du mini-jeu Redacted en **Faction Drop** : choix **ENL / RES**, caisses de faction, caisses adverses et caisses **Machina** rouges explosives.
- Ajout d’un nouveau mini-jeu **RITA · Portal Blaster** : shoot arcade façon Galaga, déplacement au doigt, tir automatique, bonus de faction, niveaux et boss Machina.
- Mise à jour des textes Arcade pour refléter ces ajouts.
