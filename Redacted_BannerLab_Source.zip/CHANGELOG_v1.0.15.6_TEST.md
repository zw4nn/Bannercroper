# Redacted BannerLab 1.0.15.6 TEST · build 11507

## Arcade du Lab — entrée clandestine retouchée

- L’accueil de l’Arcade adopte une vraie ambiance **backroom / salle de jeu clandestine** construite uniquement avec les assets existants et du CSS.
- L’enseigne devient **REDACTED BANNER ~~LAB~~ ARCADE** : `LAB` est barré et `ARCADE` est ajouté en néon clandestin.
- Le bandeau supérieur reprend le même branding au lieu de `RBL // ARCADE`.
- Redacted n’est plus affiché comme une grosse tête seule au centre : son **icône launcher existante** sert désormais d’avatar dans une bulle de dialogue.
- Le décor central devient une porte technique / terminal de sous-sol, entourée des bornes IGOR et RITA et des états de l’équipe.
- Aucun nouvel asset généré n’a été ajouté.
