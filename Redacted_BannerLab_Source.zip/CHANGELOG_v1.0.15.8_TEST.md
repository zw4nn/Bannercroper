# Redacted BannerLab 1.0.15.8 TEST · build 11509

## Arcade — Redacted harmonisé

- Remplacement du visuel du mini-jeu Redacted par la **nouvelle tête / icône launcher** dans le menu Arcade.
- Harmonisation du titre avec les autres jeux : **REDACTED · Faction Drop**.
- Le briefing et l’en-tête de ce mini-jeu utilisent aussi l’avatar launcher/logo de Redacted.
