# Redacted BannerLab 1.0.15 · build 11501

## 🧪 MILO entre au laboratoire

Le poste de publication accueille officiellement **MILO**, *Mission Import & Launch Operator*. Il remplace l’ancien RBL Publisher dans l’interface et accompagne désormais la publication des missions dans Mission Authoring Tool.

- **MILO 0.5.1** : interface plus claire, actions nommées et Submit reste toujours sous le contrôle de l’Agent.
- Nouvel assistant Chrome pas à pas avec de vraies captures nettoyées.
- Les fichiers prennent enfin son nom : `MILO.user.js`, `MILO_CurrentBanner.json` et `MILO_Launch.txt`.
- Compatibilité conservée avec les anciens fichiers de session pendant la migration vers les noms MILO.
- La configuration Chrome est rejouée une fois pour basculer proprement sur les nouveaux fichiers MILO.
- IGOR reste en **0.6.10**.

---

# Redacted BannerLab 1.0.14 · build 11408


## Build 11408 TEST — naissance de MILO
- Le navigateur Publisher devient **MILO** : *Mission Import & Launch Operator*, assistant Publisher du Lab.
- MILO présente lui-même le tutoriel Chrome avec un petit lore de laboratoire et l’illustration fournie par le projet.
- Le favori Chrome s’appelle désormais **MILO** et le tutoriel demande de taper MILO dans la barre d’adresse.
- Le panneau dans Mission Authoring est rebaptisé MILO et sa barre d’outils utilise des boutons textuels lisibles au lieu d’une rangée d’icônes ambiguës.
- Les actions destructrices sont rangées sous **Fichiers & mémoire**.
- La capture Chrome « Modifier » a été nettoyée pour supprimer l’aperçu de capture précédent.
- Publisher/MILO navigateur : **0.4.10**. Setup Chrome : **0.10.13**. Android versionCode : **11408**.

## Correctif build 11404 — enregistrement Publisher Android

- Le bouton « Enregistrer le Publisher » n’utilise plus l’écriture directe Capacitor dans `Documents`, devenue peu fiable avec le stockage cloisonné Android récent.
- Un plugin natif dédié écrit maintenant le Publisher et les sessions dans `Téléchargements/RedactedBannerLab` via `MediaStore.Downloads` sur Android 10+.
- Le fichier `RBL_Current_Session.rblpub.json` est réécrit sur la même entrée MediaStore lorsqu’elle existe afin de conserver un fichier stable pour Chrome.
- Le Publisher est vérifié par SHA-256 avant écriture.
- Le bouton affiche immédiatement « Enregistrement… » et montre désormais l’erreur native si Android refuse l’écriture, au lieu de donner l’impression qu’il ne se passe rien.
- Publisher navigateur : 0.4.8. IGOR reste en 0.6.10.

## Correctif IGOR 0.6.10 — migration du jeton de pont

- La version publique reste `1.0.14`; seul le `versionCode` monte à `11404`.
- IGOR adopte désormais toujours le jeton de pont frais envoyé par RBL lorsqu'il reprend un parcours local créé avec 0.6.7/0.6.8.
- Si un ancien état local a perdu le jeton, IGOR tente de le restaurer depuis le dernier snapshot RBL compatible.
- Sans jeton valide, IGOR ne déclenche plus de deep link invalide : il demande de rouvrir IGOR depuis le Lab.
- La synchro manuelle reste `redactedbannerlab://sync?data=...` avec le jeton uniquement dans le payload compact.
- La détection des mises à jour par `versionCode` reste active, donc une 11401/11402 peuvent détecter la 11404 même avec le même `versionName` 1.0.14.


## Correctif IGOR 0.6.9 — synchro stable + authentifiée

- Retour au transport de synchronisation IITC qui était stable : `redactedbannerlab://sync?data=...`.
- Le jeton 256 bits n'est plus dupliqué dans l'URL. Il reste inclus dans le payload compact et est vérifié par RBL avant toute modification.
- IGOR n'envoie plus son état UI complet lors d'une synchro : seulement le projet, les missions et les champs nécessaires.
- Les autres ponts sensibles (pull, Publisher, portail) restent protégés par jeton dans leur URL, car leurs payloads sont courts.
- Android versionCode : 11401.


## v1.0.14 — durcissement sécurité
- Pont RBL ↔ IGOR authentifié par un jeton aléatoire propre à chaque installation. Les deep links internes qui modifient l’état du Lab sont refusés sans ce jeton ; les liens publics de partage de bannière restent utilisables par tous.
- IGOR passe en 0.6.9 pour transporter ce jeton dans le fragment local IITC et le renvoyer lors des synchronisations volontaires.
- Publisher navigateur 0.4.8 : le favori Chrome calcule le SHA-256 du fichier Publisher choisi et refuse de l’exécuter si son empreinte ne correspond pas au Publisher officiel embarqué.
- Suppression de `UPDATE_PACKAGES_WITHOUT_USER_ACTION`. Les mises à jour restent explicitement confirmées par l’utilisateur via Android PackageInstaller.
- Sauvegarde système Android désactivée (`allowBackup=false`) et règles d’extraction cloud/transfert explicitement vides. Les exports/backups manuels RBL restent disponibles.
- Trafic HTTP clair interdit côté Android (`usesCleartextTraffic=false`).
- Vite passe de 7.1.3 à 7.3.6.
- Leaflet reste en 1.9.4 car aucune version stable plus récente n’est publiée ; le popup RBL n’utilise plus de chaîne HTML et reçoit désormais un nœud texte, ce qui neutralise le vecteur XSS concerné dans notre usage.
- Android `versionCode` : 11401.

# Redacted BannerLab 1.0.14

Éditeur mobile-first de fresques et de missions Ingress Prime, non officiel.

## 0.7.0

- Mission Planner mobile entièrement revu : liste compacte des missions, puis fiche d’édition dédiée.
- Redacted BannerLab n’utilise plus UMM comme workflow principal : export natif `BannerLab` avec `missions.json` + images 512×512.
- Actions officielles par portail : Hack, Mod, Capture/Upgrade, Link, Field, Passphrase.
- Passphrase : question + réponse attendue enregistrées avec le portail.
- Reprise autorisée du dernier portail d’une mission comme premier portail de la suivante.
- Option pour reprendre automatiquement ce portail lors du passage à la mission suivante.
- Les doublons légitimes fin→début ne sont plus signalés comme erreurs.
- IITC Companion 0.5.0 inclus :
  - statistiques piétonnes Valhalla/OpenStreetMap,
  - choix de l’action,
  - question/réponse de passphrase,
  - reprise fin→début,
  - mode sécurisé basé sur `portalSelected`.
- Première couche multilingue Français / English / Español :
  - navigation principale,
  - Mission Planner,
  - publication,
  - Companion IITC.
- La langue se choisit dans Réglages & infos et est conservée sur l’appareil.

## Publication

BannerLab génère désormais son propre pack :
- `missions/001.jpg`, `002.jpg`, etc.
- `missions.json` contenant titres, descriptions, type de mission, visibilité,
  portails, coordonnées, objectifs et passphrases.

La prochaine étape est un `Redacted BannerLab Publisher` pour préremplir
le Mission Authoring Tool officiel à partir de ce format. La soumission finale
reste volontairement faite dans l’outil officiel.

## Signature Android

La clé de signature stable ne doit jamais être remplacée.


## 0.7.1 — calques globaux et historique

- Les recadrages individuels ne transforment que l'image de fond.
- Les textes restent des calques globaux, composés après tous les recadrages locaux.
- Aperçu, export rapide, export mission par mission et éditeur plein écran respectent la même composition.
- Annuler / Rétablir multi-étapes (80 opérations), avec un geste tactile = une opération.
- Undo/Redo aussi dans l'éditeur de mission plein écran.
- Ctrl+Z, Ctrl+Y et Ctrl+Shift+Z sur la future version web / clavier.


## 0.7.2 — traduction et Companion 0.6
- Nettoyage des chaînes historiques FR/EN/ES dans l’éditeur, Texte, Cadrage, Aperçu, Export, Infos et Projets.
- Companion IITC intégré en 0.6.0.
- Ouverture IITC corrigée : le payload BannerLab passe dans `#rbl=` et n’est plus envoyé au serveur Intel.
- Langue BannerLab transmise au Companion.


## 0.8.0 — Publisher intégré expérimental
- Nouveau bouton Publier → Préparer directement dans Mission Authoring.
- RBL rend les images 512×512 en mémoire et écrit un payload temporaire interne, sans ZIP ni téléchargement.
- Android ouvre une PublisherActivity WebView sur missions.ingress.com et injecte automatiquement le Publisher RBL.
- Le Publisher importe titre, description, séquentiel/caché, portails, objectifs, passphrases et image.
- Le clic final Submit reste manuel.
- Companion IITC intégré 0.6.1.
- Sync Companion accepte les formats futurs >=2.

## 0.8.1 — Publisher navigateur
- Abandon de l'authentification Google dans WebView intégrée.
- Publisher direct dans Firefox Android avec Violentmonkey.
- Une mission est transmise directement via le fragment `#rblpub=` : aucun ZIP.
- Le payload est sauvegardé côté `missions.ingress.com` avant la redirection Google.
- Mission suivante : retour automatique RBL, génération de l'image suivante, puis réouverture Firefox.
- Companion IITC 0.6.1 intégré.

## 0.8.2 — Chrome + Firefox
- Choix persistant du navigateur de publication.
- Chrome : aucune application supplémentaire, bookmarklet installé une seule fois puis lancé depuis la barre d'adresse.
- Assistant Chrome : copie du bookmarklet, ouverture Mission Authoring, test et validation par deep link.
- Firefox : mode automatique via Violentmonkey + Publisher userscript.
- Le Publisher 0.3.1 renvoie un deep link de validation pour les deux modes.
- Aucun ZIP dans le workflow de publication.

## 0.8.3 — assistant Chrome simplifié
- Bookmarklet Chrome réduit de ~20 000 caractères à 1759 caractères.
- Le bookmarklet mémorise le `FileSystemFileHandle` de `publisher.js` dans IndexedDB.
- Au premier test : sélection du fichier `publisher.js`.
- Aux utilisations suivantes : réutilisation du fichier et demande `Autoriser` si Chrome l'exige.
- Assistant Chrome en 3 étapes, mémorisé, avec précédent / continuer / recommencer.
- Test réel : le Publisher renvoie `redactedbannerlab://publisher-chrome-ready`.
- Firefox + Violentmonkey reste disponible comme mode automatique.

## 0.8.4 — garde-fous de publication
- Description de bannière sortie des réglages avancés et affichée directement dans Missions.
- Description de bannière obligatoire avant d'ouvrir l'écran Publier.
- La description commune continue d'être propagée aux missions non personnalisées.
- Minimum absolu de 6 portails par mission dans RBL et Companion IITC.
- Une mission n'est pas envoyée au Publisher tant qu'elle n'atteint pas son quota configuré (minimum 6).
- Le Publisher 0.3.3 refait la validation côté missions.ingress.com et refuse lui aussi description vide / moins de 6 portails.
- Companion IITC intégré : 0.6.2.

## 0.9.0 — Jouer + Overlay + Publisher session
- Nouveau hub « Jouer » : recherche Bannergress, favoris locaux, bannière en cours.
- Détails Bannergress + lancement d'une bannière.
- Overlay Android natif Redacted : précédent / ouvrir / suivant / terminé / réduction en bulle / déplacement / fermeture.
- Aucune interaction directe avec l'UI Ingress : uniquement des deeplinks de missions.
- Autorisation SYSTEM_ALERT_WINDOW gérée depuis RBL.
- Service de premier plan `specialUse` pour maintenir l'overlay pendant Ingress.
- Publisher 0.4.0 : fichier de session contenant toute la bannière ; le favori Chrome n'est lancé qu'une fois par session normale.
- Chrome conserve le handle de publisher.js ; une nouvelle session demande le fichier *.rblpub.json une seule fois.
- Firefox charge lui aussi une session complète via le panneau Publisher.
- Easter egg : 7 taps sur le logo, Redacted détouré traverse l'écran une fois puis disparaît.

## 0.9.1 — overlay + recherche Bannergress
- Overlay déplié : poignée dédiée `≡ Déplacer`, gestes consommés proprement, réduction/fermeture accessibles.
- Overlay automatiquement contraint dans la zone visible quand il démarre, se déplace ou passe bulle ↔ panneau.
- Suppression de `FLAG_LAYOUT_NO_LIMITS` pour éviter les panneaux perdus hors écran.
- Bouton principal renommé « Rechercher une fresque ».
- Recherche Bannergress multi-critères : nom/mot-clé, ville (résolue via `/places` puis `placeId`), auteur (`author`) et autour de moi (`proximityStartPoint`).
- Les critères nom/auteur peuvent être combinés avec ville ou proximité.
- Favoris et reprise de fresque conservés.

## 0.9.2 — correctif compilation Android
- Correction de l'import `ActivityNotFoundException` dans `MissionOverlayService.java`.
- `android.app.ActivityNotFoundException` remplacé par `android.content.ActivityNotFoundException`.
- Aucun changement de workflow GitHub requis.

## 0.9.3 — Publisher sessions / ouverture directe
- « Préparer toute la bannière » n’ouvre plus la feuille Android de partage.
- La session courante est écrite automatiquement dans
  `Téléchargements/RedactedBannerLab/RBL_Current_Session.rblpub.json`, puis Mission Authoring est ouvert.
- Une copie lisible par projet est aussi conservée dans le même dossier.
- Le mini-bookmarklet Chrome mémorise séparément le handle du Publisher JS et celui du JSON de session.
- Après la première sélection de `RBL_Current_Session.rblpub.json`, Chrome peut réutiliser le même fichier
  aux préparations suivantes et ne redemander que l’autorisation de lecture.
- Publisher 0.4.1 : plusieurs projets/sessions mémorisés dans IndexedDB.
- Sélecteur de projet, Charger JSON, Actualiser depuis RBL, Supprimer le projet courant et Tout effacer.
- Les anciennes sessions v2 sont migrées mais ne sont plus impossibles à supprimer.
- Une bannière complète reste chargée pendant toute la session : pas besoin de relancer le favori entre les missions.

## 0.9.4 — enregistrement direct du Publisher Chrome
- Le bouton « Enregistrer le Publisher » n'utilise plus `Share.share()`.
- RBL écrit directement :
  `Téléchargements/RedactedBannerLab/redacted-bannerlab-publisher.user.js`
- Le JSON de session reste :
  `Téléchargements/RedactedBannerLab/RBL_Current_Session.rblpub.json`
- Chrome ne demande plus qu'à sélectionner ces deux fichiers lors de la première configuration.
- Le partage Android reste uniquement utile au mode Firefox/userscript et aux exports volontaires.

## 0.9.5 — fin des sessions fantômes Chrome
- Le handle du Publisher JS reste mémorisé.
- Le JSON de session n'est plus réutilisé silencieusement lorsqu'une nouvelle bannière est préparée.
- `#rblsession=1` force désormais le sélecteur Chrome pour `RBL_Current_Session.rblpub.json`.
- Une fois le JSON choisi, toute la bannière reste chargée : aucune nouvelle sélection entre les missions.
- Publisher 0.4.2 : boutons « Changer le fichier de session » et « Oublier le fichier mémorisé ».
- Ces boutons nettoient aussi le handle `session` du mini-bookmarklet dans IndexedDB.
- Supprimer un favori Chrome n'est plus présenté comme une méthode de réinitialisation : les handles sont gérés explicitement.

## 0.9.6 — conserver la session Mission Authoring
- RBL ne navigue plus vers `missions.ingress.com` à chaque préparation.
- Après écriture du JSON courant, l'application Chrome/Firefox est simplement ramenée au premier plan avec `IntentLauncher.openApplication`.
- La navigation vers Mission Authoring n'est utilisée qu'en secours si le navigateur ne peut pas être repris.
- Publisher 0.4.3 surveille toutes les 2 secondes `RBL_Current_Session.rblpub.json`.
- Quand RBL écrase ce fichier avec une nouvelle bannière, le Publisher déjà ouvert charge automatiquement la nouvelle session.
- Aucun nouveau passage OAuth Google n'est déclenché par RBL entre deux préparations tant que l'onglet Mission Authoring reste ouvert.
- Le fichier Publisher Chrome est réécrit silencieusement à chaque préparation, donc aucun nouveau favori n'est nécessaire.

## 0.9.7 — reprise Publisher + verrouillage des étapes
- La session Publisher est persistée dans IndexedDB : projet courant, session complète et progression.
- La progression (mission courante, préparées, soumises) est désormais sauvegardée à la fois dans localStorage et dans l'enregistrement IndexedDB du projet.
- Après fermeture/kill de la page, relancer le Publisher restaure automatiquement la session et la mission en cours.
- Chrome nécessite toujours de relancer le favori une fois après une fermeture réelle de page : le JavaScript ne peut pas survivre à une page fermée.
- Le workflow RBL verrouille maintenant l'édition de la fresque quand l'étape 2 Parcours, 3 Missions ou 4 Publier est active.
- Fermer une feuille / utiliser Retour ne déverrouille pas la fresque.
- Pour modifier image, cadrage, texte, recadrage mission, rangées ou Undo/Redo, il faut explicitement sélectionner l'étape 1 Fresque.
- Aperçu et Export restent accessibles pendant les étapes verrouillées.

## 0.9.8 — onglet Mission Authoring dédié RBL
- Correction du bouton Publier qui ouvrait uniquement l'écran des onglets Chrome.
- RBL utilise maintenant `ACTION_VIEW` vers `https://missions.ingress.com/`.
- L'intent contient `Browser.EXTRA_APPLICATION_ID` (`com.android.browser.application_id`)
  avec l'identifiant stable `com.bannerforge.mobile`.
- Chrome peut ainsi associer un onglet à RBL et tenter de réutiliser ce même onglet
  aux ouvertures suivantes au lieu de créer un nouvel onglet.
- Cela conserve mieux le contexte/session Mission Authoring dans le même onglet.
- Le JSON Publisher reste local : aucun payload RBL n'est envoyé dans l'URL.
- La configuration Chrome/bookmarklet existante reste valide.
- Publisher interne : 0.4.5.

## 0.10.0 — Jouer sans compte Bannergress
- Aucun login Bannergress : recherche et détails publics uniquement.
- Liste locale « À faire » distincte des favoris RBL.
- Historique local avec progression, date, durée active, distance Bannergress estimée et reprise.
- Overlay : bouton Pause/Reprendre et statistiques persistées localement.
- Partage groupe sans serveur par lien/deeplink `redactedbannerlab://play?...` et QR code.
- Le lien contient l'identifiant public Bannergress et le numéro de mission courant ; le téléphone destinataire récupère les données publiques puis propose de rejoindre la même mission.
- Carte Leaflet/OpenStreetMap du parcours complet à partir des `mission.steps[].poi` fournis par Bannergress.
- Bouton itinéraire piéton vers le premier point de la première mission via Google Maps, avec fallback navigateur.
- Bouton partager la progression depuis la session en cours.
- Dépendances ajoutées : Leaflet 1.9.4 et qrcode 1.5.4.

## 0.10.1 — stats totalement inutiles sur Bannergress
- Chaque résultat Bannergress possède un bouton « 📊 Stats inutiles ».
- Le détail de la fresque n'est chargé qu'à la demande pour éviter une avalanche d'appels API.
- La fiche complète affiche automatiquement les statistiques.
- Calculs locaux à partir des coordonnées publiques Bannergress :
  distance Bannergress, tracé géométrique, temps de marche théorique, nombre d'étapes,
  lieux distincts, passages répétés, étapes/km, moyenne par mission, mission la plus longue,
  plus long tronçon, transitions inter-missions, ligne droite départ/arrivée,
  coefficient de détour et couverture cartographique.
- Les distances géométriques sont volontairement présentées comme des estimations et non
  comme un itinéraire routier.

### 0.10.1 — raffinement stats piétonnes
- La version visible reste 0.10.1.
- Les « Stats inutiles » des fresques Bannergress réutilisent maintenant le même moteur
  Valhalla + OpenStreetMap en profil `pedestrian` que le Companion IITC.
- Tous les points de toutes les missions sont routés dans l'ordre, y compris les transitions
  fin de mission → début de mission suivante.
- Le calcul est découpé en groupes de 45 points pour rester compatible avec le moteur public.
- Valhalla fournit distance et temps de marche par tronçon.
- RBL calcule à partir de ces tronçons : distance piétonne totale, temps, moyenne par mission,
  mission la plus longue, plus long tronçon, transitions et détour du réseau piéton.
- La distance géométrique cumulée est conservée en comparaison et sert de fallback si Valhalla échoue.
- Un cache local par fresque + signature du parcours évite de recalculer les mêmes stats à chaque ouverture.

### 0.10.1 — hotfix Valhalla Android
- La version visible reste 0.10.1.
- Correction du faux « Valhalla indisponible » dans l'application Android.
- Cause : `fetch()` partait de la WebView Capacitor et pouvait être bloqué par CORS.
- Android utilise maintenant `CapacitorHttp.post()` fourni nativement par `@capacitor/core`.
- Le routage n'est donc plus dépendant des règles CORS de la WebView.
- Ajout du header `X-Client-Id: redacted-bannerlab` pour identifier proprement l'application
  auprès du serveur de démonstration public Valhalla.
- Le futur mode web utilise un GET `?json=...` en fallback afin d'éviter le preflight POST JSON.
- Le cache de routage passe de v1 à v2 pour forcer un nouveau calcul après ce correctif.
- En cas d'échec réel, l'interface affiche maintenant l'erreur Valhalla technique sous le fallback.

## 0.10.2 — hotfix Valhalla Android
- Numéro de version monté pour garantir une vraie mise à jour Android par-dessus 0.10.1.
- Conserve le correctif `CapacitorHttp` natif pour Valhalla/OSM pedestrian.
- Clé de signature et package Android historique inchangés.

## 0.10.3 — Valhalla public endpoint max 10 locations
- Correction de l'erreur `Valhalla HTTP 400 · Exceeded max locations: 10`.
- Le serveur public Valhalla accepte au maximum 10 points par requête.
- RBL découpe maintenant le parcours en paquets de 10 points.
- Chaque paquet reprend le dernier point du paquet précédent afin de ne perdre aucun tronçon.
- Exemple : points 1→10, puis 10→19, puis 19→28, etc.
- Distances et temps de tous les paquets sont additionnés pour conserver les statistiques complètes.
- Cache de routage monté en v3 pour forcer un recalcul après correction.

## 0.10.4 — routage piéton adapté à la portée Ingress
- Correction des distances Valhalla exagérées quand un portail est posé sur un POI non directement
  accessible par une arête piétonne OSM.
- Chaque portail est désormais corrélé avec `radius: 40`.
- `rank_candidates: false` permet au moteur de choisir le réseau piéton le plus logique dans cette zone
  au lieu de forcer l'arête la plus proche de la coordonnée exacte.
- `minimum_reachability: 0` conserve les petits chemins et impasses autour des POI.
- Le routage continue à utiliser le profil `pedestrian`, HTTP natif Android et des paquets de 10 points.
- La distance directe cumulée reste affichée comme contrôle.
- Cache monté en v4 afin de recalculer les fresques déjà mises en cache.

## 0.10.5 — routage piéton hybride contrôlé
- Suppression du rayon de corrélation 40 m qui pouvait raccourcir artificiellement les fresques denses.
- `Distance jouable RBL` devient `Distance piétonne estimée`.
- `Temps de marche RBL` devient `Temps de marche estimé`.
- Valhalla route normalement chaque liaison portail → portail.
- Chaque leg Valhalla est comparé à sa distance haversine :
  - si Valhalla est < 88 % de la distance directe, le tronçon est considéré comme un mauvais snapping ;
  - si Valhalla dépasse `max(distance directe × 4, distance directe + 350 m)`, le détour est considéré aberrant ;
  - ces tronçons uniquement repassent en distance directe + temps de marche à 4,8 km/h.
- Les autres tronçons conservent la vraie distance et le vrai temps Valhalla.
- Ajout des statistiques `Valhalla brut` et `Tronçons corrigés`.
- Cache routage monté en v5 pour recalculer toutes les fresques.

## 0.10.6 — crédits Bannergress
- Suppression du bouton « Voir sur Bannergress » dans Partager / groupe.
- Le lien Bannergress n'est plus ajouté au texte partagé : le partage groupe reste centré sur le deeplink RBL.
- Ajout d'une section « Crédits & remerciements » dans Infos.
- Remerciement explicite à Bannergress et à ses contributeurs pour les données publiques de fresques.
- Mention que RBL ne nécessite aucun compte Bannergress.
- Mention claire du caractère indépendant de Redacted BannerLab.
- Crédits ajoutés pour OpenStreetMap et Valhalla.
- Un lien volontaire vers Bannergress reste disponible dans Infos.

## 0.10.7 — texte par défaut & synchro Bannergress
- Nouveau texte par défaut des calques texte : `I LOVE REDACTED`.
- Publisher 0.4.6.
- Après le clic utilisateur « J’ai soumis », RBL vérifie que la mission est réellement `PUBLISHED` dans Mission Authoring avant toute synchronisation.
- Si une session Bannergress déjà enregistrée dans le navigateur est disponible, RBL synchronise la mission publiée vers l’API Bannergress sans ouvrir de nouvelle connexion.
- Aucune connexion Bannergress n’est forcée : sans session existante, la mission reste simplement en attente de synchronisation.
- Les missions déjà publiées mais non synchronisées sont retentées au redémarrage du Publisher.


## 0.10.9 — célébration de fin de fresque
- À la validation de la toute dernière mission dans l’overlay Android, Redacted apparaît au centre de l’écran.
- Ajout de feux d’artifice réellement animés en particules derrière Redacted pendant quelques secondes.
- La célébration est transparente, non interactive et ne bloque donc pas Ingress.
- L’animation ne se déclenche qu’au passage réel de la fresque à l’état terminé, pas à chaque pression ultérieure.
- Le bouton de validation de l’overlay affiche ensuite « 🏁 Fresque terminée ».
- Aucun nouveau visuel n’est ajouté : la célébration réutilise `redacted_dino_cutout`, le même Redacted que l’easter egg.

## 0.10.11 — annulation de progression dans l’overlay
- Ajout d’un bouton `↶ Annuler mission` dans l’overlay Android lorsqu’une mission affichée est déjà marquée terminée.
- L’annulation retire uniquement cette mission de la progression, y compris après une fresque entièrement terminée.
- Ajout d’un bouton `↺ Reset fresque` pour effacer toute la progression de la fresque en cours et revenir à la mission 1.
- Le reset complet demande un second appui `⚠ Confirmer reset` dans les 4 secondes afin d’éviter les effacements accidentels.
- Un reset complet remet aussi à zéro le chronomètre, la pause et l’état de fin de fresque.
- La célébration de fin est annulée si une mission est dévalidée ou si la fresque est réinitialisée.


## 1.0 — éditeur multi-calques
- Passage de Redacted BannerLab à la version majeure **1.0**.
- Le fond principal devient un calque sélectionnable qui reste verrouillé tout en bas de la pile.
- Ajout d’un nombre libre de calques image PNG/JPG/WebP au-dessus du fond, y compris les PNG transparents.
- Chaque calque peut être sélectionné, déplacé à un doigt, zoomé/tourné à deux doigts, masqué, réordonné, renommé, dupliqué ou supprimé.
- Le gestionnaire de calques affiche l’ordre de superposition et permet de sélectionner précisément l’image à modifier.
- Plusieurs calques image peuvent être cochés puis groupés. Un groupe se déplace, zoome et tourne comme un seul ensemble, et peut être dégroupé ensuite.
- Les calques et leurs images sont sauvegardés dans chaque projet IndexedDB et restaurés à la réouverture.
- Les anciens projets 0.10.x restent compatibles : leur image existante est reprise comme fond principal.
- L’export des missions et l’aperçu aplatissent automatiquement le fond, tous les calques image et les calques texte au rendu final.
- Clé de signature Android et identifiant de package historique inchangés afin de conserver les mises à jour APK.


## 1.0.1 — interface calques + passphrase automatique
- Correction des icônes SVG sur les boutons de l’éditeur de calques : tailles compactes sur Android.
- Mise en page mobile des actions de calques en grille compacte.
- Passphrase classique préremplie automatiquement : la question demande le numéro de la mission et la réponse vaut uniquement le numéro (`1`, `2`, `3`, etc.).
- La question est générée dans la langue du projet au moment de sa création (FR / EN / ES).
- Les passphrases personnalisées déjà renseignées ne sont jamais écrasées.
- Companion IITC mis à jour pour appliquer le même préremplissage lors de la création ou de la reprise du premier portail de mission.


## v1.0.2
- Groupes de calques beaucoup plus lisibles : couleur stable, cadre, bande latérale et badge Groupe 1/2/3… avec nombre de calques.
- Infos : mention « Créé par Zw4nn », accès au bot Telegram `https://t.me/redactedbannerlabbot` et section communauté/support.
- Signalement de problème : diagnostic technique copiable (version, plateforme/Android, langue, Companion IITC) puis ouverture de Telegram.


## 1.0.3 — sauvegarde complète
- Dossier de sauvegarde Android configurable via le sélecteur système (SAF), sans permission générale sur le stockage.
- Sauvegarde automatique optionnelle quand l’application passe en arrière-plan, uniquement si les données ont changé.
- Sauvegarde manuelle immédiate dans le dossier configuré.
- Export / import d’un JSON portable contenant tous les projets, réglages utiles et toutes les images (fond + calques).
- Restauration au choix par fusion ou remplacement complet des projets locaux.
- Nouveau logo Redacted BannerLab utilisé pour le launcher Android.
- Companion IITC reste en 0.6.3.


## 1.0.4 — autosave + studio plein écran + nouveau logo
- L’autosave ne dépend plus uniquement de `appStateChange`, trop tardif sur certains Android.
- Snapshot automatique préparé périodiquement pendant que BannerLab est encore au premier plan dès que des données changent.
- Flush supplémentaire sur `pause`, `appStateChange`, `visibilitychange` et `pagehide`.
- Une modification survenue pendant la création d’une sauvegarde déclenche automatiquement un second passage.
- Studio d’édition plein écran revu pour le portrait : une rangée de 6 missions occupe la hauteur du téléphone et les rangées suivantes deviennent des colonnes vers la droite avec scroll horizontal.
- Les anciens raccourcis de zoom `1` / `6` sont supprimés : le Studio propose désormais des modes explicites `Mission` et `Fresque`, plus zoom libre et mode Défilement tactile.
- Palettes latérales repliables pour les Calques, les Textes et les Outils.
- Les textes sont directement accessibles dans le Studio : ajout, sélection, modification, déplacement, rotation, duplication et suppression.
- Atelier typographique : choix de police, graisse, italique, alignement, espacement des lettres, interligne, contour et couleurs.
- Fond optionnel derrière le texte avec couleur, opacité, marge et radius réglables.
- Import de polices personnalisées TTF / OTF / WOFF / WOFF2 ; elles sont intégrées au projet et suivent les sauvegardes JSON.
- Le gestionnaire Image complet historique reste disponible depuis le Studio.
- Nouveau logo launcher sans texte : tête de Redacted recentrée, cercle lumineux et emblème ENL discret en arrière-plan. Le même visuel est utilisé comme logo principal dans l’application.
- Les ressources Android sont forcées à chaque build afin que le launcher installé et les métadonnées/icône de l’APK utilisent le même nouveau visuel.
- Companion IITC reste en 0.6.3.

- Barre inférieure simplifiée dans la révision v1.0.4 : `Image · Calques · Texte · Aperçu · Exporter`. L’ancien bouton `Cadrage`, qui ouvrait seulement les réglages de transformation de l’élément actif, est remplacé par un gestionnaire Calques plus explicite listant fond, images et textes. Les réglages de cadrage restent accessibles depuis l’élément concerné et par les gestes directs sur la fresque.
- Sélection de mission simplifiée et persistante : une seule mission à la fois. Le premier toucher sélectionne sans déplacer ; les gestes suivants sur cette mission la transforment. `Fresque` désélectionne la mission et revient au cadrage global. Même logique dans le mode normal.


## v1.0.5 — projet portable & bot Telegram

- Export / partage d’un seul projet au format `*.rbl.json`.
- Le projet portable contient les données de fresque, images de fond et calques, textes, polices personnalisées, missions, portails, GUID, coordonnées et actions. Le tracé est reconstructible depuis l’ordre et les coordonnées des portails.
- Import d’un projet portable comme nouveau projet, sans modifier les autres projets présents dans l’application.
- Le support Telegram pointe désormais vers `https://t.me/redactedbannerlabbot`.
- Companion IITC maintenu en v0.6.3.



## v1.0.7 — base courante

- Reprise de la v1.0.6 publiée et testée comme nouvelle base de développement.
- Conservation du support Telegram via `@redactedbannerlabbot`.
- Conservation de la section Communauté & support simplifiée, sans Buy Me a Coffee.
- Conservation du nettoyage de la planification : suppression de l’ajout manuel de portail et du bouton de reprise manuelle du portail précédent.
- Companion IITC maintenu en v0.6.3.
- Clé de signature Android et identifiant Android inchangés.

## v1.0.6 — support simplifié

- Suppression complète de l’ancienne carte de soutien financier.
- La carte Communauté & support n’affiche plus un second gros bouton vers le bot ; le lien `t.me/redactedbannerlabbot` reste accessible directement.
- Dans « Signaler un problème », le bouton Telegram devient « Contacter le support » et reste l’accès principal au bot.
- Companion IITC maintenu en v0.6.3.

## v1.0.7 — Tutoriels guidés
- Première ouverture : proposition d’une visite guidée avec Commencer / Plus tard / Ne plus afficher.
- Moteur de tutoriels contextuels en overlay, basé sur les vrais éléments de l’interface et adaptable aux tailles d’écran.
- Tutoriels relançables depuis Réglages & infos : découverte rapide, création de fresque, images/calques/textes, IITC Companion, publication, sauvegardes/projets portables.
- Utilisation du Redacted déjà présent dans les assets ; aucun nouvel asset généré.
- Import d’image clarifié : Fond principal est l’action mise en avant, Calque reste disponible pour les images supplémentaires.


## v1.0.8 — export projet Android

- Le bouton **Exporter** d’un projet portable ouvre maintenant le sélecteur de documents Android (`ACTION_CREATE_DOCUMENT`) afin de choisir le dossier de destination et, si besoin, le nom du fichier.
- Le bouton **Partager** conserve la feuille de partage Android.
- Le format `.rbl.json` et l’import des projets restent inchangés.
- Companion IITC reste en v0.6.3.


## Ajustement UI v1.0.8
- Le bouton `ⓘ` de l’en-tête est remplacé par une roue `⚙️`, plus cohérente avec son rôle.
- Le panneau s’intitule désormais `Réglages & infos`.
- Les tutoriels guidés utilisent ce nouveau libellé.


## Ajustement Images / calques & Studio v1.0.8
- Suppression de l’onglet inférieur `Calques`, devenu redondant.
- La barre inférieure devient `Images · Texte · Aperçu · Exporter`.
- Le panneau Images est renommé `Images & calques` et devient l’unique gestionnaire des images : fond, calques, sélection, visibilité, ordre et groupement.
- Ajout d’une miniature réelle pour le fond et chaque calque image afin d’identifier immédiatement l’élément manipulé.
- Ajout des mêmes miniatures dans le tiroir Calques du Studio plein écran.
- Mise à jour de tous les tutoriels guidés pour supprimer toute référence à l’ancien onglet Calques et guider vers `Images & calques`.
- Centrage horizontal et vertical automatique de la zone de travail du Studio lorsque la fresque tient dans l’espace disponible ; le scroll reste actif dès qu’elle dépasse.
- Cache PWA : `redacted-bannerlab-v1.0.8-r4`.


## Correctif miniatures v1.0.8

- Les miniatures du fond et des calques utilisent désormais une URL de prévisualisation persistante créée depuis le Blob original.
- Correction des icônes d’image cassée / texte alternatif qui apparaissaient à la place des miniatures dans Images & calques et dans le Studio.
- Cache PWA : `redacted-bannerlab-v1.0.8-r4`.


## Hotfix miniatures v1.0.8 (mise à jour APK)

- La version visible reste `1.0.8`.
- Le `versionCode` Android est forcé à `10804` afin que cette révision puisse s’installer par-dessus une précédente APK v1.0.8.
- Les miniatures Images & calques utilisent leur propre URL Blob persistante et s’affichent correctement.
- Cache PWA : `redacted-bannerlab-v1.0.8-r4`.


## v1.0.11 — Calques liés aux missions

- Ajout de deux portées pour les calques image : `global` (fresque entière) et `mission`.
- Un calque de mission est associé à un numéro de mission, centré automatiquement sur sa case et clipé à 512 × 512 sans pouvoir déborder sur les missions voisines.
- Modes d'ajustement `Remplir` (cover, par défaut) et `Contenir`.
- Ajout de `Sur une mission` dans Images & calques pour importer directement une image sur une mission précise.
- Ajout de `Importer une série` pour importer 6, 12, 18 images ou davantage et les associer automatiquement aux missions 1, 2, 3…
- L'écran de série permet de changer l'association de chaque fichier et de réordonner les images avant import.
- Les calques de mission affichent un badge `M1`, `M2`, etc. dans Images & calques et dans le Studio plein écran.
- Les calques peuvent être convertis après coup entre Fresque entière et Calque de mission depuis leurs actions.
- Les calques liés à une mission restent éditables (déplacement, zoom, rotation, opacité, ordre) tout en restant clipés dans leur mission.
- Le changement du nombre de rangées ré-ancre automatiquement les calques de mission sur leur numéro de mission.
- Les projets, projets portables et sauvegardes JSON conservent la portée, le numéro de mission et le mode d'ajustement.
- Les tutoriels Images & calques expliquent désormais l'import sur une mission et l'import en série.
- `versionCode` Android : `11000` ; `versionName` : `1.0.11`.
- Cache PWA : `redacted-bannerlab-v1.0.11`.
- Companion IITC maintenu en v0.6.3.

## v1.0.9 — Recherche Bannergress géographique

- Suppression de la recherche dédiée par auteur, non pertinente sans session Bannergress authentifiée.
- Ajout d’un rayon de recherche de 1 à 50 km, 5 km par défaut, applicable à une ville ou à la position actuelle.
- Les résultats géographiques sont limités par boîte englobante puis contrôlés côté BannerLab avec la distance réelle jusqu’au point de départ de la fresque.
- Résolution de ville tolérante aux espaces, tirets, accents et abréviations `St` / `Ste` (`St Nazaire`, `Saint Nazaire`, `Saint-Nazaire`, etc.).
- Vérification native Android de l’activation des services de localisation avant la demande GPS afin d’éviter les timeouts inutiles.
- Messages distincts pour localisation désactivée, permission refusée, position indisponible et timeout, avec accès aux réglages Android adaptés.
- Distance par rapport au centre de recherche affichée dans les résultats.
- `versionCode` Android : `10900` ; `versionName` : `1.0.9`.
- Cache PWA : `redacted-bannerlab-v1.0.9`.
- Companion IITC maintenu en v0.6.3.


## v1.0.11 — révision 2

- Version visible maintenue en `1.0.11`.
- `versionCode` Android : `11001`, pour permettre l'installation par-dessus la première v1.0.11.
- La sélection multiple de calques ne reconstruit plus le panneau à chaque coche : plus de retour automatique en haut.
- La sélection multiple devient une vraie sélection d'actions : modification commune, groupement et suppression.
- Modification commune : portée globale/mission, mission cible, mode Remplir/Contenir, visibilité et opacité.
- L'ajout de calque est unifié : Fresque complète / Une mission / Plusieurs missions (série).
- Les mêmes actions de sélection sont accessibles dans le Studio plein écran.
- Tutoriel Images & calques adapté au nouveau bouton Ajouter un calque.


### v1.0.11 — révision 3
- Le bloc d’actions de sélection multiple n’apparaît qu’à partir de deux calques cochés, dans Images & calques et dans le Studio plein écran.
- `versionCode` Android : `11002` ; `versionName` : `1.0.11`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r3`.


## v1.0.11 — Multilingue
- 20 langues disponibles dans Réglages & infos.
- Détection automatique de la langue du téléphone au premier lancement.
- Interface principale, recherche, projets, calques, tutoriels et support localisés dans les langues principales ; les chaînes techniques rares utilisent l’anglais en secours.
- Support Telegram ouvert avec la langue de BannerLab dans le deep-link.
- Prise en charge RTL pour l’arabe.


## v1.0.11 — révision multilingue / Companion 0.6.4

- `versionName` Android : `1.0.11`.
- `versionCode` Android : `11101` pour mise à jour par-dessus la première v1.0.11.
- Cache PWA : `redacted-bannerlab-v1.0.11-r2`.
- Companion IITC : `0.6.4`.
- Companion traduit dans les 20 langues de BannerLab.
- Missions du Companion affichées sur une grille de 6 colonnes : 7 sous 1, 13 sous 7, etc.
- Progression IITC conservée localement et protégée contre l'écrasement lors d'une simple réouverture depuis BannerLab.
- Dernier état reçu de BannerLab conservé séparément pour une restauration volontaire.
- Boutons Companion « Recharger depuis BannerLab » et « Réinitialiser l’avancée » avec confirmation en deux temps.
- Sauvegarde de sécurité du Companion au masquage, `pagehide` et fermeture.
- Codes chinois harmonisés à la frontière Telegram : `zh-Hans` → `zh-CN`, `zh-Hant` → `zh-TW`.
- Allemand, néerlandais et portugais : couverture complète des 799 chaînes de l'application, sans fallback anglais.

### Révision v1.0.11 multilingue / Companion 0.6.4
- Le bouton « Installer / mettre à jour le plugin IITC » ouvre désormais le sélecteur Android « Enregistrer dans… » au lieu de la feuille de partage.
- Le fichier `redacted-bannerlab-iitc.user.js` est enregistré directement avec son vrai nom.
- IITC Companion passe en 0.6.4.
- La progression Companion est conservée localement pour un même projet et ne doit plus être écrasée par une simple réouverture depuis BannerLab.
- Ajout de « Recharger depuis BannerLab » et « Réinitialiser l’avancée ».
- Les missions du Companion sont disposées par rangées de 6 (7 sous 1, 13 sous 7).
- Les codes de langue des liens Telegram sont normalisés (`zh-Hans` → `zh-CN`, `zh-Hant` → `zh-TW`).


## v1.0.11 — révision testable multilingue / Companion 0.6.4
- Version visible : `1.0.11`.
- Version Android interne : `11102`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r4`.
- Companion IITC : `0.6.4`.
- Allemand, portugais et néerlandais disposent d’une couverture complète de l’interface actuelle.
- Les autres langues restent disponibles et continuent d’être enrichies ; les chaînes non encore localisées utilisent l’anglais en secours.
- Les liens Support transmettent la langue au bot et normalisent `zh-Hans` vers `zh-CN` et `zh-Hant` vers `zh-TW`.
- Le Companion conserve sa progression locale, restaure le même projet sans écraser l’avancement et propose Recharger depuis BannerLab / Réinitialiser l’avancée.
- Les missions du Companion utilisent une grille de 6 colonnes : 7 sous 1, 13 sous 7.
- L’installation/mise à jour du plugin IITC ouvre Android « Enregistrer dans… » et ne passe plus par la feuille de partage.


## v1.0.11 — révision testable r5
- Version visible : `1.0.11`.
- Version Android interne : `11103`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r5`.
- Companion IITC : `0.6.4`.
- Grille Companion de 6 colonnes : 7 sous 1, 13 sous 7.
- Sauvegarde locale et restauration de la progression Companion.
- Boutons Recharger depuis BannerLab / Réinitialiser l’avancée.
- Installation du plugin IITC via Android « Enregistrer dans… ».
- Liens Telegram Support avec code langue normalisé.
- Passe multilingue étendue intégrée à l’application et au Companion.


## v1.0.11 — révision testable r6
- Version visible : `1.0.11`.
- Version Android interne : `11104`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r6`.
- Italien : traduction complète de l’interface actuelle, Studio, Publisher, recherche Bannergress, sauvegardes, tutoriels et calques liés aux missions.
- Français, anglais, allemand, néerlandais, portugais, espagnol et italien disposent désormais d’une couverture complète des chaînes actives.
- Les 13 autres langues restent disponibles avec fallback anglais lorsqu’une chaîne n’est pas encore localisée.
- Suppression de plusieurs textes codés en dur dans les exports, diagnostics, listes de missions et messages d’erreur afin de respecter la langue active.
- Correction de l’emoji de l’état sans bannière : Redacted est bien un dinosaure, pas un crocodile.


## v1.0.11 — révision r7 / Companion 0.6.5
- Version visible BannerLab maintenue en `1.0.11`.
- Version Android interne : `11105`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r7`.
- Companion IITC : `0.6.5`.
- Correction du parcours d’installation du Companion sur Android.
- « Installer / mettre à jour le plugin IITC » propose maintenant deux choix : ouverture directe avec IITC Mobile ou enregistrement du fichier `.user.js`.
- L’ouverture directe crée une copie temporaire privée du plugin et la transmet à l’écran officiel d’installation des plugins externes d’IITC Mobile via `ACTION_VIEW` + `text/javascript`.
- Le mode « Enregistrer le fichier » conserve le sélecteur Android « Enregistrer dans… » comme solution de secours.
- Le fichier transmis garde exactement le nom `redacted-bannerlab-iitc.user.js`.
- Les nouvelles chaînes sont traduites dans les 7 langues complètes de BannerLab.


## v1.0.11 — révision r8 / correctif installation Companion
- Version visible BannerLab maintenue en `1.0.11`.
- Version Android interne : `11106`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r8`.
- Companion IITC : `0.6.5` (contenu fonctionnel inchangé).
- Correction du fichier Companion enregistré à 0 octet sur certains fournisseurs de documents Android.
- Sur Android, le `.user.js` n'est plus relu par `fetch()` ni transféré comme une grosse chaîne via le pont JavaScript.
- Le plugin est lu directement depuis les assets embarqués de l'APK par le code natif.
- Avant toute ouverture ou sauvegarde, BannerLab vérifie que le plugin embarqué dépasse 1 Ko et retourne sa taille réelle.
- L'ouverture directe avec IITC écrit d'abord une copie cache, vérifie sa taille exacte puis la transmet à IITC avec une URI FileProvider en lecture seule.
- L'option « Enregistrer le fichier » copie directement les octets embarqués vers le document choisi et vérifie le nombre d'octets transmis.
- Le dialogue d'installation affiche désormais la taille du plugin embarqué afin de rendre immédiatement visible une anomalie.


## v1.0.11 — révision r10 / Companion 0.6.6
- Version visible BannerLab maintenue en `1.0.11`.
- Version Android interne : `11108`.
- Cache PWA : `redacted-bannerlab-v1.0.11-r10`.
- Companion IITC : `0.6.6`.
- Correction de la reprise de parcours : relancer IITC depuis BannerLab ne doit plus ramener un parcours en cours (ex. 8/18) à la mission 1.
- La mission courante dispose maintenant d'un checkpoint séparé, identifié par l'ID du projet et par une empreinte stable du parcours.
- Pour un même parcours, l'état local est toujours prioritaire lors d'une simple réouverture ; un remplacement depuis BannerLab reste une action volontaire via « Recharger depuis BannerLab ».
- La reprise ne dépend plus du fait que les tableaux de missions soient considérés comme « non vides ».
- L'ouverture directe du plugin IITC utilise maintenant une copie réelle et vérifiée dans Téléchargements, identique au parcours d'installation manuelle qui fonctionne, au lieu d'une URI temporaire de cache.

## v1.0.12 — Companion 0.6.6 / reprise et installation Android
- Version visible BannerLab : `1.0.12`.
- Version Android interne : `11200`.
- Cache PWA : `redacted-bannerlab-v1.0.12`.
- Companion IITC : `0.6.6`.
- Refonte du mécanisme d’installation du Companion sur Android : le fichier `.user.js` est vérifié depuis les assets réellement embarqués dans l’APK avant toute installation.
- Le dialogue d’installation affiche la version et la taille réelle du Companion afin de détecter immédiatement un fichier absent ou invalide.
- L’ouverture vers IITC s’appuie sur une copie réelle et vérifiée du fichier au lieu d’une copie temporaire fragile.
- L’enregistrement manuel du Companion utilise une copie vérifiée dans Téléchargements.
- Correction majeure de la reprise de parcours : relancer IITC depuis BannerLab ne doit plus réinitialiser un parcours en cours à la mission 1.
- La mission courante est sauvegardée dans un checkpoint séparé lié à l’identifiant du projet et à une empreinte stable du parcours.
- Pour le même parcours, la progression locale IITC reste prioritaire lors d’une simple réouverture.
- « Recharger depuis BannerLab » reste l’action volontaire permettant de remplacer l’état local par celui envoyé par BannerLab.
- Compatibilité de reprise avec les sauvegardes créées par le Companion 0.6.5.



## v1.0.12 — hotfix Companion 0.6.7
- Companion IITC : `0.6.7`.
- Reprise par identifiant de session IITC stable propre à chaque projet BannerLab.
- Sauvegarde complète séparée par session dans IITC, en plus du checkpoint de mission.
- Un lancement depuis BannerLab ne peut plus écraser la mission courante d'une session déjà connue.
- Migration renforcée depuis les états 0.6.5 / 0.6.6.
- `versionCode` Android : `11201`, `versionName` : `1.0.12`.


## v1.0.12 — hotfix autosauvegarde Companion 0.6.7
- Companion IITC maintenu en `0.6.7`.
- Ajout d'une autosauvegarde dédiée et redondante du parcours dans le plugin, indépendante de l'état renvoyé par BannerLab.
- Sauvegarde complète à chaque changement et heartbeat automatique toutes les 3 secondes, plus sauvegarde lors du masquage, `pagehide` et fermeture de la WebView.
- Une copie de secours de l'autosauvegarde est conservée pour éviter qu'une écriture interrompue ne perde le dernier état valide.
- Au lancement depuis BannerLab, l'autosauvegarde locale du même parcours est prioritaire et le `c=0` envoyé par l'application ne peut plus remettre la mission courante à 1.
- Filet de sécurité d'identification : même si les identifiants de session changent anormalement, nom du projet + nombre de missions + portails par mission permettent encore de reprendre le parcours.
- Le Companion affiche maintenant directement dans son en-tête l'état de sauvegarde (`💾 M8 ✓`) et, dans les options, l'heure exacte de la dernière autosauvegarde.
- Correction des signatures de parcours vides qui pouvaient être identiques entre plusieurs bannières.
- `versionCode` Android : `11202`, `versionName` : `1.0.12`.


### Hotfix v1.0.12 / Companion 0.6.7 — reprise + synchro IITC

- Corrige la restauration d'une autosauvegarde dont la mission courante était supérieure à la longueur du tableau restauré : un checkpoint M8 reste désormais réellement M8.
- Le lancement RBL → IITC transporte maintenant le payload dans la query string plutôt que dans le fragment `#`, afin d'éviter sa perte par IITC Mobile.
- `Synchroniser BannerLab` utilise désormais un Intent Android explicite vers `com.bannerforge.mobile`, avec fallback sur le schéma `redactedbannerlab://`.
- Le payload de synchronisation est compacté et le SID IITC stable est réimporté dans BannerLab.
- Version visible inchangée : Redacted BannerLab 1.0.12 / Companion 0.6.7. Android `versionCode` : 11203.


### Hotfix v1.0.12 / Companion 0.6.7 — autosynchro de progression IITC → RBL

- Companion maintenu en `0.6.7`.
- À chaque fin de mission et changement de mission, IITC envoie automatiquement un checkpoint vers BannerLab.
- Le checkpoint est reçu par une Activity Android transparente dédiée : l’interface BannerLab ne s’ouvre pas pendant le parcours.
- Les checkpoints sont mis en file dans le stockage natif de BannerLab puis consommés au prochain réveil/ouverture de l’application.
- BannerLab met à jour le bon projet grâce à son `pid`, même si un autre projet est actuellement affiché.
- Avant « Lancer le Companion », RBL vide systématiquement sa boîte de réception afin de renvoyer à IITC la mission la plus récente connue.
- La sauvegarde locale IITC reste active en parallèle comme filet de sécurité.
- La synchronisation manuelle conserve son comportement : elle ouvre BannerLab et envoie l’état complet.
- Version visible inchangée : Redacted BannerLab `1.0.12` / Companion `0.6.7`. Android `versionCode` : `11204`.


### Hotfix v1.0.12 / Companion 0.6.7 — autosynchro silencieuse sans retour RBL
- Corrige le retour intempestif vers Redacted BannerLab lors de la fin d'une mission ou de la navigation dans le Companion.
- L'Activity Android de réception autosync n'utilise plus la tâche principale RBL (`taskAffinity` vide + `Theme.NoDisplay`).
- L'autosynchro automatique ne se déclenche plus lors d'un simple précédent/suivant/sélection de mission ni lors du passage en arrière-plan : uniquement à la fin d'une mission.
- L'autosynchro envoie désormais un delta compact de la mission terminée au lieu du projet complet ; la synchro manuelle conserve l'état complet.
- BannerLab sait fusionner ces deltas dans l'historique complet du projet.
- Version visible inchangée : Redacted BannerLab `1.0.12` / Companion `0.6.7`. Android `versionCode` : `11205`.


### v1.0.12 — correctif stabilité IITC (versionCode 11206)

- Companion maintenu en `0.6.7`.
- Suppression de l'autosynchronisation inter-app déclenchée automatiquement à la fin d'une mission : les `intent://` depuis la WebView IITC provoquaient une navigation Android au passage 6/6 et pouvaient quitter/recharger ou faire planter IITC.
- L'autosauvegarde locale du Companion reste active et conserve l'historique complet des missions et la mission courante.
- `Synchroniser BannerLab` reste disponible manuellement et envoie le projet complet vers RBL lorsqu'on le demande explicitement.
- Version visible : BannerLab `1.0.12`, Companion `0.6.7`; Android `versionCode` : `11206`.


### v1.0.12 — reprise locale + synchronisation bidirectionnelle manuelle (versionCode 11207)
- Companion maintenu en `0.6.7`.
- Un lancement normal depuis RBL est désormais un mode `resume` : si IITC possède une sauvegarde locale du projet, elle est prioritaire intégralement. RBL ne peut plus remettre la progression à M1 lors d'une simple réouverture.
- La synchro IITC → RBL reste strictement manuelle via `↑ Envoyer vers RBL`; aucune autosynchro inter-app ne se déclenche en fin de mission.
- Nouveau bouton `↓ Charger depuis RBL` dans le Companion. Après confirmation, IITC ouvre RBL avec une requête `pull`; RBL retrouve le projet par `pid`/`sid` et relance IITC avec un payload `mode=replace`. Cette action explicite remplace alors la sauvegarde locale IITC par la version actuelle du projet RBL.
- Les anciens intents `autosync` en attente sont vidés/ignorés et ne modifient plus un projet automatiquement.

### v1.0.12 — installateur IITC direct via SAF (versionCode 11208)
- Companion maintenu en `0.6.7`.
- Identité userscript verrouillée définitivement : `@id redacted-bannerlab-iitc` et `@name Redacted BannerLab Companion`.
- Le bouton « Installer / mettre à jour » n'utilise plus l'import externe IITC comme chemin principal.
- Première utilisation : BannerLab demande via le Storage Access Framework l'accès persistant au dossier `IITC_Mobile` (ou directement `IITC_Mobile/plugins`).
- BannerLab crée si nécessaire `plugins/redacted-bannerlab-iitc.user.js`, puis ouvre le fichier existant en écriture/troncature lors des mises à jour.
- Vérification après écriture par taille ET SHA-256 du fichier relu depuis le dossier IITC.
- Statut visible dans RBL : version installée, version disponible et « À jour ✓ ». Une build différente portant encore la même version 0.6.7 est détectée grâce au hash.
- Migration automatique de l'ancienne identité `redacted-bannerlab-bridge` lorsqu'un ancien fichier connu est détecté dans le dossier plugins.
- L'autorisation SAF est persistée : pas de sélection du dossier à chaque mise à jour.
- L'enregistrement manuel d'une copie `.user.js` dans Téléchargements reste disponible comme solution de secours.


## Correctif synchro IITC → RBL (1.0.12 / Companion 0.6.7)

La synchro manuelle est maintenant réceptionnée nativement dans une inbox Android avant le retour de RBL au premier plan. Le payload complet n'est plus dépendant de l'événement WebView `appUrlOpen`. Au `resume` ou au démarrage de RBL, le dernier envoi manuel est décodé puis fusionné dans le bon projet. Les anciens événements `autosync` sont ignorés.

Android versionCode : 11209.


## Correctif synchro IITC -> RBL visible
La synchro manuelle ouvre maintenant le projet correspondant au pid/sid recu avant de fusionner l'etat IITC. L'ancienne branche de mise a jour silencieuse ne peut plus laisser l'utilisateur sur un autre projet a 0/6. VersionCode Android: 11210. Companion inchange: 0.6.7.


### v1.0.12 — synchro IITC visible sur l’onglet Missions (versionCode 11211)
- Après une synchro manuelle IITC → RBL réussie, RBL ouvre directement l’étape **Missions** au lieu de l’étape Parcours.
- Le projet correspondant au pid/sid reste chargé avant la fusion de l’état IITC.
- Companion inchangé : `0.6.7`. Aucune réinstallation du plugin n’est nécessaire pour ce correctif.


### v1.0.12 — synchro IITC native redondante (versionCode 11212)
- Companion inchangé : 0.6.7.
- Le récepteur Android transmet désormais l’URI `redactedbannerlab://sync?...` à `MainActivity` en plus de l’enregistrer dans l’inbox native.
- RBL consomme aussi l’inbox lors de `visibilitychange` et `focus`, en plus des événements Capacitor.
- Une synchro manuelle dont l’ancien `pid`/`sid` n’est plus résolu retombe sur le projet RBL actuellement ouvert au lieu d’être silencieusement ignorée.
- Après import manuel réussi, ouverture de l’onglet Missions.


### v1.0.12 — restauration du pont manuel IITC ↔ RBL (versionCode 11213)

- `sync` et `pull` repassent directement par `MainActivity` : plus de récepteur natif intermédiaire pour les actions manuelles.
- Le récepteur invisible reste réservé à l'ancien host `autosync`, désormais inutilisé par le Companion.
- `Charger depuis RBL` fonctionne aussi avec un ancien projet dont le `pid`/`sid` ne correspond plus : le projet actuellement ouvert sert de cible de migration.
- La synchro manuelle IITC → RBL conserve le fallback vers le projet ouvert puis réassocie le SID reçu.
- Aucun projet existant ne doit être supprimé ou recréé.
- Companion inchangé : 0.6.7.


### v1.0.12 — restauration transport IITC historique + purge cache natif (versionCode 11214)
- Retour au transport RBL → IITC par fragment `#rbl=...`, comme dans la dernière source où la synchro fonctionnait.
- Retour IITC → RBL et `Charger depuis RBL` par `redactedbannerlab://` direct, sans `intent://` ni inbox intermédiaire.
- Toutes les URLs `redactedbannerlab://` sont à nouveau reçues directement par MainActivity.
- Purge ciblée des anciens Service Workers / CacheStorage Android, sans toucher aux projets IndexedDB/localStorage.
- Après import IITC → RBL, ouverture forcée de l’onglet Missions.
- Companion reste numéroté 0.6.7 ; son contenu change et doit donc être mis à jour via l’installateur SAF.

### v1.0.12 — missions non contiguës + rechargement RBL à chaud (versionCode 11215)

- Le pont manuel **IITC → RBL**, désormais validé sur appareil, est laissé inchangé.
- Suppression/réorganisation d’un portail dans le planner : conservation de la position de défilement de la feuille au lieu de revenir systématiquement en haut.
- Une mission vide au milieu du parcours ne tronque jamais les missions suivantes : le Companion conserve explicitement le tableau complet jusqu’à `n` missions.
- **Charger depuis RBL** fonctionne aussi lorsque IITC est déjà ouvert : le Companion surveille les nouveaux payloads `#rbl=` sur `hashchange`, retour au premier plan et visibilité, puis applique immédiatement le mode `replace`.
- Chaque ouverture RBL → IITC reçoit un identifiant de transport unique (`tx`) afin qu’un nouveau chargement soit distingué d’une URL déjà traitée.
- Après un chargement explicite depuis RBL, le Companion affiche le nombre de missions et le nombre total de portails réellement reçus.
- Cache web Android : `redacted-bannerlab-v1.0.12-11215`.


### v1.0.12 — mémoire du Lab + lancement mission vide (versionCode 11216)
- Companion inchangé en version visible `0.6.7`.
- Une reprise normale d'un projet déjà connu utilise explicitement la mémoire locale IITC et l'indique dans le panneau avec un message « laboratoire ».
- Le message rappelle que des modifications réalisées directement dans le Lab doivent être récupérées volontairement avec `↓ Charger depuis le Lab`.
- Les libellés français deviennent `↓ Charger depuis le Lab` et `↑ Envoyer vers le Lab`.
- Chaque lancement IITC reçoit désormais un nonce `rblopen`, y compris depuis une mission vide. Cela évite qu'un lancement depuis M1 vide soit confondu avec une ancienne URL Intel et ouvre un Companion vierge.
- Cache web Android : `redacted-bannerlab-v1.0.12-11216`.


### v1.0.12 — installation directe dans IITC (versionCode 11217)
- Ajout d’un bouton « Installer dans IITC » dans la fiche Companion.
- Après l’écriture/mise à jour vérifiée via SAF dans IITC_Mobile/plugins, RBL ouvre directement l’écran des plugins utilisateur IITC, catégorie Mission.
- Plus besoin de rechercher le fichier .user.js dans un explorateur. À la première installation seulement, IITC peut encore demander d’activer le plugin ; les mises à jour conservent normalement l’état d’activation grâce au nom de fichier stable.
- Le bouton d’écriture SAF seul reste disponible ainsi que l’enregistrement d’une copie de secours.
- Redacted BannerLab 1.0.12, Companion 0.6.7 inchangé, Android versionCode 11217.


### v1.0.12 — ouverture IITC sûre après installation (versionCode 11219)
- Correction du crash/écran blanc observé juste après « Installer dans IITC ».
- RBL n’impose plus directement `PluginsFragment` + catégorie `Mission` à l’Activity interne d’IITC.
- Après écriture SAF vérifiée, ouverture de l’écran Plugins normal d’IITC afin de laisser IITC reconstruire sa liste de plugins avant toute navigation.
- Si cet écran n’est pas disponible, repli sûr sur l’Activity principale IITC.
- Installation/mise à jour SAF, synchronisation IITC ↔ Lab et Companion 0.6.7 inchangés.

### v1.0.12 — ouverture IITC normale après installation (versionCode 11219)
- Le bouton « Installer dans IITC » conserve l’installation/mise à jour directe via SAF.
- Après écriture vérifiée du Companion, RBL ouvre désormais uniquement l’activité de lancement normale d’IITC.
- Suppression de toute ouverture externe de `PluginPreferenceActivity` / fragments internes IITC, qui pouvait provoquer un écran blanc ou un crash.
- Le Companion 0.6.7 est strictement inchangé par rapport au build 11218.


### v1.0.12 — installateur externe IITC restauré (versionCode 11220)

- Le bouton **Installer via IITC** remet le flux d’import externe qui affichait réellement la confirmation native d’IITC : RBL enregistre une copie vérifiée du Companion dans Téléchargements via MediaStore, puis l’envoie à `PluginPreferenceActivity` avec `ACTION_VIEW`.
- Première installation : IITC demande confirmation, puis le plugin peut être activé dans **Plugins → Mission**.
- Si le Companion est déjà présent, RBL conserve la mise à jour directe via SAF car l’import externe IITC ne sait pas remplacer un fichier existant ; IITC est ensuite ouvert normalement.
- `versionCode` Android : `11220`, supérieur aux builds 11218/11219. `versionName` reste `1.0.12`; Companion reste `0.6.7`.
- Cache web Android : `redacted-bannerlab-v1.0.12-11220`.

### v1.0.12 — installateur IITC réellement forcé (versionCode 11221)
- Le bouton **Installer via IITC** utilise désormais toujours le véritable import externe d’IITC, même si le Companion est déjà présent.
- Correction du build 11220 : il basculait sur la branche SAF + simple ouverture d’IITC dès qu’un Companion installé était détecté, d’où l’absence totale de dialogue d’installation.
- Nouveau provider Android `IitcInstallProvider` : le paquet Companion est présenté à `PluginPreferenceActivity` via `ACTION_VIEW` + `text/javascript`.
- L’ancien `redacted-bannerlab-iitc.user.js` n’est supprimé qu’au moment où IITC ouvre réellement le paquet, donc **après validation du dialogue IITC**. Annuler le dialogue ne touche pas au plugin existant.
- Cela contourne proprement l’importeur IITC actuel qui crée un nouveau fichier mais ne remplace pas un fichier canonique déjà présent.
- Le bouton séparé **Installer / mettre à jour** via SAF reste disponible pour le remplacement direct sans dialogue IITC.
- `versionCode` Android : `11221`; `versionName` reste `1.0.12`; Companion reste `0.6.7`.
- Cache web Android : `redacted-bannerlab-v1.0.12-11221`.


### v1.0.12 — aperçu Bannergress complet + Banner info (versionCode 11222)

- Dans « Rechercher une fresque », l’image du détail Bannergress conserve désormais son ratio et se trouve dans une zone défilable au doigt lorsqu’elle dépasse la hauteur disponible.
- Le champ Bannergress « Banner info » est récupéré depuis le détail de la bannière et affiché intégralement sous l’aperçu lorsqu’il est disponible.
- La lecture accepte `bannerInfo`, `banner_info`, `info` et `description` afin de rester tolérante aux variantes de réponse de l’API.
- Aucun changement du Companion IITC 0.6.7, de la synchro ou de l’installateur IITC.
- Android `versionCode` : `11222`; cache web : `redacted-bannerlab-v1.0.12-11222`.


### v1.0.12 — Banner info Bannergress réellement récupéré (versionCode 11223)
- Correction de la fusion recherche/détail Bannergress : un `bannerInfo` vide provenant du résultat de recherche ne masque plus le champ `description` du détail complet.
- Le champ affiché « Banner info » utilise en priorité `description`, qui est le champ réellement exploité par l’interface Bannergress/OpenBanners pour la description de la bannière.
- L’aperçu image scrollable du build 11222 est conservé sans modification.
- Android `versionCode` : `11223`; cache web : `redacted-bannerlab-v1.0.12-11223`.
- Companion IITC 0.6.7 et mécanismes de synchro/installation inchangés.


## v1.0.12 · build 11224 — branding IGOR

- Le Companion IITC 0.6.7 adopte le nom visible **IGOR — IITC Gateway for Operations & Routing**.
- Sous-titre : **Assistant IITC du Lab**.
- Boutons français : **↓ Charger le Lab dans IGOR** et **↑ Envoyer IGOR vers le Lab**.
- IGOR affiche le nombre de missions réellement présent dans sa mémoire locale IITC.
- Le Lab affiche explicitement l’état de connexion d’IGOR à IITC.
- Les identifiants techniques (`@id`, nom de fichier, clés de stockage/autosave) restent strictement inchangés afin de préserver installation, mise à jour et progression locale.
- Version publique de Redacted BannerLab maintenue à **1.0.12** ; la présentation publique de la naissance d’IGOR est réservée à une version ultérieure.


## v1.0.12 — build 11226 · IGOR visible + updater intégré
- Le visuel IGOR fourni par le projet est utilisé tel quel dans le Lab et dans le userscript IITC.
- Le tutoriel IITC est désormais présenté par IGOR.
- Ajout d'un updater GitHub Releases dans Réglages & infos, piloté par IGOR.
- Le dépôt est injecté automatiquement depuis `GITHUB_REPOSITORY` pendant le build Android : aucun owner/repo n'est codé en dur.
- Vérifications avant installation : digest SHA-256 GitHub, package `com.bannerforge.mobile`, versionCode supérieur et certificat de signature identique.
- Téléchargement et installation automatiques activés par défaut, avec fallback Android vers confirmation utilisateur si nécessaire.
- Autorisations Android ajoutées : `REQUEST_INSTALL_PACKAGES` et `UPDATE_PACKAGES_WITHOUT_USER_ACTION`.
- Version visible maintenue en 1.0.12 ; versionCode Android 11226.

## v1.0.12 — build 11226 · correctif compilation updater + source public assaini
- Correction Java dans `UpdateManagerPlugin.getStatus()` : conflit de variable `staged` supprimé.
- Le dossier `signing/` et tout keystore ont été retirés du ZIP source public.
- `.gitignore` bloque désormais les keystores et fichiers de secrets.
- La signature Android doit être injectée uniquement au runtime du workflow via GitHub Actions Secrets.


## Hotfix build 11226 — compilation updater
- Corrige la collision de variable Java dans `UpdateManagerPlugin.getStatus()` : le `PackageInfo` temporaire est désormais nommé `stagedInfo` au lieu de redéclarer `staged`.
- Version publique inchangée : 1.0.12.
- Aucun changement du Companion/IGOR, de la synchro IITC ou de la clé de signature.

## v1.0.13 — IGOR sort officiellement du Lab
- Version publique : **Redacted BannerLab 1.0.13**.
- Android source `versionCode` : **11300**.
- **IGOR 0.6.7 — IITC Gateway for Operations & Routing** devient l'assistant visible du Lab.
- Ajout du gestionnaire de mises à jour GitHub Releases : détection, téléchargement, SHA-256, vérification du package et du certificat, puis installation via PackageInstaller.
- Le dépôt GitHub peut rester public : aucun token GitHub n'est embarqué dans l'APK.
- La clé Android et ses mots de passe doivent rester exclusivement dans GitHub Actions Secrets.
- Le workflow de release est fourni séparément et publie l'APK signé + son SHA-256 dans une GitHub Release.

## Updater compatibility hotfix before public test
- Public version remains **1.0.13 / 11300**.
- The GitHub updater now compares version numbers with 3 or more numeric components.
- This allows test releases such as **1.0.13.1**, **1.0.13.2**, etc.
- No other functional behavior is changed.

## v1.0.13.1 — updater test release
- **No functional change** compared with the corrected v1.0.13 baseline.
- Visible/Android/GitHub version: **1.0.13.1**.
- Android `versionCode`: **11301**.
- npm package metadata uses **1.0.13-1** only because npm does not accept four-component version numbers.
- Purpose: validate the complete IGOR self-update path from 1.0.13 to 1.0.13.1.

## Updater Android permission/install bootstrap fix
- Visible version: **1.0.13.1**
- Android versionCode: **11302**
- Permission page is now launched with a real Activity result callback.
- RBL resumes installation immediately after Android confirms "allow from this source".
- PackageInstaller status now targets a dedicated foreground Activity instead of a BroadcastReceiver trampoline.
- STATUS_PENDING_USER_ACTION opens Android's confirmation from that Activity.
- Staged updates can be resumed after returning to RBL.
- This build is intended to be installed manually once to validate the corrected updater against v1.0.13.2.

## v1.0.13.2 — updater validation target
No functional change compared with the corrected v1.0.13.1 bootstrap.
This release exists only to validate the complete self-update path.
Android versionCode: **11303**.

## Overlay Android — flux d’autorisation en deux étapes
Pour les APK sideloadés, l’aide intégrée ne présente plus l’overlay comme une autorisation unique.
1. Ouvrir la fiche de Redacted BannerLab et utiliser `⋮ → Autoriser les paramètres restreints` lorsque Android affiche cette option.
2. Ouvrir ensuite `Afficher par-dessus les autres applications` et autoriser RBL.
Le plugin attend désormais réellement le retour de chaque écran Android et relance l’overlay dès que l’autorisation finale est accordée.


## Rebuild test updater — 1.0.13.2 / versionCode 11305
- Version visible conservée : **1.0.13.2**.
- Android `versionCode` relevé à **11305** afin de pouvoir installer ce rebuild par-dessus les builds de test précédents.
- Correctif IGOR : après téléchargement + vérification SHA-256/package/version/signature, l'APK est maintenant remis directement à l'installateur Android via `FileProvider` depuis l'activité au premier plan.
- Le chemin de session `PackageInstaller` qui pouvait rester bloqué à 100 % avant l'affichage de la confirmation Android n'est plus utilisé pour lancer la mise à jour.

## v1.0.13.3 — updater PackageInstaller validation target
- Functional code identical to the corrected v1.0.13.2 PackageInstaller build.
- Visible version: **1.0.13.3**.
- Android `versionCode`: **11308**.
- Purpose: install v1.0.13.2 manually, then validate IGOR self-update to v1.0.13.3.


## v1.0.13.2 — IGOR updater en deux étapes

- Version visible : **1.0.13.2**.
- Android `versionCode` : **11310**.
- Le téléchargement et l'installation sont désormais deux actions distinctes.
- Après téléchargement, IGOR vérifie SHA-256, package, signature et versionCode puis conserve l'APK en stockage interne persistant.
- L'installation ne démarre jamais automatiquement au retour dans RBL : seul un appui explicite sur **Installer** ouvre l'installateur Android.
- Si l'installateur ne s'ouvre pas ou est annulé, l'APK reste disponible et le bouton **Installer** peut être réutilisé sans nouveau téléchargement.


## Test PackageInstaller stream-close fix — 1.0.13.2 / 11312
- Version visible : **1.0.13.2**.
- Android `versionCode` : **11312**.
- Updater IGOR toujours en deux étapes : téléchargement/vérification, puis clic explicite sur Installer.
- Installation native via `PackageInstaller.Session`.
- Correctif critique : le flux `session.openWrite()` est désormais **fermé avant `Session.commit()`**, conformément à l’API Android.
- `USER_ACTION_REQUIRED` est forcé sur Android 12+ afin d’obtenir la confirmation système.
- Le callback `STATUS_PENDING_USER_ACTION` ouvre l’`Intent.EXTRA_INTENT` fourni par Android.
- Aucune relance automatique au `resume` ou `appStateChange`.

## v1.0.13.2 / 11312 — transparence & communauté
- Ajout dans Réglages & infos d'une section « Code public & confidentialité » avec accès direct au dépôt GitHub public.
- Mention explicite : pas de compte RBL, pas de publicité, pas de télémétrie ni de collecte cachée ; les données de travail restent locales sauf action volontaire d'export, partage ou publication.
- Services externes utilisés détaillés dans l'interface (GitHub, Bannergress, OpenStreetMap/Valhalla, Mission Authoring Tool et Telegram support).
- Rappel que la clé de signature Android et les secrets de build restent hors du dépôt public.
- Le bloc « Créé par Zw4nn » est remplacé par un pied de page discret : © 2026 Zw4nn · Redacted BannerLab, avec un mot d'ouverture à toute la communauté Ingress.
- Version visible et versionCode inchangés : 1.0.13.2 / 11312.

## Test PackageInstaller MainActivity callback — 1.0.13.2 / 11314
- PackageInstaller status callback is delivered directly to the foreground MainActivity.
- STATUS_PENDING_USER_ACTION opens Android's EXTRA_INTENT from the activity the user is actively using.
- No BroadcastReceiver or translucent callback-Activity trampoline.
- Download/install remain strictly separated; no resume auto-install.

## Build 11404 TEST — assistant Publisher Chrome
- Assistant Chrome refait en 7 étapes, une seule action à la fois.
- Captures réelles de Chrome Android affichées dans le guide de test.
- Parcours guidé : enregistrer Publisher → copier mini-code → ajouter favori → retrouver/modifier → coller URL → lancer depuis l'omnibox → choisir Publisher + JSON de session.
- Les captures externes sont utilisées uniquement pour cette maquette de test ; elles devront être remplacées par des captures définitives/maîtrisées avant publication publique.


## Build 11406 TEST — tutoriel Publisher avec captures réelles Chrome

- Remplacement des captures Web distantes du tutoriel Chrome par les captures réelles fournies pendant le test.
- Les captures sont embarquées localement dans l’APK sous `public/tutorials/chrome/` : le tuto ne dépend plus du chargement d’images externes.
- Ajout d’un agrandissement plein écran au toucher sur chaque capture.
- Étapes ajustées à l’interface Chrome Android réellement observée : étoile, favoris d’appareils mobiles, Modifier, suggestion dans la barre d’adresse et autorisation du fichier Publisher.
- Le nom `qqqq` visible sur la capture de suggestion est explicitement identifié comme nom de test ; le guide demande toujours `RBL Publisher`.
- Version publique inchangée `1.0.14`, versionCode `11406`.
- Version du setup Chrome portée à `0.10.11` pour rejouer le tutoriel de test.


## Build 11406 TEST — tutoriel Chrome nettoyé

- Captures Chrome réelles conservées, aucune image générée.
- Barre d’état Android (heure, réseau, batterie, notifications) retirée de toutes les captures du tutoriel.
- Les noms, images et cartes de missions visibles derrière les écrans MAT d’autorisation et de Publisher ont été masqués.
- Captures embarquées localement dans l’APK.
- Version du setup Chrome portée à `0.10.11` pour rejouer le tutoriel de test.

- Assistant Chrome réécrit : titres orientés actions, MILO parle seulement dans ses bulles, avatar compact.
- Terminologie simplifiée : « le Lab », « dossier de travail », « installer / mettre à jour MILO ».
- Panneau MILO : actions nommées et plus lisibles ; suppression de la capture finale obsolète.

## Test v1.0.15.1 — Arcade du Lab (versionCode 11502)
- Version visible : **1.0.15.1** ; Android `versionCode` : **11502**.
- 7 pressions sur Redacted ouvrent l’easter egg **Arcade du Lab**.
- 5 mini-jeux locaux : IGOR Portal Panic, MILO Launch Sequence, RITA Signal Storm, Redacted Lab Escape et Lab Memory.
- Les meilleurs scores sont conservés en `localStorage` uniquement sur l’appareil.
- Aucun service réseau n’est utilisé par les mini-jeux.


## Test v1.0.15.2 — Arcade du Lab itération 2 (versionCode 11503)
- Version visible : **1.0.15.2** ; Android `versionCode` : **11503**.
- L’Arcade du Lab passe de 5 à **6 mini-jeux**.
- Chaque mini-jeu démarre désormais avec un **briefing plus grand** où les personnages parlent, plus un **tutoriel repliable**.
- L’overlay Arcade est maintenant **décalé correctement sous la barre de notification** / safe-area Android.
- Le mini-jeu Redacted devient **Faction Drop** avec choix **ENL / RES**, bonnes caisses selon la couleur choisie, caisses adverses et **Machina rouges explosives**.
- Nouveau mini-jeu : **RITA · Portal Blaster**, un shoot arcade inspiré de Galaga avec bonus de faction, montée en niveau et boss Machina.


## Test v1.0.15.3 — Portal Blaster retouché (versionCode 11504)
- Version visible : **1.0.15.3** ; Android `versionCode` : **11504**.
- Le déplacement de **RITA · Portal Blaster** a été revu pour être plus fluide : ajout d’un **joystick horizontal** et de **flèches gauche/droite** à maintenir.
- Les ennemis standards sont maintenant surtout ceux de la **faction adverse** ; les objets de ta propre couleur apparaissent moins souvent et servent de **bonus** à récupérer.
- Les ennemis affichent désormais un **nombre de points de vie** directement sur eux.
- La difficulté monte avec le niveau : les ennemis adverses demandent plus de tirs, et les ennemis **Machina rouges** ont environ **deux fois plus de points de vie**.
- Les bonus augmentent encore la puissance de feu et le score.


## Test v1.0.15.4 — Portal Blaster arcade pass (versionCode 11505)
- Version visible : **1.0.15.4** ; Android `versionCode` : **11505**.
- Ajout de **formations d’ennemis** : lignes, vagues et zigzags au lieu d’apparitions uniquement aléatoires.
- Les boss sont désormais de la **faction adverse** (vert ou bleu selon le camp choisi), avec barre de vie dédiée.
- Ajout d’une **barre de progression de niveau** directement dans l’arène.
- Ajout d’une jauge **SUPER** : les destructions et surtout les bonus de faction la chargent ; à 100 %, un super tir frappe tout l’écran.
- Les bonus de faction restent volontairement plus rares que les ennemis.
- Les Machina rouges conservent environ **2× les PV** des ennemis standards et leurs explosions de zone.
- Effets d’explosion enrichis avec éclats/particules et gros effets sur boss, Machina et montée de niveau.
- Joystick et flèches utilisent `touch-action:none` pour éviter le scroll parasite pendant le pilotage.


## Test v1.0.15.5 — accueil Arcade retouché (versionCode 11506)
- Version visible : **1.0.15.5** ; Android `versionCode` : **11506**.
- La page d’accueil de l’Arcade du Lab a été refaite pour une ambiance plus **backroom / salle de jeu clandestine**.
- L’écran d’entrée affiche désormais un décor plus riche : **marquee**, bornes latérales, scène centrale, sol néon et cartes d’état de l’équipe du Lab.
- Redacted reste la pièce centrale, mais l’accueil ne repose plus sur une tête seule au milieu de l’écran.


## Test v1.0.15.6 — entrée Arcade clandestine (versionCode 11507)
- Version visible : **1.0.15.6** ; Android `versionCode` : **11507**.
- L’accueil caché de l’Arcade est refait façon **backroom / salle de jeu clandestine**.
- Branding d’entrée : **REDACTED BANNER ~~LAB~~ ARCADE**, avec `LAB` barré et `ARCADE` ajouté façon néon.
- Redacted parle désormais via **l’icône launcher existante** dans une vraie bulle de dialogue, au lieu d’occuper seul le centre de l’écran.
- Décor enrichi uniquement en HTML/CSS avec porte technique, câbles, terminal, bornes IGOR/RITA et cartes d’état de l’équipe.
- **Aucune image générée** ajoutée à cette révision.


## Test v1.0.15.7 — Arcade multilingue (versionCode 11508)
- Version visible : **1.0.15.7** ; Android `versionCode` : **11508**.
- Traduction complète de l’Arcade dans les 7 langues prioritaires : **FR, EN, ES, PT, DE, IT, NL**.
- Les autres langues supportées par RBL basculent automatiquement sur **l’anglais** pour tous les textes Arcade.
- Les dialogues, briefings, tutos, HUD, écran clandestin et messages de jeu utilisent tous le même pack de traduction.
- Redacted utilise l’icône launcher existante dans ses bulles de dialogue.


## Test v1.0.15.10 — carte REDACTED corrigée (versionCode 11511)
- Version visible : **1.0.15.10** ; Android `versionCode` : **11511**.
- Carte Faction Drop : utilisation forcée de la **vignette launcher/logo** existante pour Redacted.
- Titre affiché : **REDACTED - Faction Drop**.
- Aucun asset généré ; uniquement les ressources déjà présentes dans Redacted BannerLab.


## Test v1.0.15.10 — REDACTED launcher + titrage (versionCode 11511)
- Version visible : **1.0.15.10** ; Android `versionCode` : **11511**.
- **Aucune génération d’image** : réutilisation exclusive de l’icône launcher/logo déjà embarquée dans l’application.
- La carte, les briefings et les interventions de REDACTED utilisent cet avatar existant.
- Titre harmonisé exactement en **REDACTED - Faction Drop**.


## Test v1.0.15.11 — Arcade, vignettes harmonisées (versionCode 11512)
- Version visible : **1.0.15.11** ; Android `versionCode` : **11512**.
- Cadrage des portraits IGOR / MILO / RITA / Redacted harmonisé dans le menu Arcade.
- Les jeux Redacted utilisent la vignette launcher/logo existante avec un léger zoom CSS pour compenser les marges internes de l’image.
- `Lab Memory` devient **REDACTED - Lab Memory**.
- Aucune image générée.

## Test v1.0.15.12 — opacité Prime + IGOR compact (versionCode 11513)
- Version visible : **1.0.15.12** ; Android `versionCode` : **11513**.
- Ajout d’un curseur **Opacité des cercles** dans l’éditeur avec rendu en direct et persistance par projet.
- Nouveau réglage traduit dans les 7 langues prioritaires, anglais en fallback pour les autres.
- **IGOR 0.6.11** démarre réduit par défaut, avec largeur par défaut de 260 px.
- La miniature d’IGOR reçoit des flèches **‹ / ›** pour naviguer entre les missions sans déplier le panneau.
- La progression automatique devient le comportement par défaut : au 6e portail, IGOR passe à la mission suivante.
- Les 8 commandes inférieures d’IGOR passent d’une disposition 2 × 4 à une disposition **4 × 2** plus compacte.
- Les vignettes Arcade utilisent désormais exactement la même échelle de cadrage CSS.
