# Redacted BannerLab 0.7.0

Éditeur mobile-first de fresques et de missions Ingress Prime, non officiel.

## 0.7.0

- Mission Planner mobile entièrement revu : liste compacte des missions, puis fiche d’édition dédiée.
- Redacted BannerLab n’utilise plus UMM comme workflow principal : export natif `BannerLab` avec `missions.json` + images 512×512.
- Actions officielles par portail : Hack, Mod, Capture/Upgrade, Link, Field, Passphrase.
- Passphrase : question + réponse attendue enregistrées avec le portail.
- Reprise autorisée du dernier portail d’une mission comme premier portail de la suivante.
- Option pour reprendre automatiquement ce portail lors du passage à la mission suivante.
- Les doublons légitimes fin→début ne sont plus signalés comme erreurs.
- IITC Companion 0.5.0 inclus :
  - statistiques piétonnes Valhalla/OpenStreetMap,
  - choix de l’action,
  - question/réponse de passphrase,
  - reprise fin→début,
  - mode sécurisé basé sur `portalSelected`.
- Première couche multilingue Français / English / Español :
  - navigation principale,
  - Mission Planner,
  - publication,
  - Companion IITC.
- La langue se choisit dans Infos et est conservée sur l’appareil.

## Publication

BannerLab génère désormais son propre pack :
- `missions/001.jpg`, `002.jpg`, etc.
- `missions.json` contenant titres, descriptions, type de mission, visibilité,
  portails, coordonnées, objectifs et passphrases.

La prochaine étape est un `Redacted BannerLab Publisher` pour préremplir
le Mission Authoring Tool officiel à partir de ce format. La soumission finale
reste volontairement faite dans l’outil officiel.

## Signature Android

La clé de signature stable ne doit jamais être remplacée.


## 0.7.1 — calques globaux et historique

- Les recadrages individuels ne transforment que l'image de fond.
- Les textes restent des calques globaux, composés après tous les recadrages locaux.
- Aperçu, export rapide, export mission par mission et éditeur plein écran respectent la même composition.
- Annuler / Rétablir multi-étapes (80 opérations), avec un geste tactile = une opération.
- Undo/Redo aussi dans l'éditeur de mission plein écran.
- Ctrl+Z, Ctrl+Y et Ctrl+Shift+Z sur la future version web / clavier.


## 0.7.2 — traduction et Companion 0.6
- Nettoyage des chaînes historiques FR/EN/ES dans l’éditeur, Texte, Cadrage, Aperçu, Export, Infos et Projets.
- Companion IITC intégré en 0.6.0.
- Ouverture IITC corrigée : le payload BannerLab passe dans `#rbl=` et n’est plus envoyé au serveur Intel.
- Langue BannerLab transmise au Companion.


## 0.8.0 — Publisher intégré expérimental
- Nouveau bouton Publier → Préparer directement dans Mission Authoring.
- RBL rend les images 512×512 en mémoire et écrit un payload temporaire interne, sans ZIP ni téléchargement.
- Android ouvre une PublisherActivity WebView sur missions.ingress.com et injecte automatiquement le Publisher RBL.
- Le Publisher importe titre, description, séquentiel/caché, portails, objectifs, passphrases et image.
- Le clic final Submit reste manuel.
- Companion IITC intégré 0.6.1.
- Sync Companion accepte les formats futurs >=2.

## 0.8.1 — Publisher navigateur
- Abandon de l'authentification Google dans WebView intégrée.
- Publisher direct dans Firefox Android avec Violentmonkey.
- Une mission est transmise directement via le fragment `#rblpub=` : aucun ZIP.
- Le payload est sauvegardé côté `missions.ingress.com` avant la redirection Google.
- Mission suivante : retour automatique RBL, génération de l'image suivante, puis réouverture Firefox.
- Companion IITC 0.6.1 intégré.

## 0.8.2 — Chrome + Firefox
- Choix persistant du navigateur de publication.
- Chrome : aucune application supplémentaire, bookmarklet installé une seule fois puis lancé depuis la barre d'adresse.
- Assistant Chrome : copie du bookmarklet, ouverture Mission Authoring, test et validation par deep link.
- Firefox : mode automatique via Violentmonkey + Publisher userscript.
- Le Publisher 0.3.1 renvoie un deep link de validation pour les deux modes.
- Aucun ZIP dans le workflow de publication.

## 0.8.3 — assistant Chrome simplifié
- Bookmarklet Chrome réduit de ~20 000 caractères à 1759 caractères.
- Le bookmarklet mémorise le `FileSystemFileHandle` de `publisher.js` dans IndexedDB.
- Au premier test : sélection du fichier `publisher.js`.
- Aux utilisations suivantes : réutilisation du fichier et demande `Autoriser` si Chrome l'exige.
- Assistant Chrome en 3 étapes, mémorisé, avec précédent / continuer / recommencer.
- Test réel : le Publisher renvoie `redactedbannerlab://publisher-chrome-ready`.
- Firefox + Violentmonkey reste disponible comme mode automatique.

## 0.8.4 — garde-fous de publication
- Description de bannière sortie des réglages avancés et affichée directement dans Missions.
- Description de bannière obligatoire avant d'ouvrir l'écran Publier.
- La description commune continue d'être propagée aux missions non personnalisées.
- Minimum absolu de 6 portails par mission dans RBL et Companion IITC.
- Une mission n'est pas envoyée au Publisher tant qu'elle n'atteint pas son quota configuré (minimum 6).
- Le Publisher 0.3.3 refait la validation côté missions.ingress.com et refuse lui aussi description vide / moins de 6 portails.
- Companion IITC intégré : 0.6.2.

## 0.9.0 — Jouer + Overlay + Publisher session
- Nouveau hub « Jouer » : recherche Bannergress, favoris locaux, bannière en cours.
- Détails Bannergress + lancement d'une bannière.
- Overlay Android natif Redacted : précédent / ouvrir / suivant / terminé / réduction en bulle / déplacement / fermeture.
- Aucune interaction directe avec l'UI Ingress : uniquement des deeplinks de missions.
- Autorisation SYSTEM_ALERT_WINDOW gérée depuis RBL.
- Service de premier plan `specialUse` pour maintenir l'overlay pendant Ingress.
- Publisher 0.4.0 : fichier de session contenant toute la bannière ; le favori Chrome n'est lancé qu'une fois par session normale.
- Chrome conserve le handle de publisher.js ; une nouvelle session demande le fichier *.rblpub.json une seule fois.
- Firefox charge lui aussi une session complète via le panneau Publisher.
- Easter egg : 7 taps sur le logo, Redacted détouré traverse l'écran une fois puis disparaît.

## 0.9.1 — overlay + recherche Bannergress
- Overlay déplié : poignée dédiée `≡ Déplacer`, gestes consommés proprement, réduction/fermeture accessibles.
- Overlay automatiquement contraint dans la zone visible quand il démarre, se déplace ou passe bulle ↔ panneau.
- Suppression de `FLAG_LAYOUT_NO_LIMITS` pour éviter les panneaux perdus hors écran.
- Bouton principal renommé « Rechercher une fresque ».
- Recherche Bannergress multi-critères : nom/mot-clé, ville (résolue via `/places` puis `placeId`), auteur (`author`) et autour de moi (`proximityStartPoint`).
- Les critères nom/auteur peuvent être combinés avec ville ou proximité.
- Favoris et reprise de fresque conservés.

## 0.9.2 — correctif compilation Android
- Correction de l'import `ActivityNotFoundException` dans `MissionOverlayService.java`.
- `android.app.ActivityNotFoundException` remplacé par `android.content.ActivityNotFoundException`.
- Aucun changement de workflow GitHub requis.

## 0.9.3 — Publisher sessions / ouverture directe
- « Préparer toute la bannière » n’ouvre plus la feuille Android de partage.
- La session courante est écrite automatiquement dans
  `Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json`, puis Mission Authoring est ouvert.
- Une copie lisible par projet est aussi conservée dans le même dossier.
- Le mini-bookmarklet Chrome mémorise séparément le handle du Publisher JS et celui du JSON de session.
- Après la première sélection de `RBL_Current_Session.rblpub.json`, Chrome peut réutiliser le même fichier
  aux préparations suivantes et ne redemander que l’autorisation de lecture.
- Publisher 0.4.1 : plusieurs projets/sessions mémorisés dans IndexedDB.
- Sélecteur de projet, Charger JSON, Actualiser depuis RBL, Supprimer le projet courant et Tout effacer.
- Les anciennes sessions v2 sont migrées mais ne sont plus impossibles à supprimer.
- Une bannière complète reste chargée pendant toute la session : pas besoin de relancer le favori entre les missions.

## 0.9.4 — enregistrement direct du Publisher Chrome
- Le bouton « Enregistrer le Publisher » n'utilise plus `Share.share()`.
- RBL écrit directement :
  `Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js`
- Le JSON de session reste :
  `Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json`
- Chrome ne demande plus qu'à sélectionner ces deux fichiers lors de la première configuration.
- Le partage Android reste uniquement utile au mode Firefox/userscript et aux exports volontaires.

## 0.9.5 — fin des sessions fantômes Chrome
- Le handle du Publisher JS reste mémorisé.
- Le JSON de session n'est plus réutilisé silencieusement lorsqu'une nouvelle bannière est préparée.
- `#rblsession=1` force désormais le sélecteur Chrome pour `RBL_Current_Session.rblpub.json`.
- Une fois le JSON choisi, toute la bannière reste chargée : aucune nouvelle sélection entre les missions.
- Publisher 0.4.2 : boutons « Changer le fichier de session » et « Oublier le fichier mémorisé ».
- Ces boutons nettoient aussi le handle `session` du mini-bookmarklet dans IndexedDB.
- Supprimer un favori Chrome n'est plus présenté comme une méthode de réinitialisation : les handles sont gérés explicitement.

## 0.9.6 — conserver la session Mission Authoring
- RBL ne navigue plus vers `missions.ingress.com` à chaque préparation.
- Après écriture du JSON courant, l'application Chrome/Firefox est simplement ramenée au premier plan avec `IntentLauncher.openApplication`.
- La navigation vers Mission Authoring n'est utilisée qu'en secours si le navigateur ne peut pas être repris.
- Publisher 0.4.3 surveille toutes les 2 secondes `RBL_Current_Session.rblpub.json`.
- Quand RBL écrase ce fichier avec une nouvelle bannière, le Publisher déjà ouvert charge automatiquement la nouvelle session.
- Aucun nouveau passage OAuth Google n'est déclenché par RBL entre deux préparations tant que l'onglet Mission Authoring reste ouvert.
- Le fichier Publisher Chrome est réécrit silencieusement à chaque préparation, donc aucun nouveau favori n'est nécessaire.

## 0.9.7 — reprise Publisher + verrouillage des étapes
- La session Publisher est persistée dans IndexedDB : projet courant, session complète et progression.
- La progression (mission courante, préparées, soumises) est désormais sauvegardée à la fois dans localStorage et dans l'enregistrement IndexedDB du projet.
- Après fermeture/kill de la page, relancer le Publisher restaure automatiquement la session et la mission en cours.
- Chrome nécessite toujours de relancer le favori une fois après une fermeture réelle de page : le JavaScript ne peut pas survivre à une page fermée.
- Le workflow RBL verrouille maintenant l'édition de la fresque quand l'étape 2 Parcours, 3 Missions ou 4 Publier est active.
- Fermer une feuille / utiliser Retour ne déverrouille pas la fresque.
- Pour modifier image, cadrage, texte, recadrage mission, rangées ou Undo/Redo, il faut explicitement sélectionner l'étape 1 Fresque.
- Aperçu et Export restent accessibles pendant les étapes verrouillées.

## 0.9.8 — onglet Mission Authoring dédié RBL
- Correction du bouton Publier qui ouvrait uniquement l'écran des onglets Chrome.
- RBL utilise maintenant `ACTION_VIEW` vers `https://missions.ingress.com/`.
- L'intent contient `Browser.EXTRA_APPLICATION_ID` (`com.android.browser.application_id`)
  avec l'identifiant stable `com.bannerforge.mobile`.
- Chrome peut ainsi associer un onglet à RBL et tenter de réutiliser ce même onglet
  aux ouvertures suivantes au lieu de créer un nouvel onglet.
- Cela conserve mieux le contexte/session Mission Authoring dans le même onglet.
- Le JSON Publisher reste local : aucun payload RBL n'est envoyé dans l'URL.
- La configuration Chrome/bookmarklet existante reste valide.
- Publisher interne : 0.4.5.

## 0.10.0 — Jouer sans compte Bannergress
- Aucun login Bannergress : recherche et détails publics uniquement.
- Liste locale « À faire » distincte des favoris RBL.
- Historique local avec progression, date, durée active, distance Bannergress estimée et reprise.
- Overlay : bouton Pause/Reprendre et statistiques persistées localement.
- Partage groupe sans serveur par lien/deeplink `redactedbannerlab://play?...` et QR code.
- Le lien contient l'identifiant public Bannergress et le numéro de mission courant ; le téléphone destinataire récupère les données publiques puis propose de rejoindre la même mission.
- Carte Leaflet/OpenStreetMap du parcours complet à partir des `mission.steps[].poi` fournis par Bannergress.
- Bouton itinéraire piéton vers le premier point de la première mission via Google Maps, avec fallback navigateur.
- Bouton partager la progression depuis la session en cours.
- Dépendances ajoutées : Leaflet 1.9.4 et qrcode 1.5.4.
