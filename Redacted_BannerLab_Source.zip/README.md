# Redacted BannerLab 0.6.0

Éditeur mobile-first non officiel de fresques, parcours et missions Ingress Prime.

## Nouveautés 0.5.0 — Mission Planner

- Workflow Fresque → Parcours → Missions → Publier.
- Une fiche mission est automatiquement créée pour chaque badge de la fresque.
- Titres automatiques compatibles avec la syntaxe UMM : `$T`, `$N`, `$M`, `$0N`.
- Description commune ou spécifique par mission.
- Missions séquentielles / ordre libre, localisation visible / cachée.
- Nombre cible de portails par mission configurable.
- Ajout, suppression, réorganisation et choix de l’objectif de chaque portail.
- Objectifs UMM : HACK_PORTAL, INSTALL_MOD, CAPTURE_PORTAL, CREATE_LINK, CREATE_FIELD, PASSPHRASE.
- Calcul des distances par mission et de la bannière complète.
- Détection des GUID manquants et des portails dupliqués.
- Import JSON UMM.
- Export JSON UMM format 3 avec les images générées par BannerLab.
- Bouton Mission Authoring Tool.
- IITC Bridge expérimental : un plugin compagnon IITC peut renvoyer le portail sélectionné vers l’APK via `redactedbannerlab://portal`.
- Le plugin compagnon peut être partagé directement depuis l’app.

## Android / mise à jour

L’identifiant Android interne historique reste `com.bannerforge.mobile` uniquement pour préserver les mises à jour sans désinstallation.
Le nom visible reste Redacted BannerLab.

La clé de signature stable est inchangée.

SHA-256 fichier keystore :
`1b7cc0b63572f546cd2998e7be7e09ed9ae24b5a75e3f89be5d0f18f6d34b30a`

## Important

Le Mission Authoring Tool et IITC/UMM sont des services/outils externes. Redacted BannerLab ne soumet pas automatiquement des missions aux serveurs Niantic. La v0.5.0 prépare et échange les données.

Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.


## 0.6.0 — IITC Companion v2

- Panneau Redacted flottant directement dans IITC Mobile.
- Ajout direct d'un portail au toucher, sans retour vers BannerLab.
- Boutons ajouter, retirer le dernier, mission précédente/suivante.
- Tracé Leaflet de la mission active avec numérotation.
- Synchronisation de toutes les missions vers BannerLab en une seule fois.
- Le projet/planner est envoyé à IITC à l'ouverture puis conservé localement par le plugin.
- Nouveau tutoriel intégré et carte IITC Companion compacte, sans grosse flèche de téléchargement.
- Le deep link Android accepte désormais redactedbannerlab://portal et redactedbannerlab://sync.
