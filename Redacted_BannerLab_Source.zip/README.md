# Redacted BannerLab 1.0.6

Éditeur mobile-first de fresques et de missions Ingress Prime, non officiel.

## 0.7.0

- Mission Planner mobile entièrement revu : liste compacte des missions, puis fiche d’édition dédiée.
- Redacted BannerLab n’utilise plus UMM comme workflow principal : export natif `BannerLab` avec `missions.json` + images 512×512.
- Actions officielles par portail : Hack, Mod, Capture/Upgrade, Link, Field, Passphrase.
- Passphrase : question + réponse attendue enregistrées avec le portail.
- Reprise autorisée du dernier portail d’une mission comme premier portail de la suivante.
- Option pour reprendre automatiquement ce portail lors du passage à la mission suivante.
- Les doublons légitimes fin→début ne sont plus signalés comme erreurs.
- IITC Companion 0.5.0 inclus :
  - statistiques piétonnes Valhalla/OpenStreetMap,
  - choix de l’action,
  - question/réponse de passphrase,
  - reprise fin→début,
  - mode sécurisé basé sur `portalSelected`.
- Première couche multilingue Français / English / Español :
  - navigation principale,
  - Mission Planner,
  - publication,
  - Companion IITC.
- La langue se choisit dans Infos et est conservée sur l’appareil.

## Publication

BannerLab génère désormais son propre pack :
- `missions/001.jpg`, `002.jpg`, etc.
- `missions.json` contenant titres, descriptions, type de mission, visibilité,
  portails, coordonnées, objectifs et passphrases.

La prochaine étape est un `Redacted BannerLab Publisher` pour préremplir
le Mission Authoring Tool officiel à partir de ce format. La soumission finale
reste volontairement faite dans l’outil officiel.

## Signature Android

La clé de signature stable ne doit jamais être remplacée.


## 0.7.1 — calques globaux et historique

- Les recadrages individuels ne transforment que l'image de fond.
- Les textes restent des calques globaux, composés après tous les recadrages locaux.
- Aperçu, export rapide, export mission par mission et éditeur plein écran respectent la même composition.
- Annuler / Rétablir multi-étapes (80 opérations), avec un geste tactile = une opération.
- Undo/Redo aussi dans l'éditeur de mission plein écran.
- Ctrl+Z, Ctrl+Y et Ctrl+Shift+Z sur la future version web / clavier.


## 0.7.2 — traduction et Companion 0.6
- Nettoyage des chaînes historiques FR/EN/ES dans l’éditeur, Texte, Cadrage, Aperçu, Export, Infos et Projets.
- Companion IITC intégré en 0.6.0.
- Ouverture IITC corrigée : le payload BannerLab passe dans `#rbl=` et n’est plus envoyé au serveur Intel.
- Langue BannerLab transmise au Companion.


## 0.8.0 — Publisher intégré expérimental
- Nouveau bouton Publier → Préparer directement dans Mission Authoring.
- RBL rend les images 512×512 en mémoire et écrit un payload temporaire interne, sans ZIP ni téléchargement.
- Android ouvre une PublisherActivity WebView sur missions.ingress.com et injecte automatiquement le Publisher RBL.
- Le Publisher importe titre, description, séquentiel/caché, portails, objectifs, passphrases et image.
- Le clic final Submit reste manuel.
- Companion IITC intégré 0.6.1.
- Sync Companion accepte les formats futurs >=2.

## 0.8.1 — Publisher navigateur
- Abandon de l'authentification Google dans WebView intégrée.
- Publisher direct dans Firefox Android avec Violentmonkey.
- Une mission est transmise directement via le fragment `#rblpub=` : aucun ZIP.
- Le payload est sauvegardé côté `missions.ingress.com` avant la redirection Google.
- Mission suivante : retour automatique RBL, génération de l'image suivante, puis réouverture Firefox.
- Companion IITC 0.6.1 intégré.

## 0.8.2 — Chrome + Firefox
- Choix persistant du navigateur de publication.
- Chrome : aucune application supplémentaire, bookmarklet installé une seule fois puis lancé depuis la barre d'adresse.
- Assistant Chrome : copie du bookmarklet, ouverture Mission Authoring, test et validation par deep link.
- Firefox : mode automatique via Violentmonkey + Publisher userscript.
- Le Publisher 0.3.1 renvoie un deep link de validation pour les deux modes.
- Aucun ZIP dans le workflow de publication.

## 0.8.3 — assistant Chrome simplifié
- Bookmarklet Chrome réduit de ~20 000 caractères à 1759 caractères.
- Le bookmarklet mémorise le `FileSystemFileHandle` de `publisher.js` dans IndexedDB.
- Au premier test : sélection du fichier `publisher.js`.
- Aux utilisations suivantes : réutilisation du fichier et demande `Autoriser` si Chrome l'exige.
- Assistant Chrome en 3 étapes, mémorisé, avec précédent / continuer / recommencer.
- Test réel : le Publisher renvoie `redactedbannerlab://publisher-chrome-ready`.
- Firefox + Violentmonkey reste disponible comme mode automatique.

## 0.8.4 — garde-fous de publication
- Description de bannière sortie des réglages avancés et affichée directement dans Missions.
- Description de bannière obligatoire avant d'ouvrir l'écran Publier.
- La description commune continue d'être propagée aux missions non personnalisées.
- Minimum absolu de 6 portails par mission dans RBL et Companion IITC.
- Une mission n'est pas envoyée au Publisher tant qu'elle n'atteint pas son quota configuré (minimum 6).
- Le Publisher 0.3.3 refait la validation côté missions.ingress.com et refuse lui aussi description vide / moins de 6 portails.
- Companion IITC intégré : 0.6.2.

## 0.9.0 — Jouer + Overlay + Publisher session
- Nouveau hub « Jouer » : recherche Bannergress, favoris locaux, bannière en cours.
- Détails Bannergress + lancement d'une bannière.
- Overlay Android natif Redacted : précédent / ouvrir / suivant / terminé / réduction en bulle / déplacement / fermeture.
- Aucune interaction directe avec l'UI Ingress : uniquement des deeplinks de missions.
- Autorisation SYSTEM_ALERT_WINDOW gérée depuis RBL.
- Service de premier plan `specialUse` pour maintenir l'overlay pendant Ingress.
- Publisher 0.4.0 : fichier de session contenant toute la bannière ; le favori Chrome n'est lancé qu'une fois par session normale.
- Chrome conserve le handle de publisher.js ; une nouvelle session demande le fichier *.rblpub.json une seule fois.
- Firefox charge lui aussi une session complète via le panneau Publisher.
- Easter egg : 7 taps sur le logo, Redacted détouré traverse l'écran une fois puis disparaît.

## 0.9.1 — overlay + recherche Bannergress
- Overlay déplié : poignée dédiée `≡ Déplacer`, gestes consommés proprement, réduction/fermeture accessibles.
- Overlay automatiquement contraint dans la zone visible quand il démarre, se déplace ou passe bulle ↔ panneau.
- Suppression de `FLAG_LAYOUT_NO_LIMITS` pour éviter les panneaux perdus hors écran.
- Bouton principal renommé « Rechercher une fresque ».
- Recherche Bannergress multi-critères : nom/mot-clé, ville (résolue via `/places` puis `placeId`), auteur (`author`) et autour de moi (`proximityStartPoint`).
- Les critères nom/auteur peuvent être combinés avec ville ou proximité.
- Favoris et reprise de fresque conservés.

## 0.9.2 — correctif compilation Android
- Correction de l'import `ActivityNotFoundException` dans `MissionOverlayService.java`.
- `android.app.ActivityNotFoundException` remplacé par `android.content.ActivityNotFoundException`.
- Aucun changement de workflow GitHub requis.

## 0.9.3 — Publisher sessions / ouverture directe
- « Préparer toute la bannière » n’ouvre plus la feuille Android de partage.
- La session courante est écrite automatiquement dans
  `Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json`, puis Mission Authoring est ouvert.
- Une copie lisible par projet est aussi conservée dans le même dossier.
- Le mini-bookmarklet Chrome mémorise séparément le handle du Publisher JS et celui du JSON de session.
- Après la première sélection de `RBL_Current_Session.rblpub.json`, Chrome peut réutiliser le même fichier
  aux préparations suivantes et ne redemander que l’autorisation de lecture.
- Publisher 0.4.1 : plusieurs projets/sessions mémorisés dans IndexedDB.
- Sélecteur de projet, Charger JSON, Actualiser depuis RBL, Supprimer le projet courant et Tout effacer.
- Les anciennes sessions v2 sont migrées mais ne sont plus impossibles à supprimer.
- Une bannière complète reste chargée pendant toute la session : pas besoin de relancer le favori entre les missions.

## 0.9.4 — enregistrement direct du Publisher Chrome
- Le bouton « Enregistrer le Publisher » n'utilise plus `Share.share()`.
- RBL écrit directement :
  `Documents/RedactedBannerLab/redacted-bannerlab-publisher.user.js`
- Le JSON de session reste :
  `Documents/RedactedBannerLab/RBL_Current_Session.rblpub.json`
- Chrome ne demande plus qu'à sélectionner ces deux fichiers lors de la première configuration.
- Le partage Android reste uniquement utile au mode Firefox/userscript et aux exports volontaires.

## 0.9.5 — fin des sessions fantômes Chrome
- Le handle du Publisher JS reste mémorisé.
- Le JSON de session n'est plus réutilisé silencieusement lorsqu'une nouvelle bannière est préparée.
- `#rblsession=1` force désormais le sélecteur Chrome pour `RBL_Current_Session.rblpub.json`.
- Une fois le JSON choisi, toute la bannière reste chargée : aucune nouvelle sélection entre les missions.
- Publisher 0.4.2 : boutons « Changer le fichier de session » et « Oublier le fichier mémorisé ».
- Ces boutons nettoient aussi le handle `session` du mini-bookmarklet dans IndexedDB.
- Supprimer un favori Chrome n'est plus présenté comme une méthode de réinitialisation : les handles sont gérés explicitement.

## 0.9.6 — conserver la session Mission Authoring
- RBL ne navigue plus vers `missions.ingress.com` à chaque préparation.
- Après écriture du JSON courant, l'application Chrome/Firefox est simplement ramenée au premier plan avec `IntentLauncher.openApplication`.
- La navigation vers Mission Authoring n'est utilisée qu'en secours si le navigateur ne peut pas être repris.
- Publisher 0.4.3 surveille toutes les 2 secondes `RBL_Current_Session.rblpub.json`.
- Quand RBL écrase ce fichier avec une nouvelle bannière, le Publisher déjà ouvert charge automatiquement la nouvelle session.
- Aucun nouveau passage OAuth Google n'est déclenché par RBL entre deux préparations tant que l'onglet Mission Authoring reste ouvert.
- Le fichier Publisher Chrome est réécrit silencieusement à chaque préparation, donc aucun nouveau favori n'est nécessaire.

## 0.9.7 — reprise Publisher + verrouillage des étapes
- La session Publisher est persistée dans IndexedDB : projet courant, session complète et progression.
- La progression (mission courante, préparées, soumises) est désormais sauvegardée à la fois dans localStorage et dans l'enregistrement IndexedDB du projet.
- Après fermeture/kill de la page, relancer le Publisher restaure automatiquement la session et la mission en cours.
- Chrome nécessite toujours de relancer le favori une fois après une fermeture réelle de page : le JavaScript ne peut pas survivre à une page fermée.
- Le workflow RBL verrouille maintenant l'édition de la fresque quand l'étape 2 Parcours, 3 Missions ou 4 Publier est active.
- Fermer une feuille / utiliser Retour ne déverrouille pas la fresque.
- Pour modifier image, cadrage, texte, recadrage mission, rangées ou Undo/Redo, il faut explicitement sélectionner l'étape 1 Fresque.
- Aperçu et Export restent accessibles pendant les étapes verrouillées.

## 0.9.8 — onglet Mission Authoring dédié RBL
- Correction du bouton Publier qui ouvrait uniquement l'écran des onglets Chrome.
- RBL utilise maintenant `ACTION_VIEW` vers `https://missions.ingress.com/`.
- L'intent contient `Browser.EXTRA_APPLICATION_ID` (`com.android.browser.application_id`)
  avec l'identifiant stable `com.bannerforge.mobile`.
- Chrome peut ainsi associer un onglet à RBL et tenter de réutiliser ce même onglet
  aux ouvertures suivantes au lieu de créer un nouvel onglet.
- Cela conserve mieux le contexte/session Mission Authoring dans le même onglet.
- Le JSON Publisher reste local : aucun payload RBL n'est envoyé dans l'URL.
- La configuration Chrome/bookmarklet existante reste valide.
- Publisher interne : 0.4.5.

## 0.10.0 — Jouer sans compte Bannergress
- Aucun login Bannergress : recherche et détails publics uniquement.
- Liste locale « À faire » distincte des favoris RBL.
- Historique local avec progression, date, durée active, distance Bannergress estimée et reprise.
- Overlay : bouton Pause/Reprendre et statistiques persistées localement.
- Partage groupe sans serveur par lien/deeplink `redactedbannerlab://play?...` et QR code.
- Le lien contient l'identifiant public Bannergress et le numéro de mission courant ; le téléphone destinataire récupère les données publiques puis propose de rejoindre la même mission.
- Carte Leaflet/OpenStreetMap du parcours complet à partir des `mission.steps[].poi` fournis par Bannergress.
- Bouton itinéraire piéton vers le premier point de la première mission via Google Maps, avec fallback navigateur.
- Bouton partager la progression depuis la session en cours.
- Dépendances ajoutées : Leaflet 1.9.4 et qrcode 1.5.4.

## 0.10.1 — stats totalement inutiles sur Bannergress
- Chaque résultat Bannergress possède un bouton « 📊 Stats inutiles ».
- Le détail de la fresque n'est chargé qu'à la demande pour éviter une avalanche d'appels API.
- La fiche complète affiche automatiquement les statistiques.
- Calculs locaux à partir des coordonnées publiques Bannergress :
  distance Bannergress, tracé géométrique, temps de marche théorique, nombre d'étapes,
  lieux distincts, passages répétés, étapes/km, moyenne par mission, mission la plus longue,
  plus long tronçon, transitions inter-missions, ligne droite départ/arrivée,
  coefficient de détour et couverture cartographique.
- Les distances géométriques sont volontairement présentées comme des estimations et non
  comme un itinéraire routier.

### 0.10.1 — raffinement stats piétonnes
- La version visible reste 0.10.1.
- Les « Stats inutiles » des fresques Bannergress réutilisent maintenant le même moteur
  Valhalla + OpenStreetMap en profil `pedestrian` que le Companion IITC.
- Tous les points de toutes les missions sont routés dans l'ordre, y compris les transitions
  fin de mission → début de mission suivante.
- Le calcul est découpé en groupes de 45 points pour rester compatible avec le moteur public.
- Valhalla fournit distance et temps de marche par tronçon.
- RBL calcule à partir de ces tronçons : distance piétonne totale, temps, moyenne par mission,
  mission la plus longue, plus long tronçon, transitions et détour du réseau piéton.
- La distance géométrique cumulée est conservée en comparaison et sert de fallback si Valhalla échoue.
- Un cache local par fresque + signature du parcours évite de recalculer les mêmes stats à chaque ouverture.

### 0.10.1 — hotfix Valhalla Android
- La version visible reste 0.10.1.
- Correction du faux « Valhalla indisponible » dans l'application Android.
- Cause : `fetch()` partait de la WebView Capacitor et pouvait être bloqué par CORS.
- Android utilise maintenant `CapacitorHttp.post()` fourni nativement par `@capacitor/core`.
- Le routage n'est donc plus dépendant des règles CORS de la WebView.
- Ajout du header `X-Client-Id: redacted-bannerlab` pour identifier proprement l'application
  auprès du serveur de démonstration public Valhalla.
- Le futur mode web utilise un GET `?json=...` en fallback afin d'éviter le preflight POST JSON.
- Le cache de routage passe de v1 à v2 pour forcer un nouveau calcul après ce correctif.
- En cas d'échec réel, l'interface affiche maintenant l'erreur Valhalla technique sous le fallback.

## 0.10.2 — hotfix Valhalla Android
- Numéro de version monté pour garantir une vraie mise à jour Android par-dessus 0.10.1.
- Conserve le correctif `CapacitorHttp` natif pour Valhalla/OSM pedestrian.
- Clé de signature et package Android historique inchangés.

## 0.10.3 — Valhalla public endpoint max 10 locations
- Correction de l'erreur `Valhalla HTTP 400 · Exceeded max locations: 10`.
- Le serveur public Valhalla accepte au maximum 10 points par requête.
- RBL découpe maintenant le parcours en paquets de 10 points.
- Chaque paquet reprend le dernier point du paquet précédent afin de ne perdre aucun tronçon.
- Exemple : points 1→10, puis 10→19, puis 19→28, etc.
- Distances et temps de tous les paquets sont additionnés pour conserver les statistiques complètes.
- Cache de routage monté en v3 pour forcer un recalcul après correction.

## 0.10.4 — routage piéton adapté à la portée Ingress
- Correction des distances Valhalla exagérées quand un portail est posé sur un POI non directement
  accessible par une arête piétonne OSM.
- Chaque portail est désormais corrélé avec `radius: 40`.
- `rank_candidates: false` permet au moteur de choisir le réseau piéton le plus logique dans cette zone
  au lieu de forcer l'arête la plus proche de la coordonnée exacte.
- `minimum_reachability: 0` conserve les petits chemins et impasses autour des POI.
- Le routage continue à utiliser le profil `pedestrian`, HTTP natif Android et des paquets de 10 points.
- La distance directe cumulée reste affichée comme contrôle.
- Cache monté en v4 afin de recalculer les fresques déjà mises en cache.

## 0.10.5 — routage piéton hybride contrôlé
- Suppression du rayon de corrélation 40 m qui pouvait raccourcir artificiellement les fresques denses.
- `Distance jouable RBL` devient `Distance piétonne estimée`.
- `Temps de marche RBL` devient `Temps de marche estimé`.
- Valhalla route normalement chaque liaison portail → portail.
- Chaque leg Valhalla est comparé à sa distance haversine :
  - si Valhalla est < 88 % de la distance directe, le tronçon est considéré comme un mauvais snapping ;
  - si Valhalla dépasse `max(distance directe × 4, distance directe + 350 m)`, le détour est considéré aberrant ;
  - ces tronçons uniquement repassent en distance directe + temps de marche à 4,8 km/h.
- Les autres tronçons conservent la vraie distance et le vrai temps Valhalla.
- Ajout des statistiques `Valhalla brut` et `Tronçons corrigés`.
- Cache routage monté en v5 pour recalculer toutes les fresques.

## 0.10.6 — crédits Bannergress
- Suppression du bouton « Voir sur Bannergress » dans Partager / groupe.
- Le lien Bannergress n'est plus ajouté au texte partagé : le partage groupe reste centré sur le deeplink RBL.
- Ajout d'une section « Crédits & remerciements » dans Infos.
- Remerciement explicite à Bannergress et à ses contributeurs pour les données publiques de fresques.
- Mention que RBL ne nécessite aucun compte Bannergress.
- Mention claire du caractère indépendant de Redacted BannerLab.
- Crédits ajoutés pour OpenStreetMap et Valhalla.
- Un lien volontaire vers Bannergress reste disponible dans Infos.

## 0.10.7 — texte par défaut & synchro Bannergress
- Nouveau texte par défaut des calques texte : `I LOVE REDACTED`.
- Publisher 0.4.6.
- Après le clic utilisateur « J’ai soumis », RBL vérifie que la mission est réellement `PUBLISHED` dans Mission Authoring avant toute synchronisation.
- Si une session Bannergress déjà enregistrée dans le navigateur est disponible, RBL synchronise la mission publiée vers l’API Bannergress sans ouvrir de nouvelle connexion.
- Aucune connexion Bannergress n’est forcée : sans session existante, la mission reste simplement en attente de synchronisation.
- Les missions déjà publiées mais non synchronisées sont retentées au redémarrage du Publisher.


## 0.10.9 — célébration de fin de fresque
- À la validation de la toute dernière mission dans l’overlay Android, Redacted apparaît au centre de l’écran.
- Ajout de feux d’artifice réellement animés en particules derrière Redacted pendant quelques secondes.
- La célébration est transparente, non interactive et ne bloque donc pas Ingress.
- L’animation ne se déclenche qu’au passage réel de la fresque à l’état terminé, pas à chaque pression ultérieure.
- Le bouton de validation de l’overlay affiche ensuite « 🏁 Fresque terminée ».
- Aucun nouveau visuel n’est ajouté : la célébration réutilise `redacted_dino_cutout`, le même Redacted que l’easter egg.

## 0.10.10 — annulation de progression dans l’overlay
- Ajout d’un bouton `↶ Annuler mission` dans l’overlay Android lorsqu’une mission affichée est déjà marquée terminée.
- L’annulation retire uniquement cette mission de la progression, y compris après une fresque entièrement terminée.
- Ajout d’un bouton `↺ Reset fresque` pour effacer toute la progression de la fresque en cours et revenir à la mission 1.
- Le reset complet demande un second appui `⚠ Confirmer reset` dans les 4 secondes afin d’éviter les effacements accidentels.
- Un reset complet remet aussi à zéro le chronomètre, la pause et l’état de fin de fresque.
- La célébration de fin est annulée si une mission est dévalidée ou si la fresque est réinitialisée.


## 1.0 — éditeur multi-calques
- Passage de Redacted BannerLab à la version majeure **1.0**.
- Le fond principal devient un calque sélectionnable qui reste verrouillé tout en bas de la pile.
- Ajout d’un nombre libre de calques image PNG/JPG/WebP au-dessus du fond, y compris les PNG transparents.
- Chaque calque peut être sélectionné, déplacé à un doigt, zoomé/tourné à deux doigts, masqué, réordonné, renommé, dupliqué ou supprimé.
- Le gestionnaire de calques affiche l’ordre de superposition et permet de sélectionner précisément l’image à modifier.
- Plusieurs calques image peuvent être cochés puis groupés. Un groupe se déplace, zoome et tourne comme un seul ensemble, et peut être dégroupé ensuite.
- Les calques et leurs images sont sauvegardés dans chaque projet IndexedDB et restaurés à la réouverture.
- Les anciens projets 0.10.x restent compatibles : leur image existante est reprise comme fond principal.
- L’export des missions et l’aperçu aplatissent automatiquement le fond, tous les calques image et les calques texte au rendu final.
- Clé de signature Android et identifiant de package historique inchangés afin de conserver les mises à jour APK.


## 1.0.1 — interface calques + passphrase automatique
- Correction des icônes SVG sur les boutons de l’éditeur de calques : tailles compactes sur Android.
- Mise en page mobile des actions de calques en grille compacte.
- Passphrase classique préremplie automatiquement : la question demande le numéro de la mission et la réponse vaut uniquement le numéro (`1`, `2`, `3`, etc.).
- La question est générée dans la langue du projet au moment de sa création (FR / EN / ES).
- Les passphrases personnalisées déjà renseignées ne sont jamais écrasées.
- Companion IITC mis à jour pour appliquer le même préremplissage lors de la création ou de la reprise du premier portail de mission.


## v1.0.2
- Groupes de calques beaucoup plus lisibles : couleur stable, cadre, bande latérale et badge Groupe 1/2/3… avec nombre de calques.
- Infos : mention « Créé par Zw4nn », accès au bot Telegram `https://t.me/redactedbannerlabbot` et section communauté/support.
- Signalement de problème : diagnostic technique copiable (version, plateforme/Android, langue, Companion IITC) puis ouverture de Telegram.


## 1.0.3 — sauvegarde complète
- Dossier de sauvegarde Android configurable via le sélecteur système (SAF), sans permission générale sur le stockage.
- Sauvegarde automatique optionnelle quand l’application passe en arrière-plan, uniquement si les données ont changé.
- Sauvegarde manuelle immédiate dans le dossier configuré.
- Export / import d’un JSON portable contenant tous les projets, réglages utiles et toutes les images (fond + calques).
- Restauration au choix par fusion ou remplacement complet des projets locaux.
- Nouveau logo Redacted BannerLab utilisé pour le launcher Android.
- Companion IITC reste en 0.6.3.


## 1.0.4 — autosave + studio plein écran + nouveau logo
- L’autosave ne dépend plus uniquement de `appStateChange`, trop tardif sur certains Android.
- Snapshot automatique préparé périodiquement pendant que BannerLab est encore au premier plan dès que des données changent.
- Flush supplémentaire sur `pause`, `appStateChange`, `visibilitychange` et `pagehide`.
- Une modification survenue pendant la création d’une sauvegarde déclenche automatiquement un second passage.
- Studio d’édition plein écran revu pour le portrait : une rangée de 6 missions occupe la hauteur du téléphone et les rangées suivantes deviennent des colonnes vers la droite avec scroll horizontal.
- Les anciens raccourcis de zoom `1` / `6` sont supprimés : le Studio propose désormais des modes explicites `Mission` et `Fresque`, plus zoom libre et mode Défilement tactile.
- Palettes latérales repliables pour les Calques, les Textes et les Outils.
- Les textes sont directement accessibles dans le Studio : ajout, sélection, modification, déplacement, rotation, duplication et suppression.
- Atelier typographique : choix de police, graisse, italique, alignement, espacement des lettres, interligne, contour et couleurs.
- Fond optionnel derrière le texte avec couleur, opacité, marge et radius réglables.
- Import de polices personnalisées TTF / OTF / WOFF / WOFF2 ; elles sont intégrées au projet et suivent les sauvegardes JSON.
- Le gestionnaire Image complet historique reste disponible depuis le Studio.
- Nouveau logo launcher sans texte : tête de Redacted recentrée, cercle lumineux et emblème ENL discret en arrière-plan. Le même visuel est utilisé comme logo principal dans l’application.
- Les ressources Android sont forcées à chaque build afin que le launcher installé et les métadonnées/icône de l’APK utilisent le même nouveau visuel.
- Companion IITC reste en 0.6.3.

- Barre inférieure simplifiée dans la révision v1.0.4 : `Image · Calques · Texte · Aperçu · Exporter`. L’ancien bouton `Cadrage`, qui ouvrait seulement les réglages de transformation de l’élément actif, est remplacé par un gestionnaire Calques plus explicite listant fond, images et textes. Les réglages de cadrage restent accessibles depuis l’élément concerné et par les gestes directs sur la fresque.
- Sélection de mission simplifiée et persistante : une seule mission à la fois. Le premier toucher sélectionne sans déplacer ; les gestes suivants sur cette mission la transforment. `Fresque` désélectionne la mission et revient au cadrage global. Même logique dans le mode normal.


## v1.0.5 — projet portable & bot Telegram

- Export / partage d’un seul projet au format `*.rbl.json`.
- Le projet portable contient les données de fresque, images de fond et calques, textes, polices personnalisées, missions, portails, GUID, coordonnées et actions. Le tracé est reconstructible depuis l’ordre et les coordonnées des portails.
- Import d’un projet portable comme nouveau projet, sans modifier les autres projets présents dans l’application.
- Le support Telegram pointe désormais vers `https://t.me/redactedbannerlabbot`.
- Companion IITC maintenu en v0.6.3.


## v1.0.6 — support simplifié

- Suppression complète de l’ancienne carte de soutien financier.
- La carte Communauté & support n’affiche plus un second gros bouton vers le bot ; le lien `t.me/redactedbannerlabbot` reste accessible directement.
- Dans « Signaler un problème », le bouton Telegram devient « Contacter le support » et reste l’accès principal au bot.
- Companion IITC maintenu en v0.6.3.
