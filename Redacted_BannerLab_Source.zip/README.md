# Redacted BannerLab 0.4.1

Éditeur mobile-first de fresques et bannières de missions Ingress Prime, non officiel.

## Renommage 0.4.0

- Nouveau nom visible : **Redacted BannerLab**.
- APK généré : `Redacted-BannerLab-v0.4.0.apk`.
- Artifact GitHub : `Redacted-BannerLab-APK`.
- ZIP source attendu : `Redacted_BannerLab_Source.zip`.
- Tous les exports et dossiers visibles utilisent désormais Redacted BannerLab.
- Les projets locaux des versions précédentes sont migrés automatiquement.

## Compatibilité des mises à jour Android

L'identifiant Android interne historique reste volontairement inchangé afin que cette version
puisse s'installer comme mise à jour de l'application déjà installée. Cet identifiant n'est pas
le nom affiché à l'utilisateur.

## Signature Android stable

Ne jamais remplacer `signing/redacted-bannerlab.keystore`.

SHA-256 du fichier keystore :
`1b7cc0b63572f546cd2998e7be7e09ed9ae24b5a75e3f89be5d0f18f6d34b30a`

SHA-256 du certificat attendu :
`DC:BD:F2:49:EC:D4:51:40:A2:B7:94:0E:A0:86:64:30:E1:FA:73:EC:2A:0A:18:8A:43:27:85:F6:3B:95:98:5B`

## Fonctions actuelles

- Image Redacted par défaut pour les nouveaux projets.
- Plusieurs projets locaux, nommables, duplicables et supprimables.
- 1 à 25 rangées, 6 colonnes.
- Géométrie 544 / 512 / 16.
- Recadrage global et mission par mission.
- Textes indépendants et supprimables.
- Export JPG rapide ou PNG sans perte dans un ZIP.
- APK Android aujourd'hui, architecture conservée pour une future version web.

Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n'est ni affilié ni approuvé par Niantic.


## 0.4.1 — Éditeur mission plein écran

- Une mission sélectionnée propose maintenant **Agrandir mission**.
- Éditeur plein écran 512×512 avec déplacement à un doigt.
- Pinch à deux doigts pour zoom + rotation.
- Curseurs de zoom et rotation accessibles sous la mission.
- Aperçu cercle Prime activable/désactivable.
- Navigation mission précédente / suivante sans fermer l’éditeur.
- Réinitialisation du cadrage local directement depuis l’éditeur.
