# Redacted BannerLab 0.7.0

Éditeur mobile-first de fresques et de missions Ingress Prime, non officiel.

## 0.7.0

- Mission Planner mobile entièrement revu : liste compacte des missions, puis fiche d’édition dédiée.
- Redacted BannerLab n’utilise plus UMM comme workflow principal : export natif `BannerLab` avec `missions.json` + images 512×512.
- Actions officielles par portail : Hack, Mod, Capture/Upgrade, Link, Field, Passphrase.
- Passphrase : question + réponse attendue enregistrées avec le portail.
- Reprise autorisée du dernier portail d’une mission comme premier portail de la suivante.
- Option pour reprendre automatiquement ce portail lors du passage à la mission suivante.
- Les doublons légitimes fin→début ne sont plus signalés comme erreurs.
- IITC Companion 0.5.0 inclus :
  - statistiques piétonnes Valhalla/OpenStreetMap,
  - choix de l’action,
  - question/réponse de passphrase,
  - reprise fin→début,
  - mode sécurisé basé sur `portalSelected`.
- Première couche multilingue Français / English / Español :
  - navigation principale,
  - Mission Planner,
  - publication,
  - Companion IITC.
- La langue se choisit dans Infos et est conservée sur l’appareil.

## Publication

BannerLab génère désormais son propre pack :
- `missions/001.jpg`, `002.jpg`, etc.
- `missions.json` contenant titres, descriptions, type de mission, visibilité,
  portails, coordonnées, objectifs et passphrases.

La prochaine étape est un `Redacted BannerLab Publisher` pour préremplir
le Mission Authoring Tool officiel à partir de ce format. La soumission finale
reste volontairement faite dans l’outil officiel.

## Signature Android

La clé de signature stable ne doit jamais être remplacée.


## 0.7.1 — calques globaux et historique

- Les recadrages individuels ne transforment que l'image de fond.
- Les textes restent des calques globaux, composés après tous les recadrages locaux.
- Aperçu, export rapide, export mission par mission et éditeur plein écran respectent la même composition.
- Annuler / Rétablir multi-étapes (80 opérations), avec un geste tactile = une opération.
- Undo/Redo aussi dans l'éditeur de mission plein écran.
- Ctrl+Z, Ctrl+Y et Ctrl+Shift+Z sur la future version web / clavier.


## 0.7.2 — traduction et Companion 0.6
- Nettoyage des chaînes historiques FR/EN/ES dans l’éditeur, Texte, Cadrage, Aperçu, Export, Infos et Projets.
- Companion IITC intégré en 0.6.0.
- Ouverture IITC corrigée : le payload BannerLab passe dans `#rbl=` et n’est plus envoyé au serveur Intel.
- Langue BannerLab transmise au Companion.


## 0.8.0 — Publisher intégré expérimental
- Nouveau bouton Publier → Préparer directement dans Mission Authoring.
- RBL rend les images 512×512 en mémoire et écrit un payload temporaire interne, sans ZIP ni téléchargement.
- Android ouvre une PublisherActivity WebView sur missions.ingress.com et injecte automatiquement le Publisher RBL.
- Le Publisher importe titre, description, séquentiel/caché, portails, objectifs, passphrases et image.
- Le clic final Submit reste manuel.
- Companion IITC intégré 0.6.1.
- Sync Companion accepte les formats futurs >=2.

## 0.8.1 — Publisher navigateur
- Abandon de l'authentification Google dans WebView intégrée.
- Publisher direct dans Firefox Android avec Violentmonkey.
- Une mission est transmise directement via le fragment `#rblpub=` : aucun ZIP.
- Le payload est sauvegardé côté `missions.ingress.com` avant la redirection Google.
- Mission suivante : retour automatique RBL, génération de l'image suivante, puis réouverture Firefox.
- Companion IITC 0.6.1 intégré.

## 0.8.2 — Chrome + Firefox
- Choix persistant du navigateur de publication.
- Chrome : aucune application supplémentaire, bookmarklet installé une seule fois puis lancé depuis la barre d'adresse.
- Assistant Chrome : copie du bookmarklet, ouverture Mission Authoring, test et validation par deep link.
- Firefox : mode automatique via Violentmonkey + Publisher userscript.
- Le Publisher 0.3.1 renvoie un deep link de validation pour les deux modes.
- Aucun ZIP dans le workflow de publication.

## 0.8.3 — assistant Chrome simplifié
- Bookmarklet Chrome réduit de ~20 000 caractères à 1759 caractères.
- Le bookmarklet mémorise le `FileSystemFileHandle` de `publisher.js` dans IndexedDB.
- Au premier test : sélection du fichier `publisher.js`.
- Aux utilisations suivantes : réutilisation du fichier et demande `Autoriser` si Chrome l'exige.
- Assistant Chrome en 3 étapes, mémorisé, avec précédent / continuer / recommencer.
- Test réel : le Publisher renvoie `redactedbannerlab://publisher-chrome-ready`.
- Firefox + Violentmonkey reste disponible comme mode automatique.
