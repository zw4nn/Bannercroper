# Redacted BannerLab 0.7.0

Éditeur mobile-first de fresques et de missions Ingress Prime, non officiel.

## 0.7.0

- Mission Planner mobile entièrement revu : liste compacte des missions, puis fiche d’édition dédiée.
- Redacted BannerLab n’utilise plus UMM comme workflow principal : export natif `BannerLab` avec `missions.json` + images 512×512.
- Actions officielles par portail : Hack, Mod, Capture/Upgrade, Link, Field, Passphrase.
- Passphrase : question + réponse attendue enregistrées avec le portail.
- Reprise autorisée du dernier portail d’une mission comme premier portail de la suivante.
- Option pour reprendre automatiquement ce portail lors du passage à la mission suivante.
- Les doublons légitimes fin→début ne sont plus signalés comme erreurs.
- IITC Companion 0.5.0 inclus :
  - statistiques piétonnes Valhalla/OpenStreetMap,
  - choix de l’action,
  - question/réponse de passphrase,
  - reprise fin→début,
  - mode sécurisé basé sur `portalSelected`.
- Première couche multilingue Français / English / Español :
  - navigation principale,
  - Mission Planner,
  - publication,
  - Companion IITC.
- La langue se choisit dans Infos et est conservée sur l’appareil.

## Publication

BannerLab génère désormais son propre pack :
- `missions/001.jpg`, `002.jpg`, etc.
- `missions.json` contenant titres, descriptions, type de mission, visibilité,
  portails, coordonnées, objectifs et passphrases.

La prochaine étape est un `Redacted BannerLab Publisher` pour préremplir
le Mission Authoring Tool officiel à partir de ce format. La soumission finale
reste volontairement faite dans l’outil officiel.

## Signature Android

La clé de signature stable ne doit jamais être remplacée.
